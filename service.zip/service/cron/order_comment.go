package cron

import (
	"github.com/robfig/cron"

	"gamers/controller/services"
	"gamers/models/dbmodels"
	"gamers/utils"
)

// 订单评价 系统自动完成
func OrderComment(cron *cron.Cron) {

	var SystemCommit int64
	var spec string

	if utils.Config.App.Env == "prod" {
		SystemCommit = dbmodels.SKILL_ORDER_SYSTEM_COMMENT
		spec = "0 0 3 * * ?"
	} else {
		SystemCommit = 60 * 30
		spec = "0 */1 * * * ?"
	}
	err := cron.AddFunc(spec, func() {
		comment, err := new(dbmodels.AppSkillOrder).QueryNotComment(SystemCommit)
		if err != nil {
			utils.LogErrorF("[系统自动评价订单]错误,%s", err.Error())
			return
		}
		Comment := services.NewSkillOrder()
		for _, v := range comment {
			err = Comment.Comment.SystemAutoComment(v)
			if err != nil {
				utils.LogErrorF("[系统自动评价订单]系统创建评价失败,%s", err.Error())
				continue
			}
		}
	})
	if err != nil {
		utils.LogErrorF("启动[系统自动评价订单]定时任务失败:%s", err.Error())
	}
}
