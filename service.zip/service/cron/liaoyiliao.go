package cron

import (
	"gamers/controller/services/liaoyiliao"
	"gamers/utils"

	"github.com/robfig/cron"
)

// 撩一撩初始化全局缓存
func liaoyiliaoInitGlobalCache(cron *cron.Cron) {
	// 启动时初始化
	spec := "0 0 0 * * *" // 每天0点执行
	err := cron.AddFunc(spec, func() {
		utils.LogInfoF("[撩一撩初始化全局缓存]执行")
		liaoyiliao.NewCacheMod().InitGlobalCache()
	})
	if err != nil {
		utils.LogErrorF("启动[撩一撩初始化全员缓存]定时任务失败:%s", err.Error())
	}
}

// 撩一撩更新缓存
func liaoyiliaoUpdateCache(cron *cron.Cron) {
	spec := "0 */5 * * * *" // 每1分执行
	err := cron.AddFunc(spec, func() {
		utils.LogInfoF("[撩一撩更新缓存]执行")
		liaoyiliao.NewCacheMod().RepCacheData()
	})
	if err != nil {
		utils.LogErrorF("启动[撩一撩更新缓存]定时任务失败:%s", err.Error())
	}
}
