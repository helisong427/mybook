package routers

import (
	"net/http"

	"gamers/middleware"

	"github.com/gin-gonic/gin"

	"gamers/controller"
)

// RouterInit 设置路由
func RouterInit(engine *gin.Engine) *gin.Engine {
	// 缺失路由
	engine.NoRoute(defaultRequest)

	// 默认,公共路由分组
	defaultRouter := engine.Group("/")
	{
		defaultRouter.Any("", defaultRequest)
		defaultRouter.GET("ad/adlist", middleware.Cors(), controller.AdList)
		defaultRouter.GET("ad/get_ad_list_by_type", middleware.Cors(), controller.GetAdListByType)
		defaultRouter.GET("article/list", middleware.Cors(), controller.ArticleList)
		defaultRouter.GET("article/weball", middleware.Cors(), controller.ArticleWeball) // 官网全部文章
		defaultRouter.GET("article/info", middleware.Cors(), controller.ArticleInfo)
		defaultRouter.GET("version/info", controller.GetVersionInfo)
		defaultRouter.GET("system/params", controller.GetParamList)
		defaultRouter.GET("refreshtoken", middleware.CheckRefreshToken())
		defaultRouter.GET("download-apk", controller.IndexGetApk)
		// 查询手机号
		defaultRouter.POST("query-mobile", controller.QueryMobile)
	}
	downloadRouter := engine.Group("/download")
	{
		downloadRouter.GET("/:cid/:pid/chatgogo.apk", controller.IndexDownloadApk)
	}
	indexRouter := engine.Group("/index").Use(middleware.JWTAuth())
	{
		indexRouter.GET("/params", controller.IndexParams)         // 重构已完成
		indexRouter.GET("/index", controller.Index)                // 重构已完成
		indexRouter.GET("/index-comment", controller.IndexComment) // 重构已完成
	}

	commonRouter := engine.Group("/common")
	{
		commonRouter.GET("/cos-temp-key", middleware.JWTAuth(), controller.CosTempKey)
		commonRouter.GET("/secret-cos-temp-key", middleware.JWTAuth(), controller.SecretCosTempKey)
		commonRouter.GET("/region-list", middleware.JWTAuth(), controller.GetRegionList)
		commonRouter.GET("/text-moderation", controller.TextModeration)
	}

	loginRouter := engine.Group("/login")
	{
		loginRouter.POST("/mobile", controller.LoginByMobile) // 重构已完成
		loginRouter.POST("/openid", controller.LoginByOpenid) // 重构已完成
		loginRouter.POST("/password", controller.LoginByPassword)
		loginRouter.POST("/sms-login", controller.LoginBySmsCode)
		loginRouter.POST("/multilogin", controller.LoginByMultiSmsCode)
		loginRouter.POST("/sms-code", controller.GetSmsCode)
		loginRouter.POST("/sms-bind-mobile", controller.SmsBindMobile) // 重构已完成
		// 一键绑定手机号
		loginRouter.POST("/bind-mobile", controller.BindMobile) // 重构已完成
		loginRouter.GET("/check", middleware.JWTAuth(), controller.LoginCheck)

		loginRouter.POST("/binding-sms-code", controller.BindingGetSmsCode)         // 绑定微信openid，获取验证码
		loginRouter.POST("/binding-wechat-openid", controller.BindingWechat)        // 绑定微信openid
		loginRouter.POST("/unbinding-wechat-openid", controller.UnBindingWechat)    // 解除绑定微信openid
		loginRouter.POST("/get-binding-wechat-openid", controller.GetBindingWechat) // 通过openid查询绑定信息

	}

	tweet := engine.Group("/tweet").Use(middleware.JWTAuth())
	{
		tweet.GET("/tag", controller.GetTweetTag)                // 重构已完成
		tweet.POST("/publish", controller.TweetPublish)          // 重构已完成
		tweet.GET("/detail", controller.TweetDetail)             // 重构已完成
		tweet.GET("/list", controller.TweetList)                 // 重构已完成, 推荐朋友圈列表拆分出去
		tweet.POST("/send-comment", controller.SendTweetComment) // 重构已完成
		tweet.GET("/get-comment", controller.GetTweetComment)    // 重构已完成
		tweet.POST("/like-comment", controller.LikeTweetComment) // 重构已完成
		tweet.POST("/like-tweet", controller.LikeTweet)          // 重构已完成
		tweet.POST("/hidden-tweet", controller.HiddenTweet)      // 重构已完成
		tweet.GET("/my-list", controller.MyTweetList)            // 重构已完成
		tweet.GET("/other-list", controller.OtherTweetList)      // 重构已完成
		tweet.GET("/comment-detail-list", controller.TweetCommentDetailList)
		tweet.GET("/sparring-list", controller.SparringDetailList) // 重构已完成
		tweet.POST("/delete", controller.TweetDelete)
	}

	topic := engine.Group("/topic").Use(middleware.JWTAuth())
	{
		topic.POST("/add", controller.AddTopic)
		topic.GET("/get-hot", controller.GetHotTopic)
		topic.GET("/search", controller.SearchTopic)
	}

	user := engine.Group("/user").Use(middleware.JWTAuth())
	{
		// 初始化设置
		user.POST("/init-set-user-info", controller.InitSetUserInfo)
		user.POST("/set-user-info", controller.SetUserInfo)                   // 重构已完成
		user.POST("/update-password-verify", controller.UpdatePasswordVerify) // 重构已完成
		user.POST("/set-password", controller.SetPassword)                    // 重构已完成
		user.POST("/forget-password", controller.ForGetPassword)              // 重构已完成
		user.POST("/forget-password-check", controller.ForGetPasswordCheck)   // 重构已完成
		user.GET("/user-info", controller.UserInfo)                           // 重构未完成
		user.POST("/old-mobile-sms", controller.OldMobileSms)
		user.POST("/old-mobile-check", controller.OldMobileCheck)
		user.POST("/new-mobile-bind", controller.NewMobileBind)
		user.GET("/im-sign", controller.GetImSign)        // 重构已完成
		user.POST("/follow", controller.FollowUser)       // 重构已完成
		user.GET("/savor-list", controller.UserSavorList) // 重构已完成
		user.GET("/follow-list", controller.GetUserFollowList)
		user.POST("/id-card-verification", controller.SparringIdCardVerification) // 重构已完成
		user.GET("/other-user-info", controller.OtherUserInfo)
		user.GET("/visit-save-log", controller.VisitorSaveLog)            // 存储 用户浏览记录
		user.POST("/sparring-message-set", controller.SparringMessageSet) // 设置大神是否接受用户浏览推送消息 重构已完成
		user.GET("/user-card", controller.UserCard)                       // 重构已完成
		user.POST("/update-youth", controller.UpdateUserYouth)            // 重构已完成
		user.GET("/check-youth", controller.CheckUserYouth)               // 重构已完成
		user.POST("/report", controller.Report)
		user.POST("/exchange-money", controller.ExchangeMoney)
		user.GET("/certification-detail", controller.UserCertificationDetail) // 重构已完成
		user.GET("/visitor-list", controller.UserVisitorList)
		user.GET("/wallet", controller.GetUserWalletInfo)       // 重构已完成
		user.GET("/user-income", controller.GetUserIncome)      // 已废弃
		user.GET("/sparring-income", controller.SparringIncome) // 重构已完成
		user.GET("/gift-income", controller.GetGiftIncome)      // 重构已完成
		user.GET("/other-income", controller.UserOtherIncome)
		user.POST("/set-game-order", controller.UserSetGameOrder) // 重构已完成
		user.POST("/blacklist-add", controller.BlacklistAddUser)
		user.POST("/blacklist-del", controller.BlacklistDelUser)
		user.GET("/blacklist-list", controller.BlacklistList)
		user.POST("/feedback-add", controller.FeedbackAdd)                         // 重构已完成
		user.GET("/go-bill", controller.UserGoBill)                                // 重构已完成
		user.GET("/first-charge", controller.UserFirstCharge)                      // 重构已完成
		user.GET("/live-authentication-url", controller.UserLiveAuthenticationUrl) // 重构已完成
		user.POST("/update-coordinate", controller.UserUpdateCoordinate)           // 重构已完成
	}

	// 大神
	sparring := engine.Group("/sparring").Use(middleware.JWTAuth())
	{
		sparring.POST("/skill-verification", controller.SparringSkill)           // 重构已完成
		sparring.POST("/face-verification", controller.SparringFaceVerification) // 重构已完成
		sparring.GET("/skill-list", controller.SparringSkillList)
		sparring.GET("/skill-info", controller.GetSparringSkillInfo) // 重构已完成
		sparring.GET("/history-icon", controller.SparringHistoryIcon)
		sparring.GET("/skill-get-skill-info", controller.GetSkillInfo)                               // 重构已完成
		sparring.POST("/skill-service-skill-update", controller.UpdateSparringServiceInfo)           // 重构已完成
		sparring.POST("/skill-verification-skill-update", controller.UpdateSparringVerificationInfo) // 重构已完成
		sparring.GET("/sparring-list", controller.SparringList)
		sparring.GET("/get-sparring-center", controller.SparringCenter)                       // 重构已完成
		sparring.GET("/sparring-detail", controller.SparringDetail)                           // 重构已完成
		sparring.GET("/sparring-before-placing-order", controller.SparringBeforePlacingOrder) // 重构已完成
		sparring.GET("/sparring-my-skill", controller.SparringMySkill)
		sparring.POST("/update-skill-status", controller.SparringUpdateSkillStatus) // 重构已完成

	}

	// 订单接口
	skillOrder := engine.Group("/skill-order").Use(middleware.JWTAuth())
	{
		skillOrder.POST("/submit", controller.SkillOrderSubmit)
		skillOrder.POST("/accept", controller.SkillOrderAccept)
		skillOrder.POST("/sparring-refuse", controller.SkillOrderSparringRefuse)
		skillOrder.POST("/user-cancel", controller.SkillOrderUserCancel)
		skillOrder.POST("/user-refund", controller.SkillOrderUserRefund)
		skillOrder.POST("/sparring-finish", controller.SkillOrderFinishBySparring)
		skillOrder.POST("/user-finish", controller.SkillOrderFinishByUser)
		skillOrder.POST("/refund-confirm", controller.SkillOrderRefundConfirm)
		skillOrder.GET("/detail", controller.SkillOrderDetail)
		skillOrder.GET("/sparring-order-record", controller.GetSparringOrderRecord)
		skillOrder.GET("/user-order-record", controller.GetUserOrderRecord)
		skillOrder.POST("/appeal", controller.SkillAppeal)
		skillOrder.POST("/sparring-appeal", controller.SkillSparringAppeal)
		skillOrder.GET("/refund-reason", controller.SkillRefundReason)
		skillOrder.GET("/refund-refuse-reason", controller.SkillRefundRefuseReason)
		skillOrder.POST("/refund-cancel", controller.SkillOrderRefundCancel)
		skillOrder.GET("/refund-info", controller.SkillRefundInfo) // 重构已完成
	}

	// 订单评论
	evaluation := engine.Group("/order-evaluation").Use(middleware.JWTAuth())
	{
		evaluation.POST("/label", controller.GetEvaluationLabel)   // 根据技能id获取标签
		evaluation.POST("/submit", controller.SubmitEvaluation)    // 提交评论 // 重构已完成
		evaluation.POST("/get", controller.GetEvaluation)          // 获取评论 // 重构已完成
		evaluation.POST("/get-list", controller.GetEvaluationList) // 评论列表 折叠评论列表 // 重构已完成
	}

	skillStudio := engine.Group("/studio").Use(middleware.JWTAuth())
	{
		skillStudio.GET("/attrs", controller.GetLiveRoomAttrs)                    // 重构已完成
		skillStudio.POST("/agora-token", controller.AgoraToken)                   // 重构已完成
		skillStudio.GET("/get-studio-list", controller.GetStudioList)             // 重构已完成
		skillStudio.POST("/create-studio", controller.CreateStudio)               // 重构已完成（拆分为两个接口：创建房间、重置房间）
		skillStudio.POST("/update-studio", controller.UpdateStudio)               // 重构已完成
		skillStudio.POST("/close-studio", controller.CloseStudio)                 // 重构已完成
		skillStudio.POST("/open-studio", controller.OpenStudio)                   // 重构已完成
		skillStudio.GET("/get-room-attrId", controller.GetRoomAttrId)             // 重构已完成
		skillStudio.GET("/live-settlement", controller.LiveSettlement)            // 重构已完成
		skillStudio.GET("/get-studio-info", controller.GetStudioInfo)             // 重构已完成 还差数据迁移的东西
		skillStudio.GET("/get-studio-card", controller.GetStudioCard)             // 重构已完成
		skillStudio.POST("/favorite-studio", controller.FavoriteStudio)           // 重构已完成
		skillStudio.GET("/get-favorite-list", controller.GetFavoriteList)         // 已弃用
		skillStudio.GET("/get-anchor-center", controller.GetAnchorCenter)         // 重构已完成
		skillStudio.GET("/get-quick-list", controller.GetQuickList)               // 重构已完成
		skillStudio.GET("/get-studio-count-gifts", controller.GetStudioCountGift) // 重构已完成
		skillStudio.GET("/get-studio-gifts", controller.GetStudioGift)            // 重构已完成
		skillStudio.GET("/get-user-gift-record", controller.GetUserGiftRecord)    // 重构已完成
		skillStudio.GET("/get-recommend-studios", controller.GetRecommendStudios) // 重构已完成
		skillStudio.GET("/get-own-info", controller.GetUserInfoByStudio)          // 重构已完成
		skillStudio.GET("/get-time", controller.GetTime)                          // 获取时间 // 重构已完成
	}

	// 主播模块
	Anchor := engine.Group("/anchor").Use(middleware.JWTAuth())
	{
		Anchor.POST("/apply", controller.ApplyAnchor)
		Anchor.GET("/attrs", controller.GetLiveAttrByAnchor)
		Anchor.GET("/check-status", controller.GetCheckStatusInfo)
	}
	// 消息接口
	Msg := engine.Group("/msg").Use(middleware.JWTAuth())
	{
		Msg.GET("/interactive", controller.GetInteractive)
		Msg.GET("/orders", controller.GetUserOrders)
		Msg.GET("/quick-reply", controller.GetQuickReply)
		Msg.GET("/order-skill", controller.GetOrderOrSkills)
		Msg.GET("/user-info", controller.GetMsgUserInfo)
		Msg.GET("/init-orders", controller.GetConfirmOrders)
	}

	live := engine.Group("/live").Use(middleware.JWTAuth(), middleware.LiveAuth())
	{
		live.POST("/switch-love", controller.SwitchLove)                     // 开关爱意值	---重构已完成
		live.POST("/up-and-down-wheat", controller.UpAndDownWheat)           // 上下麦		---重构已完成
		live.POST("/invite-up-wheat", controller.InviteUpWheat)              // 邀请上麦		---重构已完成
		live.POST("/accept-up-wheat", controller.AcceptUpWheat)              // 接受上麦		---重构已完成
		live.POST("/refuse-up-wheat", controller.RefuseUpWheat)              // 拒绝上麦		---重构已完成
		live.POST("/lock-and-unlock-wheat", controller.LockAndUnlockWheat)   // 锁定/解锁麦位	---重构已完成
		live.POST("/send-gift", controller.SendProp)                         // 送礼			---重构已完成
		live.POST("/update-wheat-queue", controller.UpdateWheatQueue)        // 更新麦序列表	---重构已完成
		live.GET("/wheat-list", controller.GetWheatList)                     // 获取麦位列表	---重构已完成
		live.POST("/hod-up-and-on-wheat", controller.HodUpAndOnWheat)        // 抱上下麦序	---重构已完成
		live.GET("/get-wheat-queue-list", controller.GetWheatQueueList)      // 获取麦序列表	---重构已完成
		live.POST("/set-admin", controller.SetAdmin)                         // 设置管理员	---重构已完成
		live.POST("/cancel-admin", controller.CancelAdmin)                   // 取消管理员	---重构已完成
		live.GET("/admin-list", controller.AdminList)                        // 获取管理员列表	---重构已完成
		live.POST("/mute", controller.LiveMute)                              // 禁言		    ---重构已完成
		live.POST("/unmute", controller.LiveUnMute)                          // 取消禁言		---重构已完成
		live.GET("/mute-users", controller.LiveMuteUsers)                    // 获取禁言列表  ---重构已完成
		live.POST("/kick-out", controller.LiveKickOut)                       // 踢出直播间	---重构已完成
		live.POST("/un-kick-out", controller.LiveUnKickOut)                  // 取消被踢		---重构已完成
		live.GET("/kick-users", controller.LiveKickers)                      // 获取被踢列表	---重构已完成
		live.POST("/forbidden", controller.LiveForbidden)                    // 拉黑			---重构已完成
		live.POST("/un-forbidden", controller.LiveUnForbidden)               // 取消拉黑		---重构已完成
		live.GET("/forbidden-users", controller.LiveForbiddenUsers)          // 黑名单		---重构已完成
		live.GET("/room-members-online", controller.GetLiveRoomOnlineMember) // 获取在线人员列表	---重构已完成
		live.POST("/switch-wheat", controller.LiveSwitchWheat)               // 开关麦位			---重构已完成
		live.POST("/room-before-to-check", controller.LiveRoomBeforeToCheck) // 进入直播间前预计预检查	---重构已完成
		live.POST("/confirm-downcast", controller.LiveConfirmDowncast)       // 确认下播				---重构已完成
		live.GET("/background", controller.LiveBackground)                   // 背景图				---重构已完成
		live.POST("/ban-wheat", controller.LiveBanWheat)                     // 禁麦					---重构已完成
		live.GET("/anchor-live-income", controller.GetAnchorLiveIncome)      // 获取直播中收益			---重构已完成
		live.POST("/quit", controller.QuitLive)                              // 退出房间				---重构已完成
		live.POST("/join", controller.JoinLive)                              // 进入房间				---重构已完成
		live.GET("/last-room", controller.GetLastRoom)                       // 获取上次房间			---重构已完成
		live.GET("/get-last-live-info", controller.GetLastLiveInfo)          // 开直播获取之前房间缓存	---重构已完成
		live.GET("/hug-wheat-list", controller.GetHugWheatList)              // 抱人上麦列表			---重构已完成

		// pk
		live.POST("/pk-setting", controller.RoomPkSetting)            // 房间pk设置   --重构已完成
		live.POST("/pk-start", controller.RoomPkStart)                // 房间开始pk --重构已完成
		live.POST("/pk-manual-settle", controller.RoomManualSettlePK) // 房间主动结算pk --重构已完成
		live.POST("/pk-add-time", controller.AddPkTime)               // 房间pk增加时间 --重构已完成
		live.POST("/pk-end", controller.RoomPkEnd)                    // 结束惩罚  --重构已完成
		live.GET("/pk-detail", controller.RoomPkDetail)               // 获取pk结果快照
		live.GET("/room-history-heat", controller.RoomHistoryHeat)    // 隐藏接口
	}

	// 排行榜
	rank := engine.Group("/rank").Use(middleware.JWTAuth())
	{
		rank.GET("/user-send-wealth", controller.GetRankUserSendWealth)
		rank.GET("/user-recv-charm", controller.GetRankUserRecvCharm) // 用户收礼逻辑和送礼逻辑类似，查看送礼逻辑注释整理逻辑
		rank.GET("/room-send-charm", controller.GetRankRoomSendCharm)
		rank.GET("/room-send-charm-roll-polling", middleware.LiveAuth(), controller.GetRankRoomSendCharmRollPolling)
		rank.GET("/room-user-send-wealth", middleware.LiveAuth(), controller.GetRankRoomUserSendWealth) // 类似用户送礼逻辑，过滤了房间信息而已
		rank.GET("/room-user-recv-charm", middleware.LiveAuth(), controller.GetRankRoomUserRecvCharm)
	}

	// Vip接口
	vip := engine.Group("/vip").Use(middleware.JWTAuth())
	{
		vip.GET("/privilege", controller.VipIndex)
		vip.GET("/user-info", controller.GetVipUserInfo)
	}

	// 搜索模块
	search := engine.Group("/search").Use(middleware.JWTAuth())
	{
		search.GET("/results-list", controller.SearchResultsList) // 重构已完成
		search.GET("/recommend", controller.SearchRecommend)      // 重构已完成
	}

	// 道具模块
	prop := engine.Group("/prop")
	{
		prop.GET("/get-prop-list", controller.GetPropList)
		prop.GET("/get-prop_attr", controller.GetPropAttrs)
		prop.GET("/get-gift-lists", controller.GetGiftLists)
		prop.GET("/get-user-over", controller.GetUserOver)
		prop.GET("/get-backpack-gift", controller.GetBackpackGift)
	}

	// 背包
	backpack := engine.Group("/backpack").Use(middleware.JWTAuth())
	{
		backpack.GET("/backpack-list", controller.GetBackpackList) // 获取背包列表
	}

	// 砸蛋
	eggBreak := engine.Group("/egg-break").Use(middleware.JWTAuth())
	{
		eggBreak.GET("/config-list", controller.EggBreakConfig) // 获取砸蛋配置（基础配置）
		eggBreak.GET("/setting", controller.EggBreakSetting)
		eggBreak.POST("/setting-change", controller.EggBreakSettingChange)
		eggBreak.POST("/break", middleware.LiveAuth(), controller.EggBreak)
		eggBreak.GET("/break-records", controller.EggBreakRecords)
		eggBreak.GET("/rank", controller.EggBreakRank)
	}

	turnTableKey := engine.Group("/turn-table-key").Use(middleware.JWTAuth())
	{
		turnTableKey.GET("/get", controller.TurnTableReturnKey) // 获取大转盘key
	}

	// 转盘
	turnTable := engine.Group("/turn-table").Use(middleware.CheckUserKey(), middleware.Cors())
	// turnTable := engine.Group("/turn-table")
	{
		turnTable.GET("/config-list", controller.TurnTableConfig)                      // 获取转盘配置
		turnTable.POST("/turn", controller.Turn)                                       // 转盘抽奖
		turnTable.GET("/turn-records", controller.TurnTableRecords)                    // 转盘抽奖记录
		turnTable.POST("/turn-address-save", controller.SaveAddress)                   // 保存地址
		turnTable.GET("/turn-address-get", controller.GetAddress)                      // 获取地址
		turnTable.GET("/list-task-center-turn-table", controller.TaskGetListTurnTable) // 获取任务数据(大转盘任务中心)
		turnTable.POST("/get-reward", controller.TurnTableTaskGetReward)               // 领取奖励
		turnTable.GET("/backpack-list", controller.TurnTableGetBackpackList)           // 获取背包列表
	}

	// 任务系统
	task := engine.Group("/task").Use(middleware.JWTAuth())
	{
		task.GET("/list-task-center", controller.TaskGetListTaskCenter)               // 获取任务数据（任务中心）  // 重构已完成
		task.GET("/list-checkin-continuous", controller.TaskGetListCheckinContinuous) // 获取任务数据（签到任务）	// 重构已完成
		task.POST("/report-condition", controller.TaskReportCondition)                // 上报前端任务完成条件行为来触发任务
		task.POST("/get-reward", controller.TaskGetReward)                            // 领取奖励				// 重构已完成
		task.POST("/checkin", controller.TaskCheckin)                                 // 签到
	}

	// 公会
	unionRouter := engine.Group("/union").Use(middleware.JWTAuth())
	{
		unionRouter.POST("/search", controller.UnionSearch)                  // 查找公会
		unionRouter.POST("/apply-for-join", controller.UnionApplyForJoin)    // 申请加入公会
		unionRouter.GET("/mine-union-rooms", controller.UnionMineUnionRooms) // 获取自己所在公会房间
	}

	// 商城
	shopping := engine.Group("/shopping").Use(middleware.JWTAuth())
	{
		shopping.POST("/buy-prop", controller.ShoppingBuyProp)
		shopping.GET("/dress-attr", controller.ShoppingDressAttr)
		shopping.GET("/dress-up-list", controller.ShoppingDressUpList)
		shopping.POST("/dress-up-use", controller.ShoppingDressUpUse)
		shopping.POST("/dress-take-off", controller.ShoppingDressTakeOff)
	}

	// 充值
	pay := engine.Group("/pay")
	{
		pay.GET("/recharge-parameters", middleware.JWTAuth(), controller.RechargeParameters)          // 重构完成
		pay.POST("/place-order-wechat", middleware.JWTAuth(), controller.AppPlaceOrderWechat)         // 重构完成
		pay.POST("/place-order-alipay", middleware.JWTAuth(), controller.AppPlaceOrderAlipay)         // 重构完成
		pay.POST("/place-order-apple-pay", middleware.JWTAuth(), controller.PlaceOrderApplePay)       // 重构完成
		pay.POST("/apple-pay-verify-receipt", middleware.JWTAuth(), controller.ApplePayVerifyReceipt) // 重构完成

		// h5支付使用 start
		pay.GET("/user/find", controller.UserFind)                              // 查找用户
		pay.GET("/web-recharge-parameters", controller.WebRechargeParameters)   // web端充值参数查询 重构完成
		pay.POST("/wap-place-order-wechat", controller.WapPlaceOrderWechat)     // 微信网页下单  重构完成
		pay.POST("/jsapi-place-order-wechat", controller.JsapiPlaceOrderWechat) // 微信公众号下单  重构完成
		pay.POST("/wap-place-order-alipay", controller.WapPlaceOrderAlipay)     // 支付宝网页下单  重构完成
		pay.GET("/pay-result-query", controller.PayResultQuery)                 // 支付结果查询 重构完成
		// h5支付使用 end
	}

	// 提现接口
	withdraw := engine.Group("/withdraw").Use(middleware.JWTAuth())
	{
		withdraw.GET("/home", controller.WithdrawHome)
		withdraw.POST("/bind-bank-card", controller.WithdrawBindBankCard)
		withdraw.POST("/bind-alipay", controller.WithdrawBindAlipay)
		withdraw.POST("/submit", controller.WithdrawSubmit)
	}

	// 用户隐私设置
	usePrivacy := engine.Group("/user-privacy").Use(middleware.JWTAuth())
	{
		usePrivacy.GET("/get", controller.PrivacyGet)        // 获取用户隐私设置 重构已完成
		usePrivacy.POST("/update", controller.PrivacyUpdate) // 更新用户隐私设置 重构已完成
	}

	// 撩一撩
	liaoyiliao := engine.Group("/liaoyiliao", middleware.JWTAuth())
	{
		liaoyiliao.GET("/list", controller.LiaoyiliaoList)  // 重构已完成
		liaoyiliao.POST("/send", controller.LiaoyiliaoSend) // 重构已完成
	}
	// 撩一撩邀请消息
	invMsg := engine.Group("/invite-message", middleware.JWTAuth())
	{
		// 查询用户撩一撩邀请消息状态
		invMsg.GET("/query", controller.InviteMessageQuery) //  重构已完成
		// 增加用户邀请消息
		invMsg.POST("/add", controller.InviteMessageAdd) // 重构已完成
		// 修改用户邀请消息
		invMsg.POST("/edit", controller.InviteMessageEdit) // 重构已完成
	}

	// 内网路由
	localNetwork := engine.Group("/local-network").Use(middleware.LocalNetwork())
	{
		localNetwork.POST("/live-msg", controller.LocalLiveMsg)
		localNetwork.POST("/join-union-msg", controller.LocalJoinUnionMsg) // 重构已完成, 逻辑合并到公会管理后端修改主播申请状态接口
		localNetwork.POST("/text-msg", controller.LocalTextMsg)
		localNetwork.POST("/rank-room-send-charm-modify-msg", controller.LocalRankRoomSendCharmModifyMsg)
		localNetwork.POST("/sparring-review-msg", controller.LocalSparringReviewMsg)
		localNetwork.POST("/anchor-review-msg", controller.LocalAnchorReviewMsg) // 重构已完成, 逻辑合并到后端修改主播申请状态接口
		localNetwork.POST("/get-transactionid", controller.LocalTransactionId)

		localNetwork.POST("/order-appeal-msg", controller.LocalOrderAppealMsg)             // 订单申诉消息
		localNetwork.POST("/tweet-refuse-msg", controller.LocalTweetRefuseMsg)             // 动态审核不通过消息
		localNetwork.POST("/material-refuse-msg", controller.LocalMaterialRefuseMsg)       // 素材审核不通过消息
		localNetwork.POST("/studio-refuse-msg", controller.LocalStudioRefuseMsg)           // 房间资料不通过消息
		localNetwork.POST("/sparring-forbidden-msg", controller.LocalSparringForbiddenMsg) // 大神冻结消息

		localNetwork.POST("/extract-fail-msg", controller.LocalExtractFailMsg)          // 提现失败消息
		localNetwork.POST("/extract-success-msg", controller.LocalExtractSuccessMsg)    // 提现成功消息
		localNetwork.POST("/invite-refuse-msg", controller.LocalInviteMessageRejectMsg) // 撩一撩快捷语拒绝审核消息
	}

	// 周星榜
	weekRouter := engine.Group("/week-star")
	{
		weekRouter.POST("/rank-list", controller.WeekStarRankList)     // 获取 排行榜
		weekRouter.GET("/rank-info", controller.GetWeekStarInfo)       // 获取 周星榜
		weekRouter.GET("/rank-history", controller.GetWeekStarHistory) // 获取 周星榜 历史纪录
	}
	// // 回调
	// callback := engine.Group("/callback")
	// {
	// 	callback.POST("/wechat-pay", controller.WechatPayCallback)            // 重构完成
	// 	callback.POST("/wechat-pay-jsapi", controller.WechatPayCallbackJsapi) // 重构完成
	// 	callback.POST("/alipay", controller.AlipayCallback)                   // 重构完成
	// 	callback.POST("/fdd", controller.FddCallback)
	//
	// 	callback.GET("/channel/wsd", controller.BiliBiliWSDCallback)
	// 	callback.GET("/channel/ss", controller.BiliBiliSSCallback)
	// 	callback.GET("/channel/tuia", controller.TuiACallback)
	// 	callback.GET("/channel/huawei", controller.HuaWeiCallback)
	// }

	// 微信公众号
	wechat := engine.Group("/wechat")
	{
		wechat.GET("/code-url", controller.WechatCodeUrl)
		wechat.GET("/access-token", controller.WechatAccessToken)

		wechat.GET("/binding-code-url", controller.WechatBindingCodeUrl) // 公众号绑定获取code地址
		wechat.GET("/binding-access-token", controller.WechatBindingAccessToken)
	}

	// im回调接口
	// engine.POST("im/callback", controller.ImCallBack)

	// 数据上报接口
	report := engine.Group("/report")
	{
		report.POST("/account", controller.Account)
		report.POST("/login", controller.LoginAndLogout)
		report.POST("/channel-ad", controller.ReportAd)
	}

	// 保活状态检查
	engine.GET("livez", controller.ServiceCheck)

	engine.GET("tweetlisttest", controller.TweetListTest)

	// 极速匹配
	speedMatching := engine.Group("/speed-matching", middleware.JWTAuth())
	{
		speedMatching.GET("/params", controller.SpeedMatchingParams)                             // 匹配参数 重构已完成
		speedMatching.GET("/sparring-material", controller.SpeedMatchingSparringMaterial)        // 大神素材 重构已完成
		speedMatching.POST("/place-order", controller.SpeedMatchingPlaceOrder)                   // 用户下单 重构已完成
		speedMatching.GET("/query-status", controller.SpeedMatchingQueryStatus)                  // 状态查询 重构已完成
		speedMatching.POST("/success", controller.SpeedMatchingSuccess)                          // 完成处理 重构已完成
		speedMatching.GET("/order-grabbing-center", controller.SpeedMatchingOrderGrabbingCenter) // 抢单中心 重构已完成
		speedMatching.POST("/order-cancel", controller.SpeedMatchingRefund)                      // 退款 重构已完成
		speedMatching.POST("/grabbing-orders", controller.SpeedMatchingGrabbingOrders)           // 抢单 重构已完成
		speedMatching.POST("/rematch", controller.SpeedMatchingRematch)                          // 重新下单 重构已完成
	}

	return engine
}

// 默认路由
func defaultRequest(gctx *gin.Context) {
	// response.ResponseOk(gctx, "", nil)
	r := struct {
		Code       int         `json:"code"`
		Message    string      `json:"message"`
		SubCode    string      `json:"subcode"`
		SubMessage string      `json:"submessage"`
		Data       interface{} `json:"data"`
	}{Code: 404,
		Message:    "地址不存在",
		SubCode:    "",
		SubMessage: "",
		Data:       nil}
	gctx.JSON(http.StatusNotFound, r)
	// response.ResponseError(gctx, response.RESPONSE_UNKNOWN, "地址不存在", "", "")
	return
}
