package token

import (
	"strconv"
	"time"

	"gamers/utils"
)

func CreateRTCToken(_channelName uint64, userId uint64, role int) string {
	var roleCode Role
	if role == 1 {
		roleCode = RolePublisher
	} else if role == 2 {
		roleCode = RoleSubscriber
	}
	expireTimestamp := time.Now().Unix() + 3600*24
	token, err := RTCTokenWithUID(utils.Config.Third.Agora.AppId, utils.Config.Third.Agora.AppSecret, strconv.Itoa(int(_channelName)), userId, roleCode, uint32(expireTimestamp))
	if err != nil {
		return ""
	}
	return token
}
