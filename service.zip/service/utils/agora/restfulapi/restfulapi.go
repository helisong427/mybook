package restfulapi

import (
	// "encoding/base64"
	"bytes"
	"encoding/base64"
	"encoding/json"
	"io/ioutil"
	"net/http"
	"time"

	"gamers/utils"
)

const (
	// appID          = "4e80e0d1add74e70844ba8e9a8ba809d" //Code ID
	appCertificate = "d041ef84a2574c669c73e0ab0565f920" // Code 证书
	// customerID     = "88a08f2253224658aced1e3880d4aa7c"
	// customerSecret = "c69ea9572f0a40219ff6b0ef23b4be51"
)

type CreateKickingRuleResult struct {
	RuleId int64  `json:"id"`
	Status string `json:"status"`
}
type QueryKickingRuleResult struct {
	Status string `json:"status"`
	Rules  []struct {
		RuleId   int64  `json:"id"`
		AppId    string `json:"appid"`
		Uid      int64  `json:"uid"`
		OpId     int64  `json:"opid"`
		Cname    string `json:"cname"`
		Ip       string `json:"ip"`
		Ts       string `json:"ts"`
		CreateAt string `json:"createAt"`
		UpdateAt string `json:"updateAt"`
	} `json:"rules"`
}
type UpdateKickingRuleResult struct {
	Status string `json:"status"`
	Result struct {
		RuleId int64  `json:"id"`
		Ts     string `json:"ts"`
	} `json:"result"`
}

type QueryUserPropertyResult struct {
	Success bool `json:"success"`
	Data    struct {
		Join      int64 `json:"join"`
		InChannel bool  `json:"in_channel"`
		Role      int64 `json:"role"`
	} `json:"data"`
}
type UserEvents struct {
	Events    []interface{} `json:"events"`
	RequestId string        `json:"request_id"`
	Result    string        `json:"result"`
}

type CreateHistory struct {
	Limit     int32  `json:"limit"`
	Location  string `json:"location"`
	Offset    int32  `json:"offset"`
	Order     string `json:"order"`
	RequestId string `json:"request_id"`
	Result    string `json:"result"`
}
type QueryHistory struct {
	Code      string `json:"code"`
	RequestId string `json:"request_id"`
	Result    string `json:"result"`
}
type HistoryCount struct {
	Code      string `json:"code"`
	Count     uint32 `json:"count"`
	RequestId string `json:"request_id"`
	Result    string `json:"result"`
}

type QueryUserListResult struct {
	Data struct {
		ChannelExist bool `json:"channel_exist"`
	} `json:"data"`
	Success bool `json:"success"`
}

type QueryChannelListResult struct {
	Data struct {
		Channels  []interface{} `json:"channels"`
		TotalSize uint32        `json:"total_size"`
	} `json:"data"`
	Success bool `json:"success"`
}

// RTMUserEvents 获取用户上线或下线事件
func RTMUserEvents(rtmToken string, account string) *UserEvents {
	client := &http.Client{}
	req, _ := http.NewRequest("GET", "https://api.agora.io/dev/v2/project/"+utils.Config.Agora.AppId+"/rtm/vendor/user_events", nil)
	req.Header.Set("Content-Type", "application/json;charset=utf-8")
	if rtmToken == "" && account == "" {
		basicString := base64.StdEncoding.EncodeToString([]byte(utils.Config.Agora.CustomerId + ":" + utils.Config.Agora.CustomerSecret))
		req.Header.Add("Authorization", "Basic "+basicString)
	} else {
		req.Header.Add("x-agora-token", rtmToken) // RTMToken
		req.Header.Add("x-agora-uid", account)    // 生成该 RTM Token 的 uid
	}
	resp, err := client.Do(req)
	result := &UserEvents{Result: "failed"}
	if err != nil {
		return result
	}
	defer resp.Body.Close()
	body, _ := ioutil.ReadAll(resp.Body)
	if resp.StatusCode == 200 {
		json.Unmarshal(body, &result)
	}
	return result
}

// RTMChannelEvents 获取用户加入或离开频道事件
func RTMChannelEvents(rtmToken string, account string) *UserEvents {
	client := &http.Client{}
	req, _ := http.NewRequest("GET", "https://api.agora.io/dev/v2/project/"+utils.Config.Agora.AppId+"/rtm/vendor/channel_events", nil)
	req.Header.Set("Content-Type", "application/json;charset=utf-8")
	if rtmToken == "" && account == "" {
		basicString := base64.StdEncoding.EncodeToString([]byte(utils.Config.Agora.CustomerId + ":" + utils.Config.Agora.CustomerSecret))
		req.Header.Add("Authorization", "Basic "+basicString)
	} else {
		req.Header.Add("x-agora-token", rtmToken) // RTMToken
		req.Header.Add("x-agora-uid", account)    // 生成该 RTM Token 的 uid
	}
	resp, err := client.Do(req)
	result := &UserEvents{Result: "failed"}
	if err != nil {
		return result
	}
	defer resp.Body.Close()
	body, _ := ioutil.ReadAll(resp.Body)
	if resp.StatusCode == 200 {
		json.Unmarshal(body, &result)
	}
	return result
}

// RTMCreateHistory 创建历史消息查询资源
func RTMCreateHistory(rtmToken string, account string, source string, destination string, startTime int64, endTime int64, offset int, limit int, order string) *CreateHistory {
	start_time := time.Unix(startTime, 0).UTC().Format("2006-01-02T15:04:05Z")
	end_time := time.Unix(endTime, 0).UTC().Format("2006-01-02T15:04:05Z")
	filter := make(map[string]interface{})
	filter["source"] = source           // 消息发送方，必须是用户
	filter["destination"] = destination // 消息接收方，可以是用户或频道
	filter["start_time"] = start_time   // 历史消息查询起始时间UTC,2020-09-27T10:10:00Z
	filter["end_time"] = end_time       // 历史消息查询结束时间UTC,,2020-09-27T10:10:00Z
	params := make(map[string]interface{})
	params["filter"] = filter
	params["offset"] = offset // 当前时间段内的消息偏移量。
	params["limit"] = limit   // 单页历史消息条数。可选值：
	params["order"] = "asc"
	if order != "" {
		params["order"] = order // asc（默认）：按时间顺序。desc：按时间倒序。
	}
	jsonStr, _ := json.Marshal(params)
	url := "https://api.agora.io/dev/v2/project/" + utils.Config.Agora.AppId + "/rtm/message/history/query"
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
	req.Header.Set("Content-Type", "application/json;charset=utf-8")
	if rtmToken == "" && account == "" {
		basicString := base64.StdEncoding.EncodeToString([]byte(utils.Config.Agora.CustomerId + ":" + utils.Config.Agora.CustomerSecret))
		req.Header.Add("Authorization", "Basic "+basicString)
	} else {
		req.Header.Add("x-agora-token", rtmToken) // RTMToken
		req.Header.Add("x-agora-uid", account)    // 生成该 RTM Token 的 uid
	}
	client := &http.Client{Timeout: 5 * time.Second} // 超时时间：5秒
	resp, err := client.Do(req)
	result := &CreateHistory{Result: "failed"}
	if err != nil {
		return result
	}
	defer resp.Body.Close()
	body, _ := ioutil.ReadAll(resp.Body)
	if resp.StatusCode == 200 {
		json.Unmarshal(body, &result)
	}
	return result
}

// RTMQueryHistory 获取历史消息
func RTMQueryHistory(rtmToken string, account string, handle string) *QueryHistory {
	client := &http.Client{}
	req, _ := http.NewRequest("GET", "https://api.agora.io/dev/v2/project/"+utils.Config.Agora.AppId+"/rtm/message/history/query/"+handle, nil)
	req.Header.Set("Content-Type", "application/json;charset=utf-8")
	if rtmToken == "" && account == "" {
		basicString := base64.StdEncoding.EncodeToString([]byte(utils.Config.Agora.CustomerId + ":" + utils.Config.Agora.CustomerSecret))
		req.Header.Add("Authorization", "Basic "+basicString)
	} else {
		req.Header.Add("x-agora-token", rtmToken) // RTMToken
		req.Header.Add("x-agora-uid", account)    // 生成该 RTM Token 的 uid
	}
	resp, err := client.Do(req)
	result := &QueryHistory{Result: "failed"}
	if err != nil {
		return result
	}
	defer resp.Body.Close()
	body, _ := ioutil.ReadAll(resp.Body)
	if resp.StatusCode == 200 {
		json.Unmarshal(body, &result)
	}
	return result
}

// RTMHistoryCount 获取历史消息数目
func RTMHistoryCount(rtmToken string, account string, source string, destination string, startTime int64, endTime int64) *HistoryCount {
	urlParams := ""
	if source != "" {
		urlParams = urlParams + "source=" + source + "&"
	}
	if destination != "" {
		urlParams = urlParams + "destination=" + destination + "&"
	}
	if startTime >= 0 {
		urlParams = urlParams + "start_time=" + time.Unix(startTime, 0).UTC().Format("2006-01-02T15:04:05Z") + "&"
	}
	if endTime > 0 {
		urlParams = urlParams + "end_time=" + time.Unix(endTime, 0).UTC().Format("2006-01-02T15:04:05Z") + "&"
	}
	client := &http.Client{}
	req, _ := http.NewRequest("GET", "https://api.agora.io/dev/v2/project/"+utils.Config.Agora.AppId+"/rtm/message/history/count?"+urlParams, nil)
	req.Header.Set("Content-Type", "application/json;charset=utf-8")
	if rtmToken == "" && account == "" {
		basicString := base64.StdEncoding.EncodeToString([]byte(utils.Config.Agora.CustomerId + ":" + utils.Config.Agora.CustomerSecret))
		req.Header.Add("Authorization", "Basic "+basicString)
	} else {
		req.Header.Add("x-agora-token", rtmToken) // RTMToken
		req.Header.Add("x-agora-uid", account)    // 生成该 RTM Token 的 uid
	}
	resp, err := client.Do(req)
	result := &HistoryCount{Result: "failed"}
	if err != nil {
		return result
	}
	defer resp.Body.Close()
	body, _ := ioutil.ReadAll(resp.Body)
	if resp.StatusCode == 200 {
		json.Unmarshal(body, &result)
	}
	return result
}

// RTMPeerMessages 发送点对点消息
func RTMPeerMessages(rtmToken string, account string) *QueryHistory {
	params := make(map[string]interface{})
	params["destination"] = "userB"              // 接收者
	params["enable_offline_messaging"] = true    // true: 开启离线消息 ,false 不开启
	params["enable_historical_messaging"] = true // 是否保存为历史消息。默认值是 false
	params["payload"] = "Hello"                  // 消息内容
	jsonStr, _ := json.Marshal(params)
	url := "https://api.agora.io/dev/v2/project/" + utils.Config.Agora.AppId + "/rtm/users/" + account + "/peer_messages?wait_for_ack=true"
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
	req.Header.Set("Content-Type", "application/json;charset=utf-8")
	if rtmToken == "" && account == "" {
		basicString := base64.StdEncoding.EncodeToString([]byte(utils.Config.Agora.CustomerId + ":" + utils.Config.Agora.CustomerSecret))
		req.Header.Add("Authorization", "Basic "+basicString)
	} else {
		req.Header.Add("x-agora-token", rtmToken) // RTMToken
		req.Header.Add("x-agora-uid", account)    // 生成该 RTM Token 的 uid
	}
	client := &http.Client{Timeout: 5 * time.Second} // 超时时间：5秒
	resp, err := client.Do(req)
	result := &QueryHistory{Result: "failed"}
	if err != nil {
		return result
	}
	defer resp.Body.Close()
	body, _ := ioutil.ReadAll(resp.Body)
	if resp.StatusCode == 200 {
		json.Unmarshal(body, &result)
	}
	return result
}

// RTMChannelMessages 发送频道消息
func RTMChannelMessages(rtmToken string, account string, channel string) *QueryHistory {
	params := make(map[string]interface{})
	params["channel_name"] = channel             // 接收频道消息的 RTM 频道名
	params["enable_historical_messaging"] = true // 是否保存为历史消息。默认值是 false
	params["payload"] = "Hello"                  // 消息内容
	jsonStr, _ := json.Marshal(params)
	url := "https://api.agora.io/dev/v2/project/" + utils.Config.Agora.AppId + "/rtm/users/" + account + "/channel_messages?wait_for_ack=true"
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
	req.Header.Set("Content-Type", "application/json;charset=utf-8")
	if rtmToken == "" && account == "" {
		basicString := base64.StdEncoding.EncodeToString([]byte(utils.Config.Agora.CustomerId + ":" + utils.Config.Agora.CustomerSecret))
		req.Header.Add("Authorization", "Basic "+basicString)
	} else {
		req.Header.Add("x-agora-token", rtmToken) // RTMToken
		req.Header.Add("x-agora-uid", account)    // 生成该 RTM Token 的 uid
	}
	client := &http.Client{Timeout: 5 * time.Second} // 超时时间：5秒
	resp, err := client.Do(req)
	result := &QueryHistory{Result: "failed"}
	if err != nil {
		return result
	}
	defer resp.Body.Close()
	body, _ := ioutil.ReadAll(resp.Body)

	if resp.StatusCode == 200 {
		json.Unmarshal(body, result)
	}
	return result
}

// CreateKickingRule 创建踢人规则
func CreateKickingRule(appid string, uid int, channel string, ip string, ruleTime int) *CreateKickingRuleResult {
	params := make(map[string]interface{})
	params["appid"] = appid
	params["cname"] = channel
	params["uid"] = uid
	params["ip"] = ip
	params["time"] = ruleTime
	params["privileges"] = []string{"join_channel"}
	jsonStr, _ := json.Marshal(params)
	url := "https://api.agora.io/dev/v1/kicking-rule"
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
	basicString := base64.StdEncoding.EncodeToString([]byte(utils.Config.Agora.CustomerId + ":" + utils.Config.Agora.CustomerSecret))
	req.Header.Add("Authorization", "Basic "+basicString)
	req.Header.Set("Content-Type", "application/json;charset=utf-8")
	client := &http.Client{Timeout: 5 * time.Second} // 超时时间：5秒
	resp, err := client.Do(req)
	result := &CreateKickingRuleResult{Status: "fail", RuleId: 0}
	if err != nil {
		return result
	}
	defer resp.Body.Close()
	body, _ := ioutil.ReadAll(resp.Body)
	if resp.StatusCode == 200 {
		json.Unmarshal(body, result)
	}
	return result
}

// QueryKickingRule获取踢人规则列表
func QueryKickingRule(appid string) *QueryKickingRuleResult {
	client := &http.Client{}
	req, _ := http.NewRequest("GET", "https://api.agora.io/dev/v1/kicking-rule?appid="+appid, nil)
	basicString := base64.StdEncoding.EncodeToString([]byte(utils.Config.Agora.CustomerId + ":" + utils.Config.Agora.CustomerSecret))
	req.Header.Add("Authorization", "Basic "+basicString)
	req.Header.Set("Content-Type", "application/json;charset=utf-8")
	resp, err := client.Do(req)
	result := &QueryKickingRuleResult{Status: "fail"}
	if err != nil {
		return result
	}
	defer resp.Body.Close()
	body, _ := ioutil.ReadAll(resp.Body)
	if resp.StatusCode == 200 {
		json.Unmarshal(body, result)
	}
	return result
}

// UpdateKickingRule 更新踢人规则的生效时间
func UpdateKickingRule(appID string, ruleId int, ruleTime int) *UpdateKickingRuleResult {
	client := &http.Client{}
	params := make(map[string]interface{})
	params["appid"] = appID
	params["id"] = ruleId
	params["time"] = ruleTime
	jsonStr, _ := json.Marshal(params)
	req, _ := http.NewRequest("PUT", "https://api.agora.io/dev/v1/kicking-rule", bytes.NewBuffer(jsonStr))
	basicString := base64.StdEncoding.EncodeToString([]byte(utils.Config.Agora.CustomerId + ":" + utils.Config.Agora.CustomerSecret))
	req.Header.Add("Authorization", "Basic "+basicString)
	req.Header.Set("Content-Type", "application/json;charset=utf-8")
	resp, err := client.Do(req)
	result := &UpdateKickingRuleResult{Status: "fail"}
	if err != nil {
		return result
	}
	defer resp.Body.Close()
	body, _ := ioutil.ReadAll(resp.Body)
	if resp.StatusCode == 200 {
		json.Unmarshal(body, result)
	}
	return result
}

// DeleteKickingRule 删除踢人规则
func DeleteKickingRule(appID string, ruleId int) *CreateKickingRuleResult {
	client := &http.Client{}
	params := make(map[string]interface{})
	params["appid"] = appID
	params["id"] = ruleId
	jsonStr, _ := json.Marshal(params)
	req, _ := http.NewRequest("DELETE", "https://api.agora.io/dev/v1/kicking-rule", bytes.NewBuffer(jsonStr))
	basicString := base64.StdEncoding.EncodeToString([]byte(utils.Config.Agora.CustomerId + ":" + utils.Config.Agora.CustomerSecret))
	req.Header.Set("Content-Type", "application/json;charset=utf-8")
	req.Header.Add("Authorization", "Basic "+basicString)
	resp, err := client.Do(req)
	result := &CreateKickingRuleResult{Status: "fail"}
	if err != nil {
		return result
	}
	defer resp.Body.Close()
	body, _ := ioutil.ReadAll(resp.Body)
	if resp.StatusCode == 200 {
		json.Unmarshal(body, result)
	}
	return result
}

// QueryUserProperty 查询用户状态
func QueryUserProperty(appid string, uid int, channel string) *QueryUserPropertyResult {
	client := &http.Client{}
	req, _ := http.NewRequest("GET", "https://api.agora.io/dev/v1/channel/user/property/"+appid+"/"+string(uid)+"/"+channel, nil)
	basicString := base64.StdEncoding.EncodeToString([]byte(utils.Config.Agora.CustomerId + ":" + utils.Config.Agora.CustomerSecret))
	req.Header.Set("Content-Type", "application/json;charset=utf-8")
	req.Header.Add("Authorization", "Basic "+basicString)
	resp, err := client.Do(req)
	result := &QueryUserPropertyResult{Success: false}
	if err != nil {
		return result
	}
	defer resp.Body.Close()
	body, _ := ioutil.ReadAll(resp.Body)
	if resp.StatusCode == 200 {
		json.Unmarshal(body, result)
	}
	return result
}

// QueryUserList 获取用户列表
func QueryUserList(appid string, channel string) *QueryUserListResult {
	client := &http.Client{}
	req, _ := http.NewRequest("GET", "https://api.agora.io/dev/v1/channel/user/"+appid+"/"+channel, nil)
	basicString := base64.StdEncoding.EncodeToString([]byte(utils.Config.Agora.CustomerId + ":" + utils.Config.Agora.CustomerSecret))
	req.Header.Set("Content-Type", "application/json;charset=utf-8")
	req.Header.Add("Authorization", "Basic "+basicString)
	resp, err := client.Do(req)
	result := &QueryUserListResult{Success: false}
	if err != nil {
		return result
	}
	defer resp.Body.Close()
	body, _ := ioutil.ReadAll(resp.Body)
	if resp.StatusCode == 200 {
		json.Unmarshal(body, result)
	}
	return result
}

// 分页查询项目的频道列表
func QueryChannelList(appid string, page_no int32, page_size int32) *QueryChannelListResult {
	urlParams := ""
	if page_no > 0 {
		urlParams = urlParams + "page_no=" + string(page_no) + "&"
	}
	if page_size > 0 {
		urlParams = urlParams + "page_size=" + string(page_size) + "&"
	}
	client := &http.Client{}
	req, _ := http.NewRequest("GET", "https://api.agora.io/dev/v1/channel/"+appid+"?"+urlParams, nil)
	basicString := base64.StdEncoding.EncodeToString([]byte(utils.Config.Agora.CustomerId + ":" + utils.Config.Agora.CustomerSecret))
	req.Header.Set("Content-Type", "application/json;charset=utf-8")
	req.Header.Add("Authorization", "Basic "+basicString)
	resp, err := client.Do(req)
	result := &QueryChannelListResult{Success: false}
	if err != nil {
		return result
	}
	defer resp.Body.Close()
	body, _ := ioutil.ReadAll(resp.Body)
	if resp.StatusCode == 200 {
		json.Unmarshal(body, result)
	}
	return result
}
