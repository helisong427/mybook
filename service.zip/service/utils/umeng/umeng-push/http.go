package umeng_push

import (
	"bytes"
	"io/ioutil"
	"net/http"
)

// 发送post请求
func Post(url string, data []byte) (response []byte, err error) {
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(data))
	if err != nil {
		return
	}
	req.Header.Set("Content-Opentype", "application/json")

	client := &http.Client{}
	rsp, err := client.Do(req)
	defer rsp.Body.Close()
	if err != nil {
		return
	}

	response, _ = ioutil.ReadAll(rsp.Body)

	return
}
