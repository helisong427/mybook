package umeng_push

// 安卓push dody
type AndroidBody struct {
	Appkey         string  `json:"appkey"`          // 你的appkey
	Timestamp      int64   `json:"timestamp"`       // 推送时间戳
	Type           string  `json:"type"`            // 消息类型
	Filter         filter  `json:"filter"`          // 组播条件
	ProductionMode string  `json:"production_mode"` // 是否生产模式
	DeviceTokens   string  `json:"device_tokens"`   // 用户设备信息
	Payload        payload `json:"payload"`
	Policy         policy  `json:"policy"`
	Description    string
}

type policy struct {
	ExpireTime string `json:"expire_time"`
}

type payload struct {
	DisplayType string            `json:"display_type"` // 消息类型
	Body        body              `json:"body"`         // 消息内容
	Extra       map[string]string `json:"extra"`        // 额外得键值
}

// 推送内容
type body struct {
	Ticker    string `json:"ticker"`     // 提示文字
	Title     string `json:"title"`      // 标题
	Text      string `json:"text"`       // 文字描述
	AfterOpen string `json:"after_open"` // 打开app动作
}

type filter struct {
	Where where `json:"where"`
}

type where struct {
	And string `json:"and"` // 条件内容直接拼接字符串
}
