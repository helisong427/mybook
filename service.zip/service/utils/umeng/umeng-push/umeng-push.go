package umeng_push

import (
	"encoding/json"
	"errors"
	"strings"
	"time"

	"github.com/tidwall/sjson"
)

type UPushNew struct {
	Appkey      string `json:"appkey"` // 你的appkey
	Secret      string `json:"secret"`
	Timestamp   int64  `json:"timestamp"`    // 推送类型
	ExpireTime  string `json:"expire_time"`  // 过期时间
	DisplayType string `json:"display_type"` // 消息类型
}

// 组群消息条件
type PushCondition struct {
	AppVersion    []string // (应用版本)
	Channel       []string // (渠道)
	Tag           []string // (用户标签)
	LaunchFrom    string   // (一段时间内活跃)
	NotLaunchFrom string   // (一段时间内不活跃)
	// Country       []string //(国家和地区)
	// Language      []string //(语言)
	// DeviceModel   []string //(设备型号)
	// Province      []string //(省)
}

const (
	// 发送类型
	SEND_ONE       = "unicast"   // 单播
	SEND_LIST      = "listcast"  // 列播
	SEND_ALL       = "broadcast" // 广播
	SEND_GROUPCAST = "groupcast" // 组播

	// 消息类型
	DISPLAY_TYPE = "notification"

	// 友盟推送地址
	PUSH_YRL = "http://msg.umeng.com/api/send"
)

// 响应内容
type PushResponse struct {
	Ret  string `json:"ret"`
	Data struct {
		MsgId     string `json:"msg_id"`
		ErrorCode string `json:"error_code"`
		ErrorMsg  string `json:"error_msg"`
	}
}

// 初始化参数
func NewPush() *UPushNew {
	return &UPushNew{
		Appkey:      "5f5329dd7823567fd86430c0",
		Secret:      "ewdx9gvd686oevws7tinkikmyav8rd30",
		Timestamp:   time.Now().Unix(),
		ExpireTime:  time.Now().Add(+time.Minute * 10).Format("2006-01-02 15:04:05"), // 10分钟过后过期
		DisplayType: DISPLAY_TYPE,
	}
}

// 发送安卓单播消息
func (u *UPushNew) SendAndroidUnicast(title string, text string, afterOpen string, extra map[string]string, devicesTokens string) (res PushResponse, err error) {
	body := AndroidBody{
		Appkey:         u.Appkey,
		Timestamp:      u.Timestamp,
		Type:           SEND_ONE,
		ProductionMode: "false",
		DeviceTokens:   devicesTokens,
		Description:    "发送android单播消息",
	}

	u.androidBodyHandler(title, text, afterOpen, extra, &body)
	bodyByte, err := json.Marshal(&body)
	if err != nil {
		return
	}
	res, err = u.send(bodyByte)
	if err != nil {
		return
	}
	return
}

// 发送iOS单播消息
func (u *UPushNew) SendIOSUnicast(title string, text string, extra map[string]string, devicesTokens string) (res PushResponse, err error) {
	body := IOSBody{
		Appkey:         u.Appkey,
		Timestamp:      u.Timestamp,
		Type:           SEND_ONE,
		ProductionMode: "false",
		DeviceTokens:   devicesTokens,
		Description:    "发送android单播消息",
	}
	u.iOSBodyHandler(title, text, &body)
	bodyByte, err := json.Marshal(&body)
	if err != nil {
		return
	}
	// 插入额外参数
	bodyByte, err = iosAddExtra(bodyByte, extra)
	if err != nil {
		return
	}

	res, err = u.send(bodyByte)
	if err != nil {
		return
	}
	return
}

// 发送安卓列播消息
func (u *UPushNew) SendAndroidListcast(title string, text string, afterOpen string, extra map[string]string, devicesTokenMap []string) (res PushResponse, err error) {
	devicesTokens := strings.Join(devicesTokenMap, ",")
	body := AndroidBody{
		Appkey:         u.Appkey,
		Timestamp:      u.Timestamp,
		Type:           SEND_LIST,
		ProductionMode: "false",
		DeviceTokens:   devicesTokens,
		Description:    "发送android列播消息",
	}
	u.androidBodyHandler(title, text, afterOpen, extra, &body)
	bodyByte, err := json.Marshal(&body)
	if err != nil {
		return
	}
	res, err = u.send(bodyByte)
	if err != nil {
		return
	}
	return
}

// 发送iOS列表消息
func (u *UPushNew) SendIOSListcast(title string, text string, extra map[string]string, devicesTokenMap []string) (res PushResponse, err error) {
	devicesTokens := strings.Join(devicesTokenMap, ",")
	body := IOSBody{
		Appkey:         u.Appkey,
		Timestamp:      u.Timestamp,
		Type:           SEND_LIST,
		ProductionMode: "false",
		DeviceTokens:   devicesTokens,
		Description:    "发送android列播消息",
	}
	u.iOSBodyHandler(title, text, &body)
	body.Policy.ExpireTime = u.ExpireTime
	bodyByte, err := json.Marshal(&body)
	if err != nil {
		return
	}

	// 插入额外参数
	bodyByte, err = iosAddExtra(bodyByte, extra)
	if err != nil {
		return
	}
	res, err = u.send(bodyByte)
	if err != nil {
		return
	}
	return
}

// 发送安卓广播消息
// 向安装app的所有android用户发送消息
func (u *UPushNew) SendAndroidBroadcast(title string, text string, afterOpen string, extra map[string]string) (res PushResponse, err error) {
	body := AndroidBody{
		Appkey:         u.Appkey,
		Timestamp:      u.Timestamp,
		Type:           SEND_ALL,
		ProductionMode: "false",
		Description:    "发送android广播消息",
	}
	u.androidBodyHandler(title, text, afterOpen, extra, &body)
	bodyByte, err := json.Marshal(&body)
	if err != nil {
		return
	}
	res, err = u.send(bodyByte)
	if err != nil {
		return
	}
	return
}

// 发送iOS广播消息
// 向安装app的所有ios用户发送消息
func (u *UPushNew) SendIOSBroadcast(title string, text string, afterOpen string, extra map[string]string) (res PushResponse, err error) {
	body := IOSBody{
		Appkey:         u.Appkey,
		Timestamp:      u.Timestamp,
		Type:           SEND_ALL,
		ProductionMode: "false",
		Description:    "发送android广播消息",
	}
	u.iOSBodyHandler(title, text, &body)
	body.Policy.ExpireTime = u.ExpireTime
	bodyByte, err := json.Marshal(&body)
	if err != nil {
		return
	}
	bodyByte, err = iosAddExtra(bodyByte, extra)
	if err != nil {
		return
	}

	res, err = u.send(bodyByte)
	if err != nil {
		return
	}
	return
}

// 发送安卓组播消息
func (u *UPushNew) SendAndroidGroupcast(title string, text string, afterOpen string, extra map[string]string) (res PushResponse, err error) {
	body := AndroidBody{
		Appkey:         u.Appkey,
		Timestamp:      u.Timestamp,
		Type:           SEND_GROUPCAST,
		ProductionMode: "false",
		Description:    "发送android组播消息",
	}
	u.androidBodyHandler(title, text, afterOpen, extra, &body)
	// 条件拼接
	body.Filter.Where.And = ""

	bodyByte, err := json.Marshal(&body)
	if err != nil {
		return
	}
	res, err = u.send(bodyByte)
	if err != nil {
		return
	}
	return
}

// 发送iOS组播消息
func (u *UPushNew) SendIosGroupcast(title string, text string, extra map[string]string) (res PushResponse, err error) {
	body := IOSBody{
		Appkey:         u.Appkey,
		Timestamp:      u.Timestamp,
		Type:           SEND_GROUPCAST,
		ProductionMode: "false",
		Description:    "发送android组播消息",
	}
	u.iOSBodyHandler(title, text, &body)
	// 条件拼接
	body.Filter.Where.And = ""

	bodyByte, err := json.Marshal(&body)
	if err != nil {
		return
	}
	bodyByte, err = iosAddExtra(bodyByte, extra)
	if err != nil {
		return
	}

	res, err = u.send(bodyByte)
	if err != nil {
		return
	}
	return
}

// 发送推送请求
func (u *UPushNew) send(bodyByte []byte) (res PushResponse, err error) {
	body := string(bodyByte)
	url := UrlSign(PUSH_YRL, body, u.Secret)
	respBytes, err := Post(url, bodyByte)
	if err != nil {
		return
	}
	// 绑定到结构体
	err = json.Unmarshal(respBytes, &res)
	if err != nil {
		return
	}
	if res.Ret != "success" {
		err = errors.New(res.Data.ErrorMsg)
		return
	}
	return
}

// android body 通用参数处理
func (u *UPushNew) androidBodyHandler(title string, text string, afterOpen string, extra map[string]string, body *AndroidBody) {
	body.Payload.DisplayType = u.DisplayType
	body.Payload.Body.Ticker = title
	body.Payload.Body.Title = title
	body.Payload.Body.Text = text
	body.Payload.Body.AfterOpen = afterOpen
	body.Payload.Extra = extra
	body.Policy.ExpireTime = u.ExpireTime
}

// iOS body 通用参数处理
func (u *UPushNew) iOSBodyHandler(title string, text string, body *IOSBody) {
	body.Payload.Aps.Alert.Subtitle = title
	body.Payload.Aps.Alert.Title = title
	body.Payload.Aps.Alert.Body = text
	body.Policy.ExpireTime = u.ExpireTime
}

// 增加ios消息额外参数
func iosAddExtra(bodyByte []byte, extra map[string]string) ([]byte, error) {
	for k, v := range extra {
		bodyByte, err := sjson.SetBytes(bodyByte, "payload."+k, v)
		if err != nil {
			return bodyByte, err
		}
	}
	return bodyByte, nil
}
