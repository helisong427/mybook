package umeng_push

import (
	"encoding/json"
	"errors"
	"time"
)

// push tagBody参数
type PushTagBody struct {
	Appkey       string `json:"appkey"`        // 必填, 应用唯一标识
	Timestamp    int64  `json:"timestamp"`     // 必填, 时间戳,10位或者13位均可,时间戳有效期为10分钟
	DeviceTokens string `json:"device_tokens"` // 只支持一个device_token
	Tag          string `json:"tag"`           // 要添加的标签,如果有多个,以英文逗号分隔
}

type TagRequest struct {
	Url    string
	Body   string
	Secret string
}

// 管理用户自定义标签-调用返回
type TagResponse struct {
	Ret  string `json:"ret"` // SUCCESS/FAIL
	Data struct {
		// 当"ret"为"FAIL"时,包含如下参数:
		ErrorCode string `json:"error_code"`
		ErrorMsg  string `json:"error_msg"`
	} `json:"data"`
}

const (
	TAG_LIST   = "http://msg.umeng.com/api/tag/list"   // 查询设备tag列表
	TAG_SET    = "http://msg.umeng.com/api/tag/set"    // 设置设备tag
	TAG_DELETE = "http://msg.umeng.com/api/tag/delete" // 删除设备tag
	TAG_CLEAR  = "http://msg.umeng.com/api/tag/clear"  // 清除设备tag
)

// 初始化
func NewPushTag() *PushTagBody {
	return &PushTagBody{
		Appkey:    "xxx",
		Timestamp: time.Now().Unix(),
	}
}

// 查询设备tag列表
func (p *PushTagBody) TagList(deviceTokens string) (result TagResponse, err error) {
	p.DeviceTokens = deviceTokens
	bodyBytes, _ := json.Marshal(p)
	t := TagRequest{
		Url:  TAG_LIST,
		Body: string(bodyBytes),
	}
	return t.Send()
}

// 设置设备tag
func (p *PushTagBody) TagSet(deviceTokens string, tag string) (result TagResponse, err error) {
	p.DeviceTokens = deviceTokens
	p.Tag = tag
	bodyBytes, _ := json.Marshal(p)
	t := TagRequest{
		Url:  TAG_DELETE,
		Body: string(bodyBytes),
	}
	return t.Send()
}

// 设置设备tag
func (p *PushTagBody) TagClear(deviceTokens string) (result TagResponse, err error) {
	p.DeviceTokens = deviceTokens
	bodyBytes, _ := json.Marshal(p)
	t := TagRequest{
		Url:  TAG_CLEAR,
		Body: string(bodyBytes),
	}
	return t.Send()
}

// 删除设备tag
func (p *PushTagBody) TagDelete(deviceTokens string, tag string) (result TagResponse, err error) {
	p.DeviceTokens = deviceTokens
	p.Tag = tag
	bodyBytes, _ := json.Marshal(p)
	t := TagRequest{
		Url:  TAG_SET,
		Body: string(bodyBytes),
	}
	return t.Send()
}

func (t *TagRequest) Send() (result TagResponse, err error) {
	t.Secret = "xxx"
	url := UrlSign(t.Url, t.Body, t.Secret)
	respBytes, err := Post(url, []byte(t.Body))
	if err != nil {
		return
	}
	// 绑定到结构体
	err = json.Unmarshal(respBytes, &result)
	if err != nil {
		return
	}

	if result.Ret != "success" {
		err = errors.New(result.Data.ErrorMsg)
	}

	return
}
