package umeng_push

// iOS push dody
// 安卓push dody
type IOSBody struct {
	Appkey         string     `json:"appkey"`          // 你的appkey
	Timestamp      int64      `json:"timestamp"`       // 推送时间戳
	Type           string     `json:"type"`            // 消息类型
	Filter         filter     `json:"filter"`          // 组播条件
	ProductionMode string     `json:"production_mode"` // 是否生产模式
	DeviceTokens   string     `json:"device_tokens"`   // 用户设备信息
	Payload        iosPayload `json:"payload"`
	Policy         policy     `json:"policy"`
	Description    string
}

type iosPayload struct {
	Aps aps `json:"aps"`
}

type aps struct {
	Alert alert `json:"alert"` // 消息内容
}

type alert struct {
	Subtitle string `json:"subtitle"`
	Title    string `json:"title"`
	Body     string `json:"body"`
}
