package tencentIm

import (
	"strconv"
)

const (
	SET_NO_SPEAKING = "v4/openconfigsvr/setnospeaking" // 设置全局禁言
	GET_NO_SPEAKING = "v4/openconfigsvr/getnospeaking" // 查询全局禁言
)

type SetNoSpeakingRequest struct {
	SetAccount   string `json:"Set_Account"`
	C2CmsgTime   int64  `json:"C2CmsgNospeakingTime"`
	GroupmsgTime int64  `json:"GroupmsgNospeakingTime"`
}

type SetNoSpeakingResponse struct {
	ErrorCode int    `json:"ErrorCode"`
	ErrorInfo string `json:"ErrorInfo"`
}

// 禁言
func SetNoSpeaking(userId, c2cmsgTime, groupmsgTime int64) (err error) {
	// 查询用户信息
	data := SetNoSpeakingRequest{
		SetAccount:   strconv.Itoa(int(userId)),
		C2CmsgTime:   c2cmsgTime,
		GroupmsgTime: groupmsgTime,
	}
	res := SetNoSpeakingResponse{}
	err = post(SET_NO_SPEAKING, data, &res)
	return
}
