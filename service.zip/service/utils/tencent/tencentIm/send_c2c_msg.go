package tencentIm

import (
	"encoding/json"
	"errors"
	"math/rand"
	"time"
)

const (
	SEND_C2C_MSG = "v4/openim/sendmsg"
)

type CustomMsg struct {
	MsgType    string        `json:"MsgType"`
	MsgContent TIMCustomElem `json:"MsgContent"`
}

type TIMCustomElem struct {
	OfflineTitle string `json:"-"`
	Data         string `json:"Data"`
	Desc         string `json:"Desc"`
	Ext          string `json:"Ext"`
	Sound        string `json:"Sound"`
}

type OfflinePushInfo struct {
	Title    string `json:"Title"`
	PushFlag int    `json:"PushFlag"`
	Desc     string `json:"Desc"`
	Ext      string `json:"Ext"`
}

// 发送用户单聊自定义消息
type SendC2CMsgRequest struct {
	SyncOtherMachine int             `json:"SyncOtherMachine"`
	FromAccount      string          `json:"From_Account"`
	ToAccount        string          `json:"To_Account"`
	MsgLifeTime      int64           `json:"MsgLifeTime"`
	MsgRandom        int             `json:"MsgRandom"`
	MsgTimeStamp     int64           `json:"MsgTimeStamp"`
	MsgBody          []CustomMsg     `json:"MsgBody"`
	OfflinePushInfo  OfflinePushInfo `json:"OfflinePushInfo"`
}

// SendC2CSingleMsgRequest 发送用户私聊文本消息请求结构体
type SendC2CSingleMsgRequest struct {
	SyncOtherMachine int             `json:"SyncOtherMachine"`
	FromAccount      string          `json:"From_Account"`
	ToAccount        string          `json:"To_Account"`
	MsgLifeTime      int64           `json:"MsgLifeTime"`
	MsgRandom        int             `json:"MsgRandom"`
	MsgTimeStamp     int64           `json:"MsgTimeStamp"`
	MsgBody          []TextBody      `json:"MsgBody"`
	OfflinePushInfo  OfflinePushInfo `json:"OfflinePushInfo"`
}

// TextBody 文本内容
type TextBody struct {
	MsgType    string  `json:"MsgType"`
	MsgContent TextMsg `json:"MsgContent"`
}

// TextMsg 文本消息
type TextMsg struct {
	Text string `text`
}

// SendC2CSingleMsgResponse 发送用户私聊文本消息响应结构体
type SendC2CSingleMsgResponse struct {
	ActionStatus string `json:"ActionStatus"` // 请求处理的结果，OK 表示处理成功，FAIL 表示失败
	ErrorCode    int    `json:"ErrorCode"`    // 错误码，0表示成功，非0表示失败
	ErrorInfo    string `json:"ErrorInfo"`    // 错误信息
	MsgTime      int    `json:"MsgTime"`      // 消息时间戳，UNIX 时间戳
	MsgKey       string `json:"MsgKey"`       // 消息唯一标识，用于撤回。长度不超过50个字符
}

const (
	SYS_IM_USER_NOTIFICATION = "1" // 发送系统通知用的账号id
)

const DEFAULT_MSGLIFETIE = 60 * 60 * 24 * 7

// 在群组中发送普通消息
func SendC2CMsg(fromAccount string, targetId string, msg interface{}) (err error) {
	msgstr, _ := json.Marshal(msg)
	rand.Seed(time.Now().UnixNano())
	data := SendC2CMsgRequest{
		FromAccount:      fromAccount,
		SyncOtherMachine: 2,
		ToAccount:        targetId,
		MsgLifeTime:      DEFAULT_MSGLIFETIE,
		MsgRandom:        rand.Intn(MAX_RAND_NUM),
		MsgTimeStamp:     time.Now().Unix(),
		MsgBody: []CustomMsg{{MsgType: "TIMCustomElem", MsgContent: TIMCustomElem{
			Data: string(msgstr),
		}}},
	}
	res := SendGroupMsgResponse{}
	err = post(SEND_C2C_MSG, data, &res)
	return
}

// SendC2CSingleMsg 给用户发送单条私聊消息
func SendC2CSingleMsg(fromAccount string, toAccount string, msg string) (err error) {
	rand.Seed(time.Now().UnixNano())
	data := SendC2CSingleMsgRequest{
		FromAccount:      fromAccount,
		SyncOtherMachine: 2,
		ToAccount:        toAccount,
		MsgLifeTime:      DEFAULT_MSGLIFETIE,
		MsgRandom:        rand.Intn(MAX_RAND_NUM),
		MsgTimeStamp:     time.Now().Unix(),
		MsgBody: []TextBody{{
			"TIMTextElem",
			TextMsg{
				Text: msg,
			},
		}},
	}
	res := SendC2CSingleMsgResponse{}
	err = post(SEND_C2C_MSG, data, &res)
	if err != nil {
		return
	}
	if res.ErrorCode != 0 {
		err = errors.New(res.ErrorInfo)
		return
	}

	return
}
