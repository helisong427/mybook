package tencentIm

const (
	ADD_USER_ATTR = "v4/all_member_push/im_set_attr"
	DEL_USER_ATTR = "v4/all_member_push/im_remove_attr"
	GET_USER_ATTR = "v4/all_member_push/im_get_attr"
)

type AddUserAttrReq struct {
	UserAttrs []AddUserAttrItem `json:"UserAttrs"`
}
type AddUserAttrItem struct {
	ToAccount string            `json:"To_Account"`
	Attrs     map[string]string `json:"Attrs"`
}

// 设置用户多个属性
func AddUserAttr(user string, attr map[string]string) (err error) {
	item := AddUserAttrItem{
		ToAccount: user,
		Attrs:     attr,
	}
	data := AddUserAttrReq{
		UserAttrs: []AddUserAttrItem{item},
	}
	res := baseResponse{}
	err = post(ADD_USER_ATTR, data, &res)
	return
}

type DelUserAttrReq struct {
	UserAttrs []DelUserAttrItem `json:"UserAttrs"`
}
type DelUserAttrItem struct {
	ToAccount string   `json:"To_Account"`
	Attrs     []string `json:"Attrs"`
}

// 删除用户属性
func DelUserAttr(user, key string) (err error) {
	item := DelUserAttrItem{
		ToAccount: user,
		Attrs:     []string{key},
	}
	data := DelUserAttrReq{
		UserAttrs: []DelUserAttrItem{item},
	}
	res := baseResponse{}
	err = post(DEL_USER_ATTR, data, &res)
	return
}

type UserAttrsResp struct {
	baseResponse
	UserAttrs []AddUserAttrItem `json:"UserAttrs"`
}

// 获取用户属性
func GetUserAttr(users []string) (err error, res UserAttrsResp) {
	data := RemoveAllTagReq{
		ToAccount: users,
	}
	err = post(GET_USER_ATTR, data, &res)
	return
}
