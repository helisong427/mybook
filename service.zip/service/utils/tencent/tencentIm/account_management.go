package tencentIm

import (
	"strconv"
)

const (
	ACCOUNT_IMPORT = "v4/im_open_login_svc/account_import" // 导入单个账号
)

type AccountImportRequest struct {
	Identifier string `json:"Identifier"`
	Nick       string `json:"Nick"`
	FaceUrl    string `json:"FaceUrl"`
}

type AccountImportResponse struct {
	baseResponse
}

// 导入单个账号
func AccountImport(userId int64, userNickname, userIconurl string) (err error) {
	// 查询用户信息
	data := AccountImportRequest{
		Identifier: strconv.Itoa(int(userId)),
		Nick:       userNickname,
		FaceUrl:    userIconurl,
	}
	res := AccountImportResponse{}
	err = post(ACCOUNT_IMPORT, data, &res)
	return
}
