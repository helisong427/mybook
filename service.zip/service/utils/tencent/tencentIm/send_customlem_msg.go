package tencentIm

import (
	"math/rand"
	"time"
)

func SendCusMsg(fromAccount string, tarGetId string, msg TIMCustomElem) (err error) {
	rand.Seed(time.Now().UnixNano())
	data := SendC2CMsgRequest{
		FromAccount:      fromAccount,
		SyncOtherMachine: 2,
		ToAccount:        tarGetId,
		MsgLifeTime:      DEFAULT_MSGLIFETIE,
		MsgRandom:        rand.Intn(MAX_RAND_NUM),
		MsgTimeStamp:     time.Now().Unix(),
		OfflinePushInfo:  OfflinePushInfo{Desc: msg.Desc},
		MsgBody:          []CustomMsg{{MsgType: "TIMCustomElem", MsgContent: msg}},
	}
	if msg.OfflineTitle != "" {
		data.OfflinePushInfo.Title = msg.OfflineTitle
	}
	res := SendGroupMsgResponse{}
	err = post(SEND_C2C_MSG, data, &res)
	return
}

// 取消离线推送
func SendCusMsgWithoutOffline(fromAccount string, tarGetId string, msg TIMCustomElem) (err error) {
	rand.Seed(time.Now().UnixNano())
	data := SendC2CMsgRequest{
		FromAccount:      fromAccount,
		SyncOtherMachine: 2,
		ToAccount:        tarGetId,
		MsgLifeTime:      DEFAULT_MSGLIFETIE,
		MsgRandom:        rand.Intn(MAX_RAND_NUM),
		MsgTimeStamp:     time.Now().Unix(),
		MsgBody:          []CustomMsg{{MsgType: "TIMCustomElem", MsgContent: msg}},
	}
	res := SendGroupMsgResponse{}
	err = post(SEND_C2C_MSG, data, &res)
	return
}

// 发送全局消息
func SendAllMsg(fromAccount string, msg TIMCustomElem) (taskId string, err error) {
	rand.Seed(time.Now().UnixNano())
	data := SendSystemNotificationRequest{
		FromAccount:     fromAccount,
		MsgRandom:       rand.Intn(MAX_RAND_NUM),
		MsgLifeTime:     60 * 60,
		MsgBody:         []CustomMsg{{MsgType: "TIMCustomElem", MsgContent: msg}},
		OfflinePushInfo: OfflinePushInfo{Desc: msg.Desc, Title: msg.OfflineTitle},
	}
	res := SendSystemNotificationResponse{}
	err = post(SEND_SYSTEM_NOTIFICATION, data, &res)
	taskId = res.TaskId
	return
}

// 通过属性推送
func SendByAttr(fromAccount string, condition *ConditionOrItem, msg TIMCustomElem) (taskId string, err error) {
	rand.Seed(time.Now().UnixNano())
	data := SendSystemNotificationRequest{
		FromAccount:     fromAccount,
		MsgRandom:       rand.Intn(MAX_RAND_NUM),
		Condition:       condition,
		MsgLifeTime:     60 * 60,
		MsgBody:         []CustomMsg{{MsgType: "TIMCustomElem", MsgContent: msg}},
		OfflinePushInfo: OfflinePushInfo{Desc: msg.Desc, Title: msg.OfflineTitle},
	}
	res := SendSystemNotificationResponse{}
	err = post(SEND_SYSTEM_NOTIFICATION, data, &res)
	taskId = res.TaskId
	return
}
