package tencentIm

import "gamers/enum"

const SET_APP_ATTR_NAME = "v4/all_member_push/im_set_attr_name"

type SetAppAttrReq struct {
	AttrNames map[string]string `json:"AttrNames"`
}

func InitAppAttr() (err error) {
	dataMap := make(map[string]string)
	dataMap["0"] = enum.IM_USER_ATTR_CLIENT
	dataMap["1"] = enum.IM_USER_ATTR_ANCHOR
	dataMap["2"] = enum.IM_USER_ATTR_SPARRING
	data := SetAppAttrReq{
		AttrNames: dataMap,
	}

	res := baseResponse{}
	err = post(SET_APP_ATTR_NAME, data, &res)
	return
}
