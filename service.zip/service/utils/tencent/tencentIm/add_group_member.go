package tencentIm

import (
	"strconv"
)

const (
	ADD_GROUP_MEMBER = "v4/group_open_http_svc/add_group_member" // 增加群成员

	// 加人结果
	ADD_GROUP_MEMBER_FAIL    int = iota // 失败
	ADD_GROUP_MEMBER_SUCCESS            // 成功
	ADD_GROUP_MEMBER_ALREADY            // 已经是群成员
	ADD_GROUP_MEMBER_WAIT               // 等待被邀请者确认
)

type addGroupMemberRequest struct {
	GroupId    string `json:"GroupId"` // 要操作的群组id
	MemberList []struct {
		Member_Account string `json:"Member_Account"` // 群员id
	} `json:"MemberList"` // 一次最多添加500个成员
}

type addGroupMemberResponse struct {
	baseResponse
	MemberList     []map[string]string `json:"MemberList"`     // 返回添加的群成员结果
	Member_Account string              `json:"Member_Account"` // 返回的群成员 UserID
	Result         int                 `json:"Result"`         // 加人结果：0-失败；1-成功；2-已经是群成员；3-等待被邀请者确认
}

// 增加群成员
func AddGroupMember(userId int64, groupId int) (result int, err error) {
	data := addGroupMemberRequest{
		GroupId:    strconv.Itoa(groupId),
		MemberList: nil,
	}
	// 一次增加一个用户
	data.MemberList[0].Member_Account = strconv.Itoa(int(userId))
	res := addGroupMemberResponse{}
	err = post(ADD_GROUP_MEMBER, data, &res)
	if err != nil {
		return
	}
	result = res.Result
	return
}
