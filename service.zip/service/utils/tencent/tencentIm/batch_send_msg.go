package tencentIm

import (
	"gamers/utils"
	"math/rand"
	"time"
)

const (
	BATCHSENDMSG = "v4/openim/batchsendmsg"
)

type BatchSendMsgReq struct {
	SyncOtherMachine int             `json:"SyncOtherMachine"` // 消息是否同步至发送方：1--是，2--否
	ToAccount        []string        `json:"To_Account"`       // 目标帐号列表
	FromAccount      string          `json:"From_Account"`     // 指定消息发送者（选填）
	MsgRandom        int             `json:"MsgRandom"`        // 消息随机数
	MsgBody          []CustomMsg     `json:"MsgBody"`          // 消息内容
	OfflinePushInfo  OfflinePushInfo `json:"OfflinePushInfo"`  // 离线消息内容
}

type BatchSendMsgResponse struct {
	baseResponse
	MsgKey    string `json:"MsgKey"`
	ErrorList []struct {
		ToAccount string `json:"To_Account"`
		ErrorCode int    `json:"ErrorCode"`
	} `json:"ErrorList"`
}

// 批量发单聊文本消息
func BatchSendMsg(userIds []string, fromAccount string, msg TIMCustomElem) (err error) {
	rand.Seed(time.Now().UnixNano())
	data := BatchSendMsgReq{
		SyncOtherMachine: 1,
		ToAccount:        userIds,
		FromAccount:      fromAccount,
		MsgRandom:        rand.Intn(MAX_RAND_NUM),
		MsgBody: []CustomMsg{{
			MsgType:    "TIMCustomElem",
			MsgContent: msg,
		},
		},
		OfflinePushInfo: OfflinePushInfo{Desc: msg.Desc, Title: msg.Desc},
	}

	res := BatchSendMsgResponse{}
	err = post(BATCHSENDMSG, data, &res)
	if err != nil {
		utils.LogErrorF("批量发送消息失败,%v", res)
	}
	return
}

// 批量发单聊文本消息
func BatchSendMsgWithoutOffline(userIds []string, fromAccount string, msg TIMCustomElem) (err error) {
	rand.Seed(time.Now().UnixNano())
	data := BatchSendMsgReq{
		SyncOtherMachine: 1,
		ToAccount:        userIds,
		FromAccount:      fromAccount,
		MsgRandom:        rand.Intn(MAX_RAND_NUM),
		MsgBody: []CustomMsg{{
			MsgType:    "TIMCustomElem",
			MsgContent: msg,
		},
		},
	}

	res := BatchSendMsgResponse{}
	err = post(BATCHSENDMSG, data, &res)
	if err != nil {
		utils.LogErrorF("批量发送消息失败,%v", res)
	}
	return
}
