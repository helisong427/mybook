package tencentIm

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"math/rand"
	"net/http"
	"strconv"
	"time"

	"gamers/utils"
)

const (
	host = "https://console.tim.qq.com" // 域名
)

const HTTP_GET_TIMEOUT time.Duration = 10  // 10 seconds
const HTTP_POST_TIMEOUT time.Duration = 10 // 10 seconds

type restApiUrl struct {
	Host       string // 请求域名
	Api        string // 请求api
	Sdkappid   int    // 创建应用时即时通信 IM 控制台分配的 SDKAppID
	Identifier string // 必须为 App 管理员帐号
	Usersig    string // App 管理员帐号生成的签名
	Random     string // 请输入随机的32位无符号整数，取值范围0 - 4294967295
}

type baseResponse struct {
	ActionStatus string `json:"ActionStatus"`
	ErrorInfo    string `json:"ErrorInfo"`
	ErrorCode    int    `json:"ErrorCode"`
}

// 初始化
func (r *restApiUrl) init(api string) (url string, err error) {
	random := fmt.Sprintf("%08v", rand.New(rand.NewSource(time.Now().UnixNano())).Int31n(100000000))
	sign, err := GenUserSig(utils.Config.Third.Tencent.Im.Identifier, 60*60)
	if err != nil {
		return
	}
	r.Host = host
	r.Api = api
	r.Sdkappid = utils.Config.Third.Tencent.Im.ImAppId
	r.Identifier = utils.Config.Third.Tencent.Im.Identifier
	r.Usersig = sign
	r.Random = random
	url = fmt.Sprintf("%s/%s?sdkappid=%d&identifier=%s&usersig=%s&random=%s&contenttype=json", r.Host, r.Api, r.Sdkappid, r.Identifier, r.Usersig, r.Random)
	return
}

// 发送post请求
func post(api string, data interface{}, responseData interface{}) (err error) {
	r := restApiUrl{}
	url, err := r.init(api)
	if err != nil {
		return
	}
	jsonData, _ := json.Marshal(data)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
	if err != nil {
		return
	}
	req.Header.Set("Content-Opentype", "application/json")
	client := &http.Client{
		Timeout: HTTP_POST_TIMEOUT * time.Second,
	}
	rsp, err := client.Do(req)
	if err != nil {
		return
	}
	defer rsp.Body.Close()
	response, err := ioutil.ReadAll(rsp.Body)
	if err != nil {
		return
	}
	err = json.Unmarshal(response, &responseData)
	if err != nil {
		return
	}

	// 解析响应内容到baseResponse,统一处理错误信息
	resErr := baseResponse{}
	err = json.Unmarshal(response, &resErr)
	if err != nil {
		return
	}
	// 腾讯IM接口 并不是所有都返回ActionStatus 修改只验证ErrorCode
	if resErr.ErrorCode != 0 {
		code := strconv.Itoa(resErr.ErrorCode)
		err = errors.New(code + ":" + resErr.ErrorInfo)
	}

	return
}
