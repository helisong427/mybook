package tencentIm

const ADD_USER_TAG = "v4/all_member_push/im_add_tag"
const DEL_USER_TAG = "v4/all_member_push/im_remove_tag"
const REMOVE_USER_TAG = "v4/all_member_push/im_remove_all_tags"

type addTagItem struct {
	ToAccount string   `json:"To_Account"`
	Tags      []string `json:"Tags"`
}

type addTagReq struct {
	UserTags []addTagItem `json:"UserTags"`
}
type RemoveAllTagReq struct {
	ToAccount []string `json:"To_Account"`
}

func AddUserTag(target, tag string) (err error) {
	item := addTagItem{
		ToAccount: target,
		Tags:      []string{tag},
	}
	data := addTagReq{
		UserTags: []addTagItem{item},
	}
	res := SendGroupMsgResponse{}
	err = post(ADD_USER_TAG, data, &res)
	return
}

func DelUserTag(target, tag string) (err error) {
	item := addTagItem{
		ToAccount: target,
		Tags:      []string{tag},
	}
	data := addTagReq{
		UserTags: []addTagItem{item},
	}
	res := SendGroupMsgResponse{}
	err = post(DEL_USER_TAG, data, &res)
	return
}

// 删除用户所有tag
func RemoveAllTag(userIdStrs []string) (err error) {
	data := RemoveAllTagReq{
		ToAccount: userIdStrs,
	}
	res := SendGroupMsgResponse{}
	err = post(REMOVE_USER_TAG, data, &res)
	return
}
