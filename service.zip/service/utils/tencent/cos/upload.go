package cos

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"net/url"
	"strings"

	"gamers/utils"

	"github.com/tencentyun/cos-go-sdk-v5"
)

type Clienter struct {
	BaseURL   string
	CosClient *cos.Client
}

// 初始化
func New() *Clienter {
	conf := utils.Config.Third.Tencent.Cos
	baseURL := fmt.Sprintf("https://%s.cos.%s.myqcloud.com", conf.CosBucket, conf.CosRegion)
	u, _ := url.Parse(baseURL)
	b := &cos.BaseURL{BucketURL: u}
	c := cos.NewClient(b, &http.Client{
		Transport: &cos.AuthorizationTransport{
			SecretID:  conf.CosSecretId,
			SecretKey: conf.CosSecretKey,
		},
	})

	return &Clienter{
		BaseURL:   baseURL,
		CosClient: c,
	}
}

// 通过字符串上传对象
// filePath 文件存放路径
// f 文件字符串
// name 文件名称
func (c *Clienter) ObjectPut(filePath string, fileName string, f *string) (fileUrl string, err error) {
	file := strings.NewReader(*f)
	put, err := c.CosClient.Object.Put(context.Background(), filePath+fileName, file, nil)
	if err != nil {
		return
	}
	if put.Status != "200 OK" {
		err = errors.New("上传失败")
		return
	}
	if put.StatusCode != http.StatusOK {
		err = errors.New("上传失败")
		return
	}

	fileUrl = c.getFileUrl(filePath, fileName)
	return
}

// 获取文件地址
func (c *Clienter) getFileUrl(filePath string, fileName string) string {
	return fmt.Sprintf("%s%s%s", c.BaseURL, filePath, fileName)
}
