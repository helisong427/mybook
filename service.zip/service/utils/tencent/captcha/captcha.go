package captcha

import (
	"fmt"
	"gamers/utils"

	"github.com/tencentcloud/tencentcloud-sdk-go/tencentcloud/common"
	"github.com/tencentcloud/tencentcloud-sdk-go/tencentcloud/common/errors"
	"github.com/tencentcloud/tencentcloud-sdk-go/tencentcloud/common/profile"

	captcha "github.com/tencentcloud/tencentcloud-sdk-go/tencentcloud/captcha/v20190722"
)

// CheckCaptcha 验证前端的票据
func CheckCaptcha(ticket, userIp, randstr string) *int64 {
	credential := common.NewCredential(
		utils.Config.Third.Tencent.Captcha.CaptchaSecretId,
		utils.Config.Third.Tencent.Captcha.CaptchaSecretKey,
	)
	cpf := profile.NewClientProfile()
	cpf.HttpProfile.Endpoint = utils.Config.Third.Tencent.Captcha.CaptchaHost
	client, _ := captcha.NewClient(credential, "", cpf)

	request := captcha.NewDescribeCaptchaResultRequest()

	request.CaptchaType = common.Uint64Ptr(9)
	request.Ticket = common.StringPtr(ticket)
	request.UserIp = common.StringPtr(userIp)
	request.Randstr = common.StringPtr(randstr)
	request.CaptchaAppId = common.Uint64Ptr(utils.Config.Third.Tencent.Captcha.CaptchaAppid)
	request.AppSecretKey = common.StringPtr(utils.Config.Third.Tencent.Captcha.CaptchaAppSecretKey)

	response, err := client.DescribeCaptchaResult(request)
	var errorNumber int64 = 101
	if _, ok := err.(*errors.TencentCloudSDKError); ok {
		utils.Logger.Error(fmt.Sprintf("An API error has returned: %s", err))
		return &errorNumber
	}
	if err != nil {
		utils.Logger.Error(fmt.Sprintf("An API error has returned: %s", err))
		return &errorNumber
	}
	return response.Response.CaptchaCode
}
