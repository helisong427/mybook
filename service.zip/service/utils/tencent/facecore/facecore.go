package facecore

import (
	"gamers/utils"

	"github.com/tencentcloud/tencentcloud-sdk-go/tencentcloud/common"
	"github.com/tencentcloud/tencentcloud-sdk-go/tencentcloud/common/errors"
	"github.com/tencentcloud/tencentcloud-sdk-go/tencentcloud/common/profile"
	"github.com/tencentcloud/tencentcloud-sdk-go/tencentcloud/common/regions"
	faceid "github.com/tencentcloud/tencentcloud-sdk-go/tencentcloud/faceid/v20180301"
	iai "github.com/tencentcloud/tencentcloud-sdk-go/tencentcloud/iai/v20200303"
)

const (
	FCAE_DETECT_LEVEL = 75 // 五官的清晰阈值
	FACE_EXPRESSION   = 70 // 照片清晰度的阈值
)

// FaceIdCard 照片人脸核身
func FaceIdCardImage(imageBase64 *string, idCard *string, name *string) (response *faceid.ImageRecognitionResponse, err error) {
	secretId := utils.Config.Third.Tencent.Cos.CosSecretId
	secretKey := utils.Config.Third.Tencent.Cos.CosSecretKey
	// 设置凭证
	credential := common.NewCredential(secretId, secretKey)
	cpf := profile.NewClientProfile()

	// 设置请求参数
	request := faceid.NewImageRecognitionRequest()
	request.ImageBase64 = imageBase64
	request.IdCard = idCard
	request.Name = name

	// 发送请求
	client, _ := faceid.NewClient(credential, regions.Guangzhou, cpf)

	response, err = client.ImageRecognition(request)

	// 处理sdk异常
	if _, ok := err.(*errors.TencentCloudSDKError); ok {
		return
	}

	// 处理非sdk异常
	if err != nil {
		return
	}
	return
}

// FaceImage 照片人脸信息
func FaceImage(url *string) (response *iai.DetectFaceResponse, err error) {
	secretId := utils.Config.Third.Tencent.Cos.CosSecretId
	secretKey := utils.Config.Third.Tencent.Cos.CosSecretKey
	// 设置凭证
	credential := common.NewCredential(secretId, secretKey)
	cpf := profile.NewClientProfile()
	var MaxFaceNum uint64 = 2
	var FaceModelVersion = "3.0"
	var Need uint64 = 1
	// var FaceAttributesType string = "Age,Beauty,Emotion,Eye,Eyebrow,Gender,Hair,Hat,Headpose,Mask,Mouth,Moustache,Nose,Shape"
	// 设置请求参数
	request := iai.NewDetectFaceRequest()
	request.MaxFaceNum = &MaxFaceNum
	request.Url = url
	request.FaceModelVersion = &FaceModelVersion
	request.NeedFaceAttributes = &Need
	request.NeedQualityDetection = &Need
	// request.FaceAttributesType = &FaceAttributesType
	// 发送请求
	client, _ := iai.NewClient(credential, regions.Guangzhou, cpf)
	response, err = client.DetectFace(request)
	// 处理sdk异常
	if _, ok := err.(*errors.TencentCloudSDKError); ok {
		return
	}
	// 处理非sdk异常
	if err != nil {
		return
	}
	return
}

// IdCardVerification 身份信息认证
func IdCardVerification(idCard *string, name *string) (response *faceid.IdCardVerificationResponse, err error) {
	secretId := utils.Config.Third.Tencent.Cos.CosSecretId
	secretKey := utils.Config.Third.Tencent.Cos.CosSecretKey
	// 设置凭证
	credential := common.NewCredential(secretId, secretKey)
	cpf := profile.NewClientProfile()
	request := faceid.NewIdCardVerificationRequest()
	request.IdCard = idCard
	request.Name = name

	client, _ := faceid.NewClient(credential, regions.Guangzhou, cpf)
	response, err = client.IdCardVerification(request)
	// 处理sdk异常
	if _, ok := err.(*errors.TencentCloudSDKError); ok {
		return
	}
	return
}
