package vms

import (
	"gamers/utils"

	"github.com/tencentcloud/tencentcloud-sdk-go/tencentcloud/common"
	"github.com/tencentcloud/tencentcloud-sdk-go/tencentcloud/common/profile"
	vms "github.com/tencentcloud/tencentcloud-sdk-go/tencentcloud/vms/v20200902"
)

const VMS_HOST = "vms.tencentcloudapi.com"

// 发送模板消息
func SendModelMsg(modelId, phone string, params []string) (response *vms.SendTtsVoiceResponse, err error) {
	credential := common.NewCredential(
		utils.Config.Third.Tencent.Cos.CosSecretId,
		utils.Config.Third.Tencent.Cos.CosSecretKey,
	)
	cpf := profile.NewClientProfile()
	cpf.HttpProfile.ReqMethod = "POST"
	cpf.HttpProfile.Endpoint = VMS_HOST
	cpf.SignMethod = "TC3-HMAC-SHA256"
	client, _ := vms.NewClient(credential, "ap-guangzhou", cpf)
	request := vms.NewSendTtsVoiceRequest()
	request.TemplateId = common.StringPtr(modelId)
	// 模板参数，
	request.TemplateParamSet = common.StringPtrs(params)
	// 手机号
	request.CalledNumber = common.StringPtr("+86" + phone)
	request.VoiceSdkAppid = common.StringPtr(utils.Config.Third.Tencent.Vms.VmsAppId)
	// 播放次数，可选，最多3次，默认2次
	request.PlayTimes = common.Uint64Ptr(2)
	response, err = client.SendTtsVoice(request)

	// 非 SDK 异常，直接失败。实际代码中可以加入其他的处理
	if err != nil {
		return
	}
	// 当返回calledId后，将err置为nil
	if response.Response.SendStatus.CallId != nil {
		err = nil
		return
	}
	return
}
