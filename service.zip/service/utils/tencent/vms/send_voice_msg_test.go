package vms

import (
	"fmt"
	"gamers/utils"
	"testing"
)

func TestSendModelMsg(t *testing.T) {
	// 配置文件初始化
	utils.ConfigInitLocal()
	_, err := SendModelMsg("957063", "18302842579", []string{})
	if err != nil {
		fmt.Println(err.Error())
	}
}
