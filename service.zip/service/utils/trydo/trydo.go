package trydo

import (
	"time"
)

const (
	maxIntervalLength = 10
	maxTotalInterval  = time.Second * 5
)

var defaultTryIntervals = []time.Duration{
	time.Millisecond * 200,
	time.Millisecond * 100,
	time.Millisecond * 200,
	time.Millisecond * 100,
}

func CheckIntervals(tryIntervals []time.Duration) (valid bool, immediately bool, realUsedIntervals []time.Duration) {
	var length = len(tryIntervals)
	if length == 0 {
		return true, true, nil
	}

	var checkMax = maxIntervalLength
	if length < checkMax {
		checkMax = length
	}

	var tZeroIndex = -1 // Only in forepart
	var leftValidIndex = -1
	var totalInterval time.Duration
	for i := 0; i < checkMax; i++ {
		var interval = tryIntervals[i]
		if interval < 0 {
			break
		}

		totalInterval += interval
		if totalInterval > maxTotalInterval {
			break
		}

		if interval == 0 {
			if tZeroIndex != leftValidIndex {
				break
			}
			tZeroIndex += 1
		}
		leftValidIndex = i
	}

	if length != checkMax || length != leftValidIndex+1 {
		valid = false
	}
	switch leftValidIndex {
	case -1:
		immediately = true
	default:
		if tZeroIndex == -1 {
			realUsedIntervals = tryIntervals[0 : leftValidIndex+1]
		} else {
			realUsedIntervals = []time.Duration{
				time.Duration(0),
			}
			if tZeroIndex < leftValidIndex {
				realUsedIntervals = append(realUsedIntervals, tryIntervals[tZeroIndex+1:leftValidIndex+1]...)
			}
		}
	}
	return
}

func Do(tryFunc func() (isOver bool)) (succeed bool) {
	return DoWithIntervals(defaultTryIntervals, tryFunc)
}

/*
	Please check your "tryIntervals", otherwise behaviors is unexpected!!!
*/
func DoWithIntervals(tryIntervals []time.Duration, tryFunc func() (isOver bool)) (succeed bool) {
	if tryFunc == nil {
		return false
	}

	var _, immediately, realUsedIntervals = CheckIntervals(tryIntervals)
	if immediately {
		return tryFunc()
	}

	var length = len(realUsedIntervals)
	var leftTryCount = length
	for _, t := range realUsedIntervals {
		if t > 0 {
			break
		}
		var isOver = tryFunc()
		if isOver {
			return true
		}
		leftTryCount -= 1
	}

	if leftTryCount == 0 {
		return false
	}

	// var ticker = time.NewTicker(tryIntervals[length-leftTryCount]) // compatibility to 1.15.06
	// defer ticker.Stop()
	var ticker = time.NewTimer(tryIntervals[length-leftTryCount])
	defer func() {
		if !ticker.Stop() {
			// <-ticker.C
		}
	}()

	for {
		var isOver = false
		var isForceOver = false

		select {
		case <-ticker.C:
			leftTryCount -= 1
			switch leftTryCount {
			case 0:
				isForceOver = true
			default:
				// ticker.Reset(tryIntervals[length-leftTryCount]) // compatibility to 1.15.06
				if !ticker.Stop() {
					// <-ticker.C
				}
				ticker.Reset(tryIntervals[length-leftTryCount])
			}
			isOver = tryFunc()
		}

		if isOver {
			return true
		}
		if isForceOver {
			return false
		}
	}
}
