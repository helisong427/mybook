package utils

import (
	"fmt"
	"os"
	"time"

	"github.com/Shopify/sarama"
	cluster "github.com/bsm/sarama-cluster"
)

const DEFAULT_SEND_RETRY_MAX = 5
const PRODUCER_NAME = "PRODUCER"

type MqOption struct {
	Host         []string `json:"host" yaml:"host"`
	Topic        []string `json:"topic" yaml:"topic"`
	GroupId      string   `json:"groupid" yaml:"groupid"`
	SendRetryMax int      `json:"sendretrymax" yaml:"sendretrymax"`
	Stop         chan struct{}
}

var mqOpt *MqOption

var kafkaProducer sarama.SyncProducer

func KafkaInitProducer() {
	var err error
	mqOpt = &MqOption{
		Host: Config.Kafka.Host,
		Stop: make(chan struct{}),
	}
	kafkaProducer, err = NewKafkaProducer(mqOpt)
	if err != nil {
		os.Exit(1)
	}
}

func (m *MqOption) Info(name string) {
	fmt.Sprintln("", "Current connect [%s] kafka: Host[%s], topic[%s], groupId[%s], retrymax[%d]\n", name, m.Host, m.Topic, m.GroupId, m.SendRetryMax)
}

func NewKafkaProducer(opt *MqOption) (sarama.SyncProducer, error) {
	if opt.SendRetryMax == 0 {
		opt.SendRetryMax = DEFAULT_SEND_RETRY_MAX
	}
	// sarama.Logger = log.New(os.Stderr, "[Sarama] ", log.LstdFlags)
	opt.Info(PRODUCER_NAME)
	cf := sarama.NewConfig()
	cf.Producer.RequiredAcks = sarama.WaitForAll
	cf.Producer.Retry.Max = opt.SendRetryMax
	cf.Producer.Return.Successes = true

	producer, err := sarama.NewSyncProducer(opt.Host, cf)
	if err != nil {
		Logger.Error("failed to create sync kafka producer, " + err.Error())
		return nil, err
	}

	return producer, nil
}

func KafkaSendMsg(topic, key string, data []byte) error {
	msg := &sarama.ProducerMessage{
		Topic: topic,
		Key:   sarama.StringEncoder(key),
		Value: sarama.StringEncoder(data),
	}

	partition, offset, err := kafkaProducer.SendMessage(msg)
	if err != nil {
		errstr := fmt.Sprintf("send kafka msg failed, %s, %s, %s", topic, key, err.Error())
		Logger.Error(errstr)
		return err
	}
	infostr := fmt.Sprintf("msgId: %s, partition: %d, offset: %d", key, partition, offset)
	Logger.Info(infostr)
	return nil
}

func newKafkaConsumer(opt *MqOption) (*cluster.Consumer, error) {
	opt.Info(opt.GroupId)

	cf := cluster.NewConfig()
	cf.Consumer.Return.Errors = true
	cf.Group.Return.Notifications = true
	cf.Group.Session.Timeout = 60 * time.Second
	consumer, err := cluster.NewConsumer(opt.Host, opt.GroupId, opt.Topic, cf)
	if err != nil {
		LogErrorF("failed to create kafka consumer, %s", err.Error())
		return nil, err
	}

	return consumer, nil
}

func KafkaConsumeMsg(opt *MqOption, handleF func(message *sarama.ConsumerMessage)) error {
	var err error
	consumer, err := newKafkaConsumer(opt)
	if err != nil {
		return err
	}
	defer consumer.Close()
	go func() {
		for err := range consumer.Errors() {
			errStr := fmt.Sprintf("consumer msg error: %s, %s, %s, %s", opt.Host, opt.Topic, opt.GroupId, err.Error())
			fmt.Println(errStr)
		}
	}()
	go func() {
		for ntf := range consumer.Notifications() {
			fmt.Println(ntf)
		}
	}()

	for {
		select {
		case msg, ok := <-consumer.Messages():
			if ok {
				go func(msg *sarama.ConsumerMessage) {
					handleF(msg)
					consumer.MarkOffset(msg, "")
				}(msg)
			}
		case <-opt.Stop:
			warnstr := fmt.Sprintf("stop consumer: %s, %s, %s", opt.Host, opt.Topic, opt.GroupId)
			fmt.Println(warnstr)
			return nil
		}
	}
}
func KafkaClose() error {
	if kafkaProducer != nil {
		return kafkaProducer.Close()
	}
	return nil
}
