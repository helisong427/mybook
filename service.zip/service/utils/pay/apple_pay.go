package pay

import (
	"fmt"
	"github.com/guonaihong/gout"
)

type ApplePay struct {
}

type ApplePayVerifyReceiptRequest struct {
	ReceiptData string `json:"receipt-data"` // Base64编码的收据数据。注意是中横线”-“
}

type ApplePayVerifyReceiptResponse struct {
	Status      int    `json:"status"`      //状态
	Environment string `json:"environment"` //环境
	Receipt     struct {
		ReceiptType                string                   `json:"receipt_type"`
		AdamID                     int                      `json:"adam_id"`
		AppItemID                  int                      `json:"app_item_id"`
		BundleID                   string                   `json:"bundle_id"`
		ApplicationVersion         string                   `json:"application_version"`
		DownloadID                 int                      `json:"download_id"`
		VersionExternalIdentifier  int                      `json:"version_external_identifier"`
		ReceiptCreationDate        string                   `json:"receipt_creation_date"`
		ReceiptCreationDateMs      string                   `json:"receipt_creation_date_ms"`
		ReceiptCreationDatePst     string                   `json:"receipt_creation_date_pst"`
		RequestDate                string                   `json:"request_date"`
		RequestDateMs              string                   `json:"request_date_ms"`
		RequestDatePst             string                   `json:"request_date_pst"`
		OriginalPurchaseDate       string                   `json:"original_purchase_date"`
		OriginalPurchaseDateMs     string                   `json:"original_purchase_date_ms"`
		OriginalPurchaseDatePst    string                   `json:"original_purchase_date_pst"`
		OriginalApplicationVersion string                   `json:"original_application_version"`
		InApp                      []map[string]interface{} `json:"in_app"`
	} `json:"receipt"`
}

// 服务器二次验证代码
// * 21000 App Store不能读取你提供的JSON对象
// * 21002 receipt-data域的数据有问题
// * 21003 receipt无法通过验证
// * 21004 提供的shared secret不匹配你账号中的shared secret
// * 21005 receipt服务器当前不可用
// * 21006 receipt合法，但是订阅已过期。服务器接收到这个状态码时，receipt数据仍然会解码并一起发送
// * 21007 receipt是Sandbox receipt，但却发送至生产系统的验证服务
// * 21008 receipt是生产receipt，但却发送至Sandbox环境的验证服务

func NewApplePay() *ApplePay {
	p := ApplePay{}
	return &p
}

//验证苹果支付结果
func (p *ApplePay) VerifyReceipt(url, productId, transactionId, bundleID, receiptData string) (r ApplePayVerifyReceiptResponse, err error) {
	request := ApplePayVerifyReceiptRequest{
		ReceiptData: receiptData,
	}
	_, envIsProd := GetPayEnv()
	err = gout.POST(url).SetJSON(request).BindJSON(&r).Do()
	if err != nil {
		return
	}
	if r.Status != 0 {
		err = fmt.Errorf("验证失败,错误代码:%d", r.Status)
	}
	if r.Receipt.BundleID != bundleID || (envIsProd && r.Environment == "Sandbox") {
		err = fmt.Errorf("验证失败,数据涉嫌伪造,错误代码:%d", r.Status)
	}
	if len(r.Receipt.InApp) > 0 {
		for kk, vv := range r.Receipt.InApp[0] {
			if kk == "transaction_id" && vv != transactionId {
				err = fmt.Errorf("验证失败,transaction_id错误")
				continue
			}
			if kk == "product_id" && vv != productId {
				err = fmt.Errorf("验证失败,product_id错误")
				continue
			}
		}
	} else {
		err = fmt.Errorf("验证失败,in_app错误:%s", r.Receipt)
	}

	return
}
