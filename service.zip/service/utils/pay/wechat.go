package pay

import (
	"errors"
	"fmt"
	"gamers/utils"
	"github.com/iGoogle-ink/gopay"
	"github.com/iGoogle-ink/gopay/wechat"
	"time"
)

//微信支付
type WechatPay struct {
	client     *wechat.Client
	Price      int64  //金额/分
	OutTradeNo int64  //商户订单号
	Desc       string //描述
	Ip         string //ip
	Openid     string //openid(微信公众号下单需要)
	TradeType  string //交易类型
	notifyUrl  string //回调地址
	ReturnUrl  string //h5支付返回地址
	appId      string //应用ID
	mchId      string //商户Id
	apiKey     string //密钥
}

type WechatPlaceOrderResponse struct {
	AppId     string `json:"app_id"`     //应用ID
	PartnerId string `json:"partner_id"` //商户号
	PrepayId  string `json:"prepay_id"`  //预支付交易会话ID
	NonceStr  string `json:"nonce_str"`  //随机字符串
	Timestamp string `json:"timestamp"`  //时间戳
	Sign      string `json:"sign"`       //签名
}

//初始化微信App支付
func NewWheatPay(appId, apiKey, mchid, notifyUrl string) *WechatPay {
	p := WechatPay{}
	//获取环境
	debug, _ := GetPayEnv()
	p.client = wechat.NewClient(appId, mchid, apiKey, true)
	p.client.DebugSwitch = debug
	p.notifyUrl = notifyUrl
	p.appId = appId
	p.mchId = mchid
	p.apiKey = apiKey
	p.TradeType = wechat.TradeType_App
	return &p
}

//初始化微信公众号支付
func NewJsapiPay(appId, apiKey, mchid, notifyUrl string) *WechatPay {
	p := WechatPay{}
	//获取环境
	debug, _ := GetPayEnv()
	p.client = wechat.NewClient(appId, mchid, apiKey, true)
	p.client.DebugSwitch = debug
	p.notifyUrl = notifyUrl
	p.appId = appId
	p.mchId = mchid
	p.apiKey = apiKey
	p.TradeType = wechat.TradeType_JsApi
	return &p
}

//下单
func (p *WechatPay) PlaceOrder() (orderParameters interface{}, err error) {
	bm := make(gopay.BodyMap)
	nonceStr := utils.FuncRandString(32)
	bm.Set("nonce_str", nonceStr).
		Set("body", p.Desc). //商品描述
		Set("out_trade_no", p.OutTradeNo).
		Set("total_fee", p.Price).
		Set("spbill_create_ip", p.Ip).
		Set("notify_url", p.notifyUrl).
		Set("trade_type", p.TradeType).
		Set("sign_type", wechat.SignType_MD5)
	if p.Openid != "" {
		bm.Set("openid", p.Openid)
	}
	wxRsp, err := p.client.UnifiedOrder(bm)
	if err != nil {
		return
	}
	if wxRsp.ReturnCode != "SUCCESS" {
		err = errors.New(wxRsp.ReturnMsg)
		return
	}
	if wxRsp.ResultCode == "FAIL" {
		err = errors.New(wxRsp.ErrCodeDes)
		return
	}

	res := WechatPlaceOrderResponse{
		AppId:     p.appId,
		PartnerId: p.mchId,
		PrepayId:  wxRsp.PrepayId,
		NonceStr:  wxRsp.NonceStr,
		Timestamp: fmt.Sprintf("%d", time.Now().Unix()),
	}

	//二次签名
	sign := wechat.GetAppPaySign(res.AppId, res.PartnerId, wxRsp.NonceStr, wxRsp.PrepayId, wechat.SignType_MD5, res.Timestamp, p.apiKey)
	res.Sign = sign
	orderParameters = res
	return
}
