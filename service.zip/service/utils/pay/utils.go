package pay

import (
	"github.com/iGoogle-ink/gopay"

	"gamers/utils"
)

// 获取支付环境
func GetPayEnv() (gopay.DebugSwitch, bool) {
	var debug gopay.DebugSwitch
	env := utils.Config.App.Env
	// 是否正式环境
	isProd := true
	if env == "" || env == "debug" || env == "test" || env == "staging" {
		// debug模式
		// 关闭正式环境,使用沙箱环境
		isProd = false
		debug = gopay.DebugOn
	}
	return debug, isProd
}
