package pay

// 支付回调
type PayCallback struct {
	PayType     int    `json:"pay_type"`     // 支付类型
	OutTradeNo  string `json:"out_trade_no"` // 商户订单号
	TotalAmount string `json:"total_amount"` // 订单价格
	TradeStatus string `json:"trade_status"` // 交易状态
	TradeType   string `json:"trade_type"`   // 下单类型
	ThirdNo     string `json:"third_no"`     // 第三id
	ChannelId   int    `json:"channel_id"`   // 交易渠道
}

const (
	// 支付交易状态
	WECHAT_PAY_TRADE_STATUS_SUCCESS  = "SUCCESS"        // 微信交易状态--成功
	WECHAT_PAY_TRADE_STATUS_FAIL     = "FAIL"           // 微信交易状态--失败
	ALIPAY_PAY_TRADE_STATUS_SUCCESS  = "TRADE_SUCCESS"  // 支付宝交易状态--支付成功
	ALIPAY_PAY_TRADE_STATUS_CLOSE    = "TRADE_CLOSED"   // 支付宝交易状态--未付款交易超时关闭，或支付完成后全额退款。
	ALIPAY_PAY_TRADE_STATUS_FINISHED = "TRADE_FINISHED" // 支付宝交易状态--交易结束，不可退款。
)
