// 支付预警
package warning

import (
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"sync"
	"time"

	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"gamers/utils/chuanglan/sms"

	"github.com/go-redis/redis"
)

// Message 通道类型
type Message struct {
	UserID          int64 // 用户id
	TransactionID   int64 // 交易id
	TransactionTime int64 // 交易时间
	Type            int64 // 消息类型。1 支付宝 2 微信 4 苹果
	Cash            int64 // 交易金额
}

// 单例
var q = &queue{
	msgs: make(chan Message),
	done: make(chan struct{}),
}

// 预警消息队列
type queue struct {
	once sync.Once

	msgs chan Message
	done chan struct{}
}

// func init() {
// 	q = &queue{
// 		msgs: make(chan Message),
// 		done: make(chan struct{}),
// 	}
//
// 	go q.run()
// }

// Run 启动预警队列
func (q *queue) Run() {
	for {
		select {
		case msg := <-q.msgs:
			// 逻辑处理
			go q.dealMessage(msg)
		case <-q.done:
			fmt.Println("waring queue stoped")
			return
		}
	}
}

// PushMessage 推送消息
func (q *queue) PushMessage(msg Message) {
	select {
	case q.msgs <- msg:
	case <-q.done:
		return
	}
}

// 处理消息
func (q *queue) dealMessage(msg Message) {
	select {
	case <-q.done:
		return
	default:
		start := time.Now().Unix()

		// 获取预警参数,存在缓存。
		var sp dbmodels.SystemParam
		data, err := sp.QueryKey(dbmodels.PARAM_KEY_PAY_WARNING)
		if err != nil {
			utils.LogErrorF("查询支付预警参数失败（system_param表）：%v", err)
			return
		}
		v, ok := data["value"]
		if !ok {
			utils.LogErrorF("查询支付预警参数失败，值不存在")
			return
		}
		var params dbmodels.PayWarningParams
		if err = json.Unmarshal([]byte(v), &params); err != nil {
			utils.LogErrorF("解析支付预警参数失败：%v", err)
			return
		}
		// 日志
		utils.LogInfoF("解析后支付预警参数：%v", params)

		var u redismodels.UserInfo
		// 用户创建时间
		created, err := u.GetUserCreateTime(msg.UserID)
		if err != nil {
			utils.LogErrorF("获取用户创建时间失败：%v", err)
			return
		}
		sub := start - created // 从用户创建时间到发送订单是否超过 48 小时.改为动态配置
		utils.LogInfoF("收到消息时间：%d|用户创建时间：%d|差值：%d（单位 s）", start, created, sub)
		if sub > params.Time {
			return
		}

		// ios
		if msg.Type == int64(dbmodels.DB_ACCOUNT_TYPE_APPLEPAY) {
			if err = handleApplePay(params, msg); err != nil {
				utils.LogErrorF("处理苹果支付预警失败：%v", err)
			}
			return
		}

		// 微信或支付宝
		if err = handleAliAndWechatPay(params, msg); err != nil {
			utils.LogErrorF("处理支付宝和微信支付预警失败：%v", err)
		}

		// 支付宝
		// if msg.Type == int64(dbmodels.DB_ACCOUNT_TYPE_ALIPAY) {
		// 	if err = handleAliPay(params, msg); err != nil {
		// 		utils.LogErrorF("处理支付宝支付预警失败：%v", err)
		// 	}
		// 	return
		// }

		// 微信
		// if msg.Type == int64(dbmodels.DB_ACCOUNT_TYPE_WEHCHAT) {
		// 	if err = handWechatPay(params, msg); err != nil {
		// 		utils.LogErrorF("处理微信支付预警失败：%v", err)
		// 	}
		// 	return
		// }

		// 苹果
		// if err = handleApplePay(params, msg); err != nil {
		// 	utils.LogErrorF("处理苹果支付预警失败：%v", err)
		// }
	}
}

// Stop 停止预警队列
func (q *queue) Stop() {
	q.once.Do(func() {
		close(q.done)
	})
}

// Done 返回关闭信号
func (q *queue) Done() <-chan struct{} {
	return q.done
}

// Queue 获取预警队列
func Queue() *queue {
	return q
}

// NewQueue 创建预警队列
// func NewQueue() *queue {
// 	return &queue{
// 		msgs: make(chan Message),
// 		done: make(chan struct{}),
// 	}
// }

// 安卓 支付宝和微信处理条件相同
func handleAliAndWechatPay(params dbmodels.PayWarningParams, msg Message) (err error) {
	if msg.Cash < params.AliPayCash {
		return
	}

	// 查询订单数总和超过 2
	var at dbmodels.AppTransaction
	count, err := at.QueryAliAndWechatPayTimes(params.AliPayCash, msg.UserID)
	if err != nil {
		utils.LogErrorF("查询用户满足条件订单数量失败：%v", err)
		return
	}
	if count < int64(params.TimesAliPay) {
		return
	}

	// 获取 redis 中短信是否已经发送
	pw := redismodels.PayWarning{
		UserID: msg.UserID,
	}
	state, err := pw.GetSendState(utils.REDIS_PAY_WARNING)
	if err != nil && err != redis.Nil {
		utils.LogErrorF("获取用户支付预警发送状态失败：%v", err)
		return
	}
	// 已经发送
	if state == redismodels.SMS_SEND_YES {
		utils.LogInfoF("用户ID：%d|--------------> 支付宝或微信支付预警短信已经发送 <--------------|", msg.UserID)
		return
	}

	// 只触发充值预警
	resp, err := sendPayWarningSMS(params, msg, 3, time.Second)
	if err != nil || resp.Code != "0" {
		utils.LogErrorF("支付预警短信发送失败。内容：%v 错误信息：%v", resp, err)
		return
	}

	// 发送成功总条数不相等
	nums := strconv.Itoa(len(params.Phone))
	if resp.SuccessNum != nums {
		utils.LogErrorF("发送成功短信总数数与配置手机数不相等.成功条数:%s,手机总数:%s", resp.SuccessNum, nums)
	}

	// 设置 redis 缓存已经发送
	exp := time.Duration(params.Time) * time.Second
	if err = pw.SaveSendState(utils.REDIS_PAY_WARNING, redismodels.SMS_SEND_YES, exp); err != nil {
		utils.LogErrorF("保存支付预警发送状态失败：%v", err)
	}
	utils.LogInfoF("支付宝或微信支付预警短信发送成功")
	return
}

// handleAliPay 处理支付宝支付
func handleAliPay(params dbmodels.PayWarningParams, msg Message) (err error) {
	if msg.Cash < params.AliPayCash {
		return
	}

	// 查询订单数超过2
	var at dbmodels.AppTransaction
	count, err := at.QueryPayTimes(dbmodels.DB_ACCOUNT_TYPE_ALIPAY, params.AliPayCash, msg.UserID)
	if err != nil {
		utils.LogErrorF("查询用户满足条件订单数量失败：%v", err)
		return
	}
	if count < int64(params.TimesAliPay) {
		return
	}

	// 获取 redis 中短信是否已经发送
	pw := redismodels.PayWarning{
		UserID: msg.UserID,
	}
	state, err := pw.GetSendState(utils.REDIS_PAY_WARNING)
	if err != nil && err != redis.Nil {
		utils.LogErrorF("获取用户支付预警发送状态失败：%v", err)
		return
	}
	// 已经发送
	if state == redismodels.SMS_SEND_YES {
		utils.LogInfoF("用户ID：%d|--------------> 支付宝支付预警短信 48 小时内已经发送 <--------------|", msg.UserID)
		return
	}

	// 只触发充值预警
	resp, err := sendPayWarningSMS(params, msg, 3, time.Second)
	if err != nil || resp.Code != "0" {
		utils.LogErrorF("支付预警短信发送失败。内容：%v 错误信息：%v", resp, err)
		return
	}

	// 发送成功总条数不相等
	nums := strconv.Itoa(len(params.Phone))
	if resp.SuccessNum != nums {
		utils.LogErrorF("发送成功短信总数数与配置手机数不相等.成功条数:%s,手机总数:%s", resp.SuccessNum, nums)
	}

	// 设置 redis 缓存已经发送
	exp := time.Duration(params.Time) * time.Second
	if err = pw.SaveSendState(utils.REDIS_PAY_WARNING, redismodels.SMS_SEND_YES, exp); err != nil {
		utils.LogErrorF("保存支付预警发送状态失败：%v", err)
	}
	utils.LogInfoF("支付宝支付预警短信发送成功")
	return
}

// handWechatPay 处理微信支付
func handWechatPay(params dbmodels.PayWarningParams, msg Message) (err error) {
	if msg.Cash < params.WechatPayCash {
		return
	}

	// 和支付宝触发条件一样
	var at dbmodels.AppTransaction
	count, err := at.QueryPayTimes(dbmodels.DB_ACCOUNT_TYPE_WEHCHAT, params.WechatPayCash, msg.UserID)
	if err != nil {
		return
	}
	if count < int64(params.TimesWechatPay) {
		return
	}

	// 获取 redis 中短信是否已经发送
	pw := redismodels.PayWarning{
		UserID: msg.UserID,
	}
	state, err := pw.GetSendState(utils.REDIS_PAY_WARNING)
	if err != nil && err != redis.Nil {
		utils.LogErrorF("获取用户支付预警发送状态失败：%v", err)
		return
	}
	// 已经发送
	if state == redismodels.SMS_SEND_YES {
		utils.LogErrorF("用户ID：%d|--------------> 微信支付预警短信 48 小时内已经发送 <--------------|", msg.UserID)
		return
	}

	// 触发充值预警
	resp, err := sendPayWarningSMS(params, msg, 3, time.Second)
	if err != nil || resp.Code != "0" {
		utils.LogErrorF("支付预警短信发送失败。内容：%v 错误信息：%v", resp, err)
		return
	}

	// 发送成功总条数不相等
	nums := strconv.Itoa(len(params.Phone))
	if resp.SuccessNum != nums {
		utils.LogErrorF("发送成功短信总数数与配置手机数不相等.成功条数:%s,手机总数:%s", resp.SuccessNum, nums)
	}

	exp := time.Duration(params.Time) * time.Second
	if err = pw.SaveSendState(utils.REDIS_PAY_WARNING, redismodels.SMS_SEND_YES, exp); err != nil {
		utils.LogErrorF("保存支付预警发送状态失败：%v", err)
	}
	utils.LogInfoF("微信支付预警短信发送成功")
	return
}

// handleApplePay 处理苹果支付
func handleApplePay(params dbmodels.PayWarningParams, msg Message) (err error) {
	if msg.Cash < params.ApplePayCash {
		return
	}

	// 默认是满足条件就触发预警
	// var at dbmodels.AppTransaction
	// count,err := at.QueryPayTimes(dbmodels.DB_ACCOUNT_TYPE_APPLEPAY, msg.Cash, msg.UserID)
	// if err != nil {
	// 	return
	// }
	// if count < int64(params.TimesApplePay) {
	// 	return
	// }

	// 获取 redis 中短信是否已经发送
	pw := redismodels.PayWarning{
		UserID: msg.UserID,
	}
	state, err := pw.GetSendState(utils.REDIS_PAY_WARNING)
	if err != nil && err != redis.Nil {
		utils.LogErrorF("获取用户支付预警发送状态失败：%v", err)
		return
	}
	// 已经发送
	if state == redismodels.SMS_SEND_YES {
		utils.LogErrorF("用户ID：%d|--------------> 苹果支付预警短信已经发送 <--------------|", msg.UserID)
		return
	}

	// 触发充值预警
	resp, err := sendPayWarningSMS(params, msg, 3, time.Second)
	if err != nil || resp.Code != "0" {
		utils.LogErrorF("支付预警短信发送失败。内容：%v 错误信息：%v", resp, err)
		return
	}

	// 发送成功总条数不相等
	nums := strconv.Itoa(len(params.Phone))
	if resp.SuccessNum != nums {
		utils.LogErrorF("发送成功短信总数数与配置手机数不相等.成功条数:%s,手机总数:%s", resp.SuccessNum, nums)
	}

	exp := time.Duration(params.Time) * time.Second
	if err = pw.SaveSendState(utils.REDIS_PAY_WARNING, redismodels.SMS_SEND_YES, exp); err != nil {
		utils.LogErrorF("保存支付预警发送状态失败：%v", err)
	}
	utils.LogInfoF("苹果支付预警短信发送成功")
	return
}

// convert 转换时间格式和构建预警消息参数
func convert(params dbmodels.PayWarningParams, msg Message) (msgParams string) {
	t := time.Unix(msg.TransactionTime, 0).Local().Format("2006-01-02 15:04:05")
	cash := msg.Cash / 100 // 转换成元，默认为分。
	for _, phone := range params.Phone {
		msgParams += fmt.Sprintf("%s,%d,%d,%d,%s;", phone, msg.UserID, msg.TransactionID, cash, t)
	}
	msgParams = strings.TrimRight(msgParams, ";")
	return
}

// sendPayWarningSMS 发送支付预警短信。若失败设置重拾
func sendPayWarningSMS(params dbmodels.PayWarningParams, msg Message, times int, timeout time.Duration) (resp sms.SmsCodeResponse, err error) {
	msgParams := convert(params, msg)

	// 发送操作
	for i := 0; i < times; i++ {
		resp, err = sms.SendPayWarningSms(1, sms.SMS_Warning, msgParams)
		if err == nil && resp.Code == "0" {
			return
		}
		time.Sleep(timeout)
	}
	return
}
