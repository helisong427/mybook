package utils

import (
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

var GEngine *gorm.DB
var REngine *gorm.DB

func GDBInit() {
	// LogLevel := logger.Error
	// if Config.App.LogLevel == "debug" {
	// 	LogLevel = logger.Info
	// }
	// newLogger := NewGormLog(
	// 	log.New(os.Stdout, "\r\n", log.LstdFlags), // io writer
	// 	logger.Config{
	// 		SlowThreshold: time.Second, // 慢 SQL 阈值
	// 		LogLevel:      logger.Info, // Log level
	// 		Colorful:      true,        // 禁用彩色打印
	// 	},
	// )
	var err error
	masterConfStr := Config.Mysql.DataSource
	masterConfig := mysql.New(mysql.Config{
		DSN:                       masterConfStr,
		DefaultStringSize:         1024,  // string 类型字段的默认长度
		DisableDatetimePrecision:  true,  // 禁用 datetime 精度，MySQL 5.6 之前的数据库不支持
		DontSupportRenameIndex:    true,  // 重命名索引时采用删除并新建的方式，MySQL 5.7 之前的数据库和 MariaDB 不支持重命名索引
		DontSupportRenameColumn:   true,  // 用 `change` 重命名列，MySQL 8 之前的数据库和 MariaDB 不支持重命名列
		SkipInitializeWithVersion: false, // 根据当前 MySQL 版本自动配置

	})
	GEngine, err = gorm.Open(masterConfig, &gorm.Config{
		// Logger:      newLogger,
		QueryFields: true,
	})

	if err != nil {
		panic(err)
		return
	}

	rConfigStr := Config.Mysql.DataSource
	reportConfig := mysql.New(mysql.Config{
		DSN:                       rConfigStr,
		DefaultStringSize:         1024,  // string 类型字段的默认长度
		DisableDatetimePrecision:  true,  // 禁用 datetime 精度，MySQL 5.6 之前的数据库不支持
		DontSupportRenameIndex:    true,  // 重命名索引时采用删除并新建的方式，MySQL 5.7 之前的数据库和 MariaDB 不支持重命名索引
		DontSupportRenameColumn:   true,  // 用 `change` 重命名列，MySQL 8 之前的数据库和 MariaDB 不支持重命名列
		SkipInitializeWithVersion: false, // 根据当前 MySQL 版本自动配置

	})
	REngine, err = gorm.Open(reportConfig, &gorm.Config{
		// Logger:      newLogger,
		QueryFields: true,
	})

	if err != nil {
		panic(err)
		return
	}

	// if Config.Slave1DB.Type != "" {
	// 	slaveConfigStr := fmt.Sprintf("%s:%s@tcp(%s)/%s?charset=%s&parseTime=True&loc=%s",
	// 		Config.Slave1DB.Username,
	// 		Config.Slave1DB.Password,
	// 		Config.Slave1DB.Host+Config.Slave1DB.Port,
	// 		Config.Slave1DB.Dbname,
	// 		Config.Slave1DB.Charset,
	// 		Config.Slave1DB.TimeZone,
	// 	)
	// 	err := GEngine.Use(dbresolver.Register(dbresolver.Config{
	// 		Replicas: []gorm.Dialector{mysql.Open(slaveConfigStr)},
	// 		Policy:   dbresolver.RandomPolicy{},
	// 	}).SetMaxIdleConns(Config.MasterDB.MaxIdleConns).
	// 		SetMaxOpenConns(Config.MasterDB.MaxOpenConns))
	// 	if err != nil {
	// 		Logger.Fatal("初始化从数据库失败" + err.Error())
	// 		return
	// 	}
	// }
	return
}
