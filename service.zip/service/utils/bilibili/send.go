package bilibili

import (
	"encoding/json"
	"io/ioutil"
	"net/http"
	"strconv"
	"time"

	"gamers/utils"
)

type BiliBiliAdCallbackReq struct {
	TrackId      string `form:"track_id" binding:"required" json:"track_id"`
	AccountId    string `form:"account_id" json:"account_id"`     // b站账号
	CampaignId   string `form:"campaign_id" json:"campaign_id"`   // b站计划id
	UnitId       string `form:"unit_id" json:"unit_id"`           // b站单元id
	CreativeId   string `form:"creative_id" json:"creative_id"`   // b站创意id
	OS           string `form:"os" json:"os"`                     // 0安卓，1ios，2windows phone
	Imei         string `form:"imei" json:"imei"`                 // 用户终端的 IMEI，原始值为 15 位 IMEI，取其 32 位 MD5 摘要。
	CallbackUrl  string `form:"callback_url" json:"callback_url"` // 回调地址（需要 urlencode
	Mac          string `form:"mac" json:"mac"`                   // 保留分隔符”:”的大写 MAC 地址，取其 32 位 MD5 摘要
	IDFA         string `form:"idfa" json:"idfa"`                 // iOS IDFA，适用于 iOS6 及以上
	AAID         string `form:"aaid" json:"aaid"`                 // Android Advertising ID
	AndroidId    string `form:"android_id" json:"android_id"`     // 用户终端的 Android ID
	OAID         string `form:"oaid" json:"oaid"`                 // 匿名设备标识符
	Ip           string `form:"ip" json:"ip"`
	UA           string `form:"ua" json:"ua"`                         // 数据上报终端设备的 User Agent
	ModelPattern string `form:"model_pattern" json:"model_pattern"`   // 手机型号
	ClientClickT int64  `form:"client_click_t" json:"client_click_t"` // 客户端点击时间
	ShopId       string `form:"shop_id" json:"shop_id"`               // 店铺 ID
	UpMid        string `form:"up_mid" json:"up_mid"`                 // 视频 UP 主 MID
}

func (s *BiliBiliAdCallbackReq) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s *BiliBiliAdCallbackReq) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

func (s *BiliBiliAdCallbackReq) GetChannelInfo(key string) (data BiliBiliAdCallbackReq, err error) {
	key = utils.REDIS_CHANNEL_CALLBACK + key
	err = utils.RedisClient.Get(key).Scan(&data)
	return
}

func (s *BiliBiliAdCallbackReq) Del(key string) (err error) {
	key = utils.REDIS_CHANNEL_CALLBACK + key
	err = utils.RedisClient.Del(key).Err()
	return
}

const SEND_URL = "https://cm.bilibili.com/conv/api/conversion/ad/cb/v1?"
const (
	BILIBILI_REPORT_TYPE_DOWNLOAD         = "APP_DOWNLOAD"     // APP 下载成功
	BILIBILI_REPORT_TYPE_APP_INSTALL      = "APP_INSTALL"      // APP 安装成功
	BILIBILI_REPORT_TYPE_APP_FIRST_ACTIVE = "APP_FIRST_ACTIVE" // APP 首次激活
	BILIBILI_REPORT_TYPE_APP_ACTIVE       = "APP_ACTIVE"       // APP 激活但不是首次激活回传个值

	BILIBILI_REPORT_TYPE_DFORM_SUBMIT   = "DFORM_SUBMIT"   // 表单提交
	BILIBILI_REPORT_TYPE_USER_REGISTER  = "USER_REGISTER"  // ：用户注册
	BILIBILI_REPORT_TYPE_ADD_TO_CART    = "ADD_TO_CART"    // 加入购物车
	BILIBILI_REPORT_TYPE_ORDER_PLACE    = "ORDER_PLACE"    // 提交订单
	BILIBILI_REPORT_TYPE_USER_COST      = "USER_COST"      // 完成付费行为
	BILIBILI_REPORT_TYPE_USER_RESERVE   = "USER_RESERVE"   // 用户参与某个活动预订
	BILIBILI_REPORT_TYPE_RETENTION      = "RETENTION"      // ：用户留存
	BILIBILI_REPORT_TYPE_APP_CALLUP     = "APP_CALLUP"     // 调起成功
	BILIBILI_REPORT_TYPE_FORM_USER_COST = "FORM_USER_COST" // 教育完成表单付费行为
)

type Resp struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
	Data    string `json:"data"`
}

func (s *BiliBiliAdCallbackReq) Send(key string) {
	req := make(map[string][]string)
	req["conv_type"] = []string{BILIBILI_REPORT_TYPE_APP_FIRST_ACTIVE}
	req["conv_time"] = []string{strconv.Itoa(int(time.Now().UnixNano() / 1e6))}
	req["track_id"] = []string{s.TrackId}
	var resp *http.Response
	// uri,err := url.Parse(m.CallbackUrl)
	// if err != nil{
	//	utils.LogErrorF("解析回调连接[%s]失败,err:%s", m.CallbackUrl, err.Error())
	//	return
	// }
	var err error
	reqUrl := s.CallbackUrl
	if reqUrl == "" || reqUrl == "__CALLBACKURL__" {
		reqUrl = SEND_URL
		utils.LogInfoF("解析回调地址失败,启用备用上报链接，track_id：%s", s.TrackId)
		// err = m.Del(key)
		// if err != nil{
		//	utils.LogErrorF("移除无效channel信息失败，track_id：%s", m.TrackId)
		// }
		req["track_id"] = []string{s.TrackId}
		// return
	}
	for i := 0; i < 3; i++ {
		resp, err = utils.HttpGet(reqUrl, req, nil)
		if err != nil {
			utils.LogErrorF("第[%d]次上报到[%s]失败,err:%s", i+1, reqUrl, err.Error())
			time.Sleep(time.Duration(5*(i+1)) * time.Second)
		} else {
			break
		}
	}
	if err != nil {
		utils.LogErrorF("上报track_id[%s]到[%s]失败,err:%s", s.TrackId, reqUrl, err.Error())
		return
	}

	response, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return
	}
	var responseData Resp
	err = json.Unmarshal(response, &responseData)
	if err != nil {
		return
	}
	utils.LogInfoF("上报bilibili成功，track_id：%s", s.TrackId)
	err = s.Del(key)
	if err != nil {
		utils.LogErrorF("移除无效channel信息失败，track_id：%s", s.TrackId)
	}
	return
}
