package utils

//
// import (
// 	"context"
// 	"fmt"
//
// 	"github.com/olivere/elastic/v7"
// )
//
// // ESClient elasticsearch 链接
// var ESClient *elastic.Client
//
// // ESInit elasticsearch 链接
// func ESInit() {
// 	var err error
// 	host := "http://" + Config.Elasticsearch.Host + Config.Elasticsearch.Port
// 	if Config.Elasticsearch.User != "" && Config.Elasticsearch.User != "" {
// 		ESClient, err = elastic.NewClient(
// 			elastic.SetSniff(false),
// 			elastic.SetBasicAuth(Config.Elasticsearch.User, Config.Elasticsearch.Password),
// 			elastic.SetURL(host))
// 	} else {
// 		ESClient, err = elastic.NewClient(
// 			elastic.SetSniff(false),
// 			elastic.SetURL(host))
// 	}
// 	if err != nil {
// 		Logger.Fatal("ElasticSearch链接失败:" + err.Error())
// 	}
// }
//
// // ESCreateIndex创建索引
// func ESCreateIndex(index, mapping string) bool {
// 	ctx := context.Background()
// 	result, err := ESClient.CreateIndex(index).BodyString(mapping).Do(ctx)
// 	if err != nil {
// 		fmt.Println(err)
// 		return false
// 	}
// 	return result.Acknowledged
// }
//
// // ESDeleteIndex 删除index
// func ESDeleteIndex(index string) bool {
// 	ctx := context.Background()
// 	result, err := ESClient.DeleteIndex(index).Do(ctx)
// 	if err != nil {
// 		fmt.Println(err)
// 		return false
// 	}
// 	return result.Acknowledged
// }
//
// // ESIndexExists 校验 index 是否存在
// func ESIndexExists(index ...string) bool {
// 	exists, err := ESClient.IndexExists(index...).Do(context.Background())
// 	if err != nil {
// 		return false
// 	}
// 	return exists
// }
//
// // ESCreate创建
// func ESCreate(index string, id string, doc interface{}) (string, error) {
// 	result, err := ESClient.Index().Index(index).Id(id).BodyJson(doc).Do(context.Background())
// 	if err != nil {
// 		return "", err
// 	}
// 	return result.Id, nil
// }
//
// // ESDelete 删除
// func ESDelete(index string, id string) {
// 	res, err := ESClient.Delete().Index(index).Id(id).Do(context.Background())
// 	if err != nil {
// 		fmt.Printf(err.Error())
// 		return
// 	}
// 	fmt.Printf("delete result %s\n", res.Result)
// }
//
// // ESUpdate 修改  doc:=map[string]interface{}{"age": 88,"interests": []string{}}
// func ESUpdate(index string, id string, doc interface{}) {
// 	ctx := context.Background()
// 	res, err := ESClient.Update().Index(index).Id(id).Doc(doc).Do(ctx)
// 	if err != nil {
// 		fmt.Printf(err.Error())
// 		return
// 	}
// 	fmt.Printf("update age %s\n", res.Result)
// }
//
// // ESQuery 通过id查找
// func ESGet(index string, id string) *elastic.GetResult {
// 	ctx := context.Background()
// 	GetResult, err := ESClient.Get().Index(index).Id(id).Do(ctx)
// 	if err != nil {
// 		fmt.Println(err)
// 	}
// 	return GetResult
// }
//
// // ESTermsSearch  字段精准匹配搜索
// func ESTermsSearch(index string, field string, query ...interface{}) *elastic.SearchResult {
// 	ctx := context.Background()
// 	var err error
// 	SearchResult, err := ESClient.Search(index).Query(elastic.NewTermsQuery(field, query...)).Pretty(true).Do(ctx)
// 	if err != nil {
// 		fmt.Println("err:", err.Error())
// 	}
// 	return SearchResult
// }
//
// // 以下是测试/参考代码请勿在项目中直接使用
// // TODO
// // esAggSearch 聚合
// func ESAggSearch(index string) {
// 	ctx := context.Background()
// 	all := elastic.NewMatchAllQuery() // 查询条件
// 	maxAgg := elastic.NewMaxAggregation().Field("age")
// 	maxAggResult, _ := ESClient.Search(index).Query(all).Pretty(true).Aggregation("maxAgg", maxAgg).Do(ctx)
// 	aggResult, _ := maxAggResult.Aggregations.Max("maxAgg")
// 	fmt.Println("max:", *aggResult.Value)
//
// 	minAgg := elastic.NewMinAggregation().Field("age") // 设置聚合字段
// 	minAggResult, _ := ESClient.Search(index).Pretty(true).Aggregation("minAgg", minAgg).Do(ctx)
// 	aggResult, _ = minAggResult.Aggregations.Min("minAgg")
// 	fmt.Println("min:", *aggResult.Value)
//
// 	avgAgg := elastic.NewAvgAggregation().Field("age") // 设置聚合字段
// 	avgAggResult, _ := ESClient.Search(index).Pretty(true).Aggregation("avgAgg", avgAgg).Do(ctx)
// 	aggResult, _ = avgAggResult.Aggregations.Min("avgAgg")
// 	fmt.Println("avg:", *aggResult.Value)
//
// 	sumAgg := elastic.NewSumAggregation().Field("age") // 设置聚合字段
// 	sumResult, _ := ESClient.Search(index).Pretty(true).Aggregation("sumAgg", sumAgg).Do(ctx)
// 	aggResult, _ = sumResult.Aggregations.Sum("sumAgg")
// 	fmt.Println("sum:", *aggResult.Value)
//
// 	valueCountAgg := elastic.NewValueCountAggregation().Field("age") // 设置聚合字段
// 	valueCountResult, _ := ESClient.Search(index).Pretty(true).Aggregation("valueCountAgg", valueCountAgg).Do(ctx)
// 	aggResult, _ = valueCountResult.Aggregations.ValueCount("valueCountAgg")
// 	fmt.Println("valueCount:", *aggResult.Value)
//
// 	statsAgg := elastic.NewStatsAggregation().Field("age") // 设置聚合字段
// 	statsResult, _ := ESClient.Search(index).Pretty(true).Aggregation("statsAgg", statsAgg).Do(ctx)
// 	statsResultStats, _ := statsResult.Aggregations.Stats("statsAgg")
// 	fmt.Println("stats:", statsResultStats)
// 	fmt.Println("stats-avg:", *statsResultStats.Avg)
// 	//
// 	extendedStatsAgg := elastic.NewExtendedStatsAggregation().Field("age") // 设置聚合字段
// 	extendedStatsResult, _ := ESClient.Search(index).Pretty(true).Aggregation("extendedStatsAgg", extendedStatsAgg).Do(ctx)
// 	extendedStatsResultStats, _ := extendedStatsResult.Aggregations.ExtendedStats("extendedStatsAgg")
// 	fmt.Println("extendedStats:", extendedStatsResultStats)
// 	fmt.Println("extendedStats-SumOfSquares:", *extendedStatsResultStats.SumOfSquares)
// 	fmt.Println("extendedStats-StdDeviation:", *extendedStatsResultStats.StdDeviation)
//
// 	// 分段聚合 0-30,30-60,60+
// 	rangeAgg := elastic.NewRangeAggregation().Field("age").AddRange(0, 30).AddRange(30, 60).Gt(60)
// 	rangeResult, err := ESClient.Search(index).Pretty(true).Aggregation("rangeAgg", rangeAgg).Do(ctx)
// 	if err != nil {
// 		fmt.Println(err)
// 	}
// 	rangeAggRes, _ := rangeResult.Aggregations.Range("rangeAgg")
// 	fmt.Println("rangeAgg:")
// 	for _, item := range rangeAggRes.Buckets {
// 		fmt.Printf("key: %s, value: %v\n", item.Key, item.DocCount)
// 	}
// 	// 分析first_name
// 	termsAggs := elastic.NewTermsAggregation().Field("first_name")
// 	SearchResult, err := ESClient.Search(index).Aggregation("Terms_agg", termsAggs).Do(ctx)
// 	if err != nil {
// 		fmt.Println(err.Error())
// 	}
// 	termsAggRes, _ := SearchResult.Aggregations.Terms("Terms_agg")
// 	fmt.Println("termsAgg:")
// 	for _, item := range termsAggRes.Buckets {
// 		fmt.Printf("key: %s, value: %v\n", item.Key, item.DocCount)
// 	}
// 	// top
// 	topInterestsHitsAgg := elastic.NewTopHitsAggregation().FetchSource(true)
// 	topInterestsAgg := elastic.NewTermsAggregation().Field("interests").Size(2).SubAggregation("top_interests_hits", topInterestsHitsAgg)
// 	SearchResult, err = ESClient.Search(index).Aggregation("top-tags", topInterestsAgg).Do(ctx)
// 	if err != nil {
// 		fmt.Println(err.Error())
// 	}
// 	termsAggRes, _ = SearchResult.Aggregations.Terms("top-tags")
// 	fmt.Println("topHitsAgg:")
// 	for _, item := range termsAggRes.Buckets {
// 		fmt.Printf("key: %s, value: %v\n", item.Key, item.DocCount)
// 	}
// 	// SubAggregation
// 	filterAgg := elastic.NewFilterAggregation().Filter(
// 		elastic.NewRangeQuery("age").Gte(10).Lte(20)).
// 		SubAggregation("avgRetweetsSub", elastic.NewAvgAggregation().Field("age"))
// 	filterAggResult, err := ESClient.Search(index).Pretty(true).Aggregation("filterAgg", filterAgg).Do(ctx)
// 	if err != nil {
// 		fmt.Println(err.Error())
// 	}
// 	agg, _ := filterAggResult.Aggregations.Filter("filterAgg")
// 	fmt.Println("filterAgg-doc:", agg.DocCount)
// 	sub, _ := agg.Avg("avgRetweetsSub")
// 	fmt.Println("filterAgg-sub-aggregation:", *sub.Value)
//
// 	missingAgg := elastic.NewMissingAggregation().Field("age")
// 	missingAggResult, err := ESClient.Search(index).Aggregation("missingAgg", missingAgg).Do(ctx)
// 	if err != nil {
// 		fmt.Println(err.Error())
// 	}
// 	missingAggResults, _ := missingAggResult.Aggregations.Missing("missingAgg")
// 	fmt.Println("missingAgg:", missingAggResults.DocCount)
// }
//
// // esBoolSearch bool查询
// func esBoolSearch(index string) *elastic.SearchResult {
// 	ctx := context.Background()
// 	var err error
// 	// 条件查询
// 	boolQ := elastic.NewBoolQuery()
// 	boolQ.Must(elastic.NewTermQuery("interests", "sports")) // 匹配查询
// 	boolQ.Must(elastic.NewRangeQuery("age").Lte(210))       // 且小于等于210
// 	// elastic.NewMissingAggregation()
// 	boolQ.MustNot(elastic.NewMatchPhraseQuery("about", "24口")) // 但about不包含24口MustNot=not
// 	boolQ.Should(elastic.NewMatchQuery("first_name", "997"))   // Should=or first_name 包含997
// 	SearchResult, err := ESClient.Search(index).Query(boolQ).Do(ctx)
// 	if err != nil {
// 		fmt.Println("err:", err.Error())
// 	}
// 	return SearchResult
// }
