package fdd

import "errors"

// 获取pdf模板表单域key值接口
type GetPdftemplateKeysRequest struct {
	baseRequest
	TemplateId string `json:"template_id"` // 模板id
}

type GetPdftemplateKeysResponse struct {
	Code int      `json:"code"`
	Msg  string   `json:"msg"`
	Data []string `json:"data"`
}

func (c *Client) GetPdftemplateKeys() (tempKeys []string, err error) {
	c.Address = getPdftemplateKeys
	req := GetPdftemplateKeysRequest{
		baseRequest: c.baseRequest,
		TemplateId:  c.TemplateId,
	}
	sign := c.getPdftemplateKeysSign(c.TemplateId)
	req.MsgDigest = sign
	r := GetPdftemplateKeysResponse{}
	err = c.send(req, &r)
	if err != nil {
		return
	}
	if r.Code != 1 {
		err = errors.New(r.Msg)
		return
	}
	tempKeys = r.Data
	return
}
