package fdd

import (
	"crypto/sha1"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"sort"
	"strings"
	"time"

	"github.com/guonaihong/gout"

	"gamers/utils"
)

const (
	accountRegister    = "account_register.api"      // 注册账号
	personVerifyUrl    = "get_person_verify_url.api" // 个人实名认证地址
	personVerifySign   = "person_verify_sign.api"    // 快捷签
	findPersonCertInfo = "find_personCertInfo.api"   // 查询个人实名认证信息
	getFile            = "get_file.api"              // 通过uuid下载文件
	extSignAuto        = "extsign_auto.api"          // 自动签
	beforeAuthsign     = "before_authsign.api"       // 授权自动签
	uploaddocs         = "uploaddocs.api"            // 合同上传
	generateContract   = "generate_contract.api"     // 模板填充
	getPdftemplateKeys = "get_pdftemplate_keys.api"  // 获取pdf模板表单key值
	contractFiling     = "contractFiling.api"        // 合同归档

)

type Client struct {
	Host        string `json:"host"`         // 请求域名
	AppSecret   string `json:"app_secret"`   // 应用秘钥
	Address     string `json:"address"`      // 请求地址
	TemplateId  string `json:"contract_id"`  // 模板编号
	DocTitle    string `json:"doc_title"`    // 合同名称
	SignKeyword string `json:"sign_keyword"` // 合同盖章关键字
	CustomerId  string `json:"customer_id"`  // 客户id（平台）
	NotifyUrl   string `json:"notify_url"`   // 异步通知地址
	ReturnUrl   string `json:"return_url"`   // 返回地址
	DocUrl      string `json:"doc_url"`      // 合同地址
	baseRequest
}

type baseRequest struct {
	AppId     string `json:"app_id"`     // 接入方ID
	Timestamp string `json:"timestamp"`  // 请求时间 yyyyMMddHHmmss
	V         string `json:"v"`          // 版本号码:2.0
	MsgDigest string `json:"msg_digest"` // 签名
}

type baseResponse struct {
	Code int    `json:"code"`
	Msg  string `json:"msg"`
}

func NewFdd() *Client {
	conf := utils.Config.Third.FDD
	return &Client{
		Host:        conf.Host,
		AppSecret:   conf.AppSecret,
		TemplateId:  conf.TemplateId,
		CustomerId:  conf.CustomerId,
		DocTitle:    conf.DocTitle,
		DocUrl:      "",
		SignKeyword: conf.SignKeyword,
		NotifyUrl:   conf.NotifyUrl,
		ReturnUrl:   conf.ReturnUrl,
		baseRequest: baseRequest{
			AppId:     conf.AppId,
			Timestamp: time.Now().Format("20060102150405"),
			V:         "2.0",
		},
	}
}

func (c *Client) send(request interface{}, response interface{}) (err error) {
	url := c.Host + c.Address
	marshal, err := json.Marshal(request)
	if err != nil {
		return
	}
	m := make(map[string]string)
	err = json.Unmarshal(marshal, &m)
	if err != nil {
		return
	}
	fmt.Println(m)
	err = gout.POST(url).Debug(true).SetWWWForm(m).BindJSON(response).Do()
	return
}

// 参数签名
// Base64( sha1( app_id+md5(timestamp)+sha1(app_secret+account_type+open_id) ) )
func (c *Client) sign(params map[string]interface{}) (sign string) {
	buf := strings.Builder{}
	buf.WriteString(c.AppSecret)
	// 排序
	sortSlice := []string{}

	for k := range params {
		sortSlice = append(sortSlice, k)
	}
	sort.Strings(sortSlice)
	for _, k := range sortSlice {
		if v, ok := params[k]; ok {
			buf.WriteString(v.(string))
		}
	}
	asciiString := buf.String()

	// 业务参数sha1
	h1 := sha1.New()
	h1.Write([]byte(asciiString))
	businessParams := strings.ToUpper(hex.EncodeToString(h1.Sum(nil)))

	// 全部参数拼接sha1
	h2 := sha1.New()
	md5Time := strings.ToUpper(utils.FuncMD5(c.Timestamp))
	h2.Write([]byte(c.AppId + md5Time + businessParams)) // app_id+md5(timestamp)+sha1(...)
	lastParams := strings.ToUpper(hex.EncodeToString(h2.Sum(nil)))
	sign = base64.StdEncoding.EncodeToString([]byte(lastParams))
	return
}

// 自动签接口签名
// Base64( SHA1(app_id +MD5(transaction_id+timestamp) +SHA1(app_secret+ customer_id) ) )
func (c *Client) extsionAuto(transactionId string, customerId string) (sign string) {
	h1 := sha1.New()
	h1.Write([]byte(c.AppSecret + customerId))
	businessParams := strings.ToUpper(hex.EncodeToString(h1.Sum(nil)))

	h2 := sha1.New()
	md5Time := strings.ToUpper(utils.FuncMD5(transactionId + c.Timestamp))
	h2.Write([]byte(c.AppId + md5Time + businessParams))
	lastParams := strings.ToUpper(hex.EncodeToString(h2.Sum(nil)))
	sign = base64.StdEncoding.EncodeToString([]byte(lastParams))
	return
}

// 合同模板填充签名
// Base64( SHA1(app_id +MD5(timestamp) +SHA1(app_secret+ template_id + contract_id) + parameter_map ) )
func (c *Client) generateContractSign(contractId string, parameterMap string) (sign string) {
	h1 := sha1.New()
	h1.Write([]byte(c.AppSecret + c.TemplateId + contractId))
	businessParams := strings.ToUpper(hex.EncodeToString(h1.Sum(nil)))

	h2 := sha1.New()
	md5Time := strings.ToUpper(utils.FuncMD5(c.Timestamp))

	h2.Write([]byte(c.AppId + md5Time + businessParams + parameterMap))
	lastParams := strings.ToUpper(hex.EncodeToString(h2.Sum(nil)))
	sign = base64.StdEncoding.EncodeToString([]byte(lastParams))
	return
}

// 合同上传签名
func (c *Client) uploaddocsSign(contractId string) (sign string) {
	h1 := sha1.New()
	h1.Write([]byte(c.AppSecret + contractId))
	businessParams := strings.ToUpper(hex.EncodeToString(h1.Sum(nil)))

	h2 := sha1.New()
	md5Time := strings.ToUpper(utils.FuncMD5(c.Timestamp))

	h2.Write([]byte(c.AppId + md5Time + businessParams))
	lastParams := strings.ToUpper(hex.EncodeToString(h2.Sum(nil)))
	sign = base64.StdEncoding.EncodeToString([]byte(lastParams))
	return
}

// 合同归档
func (c *Client) sontractFilingSign(contractId string) (sign string) {
	h1 := sha1.New()
	h1.Write([]byte(c.AppSecret + contractId))
	businessParams := strings.ToUpper(hex.EncodeToString(h1.Sum(nil)))

	h2 := sha1.New()
	md5Time := strings.ToUpper(utils.FuncMD5(c.Timestamp))

	h2.Write([]byte(c.AppId + md5Time + businessParams))
	lastParams := strings.ToUpper(hex.EncodeToString(h2.Sum(nil)))
	sign = base64.StdEncoding.EncodeToString([]byte(lastParams))
	return
}

// 获取pdf模板表单key签名
func (c *Client) getPdftemplateKeysSign(templateId string) (sign string) {
	h1 := sha1.New()
	h1.Write([]byte(c.AppSecret + templateId))
	businessParams := strings.ToUpper(hex.EncodeToString(h1.Sum(nil)))

	h2 := sha1.New()
	md5Time := strings.ToUpper(utils.FuncMD5(c.Timestamp))

	h2.Write([]byte(c.AppId + md5Time + businessParams))
	lastParams := strings.ToUpper(hex.EncodeToString(h2.Sum(nil)))
	sign = base64.StdEncoding.EncodeToString([]byte(lastParams))
	return
}
