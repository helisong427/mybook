package fdd

import (
	"errors"

	"github.com/fatih/structs"
)

const (
	// 法大大认证状态
	PERSON_STATUS_INACTIVATED             string = "0" // 未激活
	PERSON_STATUS_NOT_CERTIFIED           string = "1" // 未激活
	PERSON_STATUS_PASSED                  string = "2" // 审核通过
	PERSON_STATUS_SUBMITTED_FOR_REVIEW    string = "3" // 已提交待审核
	PERSON_STATUS_FAILED_THE_REVIEWSTRING string = "4" // 审核不通过
)

type FindPersonCertInfoRequest struct {
	baseRequest
	VerifiedSerialno string `json:"verified_serialno"` // 交易号,获取认证信息时返回
}

type FindPersonCertInfoResponse struct {
	baseResponse
	Data struct {
		TransactionNo            string   `json:"transactionNo"`            // 交易号码
		Type                     string   `json:"type"`                     // 1个人,2企业
		PassTime                 string   `json:"passTime"`                 // 审核通过时间
		AuthenticationSubmitTime string   `json:"authenticationSubmitTime"` // 认证提交时间
		Person                   struct { // 个人信息
			PersonName           string `json:"personName"`           // 个人姓名
			Type                 string `json:"type"`                 // 0个人,1法人,2代理人
			CertType             string `json:"certType"`             // 证件类型:0身份证,1护照,B香港,C台湾
			AuditorTime          string `json:"auditorTime"`          // 审核时间
			IdCard               string `json:"idCard"`               // 身份证号码
			Mobile               string `json:"mobile"`               // 手机号
			Status               string `json:"status"`               // 0:未激活,1未认证,2审核通过,3已提交待审核,4审核不通过
			VerifyType           string `json:"verifyType"`           // 认证方式:0腾讯云,1三要素,2手势
			AuditFailReason      string `json:"auditFailReason"`      // 不通过原因
			HeadPhotoPath        string `json:"headPhotoPath"`        // 身份证正面uuid
			BackGroundidCardPath string `json:"backGroundidCardPath"` // 身份证反面uuid
			PhotoUuid            string `json:"photoUuid"`            // 薇众返回的照片uuid,人脸识别通过才返回
			GesturePhotoPath     string `json:"gesturePhotoPath"`     // 手势照片uuid
			Fork                 string `json:"fork"`                 // 民族
			Birthday             string `json:"birthday"`             // 生日
			Sex                  string `json:"sex"`                  // 性别:1男,2女
			StartDate            string `json:"startDate"`            // 证件起始时间
			ExpiresDate          string `json:"expiresDate"`          // 证件到期时间
			IssueAuthority       string `json:"issueAuthority"`       // 办法机构
			Address              string `json:"address"`              // 地址
			BankCardNo           string `json:"bankCardNo"`           // 银行卡号码
		} `json:"person"`
	} `json:"data"`
}

// 查询个人认证信息
func (c *Client) FindPersonCertInfoResponse(transactionNo string) (r FindPersonCertInfoResponse, err error) {
	c.Address = findPersonCertInfo
	req := FindPersonCertInfoRequest{
		baseRequest:      c.baseRequest,
		VerifiedSerialno: transactionNo,
	}
	m := structs.Map(&req)
	sign := c.sign(m)
	req.MsgDigest = sign
	err = c.send(req, &r)
	if err != nil {
		return
	}
	if r.Code != 1 {
		err = errors.New(r.Msg)
		return
	}
	return
}
