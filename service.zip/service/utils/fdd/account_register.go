package fdd

import (
	"errors"

	"github.com/fatih/structs"
)

type AccountRegisterRequest struct {
	baseRequest
	OpenId      string `json:"open_id"`      // 用户id在接入方的唯一标识
	AccountType string `json:"account_type"` // 1:个人,2:企业
}

type AccountRegisterResponse struct {
	Code int    `json:"code"`
	Msg  string `json:"msg"`
	Data string `json:"data"`
}

// 注册账号
func (c *Client) AccountRegister(openId string) (r AccountRegisterResponse, err error) {
	c.Address = accountRegister
	req := AccountRegisterRequest{
		baseRequest: c.baseRequest,
		OpenId:      openId,
		AccountType: "1",
	}
	m := structs.Map(&req)
	sign := c.sign(m)
	req.MsgDigest = sign
	err = c.send(req, &r)
	if err != nil {
		return
	}
	if r.Code != 1 {
		err = errors.New(r.Msg)
		return
	}
	return
}
