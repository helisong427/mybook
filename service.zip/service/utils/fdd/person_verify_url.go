package fdd

import (
	"errors"

	"github.com/fatih/structs"
)

const (
	// 是否允许用户页面修改
	pageModifyAllow      string = "1" // 允许
	pageModifyNotAllowed string = "2" // 不允许
)

type PersonVerifyUrlRequest struct {
	baseRequest
	CustomerId  string `json:"customer_id"`  // 客户编号,在注册时返回
	VerifiedWay string `json:"verified_way"` // 实名认证套餐类型:0:三要素标准方案；1:三要素补充方案； 2:四要素标准方案；3:四要素补充方案'
	PageModify  string `json:"page_modify"`  // 是否允许用户页面修改:1--允许,2--不允许
	NotifyUrl   string `json:"notify_url"`   // 异步回调地址
	ReturnUrl   string `json:"return_url"`   // 同步通知url
}

type PersonVerifyUrlResponse struct {
	baseResponse
	Data struct {
		TransactionNo string `json:"transactionNo"` // 交易号码(需要保存,用于证书申请和实名认证查询)
		Url           string `json:"url"`           // 地址(需要base64解码)
	} `json:"data"`
}

// 个人实名认证
func (c *Client) PersonVerifyUrl(customerId string) (r PersonVerifyUrlResponse, err error) {
	c.Address = personVerifyUrl
	req := PersonVerifyUrlRequest{
		baseRequest: c.baseRequest,
		CustomerId:  customerId,
		VerifiedWay: "0",
		PageModify:  pageModifyNotAllowed,
		NotifyUrl:   c.NotifyUrl,
		ReturnUrl:   c.ReturnUrl,
	}
	m := structs.Map(&req)
	sign := c.sign(m)
	req.MsgDigest = sign
	err = c.send(req, &r)
	if err != nil {
		return
	}
	if r.Code != 1 {
		err = errors.New(r.Msg)
		return
	}
	return
}
