package fdd

import (
	"errors"
	"fmt"
	"time"

	"github.com/fatih/structs"

	"gamers/utils"
)

type PersonVerifySignRequest struct {
	baseRequest
	TransactionId     string `json:"transaction_id"`      // 交易号码
	ContractId        string `json:"contract_id"`         // 合同编号
	CustomerId        string `json:"customer_id"`         // 客户编号
	VerifiedWay       string `json:"verified_way"`        // 实名认证套餐类型:0:三要素标准方案；1:三要素补充方案； 2:四要素标准方案；3:四要素补充方案'
	PageModify        string `json:"page_modify"`         // 是否允许用户页面修改:1--允许,2--不允许
	NotifyUrl         string `json:"notify_url"`          // 异步回调地址
	ReturnUrl         string `json:"return_url"`          // 同步通知url
	VerifiedNotifyUrl string `json:"verified_notify_url"` // 认证结果异步回调地址
	IdPhotoOptional   string `json:"id_photo_optional"`   // 是否需要上传身份证照片:0-只需要头像面,1-头像和国徽面都需要,3-都不需要
}

type PersonVerifySignResponse struct {
	baseResponse
	Data struct {
		VerifiedSerialNo string `json:"verifiedSerialNo"` // 交易编号
		Url              string `json:"url"`              // 合同地址
	} `json:"data"`
}

// 快捷签
func (c *Client) PersonVerifySign(contractId string, customerId string) (r PersonVerifySignResponse, transactionId string, err error) {
	c.Address = personVerifySign
	req := PersonVerifySignRequest{
		baseRequest:       c.baseRequest,
		TransactionId:     fmt.Sprintf("%d%s", time.Now().Unix(), utils.FuncRandString(10)),
		ContractId:        contractId,
		CustomerId:        customerId,
		VerifiedWay:       "0",
		PageModify:        pageModifyNotAllowed,
		NotifyUrl:         c.NotifyUrl,
		ReturnUrl:         c.ReturnUrl,
		VerifiedNotifyUrl: c.NotifyUrl,
		IdPhotoOptional:   "1",
	}
	m := structs.Map(&req)
	sign := c.sign(m)
	req.MsgDigest = sign
	err = c.send(req, &r)
	if err != nil {
		return
	}
	if r.Code != 1 {
		err = errors.New(r.Msg)
		return
	}
	transactionId = req.TransactionId
	return
}
