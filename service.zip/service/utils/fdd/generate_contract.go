package fdd

import (
	"encoding/json"
	"errors"
	"fmt"
	"time"
)

// 合同模板填充
type GenerateContractRequest struct {
	baseRequest
	DocTitle     string `json:"doc_title"`     // 文档标题
	TemplateId   string `json:"template_id"`   // 模板编号
	ContractId   string `json:"contract_id"`   // 合同编号
	FontSize     string `json:"font_size"`     // 字体大小
	FontType     string `json:"font_type"`     // 字体类型:0-宋体；1-仿宋；2-黑体；3-楷体；4-微软雅黑
	FillType     string `json:"fill_type"`     // 0 pdf模板、1在线填充模板 不填默认为0
	ParameterMap string `json:"parameter_map"` // 填充内容
}

type ParameterMap struct {
	UserName string `json:"userName"`
}

type GenerateContractResponse struct {
	Result      string `json:"result"`       // 处理结果
	Code        string `json:"code"`         // 状态码
	Msg         string `json:"msg"`          // 描述
	DownloadUrl string `json:"download_url"` // 合同下载地址
	ViewpdfUrl  string `json:"viewpdf_url"`  // 合同查看地址
}

func (c *Client) GenerateContract(userId int64) (contractId string, err error) {
	// 获取模板key
	keys, err := c.GetPdftemplateKeys()
	if err != nil {
		return
	}

	parameterMap := make(map[string]interface{})
	for _, v := range keys {
		parameterMap[v] = fmt.Sprintf("签约时间：%s", time.Now().Format("2006年01月02日"))
	}
	c.Address = generateContract

	marshal, _ := json.Marshal(parameterMap)
	// 合合同编号
	contractId = fmt.Sprintf("%d%d", userId, time.Now().Unix())
	req := GenerateContractRequest{
		baseRequest:  c.baseRequest,
		DocTitle:     c.DocTitle,
		TemplateId:   c.TemplateId,
		ContractId:   contractId,
		FontSize:     "14",
		FontType:     "0",
		FillType:     "1",
		ParameterMap: string(marshal),
	}
	sign := c.generateContractSign(req.ContractId, req.ParameterMap)
	req.MsgDigest = sign
	r := UploaddocsResponse{}
	err = c.send(req, &r)
	if err != nil {
		return
	}
	if r.Result != "success" || r.Code != "1000" {
		err = errors.New(r.Msg)
		return
	}
	return
}
