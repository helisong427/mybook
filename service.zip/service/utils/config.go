package utils

import (
	"github.com/tal-tech/go-zero/core/conf"

	"gamers/v2/config"
)

// 全局配置文件
var Config *config.Config

// ConfigInit 初始化配置文件 Env 运行环境
func ConfigInit(configFile *string) {
	Config = &config.Config{}
	conf.MustLoad(*configFile, Config)
	// iniFile, _ := ini.Load("./config/" + env + ".ini")
	// Config = new(config.FileConfig)
	// iniFile.MapTo(Config)
}

// ConfigInitLocal 初始化配置文件 Env 运行环境 (本地做调试用)
func ConfigInitLocal(configFile ...string) {

	Config = &config.Config{}
	conf.MustLoad(configFile[0], Config)
	// var (
	// 	err     error
	// 	pwd     string
	// 	iniFile *ini.File
	// )
	//
	// if pwd, err = os.Getwd(); err != nil {
	// 	log.Println("get config pwd error: ", err.Error())
	// 	pwd = "."
	// } else {
	// 	pwd = strings.Replace(pwd, "\\", "/", -1)
	// 	re3, _ := regexp.Compile("service(.?)*([a-zA-Z])*")
	// 	rep := re3.ReplaceAllStringFunc(pwd, func(s string) string {
	// 		return ""
	// 	})
	// 	pwd = rep + "service"
	// }
	//
	// if iniFile, err = ini.Load(pwd + "/config/" + env + ".ini"); err != nil {
	// 	log.Fatal("init config error: ", err.Error())
	// 	return
	// }
	//
	// Config = new(config.FileConfig)
	//
	// if err = iniFile.MapTo(Config); err != nil {
	// 	log.Fatal("convert config error: ", err.Error())
	// }
}
