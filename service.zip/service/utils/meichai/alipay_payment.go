package meichai

import (
	"encoding/json"
	"errors"
)

type AlipayPaymentRequest struct {
	Outtradeno   string `json:"outtradeno"`   // 商户交易流水号
	Username     string `json:"username"`     // 姓名
	Useridcard   string `json:"useridcard"`   // 身份证号码
	Usermobile   string `json:"usermobile"`   // 手机号
	Useralipayno string `json:"useralipayno"` // 支付宝账号
	Salary       string `json:"salary"`       // 薪资
	Salarymemo   string `json:"salarymemo"`   // 薪资备注
}

type AlipayPaymentResponse struct {
	BaseResponse
	Data struct {
		TradeNo string `json:"trade_no"`
	} `json:"data"`
}

// 测试环境不能支付
func (c *Client) AlipayPayment(request AlipayPaymentRequest) (tradeNo string, err error) {
	c.Params["method"] = alipayPaymentMethod
	bizContent, err := json.Marshal(request)
	if err != nil {
		return
	}
	c.Params["biz_content"] = string(bizContent)
	err = c.getSign()
	if err != nil {
		return
	}
	r := BankCardVerifyResponse{}
	err = c.Send(&r)
	if err != nil {
		return
	}
	if r.Code != "00" || r.SubCode != "00000" {
		marshal, _ := json.Marshal(r)
		err = errors.New(string(marshal))
	}
	return
}
