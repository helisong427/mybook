package meichai

import (
	"encoding/json"
	"errors"

	"gamers/utils"
)

//姓名+身份证+支付宝 三要素校验接口
type AlipayCardVerifyRequest struct {
	IndividualName     string `json:"individual_name"`     // 姓名
	IndividualIdCard   string `json:"individual_idcard"`   // 身份证号码
	IndividualAlipayno string `json:"individual_alipayno"` // 支付宝账号
	IndividualMobile   string `json:"individual_mobile"`   // 手机号
}

type AlipayCardVerifyResponse struct {
	BaseResponse
}

// 支付宝校验
func (c *Client) AlipayCardVerify(realName, idCard, alipay, mobile string) (err error) {
	c.Params["method"] = alipayCardVerifyMethod
	request := AlipayCardVerifyRequest{
		IndividualName:     realName,
		IndividualIdCard:   idCard,
		IndividualAlipayno: alipay,
		IndividualMobile:   mobile,
	}
	bizContent, err := json.Marshal(request)
	if err != nil {
		return
	}
	c.Params["biz_content"] = string(bizContent)

	err = c.getSign()
	if err != nil {
		return
	}
	r := BankCardVerifyResponse{}
	err = c.Send(&r)
	if err != nil {
		return
	}
	if utils.Config.App.Env == "prod" {
		if r.Code != "00" || r.SubCode != "00000" {
			marshal, _ := json.Marshal(r)
			err = errors.New(string(marshal))
		}
	} else {
		if r.Code != "00" {
			marshal, _ := json.Marshal(r)
			err = errors.New(string(marshal))
		}
	}
	return
}
