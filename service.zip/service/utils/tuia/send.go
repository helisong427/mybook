package tuia

import (
	"encoding/json"
	"io/ioutil"
	"net/http"
	"strconv"
	"time"

	"gamers/utils"
)

type TuiACallbackReq struct {
	TuiAId      string `form:"tui_a_id" binding:"required"` // 推啊用户id
	TuiAOrderId string `form:"tui_a_order_id"`
	Ip          string `form:"ip" json:"ip"`
	UA          string `form:"ua" json:"ua"`     // 数据上报终端设备的 User Agent
	Imei        string `form:"imei" json:"imei"` // 加密imei，原值MD5 32位加密小写
	IDFA        string `form:"idfa" json:"idfa"` // iOS IDFA，适用于 iOS6 及以上
	AAID        string `form:"aaid" json:"aaid"` // Android Advertising ID
	Device      string `form:"device"`           // 推啊的imeiMd5>idfaMd5>oaidMd5参数值替换
}

func (s *TuiACallbackReq) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s TuiACallbackReq) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

func (m TuiACallbackReq) GetChannelInfo(key string) (data TuiACallbackReq, err error) {
	key = utils.REDIS_CHANNEL_CALLBACK + key
	err = utils.RedisClient.Get(key).Scan(&data)
	return
}

func (m TuiACallbackReq) Del(key string) (err error) {
	key = utils.REDIS_CHANNEL_CALLBACK + key
	err = utils.RedisClient.Del(key).Err()
	return
}

const SEND_URL = "https://activity.tuia.cn/log/effect/v2"

const (
	TUIA_SUBTYPE_INSTALL    = iota + 1 // 安装
	TUIA_SUBTYPE_START                 // 启动 APP
	TUIA_SUBTYPE_REGISTER              // 注册账号
	TUIA_SUBTYPE_ACTIVATION            // 激活账号
	TUIA_SUBTYPE_LOGIN                 // 登录账号
	TUIA_SUBTYPE_PAID                  // 用户付费

)

type TuiAResp struct {
	Redesc string `json:"redesc"`
	Record string `json:"record"`
	AOld   string `json:"a_old"`
}

// 推啊上报
func (m TuiACallbackReq) Send(key string, config string) {
	req := make(map[string][]string)
	req["a_oId"] = []string{m.TuiAId}
	req["advertKey"] = []string{config}
	req["subType"] = []string{strconv.Itoa(TUIA_SUBTYPE_START)}
	var err error
	var resp *http.Response
	for i := 0; i < 3; i++ {
		resp, err = utils.HttpGet(SEND_URL, req, nil)
		if err != nil {
			utils.LogErrorF("第[%d]次上报到[%s]失败,err:%s", i+1, SEND_URL, err.Error())
			time.Sleep(time.Duration(5*(i+1)) * time.Second)
		} else {
			break
		}
	}
	if err != nil {
		utils.LogErrorF("上报推啊[%s]到[%s]失败,err:%s", SEND_URL, err.Error())
		return
	}

	response, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return
	}
	var responseData TuiAResp
	err = json.Unmarshal(response, &responseData)
	if err != nil {
		return
	}
	utils.LogInfoF("上报推啊成功，id：%s", m.TuiAId)
	err = m.Del(key)
	if err != nil {
		utils.LogErrorF("移除无效channel信息失败，推啊id：%s", m.TuiAId)
	}
	return
}
