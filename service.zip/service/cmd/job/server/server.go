/**
 * @Author: 陈建君
 * @Date: 2021/6/8 2:55 下午
 * @Description: job server
 */

package server

import (
	"context"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"

	"gamers/utils"
	"gamers/v2/pkg/serverman"
)

type job struct {
	server *http.Server
}

func New() *job {
	return &job{}
}

func (b *job) Serve() (err error) {
	if utils.FuncEnv() {
		gin.SetMode(gin.ReleaseMode)
	}
	engine := gin.Default()

	// 保活路由
	engine.GET("/livez", func(c *gin.Context) {
		c.String(http.StatusOK, utils.Config.App.Name+" success!")
	})

	b.server = &http.Server{
		Addr:         utils.Config.Job.Host,
		Handler:      engine,
		ReadTimeout:  time.Duration(60) * time.Second,
		WriteTimeout: time.Duration(60) * time.Second,
	}

	err = b.server.ListenAndServe()
	if err != nil {
		return err
	}

	return err
}

func (b *job) Stop() (err error) {
	ctx, cancel := context.WithTimeout(&serverman.ShutdownContext{Chan: nil}, 15*time.Second)
	defer cancel()
	b.server.Shutdown(ctx)
	return
}
