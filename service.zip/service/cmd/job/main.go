package main

import (
	"flag"
	"log"

	"github.com/robfig/cron"

	"gamers/cmd/job/server"
	"gamers/utils"
	v2Job "gamers/v2/job"
	"gamers/v2/pkg/serverman"
)

var configFile = flag.String("f", "./etc/config.yaml", "the config file")

// func init() {
// 	// 加载配置
// 	utils.ConfigInit(configFile)
// 	// 初始化日志
// 	utils.LoggerInit()
//
// 	utils.GDBInit()
// 	// utils.ESInit()
// 	utils.RedisInit()
// 	// utils.KafkaInitProducer()
// 	// utils.RabbitMQInit()
// }

//
// var wg sync.WaitGroup
// cronSignal := make(chan struct{}, 1)
// // 捕获 ctrl + c 和 kill -9，方便注册 ws 的服务进行清理服务
// signalChan := make(chan os.Signal, 1)
// signal.Notify(signalChan, syscall.SIGINT, syscall.SIGTERM)
//
// wg.Add(1)
//
// // 关闭 cron 定时任务协程
// go func() {
// 	v2Job.Main(signalChan, cronSignal)
// 	cron.NewCron(signalChan, cronSignal)
// 	wg.Done()
// }()
//
// go webServer(cronSignal)
//
// wg.Wait()

func main() {
	// 加载配置
	utils.ConfigInit(configFile)
	// // 初始化日志
	// utils.LoggerInit()
	//
	// utils.GDBInit()
	// // utils.ESInit()
	// utils.RedisInit()
	//
	cron := cron.New()
	// 开启定时任务
	v2Job.Main(cron)
	cron.Start()
	defer cron.Stop()

	serverman.RegisterServer(server.New())
	err := serverman.Start()
	if err != nil {
		log.Fatal(err)
	}
}
