package main

//
// import (
// 	"fmt"
// 	"gamers/mq/kafkaConsumer"
// 	"gamers/mq/rabbitmqConsumer"
// 	"gamers/routers"
// 	"gamers/utils"
// 	"net/http"
// 	"os"
// 	"os/signal"
// 	"syscall"
// 	"time"
//
// 	"github.com/gin-gonic/gin"
//
// 	"github.com/Shopify/sarama"
// )
//
// const (
// 	CONSUMER_StateChange     = "StateChange"     // 状态改变之后回调
// 	CONSUMER_GIFT            = "GIFT"            // 礼物topic
// 	CONSUMER_PAY_CALLBACK    = "PayCallback"     // 支付回调
// 	CONSUMER_HEADLINE_MSG    = "HeadlineMsg"     // 支付回调
// 	CONSUMER_VIP             = "VIP"             // VIP消费者
// 	CONSUMER_MSG_PUSH        = "MsgPushRefactor" // 临时修改消息推送topic
// 	CONSUMER_WEEK_STAR_TOPIC = "WeekStarTopic"   // 周星榜 定时结算 消费者
// 	CONSUMER_ROOM_PK         = "RoomPK"          // 房间pk消费者
// )
//
// func init() {
// 	conf := os.Getenv("GIN_CONFIG")
// 	if conf == "" {
// 		conf = "test"
// 	}
// 	// 配置文件初始化
// 	utils.ConfigInit(conf)
// 	// 初始化日志
// 	utils.LoggerInit()
// 	// 建立连接池
// 	CreatePool()
// 	go webServer()
// }
//
// func webServer() {
// 	engine := gin.Default()
// 	router := routers.LivezRouterInit(engine, utils.Config.Consumer.Name)
// 	server := &http.Server{
// 		Addr:         utils.Config.Consumer.Port,
// 		Handler:      router,
// 		ReadTimeout:  time.Duration(utils.Config.App.ReadTimeout) * time.Second,
// 		WriteTimeout: time.Duration(utils.Config.App.WriteTimeout) * time.Second,
// 	}
// 	// 服务连接
// 	if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
// 		utils.Logger.Panic(fmt.Sprintf(utils.Config.Consumer.Name+" server listen: %s\n", err))
// 	}
// }
//
// func KafkaConsumeMsg(condition string, handleF func(message *sarama.ConsumerMessage)) (Opt *utils.MqOption) {
// 	Opt = &utils.MqOption{
// 		Host:         []string{utils.Config.Kafka.Host},
// 		Topic:        []string{condition},
// 		GroupId:      condition,
// 		SendRetryMax: 5,
// 		Stop:         make(chan struct{}, 1),
// 	}
// 	go utils.KafkaConsumeMsg(Opt, handleF)
// 	return
// }
//
// func main() {
// 	// Kafka消费者
// 	// 捕获 ctrl + c 和 kill -9，方便注册 ws 的服务进行清理服务
// 	signalChan := make(chan os.Signal, 1)
// 	signal.Notify(signalChan, syscall.SIGINT, syscall.SIGTERM)
//
// 	logOpt := &utils.MqOption{}
// 	if utils.Config.App.LogType == "kafka" {
// 		// 程序日志消费到es
// 		logOpt = KafkaConsumeMsg(utils.Config.App.LogName, kafkaConsumer.Logger)
// 	}
// 	// 礼物日志消费到es
// 	giftOpt := KafkaConsumeMsg(CONSUMER_GIFT, kafkaConsumer.GiftConsumer)
// 	// 消息推送消费者
// 	msgPushOpt := KafkaConsumeMsg(CONSUMER_MSG_PUSH, kafkaConsumer.MsgPush)
// 	// 状态变更回调
// 	StateChangeOpt := KafkaConsumeMsg(CONSUMER_StateChange, kafkaConsumer.IMStateChange)
// 	// vip信息
// 	vipOpt := KafkaConsumeMsg(CONSUMER_VIP, kafkaConsumer.VipConsumer)
// 	// 支付回调
// 	payOpt := KafkaConsumeMsg(CONSUMER_PAY_CALLBACK, kafkaConsumer.PayCallback)
// 	// headline
// 	headlineOpt := KafkaConsumeMsg(CONSUMER_HEADLINE_MSG, kafkaConsumer.HeadlineConsumer)
// 	// 处理周星榜
// 	weekStarOpt := KafkaConsumeMsg(CONSUMER_WEEK_STAR_TOPIC, kafkaConsumer.ConsumeWeekStarSettle)
// 	// 处理房间pk
// 	roomPKOpt := KafkaConsumeMsg(CONSUMER_ROOM_PK, kafkaConsumer.RoomPkConsumer)
//
// 	// RabbitMQ消费者
// 	go utils.RabbitMQConsumerDelayed(utils.RABBITMQ_SKILL_ORDER, rabbitmqConsumer.SkillOrderHandle)
// 	go utils.RabbitMQConsumerDelayed(utils.RABBITMQ_SKILL_ORDER_APPEAL, rabbitmqConsumer.SkillOrderAppealHandler)
// 	go utils.RabbitMQConsumerDelayed(utils.RABBITMQ_SKILL_ORDER_VMS, rabbitmqConsumer.SkillOrderVmsHandler)
// 	go utils.RabbitMQConsumerDelayed(utils.RABBITMQ_CLOSE_ROOM, rabbitmqConsumer.CloseRoom)
// 	go utils.RabbitMQConsumerDelayed(utils.RABBITMQ_IM_STATE_CHANGE, rabbitmqConsumer.IMStateChange)
// 	go utils.RabbitMQConsumerDelayed(utils.RABBITMOQ_INVITE_MESSAGE, rabbitmqConsumer.InviteMessageSend)
// 	go utils.RabbitMQConsumerDelayed(utils.RABBITMQ_MATCHING_CANCEL, rabbitmqConsumer.MatchingCancel)
// 	// go utils.RabbitMQConsumerDelayed("test_delay", rabbitmqConsumer.TestDelay)
// 	defer func() {
// 		if r := recover(); r != nil {
// 			utils.LogErrorF("消费者异常：", r.(string))
// 		}
// 		return
// 	}()
// 	<-signalChan
//
// 	if utils.Config.App.LogType == "kafka" && logOpt != nil {
// 		logOpt.Stop <- struct{}{}
// 	}
//
// 	giftOpt.Stop <- struct{}{}
// 	vipOpt.Stop <- struct{}{}
// 	msgPushOpt.Stop <- struct{}{}
// 	StateChangeOpt.Stop <- struct{}{}
// 	headlineOpt.Stop <- struct{}{}
// 	payOpt.Stop <- struct{}{}
// 	weekStarOpt.Stop <- struct{}{}
// 	roomPKOpt.Stop <- struct{}{}
// 	time.Sleep(1 * time.Second)
// }
//
// // CreatePool 创建连接池
// func CreatePool() {
// 	utils.GDBInit()
// 	utils.ESInit()
// 	utils.KafkaInitProducer()
// 	utils.RedisInit()
// 	utils.RabbitMQInit()
// }
