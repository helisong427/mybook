package main

import (
	"flag"
	"fmt"
	"log"
	"os"

	"gamers/cmd/service/server"
	"gamers/utils"
	"gamers/v2/boot"
	"gamers/v2/global"
	"gamers/v2/pkg/serverman"
)

var configFile = flag.String("f", "./etc/config.yaml", "the config file")

//
// func init() {
// 	// 加载配置
// 	utils.ConfigInit(configFile)
//
// 	// conf := os.Getenv("GIN_CONFIG")
// 	// if conf == "" {
// 	// 	conf = "debug"
// 	// }
// 	// // 配置文件初始化
// 	// utils.ConfigInit(conf)
// 	// // 初始化日志
// 	utils.LoggerInit()
//
// 	// 重构模块初始化
// 	boot.Bootstrap()
//
// 	utils.GDBInit()
// 	// utils.ESInit()
// 	// utils.KafkaInitProducer()
// 	utils.RedisInit()
// 	// utils.RabbitMQInit()
//
// 	// 初始化推送
// 	// InitIm(conf) // 现在的系统已经初始化，无需每次检查
//
// 	utils.InitSingLefLight()
// }

//
// func startServer(engine *gin.Engine, address string, processed chan struct{}) (err error) {
// 	server := &http.Server{
// 		Addr:         address,
// 		Handler:      engine,
// 		ReadTimeout:  time.Duration(60) * time.Second,
// 		WriteTimeout: time.Duration(60) * time.Second,
// 	}
//
// 	go func() {
// 		// 启动信号量
// 		c := make(chan os.Signal, 1)
// 		// 收到ctrl C阻断信号才释放继续执行
// 		signal.Notify(c, os.Interrupt)
// 		<-c
//
// 		// ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
// 		ctx, cancel := context.WithTimeout(&ShutdownContext{Chan: nil}, 3*time.Second)
// 		defer cancel()
//
// 		if err := server.Shutdown(ctx); err != nil {
// 			log.Fatalf("server shutdown failed, err: %v\n", err)
// 		}
// 		close(processed)
// 	}()
//
// 	fmt.Println("|-----------------------------------|")
// 	fmt.Println("|            frontend-service       |")
// 	fmt.Println("|-----------------------------------|")
// 	fmt.Println("|  Go Http Server Start Successful  |")
// 	fmt.Println("|       Port:" + utils.Config.App.Host + "    Pid:" + fmt.Sprintf("%d", os.Getpid()) + "    |")
// 	fmt.Println("|-----------------------------------|")
//
// 	err = server.ListenAndServe()
// 	if http.ErrServerClosed != err {
// 		err = errors.New(fmt.Sprintf("server not gracefully shutdown, err :%v", err))
// 	}
//
// 	return
// }
//
// // CreatePool 创建连接池
// func CreatePool() {
// 	utils.GDBInit()
// 	// utils.ESInit()
// 	// utils.KafkaInitProducer()
// 	utils.RedisInit()
// 	// utils.RabbitMQInit()
// }
//
// type InitImInfo struct {
// 	InteractiveId   string `json:"interactive_id"`
// 	InteractiveName string `json:"interactive_name"`
// 	InteractiveIcon string `json:"interactive_icon"`
// 	AssistantId     string `json:"assistant_id"`
// 	AssistantName   string `json:"assistant_name"`
// 	AssistantIcon   string `json:"assistant_icon"`
// 	OrderId         string `json:"order_id"`
// 	OrderName       string `json:"order_name"`
// 	OrderIcon       string `json:"order_icon"`
// 	Init            int    `json:"init"`
// }
//
// // im初始化
// func InitIm(conf string) {
// 	param, err := models.NewParamModel().GetByKey(global.ParamKeyImInit)
// 	if err != nil {
// 		panic(err)
// 	}
//
// 	var form InitImInfo
// 	err = json.Unmarshal([]byte(param.ParamValue), &form)
// 	if err != nil {
// 		panic(err)
// 		return
// 	}
// 	if form.Init == 1 {
// 		return
// 	}
// 	update := true
// 	_, err = tencentIm.PortraitManagerSet(form.OrderId, form.OrderName, form.OrderIcon)
// 	if err != nil {
// 		update = false
// 	}
// 	_, err = tencentIm.PortraitManagerSet(form.AssistantId, form.AssistantName, form.AssistantIcon)
// 	if err != nil {
// 		update = false
// 	}
// 	_, err = tencentIm.PortraitManagerSet(form.InteractiveId, form.InteractiveName, form.InteractiveIcon)
// 	if err != nil {
// 		update = false
// 	}
// 	err = tencentIm.InitAppAttr()
// 	if err != nil {
// 		update = false
// 		// 测试环境和正式环境这里需要panic
// 		if conf == "test" || conf == "release" {
// 			panic(err)
// 			return
// 		}
// 	}
// 	if update {
// 		form.Init = 1
// 		data, _ := json.Marshal(&form)
//
// 		param.ParamValue = string(data)
// 		err = models.NewParamModel().Update(*param)
// 		if err != nil {
// 			panic(err)
// 		}
// 	}
//
// 	return
// }
//
// // 实现 context.Context 接口
// // Deadline() (deadline time.Time, ok bool)
// // Done() <-chan struct{}
// // Err() error
// // Value(key interface{}) interface{}
// // 让 http 优雅退出(graceful)
// type ShutdownContext struct {
// 	Chan         chan struct{}
// 	DeadLineTime time.Time
// }
//
// func (s *ShutdownContext) Deadline() (deadline time.Time, ok bool) {
// 	deadline = s.DeadLineTime
// 	ok = true
// 	return
// }
//
// func (s *ShutdownContext) Done() <-chan struct{} {
// 	return s.Chan
// }
//
// func (s *ShutdownContext) Err() error {
// 	return nil
// }
//
// func (s *ShutdownContext) Value(key interface{}) interface{} {
// 	return nil
// }

func main() {
	// 加载配置
	utils.ConfigInit(configFile)
	// 初始化日志
	utils.LoggerInit()
	// 重构模块初始化
	boot.Bootstrap(false)

	utils.GDBInit()
	// utils.ESInit()
	// utils.KafkaInitProducer()
	utils.RedisInit()
	utils.InitSingLefLight()

	global.LogInfo("程序启动", "Port"+utils.Config.App.Host, " Pid:"+fmt.Sprintf("%d", os.Getpid()))
	serverman.RegisterServer(server.New())
	err := serverman.Start()
	if err != nil {
		log.Fatal(err)
	}
}
