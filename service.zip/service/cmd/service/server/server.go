/**
 * @Author: 陈建君
 * @Date: 2021/6/8 3:18 下午
 * @Description: gogo server
 */

package server

import (
	"context"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"

	"gamers/middleware"
	"gamers/utils"
	v2 "gamers/v2"
	"gamers/v2/pkg/serverman"
)

type gogo struct {
	server *http.Server
}

func New() *gogo {
	return &gogo{}
}

func (b *gogo) Serve() (err error) {
	if utils.Config.App.Env != "debug" {
		gin.SetMode(gin.ReleaseMode)
		// 禁止gin的输出
		// gin.DefaultWriter = ioutil.Discard
	}
	engine := gin.Default()

	// 跨域
	engine.Use(middleware.Cors())
	// 捕获异常
	engine.Use(middleware.Recovery())

	// 设置路由
	// routers.RouterInit(engine)
	// 重构路由
	v2.Main(engine)

	b.server = &http.Server{
		Addr:         utils.Config.App.Host,
		Handler:      engine,
		ReadTimeout:  time.Duration(60) * time.Second,
		WriteTimeout: time.Duration(60) * time.Second,
	}

	err = b.server.ListenAndServe()
	if err != nil {
		return err
	}

	return err
}

func (b *gogo) Stop() (err error) {
	ctx, cancel := context.WithTimeout(&serverman.ShutdownContext{Chan: nil}, 15*time.Second)
	defer cancel()
	return b.server.Shutdown(ctx)
}
