/**
 * @Author: 何玉峰
 * @Date: 2021/6/11 下午4:15
 * @Description: TODO:描述
 */
package script_test

import (
	"fmt"
	"os"
	"testing"

	"gamers/cmd/migrate/script"
)

func TestMigrateRoomCache(t *testing.T) {
	dir, _ := os.Getwd()
	fmt.Println("当前路径：", dir)
	script.MigrateRoomCache(dir+"/../../../etc/config.yaml", dir+"/../../../etc/old-redis-config.yaml")
}
