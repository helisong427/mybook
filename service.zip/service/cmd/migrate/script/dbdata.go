/**
 * @Author: wanglin
 * @Author: wanglin@vspn.com
 * @Date: 2021/6/23 16:48
 * @Desc: 迁移数据库数据
 */

package script

import (
	"log"

	"gamers/v2/global"
)

func MigrateDbData() {
	sqls := []string{
		"UPDATE `app_msg_model` SET `msg_content` = '由于您超过12小时未处理用户的退款申请，系统已自动判定用户退款成功。金额：${order_amount}GO币' WHERE `msg_key` = 'c2c_order_sparring_refund_ok_system';",
	}

	for i, sql := range sqls {
		if _, err := global.SqlConn.Exec(sql); err != nil {
			log.Printf("执行%v号SQL迁移失败：%v", i, err.Error())
		}
	}
}
