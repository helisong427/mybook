/**
 * @Author: wanglin
 * @Author: wanglin@vspn.com
 * @Date: 2021/6/7 14:22
 * @Desc: 迁移数据库数据结构
 */

package script

import (
	"log"
	"sync"

	"gamers/v2/global"
)

// MigrateDbStructure 迁移数据结构
func MigrateDbStructure() {
	sqls := map[string][]string{
		"app_certification": {
			"ALTER TABLE `app_certification` DROP PRIMARY KEY;",
			"ALTER TABLE `app_certification` ADD `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '记录id' FIRST, ADD PRIMARY KEY (`id`);",
			"CREATE UNIQUE INDEX `idx_certification_id` ON `app_certification` (`certification_id`) USING BTREE;",
		},
		"app_user_wallet": {
			"ALTER TABLE `app_user_wallet` DROP PRIMARY KEY;",
			"ALTER TABLE `app_user_wallet` ADD `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '记录id' FIRST, ADD PRIMARY KEY (`id`);",
			"CREATE UNIQUE INDEX `idx_wallet_user_id` ON `app_user_wallet` (`wallet_user_id`) USING BTREE;",
		},
		"app_user_vip_experience": {
			"ALTER TABLE `app_user_vip_experience` DROP PRIMARY KEY;",
			"ALTER TABLE `app_user_vip_experience` ADD `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '记录id' FIRST, ADD PRIMARY KEY (`id`);",
			"CREATE UNIQUE INDEX `idx_experience_user_id` ON `app_user_vip_experience` (`experience_user_id`) USING BTREE;",
		},
		"app_msg_model": {
			"CREATE UNIQUE INDEX `idx_msg_key` ON `app_msg_model` (`msg_key`) USING BTREE;",
		},
		"app_union_withdrawal_balance": {},
		"app_attention": {
			"DELETE FROM `app_attention` WHERE `deleted` > 0;",
			"CREATE UNIQUE INDEX `idx_balance_union_id` ON `app_attention` (`attention_user_id`,`attention_follow_user_id`) USING BTREE;",
		},
		"app_idcard_withdrawal": {
			"ALTER TABLE `app_idcard_withdrawal` ADD UNIQUE INDEX `idx_idcard_month_channel`(`withdrawal_month`, `withdrawal_channel_id`, `withdrawal_idcard`) USING BTREE;",
		},
		"app_tweet_user": {
			"DELETE FROM `app_tweet_user` WHERE `user_id` IN (SELECT a.user_id FROM (SELECT `user_id` FROM `app_tweet_user` WHERE `user_user_id` IN (SELECT `user_user_id` FROM `app_tweet_user` GROUP BY `user_tweet_id`,`user_user_id` HAVING count( * ) > 1) AND `user_tweet_id` IN (SELECT `user_tweet_id` FROM `app_tweet_user` GROUP BY `user_tweet_id`,`user_user_id` HAVING count( * ) > 1 ) LIMIT 1,1000) AS a);",
			"ALTER TABLE `app_tweet_user` DROP INDEX `tweet_key`,ADD UNIQUE INDEX `uq_tweet_id_user_id`(`user_tweet_id`, `user_user_id`) USING BTREE;",
		},
		"app_tweet_comment_user": {
			"DELETE FROM `app_tweet_comment_user` WHERE `user_id` IN (SELECT a.user_id FROM (SELECT `user_id` FROM `app_tweet_comment_user` WHERE `user_user_id` IN (SELECT `user_user_id` FROM `app_tweet_comment_user` GROUP BY `user_comment_id`,`user_user_id` HAVING count(*) > 1 ) AND `user_comment_id` IN (SELECT `user_comment_id` FROM `app_tweet_comment_user` GROUP BY `user_comment_id`, `user_user_id` HAVING count(*) > 1) LIMIT 1,1000) AS a);",
			"ALTER TABLE `app_tweet_comment_user` ADD UNIQUE INDEX `uq_comment_id_user_id`(`user_comment_id`, `user_user_id`) USING BTREE;",
		},
		"app_skill_order_speed_matching": {
			"ALTER TABLE app_skill_order_speed_matching MODIFY matching_order_id BIGINT unsigned NOT NULL DEFAULT '0' COMMENT '订单id';",
			"ALTER TABLE app_skill_order_speed_matching MODIFY matching_user_id BIGINT unsigned NOT NULL DEFAULT '0' COMMENT '订单用户id';",
			"ALTER TABLE app_skill_order_speed_matching MODIFY matching_sparring_user_id BIGINT unsigned NOT NULL DEFAULT '0' COMMENT '订单用户id';",
		},
		"app_backpack_log": {
			"ALTER TABLE `app_backpack_log` MODIFY `log_type_id` bigint(20) unsigned NOT NULL DEFAULT 0 COMMENT '交易关联表的id';",
		},
		"app_recommend_intervention": {
			"ALTER TABLE `app_recommend_intervention` MODIFY `intervention_content_user_id` BIGINT unsigned NOT NULL DEFAULT '0' COMMENT '用户ID';",
		},
		"system_sensitive_word": {
			"CREATE TABLE `system_sensitive_word` (`word_id` int(10) unsigned NOT NULL AUTO_INCREMENT,`word_text` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '敏感词文字',`created` int(10) unsigned NOT NULL COMMENT '创建时间',`edited` int(10) unsigned NOT NULL COMMENT '修改时间',`deleted` int(10) unsigned NOT NULL COMMENT '删除时间',PRIMARY KEY (`word_id`) USING BTREE,KEY `text_idx` (`word_text`) USING BTREE) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
		},
		"app_skill_order_comment": {
			"ALTER TABLE `app_skill_order_comment` MODIFY `comment_order_id` BIGINT unsigned NOT NULL DEFAULT '0' COMMENT '订单id';",
			"ALTER TABLE `app_skill_order_comment` MODIFY `comment_order_user_id` BIGINT unsigned NOT NULL DEFAULT '0' COMMENT '订单用户id';",
			"ALTER TABLE `app_skill_order_comment` MODIFY `comment_sparring_id` BIGINT unsigned NOT NULL DEFAULT '0' COMMENT '大神id';",
		},
		"app_union": {
			"CREATE UNIQUE INDEX `uq_union_invite_key` ON `app_union` (`union_invite_key`) USING BTREE;",
		},
		"system_user_privacy_setting": {
			"CREATE UNIQUE INDEX `idx_user_id` ON `system_user_privacy_setting` (`user_id`) USING BTREE;",
		},
		"app_first_charge": {
			"CREATE UNIQUE INDEX `idx_charge_prop_id` ON `app_first_charge` (`charge_prop_id`) USING BTREE;",
		},
	}

	exec(sqls)
}

// 执行迁移
func exec(sqls map[string][]string) {
	var wg sync.WaitGroup

	wg.Add(len(sqls))

	for table, group := range sqls {
		go func(table string, group []string) {
			for _, sql := range group {
				if _, err := global.SqlConn.Exec(sql); err != nil {
					log.Printf("执行%v表迁移失败：%v", table, err.Error())
				}
			}

			wg.Done()
		}(table, group)
	}

	wg.Wait()
}
