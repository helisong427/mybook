/**
 * @Author: wanglin
 * @Author: wanglin@vspn.com
 * @Date: 2021/6/7 14:15
 * @Desc: 迁移装扮
 */

package script

import (
	"encoding/json"
	"fmt"
	"log"
	"strings"
	"sync"
	"time"

	"github.com/tal-tech/go-zero/core/stores/redis"

	"gamers/models/redismodels"
	"gamers/utils"
	"gamers/v2/global"
)

type Dress struct {
	Id       int64  `json:"id"`
	Type     int64  `json:"type"`
	Url      string `json:"url"`
	Url1     string `json:"url1"`
	ExpireAt int64  `json:"expire"`
}

func MigrateDress() {
	var wg sync.WaitGroup

	wg.Add(3)

	go func() {
		migrateAvatar()
		wg.Done()
	}()

	go func() {
		migrateChat()
		wg.Done()
	}()

	go func() {
		migrateCar()
		wg.Done()
	}()

	wg.Wait()
}

func migrateAvatar() {
	var (
		dressType = global.DbPropTypeTypeAvatar
		dressKey  = utils.REDIS_USER_ICON_INFO
		dressName = "头像框"
		style     redismodels.IconStyle
	)

	keys, err := global.Redis.Keys(fmt.Sprintf("%s%s", dressKey, "*"))
	if err != nil && err != redis.Nil {
		log.Printf("批量获取原始%s失败：%v", "头像框", err.Error())
	} else {
		var wg sync.WaitGroup

		wg.Add(len(keys))

		for _, key := range keys {
			go func(key string) {
				userId := strings.Split(key, ":")[1]

				if val, err := global.Redis.Get(key); err != nil {
					log.Printf("获取用户%v%s失败：%v", userId, dressName, err.Error())
				} else {
					if err = json.Unmarshal([]byte(val), &style); err != nil {
						log.Printf("解析用户%v%s失败：%v", userId, dressName, err.Error())
					} else {
						if expire := int(time.Now().Unix() - style.EndT); expire > 0 {
							if str, err := json.Marshal(Dress{
								Id:       style.IconId,
								Type:     int64(dressType),
								Url:      style.BgUrl,
								ExpireAt: style.EndT,
							}); err != nil {
								log.Printf("序列化用户%v%s失败：%v", userId, dressName, err.Error())
							} else {
								err := global.Redis.Setex(fmt.Sprintf("gogo:user:dress:%s:%v", userId, dressType), string(str), expire)
								if err != nil {
									log.Printf("转存用户%v%s失败：%v", userId, dressName, err.Error())
								}
							}
						}
					}
				}

				wg.Done()
			}(key)
		}

		wg.Wait()
	}
}

func migrateChat() {
	var (
		dressType = global.DbPropTypeTypeChat
		dressKey  = utils.REDIS_USER_CHAT_INFO
		dressName = "聊天框"
		style     redismodels.ChatStyle
	)

	keys, err := global.Redis.Keys(fmt.Sprintf("%s%s", dressKey, "*"))
	if err != nil && err != redis.Nil {
		log.Printf("批量获取原始%s失败：%v", "头像框", err.Error())
	} else {
		var wg sync.WaitGroup

		wg.Add(len(keys))

		for _, key := range keys {
			go func(key string) {
				userId := strings.Split(key, ":")[1]

				if val, err := global.Redis.Get(key); err != nil {
					log.Printf("获取用户%v%s失败：%v", userId, dressName, err.Error())
				} else {
					if err = json.Unmarshal([]byte(val), &style); err != nil {
						log.Printf("解析用户%v%s失败：%v", userId, dressName, err.Error())
					} else {
						if expire := int(time.Now().Unix() - style.EndT); expire > 0 {
							if str, err := json.Marshal(Dress{
								Id:       style.ChatId,
								Type:     int64(dressType),
								Url:      style.BgUrl,
								ExpireAt: style.EndT,
							}); err != nil {
								log.Printf("序列化用户%v%s失败：%v", userId, dressName, err.Error())
							} else {
								err := global.Redis.Setex(fmt.Sprintf("gogo:user:dress:%s:%v", userId, dressType), string(str), expire)
								if err != nil {
									log.Printf("转存用户%v%s失败：%v", userId, dressName, err.Error())
								}
							}
						}
					}
				}

				wg.Done()
			}(key)
		}

		wg.Wait()
	}
}

func migrateCar() {
	var (
		dressType = global.DbPropTypeTypeCar
		dressKey  = utils.REDIS_USER_COME_IN_INFO
		dressName = "座驾"
		style     redismodels.ComeInStyle
	)

	keys, err := global.Redis.Keys(fmt.Sprintf("%s%s", dressKey, "*"))
	if err != nil && err != redis.Nil {
		log.Printf("批量获取原始%s失败：%v", "头像框", err.Error())
	} else {
		var wg sync.WaitGroup

		wg.Add(len(keys))

		for _, key := range keys {
			go func(key string) {
				userId := strings.Split(key, ":")[1]

				if val, err := global.Redis.Get(key); err != nil {
					log.Printf("获取用户%v%s失败：%v", userId, dressName, err.Error())
				} else {
					if err = json.Unmarshal([]byte(val), &style); err != nil {
						log.Printf("解析用户%v%s失败：%v", userId, dressName, err.Error())
					} else {
						if expire := int(time.Now().Unix() - style.EndT); expire > 0 {
							if str, err := json.Marshal(Dress{
								Id:       style.ComeInId,
								Type:     int64(dressType),
								Url:      style.BgUrl,
								Url1:     style.PetUrl,
								ExpireAt: style.EndT,
							}); err != nil {
								log.Printf("序列化用户%v%s失败：%v", userId, dressName, err.Error())
							} else {
								err := global.Redis.Setex(fmt.Sprintf("gogo:user:dress:%s:%v", userId, dressType), string(str), expire)
								if err != nil {
									log.Printf("转存用户%v%s失败：%v", userId, dressName, err.Error())
								}
							}
						}
					}
				}

				wg.Done()
			}(key)
		}

		wg.Wait()
	}
}
