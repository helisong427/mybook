/**
 * @Author: 何玉峰
 * @Date: 2021/6/11 下午3:38
 * @Description: TODO:描述
 */
package script

import (
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"strconv"
	"strings"
	"time"

	jsoniter "github.com/json-iterator/go"
	"github.com/tal-tech/go-zero/core/conf"
	"github.com/tal-tech/go-zero/core/stores/cache"
	"github.com/tal-tech/go-zero/core/stores/redis"
	"github.com/tal-tech/go-zero/core/stores/sqlx"

	"gamers/v2/global"
)

var (
	oldRedis, newRedis *redis.Redis
	sqlConn            sqlx.SqlConn
	isDownKey          = "gogo:migrate:room"
	migrateRoomLock    = "gogo:migrate:lock"
)

const (
	MigrateRoomStatusInit    = "init"
	MigrateRoomStatusFailed  = "failed"
	MigrateRoomStatusSuccess = "success"
)

type (
	RoomInfo struct {
		WheatLoveSwitch int `json:"wheat_love_switch"` // 爱意值开关 备注：之后移动数据库
		WheatNum        int `json:"wheat_num"`         // 麦位个数
		Status          int `json:"-"`                 // 0 只存在redis中，1 只存在数据库中， 2 两者都在
	}

	WheatBitInfo struct {
		UserId     int64 `json:"user_id"`     // 用户id
		Status     int   `json:"status"`      // 麦位状态：0--正常，1--上锁，2--禁麦
		UpdateTime int64 `json:"update_time"` // 更新时间
	}

	ForbiddenInfo struct {
		UserId    int64 `json:"-"`
		AdminId   int64 `json:"admin_id"`
		BeginTime int64 `json:"begin_time"`
	}

	KickOutInfo struct {
		UserId    int64 `json:"user_id"`
		AdminId   int64 `json:"admin_id"`
		BeginTime int64 `json:"begin_time"`
		EndTime   int64 `json:"end_time"`
	}

	MuteInfo struct {
		UserId    int64 `json:"user_id"`
		AdminId   int64 `json:"admin_id"`
		BeginTime int64 `json:"begin_time"`
		EndTime   int64 `json:"end_time"`
	}
)
type QueryRoom struct {
	RoomId        int64 `json:"room_id"`
	RoomType      int64 `json:"room_type"`
	RoomSpeakType int64 `json:"room_speak_type"`
}

type Config struct {
	CacheRedis cache.ClusterConf
	Mysql      struct {
		DataSource string
	}
}

type OldRedisConfig struct {
	CacheRedis cache.ClusterConf
}

func roomPanicf(format string, v ...interface{}) {
	log.Panicf("migrate:room："+format, v...)
}

func Init(configFile, oldRedisConfigFile string) error {
	config := &Config{}
	conf.MustLoad(configFile, config)

	sqlConn = sqlx.NewMysql(config.Mysql.DataSource)

	newRedis = cache.CacheConf{
		cache.NodeConf{
			RedisConf: redis.RedisConf{
				Host: config.CacheRedis[0].Host,
				Type: config.CacheRedis[0].Type,
				Pass: config.CacheRedis[0].Pass,
			},
			Weight: 100,
		},
	}[0].NewRedis()
	ok := newRedis.Ping()
	if !ok {
		return errors.New("链接newRedis失败， Host: " + config.CacheRedis[0].Host)
	}

	oldRedisConfig := &OldRedisConfig{}
	conf.MustLoad(oldRedisConfigFile, oldRedisConfig)

	oldRedis = cache.CacheConf{
		cache.NodeConf{
			RedisConf: redis.RedisConf{
				Host: oldRedisConfig.CacheRedis[0].Host,
				Type: oldRedisConfig.CacheRedis[0].Type,
				Pass: oldRedisConfig.CacheRedis[0].Pass,
			},
			Weight: 100,
		},
	}[0].NewRedis()

	ok = oldRedis.Ping()
	if !ok {
		return errors.New("链接oldRedis失败， Host: " + config.CacheRedis[0].Host)
	}

	return nil
}

func MigrateForbiddenInfo() error {
	// 获取拉黑信息
	val, err := oldRedis.Keys("liveForBiden:*")
	if err != nil {
		return errors.New("拉黑、踢人 redis操作异常：" + err.Error())
	}
	for _, v := range val {
		forBiddenStr, err := oldRedis.Get(v)
		if err != nil {
			return errors.New("拉黑、踢人 redis操作异常：" + err.Error())
		}

		adminId := jsoniter.Get([]byte(forBiddenStr), "admin", "user_id").ToInt64()
		if adminId == 0 {
			return errors.New("拉黑信息错误：解析admin用户ID失败 " + v + " " + forBiddenStr)
		}
		startTime := jsoniter.Get([]byte(forBiddenStr), "start_t").ToInt64()
		if startTime == 0 {
			return errors.New("拉黑信息错误：解析start_t失败 " + v + " " + forBiddenStr)
		}

		endTime := jsoniter.Get([]byte(forBiddenStr), "end_t").ToInt64()
		if endTime == 0 {
			return errors.New("拉黑信息错误：解析end_t失败 " + v + " " + forBiddenStr)
		}

		strs := strings.Split(v, ":")
		if len(strs) != 3 {
			return errors.New("拉黑信息错误：解析redis key 失败 " + v)
		}

		roomId, err := strconv.ParseInt(strs[1], 10, 64)
		if err != nil {
			return errors.New("拉黑信息错误：解析redis key 失败 " + v)
		}
		userId, err := strconv.ParseInt(strs[2], 10, 64)
		if err != nil {
			return errors.New("拉黑信息错误：解析redis key 失败 " + v)
		}

		if endTime == -1 {
			err = setForbidden(userId, adminId, roomId, startTime)
		} else {
			expire := endTime - time.Now().Unix()
			if expire > 0 {
				err = kickOut(userId, adminId, roomId, startTime, endTime)
			}
		}

		if err != nil {
			return errors.New("拉黑、踢人 redis操作异常：" + err.Error())
		}
	}

	return nil
}

func MigrateMuteInfo() error {
	// 获取禁言信息
	val, err := oldRedis.Keys("liveMute:*")
	if err != nil {
		return errors.New("禁言 redis操作异常：" + err.Error())
	}
	for _, v := range val {
		forBiddenStr, err := oldRedis.Get(v)
		if err != nil {
			return errors.New("禁言 redis操作异常：" + err.Error())
		}

		adminId := jsoniter.Get([]byte(forBiddenStr), "admin", "user_id").ToInt64()
		if adminId == 0 {
			return errors.New("禁言信息错误：解析admin用户ID失败 " + v + " " + forBiddenStr)
		}
		startTime := jsoniter.Get([]byte(forBiddenStr), "start_t").ToInt64()
		if startTime == 0 {
			return errors.New("禁言信息错误：解析startTime失败 " + v + " " + forBiddenStr)
		}

		endTime := jsoniter.Get([]byte(forBiddenStr), "end_t").ToInt64()
		if endTime == 0 {
			return errors.New("拉黑信息错误：解析end_t失败 " + v + " " + forBiddenStr)
		}

		strs := strings.Split(v, ":")
		if len(strs) != 3 {
			return errors.New("禁言信息错误：解析redis key 失败 " + v)
		}

		roomId, err := strconv.ParseInt(strs[1], 10, 64)
		if err != nil {
			return errors.New("禁言信息错误：解析redis key 失败 " + v)
		}
		userId, err := strconv.ParseInt(strs[2], 10, 64)
		if err != nil {
			return errors.New("禁言信息错误：解析redis key 失败 " + v)
		}

		err = setMute(userId, adminId, roomId, startTime, endTime)
		if err != nil {
			return errors.New("禁言 redis操作异常：" + err.Error())
		}
	}

	return nil
}

func setRoomInfo(roomId int64, info *RoomInfo) (err error) {
	val, err := json.Marshal(info)
	if err != nil {
		return err
	}

	if info == nil {
		return errors.New("房间信息为空")
	}

	key := fmt.Sprintf("gogo:room:cache:%d", roomId)

	return newRedis.Set(key, string(val))
}

func setWheatBitInfo(roomId int64, pos int, val *WheatBitInfo) (err error) {
	key := fmt.Sprintf("gogo:room:cache:wheatBit:%d", roomId)
	field := fmt.Sprintf("%d", pos)

	if val == nil {
		err = errors.New("麦位信息不能为空")
		return
	}

	str, err := json.Marshal(val)
	if err != nil {
		return err
	}

	return newRedis.Hset(key, field, string(str))
}

// 添加拉黑用户
func setForbidden(userId, adminId, roomId, beginTime int64) (err error) {

	key := fmt.Sprintf("gogo:room:cache:forbidden:%d", roomId)
	userIdStr := strconv.FormatInt(userId, 10)

	str, err := json.Marshal(&ForbiddenInfo{
		AdminId:   adminId,
		BeginTime: beginTime,
		// EndTime:   0,
	})
	if err != nil {
		return err
	}
	err = newRedis.Hset(key, userIdStr, string(str))
	if err != nil {
		return err
	}

	return
}

func kickOut(userId, adminId, roomId int64, beginTime, endTime int64) (err error) {

	key := fmt.Sprintf("gogo:room:cache:kick:%d:%v", roomId, userId)
	str, err := json.Marshal(&KickOutInfo{
		UserId:    userId,
		AdminId:   adminId,
		BeginTime: beginTime,
		EndTime:   endTime,
	})
	if err != nil {
		return err
	}
	expireSecond := endTime - time.Now().Unix()
	return newRedis.Setex(key, string(str), int(expireSecond))
}

func setMute(userId, adminId, roomId, startTime, endTime int64) (err error) {

	key := fmt.Sprintf("gogo:room:cache:mute:%d:%v", roomId, userId)
	str, err := json.Marshal(&MuteInfo{
		UserId:    userId,
		AdminId:   adminId,
		BeginTime: startTime,
		EndTime:   endTime,
	})
	if err != nil {
		return err
	}
	second := endTime - time.Now().Unix()
	if second > 0 {
		return newRedis.Setex(key, string(str), int(second))
	}

	return nil
}

func MigrateRoomInfo() error {

	var (
		roomMap = make(map[int64]*RoomInfo)
		now     = time.Now().Unix()
	)
	// 获取爱意值开关
	val, err := oldRedis.Keys("liveWheat:*")
	if err != nil {
		return errors.New("MigrateRoomInfo redis操作异常：" + err.Error())
	}
	for _, v := range val {
		loveSwitchStr, err := oldRedis.Hget(v, "wheat_love_switch")
		if err != nil {
			return errors.New("MigrateRoomInfo redis操作异常：" + err.Error())
		}

		strs := strings.Split(v, ":")
		if len(strs) != 2 {
			return errors.New("MigrateRoomInfo：解析redis key 失败 " + v)
		}

		roomId, err := strconv.ParseInt(strs[1], 10, 64)
		if err != nil {
			return errors.New("MigrateRoomInfo：解析redis key 失败 " + v)
		}

		loveSwitch, err := strconv.Atoi(loveSwitchStr)
		if err != nil {
			return errors.New("MigrateRoomInfo：解析爱意值开关值 失败 " + loveSwitchStr)
		}
		roomMap[roomId] = &RoomInfo{
			WheatLoveSwitch: loveSwitch,
		}
	}

	var queryRoom = make([]*QueryRoom, 0, len(roomMap)+1000)

	// 查询房间数据
	err = sqlConn.QueryRows(&queryRoom, "select room_id, room_type, room_speak_type from app_live_room")
	if err != nil {
		return errors.New("MigrateRoomInfo：查询数据库 app_live_room 失败" + err.Error())
	}

	for _, v := range queryRoom {

		var wheatNum int
		if v.RoomType == global.RoomTypeLive {
			if v.RoomSpeakType == global.SpeakTypeLiveWithoutMic {
				wheatNum = global.WheatWithoutLiveNum
			} else if v.RoomSpeakType == global.SpeakTypeLiveWithMic {
				wheatNum = global.WheatLiveNum
			} else {
				fmt.Printf("MigrateRoomInfo警告1：原始内存房间数据错误，roomId=%d roomType=%d roomSpeakType=%d \n", v.RoomId, v.RoomType, v.RoomSpeakType)
			}
		} else if v.RoomType == global.RoomTypeParty {
			wheatNum = global.WheatPartyNum
		} else {
			fmt.Printf("MigrateRoomInfo警告2：原始内存房间数据错误，roomId=%d roomType=%d \n", v.RoomId, v.RoomType)
		}

		if room, ok := roomMap[v.RoomId]; ok {
			room.WheatNum = wheatNum
			room.Status = 2
		} else {
			fmt.Printf("MigrateRoomInfo警告3：redis内存中不存在数据库中的房间数据，roomId=%d \n", v.RoomId)
			roomMap[v.RoomId] = &RoomInfo{
				WheatLoveSwitch: global.WheatLoveSwitchOff, // 异常情况，爱意值开关默认关闭
				WheatNum:        wheatNum,
				Status:          1,
			}
		}
	}

	for roomId, v := range roomMap {
		if v.Status == 0 {
			fmt.Printf("MigrateRoomInfo警告4：redis内存中的房间数据，数据库中不存在，roomId=%d \n", roomId)
			continue
		}
		// 设置房间信息
		err = setRoomInfo(roomId, v)
		if err != nil {
			return errors.New("MigrateRoomInfo：设置房间信息失败" + err.Error())
		}

		// 重置麦位
		for i := 0; i < v.WheatNum; i++ {
			err = setWheatBitInfo(roomId, i, &WheatBitInfo{UpdateTime: now})
			if err != nil {
				return errors.New("MigrateRoomInfo：重置麦位信息失败" + err.Error())
			}
		}
	}

	return nil
}

func MigrateRoomCacheHandler() error {

	// 迁移拉黑、踢人信息
	err := MigrateForbiddenInfo()
	if err != nil {
		return err
	}

	// 迁移禁言信息
	err = MigrateMuteInfo()
	if err != nil {
		return err
	}

	// 迁移房间信息
	err = MigrateRoomInfo()
	if err != nil {
		return err
	}

	return nil
}

func MigrateRoomCache(configFile, oldRedisConfigFile string) {
	err := Init(configFile, oldRedisConfigFile)
	if err != nil {
		roomPanicf("初始化失败: " + err.Error())
	}

	lock, err := newRedis.SetnxEx(migrateRoomLock, "LOCKED", 6000)
	if err != nil {
		roomPanicf("redis操作异常：" + err.Error())
	}

	if !lock {
		fmt.Println("migrate:room：其他程序在执行同步，我们直接退出 。。。。")
		return
	}

	status, err := newRedis.Get(isDownKey)
	if err != nil {
		roomPanicf("redis操作异常：" + err.Error())
	}

	if status == "" {
		err = newRedis.Set(isDownKey, MigrateRoomStatusInit)
		if err != nil {
			roomPanicf("redis操作异常：" + err.Error())
		}
		status = MigrateRoomStatusInit
	}
	if status == MigrateRoomStatusSuccess {
		fmt.Println("migrate:room：已经同步完成，不再执行！！")
		return
	}

	err = MigrateRoomCacheHandler()
	if err != nil {
		err1 := newRedis.Set(isDownKey, MigrateRoomStatusFailed)
		if err1 != nil {
			roomPanicf("migrate:room：redis操作异常：" + err1.Error())
		}
		roomPanicf("migrate:room：同步失败" + err.Error())
	}

	err1 := newRedis.Set(isDownKey, MigrateRoomStatusSuccess)
	if err1 != nil {
		roomPanicf("migrate:room：redis操作异常：" + err1.Error())
	}
	fmt.Println("migrate:room：😀😀😀😀😀😀😀 同步成功 😀😀😀😀😀😀😀")
}
