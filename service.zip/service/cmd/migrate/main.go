/**
 * @Author: wanglin
 * @Author: wanglin@vspn.com
 * @Date: 2021/6/7 14:13
 * @Desc: 数据迁移脚本
 */

package main

import (
	"flag"

	"gamers/cmd/migrate/script"
	"gamers/utils"
	"gamers/v2/boot"
)

var configFile = flag.String("f", "./etc/config.yaml", "the config file")

func init() {
	// 配置文件初始化
	utils.ConfigInit(configFile)
	// 重构模块初始化
	boot.Bootstrap(false)
}

func main() {
	// 迁移数据库结构
	script.MigrateDbStructure()
	// 迁移数据库数据
	script.MigrateDbData()
	// 迁移敏感词
	script.MigrateSensitive()
	// 迁移装扮
	script.MigrateDress()

	// 房间redis内存数据迁移
	script.MigrateRoomCache(*configFile, *configFile)
}
