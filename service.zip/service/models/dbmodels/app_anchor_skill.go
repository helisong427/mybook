package dbmodels

import (
	"gamers/controller/response"
	"gamers/utils"
)

// 主播技能认证
type AppAnchorSkill struct {
	SkillID     int64     `gorm:"column:skill_id;primaryKey;autoIncrement" json:"skill_id"`
	SkillUserID int64     `gorm:"column:skill_user_id"` // 用户id
	SkillAttrId int64     `gorm:"column:skill_attr_id"`
	SkillStatus int       // 技能状态
	BaseModel   BaseModel `gorm:"embedded" json:"base_model"`
}

// TableName 会将 User 的表名重写为 `app_skill_order`
func (AppAnchorSkill) TableName() string {
	return "app_anchor_skill"
}

const (
	ANCHOR_SKILL_STATUS_INIT = iota // 认证初始状态
	ANCHOR_SKILL_STATUS_PASS        // 认证失败
	ANCHOR_SKILL_STATUS_OK          // 认证ok
)

// Create
func (m *AppAnchorSkill) Create() (err error) {
	err = utils.GEngine.Create(m).Error
	return
}

// Save
func (m *AppAnchorSkill) Save() (err error) {
	err = utils.GEngine.Save(m).Error
	return
}

// 判断是否已认证类型
func (m *AppAnchorSkill) GetAnchorByAttr(attrId int64, userId int64) (anchor AppAnchorSkill, err error) {
	err = utils.GEngine.Model(m).Where("skill_attr_id = ? and deleted = 0 and skill_user_id = ? and skill_status = ?", attrId, userId, ANCHOR_SKILL_STATUS_OK).First(&anchor).Error
	return
}

//获取主播的属性
func (m *AppAnchorSkill) GetAnchorById(userId int64) (result []response.GetRoomAttrId, err error) {
	err = utils.GEngine.Model(m).Where("skill_user_id = ? and deleted = 0", userId).Find(&result).Error
	return
}

//获取主播是否认证成功
func (m *AppAnchorSkill) VerificationByUserId(userId int64) (anchor AppAnchorSkill, err error) {
	err = utils.GEngine.Where("skill_user_id = ? and  skill_status = ? and deleted = 0", userId, ANCHOR_SKILL_STATUS_OK).First(&anchor).Error
	return
}

// 获取待审核的技能信息
func (m *AppAnchorSkill) GetCheckInfoByUserId(userId int64) (data response.GetCheckInfoResp, err error) {
	err = utils.GEngine.Model(m).Joins("inner join app_live_attr as u on skill_attr_id = u.attr_id").
		Select("u.attr_name,u.attr_id,u.attr_directions,u.attr_demand,app_anchor_skill.created").
		Where("skill_user_id = ? and  skill_status = ? and app_anchor_skill.deleted = 0", userId, ANCHOR_SKILL_STATUS_INIT).
		Order("app_anchor_skill.skill_id desc").First(&data).Error
	return
}
