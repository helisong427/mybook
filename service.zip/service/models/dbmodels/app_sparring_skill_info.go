package dbmodels

import (
	"gamers/utils"

	"gorm.io/gorm"
)

// 陪玩师技能信息表
type AppSparringSkillInfo struct {
	InfoId              int64              `gorm:"column:info_id" json:"info_id"`                               // 自增长id
	InfoSkillId         int64              `gorm:"column:info_skill_id" json:"info_skill_id"`                   // 技能id
	InfoUserId          int64              `gorm:"column:info_user_id" json:"info_user_id"`                     // 用户id
	InfoSparringSkillId int64              `gorm:"column:info_sparring_skill_id" json:"info_sparring_skill_id"` // 大神认证id
	InfoValueId         int64              `gorm:"column:info_value_id" json:"info_value_id"`                   // filed的id
	AppSkillFieldValue  AppSkillFieldValue `gorm:"foreignKey:ValueId;references:InfoValueId"`                   // 一对一关联技能字段配置表
	BaseModel           BaseModel          `gorm:"embedded" json:"base_model"`
}

func (AppSparringSkillInfo) TableName() string {
	return "app_sparring_skill_info"
}

// Create
func (m *AppSparringSkillInfo) Create() (err error) {
	err = utils.GEngine.Create(m).Error
	return
}

// 获取skillInfo记录
func (m *AppSparringSkillInfo) GetSkillInfoByUserId(userId int64, gameId, skillId int64) (result []AppSparringSkillInfo, err error) {
	err = utils.GEngine.Where("info_user_id = ? and info_sparring_skill_id= ? and info_skill_id = ?", userId, gameId, skillId).Find(&result).Error
	if err != nil {
		return nil, err
	}
	return
}

// 校验必穿的id
func (m *AppSparringSkillInfo) GetSkillInfoByUserIdAndGameId(userId int64, skillId int64) (result AppSparringSkillInfo, err error) {
	err = utils.GEngine.Model(m).Joins("INNER JOIN app_skill_field_value ON app_skill_field_value.value_id = info_value_id").
		Joins("INNER JOIN app_skill ON app_skill_field_value.value_skill_id = app_skill.skill_id").
		Where("app_sparring_skill_info.info_user_id = ? and app_sparring_skill_info.info_skill_id= ? and app_skill_field_value.value_field = app_skill.skill_required_field AND app_skill_field_value.deleted =0", userId, skillId).
		First(&result).Error
	return
}

func (m *AppSparringSkillInfo) UpdateSkillInfoByValue(tx *gorm.DB, data []AppSparringSkillInfo, del AppSparringSkillInfo) (err error) {
	// 1.删除之前的skillInfo
	err = tx.Session(&gorm.Session{AllowGlobalUpdate: true}).Where("info_id <> ? and info_user_id = ? and info_skill_id = ? and info_sparring_skill_id = ?", del.InfoId, del.InfoUserId, del.InfoSkillId, del.InfoSparringSkillId).Delete(del).Error
	if err != nil {
		return
	}
	// 新增数据
	if len(data) > 0 {
		err = tx.Model(m).Save(&data).Error
	}
	return
}

// QueryByInfoId 根据技能信息id查询
func (m *AppSparringSkillInfo) QueryByInfoId(infoId int) (has int64, data AppSparringSkillInfo, err error) {
	model := utils.GEngine.Where("info_id = ?", infoId).First(&data)
	has = model.RowsAffected
	err = model.Error
	return
}

func (m *AppSparringSkillInfo) DelSkillInfoByInfoKey() (affected int64, err error) {
	model := utils.GEngine.Where("info_user_id = ? and info_skill_id= ? and info_sparring_skill_id = ?", m.InfoUserId, m.InfoSkillId, m.InfoSparringSkillId).Delete(m)
	affected = model.RowsAffected
	err = model.Error
	return
}

// func (m *AppSparringSkillInfo) AddSkillInfoByInfoKey(_value int64) (err error) {
//	m.InfoValue = _value
//	err = utils.GEngine.Create(m).Error
//	return
// }

// QueryByInSkillId 根据技能id in查询
func (m *AppSparringSkillInfo) QueryByInSkillId(skillId []int64) (data []AppSparringSkillInfo, err error) {
	err = utils.GEngine.Preload("AppSkillFieldValue").Where("info_sparring_skill_id IN ?", skillId).Find(&data).Error
	return
}

// 根据技能id in查询
func (m *AppSparringSkillInfo) QueryByInSkillIdStr(skillId []string) (data []AppSparringSkillInfo, err error) {
	err = utils.GEngine.Preload("AppSkillFieldValue").Where("info_sparring_skill_id IN ?", skillId).Find(&data).Error
	return
}

// 获取一条技能价格
func (m *AppSparringSkillInfo) QuerySkillPriceFirst(userId int64, gameId, skillId int64) (data AppSparringSkillInfo, err error) {
	err = utils.GEngine.Where("info_user_id = ? and info_game_id= ? and info_skill_id = ? and info_key = 'SkillPrice' and info_value = ?", userId, gameId, skillId, APP_GAME_DEFAULT_KEY).First(&data).Error
	return
}

// 修改段位认证
func (m *AppSparringSkillInfo) UpdateSkillLevel(tx *gorm.DB, InfoId, InfoValueId int64) (err error) {
	err = tx.Model(m).Where("info_id = ?", InfoId).Update("info_value_id", InfoValueId).Error
	return
}
