package dbmodels

import (
	"errors"
	"time"

	"gorm.io/gorm"

	"gamers/enum"
)

type AppTaskRecord struct {
	RecordID           uint32 `json:"record_id"`
	RecordUserID       int64  `json:"record_user_id"`       // user_id
	RecordSetID        uint32 `json:"record_set_id"`        // 任务集合ID
	RecordTaskID       uint32 `json:"record_task_id"`       // 任务ID
	RecordConditionTag string `json:"record_condition_tag"` // 任务条件标签
	RecordProgress     uint32 `json:"record_progress"`      // 任务进度
	RecordState        uint32 `json:"record_state"`         // 任务状态(0:未完成;1:已完成;2:已领取)
	RecordTime         int64  `json:"record_time"`          // 任务时间
	BaseModel
}

func (AppTaskRecord) TableName() string {
	return "app_task_record"
}

type TaskUpdateProgress struct {
	UserID            int64
	SetID             uint32
	TaskID            uint32
	ConditionTag      string
	ConditionCount    uint32    // 配置中完成条件
	AddConditionCount uint32    // 完成条件增加数量
	RecordTime        time.Time // 触发时间
	TaskBegin         int64
	TaskEnd           int64
}

// 更新任务进度
func (r *AppTaskRecord) UpdateProgress(db *gorm.DB, tup *TaskUpdateProgress) error {
	var orgRecord AppTaskRecord

	var queryDB = db.Model(r).Where("record_user_id = ? AND record_task_id = ?", tup.UserID, tup.TaskID)
	if tup.TaskBegin != 0 && tup.TaskEnd != 0 {
		queryDB = queryDB.Where("record_time >= ? and record_time <= ?", tup.TaskBegin, tup.TaskEnd)
	}
	var err = queryDB.First(&orgRecord).Error
	if err != nil && err != gorm.ErrRecordNotFound {
		return err
	}

	if err == gorm.ErrRecordNotFound {
		var newRecord = &AppTaskRecord{
			RecordID:           0,
			RecordUserID:       tup.UserID,
			RecordSetID:        tup.SetID,
			RecordTaskID:       tup.TaskID,
			RecordConditionTag: tup.ConditionTag,
			RecordProgress:     tup.AddConditionCount,
			RecordState:        enum.TaskStateInProgress,
			RecordTime:         tup.RecordTime.Unix(),
		}
		if tup.AddConditionCount >= tup.ConditionCount {
			newRecord.RecordState = enum.TaskStateFinish
		}
		if retErr := db.Model(r).Create(newRecord).Error; retErr != nil {
			return retErr
		}
		return nil
	}

	// 已完成/已领取，不在更新数据
	switch orgRecord.RecordState {
	case enum.TaskStateFinish, enum.TaskStateGet:
		return nil
	case enum.TaskStateInProgress:
	default:
		return nil
	}

	var newRecordProgress = tup.AddConditionCount + orgRecord.RecordProgress
	var newRecordState = enum.TaskStateInProgress
	var newRecordTime = tup.RecordTime.Unix()
	if newRecordProgress >= tup.ConditionCount {
		newRecordState = enum.TaskStateFinish
		newRecordProgress = tup.ConditionCount
	}

	var updateErr = db.Model(r).Where("record_id = ?", orgRecord.RecordID).Updates(map[string]interface{}{
		"record_progress": newRecordProgress,
		"record_state":    newRecordState,
		"record_time":     newRecordTime,
	}).Error

	if updateErr != nil {
		return updateErr
	}

	return nil
}

type TaskFinishTask struct {
	UserID     int64
	SetID      uint32
	TaskID     uint32
	RecordTime time.Time // 触发时间
	TaskBegin  int64
	TaskEnd    int64
}

// 完成任务（只修改任务状态）
func (r *AppTaskRecord) FinishTask(db *gorm.DB, tft *TaskFinishTask) (string, error) {
	var orgRecord AppTaskRecord

	var queryDB = db.Model(r).Where("record_user_id = ? AND record_task_id = ?", tft.UserID, tft.TaskID)
	if tft.TaskBegin != 0 && tft.TaskEnd != 0 {
		queryDB = queryDB.Where("record_time >= ? and record_time <= ?", tft.TaskBegin, tft.TaskEnd)
	}
	var err = queryDB.First(&orgRecord).Error

	if err == gorm.ErrRecordNotFound {
		return "任务未完成", errors.New("task isn't finished")
	}
	if err != nil {
		return "", err
	}

	switch orgRecord.RecordState {
	case enum.TaskStateInProgress:
		return "任务未完成", errors.New("task isn't finished")
	case enum.TaskStateFinish:
	case enum.TaskStateGet:
		return "任务已领取", errors.New("task is already get")
	default:
		return "任务状态错误", errors.New("error task state")
	}

	var rowsAffected = db.Model(r).Where("record_id = ? AND record_state = ?", orgRecord.RecordID, enum.TaskStateFinish).Updates(
		map[string]interface{}{
			"record_state": enum.TaskStateGet,
			"record_time":  tft.RecordTime.Unix(),
		}).RowsAffected

	if rowsAffected != 1 {
		return "任务领取失败", errors.New("get task reward failed")
	}

	return "", nil
}
