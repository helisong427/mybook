/**
 * @Author: panke
 * @Description:
 * @File: app_trun_table_reward
 * @Date: 2021/4/22 14:52
 */

package dbmodels

type AppTurnTableReward struct {
	RewardID          uint    `json:"reward_id" gorm:"column:reward_id"`
	RewardTurnTableID uint    `json:"reward_turn_table_id" gorm:"column:reward_turn_table_id"` // 转盘id
	RewardPropType    uint    `json:"reward_prop_type" gorm:"column:reward_prop_type"`         // 物品类型(0go币,1礼物,2锤子,3头像框,4聊天框,5座驾,6活动道具,7实物道具,8Go币道具)
	RewardPropID      uint    `json:"reward_prop_id" gorm:"column:reward_prop_id"`             // 物品ID
	RewardPropCount   int64   `json:"reward_prop_count" gorm:"column:reward_prop_count"`       // 物品被抽到次数
	AppProp           AppProp `gorm:"foreignKey:PropId;references:RewardPropID"`               // 关联礼物
	BaseModel
}

func (m *AppTurnTableReward) TableName() string {
	return "app_turn_table_reward"
}
