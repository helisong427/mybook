package dbmodels

import (
	"encoding/json"
	"gamers/utils"

	"github.com/go-redis/redis"
)

//用户渠道表
type AppUserChannel struct {
	ChannelId       int64  `gorm:"column:channel_id" json:"channel_id"`
	ChannelParentId int64  `gorm:"column:channel_parent_id" json:"channel_parent_id"`
	ChannelName     string `gorm:"column:channel_name" json:"channel_name"`
	ChannelOrder    int64  `gorm:"column:channel_order" json:"channel_order"`
	ChannelKey      string `gorm:"column:channel_key" json:"channel_key"`
	ChannelApkURL   string `gorm:"column:channel_apk_url" json:"channel_apk_url"`
	ChannelConfig   string `gorm:"column:channel_config" json:"channel_config"`
	BaseModel
}

type AppUserChannelSearch struct {
	ChannelId       *uint64
	ChannelParentId *uint64
	ChannelName     string
	OrderField      string `json:"order_field"` //排序字段
	OrderType       uint8  `json:"order_type"`  //排序类型
	Page            int    `json:"page"`        //当前页
	PageSize        int    `json:"size"`        //每页条数
}

func (AppUserChannel) TableName() string {
	return "app_user_channel"
}

func (s *AppUserChannel) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s AppUserChannel) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

const (
	CHANNEL_KEY_WEISIDUN    = "WEISIDUN"
	CHANNEL_KEY_SHUANGSHENG = "SHUANGSHENG"
	CHANNEL_KEY_TUIA        = "TUIA"
	CHANNEL_KEY_YIMI        = "YIMI"
	CHANNEL_KEY_HUAWEI      = "HUAWEI"
)

func (auc *AppUserChannel) Create() (err error) {
	err = utils.GEngine.Create(&auc).Error
	return
}

//更新
func (auc *AppUserChannel) Update(channelId int64, update map[string]interface{}) (err error) {
	err = utils.GEngine.Model(&auc).Where("channel_id = ?", channelId).Updates(update).Error
	return
}

//根据id查询一条
func (auc *AppUserChannel) QueryById(channelId int64, channelParentId int64) (data AppUserChannel, err error) {
	err = utils.GEngine.Where("channel_id = ? AND channel_parent_id=?", channelId, channelParentId).First(&data).Error
	return
}

//分页查询
func (auc *AppUserChannel) SearchList(search *AppUserChannelSearch) (total int64, data []AppUserChannel, err error) {
	model := utils.GEngine.Model(&auc).Where("deleted = 0")
	if search.ChannelId != nil {
		model = model.Where("channel_id = ?", *search.ChannelId)
	}
	if search.ChannelParentId != nil {
		model = model.Where("channel_parent_id = ?", *search.ChannelParentId)
	}
	if search.ChannelName != "" {
		model = model.Where("channel_name LIKE ?", "%"+search.ChannelName+"%")
	}

	if search.OrderField == "" {
		model = model.Order("channel_order ASC")
	} else if search.OrderType == 0 {
		model = model.Order(search.OrderField + " ASC")
	} else if search.OrderType == 1 {
		model = model.Order(search.OrderField + " DESC")
	}
	offset := (search.Page - 1) * search.PageSize
	if offset <= 0 {
		offset = 0
	}
	err = model.Count(&total).Offset(offset).Limit(search.PageSize).
		Find(&data).Error
	return
}

func (auc *AppUserChannel) SearchAll() (data []AppUserChannel, err error) {
	err = utils.GEngine.Model(&auc).Where("deleted = 0").Find(&data).Error
	return
}

// 根据唯一key获取渠道信息
func (auc *AppUserChannel) GetChannelByKey(key string) (data AppUserChannel, err error) {
	//获取缓存
	err = utils.RedisClient.HGet(utils.REDIS_CHANNEL_INFO, key).Scan(&data)
	if err != nil && err != redis.Nil {
		return
	}
	if err == nil {
		return
	}
	//未获取到缓存，从数据库取
	err = utils.GEngine.Model(auc).Where("channel_key = ? and deleted = 0", key).First(&data).Error
	if err != nil {
		return
	}
	//保存缓存
	err = utils.RedisClient.HSet(utils.REDIS_CHANNEL_INFO, key, data).Err()
	return
}

//根据id查询一条
func (auc *AppUserChannel) GetChannelById(channelId int64) (data AppUserChannel, err error) {
	err = utils.GEngine.Where("channel_id = ? AND deleted = 0", channelId).First(&data).Error
	return
}
