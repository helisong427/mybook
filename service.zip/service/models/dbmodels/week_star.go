package dbmodels

import (
	"gamers/utils"
	"gorm.io/gorm"
	"time"
)

type AppWeekStar struct {
	WeekStarId         int64  `gorm:"column:week_star_id" json:"week_star_id"`
	WeekStarStatus     int64  `gorm:"column:week_star_status" json:"week_star_status"`           // 周星榜状态(0关闭, 1开启)
	WeekStarBackground string `gorm:"column:week_star_background" json:"week_star_background"`   // 活动背景图
	WeekStarWealthGift string `gorm:"column:week_star_wealth_gift" json:"week_star_wealth_gift"` // 财富榜奖励(json形式)
	WeekStarCharmGift  string `gorm:"column:week_star_charm_gift" json:"week_star_charm_gift"`   // 魅力榜奖励(json形式)
	WeekStarGift       string `gorm:"column:week_star_gift" json:"week_star_gift"`               // 周星榜礼物列表
	WeekStarStartTime  int64  `gorm:"column:week_star_start_time" json:"week_star_start_time"`   // 活动开始时间
	WeekStarEndTime    int64  `gorm:"column:week_star_end_time" json:"week_star_end_time"`       // 活动结束时间
	WeekStarType       int64  `gorm:"column:week_star_type" json:"week_star_type"`               // 周星榜 类型 (0周星榜, 1 愚人节)
	WeekStarTaskId     int64  `gorm:"column:week_star_task_id" json:"week_star_task_id"`         // 周星榜 任务ID
	Created            int64  `gorm:"column:created" json:"created"`                             // create time
	Edited             int64  `gorm:"column:edited" json:"edited"`                               // edit time
	Deleted            int64  `gorm:"column:deleted" json:"deleted"`                             // delete time
}

func (m *AppWeekStar) TableName() string {
	return "app_week_star"
}

// 创建记录
func (m *AppWeekStar) Create() error {
	m.Created = time.Now().Unix()
	return utils.GEngine.Model(m).Create(m).Error
}

// 更新数据 (通过 周星榜id 更新对应活动记录)
func (m *AppWeekStar) Update(weekStarId int64, update map[string]interface{}) error {
	return utils.GEngine.Model(m).Where("week_star_id = ?", weekStarId).Updates(update).Error
}

type WeekStarResultItemImage struct {
	Level     int64  `json:"level"`      // 排名
	Type      int64  `json:"type"`       // 类型
	Name      string `json:"name"`       // 礼物名 或 其他名
	PropImage string `json:"prop_image"` // 图片url
}

type AppWeekStarResultItem struct {
	WeekStarId         int64  `json:"week_star_id"`
	WeekStarStatus     int64  `json:"week_star_status"`     // 周星榜状态(0关闭, 1开启)
	WeekStarBackground string `json:"week_star_background"` // 活动背景图
	// WeekStarWealthGift     string                     `json:"week_star_wealth_gift"`      // 财富榜奖励(json形式)
	// WeekStarCharmGift      string                     `json:"week_star_charm_gift"`       // 魅力榜奖励(json形式)
	WeekStarGift      string `json:"week_star_gift"`       // 周星榜礼物列表
	WeekStarStartTime int64  `json:"week_star_start_time"` // 活动开始时间
	WeekStarEndTime   int64  `json:"week_star_end_time"`   // 活动结束时间
	WeekStarType      int64  `json:"week_star_type"`       // 周星榜 类型 0 周星榜 1 愚人节
	Created           int64  `json:"created"`              // create time
	Edited            int64  `json:"edited"`               // edit time
	Deleted           int64  `json:"deleted"`              // delete time
	// WeekStarWealthGiftList []*WeekStarResultItemImage `json:"week_star_wealth_gift_list"` // 财富榜奖励图片数组
	// WeekStarCharmGiftList  []*WeekStarResultItemImage `json:"week_star_charm_gift_list"`  // 魅力榜奖励图片数组
	WeekStarGiftList []*WeekStarResultItemImage `gorm:"-" json:"week_star_gift_list"` // 活动礼物图片列表
}

// 通过 当前时间 获取 记录
func (m *AppWeekStar) GetByNowTime(timeStamp int64) (result *AppWeekStarResultItem, err error) {
	var (
		data AppWeekStarResultItem
	)

	if err = utils.GEngine.Model(m).Where("deleted = 0").
		Where("week_star_start_time <= ?", timeStamp).
		Where("week_star_end_time >= ?", timeStamp).
		Where("week_star_status = 1").
		First(&data).Error; err != nil {
		if err == gorm.ErrRecordNotFound {
			err = nil
		}
	}

	result = &data

	return
}

func (m *AppWeekStar) QueryById(weekStar int64) (result *AppWeekStarResultItem, err error) {
	var (
		data AppWeekStarResultItem
	)

	if err = utils.GEngine.Model(m).Where("deleted = 0").
		Where("week_star_id = ?", weekStar).
		First(&data).Error; err != nil {
		if err == gorm.ErrRecordNotFound {
			err = nil
		}
	}

	result = &data

	return
}
