package dbmodels

import (
	"encoding/json"
	"strconv"

	"github.com/go-redis/redis"

	"gamers/controller/response"
	"gamers/utils"
	"gamers/utils/prop"
)

// 道具表
type AppProp struct {
	PropId           int64     `gorm:"column:prop_id;primaryKey;autoIncrement" json:"prop_id"` // 道具id
	PropName         string    `gorm:"column:prop_name" json:"prop_name"`                      // 礼物名称
	PropType         int       `gorm:"column:prop_type" json:"prop_type"`                      // 道具类型(1礼物,2锤子,3头像框,4聊天框,5座驾,6活动道具,7实物道具,8Go币道具)
	PropClass        int       `gorm:"column:prop_class" json:"prop_class"`                    // 礼物类型(0正常礼物,1免费倒计时礼物,2限时购买礼物) 用于送礼物区分
	PropAttrId       int64     `gorm:"column:prop_attr_id" json:"prop_attr_id"`                // 道具属性(礼物页签,对应app_prop_attr中的attr_id)
	PropLevel        int       `gorm:"column:prop_level" json:"prop_level"`                    // 礼物抽成类型(0普通礼物,1冠名礼物 )
	PropPrice        int64     `gorm:"column:prop_price" json:"prop_price"`                    // 代币价格
	PropOrgPrice     int64     `gorm:"column:prop_org_price" json:"prop_org_price"`            // 原价
	PropVipLevel     int       `gorm:"column:prop_vip_level"`                                  // 需要解锁的vip等级
	PropWealth       int64     `gorm:"column:prop_wealth" json:"prop_wealth"`                  // 财富值
	PropCharm        int64     `gorm:"column:prop_charm" json:"prop_charm"`                    // 魅力值
	PropInterval     int64     `gorm:"column:prop_interval" json:"prop_interval"`              // 免费礼物时间间隔单位秒
	PropGetMax       int64     `gorm:"column:prop_get_max" json:"prop_get_max"`                // 每天免费获取上限
	PropRadioCount1  int64     `gorm:"column:prop_radio_count1" json:"prop_radio_count_1"`     // 本房间广播数量
	PropRadioCount2  int64     `gorm:"column:prop_radio_count2" json:"prop_radio_count_2"`     // 同标签广播数量
	PropRadioCount3  int64     `gorm:"column:prop_radio_count3" json:"prop_radio_count_3"`     // 全服广播数量
	PropIcon         string    `gorm:"column:prop_icon" json:"prop_icon"`                      // 礼物图标
	PropUrl          string    `gorm:"column:prop_url" json:"prop_url"`                        // 礼物url 特效地址
	PropUrl1         string    `gorm:"column:prop_url1" json:"prop_url1"`                      // 礼物url1 特效地址
	PropQuickCount   string    `gorm:"column:prop_quick_count" json:"prop_quick_count"`        // 快捷送礼数量josn数组
	PropStartTime    int64     `gorm:"column:prop_start_time" json:"prop_start_time"`          // 开启购买时间
	PropEndTime      int64     `gorm:"column:prop_end_time" json:"prop_end_time"`              // 结束购买时间
	PropSpecialLevel int64     `gorm:"column:prop_special_level" json:"prop_special_level"`    // 礼物特效等级(1最初级 数字越大越高级)
	PropGetRadio1    int64     `gorm:"column:prop_get_radio1" json:"prop_get_radio_1"`         // 获得礼物是否全服广播(0不广告,1广播)
	PropExpiredType  int64     `gorm:"column:prop_expired_type" json:"prop_expired_type"`      // 过期类型(0具体时间,1若干天后)
	PropExpiredTime  int64     `gorm:"column:prop_expired_time" json:"prop_expired_time"`      // 过期时间,根据limit_type确定
	PropAddIcon      string    `gorm:"column:prop_add_icon" json:"prop_add_icon"`              // 附属icon
	PropRemark       string    `gorm:"column:prop_remark" json:"prop_remark"`                  // 物品描述
	PropSort         int64     `gorm:"column:prop_sort" json:"prop_sort"`                      // 礼物排序,从小到大
	PropStatus       int       `gorm:"column:prop_status" json:"prop_status"`                  // 道具状态(0上架,1下架)
	BaseModel        BaseModel `gorm:"embedded" json:"-"`
}

// 道具类型
const (
	DB_PROP_TYPE          int = iota
	DB_PROP_TYPE_GIFT         // 礼物
	DB_PROP_TYPE_HAMMER       // 锤子
	DB_PROP_TYPE_AVATAR       // 头像框
	DB_PROP_TYPE_CHAT         // 聊天框
	DB_PROP_TYPE_CAR          // 座驾
	DB_PROP_TYPE_ACTIVITY     // 活动道具
	DB_PROP_TYPE_ENTITY       // 实物道具
	DB_PROP_TYPE_GO           // Go币道具
)

// 道具状态
const (
	DB_PROP_STATUS_ON  int = iota // 上架
	DB_PROP_STATUS_OFF            // 下架
)

// 礼物类型
const (
	DB_CLASS_NORMAL       int = iota // 正常礼物
	DB_CLASS_FREE                    // 1免费倒计时礼物
	DB_CLASS_LIMITED_TIME            // 2限时购买礼物
)

var DbPropTypeMap = map[int]string{
	DB_PROP_TYPE_GIFT:   "礼物",
	DB_PROP_TYPE_HAMMER: "锤子",
	DB_PROP_TYPE_AVATAR: "头像框",
	DB_PROP_TYPE_CHAT:   "聊天框",
	DB_PROP_TYPE_CAR:    "座驾",
}

func (AppProp) TableName() string {
	return "app_prop"
}

func (s *AppProp) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s AppProp) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

func (m *AppProp) Create() (err error) {
	err = utils.GEngine.Create(m).Error
	return
}

// QueryByGiftId 根据礼物id查询
func (m *AppProp) GetPropById(propId int64, propType int) (data AppProp, err error) {
	m, err = m.GetPropConfigById(propId)
	if err != nil {
		return
	}
	if m.PropType != propType {
		err = prop.ErrorUnexpectedId
		return
	}
	data = *m
	return
}

// 获取全部列表
func (m *AppProp) GetAllGifts(attrId int64) (results []response.GetGiftResp, err error) {
	err = utils.GEngine.Table(m.TableName()).Where("deleted = 0 and prop_type = ?  and prop_status = ? and prop_attr_id = ?",
		DB_PROP_TYPE_GIFT, DB_PROP_STATUS_ON, attrId).Order("prop_sort asc").Find(&results).Error
	return
}

// 分页查询装扮
func (m *AppProp) QueryDressPage(page int, size int, propType int, attrId int64) (total int64, data []AppProp, err error) {
	err = utils.GEngine.Model(m).
		Where("prop_type = ? AND prop_attr_id = ? AND prop_status = ?", propType, attrId, DB_PROP_STATUS_ON).
		Order("prop_sort asc").
		Count(&total).
		Offset((page * size) - size).
		Limit(size).
		Find(&data).Error
	return
}

// 获取物品配置（通过物品Id）
func (m *AppProp) GetPropConfigById(propId int64) (*AppProp, error) {
	var err error
	propIdStr := strconv.Itoa(int(propId))
	// 获取缓存
	err = utils.RedisClient.HGet(utils.REDIS_PROP_INFO, propIdStr).Scan(m)
	if err != nil && err != redis.Nil {
		return nil, err
	}
	if err == nil {
		return m, nil
	}
	// 未获取到缓存，从数据库取
	// err = utils.GEngine.Model(m).Where("prop_id = ? and deleted = 0 and prop_type = ?", propId, propType).First(&data).Error
	err = utils.GEngine.Model(m).Where("prop_id = ? and deleted = 0", propId).First(m).Error
	if err != nil {
		return nil, err
	}
	// 保存缓存
	err = utils.RedisClient.HSet(utils.REDIS_PROP_INFO, propIdStr, m).Err()
	return m, nil
}

// 根据 PropType 和 attrId 获取配置
func (m *AppProp) QueryByTypeAndAttrId(propType int, attrId int64) (result []*AppProp, err error) {
	var db = utils.GEngine.Model(m)
	if propType != int(prop.ExceptedTypeAll) {
		db = db.Where("prop_type = ?", propType)
	}
	if attrId != 0 {
		db = db.Where("prop_attr_id = ?", attrId)
	}
	err = db.Where("prop_status = ? and deleted = 0", DB_PROP_STATUS_ON).Find(&result).Error
	return
}

// 根据 prop_id 批量获取配置
func (m *AppProp) QueryByPropIdMaps(ids map[int64]int64) (result map[int64]*AppProp, err error) {
	if len(ids) == 0 {
		return
	}
	var arr []int64
	for id, _ := range ids {
		arr = append(arr, id)
	}

	// 忽略 prop_status 和 deleted 字段
	var ret []*AppProp
	err = utils.GEngine.Model(m).Where("prop_id in (?)", arr).Find(&ret).Error
	if err != nil {
		return
	}

	result = map[int64]*AppProp{}
	for _, v := range ret {
		result[v.PropId] = v
	}
	return
}

// in查询
func (m *AppProp) QueryByIn(ids []int64) (row int64, data []AppProp, err error) {
	model := utils.GEngine.Where("prop_id IN ?", ids).Find(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

// 根据id查询一条
func (ap *AppProp) QueryById(propId uint64) (row int64, data AppProp, err error) {
	model := utils.GEngine.Where("prop_id = ?", propId).First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}
