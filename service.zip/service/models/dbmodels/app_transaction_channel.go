package dbmodels

import (
	"encoding/json"
	"gamers/utils"
	"github.com/go-redis/redis"
	"strconv"
)

//交易渠道表
type AppTransactionChannel struct {
	ChannelId     uint64 `gorm:"column:channel_id"`
	ChannelType   int64  `gorm:"column:channel_type"`
	ChannelName   string `gorm:"column:channel_name"`
	ChannelKey    string `gorm:"column:channel_key"`
	ChannelParam  string `gorm:"column:channel_param"`
	ChannelWeight int    `gorm:"column:channel_weight"`
	BaseModel
}

const (
	// 配置key名称
	TRANSACTION_CHANNEL_KEY_MEICAI         = "meicai"         // 美差提现
	TRANSACTION_CHANNEL_KEY_APPLEPAY       = "applepay"       // 苹果原生支付
	TRANSACTION_CHANNEL_KEY_WECHATPAY      = "wechatpay"      // 微信支付
	TRANSACTION_CHANNEL_KEY_WECHATJSAPIPAY = "wechatjsapipay" // 微信网页/公众号支付
	TRANSACTION_CHANNEL_KEY_ALIPAY         = "alipay"         // 支付宝支付
	TRANSACTION_CHANNEL_KEY_YUNYIFU        = "yunyifu"        // 云易付
)

//美差参数
type ChannelMeiCaiParam struct {
	PlatformFee      int64  `json:"platform_fee"`      //平台手续费 放大10000倍 100=1%  1=0.01%
	ThirdFee         int64  `json:"third_fee"`         //第三方手续费 放大10000倍 100=1%  1=0.01%
	MonthMax         int64  `json:"month_max"`         //月累计最大提现金额
	Url              string `json:"url"`               //请求url
	MerchantId       string `json:"merchant_id"`       //商家id
	MerchantName     string `json:"merchant_name"`     //商家名称
	PublicKey        string `json:"public_key"`        //公钥
	PrivateKey       string `json:"private_key"`       //私钥
	ContractTemplate string `json:"contract_template"` //合同模板id
}

//苹果原生支付参数
type ChannelApplePayParam struct {
	BundleId   string `json:"bundle_id"`   //bandleID
	SandboxURL string `json:"sandbox_url"` //沙盒环境
	ProdURL    string `json:"prod_url"`    //正式环境
}

//微信支付参数
type ChannelWechatPayParam struct {
	AppId      string `json:"app_id"`      //appid
	ApiKey     string `json:"api_key"`     //apikey
	MerchantId string `json:"merchant_id"` //商户id
	NotifyURL  string `json:"notify_url"`  //回调通知url
}

//微信支付jsapi参数
type ChannelWechatJSAPIPayParam struct {
	AppId       string `json:"app_id"`       //appid
	ApiKey      string `json:"api_key"`      //apikey
	Secret      string `json:"secret"`       //secret
	MerchantId  string `json:"merchant_id"`  //商户id
	NotifyURL   string `json:"notify_url"`   //回调通知url
	RedirectURL string `json:"redirect_uri"` //重定向url
}

//支付宝支付
type ChannelAliPayParam struct {
	AppId      string `json:"app_id"`      //appid
	PrivateKey string `json:"private_key"` //
	PublicKey  string `json:"public_key"`  //
	NotifyURL  string `json:"notify_url"`  //回调通知url
	ReturnURL  string `json:"return_uri"`  //重定向url
}

//云易付
type ChannelYunyifuParam struct {
	PlatformFee int64  `json:"platform_fee"` //平台手续费 放大10000倍 100=1%  1=0.01%
	ThirdFee    int64  `json:"third_fee"`    //第三方手续费 放大10000倍 100=1%  1=0.01%
	MonthMax    int64  `json:"month_max"`    //月累计最大提现金额分
	AppId       string `json:"app_id"`       //appid
	AppSecret   string `json:"app_secret"`   //
	Host        string `json:"host"`         //
	NotifyURL   string `json:"notify_url"`   //回调通知url
}

//提现渠道公共参数
type ChannelWithdrawal struct {
	PlatformFee int64 `json:"platform_fee"` //平台手续费 放大10000倍 100=1%  1=0.01%
	ThirdFee    int64 `json:"third_fee"`    //第三方手续费 放大10000倍 100=1%  1=0.01%
	MonthMax    int64 `json:"month_max"`    //月累计最大提现金额分
}

func (AppTransactionChannel) TableName() string {
	return "app_transaction_channel"
}

// QueryKey 根据配置key查询
func (atc *AppTransactionChannel) QueryKey(key string) (data map[string]string, err error) {
	str, err := utils.RedisClient.HGet(utils.REDIS_TRANSACTION_CHANNEL, key).Result()
	if err != nil && err != redis.Nil {
		return
	}
	// 缓存不存在，创建之
	if err == redis.Nil {
		transactionChannel := AppTransactionChannel{}
		err = utils.GEngine.Model(&atc).Where("deleted=0 AND channel_key = ?", key).First(&transactionChannel).Error
		if err != nil {
			return
		}
		data = map[string]string{
			"key":    transactionChannel.ChannelKey,
			"param":  transactionChannel.ChannelParam,
			"weight": strconv.Itoa(transactionChannel.ChannelWeight),
			"id":     strconv.FormatUint(transactionChannel.ChannelId, 10),
		}
		str, _ := json.Marshal(data)
		err = utils.RedisClient.HSet(utils.REDIS_TRANSACTION_CHANNEL, key, string(str)).Err()
	} else {
		err = json.Unmarshal([]byte(str), &data)
	}
	return
}

func (atc *AppTransactionChannel) SearchList() (data []map[string]string, err error) {
	result, err := utils.RedisClient.HGetAll(utils.REDIS_TRANSACTION_CHANNEL).Result()
	if err != nil {
		return nil, err
	}
	var count int64 = 0
	err = utils.GEngine.Model(&atc).Where("deleted=0").Count(&count).Error
	if err != nil || count == 0 {
		return nil, err
	}
	if len(result) != int(count) {
		transactionChannel := []AppTransactionChannel{}
		err = utils.GEngine.Model(&atc).Where("deleted=0").Find(&transactionChannel).Error
		if err != nil {
			return
		}
		for _, v := range transactionChannel {
			intoData := map[string]string{
				"key":    v.ChannelKey,
				"param":  v.ChannelParam,
				"weight": strconv.Itoa(v.ChannelWeight),
				"id":     strconv.FormatUint(v.ChannelId, 10),
			}
			data = append(data, intoData)
			intoJson, _ := json.Marshal(intoData)
			err = utils.RedisClient.HSet(utils.REDIS_TRANSACTION_CHANNEL, v.ChannelKey, string(intoJson)).Err()
		}
	} else {
		for _, v := range result {
			intoData := map[string]string{}
			err = json.Unmarshal([]byte(v), &intoData)
			if err == nil {
				data = append(data, intoData)
			}
		}
	}
	return
}

// 更新
func (atc *AppTransactionChannel) UpdateValue(key, param string) (err error) {
	err = utils.GEngine.Model(atc).Where("channel_key", key).Update("ChannelParam", param).Error
	if err != nil {
		return
	}
	err = utils.RedisClient.HDel(utils.REDIS_TRANSACTION_CHANNEL, key).Err()
	return
}
