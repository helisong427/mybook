package dbmodels

import "gamers/utils"

//朋友圈话题
type AppTweetTopic struct {
	TopicID      int64     `json:"topic_id" gorm:"column:topic_id;primaryKey;autoIncrement"`
	TopicTweetID int64     `json:"topic_tweet_id"` //朋友圈id
	TopicTopicID int64     `json:"topic_topic_id"` //话题id
	BaseModel    BaseModel `gorm:"embedded" json:"base_model"`
	AppTopics    AppTopic  `gorm:"foreignKey:TopicTopicID"` //关联话题
}

func (AppTweetTopic) TableName() string {
	return "app_tweet_topic"
}

type AppTweetTopicJoin struct {
	TopicTweetID int64
	TopicID      int64
	TopicTitle   string
}

//批量插入
func (m *AppTweetTopic) InsertAll(topics []AppTweetTopic) (err error) {
	err = utils.GEngine.Create(&topics).Error
	return
}

//Query 关联查询话题详情
func (m *AppTweetTopic) Query(topicTweetIDs []int64) (data []AppTweetTopic, err error) {
	err = utils.GEngine.Model(m).
		Where("topic_tweet_id IN ?", topicTweetIDs).
		Preload("AppTopics").
		Find(&data).Error
	return
}
