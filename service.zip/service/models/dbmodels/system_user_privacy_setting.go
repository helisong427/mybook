/**
 * @Author: panke
 * @Description: 用户隐私设置表
 * @File: system_user_privacy_setting
 * @Date: 2021/5/17 16:03
 */

package dbmodels

import (
	"fmt"
	"gamers/controller/request"
	"gamers/utils"
	"github.com/go-redis/redis"
	"strconv"
	"time"
)

const (
	UserPrivacySettingRedisFieldsOnlinePush = "user_online_message_push"
	UserPrivacySettingRedisFieldsDirectPush = "direct_order_push"
	UserPrivacySettingRedisFieldsRandomPush = "random_order_push"
)

type UserPrivacySetting struct {
	UserOnlineMessagePush int `json:"user_online_message_push" gorm:"column:user_online_message_push"` // 用户上线消息推送(0推送 1不推送)
	DirectOrderPush       int `json:"direct_order_push" gorm:"column:direct_order_push"`               // 公众号定向单推送(0推送 1不推送)
	RandomOrderPush       int `json:"random_order_push" gorm:"column:random_order_push"`               // 公众号随机单推送(0推送 1不推送)
}

type SystemUserPrivacySetting struct {
	ID                    int64     `json:"id" gorm:"column:id"`
	UserID                int64     `json:"user_id" gorm:"column:user_id"`                                   // 用户id
	UserOnlineMessagePush int64     `json:"user_online_message_push" gorm:"column:user_online_message_push"` // 用户上线消息推送(0推送 1不推送)
	DirectOrderPush       int64     `json:"direct_order_push" gorm:"column:direct_order_push"`               // 公众号定向单推送(0推送 1不推送)
	RandomOrderPush       int64     `json:"random_order_push" gorm:"column:random_order_push"`               // 公众号随机单推送(0推送 1不推送)
	CreateTime            time.Time `json:"create_time" gorm:"column:create_time;default:(-)"`               // 记录创建时间
	UpdateTime            time.Time `json:"update_time" gorm:"column:update_time;default:(-)"`               // 记录修改时间
}

func (m *SystemUserPrivacySetting) TableName() string {
	return "system_user_privacy_setting"
}

// 获取用户隐私设置
func (m *SystemUserPrivacySetting) GetPrivacySetting(userId int64) (data UserPrivacySetting, err error) {

	data = UserPrivacySetting{}
	result, err := utils.RedisClient.HGetAll(fmt.Sprintf("%s%d", utils.Redis_User_Privacy_Setting, userId)).Result()
	if err != nil && err != redis.Nil {
		return
	}
	if len(result) > 0 {
		onlinePush, _ := strconv.Atoi(result[UserPrivacySettingRedisFieldsOnlinePush])
		data.UserOnlineMessagePush = onlinePush

		directPush, _ := strconv.Atoi(result[UserPrivacySettingRedisFieldsDirectPush])
		data.DirectOrderPush = directPush

		randomPush, _ := strconv.Atoi(result[UserPrivacySettingRedisFieldsRandomPush])
		data.RandomOrderPush = randomPush
		return
	} else {
		err = utils.GEngine.Model(m).Where("user_id=?", userId).Take(&data).Error
		if err != nil {
			return
		}
		_ = utils.RedisClient.HMSet(fmt.Sprintf("%s%d", utils.Redis_User_Privacy_Setting, userId), map[string]interface{}{
			UserPrivacySettingRedisFieldsOnlinePush: data.UserOnlineMessagePush,
			UserPrivacySettingRedisFieldsDirectPush: data.DirectOrderPush,
			UserPrivacySettingRedisFieldsRandomPush: data.RandomOrderPush,
		}).Err()
		return
	}
}

// 更新用户隐私设置
func (m *SystemUserPrivacySetting) Updates(userId int64, value, valueType int) (err error) {

	switch valueType {
	case request.PUSH_ONLINE:
		err = utils.GEngine.Model(m).Where("user_id=?", userId).Update("user_online_message_push", value).Error
	case request.PUSH_DIRECT:
		err = utils.GEngine.Model(m).Where("user_id=?", userId).Update("direct_order_push", value).Error
	case request.PUSH_RAND:
		err = utils.GEngine.Model(m).Where("user_id=?", userId).Update("random_order_push", value).Error
	default:
		return fmt.Errorf("更新开关类型错误！")
	}

	// err = utils.GEngine.Model(m).Where("user_id=?", userId).Updates("updates").Error
	if err != nil {
		return
	}
	_ = utils.RedisClient.Del(fmt.Sprintf("%s%d", utils.Redis_User_Privacy_Setting, userId)).Err()
	return
}

// 用户隐私创建
func (m *SystemUserPrivacySetting) Create() (err error) {
	return utils.GEngine.Create(m).Error
}
