/**
 * @Author: 何玉峰
 * @Date: 2021/5/17 下午5:54
 * @Description: 微信开发相关db操作
 */
package dbmodels

import (
	"gamers/utils"
	"github.com/go-redis/redis"
	"time"
)

func GetAccessToken() (string, bool, error) {

	r, err := utils.RedisClient.Get(utils.REDIS_WECHAT_ACCESS_TOKEN).Result()

	if err != nil && err != redis.Nil {
		return "", false, err
	}

	if err == redis.Nil {
		return "", false, nil
	}

	return r, true, nil
}

func SetAccessToken(token string, expire int) error {

	return utils.RedisClient.Set(utils.REDIS_WECHAT_ACCESS_TOKEN, token, time.Duration(expire)*time.Second).Err()
}
