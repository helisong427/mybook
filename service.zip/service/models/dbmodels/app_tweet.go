package dbmodels

import (
	"fmt"
	"gamers/utils"
	"gorm.io/gorm"
	"time"
)

//用户朋友圈
type AppTweet struct {
	TweetID                int64      `gorm:"column:tweet_id;primaryKey;autoIncrement"`
	TweetUserID            int64      `gorm:"column:tweet_user_id"`            //朋友圈拥有者
	TweetContent           string     `gorm:"column:tweet_content"`            //朋友圈内容
	TweetAttachment        string     `gorm:"column:tweet_attachment"`         //附件列表json格式
	TweetSound             string     `gorm:"column:tweet_sound"`              //声音
	TweetSoundTime         int64      `gorm:"column:tweet_sound_time"`         //声音时长
	TweetSendTime          int64      `gorm:"column:tweet_send_time"`          //发送时间
	TweetSendRegionId      int64      `gorm:"column:tweet_send_region_id"`     //发送城市id
	TweetSendLongitude     float32    `gorm:"column:tweet_send_longitude"`     //发送经度
	TweetSendLatitude      float32    `gorm:"column:tweet_send_latitude"`      //发送维度
	TweetSendPosition      string     `gorm:"column:tweet_send_position"`      //发送位置
	TweetSendTerminal      string     `gorm:"column:tweet_send_terminal"`      //发送终端
	TweetStatus            int        `gorm:"column:tweet_status"`             //状态(0:正常,1:用户删除,2:系统隐藏)
	TweetLikeCount         int64      `gorm:"column:tweet_like_count"`         //点赞数
	TweetCommentCount      int64      `gorm:"column:tweet_comment_count"`      //评论数
	TweetVisible           int        `gorm:"column:tweet_visible"`            //可见度(0:不限,1朋友可见,2仅陌生人可见)
	TweetShareCount        int64      `gorm:"column:tweet_share_count"`        //分享数
	TweetReadCount         int64      `gorm:"column:tweet_read_count"`         //阅读数
	TweetType              int        `gorm:"column:tweet_type"`               //朋友圈类型(1图片,2视频)
	TweetInterventionScore int64      `gorm:"column:tweet_intervention_score"` //后台干预分
	TweetScore             int64      `gorm:"column:tweet_score"`              //30天热度分
	BaseModel              BaseModel  `gorm:"embedded" json:"base_model"`
	AppTopic               []AppTopic `gorm:"many2many:app_tweet_topic;ForeignKey:TweetID;joinForeignKey:TopicTweetID;References:TopicID;JoinReferences:TopicTopicID;"`
}

func (AppTweet) TableName() string {
	return "app_tweet"
}

//关联
type AppTweetJoin struct {
	TweetID            int64
	TweetType          int
	TweetContent       string
	TweetAttachment    string
	TweetSound         string
	TweetSoundTime     int64
	TweetSendRegionId  int64
	TweetSendLatitude  float32
	TweetSendLongitude float32
	TweetSendTime      int64
	TweetSendPosition  string
	TweetSendTerminal  string
	TweetLikeCount     int64
	TweetCommentCount  int64
	TweetShareCount    int64
	TweetReadCount     int64
	UserID             int64
	UserNickname       string
	UserIconurl        string
	UserGender         int
	UserBirthday       int64
	UserIsLike         int //是否点赞
	IsAttention        int //是否关注
}

//朋友圈状态
type TweetStatus int

const (
	TWEET_STATUS_OK          TweetStatus = iota //正常
	TWEET_STATUS_USER_DEL                       //用户删除
	TWEET_STATUS_SYSTEM_HIDE                    //系统隐藏
)

//附件类型
const (
	ATTACHMENT_TYPE_VIDEO = "video" //视频
	ATTACHMENT_TYPE_IMAGE = "image" //图片
	ATTACHMENT_TYPE_AUDIO = "audio" //音频
)

//可见度
type TweetVisible int

const (
	TWEET_VISIBLE_UNLIMITED    TweetVisible = iota //不限
	TWEET_VISIBLE_TO_FRIENDS                       //朋友可见
	TWEET_VISIBLE_TO__STRANGER                     //陌生人可见

)

const (
	TWEET_TAG_ID_ATTENTION int = iota //关注
	TWEET_TAG_ID_POPULAR              //推荐
	TWEET_TAG_ID_RECOMMEND            //热门
	TWEET_TAG_ID_LATEST               //最新
)

const (
	//朋友圈类型
	TWEET_TYPE_IMAGE = 1 //1图片
	TWEET_TYPE_VIDEO = 2 //视频
)

//Create 创建朋友圈信息和话题
func (m *AppTweet) Create(topics []AppTweetTopic) (err error) {
	//开启事务
	err = utils.GEngine.Transaction(func(tx *gorm.DB) error {
		if err = tx.Create(m).Error; err != nil {
			return err
		}
		if len(topics) > 0 {
			if err = tx.Create(&topics).Error; err != nil {
				return err
			}
		}
		return nil
	})
	return
}

//QueryByIdJoin 根据id关联查询
func (m *AppTweet) QueryByIdJoin(id int64, userId string) (tweet AppTweetJoin, err error) {
	err = utils.GEngine.
		Select("*,b.user_id,d.attention_id as is_attention").
		Model(m).
		Joins("INNER JOIN system_user AS b ON app_tweet.tweet_user_id = b.user_id").
		Joins("LEFT JOIN app_tweet_user AS c ON (app_tweet.tweet_id = c.user_tweet_id and c.user_user_id = ?)", userId).
		Joins("LEFT JOIN app_attention AS d ON (app_tweet.tweet_user_id = d.attention_follow_user_id AND d.attention_user_id = ?)", userId).
		Where("app_tweet.tweet_id = ? and app_tweet.tweet_status = ? and b.user_status < ?", id, TWEET_STATUS_OK, USER_STATUS_BAN).
		Where("c.user_is_hidden = ? OR c.user_is_hidden IS NULL", USER_IS_HIDDEN_NO).
		Where("app_tweet.deleted = 0").
		Find(&tweet).Error
	return
}

func (m *AppTweet) QueryTest() (tweet AppTweet, err error) {
	err = utils.GEngine.Model(m).Preload("AppTopic").Find(&tweet).Error
	fmt.Printf("%+v\n", tweet)
	return
}

//PageQuery 分页查询
func (m *AppTweet) PageQuery(page int, size int, userId int64, tagId int) (total int64, tweets []AppTweetJoin, err error) {
	session := utils.GEngine
	switch tagId {
	case TWEET_TAG_ID_ATTENTION: //关注
		err = session.
			Model(m).
			Select("*,b.user_id,d.attention_id as is_attention").
			Joins("INNER JOIN system_user AS b ON app_tweet.tweet_user_id = b.user_id").
			Joins("LEFT JOIN app_tweet_user AS c ON (app_tweet.tweet_id = c.user_tweet_id AND c.user_user_id = ?)", userId).
			Joins("INNER JOIN app_attention AS d ON (app_tweet.tweet_user_id = d.attention_follow_user_id AND d.attention_user_id = ?)", userId).
			Joins("LEFT JOIN app_attention AS e ON ( app_tweet.tweet_user_id = e.attention_user_id AND e.attention_follow_user_id = ? ) ", userId).
			Where("app_tweet.tweet_status = ? and b.user_status < ?", TWEET_STATUS_OK, USER_STATUS_BAN).
			Where("`c`.`user_is_hidden` = ? OR `c`.`user_is_hidden` IS NULL", USER_IS_HIDDEN_NO).
			Where("( `app_tweet`.tweet_visible = 0 OR ( `app_tweet`.`tweet_visible` = 1 AND ( `d`.`attention_id` IS NOT NULL  AND `e`.`attention_id` IS NOT NULL ) ) OR (`app_tweet`.`tweet_visible` = 2 AND ( `d`.`attention_id` IS NULL ) ) )").
			Where("`app_tweet`.`tweet_user_id` NOT IN ( SELECT `blacklist_black_user_id` FROM `app_blacklist` WHERE blacklist_user_id = ? ) ", userId).
			Where("app_tweet.deleted = 0").
			Offset((page * size) - size).
			Limit(size).
			Order("app_tweet.created desc").
			Find(&tweets).Count(&total).Error
	case TWEET_TAG_ID_POPULAR: //推荐
		err = session.
			Model(m).
			Select("*,b.user_id,d.attention_id as is_attention").
			Joins("INNER JOIN system_user AS b ON app_tweet.tweet_user_id = b.user_id").
			Joins("LEFT JOIN app_tweet_user AS c ON (app_tweet.tweet_id = c.user_tweet_id AND c.user_user_id = ?)", userId).
			Joins("LEFT JOIN app_attention AS d ON (app_tweet.tweet_user_id = d.attention_follow_user_id AND d.attention_user_id = ?)", userId).
			Joins("LEFT JOIN app_attention AS e ON ( app_tweet.tweet_user_id = e.attention_user_id AND e.attention_follow_user_id = ? ) ", userId).
			Where("app_tweet.tweet_status = ? and b.user_status < ?", TWEET_STATUS_OK, USER_STATUS_BAN).
			Where("`c`.`user_is_hidden` = ? OR `c`.`user_is_hidden` IS NULL", USER_IS_HIDDEN_NO).
			Where("( `app_tweet`.tweet_visible = 0 OR ( `app_tweet`.`tweet_visible` = 1 AND ( ( `d`.`attention_id` IS NOT NULL AND `e`.`attention_id` IS NOT NULL ) OR `app_tweet`.tweet_user_id = ? ) ) OR (`app_tweet`.`tweet_visible` = 2 AND ( `d`.`attention_id` IS NULL OR  `app_tweet`.tweet_user_id = ? ) ) )", userId, userId).
			Where("`app_tweet`.`tweet_user_id` NOT IN ( SELECT `blacklist_black_user_id` FROM `app_blacklist` WHERE blacklist_user_id = ? ) ", userId).
			Where("app_tweet.deleted = 0").
			Offset((page * size) - size).
			Limit(size).
			Order("app_tweet.tweet_read_count desc,app_tweet.tweet_comment_count desc,app_tweet.tweet_like_count desc").
			Find(&tweets).Count(&total).Error
	case TWEET_TAG_ID_RECOMMEND: //热门
		err = session.
			Model(m).
			Select("*,b.user_id,d.attention_id as is_attention").
			Joins("INNER JOIN system_user AS b ON app_tweet.tweet_user_id = b.user_id").
			Joins("LEFT JOIN app_tweet_user AS c ON (app_tweet.tweet_id = c.user_tweet_id AND c.user_user_id = ?)", userId).
			Joins("LEFT JOIN app_attention AS d ON (app_tweet.tweet_user_id = d.attention_follow_user_id AND d.attention_user_id = ?)", userId).
			Joins("LEFT JOIN app_attention AS e ON ( app_tweet.tweet_user_id = e.attention_user_id AND e.attention_follow_user_id = ? ) ", userId).
			Where("app_tweet.tweet_status = ? and b.user_status < ?", TWEET_STATUS_OK, USER_STATUS_BAN).
			Where("`c`.`user_is_hidden` = ? OR `c`.`user_is_hidden` IS NULL", USER_IS_HIDDEN_NO).
			Where("( `app_tweet`.tweet_visible = 0 OR ( `app_tweet`.`tweet_visible` = 1 AND ( ( `d`.`attention_id` IS NOT NULL AND `e`.`attention_id` IS NOT NULL ) OR `app_tweet`.tweet_user_id = ? ) ) OR (`app_tweet`.`tweet_visible` = 2 AND ( `d`.`attention_id` IS NULL OR  `app_tweet`.tweet_user_id = ? ) ) )", userId, userId).
			Where("`app_tweet`.`tweet_user_id` NOT IN ( SELECT `blacklist_black_user_id` FROM `app_blacklist` WHERE blacklist_user_id = ? ) ", userId).
			Where("app_tweet.deleted = 0").
			Offset((page * size) - size).
			Limit(size).
			Order("app_tweet.created desc").
			Find(&tweets).Count(&total).Error
	case TWEET_TAG_ID_LATEST: //最新
		err = session.
			Model(m).
			Select("*,b.user_id,d.attention_id as is_attention").
			Joins("INNER JOIN system_user AS b ON app_tweet.tweet_user_id = b.user_id").
			Joins("LEFT JOIN app_tweet_user AS c ON (app_tweet.tweet_id = c.user_tweet_id AND c.user_user_id = ?)", userId).
			Joins("LEFT JOIN app_attention AS d ON (app_tweet.tweet_user_id = d.attention_follow_user_id AND d.attention_user_id = ?)", userId).
			Joins("LEFT JOIN app_attention AS e ON ( app_tweet.tweet_user_id = e.attention_user_id AND e.attention_follow_user_id = ? ) ", userId).
			Where("app_tweet.tweet_status = ? and b.user_status < ?", TWEET_STATUS_OK, USER_STATUS_BAN).
			Where("`c`.`user_is_hidden` = ? OR `c`.`user_is_hidden` IS NULL", USER_IS_HIDDEN_NO).
			Where("( `app_tweet`.tweet_visible = 0 OR ( `app_tweet`.`tweet_visible` = 1 AND ( ( `d`.`attention_id` IS NOT NULL AND `e`.`attention_id` IS NOT NULL ) OR `app_tweet`.tweet_user_id = ? ) ) OR (`app_tweet`.`tweet_visible` = 2 AND ( `d`.`attention_id` IS NULL OR  `app_tweet`.tweet_user_id = ? ) ) )", userId, userId).
			Where("`app_tweet`.`tweet_user_id` NOT IN ( SELECT `blacklist_black_user_id` FROM `app_blacklist` WHERE blacklist_user_id = ? ) ", userId).
			Where("app_tweet.deleted = 0").
			Offset((page * size) - size).
			Limit(size).
			Order("app_tweet.created desc").
			Find(&tweets).Count(&total).Error
	}
	return
}

//QueryPageByMy 查询我的朋友圈
func (m *AppTweet) QueryPageByMy(page int, size int, userId int) (total int64, tweets []AppTweetJoin, err error) {
	err = utils.GEngine.Model(m).
		Select("*,b.user_id").
		Joins("INNER JOIN system_user AS b ON app_tweet.tweet_user_id = b.user_id").
		Joins("LEFT JOIN app_tweet_user AS c ON (app_tweet.tweet_id = c.user_tweet_id AND c.user_user_id = ?)", userId).
		Where("app_tweet.tweet_status = ? and b.user_status < ? and app_tweet.tweet_user_id = ?", TWEET_STATUS_OK, USER_STATUS_BAN, userId).
		Where("app_tweet.deleted = 0").
		Offset((page * size) - size).Limit(size).
		Order("app_tweet.created desc").
		Find(&tweets).Count(&total).Error
	return
}

//QueryPageByUserId 查询指定用户朋友圈
func (m *AppTweet) QueryPageByUserId(page int, size int, userId int, myUserId int64) (total int64, tweets []AppTweetJoin, err error) {
	err = utils.GEngine.Model(m).
		Select("*,b.user_id,d.attention_id as is_attention").
		Joins("INNER JOIN system_user AS b ON app_tweet.tweet_user_id = b.user_id").
		Joins("LEFT JOIN app_tweet_user AS c ON (app_tweet.tweet_id = c.user_tweet_id AND c.user_user_id = ?)", myUserId).
		Joins("LEFT JOIN app_attention AS d ON (app_tweet.tweet_user_id = d.attention_follow_user_id AND d.attention_user_id = ?)", myUserId).
		Joins("LEFT JOIN app_attention AS e ON ( app_tweet.tweet_user_id = e.attention_user_id AND e.attention_follow_user_id = ? ) ", myUserId).
		Where("app_tweet.tweet_status = ? and b.user_status < ? and app_tweet.tweet_user_id = ?", TWEET_STATUS_OK, USER_STATUS_BAN, userId).
		Where("`c`.`user_is_hidden` = ? OR `c`.`user_is_hidden` IS NULL", USER_IS_HIDDEN_NO).
		Where("( `app_tweet`.tweet_visible = 0 OR ( `app_tweet`.`tweet_visible` = 1 AND ( ( `d`.`attention_id` IS NOT NULL AND `e`.`attention_id` IS NOT NULL ) OR `app_tweet`.tweet_user_id = ? ) ) OR (`app_tweet`.`tweet_visible` = 2 AND ( `d`.`attention_id` IS NULL OR  `app_tweet`.tweet_user_id = ? ) ) )", userId, userId).
		Where("`app_tweet`.`tweet_user_id` NOT IN ( SELECT `blacklist_black_user_id` FROM `app_blacklist` WHERE blacklist_user_id = ? ) ", myUserId).
		Where("app_tweet.deleted = 0").
		Offset((page * size) - size).
		Limit(size).
		Order("app_tweet.created desc").
		Find(&tweets).Count(&total).Error
	return
}

// 大神详情朋友圈列表
func (m *AppTweet) QuerySparringDetailList(userId int) (tweets []AppTweetJoin, err error) {
	err = utils.GEngine.Model(m).Select("*,b.user_id").Joins("INNER JOIN system_user AS b ON app_tweet.tweet_user_id = b.user_id").
		Where("app_tweet.tweet_status = ? and b.user_status < ? and app_tweet.tweet_user_id = ?", TWEET_STATUS_OK, USER_STATUS_BAN, userId).
		Where("app_tweet.tweet_type = ? OR app_tweet.tweet_type = ?", TWEET_TYPE_IMAGE, TWEET_TYPE_VIDEO).Limit(10).Order("app_tweet.created desc").
		Find(&tweets).Error
	return
}

//AddCommentCount 增加评论数
func (m *AppTweet) AddCommentCount(tx *gorm.DB, id int64) {
	sql := "update `app_tweet` set tweet_comment_count = tweet_comment_count+1 where tweet_id = ? "
	tx.Exec(sql, id)
}

//DecreaseLikeCount  减少点赞
func (m *AppTweet) DecreaseLikeCount(tx *gorm.DB, id int64) {
	sql := "update `app_tweet` set tweet_like_count = tweet_like_count-1 where tweet_id = ? "
	err := tx.Exec(sql, id)
	if err != nil {
		fmt.Println(err)
	}
}

//AddLikeCount  增加点赞
func (m *AppTweet) AddLikeCount(id int64) {
	sql := "update `app_tweet` set tweet_like_count = tweet_like_count+1 where tweet_id = ? "
	err := utils.GEngine.Exec(sql, id).Error
	if err != nil {
		fmt.Println(err)
	}
}

//AddReadCount 增加阅读数
func (m *AppTweet) AddReadCount(id int64) {
	sql := "update `app_tweet` set tweet_read_count = tweet_read_count+1 where tweet_id = ? "
	err := utils.GEngine.Exec(sql, id).Error
	if err != nil {
		fmt.Println(err)
	}
}

//QueryExist 查询是否存在
func (m *AppTweet) QueryExist(id int64) (has int64, data AppTweet, err error) {
	model := utils.GEngine.Model(m).Where("tweet_id = ?", id).Where("deleted = 0").First(&data)
	has = model.RowsAffected
	err = model.Error
	return
}

//QueryById 根据id查询
func (m *AppTweet) QueryById(id int) (has int64, data AppTweet, err error) {
	model := utils.GEngine.Where("tweet_id = ?", id).Where("deleted = 0").First(&data)
	has = model.RowsAffected
	err = model.Error
	return
}

//in查询
func (m *AppTweet) QueryIn(ids []int, userId int64) (data []AppTweetJoin, err error) {
	err = utils.GEngine.Model(m).
		Select("*,b.user_id").
		Joins("INNER JOIN system_user AS b ON app_tweet.tweet_user_id = b.user_id").
		Joins("LEFT JOIN app_tweet_user AS c ON (app_tweet.tweet_id = c.user_tweet_id AND c.user_user_id = ?)", userId).
		Where("tweet_id IN ?", ids).
		Where("app_tweet.deleted = 0").
		Order("app_tweet.created desc").
		Find(&data).Error
	return
}

//in查询热门朋友圈
func (m *AppTweet) QueryPopularIn(ids []int, userId int64) (tweets []AppTweetJoin, err error) {
	err = utils.GEngine.Model(m).
		Select("*,b.user_id,d.attention_id as is_attention").
		Joins("INNER JOIN system_user AS b ON app_tweet.tweet_user_id = b.user_id").
		Joins("LEFT JOIN app_tweet_user AS c ON (app_tweet.tweet_id = c.user_tweet_id AND c.user_user_id = ?)", userId).
		Joins("LEFT JOIN app_attention AS d ON (app_tweet.tweet_user_id = d.attention_follow_user_id AND d.attention_user_id = ?)", userId).
		Joins("LEFT JOIN app_attention AS e ON ( app_tweet.tweet_user_id = e.attention_user_id AND e.attention_follow_user_id = ? ) ", userId).
		Where("app_tweet.tweet_status = ? and b.user_status < ?", TWEET_STATUS_OK, USER_STATUS_BAN).
		Where("tweet_id IN ?", ids).
		Where("app_tweet.deleted = 0").
		Find(&tweets).Error
	return
}

//软删除
func (m *AppTweet) SoftDelete(tweetId int64) (err error) {
	update := make(map[string]interface{})
	update["deleted"] = time.Now().Unix()
	update["tweet_status"] = TWEET_STATUS_USER_DEL
	err = utils.GEngine.Model(m).Where("tweet_id = ?", tweetId).Updates(update).Error
	return
}
