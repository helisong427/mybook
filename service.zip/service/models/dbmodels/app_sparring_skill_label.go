package dbmodels

import (
	"fmt"
	"gamers/utils"
	"strconv"
	"strings"

	"github.com/go-redis/redis"

	"gorm.io/gorm"
)

type AppSparringSkillLabel struct {
	ID                   uint64 `json:"id" gorm:"column:id"`
	SparringLabelUserID  int64  `json:"sparring_label_user_id" gorm:"column:sparring_label_user_id"`   // 大神id
	SparringLabelSkillID int64  `json:"sparring_label_skill_id" gorm:"column:sparring_label_skill_id"` // 大神技能id
	SparringLabelID      int64  `json:"sparring_label_id" gorm:"column:sparring_label_id"`             // 大神技能标签id
	SparringLabelNum     int64  `json:"sparring_label_num" gorm:"column:sparring_label_num"`           // 大神技能标签数量
	SparringLabelName    string `json:"sparring_label_name" gorm:"-"`                                  // 标签名称
}

type SkillCommentLabel struct {
	Key   string //标签id:技能名称
	Value int64  //标签数量
}

func (m *AppSparringSkillLabel) TableName() string {
	return "app_sparring_skill_label"
}

// 有则更新 没有则创建
func (m *AppSparringSkillLabel) Update(tx *gorm.DB, sparringId, skillId, labelId int64) (err error) {

	var data AppSparringSkillLabel
	err = tx.Model(m).Where("sparring_label_user_id=?", sparringId).
		Where("sparring_label_skill_id=?", skillId).
		Where("sparring_label_id=?", labelId).First(&data).Error
	if err != nil {
		// 没有对应记录 则创建
		if err == gorm.ErrRecordNotFound {
			data.SparringLabelUserID = sparringId
			data.SparringLabelSkillID = skillId
			data.SparringLabelID = labelId
			data.SparringLabelNum = 1

			err = tx.Model(m).Create(&data).Error
			if err != nil {
				return
			}
		} else {
			return
		}
	} else {
		err = tx.Model(m).Where("id=?", data.ID).Updates(map[string]interface{}{
			"sparring_label_num": data.SparringLabelNum + 1,
		}).Error
		if err != nil {
			return
		}
	}
	return
}

//查询大神技能标签
func (m *AppSparringSkillLabel) Query(skillId int64) (res []*AppSparringSkillLabel, err error) {
	var data []SkillCommentLabel

	result, _, err := utils.RedisClient.HScan(fmt.Sprintf("%s%d", utils.REDIS_SPARRING_SKILL_LABEL, skillId), 0, "*", 1000).Result()
	if err != nil && err != redis.Nil {
		return
	}
	if err == nil && len(result) != 0 {

		// 拆解hScan的key value
		for i := 0; i < len(result)-1; i++ {
			var skillCommentLabel SkillCommentLabel
			skillCommentLabel.Key = result[i]
			value, _ := strconv.Atoi(result[i+1])
			skillCommentLabel.Value = int64(value)
			data = append(data, skillCommentLabel)
			i++
		}

		for _, v := range data {
			split := strings.Split(v.Key, ":")
			if len(split) != 2 {
				utils.LogErrorF("大神技能标签缓存错误")
				continue
			}
			appSparringSkillLabel := new(AppSparringSkillLabel)
			// 技能id
			appSparringSkillLabel.SparringLabelSkillID = skillId
			// 标签id
			sparringLabelId, _ := strconv.Atoi(split[0])
			appSparringSkillLabel.SparringLabelID = int64(sparringLabelId)
			// 标签名称
			appSparringSkillLabel.SparringLabelName = split[1]
			// 标签数量
			appSparringSkillLabel.SparringLabelNum = v.Value
			res = append(res, appSparringSkillLabel)
		}
		return
	}

	// 未取到缓存从数据库中取
	err = utils.GEngine.Model(m).Where("sparring_label_skill_id=?", skillId).Find(&res).Error
	if err != nil {
		return nil, err
	}
	for _, v := range res {
		if v.SparringLabelID == 0 {
			continue
		}
		name, err := new(AppSkillLabel).GetSkillLabelName(v.SparringLabelID)
		if err != nil {
			continue
		}
		v.SparringLabelName = name
		utils.RedisClient.HSet(fmt.Sprintf("%s%d", utils.REDIS_SPARRING_SKILL_LABEL, v.SparringLabelSkillID), fmt.Sprintf("%d:%s", v.SparringLabelID, v.SparringLabelName), v.SparringLabelNum)
	}
	return
}
