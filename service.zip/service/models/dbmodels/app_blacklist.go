package dbmodels

import (
	"gamers/controller/response"
	"gamers/utils"
	"gorm.io/gorm"
)

// 黑名单
type AppBlacklist struct {
	BlacklistId          int64      `gorm:"column:blacklist_id;primaryKey;autoIncrement"` // 黑名单自增主键
	BlacklistUserId      int64      `gorm:"column:blacklist_user_id"`                     // 拉黑用户
	BlacklistBlackUserId int64      `gorm:"column:blacklist_black_user_id"`               // 被拉黑的用户id
	BaseModel            BaseModel  `gorm:"embedded" json:"-"`
	BlackUser            SystemUser `gorm:"foreignKey:BlacklistBlackUserId;references:UserID;" json:"black_user"` //关注列表
}

func (AppBlacklist) TableName() string {
	return "app_blacklist"
}

// Create 创建黑名单
func (m *AppBlacklist) Create() (err error) {
	err = utils.GEngine.Create(m).Error
	return

}

// Delete 删除用户关注
func (m *AppBlacklist) Delete(blacklistUserId, blacklistBanUserId int64) (err error) {
	err = utils.GEngine.Model(m).Where("blacklist_user_id = ? and blacklist_black_user_id = ?", blacklistUserId, blacklistBanUserId).Delete(m).Error
	return
}

// 查询黑名单是否存在
func (m *AppBlacklist) Exists(blacklistUserId, blacklistBanUserId int64) (data AppBlacklist, err error) {
	err = utils.GEngine.Where("blacklist_user_id = ? and blacklist_black_user_id = ?", blacklistUserId, blacklistBanUserId).First(&data).Error
	return
}

// 获取黑名单列表
func (m *AppBlacklist) GetBlacklistByUserId(blacklistUserId int64, size, skip int) (data []response.GetBlacklistResp, err error, total int64) {
	err = utils.GEngine.Table("app_blacklist").Preload("BlackUser", func(db *gorm.DB) *gorm.DB {
		return db.Table("system_user").Select("user_id,user_nickname,user_gender,user_iconurl,user_birthday")
	}).Where("blacklist_user_id = ? and deleted = 0", blacklistUserId).Order("edited desc").Limit(size).Offset(skip).Find(&data).Count(&total).Error
	return
}

func (m *AppBlacklist) GetBlackByUid(blackUid, blackBlackUid int64) (black AppBlacklist, err error) {
	err = utils.GEngine.Model(m).Where("deleted = 0").Where("blacklist_user_id = ?", blackUid).Where("blacklist_black_user_id=?", blackBlackUid).First(&blackBlackUid).Error

	return
}
