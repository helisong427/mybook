package dbmodels

import (
	"gamers/utils"
	"gamers/utils/prop"
	"gamers/utils/ymd"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
	"time"
)

type AppEggBreakRankWeek struct {
	RankId         int       `gorm:"column:rank_id" json:"rank_id"`
	RankEggbreakId int       `gorm:"column:rank_eggbreak_id" json:"rank_eggbreak_id"`
	RankUserId     int64     `gorm:"column:rank_user_id" json:"rank_user_id"`
	RankPeriod     int       `gorm:"column:rank_period" json:"rank_period"`
	RankTotalPrice int64     `gorm:"column:rank_total_price" json:"rank_total_price"`
	BaseModel      BaseModel `gorm:"embedded" json:"-"`
	TriggerTime    time.Time `gorm:"-" json:"trigger_time"` // 触发时间 --> 用于计算 rank_period (或者以后表名???)
}

func (AppEggBreakRankWeek) TableName() string {
	return "app_eggbreak_week_rank"
}

func (r *AppEggBreakRankWeek) Format() {
	r.RankPeriod = ymd.GetWeekDigit(r.TriggerTime)
}

func (r *AppEggBreakRankWeek) Log() {
	r.Format()

	// unique_key: rank_user_id rank_period rank_eggbreak_id
	_ = utils.GEngine.Clauses(clause.OnConflict{
		Columns: []clause.Column{
			{Name: "rank_user_id"},
			{Name: "rank_period"},
			{Name: "rank_eggbreak_id"},
		},
		DoUpdates: clause.Assignments(map[string]interface{}{
			"rank_total_price": gorm.Expr("rank_total_price + ?", r.RankTotalPrice),
		}),
	}).Create(r).Error
}

type AppEggBreakRankDetailWeek struct {
	DetailId         int       `gorm:"column:detail_id" json:"detail_id"`
	DetailEggbreakId int       `gorm:"column:detail_eggbreak_id" json:"detail_eggbreak_id"`
	DetailUserId     int64     `gorm:"column:detail_user_id" json:"detail_user_id"`
	DetailPeriod     int       `gorm:"column:detail_period" json:"detail_period"`
	DetailPropType   prop.Type `gorm:"column:detail_prop_type" json:"detail_prop_type"`
	DetailPropId     int       `gorm:"column:detail_prop_id" json:"detail_prop_id"`
	DetailPropCount  int       `gorm:"column:detail_prop_count" json:"detail_prop_count"`
	BaseModel        BaseModel `gorm:"embedded" json:"-"`
	TriggerTime      time.Time `gorm:"-" json:"trigger_time"` // 触发时间 --> 用于计算 rank_period (或者以后表名???)
}

func (AppEggBreakRankDetailWeek) TableName() string {
	return "app_eggbreak_week_rank_detail"
}

func (d *AppEggBreakRankDetailWeek) Format() {
	d.DetailPeriod = ymd.GetWeekDigit(d.TriggerTime)
}

func (d *AppEggBreakRankDetailWeek) Log() {
	d.Format()

	var ret = AppEggBreakRankDetailWeek{}
	var err = utils.GEngine.Model(d).Where("detail_user_id = ? and detail_period = ? and detail_eggbreak_id = ? and detail_prop_type = ? and detail_prop_id = ?",
		d.DetailUserId, d.DetailPeriod, d.DetailEggbreakId, d.DetailPropType, d.DetailPropId).Find(&ret).Error

	if err == nil {
		if ret.DetailId == 0 {
			_ = utils.GEngine.Create(d).Error
		} else {
			_ = utils.GEngine.Model(d).Where("detail_id = ?", ret.DetailId).Updates(map[string]interface{}{
				"detail_prop_count": gorm.Expr("detail_prop_count + ?", d.DetailPropCount),
			}).Error
		}
	} else if err == gorm.ErrRecordNotFound {
		_ = utils.GEngine.Create(d).Error
	} else {
		utils.LogErrorF("记录 AppEggBreakRankDetailWeek 失败：%s，%v", err.Error(), d)
	}
}
