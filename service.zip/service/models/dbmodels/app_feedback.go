package dbmodels

import (
	"gamers/utils"
)

//意见反馈
type AppFeedback struct {
	FeedbackId       int64     `gorm:"column:feedback_id;primaryKey;autoIncrement"` // 黑名单自增主键
	FeedbackUserId   int64     `gorm:"column:feedback_user_id"`                     //
	FeedbackContent  string    `gorm:"column:feedback_content"`                     //
	FeedbackChannel  int       `gorm:"column:feedback_channel"`                     //反馈渠道(1官网,2AppStore,3华为)
	FeedbackTerminal int       `gorm:"column:feedback_terminal"`                    //反馈终端(1Android,2ios3web)
	FeedbackStatus   int       `gorm:"column:feedback_status"`                      //反馈状态(0待处理,1正常处理,2拒绝处理)
	BaseModel        BaseModel `gorm:"embedded" json:"-"`
}

func (AppFeedback) TableName() string {
	return "app_feedback"
}

// FeedbackAdd 创建反馈
func (afb *AppFeedback) FeedbackAdd() (err error) {
	err = utils.GEngine.Create(&afb).Error
	return
}
