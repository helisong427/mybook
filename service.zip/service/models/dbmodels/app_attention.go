package dbmodels

import "gamers/utils"

// 用户关注表
type AppAttention struct {
	AttentionID           int64      `json:"attention_id" gorm:"column:attention_id;primaryKey;autoIncrement"`
	AttentionUserID       int64      `json:"attention_user_id"`        // 关注的主用户id
	AttentionFollowUserID int64      `json:"attention_follow_user_id"` // 被关注的用户id
	BaseModel             BaseModel  `gorm:"embedded" json:"base_model"`
	FollowSystemUser      SystemUser `gorm:"foreignKey:AttentionFollowUserID;references:UserID;" json:"follow_system_user"` // 关注列表
	FollowedSystemUser    SystemUser `gorm:"foreignKey:AttentionUserID;references:UserID;" json:"followed_system_user"`     // 粉丝列表
}

func (AppAttention) TableName() string {
	return "app_attention"
}

type AppAttentionJoin struct {
	UserID       int64  `gorm:"column:user_id"`
	UserNickname string `gorm:"column:user_nickname"` // 昵称
	UserGender   int    `gorm:"column:user_gender"`   // 用户性别0未知,1男,2女
	UserIconurl  string `gorm:"column:user_iconurl"`  // 头像
	UserSlogan   string `gorm:"column:user_slogan"`   // 用户签名
	UserBirthday int64  `gorm:"column:user_birthday"` // 出生年月日
}

// Create 创建
func (m *AppAttention) Create() (err error) {
	err = utils.GEngine.Create(m).Error
	return
}

// QueryByUserID 根据主用户id查询
func (m *AppAttention) QueryByUserID(attentionUserId int) (data []AppAttention, err error) {
	err = utils.GEngine.Where("attention_user_id = ?", attentionUserId).Find(&data).Error
	return
}

// 查询是否存在
func (m *AppAttention) QueryExist(attentionUserId, attentionFollowUserId int) (result int64, err error) {
	dba := utils.GEngine.Where("attention_user_id = ? and attention_follow_user_id = ?", attentionUserId, attentionFollowUserId).First(m)
	return dba.RowsAffected, dba.Error
}

// Delete 删除用户关注
func (m *AppAttention) Delete(attentionUserId, attentionFollowUserId int) (err error) {
	err = utils.GEngine.Where("attention_user_id = ? and attention_follow_user_id = ?", attentionUserId, attentionFollowUserId).Delete(m).Error
	return
}

// GetUserFollowCount 获取用户关注的数量(关注数)
func (m *AppAttention) GetUserFollowCount(userId int64) (total int64, err error) {
	err = utils.GEngine.Model(m).Where("attention_user_id = ?", userId).Count(&total).Error
	return
}

// GetUserFollowedCount 获取被关注的数量(粉丝数)
func (m *AppAttention) GetUserFollowedCount(userId int64) (total int64, err error) {
	err = utils.GEngine.Model(m).Where("attention_follow_user_id = ?", userId).Count(&total).Error
	return
}

// QueryPageFollow 分页查询关注
func (m *AppAttention) QueryPageFollow(userId int64, page int, size int, isOnline int) (total int64, data []AppAttention, err error) {
	model := utils.GEngine.Model(m)
	if isOnline == 1 {
		model = model.Joins("INNER JOIN system_user AS u ON app_attention.attention_follow_user_id = u.user_id").Where("u.user_is_online = 1")
	}
	err = model.Preload("FollowSystemUser").
		Where("attention_user_id = ?", userId).
		Offset((page * size) - size).Limit(size).
		Order("app_attention.created desc").
		Find(&data).Count(&total).Error
	return
}

// QueryPageFollowed 分页查询粉丝
func (m *AppAttention) QueryPageFollowed(userId int64, page int, size int, isOnline int) (total int64, data []AppAttention, err error) {
	model := utils.GEngine.Model(m)
	if isOnline == 1 {
		model = model.Joins("INNER JOIN system_user AS u ON app_attention.attention_user_id = u.user_id").Where("u.user_is_online = 1")
	}
	err = model.Preload("FollowedSystemUser").
		Where("attention_follow_user_id = ?", userId).
		Offset((page * size) - size).Limit(size).
		Order("app_attention.created desc").
		Find(&data).Count(&total).Error
	return
}

// QueryFollowIn 查询是关注否互相关注
func (m *AppAttention) QueryFollowIn(userIds []int64, userId int64) (data []AppAttention, err error) {
	err = utils.GEngine.Model(m).Where("attention_user_id IN ?", userIds).Where("attention_follow_user_id = ?", userId).Find(&data).Error
	return
}

// QueryFollowIn 查询粉丝是否互相关注
func (m *AppAttention) QueryFollowedIn(userIds []int64, userId int64) (data []AppAttention, err error) {
	err = utils.GEngine.Model(m).Where("attention_follow_user_id IN ?", userIds).Where("attention_user_id = ?", userId).Find(&data).Error
	return
}

// 查询是否关注某用户
// userId 关注的主用户id
// followUserId 被关注的用户id
func (m *AppAttention) QueryFollowed(userId int64, followUserId int64) (row int64, err error) {
	model := utils.GEngine.Model(m).Where("attention_user_id = ? and attention_follow_user_id = ? and deleted = 0 ", userId, followUserId).First(m)
	row = model.RowsAffected
	err = model.Error
	return
}
