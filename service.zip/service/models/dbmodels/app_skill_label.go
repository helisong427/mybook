package dbmodels

import (
	"encoding/json"
	"fmt"
	"gamers/utils"
	"github.com/go-redis/redis"
)

type AppSkillLabel struct {
	LabelID         uint64 `json:"label_id" gorm:"primaryKey;autoIncrement;column:label_id"`
	LabelSkillID    uint64 `json:"label_skill_id" gorm:"column:label_skill_id"`     // 技能id
	LabelName       string `json:"label_name" gorm:"column:label_name"`             // 标签名称
	LabelOrder      *int64 `json:"label_order" gorm:"column:label_order"`           // 标签权重
	LabelEvaluation *int64 `json:"label_evaluation" gorm:"column:label_evaluation"` // 标签评价 (0好评，1差评)
	BaseModel
}

func (m *AppSkillLabel) TableName() string {
	return "app_skill_label"
}

func (m *AppSkillLabel) GetSkillLabel(skillId int64) (data []*AppSkillLabel, err error) {
	redisLabel, err := utils.RedisClient.Get(fmt.Sprintf("%s%d", utils.REDIS_COMMENT_LABEL, skillId)).Result()
	// 如果存在
	if err == nil {
		_ = json.Unmarshal([]byte(redisLabel), &data)
		return
	}
	// 如果不存在
	if err == redis.Nil {
		err = utils.GEngine.Model(m).Where("label_skill_id=?", skillId).Find(&data).Error
		if err != nil {
			return
		}
		marshal, _ := json.Marshal(data)
		utils.RedisClient.Set(fmt.Sprintf("%s%d", utils.REDIS_COMMENT_LABEL, skillId), marshal, 0)
	}
	return
}

func (m *AppSkillLabel) GetSkillLabelById(labelId []string) (data []string, err error) {
	err = utils.GEngine.Model(m).Select("label_name").Where("label_id in (?)", labelId).Find(&data).Error
	return
}

// 获取标签名称
func (m *AppSkillLabel) GetSkillLabelName(labelId int64) (data string, err error) {
	err = utils.GEngine.Model(m).Select("label_name").Where("label_id=?", labelId).First(&data).Error
	return
}
