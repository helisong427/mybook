package dbmodels

import (
	"gamers/controller/response"
	"gamers/utils"
	"time"

	"gorm.io/gorm"
)

// 技能订单表
type AppSkillOrder struct {
	OrderId              int64               `gorm:"column:order_id;primaryKey;autoIncrement" json:"order_id"`
	OrderBuyUserId       int64               `gorm:"column:order_buy_user_id" json:"order_buy_user_id"` // 买家id
	OrderBuyUserUnionId  int64               `gorm:"column:order_buy_user_union_id" json:"order_buy_user_union_id"`
	OrderSellUserId      int64               `gorm:"column:order_sell_user_id" json:"order_sell_user_id"` // 卖家id
	OrderSellUserUnionId int64               `gorm:"column:order_sell_user_union_id" json:"order_sell_user_union_id"`
	OrderSkillId         int64               `gorm:"column:order_skill_id" json:"order_skill_id"`                   // 游戏id
	OrderSparringSkillId int64               `gorm:"column:order_sparring_skill_id" json:"order_sparring_skill_id"` // 购买的大神技能id
	OrderPrice           int64               `gorm:"column:order_price" json:"order_price"`                         // 单价
	OrderWay             string              `gorm:"column:order_way" json:"order_way"`                             // 方式
	OrderTime            int64               `gorm:"column:order_time" json:"order_time"`                           // 陪玩方式   时长  单位分钟
	OrderProtectionTime  int64               `gorm:"column:order_protection_time" json:"order_protection_time"`     // 保护时间
	OrderCount           int64               `gorm:"column:order_count" json:"order_count"`                         // 数量
	OrderAmount          int64               `gorm:"column:order_amount" json:"order_amount"`                       // 订单总金额代币
	OrderUnionFee        int64               `gorm:"column:order_union_fee" json:"order_union_fee"`                 // 公会手续费
	OrderFee             int64               `gorm:"column:order_fee" json:"order_fee"`                             // 平台手续费代币
	OrderIncome          int64               `gorm:"column:order_income" json:"order_income"`                       // 卖家收益代币
	OrderType            int                 `gorm:"column:order_type"`                                             // 订单类型(0定向单,1随机单)
	OrderStatus          int                 `gorm:"column:order_status" json:"order_status"`                       // 订单状态(1付款,2接单,3取消,4退款,5申诉,6完成,7评价,8结算)
	OrderPayStatus       int                 `gorm:"column:order_pay_status" json:"order_pay_status"`               // 支付状态(0待付款,1付款中,2已付款)
	OrderPayTime         int64               `gorm:"column:order_pay_time" json:"order_pay_time"`                   // 订单支付时间
	OrderConfirmStatus   int                 `gorm:"column:order_confirm_status" json:"order_confirm_status"`       // 接单状态(0待接单,1大神拒绝,2大神结单,3大神完成)
	OrderConfirmTime     int64               `gorm:"column:order_confirm_time" json:"order_confirm_time"`           // 接单时间
	OrderCancelStatus    int                 `gorm:"column:order_cancel_status" json:"order_cancel_status"`         // 取消状态(0未取消,1玩家取消,2大神取消,3系统取消)
	OrderCancelTime      int64               `gorm:"column:order_cancel_time" json:"order_cancel_time"`             // 订单取消时间
	OrderCancelClient    int                 `gorm:"column:order_cancel_client" json:"order_cancel_client"`         //  取消终端(0系统取消,1Android,2ios,3web)
	OrderRefundStatus    int                 `gorm:"column:order_refund_status" json:"order_refund_status"`         // 退款状态(0未退款,1申请退款,2取消退款,3大神同意退款,4大神拒绝退款,5系统自动退款)
	OrderRefundTime      int64               `gorm:"column:order_refund_time" json:"order_refund_time"`             // 退款时间
	OrderRefundId        int64               `gorm:"column:order_refund_id" json:"order_refund_id"`                 // 当前退款id
	OrderRefundCount     int                 `gorm:"column:order_refund_count" json:"order_refund_count"`           // 退款申请次数
	OrderAppealStatus    int                 `gorm:"column:order_appeal_status" json:"order_appeal_status"`         // 申诉状态(0未申诉,1申诉中待大神举证,2待客服处理,3处理完成大神胜诉,4处理完成玩家胜诉)
	OrderAppealTime      int64               `gorm:"column:order_appeal_time" json:"order_appeal_time"`             // 申诉时间
	OrderFinishStatus    int                 `gorm:"column:order_finish_status" json:"order_finish_status"`         // 完成状态(0未完成,1系统自动完成,3玩家完成)
	OrderFinishTime      int64               `gorm:"column:order_finish_time" json:"order_finish_time"`             // 订单完成时间
	OrderIsFinished      int                 `json:"order_is_finished" gorm:"column:order_is_finished"`             // 订单是否完成
	OrderCommentStatus   int                 `gorm:"column:order_comment_status" json:"order_comment_status"`       // 评价状态(0不能评价 1待评价,2玩家已评价,3大神已评价)
	OrderRemark          string              `gorm:"column:order_remark" json:"order_remark"`                       // 下单备注
	OrderClient          int                 `gorm:"column:order_client" json:"order_client"`                       // 下单终端(1Android,2ios,3web)
	OrderSettleStatus    int                 `gorm:"column:order_settle_status" json:"order_settle_status"`         // 订单结算(提取)状态(0未结算,1系统自动已结算,2客服结算)
	OrderSettleTime      int64               `gorm:"column:order_settle_time" json:"order_settle_time"`             // 订单结算(提取)时间
	OrderDeleteStatus    int                 `gorm:"column:order_delete_status" json:"order_delete_status"`         // 订单删除状态(0正常,1回收站,2已删除)
	AppSkillOrderRefund  AppSkillOrderRefund `gorm:"foreignKey:RefundId;references:OrderRefundId"`                  // 关联退款表
	AppSkillOrderAppeal  AppSkillOrderAppeal `gorm:"foreignKey:OrderId;references:AppealOrderId"`                   // 关联申诉表
	AppSkill             AppSkill            `gorm:"foreignKey:OrderSkillId;references:SkillId"`                    // 关联基础技能
	SellSystemUser       SystemUser          `gorm:"foreignKey:UserID;references:OrderSellUserId"`                  // 关联出售订单用户信息
	BuySystemUser        SystemUser          `gorm:"foreignKey:UserID;references:OrderBuyUserId"`                   // 关联购买订单用户信息
	BaseModel            BaseModel           `gorm:"embedded" json:"-"`
}

func (AppSkillOrder) TableName() string {
	return "app_skill_order"
}

// 关联结构体
type AppSkillOrderJoin struct {
	OrderId           int64
	DetailGameId      int64
	UserNickname      string
	GameIconurl       string
	GameName          string
	DetailValue       int64
	OrderCount        int64
	OrderRemark       string
	OrderAmount       int64
	OrderFee          int64
	OrderStatus       int
	OrderPayStatus    int
	OrderRefundStatus int
	OrderTime         int64
	OrderConfirmTime  int64
	OrderCancelTime   int64
	OrderFinishTime   int64
	OrderPayTime      int64
	OrderSellUserID   int64
	OrderBuyUserId    int64
}

// 订单主状态
const (
	SKILL_ORDER_STATUS_PAY        = iota + 1 // 付款状态
	SKILL_ORDER_STATUS_CONFIRM               // 接单状态
	SKILL_ORDER_STATUS_CANCEL                // 取消状态
	SKILL_ORDER_STATUS_REFUND                // 退款状态
	SKILL_ORDER_STATUS_APPEAL                // 申述状态
	SKILL_ORDER_STATUS_FINISH                // 完成状态
	SKILL_ORDER_STATUS_COMMENT               // 评价状态
	SKILL_ORDER_STATUS_SETTLEMENT            // 结算状态
)

// 支付状态
const (
	SKILL_ORDER_PAY_STATUS_UNPAID int = iota // 待付款
	SKILL_ORDER_PAY_STATUS_PAID              // 已付款
)

// 接单状态
const (
	SKILL_ORDER_CONFIRM_STATUS_NO     = iota // 未接单
	SKILL_ORDER_CONFIRM_STATUS_REFUSE        // 拒绝接单
	SKILL_ORDER_CONFIRM_STATUS_ACCEPT        // 已接单
	SKILL_ORDER_CONFIRM_STATUS_FINISH        // 大神完成
)

// 取消状态
const (
	SKILL_ORDER_CANCEL_STATUS_NO       = iota // 未取消
	SKILL_ORDER_CANCEL_STATUS_USER            // 用户取消
	SKILL_ORDER_CANCEL_STATUS_SPARRING        // 大神取消
	SKILL_ORDER_CANCEL_STATUS_SYSTEM          // 系统取消
)

// 完成状态
const (
	SKILL_ORDER_FINISH_STATUS_NO     = iota // 未完成
	SKILL_ORDER_FINISH_STATUS_SYSTEM        // 系统完成
	SKILL_ORDER_FINISH_STATUS_USER          // 玩家完成
)

// 退款状态
const (
	SKILL_ORDER_REFUND_STATUS_NO              int = iota // 未退款
	SKILL_ORDER_REFUND_STATUS_REFUNDING                  // 退款中
	SKILL_ORDER_REFUND_STATUS_CANCEL                     // 取消退款
	SKILL_ORDER_REFUND_STATUS_SPARRING_OK                // 同意退款
	SKILL_ORDER_REFUND_STATUS_SPARRING_REFUSE            // 拒绝退款
	SKILL_ORDER_REFUND_STATUS_SYS_OK                     // 系统自动退款完成

)

// 申述状态
const (
	SKILL_ORDER_APPEAL_STATUS_NO          int = iota // 未申诉
	SKILL_ORDER_APPEAL_STATUS_ING                    // 申诉中，待大神举证
	SKILL_ORDER_APPEAL_STATUS_PENDING                // 待处理，大神已提交资料
	SKILL_ORDER_APPEAL_STATUS_SPARRING_OK            // 处理完成大神胜利
	SKILL_ORDER_APPEAL_STATUS_USER_OK                // 处理完成,用户胜利
)

// 订单结算状态
const (
	SKILL_ORDER_SETTLE_STATUS_NO      int = iota // 未结算
	SKILL_ORDER_SETTLE_STATUS_SYS_OK             // 系统自动结算
	SKILL_ORDER_SETTLE_STATUS_KEFU_OK            // 客服已结算
)

// 评价状态
const (
	SKILL_ORDER_COMMENT_STATUS_NO      int = iota // 不能评价
	SKILL_ORDER_COMMENT_STATUS_WAIT               // 待评价  (用户自己完成  系统自己完成  申述大神胜利 --> 评论状态到达此)
	SKILL_ORDER_COMMENT_STATUS_OK                 // 玩家已评价
	SKILL_ORDER_COMMENT_STATUS_REPLIED            // 已回复
)

// 订单删除状态
const (
	SKILL_ORDER_DELETE_STATUS_OK      int = iota // 正常
	SKILL_ORDER_DELETE_STATUS_RECYCLE            // 回收站
	SKILL_ORDER_DELETE_STATUS_DELETE             // 删除
)

// 终端
const (
	SKILL_ORDER_CLIENT_ANDROID int = iota // 安卓
	SKILL_ORDER_CLIENT_IOS                // iOS
	SKILL_ORDER_CLIENT_WEB                // web
)

// 过期时间
const (
	SKILL_ORDER_ORDER_TIME     = 60 * 15          // 接单过期时间15分钟
	SKILL_ORDER_REFUND_TIME    = 60 * 60 * 12     // 订单自动退款时间24小时
	SKILL_ORDER_CONFIRM_TIME   = 60 * 60 * 24     // 订单完成后待确定时间，自动完成的时间
	SKILL_ORDER_CONFIRM_APPEAL = 60 * 60 * 24     // 订单自动完成以后可以申诉时间
	SKILL_ORDER_APPEAL_TIME    = 60 * 60 * 24     // 订单申诉以后大神可提交资料时间
	SKILL_ORDER_SETTLE_TIME    = 60 * 60 * 24 * 3 // 结算时间 3天
	SKILL_ORDER_SYSTEM_COMMENT = 60 * 60 * 24 * 7 // 系统自动评价时间 7天
)

const (
	SKILL_ORDER_REFUND_TYPE_ALL = iota // 全额退款
)
const (
	SKILL_ORDER_REFUND_COUNT_MAX = 2
)

const (
	SKILL_ORDER_CONFIRM_REFUSE = iota
	SKILL_ORDER_CONFIRM_SURE
)
const (
	SKILL_ORDER_IS_FINISHED_NO = iota // 订单未完成
	SKILL_ORDER_IS_FINISHED_OK        // 订单已完成
)

const (
	// 订单类型
	SKILL_TYPE_ORIENTATION int = iota // 定向单
	SKILL_TYPE_RAND                   // 随机单
)

// Create 创建订单
func (m *AppSkillOrder) Create(tx *gorm.DB) (err error) {
	err = tx.Model(m).Create(m).Error
	return
}

// Update 更新订单信息
func (m *AppSkillOrder) Update(tx *gorm.DB, orderId int64) (err error) {
	err = tx.Model(m).Where("order_id = ? and order_delete_status = ?", orderId, SKILL_ORDER_DELETE_STATUS_OK).Updates(m).Error
	return
}

// QueryByOrderId 获取订单
func (m *AppSkillOrder) QueryByOrderId(orderId int64) (row int64, data AppSkillOrder, err error) {
	model := utils.GEngine.Model(m).
		Preload("AppSkill", func(db *gorm.DB) *gorm.DB {
			return db.Table("app_skill").Select("skill_id,skill_name,skill_iconurl")
		}).Where("order_id = ? and order_delete_status = ?", orderId, SKILL_ORDER_DELETE_STATUS_OK).First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

// 根据出售订单用户id获取订单
func (m *AppSkillOrder) GetOrdersBySparringId(sellerId int64, size, skip int) (result []response.SkillOrderBySparringRep, err error, count int64) {
	err = utils.GEngine.Table("app_skill_order").
		Preload("BuyerInfo", func(db *gorm.DB) *gorm.DB {
			return db.Table("system_user").Select("user_id,user_nickname,user_gender,user_birthday,user_iconurl")
		}).
		Preload("SellerInfo", func(db *gorm.DB) *gorm.DB {
			return db.Table("system_user").Select("user_id,user_nickname,user_gender,user_birthday,user_iconurl")
		}).
		Preload("SkillInfo", func(db *gorm.DB) *gorm.DB {
			return db.Table("app_skill").Select("skill_id,skill_name,skill_iconurl")
		}).
		Where("order_sell_user_id = ?", sellerId).Limit(size).Offset(skip).
		Order("order_is_finished asc,created desc").Find(&result).Count(&count).Error
	return result, nil, count
}

// 根据出售订单用户id获取订单
func (m *AppSkillOrder) GetOrdersByBuyerId(sellerId int64, size, skip int) (result []response.SkillOrderBySparringRep, err error, count int64) {
	err = utils.GEngine.Table("app_skill_order").
		Preload("BuyerInfo", func(db *gorm.DB) *gorm.DB {
			return db.Table("system_user").Select("user_id,user_nickname,user_gender,user_birthday,user_iconurl")
		}).
		Preload("SellerInfo", func(db *gorm.DB) *gorm.DB {
			return db.Table("system_user").Select("user_id,user_nickname,user_gender,user_birthday,user_iconurl")
		}).
		Preload("SkillInfo", func(db *gorm.DB) *gorm.DB {
			return db.Table("app_skill").Select("skill_id,skill_name,skill_iconurl")
		}).
		Where("order_buy_user_id = ?", sellerId).Limit(size).Offset(skip).
		Order("created desc").Find(&result).Count(&count).Error
	return result, err, count
}

// QuerySparringDetail 获取大神订单详情
func (m *AppSkillOrder) QuerySparringDetail(orderId int) (has int64, data AppSkillOrder, err error) {
	model := utils.GEngine.Model(m).
		Preload("AppSkillOrderRefund").
		Preload("AppSkillOrderAppeal").
		Preload("AppSkill", func(db *gorm.DB) *gorm.DB {
			return db.Select("skill_id,skill_name,skill_iconurl")
		}).
		Preload("SellSystemUser", func(db *gorm.DB) *gorm.DB {
			return db.Select("user_id,user_nickname")
		}).
		Preload("BuySystemUser", func(db *gorm.DB) *gorm.DB {
			return db.Select("user_id,user_nickname")
		}).
		Where("app_skill_order.order_id = ?", orderId).First(&data)
	has = model.RowsAffected
	err = model.Error
	return
}

// 获取收益明细
func (m *AppSkillOrder) GetSparringIncomeRecord(sparringId int64, size int, skip int) (total int64, data []response.SparringIncomeRecord, err error) {
	err = utils.GEngine.Table("app_skill_order").Where("order_status = ? and order_sell_user_id = ? and deleted = 0",
		SKILL_ORDER_STATUS_SETTLEMENT, sparringId).Or("order_status = ? and order_sell_user_id = ? and deleted = 0",
		SKILL_ORDER_STATUS_FINISH, sparringId).Select("order_sell_user_id as user_id,order_income,order_finish_time,order_settle_time,order_status").
		Order("edited desc").Count(&total).Offset(skip).Limit(size).Find(&data).Error
	return
}

// CountDownNew 计算订单倒计时
func (m *AppSkillOrder) CountDownNew(order AppSkillOrder) (countDown int64) {
	defer func() {
		if countDown < 0 {
			countDown = 0
		}
	}()
	// 计算各个状态的倒计时
	now := time.Now().Unix()
	// 待接单
	if order.OrderStatus == SKILL_ORDER_STATUS_CONFIRM && order.OrderConfirmStatus == SKILL_ORDER_CONFIRM_STATUS_NO {
		countDown = (order.OrderPayTime + SKILL_ORDER_ORDER_TIME) - now
		return
	}
	// 已接单
	if order.OrderStatus == SKILL_ORDER_STATUS_CONFIRM && order.OrderConfirmStatus == SKILL_ORDER_CONFIRM_STATUS_ACCEPT {
		// 接单时间+保护时间
		countDown = (order.OrderConfirmTime + order.OrderTime + SKILL_ORDER_CONFIRM_TIME) - now
		return
	}
	// 已完成
	if order.OrderStatus == SKILL_ORDER_STATUS_FINISH && order.OrderFinishStatus == SKILL_ORDER_FINISH_STATUS_SYSTEM {
		countDown = (order.OrderFinishTime + SKILL_ORDER_CONFIRM_APPEAL) - now
		return
	}

	// 退款中
	if order.OrderStatus == SKILL_ORDER_STATUS_REFUND && order.OrderRefundStatus == SKILL_ORDER_REFUND_STATUS_REFUNDING {
		countDown = (order.AppSkillOrderRefund.BaseModel.Created + SKILL_ORDER_REFUND_TIME) - now
		return
	}
	// 退款倒计时
	if order.OrderStatus == SKILL_ORDER_STATUS_REFUND && order.OrderRefundStatus == SKILL_ORDER_REFUND_STATUS_SPARRING_REFUSE {
		countDown = (order.AppSkillOrderRefund.BaseModel.Edited + SKILL_ORDER_REFUND_TIME) - now
		return
	}
	// 申诉
	if order.OrderStatus == SKILL_ORDER_STATUS_APPEAL && order.OrderAppealStatus == SKILL_ORDER_APPEAL_STATUS_ING {
		countDown = (order.AppSkillOrderAppeal.BaseModel.Edited + SKILL_ORDER_APPEAL_TIME) - now
		return
	}
	return
}

// 计算订单剩余保护时间
func (m *AppSkillOrder) ProtectionTime(order AppSkillOrder) (protectionTime int64) {
	now := time.Now().Unix()
	// 已接单
	if order.OrderStatus == SKILL_ORDER_STATUS_CONFIRM && order.OrderConfirmStatus == SKILL_ORDER_CONFIRM_STATUS_ACCEPT {
		// 接单时间+保护时间
		protectionTime = (order.OrderConfirmTime + order.OrderProtectionTime) - now
	}

	defer func() {
		if protectionTime < 0 {
			protectionTime = 0
		}
	}()

	return
}

// 系统完成订单
func (m *AppSkillOrder) SystemCompleteOrder(orderId int64) (err error) {
	m.OrderStatus = SKILL_ORDER_STATUS_FINISH
	m.OrderFinishStatus = SKILL_ORDER_FINISH_STATUS_SYSTEM
	m.OrderFinishTime = time.Now().Unix()
	m.OrderIsFinished = SKILL_ORDER_IS_FINISHED_OK
	m.OrderCommentStatus = SKILL_ORDER_COMMENT_STATUS_WAIT
	err = utils.GEngine.Model(m).Where("order_id = ?", orderId).Updates(m).Error
	return
}

// 获取月收入
func (m *AppSkillOrder) GetMonthIncomeBySparringId(sellerId int64) (data response.SparringMonthIncome, err error) {
	t := utils.GetMonthFirstDayTimeStamp()
	now := time.Now().Unix()
	err = utils.GEngine.Model(m).Where("order_status = ? and order_sell_user_id = ? and order_settle_time between ? and ?",
		SKILL_ORDER_STATUS_SETTLEMENT, sellerId, t, now).Or("order_status = ? and order_sell_user_id = ? and order_finish_time between ? and ?",
		SKILL_ORDER_STATUS_FINISH, sellerId, t, now).Select("sum(order_income) as month_income").FirstOrInit(&data).Error
	if err != nil {
		return
	}
	err = utils.GEngine.Model(m).Where("order_status = ? and order_sell_user_id = ? and order_finish_time between ? and ?",
		SKILL_ORDER_STATUS_FINISH, sellerId, t, now).Select("sum(order_income) as un_settle_income").FirstOrInit(&data).Error
	return
}

// 申请退款事务处理
func (m *AppSkillOrder) RefundTransaction(refundInfo AppSkillOrderRefund) (err error) {
	err = utils.GEngine.Transaction(func(tx *gorm.DB) error {
		// 在事务中执行一些 db 操作（从这里开始，您应该使用 'tx' 而不是 'db'）
		if err := tx.Create(&refundInfo).Error; err != nil {
			// 返回任何错误都会回滚事务
			return err
		}
		m.OrderRefundId = refundInfo.RefundId
		if err := tx.Where("order_id = ?", m.OrderId).Save(&m).Error; err != nil {
			return err
		}

		// 返回 nil 提交事务
		return nil
	})
	return
}

// 获取大神订单总收益
func (m *AppSkillOrder) GetOrderIncome(userId int64, st int64, et int64) (totalIncome int64, err error) {
	type income struct {
		TotalIncome int64 `gorm:"column:total_income"`
	}
	var in income
	err = utils.GEngine.Model(m).Where("order_status = ? and order_sell_user_id = ? and order_settle_time between ? and ?",
		SKILL_ORDER_STATUS_SETTLEMENT, userId, st, et).Or("order_status = ? and order_sell_user_id = ? and order_finish_time between ? and ?",
		SKILL_ORDER_STATUS_FINISH, userId, st, et).Select("sum(order_income) as total_income").FirstOrInit(&in).Error
	if err == nil {
		totalIncome = in.TotalIncome
	}
	return
}

// 获取用户相关订单
func (m *AppSkillOrder) GetMsgOrdersByUserId(userId int64, size, skip int) (result []response.SkillOrderBySparringRep, err error, count int64) {
	err = utils.GEngine.Table("app_skill_order").
		Preload("BuyerInfo", func(db *gorm.DB) *gorm.DB {
			return db.Table("system_user").Select("user_id,user_nickname,user_gender,user_birthday,user_iconurl")
		}).
		Preload("SellerInfo", func(db *gorm.DB) *gorm.DB {
			return db.Table("system_user").Select("user_id,user_nickname,user_gender,user_birthday,user_iconurl")
		}).
		Preload("SkillInfo", func(db *gorm.DB) *gorm.DB {
			return db.Table("app_skill").Select("skill_id,skill_name,skill_iconurl")
		}).
		Where("order_buy_user_id = ? or order_sell_user_id = ?", userId, userId).
		Where("(order_status = ? and (order_confirm_status in ?)) or order_status = ?", SKILL_ORDER_STATUS_CONFIRM, []int{SKILL_ORDER_CONFIRM_STATUS_NO, SKILL_ORDER_CONFIRM_STATUS_REFUSE}, SKILL_ORDER_STATUS_CANCEL).Limit(size).Offset(skip).
		Order("created desc").Find(&result).Distinct("order_id").Count(&count).Error
	return result, err, count
}

// 消息订单
func (m *AppSkillOrder) GetMsgOrdersByBuyerId(userId int64, sellerId int64) (result []response.MsgOrderInfo, err error) {
	err = utils.GEngine.Table("app_skill_order").
		Preload("SkillInfo", func(db *gorm.DB) *gorm.DB {
			return db.Table("app_skill").Select("skill_id,skill_name,skill_iconurl")
		}).Where("order_is_finished = ? and deleted = 0", SKILL_ORDER_IS_FINISHED_NO).
		Where("order_buy_user_id = ? and order_sell_user_id = ? or order_buy_user_id = ? and order_sell_user_id = ?", userId, sellerId, sellerId, userId).
		Order("created desc").Find(&result).Distinct("app_skill_order.order_id").Error
	return result, err
}

// 首页订单列表
func (m *AppSkillOrder) GetMsgOrdersBySellerId(sellerId int64) (result []response.SkillOrderMsgResp, err error) {
	err = utils.GEngine.Table("app_skill_order").
		Preload("BuyerInfo", func(db *gorm.DB) *gorm.DB {
			return db.Table("system_user").Select("user_id,user_nickname,user_gender,user_birthday,user_iconurl")
		}).
		Preload("SkillInfo", func(db *gorm.DB) *gorm.DB {
			return db.Table("app_skill").Select("skill_id,skill_name,skill_iconurl")
		}).
		Where("order_sell_user_id = ?", sellerId).Where("order_status = ? and order_confirm_status = ? and deleted = 0", SKILL_ORDER_STATUS_CONFIRM, SKILL_ORDER_CONFIRM_STATUS_NO).
		Order("created asc").Find(&result).Error
	return result, err
}

// 查询账单
func (m *AppSkillOrder) QueryBill(page int, size int, userId int64) (total int64, data []AppSkillOrder, err error) {
	err = utils.GEngine.Model(m).
		Where("order_buy_user_id = ?", userId).
		// Where("order_status IN ?", []int{SKILL_ORDER_STATUS_PAY, SKILL_ORDER_STATUS_CANCEL, SKILL_ORDER_STATUS_REFUND, SKILL_ORDER_STATUS_APPEAL}).
		Count(&total).
		Order("created desc").
		Offset((page * size) - size).
		Limit(size).
		Find(&data).Error
	return
}

// 查询时间段内未评价的订单
func (m *AppSkillOrder) QueryNotComment(SystemCommitTime int64) (data []AppSkillOrder, err error) {
	err = utils.GEngine.Model(m).
		Where("order_comment_status=?", SKILL_ORDER_COMMENT_STATUS_WAIT).
		Where("order_finish_time <?", time.Now().Unix()-SystemCommitTime).
		Where("order_delete_status=?", SKILL_ORDER_DELETE_STATUS_OK).Find(&data).Error
	return
}

// 订单清洗查询
func (m *AppSkillOrder) QueryOrderCleaning(tx *gorm.DB) (data []*AppSkillOrder, err error) {
	err = tx.Model(m).Where("order_status=? or order_status=?", SKILL_ORDER_STATUS_FINISH, SKILL_ORDER_STATUS_SETTLEMENT).
		Where("order_comment_status=?", 0).Find(&data).Error
	return
}
