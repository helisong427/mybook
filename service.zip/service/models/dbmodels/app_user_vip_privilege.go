package dbmodels

import (
	"gamers/controller/response"
	"gamers/utils"
)

// vip特权详情
type AppUserVipPrivilege struct {
	PrivilegeId      int64     `gorm:"column:privilege_id;primaryKey;autoIncrement" json:"privilege_id"`
	PrivilegeTitle   string    `gorm:"column:privilege_title" json:"privilege_title"`     // 特权title
	PrivilegeIcon    string    `gorm:"column:privilege_icon" json:"privilege_icon"`       // 特权icon
	PrivilegeContent string    `gorm:"column:privilege_content" json:"privilege_content"` // 特权内容
	PrivilegeLevel   int       `gorm:"column:privilege_level" json:"privilege_level"`     // 解锁需要的vip等级
	BaseModel        BaseModel `gorm:"embedded" json:"base_model"`
}

func (AppUserVipPrivilege) TableName() string {
	return "app_user_vip_privilege"
}

// 获取Vip特权
func (m *AppUserVipPrivilege) QueryVipPrivilege() (data []*response.GetVipPrivilegeResp, err error) {
	err = utils.GEngine.Model(m).Where("deleted = 0").Find(&data).Error
	return
}
