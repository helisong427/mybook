package dbmodels

import (
	"encoding/json"
	"gamers/utils"
	"sync"
)

// 首页推荐干预表
type AppRecommendIntervention struct {
	InterventionId            int64 `gorm:"column:intervention_id" json:"intervention_id"`
	InterventionPositionType  int   `gorm:"column:intervention_position_type" json:"intervention_position_type"`     // 推荐位置类型：0 首页大神列表；1首页专属推荐
	InterventionPositionIndex int64 `gorm:"column:intervention_position_index" json:"intervention_position_index"`   // 推荐位置序号
	InterventionContentType   int   `gorm:"column:intervention_content_type" json:"intervention_content_type"`       // 推荐内容类型：0表示大神；1表示房间
	InterventionContentId     int64 `gorm:"column:intervention_content_id" json:"intervention_content_id"`           // 推荐内容id(房间id或者大神id)
	InterventionContentUserId int64 `gorm:"column:intervention_content_user_id" json:"intervention_content_user_id"` // 被推荐的用户id
	InterventionContentWeight int64 `gorm:"column:intervention_content_weight" json:"intervention_content_weight"`   // 推荐权重
	InterventionStatus        int   `gorm:"column:intervention_status" json:"intervention_status"`                   // 推荐状态：0--关闭，1--开启
	BaseModel
}

const (
	// 推荐位置类型
	INTERVENTION_POSITION_TYPE_SPARRING  int = iota // 首页大神列表
	INTERVENTION_POSITION_TYPE_EXCLUSIVE            // 首页专属推荐
)

const (
	// 推荐内容类型
	INTERVENTION_CONTENT_TYPE_SPARRING int = iota // 表示大神
	INTERVENTION_CONTENT_TYPE_ROOM                // 表示房间
)

const (
	// 推荐状态
	INTERVENTION_STATUS_OFF int = iota // 关闭
	INTERVENTION_STATUS_ON             // 开启
)

func (AppRecommendIntervention) TableName() string {
	return "app_recommend_intervention"
}

var recommendIntervention sync.Mutex

// 获取大神推荐位
func (m *AppRecommendIntervention) QuerySparringPosition() (data []AppRecommendIntervention, err error) {
	key := utils.REDIS_RECOMMEND_SPARRING_POSITION
	result, _ := utils.RedisClient.Get(key).Result()
	if result == "" {
		recommendIntervention.Lock()
		defer recommendIntervention.Unlock()
		err = utils.GEngine.
			Where("intervention_position_type = ? AND intervention_content_type = ? AND intervention_status = ?", INTERVENTION_POSITION_TYPE_SPARRING, INTERVENTION_CONTENT_TYPE_SPARRING, INTERVENTION_STATUS_ON).
			Find(&data).Error
		if err != nil {
			return nil, err
		}
		marshal, err := json.Marshal(data)
		if err != nil {
			return nil, err
		}
		err = utils.RedisClient.Set(key, string(marshal), 0).Err()
	} else {
		err = json.Unmarshal([]byte(result), &data)
	}
	return
}

// 获取专属推荐位
func (m *AppRecommendIntervention) QueryExclusivePosition(start, end int) (data []AppRecommendIntervention, err error) {
	key := utils.REDIS_RECOMMEND_SPARRING_EXCLUSIVE
	result, _ := utils.RedisClient.Get(key).Result()

	if result == "" {
		recommendIntervention.Lock()
		defer recommendIntervention.Unlock()
		err = utils.GEngine.
			Where("intervention_position_type = ? AND intervention_status = ?", INTERVENTION_POSITION_TYPE_EXCLUSIVE, INTERVENTION_STATUS_ON).
			// Where("intervention_position_index >= ? OR intervention_position_index <= ?", start, end).
			Find(&data).Error
		if err != nil {
			return nil, err
		}

		marshal, err := json.Marshal(data)
		if err != nil {
			return nil, err
		}
		err = utils.RedisClient.Set(key, string(marshal), 0).Err()

	} else {
		err = json.Unmarshal([]byte(result), &data)
	}

	tmp := []AppRecommendIntervention{}

	for _, v := range data {
		if v.InterventionPositionIndex >= int64(start) && v.InterventionPositionIndex <= int64(end) {
			tmp = append(tmp, v)
		}
	}
	data = tmp
	return
}

// 删除推荐位
func (m *AppRecommendIntervention) Delete(id int64) (err error) {
	err = utils.GEngine.Where("intervention_content_id = ?", id).Delete(m).Error
	return
}
