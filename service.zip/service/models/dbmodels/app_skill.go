package dbmodels

import (
	"encoding/json"
	"gamers/controller/response"
	"gamers/utils"
	"strconv"
	"strings"

	"gorm.io/gorm"

	"github.com/go-redis/redis"
)

// 技能基础
type AppSkill struct {
	SkillId                int64                 `gorm:"column:skill_id" json:"skill_id"`
	SkillType              int                   `gorm:"column:skill_type" json:"skill_type"`                               // 游戏类型(0游戏,1娱乐)
	SkillName              string                `gorm:"column:skill_name" json:"skill_name"`                               // 游戏名称
	SkillIconurl           string                `gorm:"column:skill_iconurl" json:"skill_iconurl"`                         // 游戏icon
	SkillLevelTips         string                `gorm:"column:skill_level_tips" json:"skill_level_tips"`                   // 等级提示
	SkillLevelUrl          string                `gorm:"column:skill_level_url" json:"skill_level_url"`                     // 等级示例图片
	SkillSoundTips         string                `gorm:"column:skill_sound_tips" json:"skill_sound_tips"`                   // 技能申请提示
	SkillAvatarTips        string                `gorm:"-" json:"skill_avatar_tips"`                                        // 头像提示
	SkillInfoTips          string                `gorm:"column:skill_info_tips" json:"skill_info_tips"`                     // 介绍提示
	SkillFields            string                `gorm:"column:skill_fields" json:"skill_fields"`                           // 游戏可选字段用,分割
	SkillCardFields        string                `gorm:"skill_card_fields" json:"skill_card_fields"`                        // 模板可选字段,分割
	SkillStatus            int                   `gorm:"column:skill_status" json:"skill_status"`                           // 技能状态
	SkillOrder             int                   `gorm:"column:skill_order"`                                                // 技能排序,权重,升序
	SkillCardBackGroundUrl string                `gorm:"column:skill_card_background_url" json:"skill_card_background_url"` // 名片背景图片
	GameSkillFiledValues   []GameSkillFiledValue `gorm:"-" json:"game_skill_filed_values"`                                  // ...
	AppSkillFieldValue     []AppSkillFieldValue  `gorm:"foreignKey:ValueSkillId;references:SkillId" json:"-"`               // 一对多关联技能字段配置
	AppSkillPrice          []AppSkillPrice       `gorm:"foreignKey:PriceSkillId;references:SkillId" json:"app_skill_price"` // 一对多关联技能价格配置
	SkillRequiredField     string                `gorm:"column:skill_required_field" json:"skill_required_field"`           // 必填字段id
	SkillRequiredValue     []AppSkillFieldValue  `gorm:"-" json:"skill_required_value"`                                     // 必填字段id // 头像提
	BaseModel              BaseModel             `gorm:"embedded" json:"base_model"`
}

// 游戏类型
const (
	SKILL_TYPE_GAME          int = iota // 游戏
	SKILL_TYPE_ENTERTAINMENT            // 娱乐
)

const (
	SKILL_STATUS_CLOSE = iota
	SKILL_STATUS_OPEN
)

func (AppSkill) TableName() string {
	return "app_skill"
}

// 基本条件
func (m *AppSkill) baseWhere() func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		return db.Where("deleted = 0 AND skill_status = ?", SKILL_STATUS_OPEN)
	}
}

// 获取技能所有参数
func (m *AppSkill) QueryAll() (data []AppSkill, err error) {
	err = utils.GEngine.Model(m).
		Preload("AppSkillFieldValue", "deleted = 0").
		Preload("AppSkillPrice", "deleted = 0").
		Scopes(m.baseWhere()).Find(&data).Error
	return
}

// 获取全部技能名称
func (m *AppSkill) QuerySkillName() (data []AppSkill, err error) {
	err = utils.GEngine.Model(m).Select("skill_id,skill_name").Scopes(m.baseWhere()).Find(&data).Error
	return
}

// 获取全部技能
func (m *AppSkill) QuerySkillAll() (data []AppSkill, err error) {
	err = utils.GEngine.Model(m).Select("skill_id,skill_name,skill_iconurl").Scopes(m.baseWhere()).Find(&data).Error
	return
}

// 获取一条技能名称
func (m *AppSkill) QueryFirstSkillName(skillId int64) (data AppSkill, err error) {
	err = utils.GEngine.Model(m).Select("skill_name, skill_status").Where("skill_id = ?", skillId).Scopes(m.baseWhere()).First(&data).Error
	return
}

// in查询游戏名称
func (m *AppSkill) QueryInGameName(ids []string) (data []AppSkill, err error) {
	err = utils.GEngine.Select("skill_id,skill_name").Where("skill_id IN ?", ids).Scopes(m.baseWhere()).Find(&data).Error
	return
}

// 获取一条技能详情
func (m *AppSkill) QueryFirst(skillId int64) (data AppSkill, err error) {
	err = utils.GEngine.Model(m).Preload("AppSkillFieldValue").
		Preload("AppSkillPrice").
		Where("skill_id = ?", skillId).
		First(&data).Error
	return
}

func (s *AppSkill) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s AppSkill) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

func SplitSkillFields(str string) []string {
	return strings.Split(str, ",")
}

// QueryByUserId 根据游戏id查询
func (m *AppSkill) QueryBySkillId(skillId int64) (data AppSkill, err error) {
	skillid := strconv.Itoa(int(skillId))
	err = utils.RedisClient.HGet(utils.REDIS_SKILL_INFO, skillid).Scan(&data)
	if err != nil && err != redis.Nil {
		return
	}
	if err == nil {
		return
	}
	err = utils.GEngine.Model(m).Preload("AppSkillPrice").Where("skill_id = ?", skillId).Scopes(m.baseWhere()).First(&data).Error
	if err != nil {
		return
	}
	// 查询必填参数
	data.SkillRequiredValue, err = new(AppSkillFieldValue).GetAppSkillFieldByValueKeyAndSkillId(data.SkillRequiredField, skillId)
	if err != nil {
		return
	}
	fields := SplitSkillFields(data.SkillFields)
	for _, v := range fields {
		value, err := new(AppSkillFieldValue).GetAppSkillFieldByValueKeyAndSkillId(v, skillId)
		if err != nil || len(value) == 0 {
			continue
		}
		gameValue := GameSkillFiledValue{
			Values:       value,
			ValueKeyName: value[0].ValueFieldName,
			ValueKey:     value[0].ValueField,
		}
		data.GameSkillFiledValues = append(data.GameSkillFiledValues, gameValue)
	}
	// 获取价格
	// data.AppSkillPrice, err = new(AppSkillPrice).GetSkillPriceBySkillId(data.SkillId)
	err = utils.RedisClient.HSet(utils.REDIS_SKILL_INFO, skillid, data).Err()
	return
}

// 查询技能列表
func (m *AppSkill) GetSkillListByUserId(userId int64) (data []response.SkillListItem, err error) {
	err = utils.GEngine.Model(m).Select("app_skill.skill_id,app_skill.skill_type,app_skill.skill_name,app_skill.skill_iconurl,app_sparring_skill.skill_status").
		Joins("LEFT JOIN app_sparring_skill ON  app_sparring_skill.skill_skill_id = app_skill.skill_id AND skill_user_id = ?", userId).
		Where("app_skill.skill_status = ? and app_skill.deleted = 0", SKILL_STATUS_OPEN).Find(&data).Error
	return
}

// 查询大神列表
func (m *AppSkill) GetOpenSkillsByUserId(userId int64) (data []response.SkillInfo, total int, err error) {
	err = utils.GEngine.Model(m).Select(`app_skill.skill_id,app_skill.skill_name,app_skill.skill_iconurl,
		app_sparring_skill.skill_speed_matching_status as skill_speed_matching_status, app_sparring_skill.skill_msg_status as skill_msg_status`).
		Joins("LEFT JOIN app_sparring_skill ON  app_sparring_skill.skill_skill_id = app_skill.skill_id AND skill_user_id = ?", userId).
		Where("app_sparring_skill.skill_status = ?", SPARRING_SKILL_STATUS_OK).Find(&data).Error
	if err != nil {
		return
	}
	err = utils.GEngine.Table("app_sparring_skill").Where("skill_user_id = ?", userId).Select("count(skill_id)").Find(&total).Error
	return
}
