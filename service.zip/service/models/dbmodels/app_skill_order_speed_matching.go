package dbmodels

import (
	"gamers/enum"
	"gamers/utils"
	"time"

	"gorm.io/gorm"
)

// 订单极速匹配表
type AppSkillOrderSpeedMatching struct {
	MatchingId                int64      `gorm:"column:matching_id;primaryKey;autoIncrement"`
	MatchingOrderId           int64      `gorm:"column:matching_order_id"`                      // 订单id
	MatchingUserId            int64      `gorm:"column:matching_user_id"`                       // 订单用户id
	MatchingSparringUserId    int64      `gorm:"column:matching_sparring_user_id"`              // 大神用户id
	MatchingSkillId           int64      `gorm:"column:matching_skill_id"`                      // 游戏id
	MatchingPrice             int64      `gorm:"column:matching_price"`                         // 单价代币
	MatchingWay               string     `gorm:"column:matching_way"`                           // 陪玩方式 局/次/天/半小时/小时
	MatchingGender            int        `gorm:"column:matching_gender"`                        // 性别
	MatchingCount             int64      `gorm:"column:matching_count"`                         // 数量
	MatchingOtherRequirements string     `gorm:"column:matching_other_requirements"`            // 其他要求
	MatchingRemark            string     `gorm:"column:matching_remark"`                        // 备注
	MatchingStatus            int        `gorm:"column:matching_status"`                        // 抢单状态(0待抢单,1已过期,2已取消,3已抢单)
	MatchingSuccessStatus     int        `gorm:"column:matching_success_status"`                // 与大神匹配状态是否完成(0否,1是)
	AppSkill                  AppSkill   `gorm:"foreignKey:SkillId;references:MatchingSkillId"` // 关联游戏
	SystemUser                SystemUser `gorm:"foreignKey:UserID;references:MatchingUserId"`   // 关联用户
	BaseModel
}

func (AppSkillOrderSpeedMatching) TableName() string {
	return "app_skill_order_speed_matching"
}

const (
	// 抢单状态
	SPEED_MATCHING_STATUS_PENDING   int = iota // 待抢单
	SPEED_MATCHING_STATUS_EXPIRED              // 已过期
	SPEED_MATCHING_STATUS_CANCEL               // 已取消
	SPEED_MATCHING_STATUS_COMPLETED            // 已抢单
)

const (
	// 是否完成
	SPEED_MATCHING_SUCCESS_STATUS_NO  int = iota // 否
	SPEED_MATCHING_SUCCESS_STATUS_YES            // 是
)

func (m *AppSkillOrderSpeedMatching) Create(tx *gorm.DB) (err error) {
	err = tx.Create(m).Error
	return
}

// 查询是否有待抢单
func (m *AppSkillOrderSpeedMatching) QueryPendingOrder(userId int64) (cont int64, err error) {
	err = utils.GEngine.Model(m).Where("matching_user_id = ? AND matching_status = ?", userId, SPEED_MATCHING_STATUS_PENDING).Count(&cont).Error
	return
}

// 查询用户最后一笔订单
func (m *AppSkillOrderSpeedMatching) QueryLast(userId int64) (data AppSkillOrderSpeedMatching, err error) {
	err = utils.GEngine.Where("matching_user_id = ?", userId).Order("created desc").Limit(1).First(&data).Error
	return
}

// 完成异常订单
func (m *AppSkillOrderSpeedMatching) SuccessUpdate(matchingId int64, userId int64) (row int64, err error) {
	model := utils.GEngine.Model(m).
		Where("matching_id = ? AND matching_user_id = ? AND matching_success_status = ?",
			matchingId,
			userId,
			SPEED_MATCHING_SUCCESS_STATUS_NO).
		Updates(map[string]interface{}{"matching_success_status": SPEED_MATCHING_SUCCESS_STATUS_YES})
	row = model.RowsAffected
	err = model.Error
	return
}

// 分页查询大神相关订单
func (m *AppSkillOrderSpeedMatching) QueryPageSkillId(page, size int, skillId []int64, gender int) (total int64, data []AppSkillOrderSpeedMatching, err error) {
	model := utils.GEngine.Model(m).Where("matching_skill_id IN ?", skillId)
	if gender != 0 {
		model = model.Where("matching_gender = 0 OR matching_gender = ?", gender)
	}
	err = model.Count(&total).
		Preload("AppSkill").
		Preload("SystemUser").
		Order("created desc").
		Offset((page * size) - size).
		Limit(size).Find(&data).Error
	return
}

// 分页查询大神相关订单
func (m *AppSkillOrderSpeedMatching) QueryPageSkillIdByTime(page, size int, skillId []int64, gender int, userId int64) (total int64, data []AppSkillOrderSpeedMatching, err error) {
	model := utils.GEngine.Model(m).Where("matching_skill_id IN ?", skillId)
	if gender != 0 {
		model = model.Where("matching_gender = 0 OR matching_gender = ?", gender)
	}
	err = model.Count(&total).
		Preload("AppSkill").
		Preload("SystemUser").
		Order("created desc").
		Where("matching_status = 3").
		Where("matching_sparring_user_id = ?", userId).
		Where("edited >= ?", time.Now().Unix()-enum.SPEED_ORDER_TOP_TIME).
		Offset((page * size) - size).
		Limit(size).Find(&data).Error
	return
}

// 查询订单详情
func (m *AppSkillOrderSpeedMatching) QueryByMatchingId(matchingId int64) (data AppSkillOrderSpeedMatching, err error) {
	err = utils.GEngine.Where("matching_id = ?", matchingId).First(&data).Error
	return
}

// 更新订单状态
func (m *AppSkillOrderSpeedMatching) Update(tx *gorm.DB, matchingId int64, update map[string]interface{}) (err error) {
	err = tx.Model(m).Where("matching_id = ?", matchingId).Updates(update).Error
	return
}
