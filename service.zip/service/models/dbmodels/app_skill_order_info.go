package dbmodels

import (
	"gamers/utils"
	"gorm.io/gorm"
)

//技能订单详情表
type AppSkillOrderInfo struct {
	InfoId              int64     `gorm:"column:info_id" json:"info_id"`
	InfoOrderId         int64     `gorm:"column:info_order_id" json:"info_order_id"`
	InfoSkillId         int64     `gorm:"column:info_skill_id" json:"info_skill_id"`
	InfoSparringSkillId int64     `gorm:"column:info_sparring_skill_id" json:"info_sparring_skill_id"`
	InfoValueId         int64     `gorm:"column:info_value_id" json:"info_value_id"`
	InfoField           string    `gorm:"column:info_field" json:"info_field"`
	InfoFieldName       string    `gorm:"column:info_field_name" json:"info_field_name"`
	InfoValue           string    `gorm:"column:info_value" json:"info_value"`
	BaseModel           BaseModel `gorm:"embedded" json:"base_model"`
}

func (AppSkillOrderInfo) TableName() string {
	return "app_skill_order_info"
}

func (m *AppSkillOrderInfo) QueryOrderDetailByOrderId(orderId int64) (result AppSkillOrderInfo, err error) {
	err = utils.GEngine.Where("detail_order_id = ?", orderId).First(&result).Error
	return
}

func (m *AppSkillOrderInfo) BatchSave(tx *gorm.DB, data []AppSkillOrderInfo) (err error) {
	err = tx.Model(m).Create(&data).Error
	return
}
