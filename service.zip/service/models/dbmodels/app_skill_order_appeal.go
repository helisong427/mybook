package dbmodels

import (
	"gamers/utils"
	"gorm.io/gorm"
)

//大神订单申诉表
type AppSkillOrderAppeal struct {
	AppealId             int64     `gorm:"column:appeal_id;primaryKey;autoIncrement" json:"appeal_id"`  //订单申诉id
	AppealOrderId        int64     `gorm:"column:appeal_order_id" json:"appeal_order_id"`               //订单id
	AppealCount          int64     `gorm:"column:appeal_count" json:"appeal_count"`                     //退款代币数量
	AppealReason         string    `gorm:"column:appeal_reason" json:"appeal_reason"`                   //申诉原因
	AppealRemark         string    `gorm:"column:appeal_remark" json:"appeal_remark"`                   //申诉说明
	AppealImage          string    `gorm:"column:appeal_image" json:"appeal_image"`                     //申诉图片
	AppealSparringRemark string    `gorm:"column:appeal_sparring_remark" json:"appeal_sparring_remark"` //大神说明
	AppealSparringTime   int64     `gorm:"column:appeal_sparring_time" json:"appeal_sparring_time"`     // 大神提交时间
	AppealSparringImage  string    `gorm:"column:appeal_sparring_image" json:"appeal_sparring_image"`   //申诉图片,json格式["http://","http://"]
	AppealProcess        string    `gorm:"column:appeal_process" json:"appeal_process"`                 //处理备注
	AppealProcessTime    int64     `gorm:"column:appeal_process_time" json:"appeal_process_time"`       //处理时间
	AppealProcessResult  int       `gorm:"column:appeal_process_result" json:"appeal_process_result"`   //处理结果(1确认退款,2拒绝退款)
	AppealAppealStatus   int       `gorm:"column:appeal_appeal_status" json:"appeal_appeal_status"`     //申诉状态(0未申诉,1申诉中,2待处理,3处理完成)
	AppealManageId       int64     `gorm:"column:appeal_manage_id" json:"appeal_manage_id"`             //处理管理员id
	BaseModel            BaseModel `gorm:"embedded" json:"-"`
}

const (
	//处理结果
	SKILL_APPEAL_RESULT_SUCCESS int = 1 //确认退款
	SKILL_APPEAL_RESULT_FAIL    int = 2 //拒绝退款
)

const (
	//申诉状态
	SKILL_APPEAL_STATUS_NOT  int = iota //未申诉
	SKILL_APPEAL_STATUS_ING             //申诉中
	SKILL_APPEAL_STATUS_WAIT            //待处理
	SKILL_APPEAL_STATUS_OK              //处理完成
)

func (AppSkillOrderAppeal) TableName() string {
	return "app_skill_order_appeal"
}

//创建申诉信息
func (m *AppSkillOrderAppeal) Create(tx *gorm.DB) (err error) {
	err = tx.Create(m).Error
	return
}

//根据订单id查询
func (m *AppSkillOrderAppeal) QueryByOrderId(orderId int64) (row int64, data AppSkillOrderAppeal, err error) {
	model := utils.GEngine.Where("appeal_order_id = ?", orderId).First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

//Update 更新订单信息
func (m *AppSkillOrderAppeal) Update(tx *gorm.DB, orderId int64) (err error) {
	err = tx.Model(m).Where("appeal_order_id = ? ", orderId).Updates(m).Error
	return
}

func (m *AppSkillOrderAppeal) Updates(tx *gorm.DB, orderId int64, update map[string]interface{}) (err error) {
	err = tx.Model(m).Where("appeal_order_id = ? ", orderId).Updates(update).Error
	return
}
