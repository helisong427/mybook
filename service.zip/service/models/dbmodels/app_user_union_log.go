package dbmodels

import (
	"errors"

	"gorm.io/gorm"

	"gamers/utils"
)

// 公会表

type AppUserUnionLog struct {
	LogId       uint64 `gorm:"column:log_id" json:"log_id"`
	LogUnionId  int64  `gorm:"column:log_union_id" json:"log_union_id"`
	LogUserId   int64  `gorm:"column:log_user_id" json:"log_user_id"`
	LogStatus   uint64 `gorm:"column:log_status" json:"log_status"`
	LogManageId uint64 `gorm:"column:log_manage_id" json:"log_manage_id"`
	LogRemark   string `gorm:"column:log_remark" json:"log_remark"`
	BaseModel
}

func (AppUserUnionLog) TableName() string {
	return "app_user_union_log"
}

// 申请加入公会
func (auul *AppUserUnionLog) ApplyForJoin(userID int64, unionId int64) (string, error) {
	var msg string
	var err = utils.GEngine.Transaction(func(tx *gorm.DB) error {
		var existUnion int64
		if err := tx.Model((*AppUnion)(nil)).Where("union_id = ?", unionId).Count(&existUnion).Error; err != nil {
			msg = "申请加入公会失败"
			return err
		}

		// 不存在的公会
		if existUnion <= 0 {
			msg = "公会不存在"
			return errors.New("union not exist")
		}

		var userInfo SystemUser
		if err := tx.Model((*SystemUser)(nil)).Select("user_union_id").Where("user_id = ?", userID).First(&userInfo).Error; err != nil {
			msg = "申请加入公会失败"
			return err
		}

		if userInfo.UserUnionId > 0 {
			msg = "已加入公会"
			return errors.New("already in union")
		}

		var record AppUserUnionLog
		var retErr = tx.Model(auul).Where("log_union_id = ? AND log_user_id = ? AND log_status<2", unionId, userID).First(&record).Error
		if retErr != nil && retErr != gorm.ErrRecordNotFound {
			msg = "申请加入公会失败"
			return retErr
		}

		// 没有记录，就申请（创建记录）
		record.LogId = 0
		record.LogUnionId = unionId
		record.LogUserId = userID
		record.LogStatus = 0
		record.LogManageId = 0
		record.LogRemark = ""
		record.Created = 0
		record.Edited = 0
		record.Deleted = 0
		if err := tx.Create(&record).Error; err != nil {
			msg = "申请加入公会失败"
			return err
		}
		msg = "申请加入公会成功"
		return nil
	})
	return msg, err
}
