/**
 * @Author: panke
 * @Description:
 * @File: app_turn_table_pool
 * @Date: 2021/4/22 15:08
 */

package dbmodels

type AppTurnTablePool struct {
	PoolID             uint                  `json:"pool_id" gorm:"column:pool_id"`
	PoolTurnTableID    uint                  `json:"pool_turn_table_id" gorm:"column:pool_turn_table_id"` // 转盘id
	PoolWeight         uint                  `json:"pool_weight" gorm:"column:pool_weight"`               // 奖池权重
	AppTurnTableReward []*AppTurnTableReward `gorm:"foreignKey:RewardTurnTableID;references:PoolID"`      // 关联奖励
	BaseModel
}

func (m *AppTurnTablePool) TableName() string {
	return "app_turn_table_pool"
}
