package dbmodels

import (
	"gamers/controller/response"
	"gamers/utils"
	"strconv"
	"time"

	"github.com/go-redis/redis"
)

// 版本表
type AppVersionLog struct {
	LogId          int64     `gorm:"column:log_id;primaryKey;autoIncrement" json:"log_id"` // id
	LogVersion     string    `gorm:"column:log_version" json:"log_version"`                // 版本号
	LogTips        string    `gorm:"column:log_tips" json:"log_tips"`                      // 更新tips
	LogCheckSwitch int       `gorm:"column:log_check_switch" json:"log_check_switch"`      // 检查开关
	LogMustUpdate  int       `gorm:"column:log_must_update" json:"log_must_update"`        // 是否强更
	LogClient      int       `gorm:"column:log_client" json:"log_client"`                  // 客户端，1安卓，2为ios
	LogUrl         string    `gorm:"column:log_url"`                                       // 客户端，1安卓，2为ios
	BaseModel      BaseModel `gorm:"embedded" json:"-"`
}

const DEFAULT_VERSION_CACHE_TIMEOUT = 60 * 60 * 24 * 7 * time.Second
const (
	VERSION_MUST_UPDATE_NO  = iota // 不需要强更
	VERSION_MUST_UPDATE_YES        // 必须强更
)

const (
	VERSION_CHECK_SWITCH_OFF = iota // 审核开关，显示
	VERSION_CHECK_SWITCH_ON         // 审核开关，不显示
)

func (AppVersionLog) TableName() string {
	return "app_version_log"
}

// 根据version和client查询当前version
func (m *AppVersionLog) GetVersionLogByVersionAndClient(version string, client int) (data response.VersionInfo, err error) {
	key := utils.REDIS_APP_VERSION + strconv.Itoa(client) + ":" + version
	err = utils.RedisClient.Get(key).Scan(&data)
	if err != redis.Nil {
		return
	}
	err = utils.GEngine.Model(m).Where("log_version = ? and log_client = ? and deleted = 0", version, client).First(&data).Error
	if err != nil {
		return
	}
	err = utils.RedisClient.Set(key, data, DEFAULT_VERSION_CACHE_TIMEOUT).Err()
	return
}

// 根据历史id和client获取最新版本信息
func (m *AppVersionLog) GetVersionLogByLogIdAndClient(version *response.VersionInfo) (data response.VersionInfo, err error) {
	key := utils.REDIS_VERSION_INFO + strconv.Itoa(version.Client) + ":" + strconv.Itoa(int(version.LogId))
	//获取缓存
	err = utils.RedisClient.Get(key).Scan(&data)
	if err != redis.Nil {
		return
	}
	var versions []response.VersionInfo
	// 获取当前审核通过的版本
	err = utils.GEngine.Model(m).Where("log_id >= ? and log_client = ? and log_check_switch = ? and deleted = 0", version.LogId, version.Client, VERSION_CHECK_SWITCH_OFF).Order("log_id desc").Find(&versions).Error
	if err != nil {
		return
	}
	// 判断版本是否大于0
	if len(versions) > 1 {
		data = versions[0]
		for _, v := range versions {
			// 判断强更
			if v.MustUpdate == VERSION_MUST_UPDATE_YES {
				data.MustUpdate = VERSION_MUST_UPDATE_YES
				break
			}
		}
	} else if len(versions) == 1 {
		data = versions[0]
	} else {
		data = *version
	}
	err = utils.RedisClient.Set(key, data, DEFAULT_VERSION_CACHE_TIMEOUT).Err()
	return
}

//根据终端获取最新版本
func (m *AppVersionLog) GetVersionLastByClient(client int) (data response.VersionInfo, err error) {
	key := utils.REDIS_APP_LAST_VERSION + strconv.Itoa(client)
	//获取缓存
	err = utils.RedisClient.Get(key).Scan(&data)
	if err != redis.Nil {
		return
	}
	err = utils.GEngine.Model(m).Where(" log_client = ? and deleted = 0", client).Order("log_id desc").First(&data).Error
	if err != nil {
		return
	}
	err = utils.RedisClient.Set(key, data, DEFAULT_VERSION_CACHE_TIMEOUT).Err()
	return
}
