package dbmodels

import (
	"gamers/utils"
	"gorm.io/gorm"
)

//奖池奖励表
type AppEggbreakReward struct {
	RewardId         int64   `gorm:"column:reward_id;primaryKey;autoIncrement"`
	RewardEggbreakId int64   `gorm:"column:reward_eggbreak_id"`                 //砸蛋奖池id
	RewardPropType   int64   `gorm:"column:reward_prop_type"`                   //物品类型(0礼物,1锤子,2go币)
	RewardPropId     int64   `gorm:"column:reward_prop_id"`                     //物品ID
	RewardPropCount  int64   `gorm:"column:reward_prop_count"`                  //物品被抽到次数
	AppProp          AppProp `gorm:"foreignKey:PropId;references:RewardPropId"` //关联礼物
}

func (AppEggbreakReward) TableName() string {
	return "app_eggbreak_reward"
}

func (m *AppEggbreakReward) Create() (err error) {
	err = utils.GEngine.Create(m).Error
	return
}

//查询奖励列表
func (m *AppEggbreakReward) QueryByEggbreakId(rewardEggbreakId int64, giftId *int64, rewardName string) (data []AppEggbreakReward, err error) {
	model := utils.GEngine.Model(m).
		Joins("AppProp", func(db *gorm.DB) *gorm.DB {
			db = db.Select("prop_id,prop_name")
			return db
		})
	if giftId != nil {
		model = model.Where("reward_prop_id = ?", giftId)
	}
	if rewardName != "" {
		model = model.Where("AppProp.prop_name LIKE ?", "%"+rewardName+"%")
	}

	err = model.Where("reward_eggbreak_id = ?", rewardEggbreakId).
		Find(&data).Error
	return
}

//根据小奖池id和道具id查询
func (m *AppEggbreakReward) QueryFirstDetailEggbreakIdAndDetailPropId(rewardEggbreakId, rewardPropId int64) (row int64, data AppEggbreakReward, err error) {
	model := utils.GEngine.Where("reward_eggbreak_id = ? AND reward_prop_id = ?", rewardEggbreakId, rewardPropId).First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

//根据奖励id查询重复的奖励
func (m *AppEggbreakReward) QueryByRewardIdRepeat(rewardId int64, rewardEggbreakId, rewardPropId int64) (row int64, data AppEggbreakReward, err error) {
	model := utils.GEngine.Where("reward_id != ? AND reward_eggbreak_id = ? AND reward_prop_id = ?", rewardId, rewardEggbreakId, rewardPropId).First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

//更新
func (m *AppEggbreakReward) Update(rewardId int64) (err error) {
	err = utils.GEngine.Where("reward_id = ?", rewardId).Updates(m).Error
	return
}

//删除
func (m *AppEggbreakReward) Delete(rewardId int64) (err error) {
	err = utils.GEngine.Where("reward_id = ?", rewardId).Delete(m).Error
	return
}
