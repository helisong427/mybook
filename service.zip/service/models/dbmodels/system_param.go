package dbmodels

import (
	"encoding/json"
	"gamers/utils"
	"strconv"

	"gorm.io/gorm"

	"github.com/go-redis/redis"
)

// 系统参数表
type SystemParam struct {
	ParamID        int64  `json:"param_id" gorm:"column:param_id;primaryKey;autoIncrement"`
	ParamTitle     string `json:"param_title"`      // 配置标题
	ParamKey       string `json:"param_key"`        // 配置key,全局唯一,方便程序处理
	ParamValue     string `json:"param_value"`      // 配置参数值
	ParamValueType int    `json:"param_value_type"` // 值类型 0:文本,1:整数,2:小数 3:json
	BaseModel
}

// 充值参数
// PayWarningParams 支付预警参数
type PayWarningParams struct {
	AliPayCash     int64    `json:"ali_pay_cash"`     // 支付宝充值金额
	TimesAliPay    int      `json:"times_ali_pay"`    // 支付宝充值次数
	WechatPayCash  int64    `json:"wechat_pay_cash"`  // 微信充值金额
	TimesWechatPay int      `json:"times_wechat_pay"` // 微信充值次数
	ApplePayCash   int64    `json:"apple_pay_cash"`   // 苹果充值金额
	TimesApplePay  int      `json:"times_apple_pay"`  // 苹果充值次数
	Time           int64    `json:"time"`             // 时间
	Phone          []string `json:"phone"`            // 电话
}

// 充值参数
type RechargeParams struct {
	Id    string `json:"id"`    // 商品id
	Cash  int64  `json:"cash"`  // 现金
	Token int64  `json:"token"` // 代币
}

// 提现规则参数
type WithdrawRuleParams struct {
	WithdrawalDate map[string]int `json:"withdrawal_date"` // 提现日期:{"Monday":0,"Thursday":0}
	SingleMin      int64          `json:"single_min"`      // 提现单笔最小金额(人民币,分)
	SingleMax      int64          `json:"single_max"`      // 提现单笔最大金额(人民币,分)
}

// 首页推荐位参数
type IndexRecommendParams struct {
	PartyAmount    int `json:"party_amount"`
	LiveAmount     int `json:"live_amount"`
	SparringAmount int `json:"sparring_amount"`
}

// 大神技能计算分数配置
type SparringSkillScoreConfig struct {
	PraiseAndOrderCount float64 `json:"praise_and_order_count"` // 好评&接单数所占比例
	OrderSpeed          float64 `json:"order_speed"`            // 接单速度所占比例
	Refund              float64 `json:"refund"`                 // 退款率所占比例
	SparringRefuse      float64 `json:"sparring_refuse"`        // 大神拒绝所占比例
	UserRefuse          float64 `json:"user_refuse"`            // 用户取消所占比例
}

// 微信公众号绑定参数
type WechatBindingParam struct {
	AppId       string `json:"app_id"`       // appid
	Secret      string `json:"secret"`       // 公众号唯一凭证密钥
	RedirectURL string `json:"redirect_uri"` // 重定向url

}

func (SystemParam) TableName() string {
	return "system_param"
}

const (
	// 值类型
	PRAM_VALUE_TYPE_TXT   int = iota // 文本
	PRAM_VALUE_TYPE_INT              // 整数
	PRAM_VALUE_TYPE_FLOAT            // 小数
	PRAM_VALUE_TYPE_JSON             // json

	// 配置key名称
	PRAM_KEY_TWEET_TAG                         = "tweet_tag"                         // 朋友圈首页tag
	PRAM_KEY_LOVE_NUMBER                       = "love_number"                       // 爱意数
	PRAM_KEY_SKILL_ORDER_REFUND                = "skill_order_refund"                // 订单退款原因
	PRAM_KEY_SKILL_ORDER_REFUSE_REFUND         = "skill_order_refuse_refund"         // 订单拒绝退款原因
	PRAM_KEY_SPARRING_SKILL_CHECK              = "sparring_skill_check"              // 大神审核时间
	PRAM_KEY_RECHARGE_TIPS                     = "recharge_tips"                     // 充值提示
	PRAM_KEY_CHECK_SWITCH                      = "check_switch"                      // 全局审核开关
	PRAM_KEY_VIP_SETTING                       = "vip_setting"                       // VIP配置信息
	PRAM_KEY_RECHARGE_ANDROID                  = "recharge_android"                  // 安卓充值参数
	PRAM_KEY_RECHARGE_WAP                      = "recharge_wap"                      // 网页充值参数
	PRAM_KEY_RECHARGE_IOS                      = "recharge_ios"                      // ios充值参数
	PRAM_KEY_FIRST_RECHARGE_CASH               = "first_recharge_cash"               // 首充金额
	PRAM_KEY_WITHDRAW_RULE                     = "withdraw_rule_params"              // 提现规则参数
	PRAM_KEY_WITHDRAW_CHANNEL_ID               = "withdraw_channel_id"               // 提现渠道id
	PRAM_KEY_LIVE_ANNOUNCE                     = "live_announce"                     // 直播系统公告
	PRAM_KEY_WEB_SITE_ARTICLE_CATEGORY_IDS     = "web_site_article_category_ids"     // 官网文章分类ids
	PRAM_KEY_SERVICE_QQ                        = "service_qq"                        // 客服QQ
	PRAM_KEY_SERVICE_WEIXIN                    = "service_weixin"                    // 客服微信
	PRAM_KEY_SERVICE_VIP_WEIXIN                = "service_vip_weixin"                // VIP客服微信
	PRAM_KEY_ROOM_HEAT_RATE                    = "room_heat_rate"                    // 房间热度倍率
	PRAM_KEY_SPARRING_QQ                       = "sparring_qq"                       // 技能处理QQ
	PRAM_KEY_LIVE_TEACH_URL                    = "live_teach_url"                    // 直播教学url
	PRAM_KEY_INDEX_RECOMMEND                   = "index_recommend"                   // 首页推荐位
	PRAM_KEY_INDEX_RECOMMEND_PAGE_MAX          = "index_recommend_page_max"          // 首页推荐位最大页数
	PRAM_KEY_DEFAULTMANICONURL                 = "defaultManIconurl"                 // 默认男生头像
	PRAM_KEY_DEFAULTWOMANICONURL               = "defaultWomanIconurl"               // 默认女生头像
	PRAM_KEY_DEFAULTANONYMOUSEVALUATIONICONURL = "defaultAnonymousEvaluationIconurl" // 匿名评价默认头像
	PRAM_KEY_DEFAULTNICKNAME                   = "defaultNickName"                   // 默认昵称
	PRAM_KEY_DEFAULTROOMBACKIMAGE              = "defaultRoomBackImage"              // 默认房间背景
	PRAM_KEY_DEFAULTROOMCOVERIMAGE             = "defaultRoomCoverImage"             // 默认房间封面
	PRAM_KEY_DEFAULTUSERBACKIMAGE              = "defaultUserBackImage"              // 默认用户背景
	PRAM_KEY_IM_INIT                           = "imInit"                            // im初始化
	PARAM_KEY_MEICHAI_AUTO_SIGN_IMG            = "meichai_auto_sign_img"             // 美差静默签图片
	PARAM_KEY_DRESS_PROHIBITED_TO_BUY_ATTR_ID  = "dressProhibitedToBuyAttrId"        // 禁止购买的attr_id
	PARAM_KEY_ANCHOR_REFUSE_QQ_GROUP           = "anchor_qq_group"                   // 拒绝主播申请qq群
	PARAM_KEY_COMMENT_INIT                     = "comment_init"                      // 订单评价初始化
	PARAM_KEY_CAN_REGION                       = "can_region_init"                   // LOL可接大区
	PARAM_KEY_ERRBREAK_CONFIG                  = "eggbreak_config"                   // 砸蛋配置
	PARAM_KEY_PAY_WARNING                      = "pay_warning"                       // 充值预警
	PARAM_KEY_SPARRING_SKILL_SCORE_PARAM       = "sparring_skill_score_param"        // 大神技能得分计算参数
	PARAM_KEY_LIVE_PK_SELECT                   = "live_pk_time_select"               // 大神技能得分计算参数
	PARAM_KEY_WEICHAT_BINDING                  = "wechat_binding"                    // 微信公众号绑定功能参数
	PARAM_KEY_VMS_SKILL_ORDER_MODEL_ID         = "vms_skill_order_model_id"          // 订单语音提示modelId
	PARAM_KEY_LIAOYILIAO_CONFIG                = "liaoyiliao_config"                 // 撩一撩主动推送配置
)

// QueryKey 根据配置key查询
func (sp *SystemParam) QueryKey(key string) (data map[string]string, err error) {
	str, err := utils.RedisClient.HGet(utils.REDIS_SYTEM_PARAM, key).Result()
	if err != nil && err != redis.Nil {
		return
	}
	// 缓存不存在，创建之
	if err == redis.Nil {
		systemparam := SystemParam{}
		err = utils.GEngine.Model(&sp).Where("deleted=0 AND param_key = ?", key).First(&systemparam).Error
		if err != nil {
			return
		}
		data = map[string]string{
			"key":   systemparam.ParamKey,
			"value": systemparam.ParamValue,
			"type":  strconv.Itoa(systemparam.ParamValueType),
		}
		str, _ := json.Marshal(data)
		err = utils.RedisClient.HSet(utils.REDIS_SYTEM_PARAM, key, string(str)).Err()
	} else {
		err = json.Unmarshal([]byte(str), &data)
	}
	return
}
func (sp *SystemParam) SearchList() (data []map[string]string, err error) {
	result, err := utils.RedisClient.HGetAll(utils.REDIS_SYTEM_PARAM).Result()
	if err != nil {
		return nil, err
	}
	var count int64 = 0
	err = utils.GEngine.Model(&sp).Where("deleted=0").Count(&count).Error
	if err != nil || count == 0 {
		return nil, err
	}
	if len(result) != int(count) {
		systemparam := []SystemParam{}
		err = utils.GEngine.Model(&sp).Where("deleted=0").Find(&systemparam).Error
		if err != nil {
			return
		}
		for _, v := range systemparam {
			intoData := map[string]string{
				"key":   v.ParamKey,
				"value": v.ParamValue,
				"type":  strconv.Itoa(v.ParamValueType),
			}
			data = append(data, intoData)
			intoJson, _ := json.Marshal(intoData)
			err = utils.RedisClient.HSet(utils.REDIS_SYTEM_PARAM, v.ParamKey, string(intoJson)).Err()
		}
	} else {
		for _, v := range result {
			intoData := map[string]string{}
			err = json.Unmarshal([]byte(v), &intoData)
			if err == nil {
				data = append(data, intoData)
			}
		}
	}
	return
}

// 更新
func (sp *SystemParam) UpdateValue(key, value string) (err error) {
	err = utils.GEngine.Model(sp).Where("param_key", key).Update("param_value", value).Error
	if err != nil {
		return
	}
	err = utils.RedisClient.HDel(utils.REDIS_SYTEM_PARAM, key).Err()
	return
}

// 更新(事务方法)
func (sp *SystemParam) UpdateValueAffairs(tx *gorm.DB, key, value string) (err error) {
	err = tx.Model(sp).Where("param_key=?", key).Update("param_value", value).Error
	if err != nil {
		return
	}
	err = utils.RedisClient.HDel(utils.REDIS_SYTEM_PARAM, key).Err()
	return
}
