package dbmodels

import (
	"gamers/utils"
)

//公会表
type AppUnion struct {
	UnionId             int64  `gorm:"column:union_id;primaryKey;autoIncrement"` // 公会id
	UnionName           string `gorm:"column:union_name"`                        // 公会名称
	UnionUserId         int64  `gorm:"column:union_user_id"`                     // 会长用户id
	UnionCode           uint64 `gorm:"column:union_code"`                        // 公会code
	UnionInviteKey      string `gorm:"column:union_invite_key"`                  // 邀请码
	UnionGiftScale      uint64 `json:"union_gift_scale" binding:"required"`      // 公会礼物分成比例 50=50%
	UnionSkillScale     uint64 `json:"union_skill_scale" binding:"required"`     // 公会陪玩分成比例 50=50%
	UnionTaxFee         uint64 `gorm:"column:union_tax_fee"`                     // 提现税点 50=50%
	UnionRoomCount      uint64 `gorm:"column:union_room_count"`                  // 公会房间数
	UnionMobile         string `gorm:"column:union_mobile"`                      // 联系手机号
	UnionIdcode         string `gorm:"column:union_idcode"`                      // 公会会长身份证号
	UnionExtractType    uint8  `gorm:"column:union_extract_type"`                // 提现类型(0支付宝,1银行卡)
	UnionExtractAccount string `gorm:"column:union_extract_account"`             // 提现账号
	UnionExtractBank    string `gorm:"column:union_extract_bank"`                // 开户行
	UnionExtractCompany string `gorm:"column:union_extract_company"`             // 公司名称
	BaseModel
}

func (AppUnion) TableName() string {
	return "app_union"
}

type AppUnionSearch struct {
	InviteKey string `json:"invite_key"` // 邀请码
}

type AppUnionSearchRetItem struct {
	UnionID            int64  `json:"union_id"`
	UnionCode          uint64 `json:"union_code"`
	UnionName          string `json:"union_name"`
	UnionInviteKey     string `json:"union_invite_key"`
	LogExist           int64  `json:"log_exist"`
	ApplyForJoinStatus int64  `json:"apply_for_join_status"`
}

func (u *AppUnion) Search(userID int64, search *AppUnionSearch) ([]*AppUnionSearchRetItem, error) {
	var db = utils.GEngine.Model(u).
		Select("union_id, union_code, union_name, union_invite_key, if(isnull(log_union_id), 0, 1) AS log_exist, log_status AS apply_for_join_status").
		Where("union_invite_key = ?", search.InviteKey).
		Joins("LEFT JOIN app_user_union_log ON app_union.union_id = app_user_union_log.log_union_id AND app_user_union_log.log_user_id = ?", userID).
		Order("app_user_union_log.created DESC").
		Limit(1)

	var result []*AppUnionSearchRetItem
	if err := db.Find(&result).Error; err != nil {
		return nil, err
	}

	for _, v := range result {
		// 不存在记录，修正为-1，表示没申请过
		if v.LogExist == 0 {
			v.ApplyForJoinStatus = -1
		}
	}

	return result, nil
}
