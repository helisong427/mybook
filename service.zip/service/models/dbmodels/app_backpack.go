package dbmodels

import (
	"encoding/json"
	"errors"
	"gamers/controller/response"
	"gamers/enum"
	"gamers/utils"
	"gamers/utils/prop"
	"gamers/utils/ymd"
	"github.com/go-redis/redis"
	"gorm.io/gorm"
	"strconv"
	"time"
)

//用户背包
type AppBackpack struct {
	BackpackId          int64     `gorm:"column:backpack_id;primaryKey;autoIncrement" json:"backpack_id"`
	BackpackUserId      int64     `gorm:"column:backpack_user_id" json:"backpack_user_id"`           // 用户id
	BackpackPropType    int       `gorm:"column:backpack_prop_type" json:"backpack_prop_type"`       // 道具类型(1礼物,2锤子,3头像框,4聊天框,5座驾,6活动道具,7实物道具,8Go币道具)
	BackpackPropId      int64     `gorm:"column:backpack_prop_id" json:"backpack_prop_id"`           // 道具id(更加type来区分不同)
	BackpackCount       int64     `gorm:"column:backpack_count" json:"backpack_count"`               // 道具数量
	BackpackPropAttrId  int64     `gorm:"column:backpack_prop_attr_id" json:"backpack_prop_attr_id"` // 道具属性id
	BackpackExpiredTime int64     `gorm:"column:backpack_expired_time"`                              // 过期时间如果为0表示永不过期
	WeekStarIcon        int64     `gorm:"-" json:"week_star_icon"`
	AppProp             AppProp   `gorm:"foreignKey:PropId;references:BackpackPropId"` // 关联道具表
	BaseModel           BaseModel `gorm:"embedded" json:"-"`
}

const (
	DB_PROP_TYPE_TYPE_GIFT   = 1 // 礼物
	DB_PROP_TYPE_TYPE_HAMMER = 2 // 锤子
	DB_PROP_TYPE_TYPE_AVATAR = 3 // 头像框
	DB_PROP_TYPE_TYPE_CHAT   = 4 // 聊天框
	DB_PROP_TYPE_TYPE_CAR    = 5 // 座驾
)

func (b *AppBackpack) TableName() string {
	return "app_backpack"
}

func (s *AppBackpack) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s AppBackpack) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

//创建
func (m *AppBackpack) Create(tx *gorm.DB) (data AppBackpack, err error) {
	err = tx.Create(m).Scan(&data).Error
	return
}

func (m *AppBackpack) CreateWeekStar() error {
	return utils.GEngine.Model(m).Create(m).Error
}

//增加道具数量
func (m *AppBackpack) AddCount(tx *gorm.DB, backPackId int64, backpackCount int64) (data AppBackpack, err error) {
	err = tx.Model(m).Where("backpack_id = ?", backPackId).
		Updates(map[string]interface{}{"backpack_count": gorm.Expr("backpack_count + ?", backpackCount)}).Scan(&data).Error
	return
}

//更新
func (m *AppBackpack) Update(tx *gorm.DB, backPackId int64, update map[string]interface{}) (err error) {
	err = tx.Model(m).Where("backpack_id = ?", backPackId).Updates(update).Error
	return
}

// 根据 userId 和 propType
func (b *AppBackpack) Query(userId int64, propType prop.Type) (data []*AppBackpack, err error) {
	db := utils.GEngine.Model(b).Preload("AppProp")
	if propType != prop.ExceptedTypeAll {
		db = db.Where("backpack_prop_type = ?", propType)
	}

	// 如果请求锤子数量  为了兼容老版本 金银锤子都返回给前端 保证取下标正确
	if propType == prop.TypeHammer {
		db = db.Where("backpack_count >= 0 and app_backpack.deleted = 0").Where("backpack_user_id = ?", userId)
	} else {
		db = db.Where("backpack_count > 0 and app_backpack.deleted = 0").Where("backpack_user_id = ?", userId)
	}
	if err := db.Find(&data).Error; err != nil {
		return nil, err
	}
	return
}

// 根据 userId propType propId
func (b *AppBackpack) QueryByPropId(userId, propId int64, propType prop.Type) (data []*AppBackpack, err error) {
	var db = utils.GEngine.Model(b).
		Preload("AppProp").
		Where("backpack_user_id = ?", userId)

	if propType != prop.ExceptedTypeAll {
		db = db.Where("backpack_prop_type = ?", propType)
	}

	if propId != 0 {
		db = db.Where("backpack_prop_id=?", propId)
	}
	db = db.Where("backpack_count > 0 and deleted = 0")

	if err := db.Find(&data).Error; err != nil {
		return nil, err
	}
	return
}

// 检查是否充足（暂只针对数量物品）
func (b *AppBackpack) CheckEnough(userId int64, propId int64, propCount int64) (bool, []*AppBackpack) {
	var lists []*AppBackpack
	if err := utils.GEngine.Model(b).Where("backpack_user_id = ? and backpack_prop_id = ?", userId, propId).Find(&lists).Error; err != nil {
		return false, nil
	}
	if len(lists) == 0 {
		return false, nil
	}
	if lists[0].BackpackCount >= propCount {
		return true, lists
	}
	return false, nil
}

// 增加物品（暂只针对数量物品）
func (b *AppBackpack) Add(db *gorm.DB) error {
	b.BackpackId = 0
	var ret = AppBackpack{}
	var err = db.Model(b).Where("backpack_user_id = ? and backpack_prop_id = ?", b.BackpackUserId, b.BackpackPropId).First(&ret).Error
	if err == nil {
		if ret.BackpackId == 0 {
			return db.Create(b).Error
		}
		return db.Model(b).Where("backpack_user_id = ? and backpack_prop_id = ?", b.BackpackUserId, b.BackpackPropId).
			Updates(map[string]interface{}{"backpack_count": gorm.Expr("backpack_count + ?", b.BackpackCount)}).Scan(b).Error
	} else if err == gorm.ErrRecordNotFound {
		return db.Create(b).Error
	} else {
		return err
	}
}

// 删除物品（暂只针对数量物品）
func (b *AppBackpack) Dec(db *gorm.DB, userId int64, propId int, propCount int) error {
	err := db.Model(b).Where("backpack_user_id = ? and backpack_prop_id = ? and deleted = 0", userId, propId).
		Updates(map[string]interface{}{"backpack_count": gorm.Expr("backpack_count - ?", propCount)}).Scan(b).Error
	if err != nil {
		return err
	}
	if b.BackpackId <= 0 || b.BackpackCount < 0 {
		return errors.New("not enough prop")
	}
	return nil
}

//根据类型查询未过期装扮
func (m *AppBackpack) QueryDressType(userId int64, propType int, attrId int64) (data []AppBackpack, err error) {
	err = utils.GEngine.
		Where("backpack_user_id = ? AND backpack_prop_type = ? AND backpack_prop_attr_id = ?", userId, propType, attrId).
		Where("(backpack_expired_time = 0 OR backpack_expired_time >= ?)", time.Now().Unix()).
		Find(&data).Error
	return
}

//根据道具id查询一条
func (m *AppBackpack) QueryFirstPropId(userId int64, propId int64, propType int) (data AppBackpack, err error) {
	err = utils.GEngine.
		Model(m).
		Preload("AppProp").
		Where("backpack_user_id = ? AND backpack_prop_id = ? AND backpack_prop_type = ? ", userId, propId, propType).
		Where("( backpack_expired_time = 0 OR backpack_expired_time >= ? )", time.Now().Unix()).
		First(&data).Error
	return
}

//获取用户背包礼物
func (m *AppBackpack) GetBackPackByUserId(userId int64) (results []response.BackGiftResp, err error) {
	now := time.Now().Unix()
	engine := utils.GEngine
	err = engine.Table("app_backpack").Preload("AppProp").
		Where("backpack_user_id = ? and deleted = 0 and backpack_prop_type = ? and backpack_count > 0", userId, DB_PROP_TYPE_TYPE_GIFT).
		Where("(backpack_expired_time = 0 or backpack_expired_time > ?)", now).
		Find(&results).Error
	return
}

func (m *AppBackpack) AfterFind(tx *gorm.DB) (err error) {
	go handleGiftIcon(m)
	return
}

func handleGiftIcon(v *AppBackpack) {
	var (
		nowGiftList string
		lockName    string
		ok          bool
		err         error
		result      *AppWeekStarResultItem
	)

	if lockName, ok = utils.AcquireLock(enum.REDIS_WEEK_STAR_LOCK, enum.REDIS_WEEK_STAR_LOCK_TIMEOUT, enum.REDIS_WEEK_STAR_LOCK_FORCE_TIMEOUT); ok {
		// 如果加锁成功, 则设置解锁
		defer func() {
			utils.ReleaseLock(enum.REDIS_WEEK_STAR_LOCK, lockName)
		}()
	}
	// 从 redis获取活动礼物ID
	if nowGiftList = utils.RedisClient.Get(enum.REDIS_WEEK_STAR_NOW_GIFT_LIST).Val(); nowGiftList != "" {

		if handleGiftList(nowGiftList, v.AppProp.PropId) {
			v.WeekStarIcon = 1
		}

		return
	}

	nowTime := time.Now().Unix()

	// 如果没有, 则从数据库获取 当前活动列表, 并且存入 redis设置过期时间
	if result, err = new(AppWeekStar).GetByNowTime(nowTime); err != nil {
		utils.Logger.Error(err.Error())
		return
	}

	if result.WeekStarGift == "" {
		return
	}

	expireTime := ymd.GetToday24TimeStamp() - nowTime

	if err = utils.RedisClient.Set(enum.REDIS_WEEK_STAR_NOW_GIFT_LIST, result.WeekStarGift, time.Second*time.Duration(expireTime)).Err(); err != nil {
		utils.Logger.Error(err.Error())
		return
	}

	if handleGiftList(nowGiftList, v.AppProp.PropId) {
		v.WeekStarIcon = 1
	}
}

func handleGiftList(nowGiftList string, propId int64) (ok bool) {
	var (
		propIds []int64
		err     error
	)

	ok = false

	if err = json.Unmarshal([]byte(nowGiftList), &propIds); err != nil {
		return
	}

	for _, v := range propIds {
		if v == propId {
			ok = true
			return
		}
	}

	return
}

// 删除缓存
func (m *AppBackpack) DelCache(userId, backpackId int64) (err error) {
	backpackIdStr := strconv.Itoa(int(backpackId))
	userIdStr := strconv.Itoa(int(userId))
	err = utils.RedisClient.HDel(utils.REDIS_LIVE_GIFT_BACKPACK+userIdStr, backpackIdStr).Err()
	if err != nil && err != redis.Nil {
		utils.LogErrorF("移除用户背包缓存失败,err:%s", err.Error())
		return
	}
	return nil
}

// 根据id查询
func (m *AppBackpack) GetBackPackById(userId, backpackId int64) (data AppBackpack, err error) {
	backpackIdStr := strconv.Itoa(int(backpackId))
	userIdStr := strconv.Itoa(int(userId))
	err = utils.RedisClient.HGet(utils.REDIS_LIVE_GIFT_BACKPACK+userIdStr, backpackIdStr).Scan(&data)
	if err != nil && err != redis.Nil {
		return
	}
	if err != redis.Nil {
		return
	}
	now := time.Now().Unix()
	err = utils.GEngine.Table("app_backpack").Preload("AppProp").
		Where("backpack_id = ? and deleted = 0", backpackId).
		Where("(backpack_expired_time = 0 or backpack_expired_time > ?) ", now).
		First(&data).Error
	if err != nil {
		return
	}
	err = utils.RedisClient.HSet(utils.REDIS_LIVE_GIFT_BACKPACK+userIdStr, backpackIdStr, data).Err()
	return
}

// 操作背包礼物数量
func (m *AppBackpack) UpdateBackpackCount(tx *gorm.DB, backpackId int64, isAdd bool, count int64) (data AppBackpack, err error) {
	//如果是增加
	if isAdd {
		err = tx.Model(m).Where("backpack_id = ?", backpackId).Updates(map[string]interface{}{"backpack_count": gorm.Expr("backpack_count + ?", count)}).Scan(&data).Error
	} else {
		err = tx.Model(m).Where("backpack_id = ?", backpackId).Updates(map[string]interface{}{"backpack_count": gorm.Expr("backpack_count - ?", count)}).Scan(&data).Error
	}
	return
}

//查询可叠加类物品的信息
func (m *AppBackpack) QueryStackable(tx *gorm.DB, userId int64, propId int64, propType int) (row int64, data AppBackpack, err error) {
	model := tx.Where("backpack_user_id = ? AND backpack_prop_id = ? AND backpack_prop_type = ?", userId, propId, propType).
		First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

//查询不可叠加类物品的信息
func (m *AppBackpack) QueryNoStackable(tx *gorm.DB, userId int64, propId int64, propType int) (row int64, data AppBackpack, err error) {
	model := tx.Where("backpack_user_id = ? AND backpack_prop_id = ? AND backpack_prop_type = ?", userId, propId, propType).
		Where("(backpack_expired_time = 0 OR backpack_expired_time > ?)", time.Now().Unix()).
		First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}
