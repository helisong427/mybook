package dbmodels

import (
	"gamers/controller/request"
	"gamers/enum"
	"gamers/utils"
	"gorm.io/gorm"
	"math"
	"strconv"
)

type AppSkillOrderComment struct {
	CommentID             uint64     `json:"comment_id" gorm:"column:comment_id"`
	CommentOrderID        uint64     `json:"comment_order_id" gorm:"column:comment_order_id"`             // 订单id
	CommentOrderUserID    uint64     `json:"comment_order_user_id" gorm:"column:comment_order_user_id"`   // 订单用户id
	CommentSparringID     uint64     `json:"comment_sparring_id" gorm:"column:comment_sparring_id"`       // 大神id
	CommentSkillID        uint64     `json:"comment_skill_id" gorm:"column:comment_skill_id"`             // 下单技能id
	CommentAttitude       uint64     `json:"comment_attitude" gorm:"column:comment_attitude"`             // 评价态度(0好评 1差评)
	CommentContent        string     `json:"comment_content" gorm:"column:comment_content"`               // 订单评价
	CommentLabel          string     `json:"comment_label" gorm:"column:comment_label"`                   // 评论标签(标签id 用逗号分割)
	CommentState          uint64     `json:"comment_state" gorm:"column:comment_state"`                   // 订单评论状态(0显示 1屏蔽 2折叠)
	CommentSystem         uint64     `json:"comment_system" gorm:"column:comment_system"`                 // 系统自动评价(0不是 1是)
	CommentAnonymous      uint64     `json:"comment_anonymous" gorm:"column:comment_anonymous"`           // 订单匿名(0不匿名 1匿名)
	CommentRepresentation uint64     `json:"comment_representation" gorm:"column:comment_representation"` // 申述评价(0不是 1是)
	CommentAdminOperator  string     `json:"comment_admin_operator" gorm:"column:comment_admin_operator"` // 评论操作人
	SystemUser            SystemUser `gorm:"foreignKey:UserID;references:CommentOrderUserID"`             // 关联用户信息
	BaseModel
}

func (m *AppSkillOrderComment) TableName() string {
	return "app_skill_order_comment"
}

// 根据评论id查询
func (m *AppSkillOrderComment) Get(commentId int64) (data AppSkillOrderComment, err error) {
	err = utils.GEngine.Model(m).Where("comment_id=?", commentId).First(&data).Error
	return
}

// 根据订单id查询
func (m *AppSkillOrderComment) GetByOrderId(orderId int64) (data AppSkillOrderComment, err error) {
	err = utils.GEngine.Model(m).Where("comment_order_id=?", orderId).First(&data).Error
	return
}

// 获取大神第一条评论
func (m *AppSkillOrderComment) GetSparringFirstComment(skillId int64) (data AppSkillOrderComment, err error) {
	err = utils.GEngine.Model(m).Joins("SystemUser").
		Where("comment_skill_id=?", skillId).
		Where("comment_content !=?", "").
		Where("comment_system=?", 0).
		Where("comment_state=?", enum.OrderEvaluationStateDisplay).
		Where("comment_representation=?", enum.OrderEvaluationNotRepresentation).Last(&data).Error
	return
}

// 获取大神有几条评论(评论内容不为空)
func (m *AppSkillOrderComment) GetSparringCommentNum(sparID int64) (num int64, err error) {
	err = utils.GEngine.Model(m).
		Where("comment_skill_id=?", sparID).
		Where("comment_content!=?", "").
		Where("comment_system=?", enum.NotSystemEvaluation).
		Where("comment_state=?", enum.OrderEvaluationStateDisplay).Count(&num).Error
	return
}

// 添加评论
func (m *AppSkillOrderComment) Create(tx *gorm.DB) (err error) {
	err = tx.Create(m).Error
	return
}

// 列表
func (m *AppSkillOrderComment) PageList(req request.OrderEvaluationListReq) (data []*AppSkillOrderComment, count int64, err error) {

	offset := utils.FuncGetOffset(req.Page, req.Size)
	model := utils.GEngine.Model(m).Joins("SystemUser")
	// 正常评论 后台显示正常且不匿名
	if req.CommentListType == enum.OrderEvaluationStateDisplay {
		model = model.Where("comment_state=?", enum.OrderEvaluationStateDisplay).Where("comment_content!=?", "")
	}
	// 折叠评论
	if req.CommentListType == enum.OrderEvaluationStateFold {
		model = model.Where("comment_state=?", enum.OrderEvaluationStateFold)
	}
	// 筛选标签id
	if req.CommentFilterLabelId != 0 {
		model = model.Where("comment_label LIKE ?", "%"+strconv.Itoa(int(req.CommentFilterLabelId))+"%")
	}
	err = model.Offset(offset).Limit(req.Size).Count(&count).Where("comment_skill_id=?", req.CommentSkillId).Order("created desc").Find(&data).Error
	return
}

// 大神服务人数
// @return servicePeopleNum 服务人数
// @return praiseNum	好评单
// @return favorableRate 好评率
// @return CommentNum  总评论数
func (m *AppSkillOrderComment) OrderNum(req request.OrderEvaluationListReq) (servicePeopleNum, praiseNum, favorableRate, CommentNum int64, err error) {
	err = utils.GEngine.Model(m).Where("comment_skill_id=?", req.CommentSkillId).Count(&servicePeopleNum).Error
	err = utils.GEngine.Model(m).Where("comment_skill_id=?", req.CommentSkillId).Where("comment_attitude=?", enum.LabelEvaluationPraise).Count(&praiseNum).Error
	err = utils.GEngine.Model(m).Where("comment_skill_id=?", req.CommentSkillId).Count(&CommentNum).Error
	favorableRate = int64(math.Floor(float64(praiseNum) / float64(servicePeopleNum) * 100))
	return
}

// 查找大神好差评数
// @return praiseNum 好评数
// @return badNum 差评数
func (m *AppSkillOrderComment) QuerySparringNum(tx *gorm.DB, commendSkillId int64) (praiseNum, badNum int64, err error) {
	err = tx.Model(m).Where("comment_skill_id=?", commendSkillId).
		Where("comment_attitude=?", enum.LabelEvaluationPraise).Count(&praiseNum).Error
	err = tx.Model(m).Where("comment_skill_id=?", commendSkillId).
		Where("comment_attitude=?", enum.LabelEvaluationBadReview).Count(&badNum).Error
	return
}

// 查找大神好评率
func (m *AppSkillOrderComment) QueryFavorableRate(skillId int64) (favorableRate int64, err error) {
	var praiseNum, servicePeopleNum int64
	err = utils.GEngine.Model(m).Where("comment_skill_id=?", skillId).Count(&servicePeopleNum).Error
	err = utils.GEngine.Model(m).Where("comment_skill_id=?", skillId).Where("comment_attitude=?", enum.LabelEvaluationPraise).Count(&praiseNum).Error
	favorableRate = int64(math.Floor(float64(praiseNum) / float64(servicePeopleNum) * 100))

	if favorableRate < 0 {
		favorableRate = 0
	}
	if favorableRate > 100 {
		favorableRate = 100
	}
	return
}
