package dbmodels

import (
	"fmt"
	"gamers/controller/response"
	"gamers/utils"
	"gorm.io/gorm"
)

//订单退款
type AppSkillOrderRefund struct {
	RefundId             int64     `gorm:"column:refund_id;primaryKey;autoIncrement" json:"refund_id"`
	RefundOrderId        int64     `gorm:"column:refund_order_id" json:"refund_order_id"`               // 申请退款的订单id
	RefundClass          int       `gorm:"column:refund_class" json:"refund_class"`                     // 退款类型(0全部退款,1)
	RefundCount          int64     `gorm:"column:refund_count" json:"refund_count"`                     // 退款代币数量
	RefundReason         string    `gorm:"column:refund_reason" json:"refund_reason"`                   // 退款申请原因
	RefundRemark         string    `gorm:"column:refund_remark" json:"refund_remark"`                   // 退款说明
	RefundSparringRefuse string    `gorm:"column:refund_sparring_refuse" json:"refund_sparring_refuse"` // 大神拒绝原因
	RefundSparringRemark string    `gorm:"column:refund_sparring_remark" json:"refund_sparring_remark"` // 拒绝说明
	RefundOldStatus      int       `gorm:"column:refund_old_status" json:"refund_old_status"`           // 拒绝说明
	BaseModel            BaseModel `gorm:"embedded" json:"-"`
}

const (
	SKILL_ORDER_REFUND_APPEAL_COUNT = 1 //满足申诉的退款次数
)

func (AppSkillOrderRefund) TableName() string {
	return "app_skill_order_refund"
}

func (m *AppSkillOrderRefund) Create(tx *gorm.DB) (err error) {
	err = tx.Model(m).Create(m).Error
	fmt.Println(m)
	return
}

//Update 更新订单信息
func (m *AppSkillOrderRefund) Update(tx *gorm.DB, refundId int64) (err error) {
	err = tx.Model(m).Where("refund_id = ?", refundId).Updates(m).Error
	return
}

//查询退款失败次数
func (m *AppSkillOrderRefund) QueryRefundFailCount(orderId int64) (total int64, err error) {
	err = utils.GEngine.Model(m).Where("refund_order_id = ?", orderId).Count(&total).Error
	return
}

//查询退款订单信息
func (m *AppSkillOrderRefund) GetAppSkillOrderRefundById(refundId int64) (data AppSkillOrderRefund, err error) {
	err = utils.GEngine.Model(m).Where("refund_id = ?", refundId).First(&data).Error
	return
}

//查询退款订单信息
func (m *AppSkillOrderRefund) GetAppSkillOrderRefundByOrderId(orderId int64) (data response.SkillOrderRefundInfo, err error) {
	err = utils.GEngine.Model(m).Where("refund_order_id = ?", orderId).Order("refund_id desc").First(&data).Error
	return
}
