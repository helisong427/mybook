package dbmodels

import (
	"gamers/utils"
)

//砸蛋表
type AppEggbreak struct {
	EggbreakId            int64                    `gorm:"column:eggbreak_id;primaryKey;autoIncrement"`     //砸蛋id
	EggbreakTitle         string                   `gorm:"column:eggbreak_title"`                           //名称
	EggbreakDesc          string                   `gorm:"column:eggbreak_desc"`                            //描述
	EggbreakCostPropType  int                      `gorm:"column:eggbreak_cost_prop_type"`                  //消耗物品类型(1锤子,2go币)
	EggbreakCostPropId    int64                    `gorm:"column:eggbreak_cost_prop_id"`                    //物品id
	EggbreakCostPropCount int64                    `gorm:"column:eggbreak_cost_prop_count"`                 //消耗物品数量
	EggbreakStatus        int                      `gorm:"column:eggbreak_status"`                          //状态(0计划中,1开始,2结束)
	EggbreakStartTime     int64                    `gorm:"column:eggbreak_start_time"`                      //开始时间(0不限)
	EggbreakEndTime       int64                    `gorm:"column:eggbreak_end_time"`                        //结束时间(0不限)
	CreateManageId        int64                    `gorm:"column:create_manage_id"`                         //创建id
	UpdateManageId        int64                    `gorm:"column:update_manage_id"`                         //最后修改id
	AppEggbreakPool       []*AppEggbreakPool       `gorm:"foreignKey:PoolEggbreakId;references:EggbreakId"` //关联奖池
	AppEggbreakRewardRate []*AppEggbreakRewardRate `gorm:"foreignKey:RateEggbreakId;references:EggbreakId"` //关联奖励概率表
	//SystemManage          SystemManage      `gorm:"foreignKey:ManageID;references:UpdateManageId"`   //关联管理员
	AppProp AppProp `gorm:"foreignKey:PropId;references:EggbreakCostPropId"` //关联道具
	BaseModel
}

const (
	//奖池状态
	DB_EGGBREAK_STATUS_CLOSE int = iota //计划中
	DB_EGGBREAK_STATUS_OPEN             //开始
	DB_EGGBREAK_STATUS_END              //结束
)

func (AppEggbreak) TableName() string {
	return "app_eggbreak"
}

//创建
func (m *AppEggbreak) Create() (err error) {
	err = utils.GEngine.Create(m).Error
	return
}

//查询全部
func (m *AppEggbreak) QueryAll() (data []AppEggbreak, err error) {
	err = utils.GEngine.Model(m).
		Preload("AppEggbreakPool").
		Preload("AppEggbreakPool.AppEggbreakReward").
		Preload("AppEggbreakPool.AppEggbreakReward.AppProp").
		Preload("AppEggbreakRewardRate").
		Preload("AppEggbreakRewardRate.AppProp").
		//Preload("SystemManage").
		Preload("AppProp").
		Find(&data).Error
	return
}

//根据EggbreakId查询
func (m *AppEggbreak) QueryByEggbreakId(eggbreakId int64) (data AppEggbreak, err error) {
	err = utils.GEngine.Model(m).
		Preload("AppEggbreakPool").
		Preload("AppEggbreakPool.AppEggbreakReward").
		Preload("AppEggbreakPool.AppEggbreakReward.AppProp").
		//Preload("AppEggbreakRewardRate").
		//Preload("AppEggbreakRewardRate.AppProp").
		//Preload("SystemManage").
		Preload("AppProp").
		Where("eggbreak_id = ?", eggbreakId).
		First(&data).Error
	return
}

//查询一条
func (m *AppEggbreak) QueryFirst(eggbreakId int) (row int64, data AppEggbreak, err error) {
	model := utils.GEngine.Where("eggbreak_id = ?", eggbreakId).First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

//更新砸蛋
func (m *AppEggbreak) Update(eggbreakId int, update map[string]interface{}) (err error) {
	err = utils.GEngine.Model(m).Where("eggbreak_id = ?", eggbreakId).Updates(update).Error
	return
}

//更新最后修改者id
func (m *AppEggbreak) UpdateManage(eggbreakId int64, mannageId int64) (err error) {
	err = utils.GEngine.Model(m).Where("eggbreak_id = ?", eggbreakId).Update("update_manage_id", mannageId).Error
	return
}
