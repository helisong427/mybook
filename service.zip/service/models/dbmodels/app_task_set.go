package dbmodels

import (
	"errors"
	"gamers/utils"
	"gorm.io/gorm"
)

// 任务集合

type AppTaskSet struct {
	SetID         uint32 `gorm:"column:set_id;primaryKey;" json:"set_id"`        // 任务集合ID
	SetName       string `gorm:"column:set_name;" json:"set_name"`               // 任务集合名字
	SetDesc       string `gorm:"column:set_desc;" json:"set_desc"`               // 任务集合描述
	SetFlag       uint32 `gorm:"column:set_flag;" json:"set_flag"`               // 任务集合特殊标记（\\n 0:无[通用任务集合];\\n 1:连续签到[只能选连续签到条件]\\n）
	SetModel      uint32 `gorm:"column:set_model" json:"set_model"`              // 任务集合模型(0任务中心 1.转盘任务)
	SetVerifyMode uint8  `gorm:"column:set_verify_mode;" json:"set_verify_mode"` // 任务集合检查模式(0:永久;1:每日更新)
	SetShow       uint32 `gorm:"column:set_show;" json:"set_show"`               // 任务集合内任务展示方式(0:默认状态[一直展示];1:任务领取后就隐藏)
	SetSort       uint32 `gorm:"column:set_sort;" json:"set_sort"`               // 任务集合排序(从小到大;如前端需要同时显示时,确定先后顺序)
	SetStatus     uint8  `gorm:"column:set_status;" json:"set_status"`           // 任务集合状态(0:关闭;1:开启)
	SetStartTime  uint32 `gorm:"column:set_start_time;" json:"set_start_time"`   // 任务集合开启时间
	SetEndTime    uint32 `gorm:"column:set_end_time;" json:"set_end_time"`       // 任务集合关闭时间
	BaseModel
	SetTasks []*AppTask `gorm:"foreignKey:TaskSetID;references:SetID" json:"set_tasks"`
}

func (AppTaskSet) TableName() string {
	return "app_task_set"
}

func (t *AppTaskSet) QueryAll() ([]*AppTaskSet, error) {
	var data []*AppTaskSet
	var err error

	err = utils.GEngine.Model(t).
		Preload("SetTasks").
		Preload("SetTasks.TaskRewards").
		Preload("SetTasks.TaskRewards.AppProp").
		Where("deleted = 0").
		Find(&data).Error

	if err != nil {
		return nil, err
	}
	return data, nil
}

func (t *AppTaskSet) QueryBySetID(setID uint32) (*AppTaskSet, error) {
	var data AppTaskSet
	var err error

	err = utils.GEngine.Model(t).
		Preload("SetTasks").
		Preload("SetTasks.TaskRewards").
		Preload("SetTasks.TaskRewards.AppProp").
		Where("set_id = ?", setID).
		First(&data).Error

	if err == gorm.ErrRecordNotFound {
		return nil, nil
	}

	if err != nil {
		return nil, err
	}
	return &data, nil
}

func (t *AppTaskSet) Create(db *gorm.DB, d *AppTaskSet) error {
	return db.Model(t).Create(d).Error
}

func (t *AppTaskSet) Update(db *gorm.DB, setID uint32, updates map[string]interface{}) error {
	return db.Model(t).Where("set_id = ?", setID).Updates(updates).Error
}

func (t *AppTaskSet) UpdateBySetData(data *AppTaskSet) error {
	if data == nil {
		return errors.New("not exist task set")
	}

	var updates = map[string]interface{}{}
	updates["set_name"] = data.SetName
	updates["set_desc"] = data.SetDesc
	updates["set_flag"] = data.SetFlag
	updates["set_verify_mode"] = data.SetVerifyMode
	updates["set_show"] = data.SetShow
	updates["set_sort"] = data.SetSort
	updates["set_status"] = data.SetStatus
	updates["set_start_time"] = data.SetStartTime
	updates["set_end_time"] = data.SetEndTime

	return utils.GEngine.Transaction(func(tx *gorm.DB) error {
		return t.Update(tx, data.SetID, updates)
	})
}

func (t *AppTaskSet) Delete(db *gorm.DB, setID uint32) error {
	return db.Model(t).Where("set_id = ?", setID).Delete(t).Error
}

// 删除（通过完整AppTaskSet，需要SetTasks连表信息）
func (t *AppTaskSet) DeleteBySetData(data *AppTaskSet) error {
	if data == nil {
		return nil
	}

	var setID = data.SetID
	var taskIDs []uint32
	for _, v := range data.SetTasks {
		taskIDs = append(taskIDs, v.TaskID)
	}

	return utils.GEngine.Transaction(func(tx *gorm.DB) error {
		if err := t.Delete(tx, setID); err != nil {
			return err
		}

		if err := new(AppTask).DeleteBySetID(tx, setID); err != nil {
			return err
		}

		var taskRewardObj = new(AppTaskReward)
		for _, taskID := range taskIDs {
			if err := taskRewardObj.DeleteByTaskID(tx, taskID); err != nil {
				return err
			}
		}

		return nil
	})
}
