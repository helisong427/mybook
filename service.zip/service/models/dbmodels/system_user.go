package dbmodels

import (
	"errors"
	"fmt"
	"gamers/controller/response"
	"gamers/enum"
	"gamers/utils"
	"gamers/utils/tencent/tencentIm"
	"strconv"

	"gorm.io/gorm"
)

// 用户表
type SystemUser struct {
	UserID                  int64                `gorm:"column:user_id;primaryKey;autoIncrement"`
	UserPrettyId            int64                `gorm:"column:user_pretty_id"`                                 // 用户靓号
	UserWechat              string               `gorm:"column:user_wechat"`                                    // 用户微信
	UserQQ                  string               `gorm:"column:user_qq"`                                        // 用户qq
	UserParentID            int64                `gorm:"column:user_parent_id"`                                 // 会员上级id
	UserMobile              string               `gorm:"column:user_mobile"`                                    // 手机号码
	UserPassword            string               `gorm:"column:user_password"`                                  // 密码
	UserSalt                string               `gorm:"column:user_salt"`                                      // 盐值
	UserNickname            string               `gorm:"column:user_nickname"`                                  // 昵称
	UserRealname            string               `gorm:"column:user_realname"`                                  // 真实姓名
	UserGender              int                  `gorm:"column:user_gender"`                                    // 用户性别0未知,1男,2女
	UserConstellation       string               `gorm:"column:user_constellation"`                             // 星座
	UserBirthday            int64                `gorm:"column:user_birthday"`                                  // 出生年月日
	UserIconurl             string               `gorm:"column:user_iconurl"`                                   // 头像
	UserIconurlVerification int                  `gorm:"column:user_iconurl_verification"`                      // 大神认证头像
	UserCountryID           int64                `gorm:"column:user_country_id"`                                // 国家id
	UserProvinceID          int64                `gorm:"column:user_province_id"`                               // 省份id
	UserCityID              int64                `gorm:"column:user_city_id"`                                   // 城市id
	UserRegionID            int64                `gorm:"column:user_region_id"`                                 // 区县id
	UserRegIP               uint                 `gorm:"column:user_reg_ip"`                                    // 注册ip
	UserRegPlatform         int                  `gorm:"column:user_reg_platform"`                              // 注册平台
	UserRegChannel          int64                `gorm:"column:user_reg_channel"`                               // 注册渠道
	UserRegPoint            int64                `gorm:"column:user_reg_point"`                                 // 注册点(广告创意标识,二级渠道标识等,0未知)
	UserSound               string               `gorm:"column:user_sound"`                                     // 用户声音地址
	UserSoundTime           int                  `gorm:"column:user_sound_time"`                                // 用户声音长度
	UserSlogan              string               `gorm:"column:user_slogan"`                                    // 用户签名
	UserGameSavor           string               `gorm:"column:user_game_savor"`                                // 游戏兴趣
	UserLiveSavor           string               `gorm:"column:user_live_savor"`                                // 直播兴趣
	UserBackImage           string               `gorm:"column:user_back_image;type:text"`                      // 用户背景图片json格式 ["图片地址1","图片地址2"]'
	UserLongitude           float32              `gorm:"column:user_longitude"`                                 // 经度
	UserLatitude            float32              `gorm:"column:user_latitude"`                                  // 纬度
	UserStatus              int                  `gorm:"column:user_status"`                                    // 状态(0--4:正常,5:自动锁定,6:管理员锁定,7:永久封号)
	UserSkillOrderCount     int                  `gorm:"column:user_skill_order_count"`                         // 技能被购买次数
	UserIsSparring          int                  `gorm:"column:user_is_sparring"`                               // 是否是陪练师
	UserIsAnchor            int                  `gorm:"column:user_is_anchor"`                                 // 是否是主播
	UserIsSuper             int                  `gorm:"column:user_is_super"`                                  // 是否超管：0--否，1--是
	UserYouthStatus         int                  `gorm:"column:user_youth_status"`                              // 青少年模式状态(0关闭,1开启)
	UserYouthPassword       string               `gorm:"column:user_youth_password"`                            // 青少年模式密码
	UserIsOnline            int                  `gorm:"column:user_is_online"`                                 // 是否在线:0--否,1--是
	UserGameOrder           string               `gorm:"column:user_game_order"`                                // 游戏页
	UserEggbreakMsg         int                  `gorm:"column:user_eggbreak_msg"`                              // 是否展示游戏消息(0展示,1不展示)
	UserLastLoginTime       int                  `gorm:"column:user_last_login_time"`                           // 最后登录时间
	UserUnionId             int64                `gorm:"column:user_union_id"`                                  // 公会id
	UserIsRecharge          int                  `gorm:"column:user_is_recharge"`                               // 是否充值(0没有,1充值)
	UserIsReview            int64                `gorm:"column:user_is_review"`                                 // 是否审核
	UserIsForwardsNews      int64                `gorm:"user_is_forwards_news" json:"user_is_forwards_news"`    // 是否开启浏览消息推送
	UserIsFirstLogin        int64                `gorm:"column:user_is_first_login" json:"user_is_first_login"` // 是否第一次登录(0是 1不是)
	BaseModel               BaseModel            `gorm:"embedded"`                                              // base
	AppUserVipExperience    AppUserVipExperience `gorm:"foreignKey:ExperienceUserId;references:UserID"`         // 关联vip
}

const MAX_USER_PRETTY_ID = 1000000000 // 靓号最大id

func (SystemUser) TableName() string {
	return "system_user"
}

// 用户性别
type UserGender int

const (
	USER_GENDER      UserGender = iota // 未知
	USER_GENDER_MAN                    // 男
	USER_GENDER_GIRL                   // 女
)

// 头像认证是否通过
const (
	USER_ICONURL_VERTIFICATION_INIT = iota
	USER_ICONURL_VERTIFICATION_OK
)

// 用户状态
type UserStatus int

const (
	USER_STATUS_OK         UserStatus = iota // 状态正常
	USER_STATUS_LOCK                  = 5    // 自动锁定
	USER_STATUS_ADMIN_LOCK            = 6    // 管理员锁定
	USER_STATUS_BAN                   = 7    // 永久封号
)

const (
	// 青少年模式状态
	USER_YOUTH_STATUS_OFF  int = iota // 关闭
	USER_YOUTH_STATUS_OPEN            // 开启
)

const (
	USER_IS_ONLINE_OFFLINE int = iota // 离线
	USER_IS_ONLINE_ONLINE             // 在线
)

const (
	USER_IS_FIRST_LOGIN  int = iota // 首次登录
	USER_NOT_FIRST_LOGIN            // 不是第一次登录
)

const (
	// 是否首充
	USER_RECHARGE_NO  int = iota // 否
	USER_RECHARGE_YES            // 是
)

const (
	USER_IS_SPARRING_NO = iota
	USER_IS_SPARRING_YES
)

const (
	USER_IS_ANCHOR_NO = iota
	USER_IS_ANCHOR_YES
)

// 创建用户
func (m *SystemUser) CreatUser() (err error) {
	if m.UserMobile != "" {
		gene, _ := strconv.ParseInt(m.UserMobile[len(m.UserMobile)-3:], 0, 64)
		userBaseId := IDBuilderGetId(utils.REDIS_IDBUILDER_USER_ID)
		if userBaseId <= 0 {
			return errors.New("userBaseId错误!")
		}
		m.UserID = userBaseId*100 + (gene % 32)
	} else {
		return errors.New("UserMobile不能为空!")
	}

	// 开启接受用户浏览的推送消息
	m.UserIsForwardsNews = 1

	err = utils.GEngine.Create(m).Error
	if err != nil {
		return err
	}

	// 注册用户钱包信息
	AppUserWalletModel := AppUserWallet{
		WalletUserId: m.UserID,
	}
	err = AppUserWalletModel.Create()
	if err != nil {
		return err
	}

	// 用户隐私表
	setting := SystemUserPrivacySetting{UserID: m.UserID}
	err = setting.Create()
	if err != nil {
		return err
	}

	err = tencentIm.AccountImport(m.UserID, m.UserNickname, m.UserIconurl)
	if err != nil {
		return err
	}
	go func() {
		clientStr := strconv.Itoa(m.UserRegPlatform)
		userIdStr := strconv.Itoa(int(m.UserID))
		item := make(map[string]string)
		item[enum.IM_USER_ATTR_SPARRING] = "0"
		item[enum.IM_USER_ATTR_ANCHOR] = "0"
		item[enum.IM_USER_ATTR_CLIENT] = clientStr
		err := tencentIm.AddUserAttr(userIdStr, item)
		if err != nil {
			utils.LogErrorF("设置用户属性失败,err:%s", err.Error())
		}
	}()
	return
}

// 根据手机号获取用户
func (m *SystemUser) MobileByUser(mobile string) (row int64, u SystemUser, err error) {
	model := utils.GEngine.Where("user_mobile = ?", mobile).First(&u)
	row = model.RowsAffected
	err = model.Error
	return
}

// 根据用户id获取用户
func (m *SystemUser) UserIdByUser(userId interface{}) (u SystemUser, err error) {
	err = utils.GEngine.Where("user_id = ?", userId).First(&u).Error
	return
}

// 更新用户信息
func (m *SystemUser) Update(userId int64, update map[string]interface{}) (err error) {
	err = utils.GEngine.Model(m).Where("user_id = ?", userId).Updates(update).Error
	return
}

// 更新用户信息
func (m *SystemUser) UpdateUserInfo(id int64) (err error) {
	err = utils.GEngine.Where("user_id = ?", id).Updates(m).Error
	return
}

// 用户登录，返回用户信息
func (m *SystemUser) UserLogin(mobile string, ip uint) (hadUser bool, user SystemUser, err error) {
	hadUser = true
	// 用户存在，直接登录
	row, user, err := m.MobileByUser(mobile)
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	if row != 0 {
		return
	}
	// 用户不存在，注册用户信息
	m.UserMobile = mobile
	m.UserRegIP = ip
	err = m.CreatUser()
	if err != nil {
		return
	}
	// 查询用户信息
	_, user, err = m.MobileByUser(mobile)
	hadUser = false
	return
}

// AddUserTotalAmount 增加用户收益
func (m *SystemUser) AddUserTotalAmount(tx *gorm.DB, amount int64, userId int64) (err error) {
	sql := "update `system_user` set user_sell_total_amount = user_sell_total_amount+? where user_id = ? "
	err = tx.Exec(sql, amount, userId).Error
	return
}

// 查询大神收益
func (m *SystemUser) GetSparringHomeInfo(userId int64) (sparring response.SparringHomeRes, err error) {
	// t := utils.GetMonthFirstDayTimeStamp()
	err = utils.GEngine.Table("system_user").
		Joins("inner join app_user_wallet on app_user_wallet.wallet_user_id = system_user.user_id").
		Select("system_user.user_id,system_user.user_iconurl_verification,system_user.user_nickname,system_user.user_gender,"+
			"system_user.user_birthday,system_user.user_iconurl,app_user_wallet.wallet_sparring_amount as total_income,system_user.user_pretty_id as user_pretty_id, system_user.user_is_forwards_news as user_is_forwards_news").
		Where("user_id = ?", userId).Find(&sparring).Error
	return
}

// 获取用户icon
func (m *SystemUser) GetUserIconByUserId(userId int64) (data response.HistoryIcon, err error) {
	session := utils.GEngine
	err = session.Model(m).Where("user_id = ? and deleted = 0", userId).First(&data).Error
	return
}

// 设置青少年模式
func (m *SystemUser) SetYouth(userId int64, password string) (err error) {
	err = utils.GEngine.Model(m).Where("user_id = ?", userId).Updates(map[string]interface{}{"user_youth_status": USER_YOUTH_STATUS_OPEN, "user_youth_password": password}).Error
	return
}

// 取消青少年模式
func (m *SystemUser) CancelYouth(userId int64) (err error) {
	err = utils.GEngine.Model(m).Where("user_id = ?", userId).Updates(map[string]interface{}{"user_youth_status": USER_YOUTH_STATUS_OFF, "user_youth_password": ""}).Error
	return
}

// 更新用户在线状态
func (m *SystemUser) UpdateOnline(userId string, isOnline int) (err error) {
	err = utils.GEngine.Model(m).Where("user_id = ?", userId).Updates(map[string]interface{}{"user_is_online": isOnline}).Error
	return
}

// 更新用户第一次登录
func (m *SystemUser) UpdateFirstLogin(userId string, isFirstLogin int) (err error) {
	err = utils.GEngine.Model(m).Where("user_id = ?", userId).Updates(map[string]interface{}{"user_is_first_login": isFirstLogin}).Error
	return
}

// 增加服务人次
func (m *SystemUser) AddSkillOrderCount(tx *gorm.DB, userId int64) (err error) {
	err = tx.Model(m).Where("user_id = ?", userId).Updates(map[string]interface{}{
		"user_skill_order_count": gorm.Expr("user_skill_order_count + ?", 1),
	}).Error
	return
}

// 模糊搜索用户id
func (m *SystemUser) QueryLikeByUserId(page int, size int, userId string) (total int64, u []response.SearchResultsListUser, err error) {
	err = utils.GEngine.Model(m).
		Where("user_id != ? and user_id LIKE ?", userId, "%"+userId+"%").
		Or("user_pretty_id != ? and user_pretty_id LIKE ?", userId, "%"+userId+"%").Order("user_pretty_id desc").
		Count(&total).
		Offset((page * size) - size).
		Limit(size).
		Find(&u).Error
	return
}

// 设置用户常用游戏
func (m *SystemUser) UpdateGameOrder(userId int64, gameOrder string) (err error) {
	err = utils.GEngine.Model(m).Where("user_id = ?", userId).UpdateColumn("user_game_order", gameOrder).Error
	return
}

// 消息中用户的个人信息
func (m *SystemUser) GetMsgUserInfo(userId int64) (data response.MsgUserInfoResp, err error) {
	err = utils.GEngine.Model(m).Where("user_id = ?", userId).First(&data).Error
	return
}

// 批量拉取
func (m *SystemUser) GetUserInfo(userIds []int64) (ret []*SystemUser, err error) {
	err = utils.GEngine.Model(m).Where("user_id in (?)", userIds).Find(&ret).Error
	return
}

// 根据账号查找用户
func (m *SystemUser) QueryUserByAccount(account int) (row int64, data SystemUser, err error) {
	model := utils.GEngine.Model(m).Where("user_id = ? OR user_mobile = ?", account, account).First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

func (m *SystemUser) QueryNormalUserByAccount(account int) (row int64, data SystemUser, err error) {
	model := utils.GEngine.Model(m).Where("user_mobile = ? AND user_status<=5", account).First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

// 获取用户手机号
func (m *SystemUser) GetUserMobile(userId int64) (mobile string, err error) {
	err = utils.RedisClient.HGet(fmt.Sprintf("%s%d", utils.REDIS_USER_INFO, userId), "Mobile").Scan(&mobile)
	if err == nil {
		return
	}
	err = utils.GEngine.Model(m).Where("user_id = ? and deleted = 0", userId).Select("user_mobile").First(&mobile).Error
	if err != nil {
		return
	}
	err = utils.RedisClient.HSet(fmt.Sprintf("%s%d", utils.REDIS_USER_INFO, userId), "Mobile", mobile).Err()
	return
}

// 搜索精准用户
func (m *SystemUser) GetSearchInfoByUserId(userId int64) (data response.SearchResultsListUser, err error, isPretty bool) {
	if userId >= MAX_USER_PRETTY_ID {
		err = utils.GEngine.Model(m).Where("user_id = ?  and deleted = 0", userId).First(&data).Error
		isPretty = false
	} else {
		err = utils.GEngine.Model(m).Where("user_pretty_id = ?  and deleted = 0", userId).First(&data).Error
		isPretty = true
	}
	return
}

// 更新用户联系方式
func (m *SystemUser) UpdateUserQQAndWechat(tx *gorm.DB, userId int64, qq, wechat string) (err error) {
	err = tx.Model(m).Where("user_id = ?", userId).Updates(map[string]interface{}{"user_qq": qq, "user_wechat": wechat}).Error
	return
}

type UserLongitudeResult struct {
	UserID        int64   `json:"user_id"`
	UserLatitude  float32 `json:"user_latitude"`
	UserLongitude float32 `json:"user_longitude"`
}

// 获取经纬度 列表
func (m *SystemUser) GetUserLongitudeList(userIds []int64) (data []*UserLongitudeResult, err error) {
	err = utils.GEngine.Model(m).Select("user_id, user_latitude, user_longitude").Where("deleted = 0").
		Where("user_id in ?", userIds).Find(&data).Error

	return
}

// 查询id最小的用id
func (m *SystemUser) QueryMinUserId() (data SystemUser, err error) {
	err = utils.GEngine.Select("user_id").Order("user_id asc").Limit(1).First(&data).Error
	return
}

// FindOnlineSparring 查询在线大神
func (m *SystemUser) FindOnlineSparring() (data []*SystemUser, err error) {

	err = utils.GEngine.Model(m).Where("user_is_online AND user_is_sparring = ?", 1, 1).
		Limit(10).
		Find(&data).Error
	// 查询指定数量大神头像
	return
}

// 查询指定数量大神头像
func (m *SystemUser) QuerySparringAvatar(size int) (data []SystemUser, err error) {
	err = utils.GEngine.Select("user_iconurl").Where("user_is_sparring = ?", USER_IS_SPARRING_YES).Limit(size).Find(&data).Error
	return
}

// 获取大神数量
func (m *SystemUser) QuerySparringCount() (count int64, err error) {
	err = utils.GEngine.Model(m).Where("user_is_sparring = ?", USER_IS_SPARRING_YES).Count(&count).Error
	return
}

// 按照性别in查询
func (m *SystemUser) QueryByGenderIn(ids []int64) (data []SystemUser, err error) {
	err = utils.GEngine.Select("user_id").Where("user_id IN (?) AND user_status < ?", ids, USER_STATUS_LOCK).Find(&data).Error

	return
}

func (m *SystemUser) QueryById(userId int64) (data SystemUser, err error) {
	err = utils.GEngine.Model(m).Where("deleted = 0").
		Where("user_id = ?", userId).
		First(&data).Error

	return
}
