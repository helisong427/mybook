package dbmodels

import (
	"gamers/utils"
	"gorm.io/gorm"
)

//朋友圈评论用户表
type AppTweetCommentUser struct {
	UserID        int64     `json:"user_id pk autoincr" gorm:"column:user_id;primaryKey;autoIncrement"`
	UserCommentID int64     `json:"user_comment_id"` //关联的评论id
	UserUserID    int64     `json:"user_user_id"`    //用户id
	UserIsLike    int       `json:"user_is_like"`    //是否点了喜欢(0:没有,1点赞)
	BaseModel     BaseModel `gorm:"embedded" json:"base_model"`
}

func (AppTweetCommentUser) TableName() string {
	return "app_tweet_comment_user"
}

//是否点了喜欢
const (
	USER_IS_LIKE_NO  int = iota //没有
	USER_IS_LIKE_YES            //点赞
)

//Create 创建
func (m *AppTweetCommentUser) Create() (err error) {
	m.UserIsLike = USER_IS_LIKE_YES
	err = utils.GEngine.Create(m).Error
	return
}

//QueryOne 查询一条数据
func (m *AppTweetCommentUser) QueryOne(userCommentId int, userUserId int) (has int64, data AppTweetCommentUser, err error) {
	model := utils.GEngine.Where("user_comment_id = ? and user_user_id = ?", userCommentId, userUserId).First(&data)
	has = model.RowsAffected
	err = model.Error
	return
}

//PointLike 点赞
func (m *AppTweetCommentUser) PointLike() (affected int64, err error) {
	tx := utils.GEngine
	update := AppTweetCommentUser{}
	model := tx.Model(update).Where("user_id = ?", m.UserID).Update("user_is_like", USER_IS_LIKE_YES)
	affected = model.RowsAffected
	err = model.Error
	if err == nil {
		//点赞成功也增加点赞数量
		m.AfterCreate(tx)
	}
	return
}

//CancelLike 取消赞
func (m *AppTweetCommentUser) CancelLike() (affected int64, err error) {
	tx := utils.GEngine
	update := AppTweetCommentUser{}
	update.UserIsLike = USER_IS_LIKE_NO
	model := tx.Model(update).Where("user_id = ?", m.UserID).Update("user_is_like", USER_IS_LIKE_NO)
	affected = model.RowsAffected
	err = model.Error
	if err == nil {
		m.AfterDelete(tx)
	}
	return
}

//Delete 删除
func (m *AppTweetCommentUser) Delete(userCommentId int, userUserId int) (err error) {
	err = utils.GEngine.Where("user_comment_id = ? and user_user_id = ?", userCommentId, userUserId).Delete(m).Error
	return
}

//AfterCreate 插入数据成功以后
func (m *AppTweetCommentUser) AfterCreate(tx *gorm.DB) error {
	appTweetModel := AppTweetComment{}
	//增加评论表点赞数
	appTweetModel.AddLikeCount(tx, m.UserCommentID)
	return nil
}

//AfterDelete 删除/取消点赞 成功以后
func (m *AppTweetCommentUser) AfterDelete(tx *gorm.DB) error {
	appTweetModel := AppTweetComment{}
	//减少评论表点赞数
	appTweetModel.DecreaseLikeCount(tx, m.UserCommentID)
	return nil
}
