package dbmodels

import "gamers/utils"

//话题
type AppTopic struct {
	TopicID         int64     `json:"topic_id pk autoincr" gorm:"column:topic_id;primaryKey;autoIncrement"`
	TopicTitle      string    `json:"topic_title"`       //话题
	TopicContent    string    `json:"topic_content"`     //话题内容
	TopicIsSystem   int       `json:"topic_is_system"`   //是否是系统话题(0不是,1是)
	TopicUserID     int64     `json:"topic_user_id"`     //话题发布者
	TopicShareCount int64     `json:"topic_share_count"` //分享数
	TopicReadCount  int64     `json:"topic_read_count"`  //阅读数
	BaseModel       BaseModel `gorm:"embedded" json:"base_model"`
}

func (AppTopic) TableName() string {
	return "app_topic"
}

//是否系统话题
type TopicIsSystem int

const (
	TOPIC_IS_SYSYTEM_NO  TopicIsSystem = iota //不是
	TOPIC_IS_SYSYTEM_YES                      //是
)

//Create 创建话题
func (m *AppTopic) Create() (err error) {
	err = utils.GEngine.Create(m).Error
	return
}

//QueryByTitle 根据标题查询
func (m *AppTopic) QueryByTitle(title string) (affected int64, topic AppTopic, err error) {
	model := utils.GEngine.Where("topic_title = ?", title).First(&topic)
	err = model.Error
	affected = model.RowsAffected
	return
}

//QueryByTitle 根据标题模糊查询
func (m *AppTopic) QueryByLikeTitle(title string) (topic []AppTopic, err error) {
	err = utils.GEngine.Where("topic_title like ?", "%"+title+"%").Find(&topic).Error
	return
}

//QueryHot 根据热度查询
func (m *AppTopic) QueryHot() (topics []AppTopic, err error) {
	err = utils.GEngine.Order("topic_read_count desc").Limit(10).Find(&topics).Error
	return
}
