package dbmodels

import "gamers/utils"

type AppSystemMessage struct {
	MessageId             int64  `gorm:"column:message_id;primaryKey;autoIncrement" json:"message_id"`    // 消息id
	MessageType           int    `gorm:"column:message_type" json:"message_type"`                         // 0 客服消息,1 推送消息
	MessageName           string `gorm:"column:message_name" json:"message_name"`                         // 消息名称
	MessageTitle          string `gorm:"column:message_title" json:"message_title"`                       // 消息title
	MessageSubtitle       string `gorm:"column:message_subtitle" json:"message_subtitle"`                 // 消息副标题
	MessageContent        string `gorm:"column:message_content" json:"message_content"`                   // 消息内容
	MessageUrl            string `gorm:"column:message_url" json:"message_url"`                           // 跳转内容
	MessageToUserType     int64  `gorm:"column:message_to_user_type" json:"message_to_user_type"`         // 用户类型(0全部,1指定用户,2筛选用户)
	MessageToUserIdentity int64  `gorm:"column:message_to_user_identity" json:"message_to_user_identity"` // 用户身份(0全部,1主播,2陪玩,3普通用户,4主播和普通用户,5陪玩和普通用户,6陪玩和主播)
	MessageToUserPlatform int    `gorm:"column:message_to_user_platform" json:"message_to_user_platform"` // 用户终端(0全部,1安卓,2ios,3web,4安卓和ios,5安卓和web,6ios和web)
	MessageToUserIds      string `gorm:"column:message_to_user_ids" json:"message_to_user_ids"`           // 发送用户id,用,分割
	MessageCcUserIds      string `gorm:"column:message_cc_user_ids" json:"message_cc_user_ids"`           // 抄送用户id,用,分割
	MessageRemark         string `gorm:"column:message_remark" json:"message_remark"`                     // 备注
	MessageJumpLink       string `gorm:"column:message_jump_link" json:"message_jump_link"`               // 跳转链接
	MessageJumpType       int    `gorm:"column:message_jump_type" json:"message_jump_type"`               // 跳转类型(0app内,1网站)
	MessageJumpButton     string `gorm:"column:message_jump_button" json:"message_jump_button"`           // 按钮名称
	MessageStatus         int64  `gorm:"column:message_status" json:"message_status"`                     // 状态 0未发送,1成功,2部分成功,3失败
	MessageSendTime       int64  `gorm:"column:message_send_time" json:"message_send_time"`
	MessageReturnId       string `gorm:"column:message_return_id"` // im任务id
	MessageAssistantType  int    `gorm:"column:message_assistant_type" json:"message_assistant_type"`
	BaseModel
}

func (AppSystemMessage) TableName() string {
	return "app_system_message"
}

const (
	MSG_PUSH_TYPE_KEFU = iota // 客服消息
	MSG_PUSH_TYPE_SYS         // 系统消息
)
const (
	MESSAGE_FINISHED_STATUS_INIT    = iota // 初始化,未发送
	MESSAGE_FINISHED_STATUS_OK             // 全部完成
	MESSAGE_FINISHED_STATUS_PART_OK        // 部分完成
	MESSAGE_FINISHED_STATUS_FAIL           // 失败
)

const (
	MESSAGE_PUSH_USER_IDENTITY_ALL                 = iota // 全部
	MESSAGE_PUSH_USER_IDENTITY_ANCHOR                     // 主播
	MESSAGE_PUSH_USER_IDENTITY_SPARRING                   // 陪玩
	MESSAGE_PUSH_USER_IDENTITY_NORMAL                     // 普通用户
	MESSAGE_PUSH_USER_IDENTITY_ANCHOR_AND_NORMAL          // 主播和普通用户
	MESSAGE_PUSH_USER_IDENTITY_SPARRING_AND_NORMAL        // 陪玩和普通用户
	MESSAGE_PUSH_USER_IDENTITY_SPARRING_AND_ANCHOR        // 大神和主播
)

// 更新状态
func (m AppSystemMessage) UpdateStatusAndReturnIdById(id int64, status int, returnId string) (err error) {
	err = utils.GEngine.Model(m).Where("message_id = ? ", id).Updates(map[string]interface{}{"message_status": status, "message_return_id": returnId}).Error
	return
}
