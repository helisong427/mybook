package dbmodels

import "gamers/utils"

//房间收藏表 app_room_favorite
type AppRoomFavorite struct {
	FavoriteId     int64     `json:"favorite_id" gorm:"column:favorite_id;primaryKey;autoIncrement"` //收藏用户id
	FavoriteUserId int64     `json:"favorite_user_id"`                                               //房间id
	FavoriteRoomId int64     `json:"favorite_room_id"`                                               //创建时间(注册时间)
	BaseModel      BaseModel `gorm:"embedded" json:"base_model"`
}

func (AppRoomFavorite) TableName() string {
	return "app_room_favorite"
}

//添加收藏记录
func (m *AppRoomFavorite) Create() (err error) {
	err = utils.GEngine.Create(m).Error
	return
}

//获取用户收藏房间列表
func (m *AppRoomFavorite) GetListByUserId(_userId int64) (results []AppRoomFavorite, err error) {
	err = utils.GEngine.Model(m).Where("favorite_user_id = ? and deleted = 0", _userId).Find(&results).Error
	if err != nil {
		return nil, err
	}
	return
}

//用户收藏的房间
func (m *AppRoomFavorite) GetIsFavoriteByUId(_userId int64, _roomId int64) (row int64, err error) {
	model := utils.GEngine.Model(m).Where("favorite_user_id = ? and favorite_room_id = ? and deleted = 0", _userId, _roomId).First(&m)
	row = model.RowsAffected
	err = model.Error
	return
}

//取消收藏，删除记录
func (m *AppRoomFavorite) Deleted() (err error) {
	err = utils.GEngine.Where("favorite_user_id = ? and favorite_room_id = ? and deleted = 0", m.FavoriteUserId, m.FavoriteRoomId).Delete(m).Error
	return
}
