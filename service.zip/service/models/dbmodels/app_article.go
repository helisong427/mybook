package dbmodels

import (
	"gamers/utils"
	"strings"
)

// AppArticle 文章
type AppArticle struct {
	ArticleID           int64     `gorm:"column:article_id;primaryKey;autoIncrement"`
	ArticleCategoryID   int64     `gorm:"column:article_category_id"`   //  文章分类
	ArticleTitle        string    `gorm:"column:article_title"`         //  文章标题
	ArticleTitleImage   string    `gorm:"column:article_title_image"`   //  标题图片
	ArticleContentImage string    `gorm:"column:article_content_image"` //  文章缩略图
	ArticleContent      string    `gorm:"column:article_content"`       //  文章内容
	ArticleUrl          string    `gorm:"column:article_url"`           //  文章链接
	ArticleStatus       int       `gorm:"column:article_status"`        //  文章状态(0不显示,1显示)
	ArticleOrder        int64     `gorm:"column:article_order"`         //  排序
	ArticleIntroduction string    `gorm:"article_introduction" json:"article_introduction"`
	BaseModel           BaseModel `gorm:"embedded"`
}

func (AppArticle) TableName() string {
	return "app_article"
}

//广告状态
type ArticleStatus int

const (
	ARTICLE_STATUS_SHOW  ArticleStatus = iota //关闭
	ARTICLE_STATUS_CLOSE                      //开启
)

//QueryByCategoryID 查询栏目下的全部
func (a *AppArticle) QueryByCategoryID(categoryId int64) (appArticle []AppArticle, err error) {
	err = utils.GEngine.Where(" article_category_id = ?  AND article_status = ? AND deleted=?", categoryId, 1, 0).Order("article_order asc").Find(&appArticle).Error
	return
}

func (a *AppArticle) QueryAll() (appArticle []AppArticle, err error) {
	err = utils.GEngine.Where("article_status = ?   AND deleted=?", 1, 0).Order("article_order asc").Find(&appArticle).Error
	return
}

func (a *AppArticle) QueryByCategoryIDS(categoryIDs string) (appArticle []AppArticle, err error) {
	err = utils.GEngine.Where("article_status = 1 AND deleted=0 AND article_category_id IN (?)", strings.Split(categoryIDs, ",")).Order("article_order asc").Find(&appArticle).Error
	return
}
func (a *AppArticle) QueryByArticleID(articleID int64) (appArticle AppArticle, err error) {
	err = utils.GEngine.Where(" article_id = ?  AND article_status = ? AND deleted=?", articleID, 1, 0).Order("article_order asc").First(&appArticle).Error
	return
}
