package dbmodels

import (
	"gamers/utils"
	"gorm.io/gorm"
	"time"
)

// 身份证号码提现
type AppIdCardWithdrawal struct {
	WithdrawalId        int64  `gorm:"column:withdrawal_id;primaryKey;autoIncrement"`
	WithdrawalIDCard    string `gorm:"column:withdrawal_idcard"`     // 身份证号码
	WithdrawalMonth     string `gorm:"column:withdrawal_month"`      // 提现月份(202103)
	WithdrawalAmount    uint64 `gorm:"column:withdrawal_amount"`     //本月提现总金额(人民币,分)
	WithdrawalChannelId uint64 `gorm:"column:withdrawal_channel_id"` //提现渠道
	BaseModel
}

func (AppIdCardWithdrawal) TableName() string {
	return "app_idcard_withdrawal"
}

func (m *AppIdCardWithdrawal) Create() (err error) {
	err = utils.GEngine.Create(m).Error
	return
}

// 按照月份和身份证号码查询一条
func (m *AppIdCardWithdrawal) QueryMonthFirst(idCard string) (data []AppIdCardWithdrawal, err error) {
	err = utils.GEngine.Where("withdrawal_month = ? AND withdrawal_idcard = ?", time.Now().Format("200601"), idCard).Group("withdrawal_channel_id").Find(&data).Error
	return
}

// 按照月份和身份证号码查询一条（事务）
func (m *AppIdCardWithdrawal) QueryMonthFirstBegin(tx *gorm.DB, idCard string, channelId uint64) (row int64, data AppIdCardWithdrawal, err error) {
	model := tx.Where("withdrawal_idcard = ? AND withdrawal_channel_id=? AND withdrawal_month = ? ", idCard, channelId, time.Now().Format("200601")).First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

// 增加提现金额
func (m *AppIdCardWithdrawal) AddAmount(tx *gorm.DB, idCard string, channelId uint64, amount uint64) (err error) {
	_, data, err := m.QueryMonthFirstBegin(tx, idCard, channelId)
	if err != nil {
		if err != gorm.ErrRecordNotFound {
			return
		} else {
			m.WithdrawalIDCard = idCard
			m.WithdrawalMonth = time.Now().Format("200601")
			m.WithdrawalAmount = amount
			m.WithdrawalChannelId = channelId
			err = tx.Create(m).Error
			return
		}
	}
	// 更改
	err = tx.Model(m).Where("withdrawal_id = ?", data.WithdrawalId).
		Updates(map[string]interface{}{"withdrawal_amount": gorm.Expr("withdrawal_amount + ?", amount)}).Error
	return
}
