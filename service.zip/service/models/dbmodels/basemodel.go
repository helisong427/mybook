package dbmodels

import (
	"fmt"
	"gamers/utils"
	"strings"
)

type BaseModel struct {
	Created int64 `json:"created" gorm:"autoCreateTime"`
	Edited  int64 `json:"edited" gorm:"column:edited;autoUpdateTime"`
	Deleted int64 `json:"-"`
}

type ReportBaseModel struct {
	Created int64 `json:"created" gorm:"autoCreateTime:milli"`
	Edited  int64 `json:"edited" gorm:"column:edited;autoUpdateTime:milli"`
	Deleted int64 `json:"-"`
}

//随机查询,返回主键
//indexName 主键
//tableName 表名称
//size 条数
//notIn 条件
//where 条件
//result 映射的结构体
func QueryRandIndex(indexName string, tableName string, size int, notIn []int, where string, and string, groupBy string, result interface{}) (err error) {
	sql := ""
	if len(notIn) > 0 {
		//有not in 加入 where not in 条件
		notInSql := "("
		for _, v := range notIn {
			notInSql += fmt.Sprintf("%d,", v)
		}
		notInSql = strings.TrimRight(notInSql, ",")
		notInSql += ")"
		sql = fmt.Sprintf("SELECT t1.%s FROM %s AS t1 JOIN ( SELECT ROUND( RAND() * (( SELECT MAX( %s ) FROM %s %s)-(SELECT  MIN( %s ) FROM %s %s))+( SELECT MIN( %s ) FROM %s %s)) AS id ) AS t2  WHERE  t1.%s >= t2.id AND t1.%s NOT IN %s %s %s LIMIT %d;", indexName, tableName, indexName, tableName, where, indexName, tableName, where, indexName, tableName, where, indexName, indexName, notInSql, and, groupBy, size)
	} else {
		sql = fmt.Sprintf("SELECT t1.%s FROM %s AS t1 JOIN ( SELECT ROUND( RAND() * (( SELECT MAX( %s ) FROM %s %s)-(SELECT  MIN( %s ) FROM %s %s))+( SELECT MIN( %s ) FROM %s %s)) AS id ) AS t2  WHERE  t1.%s >= t2.id %s  %s LIMIT %d;", indexName, tableName, indexName, tableName, where, indexName, tableName, where, indexName, tableName, where, indexName, and, groupBy, size)
	}
	err = utils.GEngine.Raw(sql).Scan(result).Error
	return
}
