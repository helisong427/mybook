package dbmodels

import (
	"gamers/utils"
	"gorm.io/gorm"
	"time"
)

type Action struct {
	ActionId               int64  `gorm:"column:action_id;primaryKey;autoIncrement" json:"action_id"`
	ActionDevice           string `gorm:"column:action_device" json:"action_device"` // 设备id
	ActionUdid             string `gorm:"column:action_udid" json:"action_udid"`
	ActionSystem           int    `gorm:"column:action_system" json:"action_system"`
	ActionChannel          string `gorm:"column:action_channel" json:"action_channel"`
	ActionPoint            string `gorm:"column:action_point" json:"action_point"`
	ActionSystemVersion    string `gorm:"column:action_system_version" json:"action_system_version"`
	ActionDeviceBrand      string `gorm:"column:action_device_brand" json:"action_device_brand"`
	ActionDevicePattern    string `gorm:"column:action_device_pattern" json:"action_device_pattern"`
	ActionScreenResolution string `gorm:"column:action_screen_resolution" json:"action_screen_resolution"`
	ActionAppVersion       string `gorm:"column:action_app_version" json:"action_app_version"`
	ActionIp               string `gorm:"column:action_ip" json:"action_ip"`
	ActionRegTime          int64  `gorm:"column:action_reg_time" json:"action_reg_time"`
	ActionMobile           string `gorm:"column:action_mobile" json:"action_mobile"`
	ActionIsModifyInfo     int    `gorm:"column:action_is_modify_info" json:"action_is_modify_info"`
	ActionUserId           int64  `gorm:"column:action_user_id"`
	ActionNickname         string `gorm:"column:action_nickname" json:"action_nickname"`
	ActionGender           int    `gorm:"column:action_gender" json:"action_gender"`
	ActionBirthday         int64  `gorm:"column:action_birthday" json:"action_birthday"`
	ActionCountryId        string `gorm:"column:action_country_id" json:"action_country_id"`
	ActionProvinceId       string `gorm:"column:action_province_id" json:"action_province_id"`
	ActionCityId           string `gorm:"column:action_city_id" json:"action_city_id"`
	ActionRegionId         string `gorm:"column:action_region_id" json:"action_region_id"`
	ActionLongitude        string `gorm:"column:action_longitude" json:"action_longitude"`
	ActionLatitude         string `gorm:"column:action_latitude" json:"action_latitude"`
	ActionOperateId        int    `gorm:"column:action_operate_id" json:"action_operate_id"`
	ReportBaseModel
}

func (Action) TableName() string {
	return "action"
}
func (m *Action) Create() (err error) {
	err = utils.REngine.Create(m).Error
	return
}

// 根据设备id获取注册时间
func (m *Action) GetRegTimeByUdid(udid string) (regTime int64) {
	err := utils.REngine.Model(m).Where("action_udid = ?", udid).Select("action_reg_time").First(&regTime).Error
	if err != nil && err != gorm.ErrRecordNotFound {
		utils.LogErrorF("查询设备【%s】注册时间出错", udid)
	}
	if err == gorm.ErrRecordNotFound {
		regTime = time.Now().UnixNano() / 1e6
	}
	return
}
