package dbmodels

import (
	"fmt"
	"gamers/utils"
)

// 第三方用户信息表
type SystemUserBinding struct {
	Id           int64  `gorm:"column:id;primaryKey;autoIncrement"`
	UserId       int64  `gorm:"column:user_id"`       // 用户ID
	Platform     uint   `gorm:"column:platform"`      // 绑定平台类型：1微信公众号
	PlatformInfo string `gorm:"column:platform_info"` // 平台信息，json格式：例如：{"appid": "aaaaaa","clientkey":"aaaaa"}
	BindingId    string `gorm:"column:binding_id"`    // 绑定内容
	Hash         string `gorm:"column:hash"`          // hash值
	PhoneNumber  string `gorm:"column:phone_number"`  // 手机号
	BaseModel
}

func (SystemUserBinding) TableName() string {
	return "system_user_binding"
}

const (
	PLATFORM_TYPE_WECHAT = 1 // 微信公众号

)

// 创建用户
func (m *SystemUserBinding) Create() (err error) {

	tx := utils.GEngine.Begin()

	err = tx.Create(m).Error
	if err != nil {
		tx.Rollback()
		return
	}

	sql1 := "UPDATE system_user_privacy_setting SET  direct_order_push = 0, random_order_push = 0 WHERE user_id = ?"
	err = tx.Exec(sql1, m.UserId).Error
	if err != nil {
		tx.Rollback()
		return
	}

	tx.Commit()

	// 删除开关缓存
	_ = utils.RedisClient.Del(fmt.Sprintf("%s%d", utils.Redis_User_Privacy_Setting, m.UserId)).Err()

	return
}

// 解除绑定
func (m *SystemUserBinding) Unbinding(userId int64, phoneNumber, hash, openid string, platform int) (err error) {

	var db = utils.GEngine

	tx := db.Begin()

	var sql = "DELETE FROM system_user_binding WHERE user_id = ? AND phone_number = ? AND hash = ? AND binding_id = ? AND platform = ?"
	err = tx.Exec(sql, userId, phoneNumber, hash, openid, platform).Error
	if err != nil {
		tx.Rollback()
		return
	}

	sql1 := "UPDATE system_user_privacy_setting SET  direct_order_push = 1, random_order_push = 1 WHERE user_id = ?"
	err = tx.Exec(sql1, userId).Error
	if err != nil {
		tx.Rollback()
		return
	}

	tx.Commit()

	// 删除开关缓存
	_ = utils.RedisClient.Del(fmt.Sprintf("%s%d", utils.Redis_User_Privacy_Setting, userId)).Err()

	return
}

// 根据用户ID查询用户
func (m *SystemUserBinding) GetByUserId(userId int64, platform int) (binding []SystemUserBinding, err error) {
	// ret := utils.GEngine.Where("user_id = ? and Platform = ? ", userId, platform).First(&binding)
	// if ret.Error != nil && ret.Error != gorm.ErrNotImplemented {
	// 	err = ret.Error
	// 	return
	// }
	//
	// if ret.Error == gorm.ErrRecordNotFound {
	// 	return
	// }
	//
	// exist = true

	var sql = "SELECT * FROM system_user_binding WHERE user_id = ? and Platform = ? "

	err = utils.GEngine.Raw(sql, userId, platform).Scan(&binding).Error

	return
}

// 根据用户openid查询用户
func (m *SystemUserBinding) GetByBindingId(bindingId string, platform int) (binding []SystemUserBinding, err error) {

	var sql = "SELECT * FROM system_user_binding WHERE binding_id = ? and Platform = ? "

	err = utils.GEngine.Raw(sql, bindingId, platform).Scan(&binding).Error

	return
}
