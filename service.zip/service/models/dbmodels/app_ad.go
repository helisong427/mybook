package dbmodels

import (
	"gamers/utils"
	"strconv"
	"time"

	jsoniter "github.com/json-iterator/go"
)

// AppAd 广告
type AppAd struct {
	AdId         int64     `gorm:"column:ad_id" json:"ad_id"`
	AdName       string    `gorm:"column:ad_name" json:"ad_name"`               //广告名称
	AdPositionId int64     `gorm:"column:ad_position_id" json:"ad_position_id"` //广告位id
	AdContent    string    `gorm:"column:ad_content" json:"ad_content"`         //广告内容
	AdUrl        string    `gorm:"column:ad_url" json:"ad_url"`                 //广告跳转链接
	AdJumpType   int64     `gorm:"column:ad_jump_type" json:"ad_jump_type"`     //跳转类型:0--网站跳转,1--app内跳转
	AdType       int64     `gorm:"column:ad_type" json:"ad_type"`               //广告类型(0图片,1H5,2url)
	AdOrder      int64     `gorm:"column:ad_order" json:"ad_order"`             //排序
	AdStartTime  int64     `gorm:"column:ad_start_time" json:"ad_start_time"`   //开始时间
	AdEndTime    int64     `gorm:"column:ad_end_time" json:"ad_end_time"`       //结束时间
	AdStatus     int64     `gorm:"column:ad_status" json:"ad_status"`           //广告状态 0--关闭 1--开启
	AdShowCount  int64     `gorm:"column:ad_show_count"  json:"ad_show_count"`  //展示次数
	BaseModel    BaseModel `gorm:"embedded" json:"-"`
}

type AppAdResutl struct {
	AdId         int64       `json:"ad_id"`
	AdName       string      `json:"ad_name"`        //广告名称
	AdPositionId int64       `json:"ad_position_id"` //广告位id
	AdContent    string      `json:"ad_content"`     //广告内容
	AdUrl        string      `json:"ad_url"`         //广告跳转链接
	AdJumpType   int64       `json:"ad_jump_type"`   //跳转类型:0--网站跳转,1--app内跳转
	AdType       int64       `json:"ad_type"`        //广告类型(0图片,1H5,2url)
	AdOrder      int64       `json:"ad_order"`       //排序
	AdStartTime  int64       `json:"ad_start_time"`  //开始时间
	AdEndTime    int64       `json:"ad_end_time"`    //结束时间
	AdShowCount  int64       `json:"ad_show_count"`  //展示次数
	AdStatus     int64       `json:"ad_status"`      //广告状态 0--关闭 1--开启
	AdURLParam   interface{} `json:"ad_url_param"`   // AdURL 广告跳转参数
}

// AdName 广告名称
// AdPositionID 广告位id
// AdContent 广告内容
// AdURL 广告跳转链接
// AdJumpType 跳转类型:
// 0--网站跳转
// 1--app内跳转
// URL跳转 = 0 {"url":"url"}
// 用户订单详情 = 1 {"order_id":12131322}
// 关注 = 3 {"user_id":12131322}
// 大神订单详情 =3 {"order_id":12131322}
// 房间 = 4 {"room_id":121}
// 首页游戏技能信息 =5 {"skill_id":1}
// 充值 = 5
// 广场热门 = 6
// 装扮商城 = 7
// 任务中心 = 8
// 动态详情 = 9 {"tweet_id":1}
// 动态发布 = 10
// 用户主页 = 11 {"user_id":12133113}
// 大神申请 = 12
// 主播申请 = 13
// AdType 广告类型(0图片,1H5,2url)
// AdOrder 排序
// AdStartTime 开始时间
// AdEndTime 结束时间
// AdStatus 广告状态 0--关闭 1--开启

const (
	AD_POSITION_ALL    int64 = iota //全部
	AD_POSITION_HTML                //1推广页 html
	AD_POSITION_LIVE                //2主播banner中心广告
	AD_POSITION_NOTICE              //3会话banner列表广告
	AD_POSITION_INDEX               //4首页banner广告
	AD_POSITION_POPUPS              //5弹窗广告
)

func (AppAd) TableName() string {
	return "app_ad"
}

//广告状态
type AdStatus int

const (
	AD_STATUS_CLOSE AdStatus = iota //关闭
	AD_STATUS_OK                    //开启
)

//广告类型
type AdType int

const (
	AD_TYPE_IMAGE AdType = iota //图片
	AD_TYPE_H5                  //H5
)

//QueryByPositionID 查询广告位的全部
func (a *AppAd) QueryByPositionID(positionId int64) (appad []AppAdResutl, err error) {
	//判断是否有缓存
	idStr := strconv.Itoa(int(positionId))
	key := utils.REDIS_AD_LIST_INFO + idStr
	err = utils.RedisClient.Get(key).Scan(&appad)
	if err != nil {
		var dbAppAd []AppAd
		currentTime := time.Now().Unix()
		err = utils.GEngine.Where("ad_status = ? AND ad_position_id = ? AND ad_start_time<=? AND (ad_end_time >=? or ad_end_time =?) AND deleted=?", 1, positionId, currentTime, currentTime, 0, 0).Order("ad_order ASC").Find(&dbAppAd).Error
		if err == nil {
			for _, v := range dbAppAd {
				adurlparam := make(map[string]interface{})
				jsoniter.UnmarshalFromString(v.AdUrl, &adurlparam)
				appad = append(appad, AppAdResutl{
					AdId:         v.AdId,
					AdName:       v.AdName,
					AdPositionId: v.AdPositionId,
					AdContent:    v.AdContent,
					AdUrl:        v.AdUrl,
					AdJumpType:   v.AdJumpType,
					AdType:       v.AdType,
					AdOrder:      v.AdOrder,
					AdStartTime:  v.AdStartTime,
					AdEndTime:    v.AdEndTime,
					AdStatus:     v.AdStatus,
					AdURLParam:   adurlparam,
					AdShowCount:  v.AdShowCount,
				})
			}
			utils.RedisClient.Set(key, appad, 60*60*24*time.Second)
		}
	}
	return
}
func (a *AppAd) QueryAll() (appADs []AppAdResutl, err error) {
	//判断是否有缓存
	key := utils.REDIS_AD_LIST_INFO + "0"
	err = utils.RedisClient.Get(key).Scan(&appADs)
	if err != nil {
		var dbAppAd []AppAd
		currentTime := time.Now().Unix()
		err = utils.GEngine.Where(" ad_start_time<=? AND (ad_end_time >=? or ad_end_time =?) AND ad_status = ? AND deleted=?", currentTime, currentTime, 0, 1, 0).Order("ad_order ASC").Find(&dbAppAd).Error
		if err == nil {
			for _, v := range dbAppAd {
				adurlparam := make(map[string]interface{})
				jsoniter.UnmarshalFromString(v.AdUrl, &adurlparam)
				appADs = append(appADs, AppAdResutl{
					AdId:         v.AdId,
					AdName:       v.AdName,
					AdPositionId: v.AdPositionId,
					AdContent:    v.AdContent,
					AdUrl:        v.AdUrl,
					AdJumpType:   v.AdJumpType,
					AdType:       v.AdType,
					AdOrder:      v.AdOrder,
					AdStartTime:  v.AdStartTime,
					AdEndTime:    v.AdEndTime,
					AdStatus:     v.AdStatus,
					AdURLParam:   adurlparam,
					AdShowCount:  v.AdShowCount,
				})
			}
			utils.RedisClient.Set(key, appADs, 60*60*24*time.Second)
		}
	}
	return
}
