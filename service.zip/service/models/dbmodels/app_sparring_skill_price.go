package dbmodels

import (
	"encoding/json"
	"gamers/utils"
	"strconv"
	"time"

	"github.com/go-redis/redis"
	"gorm.io/gorm"
)

// 大神技能价格表
type AppSparringSkillPrice struct {
	PriceId              int64         `gorm:"column:price_id" json:"price_id"`                               // 自增长id
	PriceType            int           `json:"price_type"`                                                    // 价格类型
	PriceSkillId         int64         `gorm:"column:price_skill_id" json:"price_skill_id"`                   // 技能id
	PriceUserId          int64         `gorm:"column:price_user_id" json:"price_user_id"`                     // 用户id
	PriceSparringSkillId int64         `gorm:"column:price_sparring_skill_id" json:"price_sparring_skill_id"` // 大神技能id
	PricePriceId         int64         `gorm:"column:price_price_id" json:"price_price_id"`                   // 计价单位,对应app_skill_price的 price_id
	PricePrice           int64         `gorm:"column:price_price" json:"price_price"`                         // 价格，下单价格
	AppSkillPrice        AppSkillPrice `gorm:"foreignKey:PriceId;references:PricePriceId"`                    // 一对一关联技能价格表
	BaseModel            BaseModel     `gorm:"embedded" json:"base_model"`
}

func (AppSparringSkillPrice) TableName() string {
	return "app_sparring_skill_price"
}

func (s *AppSparringSkillPrice) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s AppSparringSkillPrice) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

const (
	SPARRING_PRICE_TYPE_EDITED = iota // 自定义的
	SPARRING_PRICE_TYPE_SYS           // 系统自动关联的价格
)

// 根据skillId查询大神价格
func (m *AppSparringSkillPrice) GetPriceBySparringSkillId(SparringSkillId int64) (data []AppSparringSkillPrice, err error) {
	err = utils.GEngine.Model(m).Where("price_sparring_skill_id = ?", SparringSkillId).Find(&data).Error
	return
}

// 修改大神价格
func (m *AppSparringSkillPrice) UpdateSparringBySparringSkillId(tx *gorm.DB, priceIds, closes []int64, skillId int64) (err error) {
	del := time.Now().Unix()
	err = tx.Model(m).Where("price_id IN ? ", priceIds).Updates(map[string]interface{}{"deleted": 0}).Error
	if err != nil {
		return
	}
	err = tx.Model(m).Where("price_id IN ?", closes).Updates(map[string]interface{}{"deleted": del}).Error
	if err != nil {
		return
	}
	idStr := strconv.Itoa(int(skillId))
	err = utils.RedisClient.HDel(utils.REDIS_SPARRING_INFO, idStr).Err()
	if err != nil && err != redis.Nil {
		return
	}
	err = nil
	return
}

// 查询大神最小价格
func (m *AppSparringSkillPrice) GetSparringByMin(PriceSparringSkillId int64) (data AppSparringSkillPrice, err error) {
	err = utils.GEngine.Model(m).Preload("AppSkillPrice").Where("price_sparring_skill_id = ?", PriceSparringSkillId).
		Order("price_price_id asc").Limit(1).First(&data).Error
	return
}
