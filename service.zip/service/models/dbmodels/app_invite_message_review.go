package dbmodels

import (
	"gamers/controller/response"
	"gamers/utils"

	"gorm.io/gorm"
)

// AppInviteMessageReview 撩一撩邀请消息审查表
type AppInviteMessageReview struct {
	ReviewID           int64  `gorm:"column:review_id;primaryKey;autoIncrement"`
	ReviewUserID       int64  `gorm:"column:review_user_id"`        // 用户ID
	ReviewUserPrettyID int64  `gorm:"column:review_user_pretty_id"` // 用户靓号
	ReviewUserNickName string `gorm:"column:review_user_nickname"`  // 用户昵称
	ReviewContent      string `gorm:"column:review_content"`        // 邀请消息内容
	ReviewStatus       int    `gorm:"column:review_status"`         // 审核状态 0 未审核 1 审核通过 2审核拒绝
	ReviewRealName     string `gorm:"column:review_real_name"`      // 审核人员真实姓名
	ReviewRejectReason string `gorm:"column:review_reject_reason"`  // 审核拒绝原因
	BaseModel
}

// TableName 表名
func (*AppInviteMessageReview) TableName() string {
	return "app_invite_message_review"
}

// GetContentAndStatus 获取用户撩一撩邀请消息的内容和审核状态
func (r *AppInviteMessageReview) GetContentAndStatus() (data response.InviteMessageResp, err error) {
	result := &AppInviteMessageReview{}
	err = utils.GEngine.Model(result).
		Select("review_id,review_reject_reason,review_content,review_status").
		Where("review_user_id = ?", r.ReviewUserID).
		First(result).Error
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}

	// 忽略记录未找到错误
	err = nil
	data.ReviewID = result.ReviewID
	data.Content = result.ReviewContent
	data.Status = result.ReviewStatus
	data.RejectReason = result.ReviewRejectReason
	return
}

// Add 向撩一撩邀请消息审查表中添加一条记录
func (r *AppInviteMessageReview) Add() (err error) {
	tx := utils.GEngine.Begin()
	defer func() {
		if r := recover(); r != nil {
			tx.Rollback()
		}
	}()

	if err = tx.Error; err != nil {
		return
	}
	if err = tx.Create(r).Error; err != nil {
		tx.Rollback()
		return
	}

	actions := "提交申请"
	// tx.Create(&AppInviteMessageReviewLogs{
	// 	LogsUserID:   r.ReviewUserID,
	// 	LogsReviewID: r.ReviewID,
	// 	LogsName:     r.ReviewUserNickName,
	// 	LogsBehavior: actions,
	// })
	l := &AppInviteMessageReviewLogs{
		LogsUserID:   r.ReviewUserID,
		LogsReviewID: r.ReviewID,
		LogsName:     r.ReviewUserNickName,
		LogsBehavior: actions,
	}
	if err = l.Create(tx); err != nil {
		tx.Rollback()
		return
	}

	return tx.Commit().Error
}

// Edit 修改用户之前提交的撩一撩邀请消息内容，每天只能修一次,第二天零点可以修改。
func (r *AppInviteMessageReview) Edit() (err error) {
	tx := utils.GEngine.Begin()
	defer func() {
		if r := recover(); r != nil {
			tx.Rollback()
		}
	}()

	if err = tx.Error; err != nil {
		return
	}

	// 修改撩一撩邀请消息，修改之后变为未审核状态。
	if err = tx.Model(&AppInviteMessageReview{}).
		Where("review_id = ? ", r.ReviewID).
		Updates(map[string]interface{}{
			"review_content": r.ReviewContent,
			"review_status":  r.ReviewStatus,
		}).Error; err != nil {
		tx.Rollback()
		return
	}

	actions := "提交申请"
	l := &AppInviteMessageReviewLogs{
		LogsUserID:   r.ReviewUserID,
		LogsReviewID: r.ReviewID,
		LogsName:     r.ReviewUserNickName,
		LogsBehavior: actions,
	}
	if err = l.Create(tx); err != nil {
		tx.Rollback()
		return
	}

	return tx.Commit().Error
}

// GetStatus 获取用户审核状态
func (r *AppInviteMessageReview) GetStatus() (status int, err error) {
	result := &AppInviteMessageReview{}
	err = utils.GEngine.Model(result).
		Select("review_status").
		Where("review_id = ?", r.ReviewID).
		First(result).Error
	if err != nil {
		return
	}

	status = result.ReviewStatus
	return
}
