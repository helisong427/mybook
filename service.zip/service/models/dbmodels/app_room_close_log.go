package dbmodels

import (
	"gamers/utils"
	"gorm.io/gorm"
)

type AppRoomCloseLog struct {
	LogId        int64     `gorm:"column:log_id;primaryKey;autoIncrement"`
	LogRoomId    int64     `gorm:"column:log_room_id"`    //房间id
	LogType      int64     `gorm:"column:log_type"`       //日志类型(1管理员(房主)关闭,2超时关闭派对房间,3整改,4封禁)
	LogClass     int64     `gorm:"column:log_class"`      //处理类型:1涉黄,2涉赌,3涉政,4侮辱谩骂,5虚假宣传,6引导私下交易,7未成年相关,8导流,9诱骗礼物
	LogRemark    string    `gorm:"column:log_remark"`     //处理备注
	LogStartTime int64     `gorm:"column:log_start_time"` //开始时间
	LogEndTime   int64     `gorm:"column:log_end_time"`   //结束时间0表示永久
	BaseModel    BaseModel `gorm:"embedded" json:"base_model"`
}

const (
	CLOSE_LOG_TYPE_ADMIN_CLOSE   = iota + 1 // 关闭
	CLOSE_LOG_TYPE_TIMEOUT_CLOSE            // 超时关闭
	CLOSE_LOG_TYPE_RECTIFY                  // 整改
	CLOSE_LOG_TYPE_FORBIDDEN                // 封禁
)

func (AppRoomCloseLog) TableName() string {
	return "app_room_close_log"
}

func (m *AppRoomCloseLog) Create(tx *gorm.DB) (err error) {
	err = tx.Create(m).Error
	return
}

func (m *AppRoomCloseLog) Update(tx *gorm.DB) (err error) {
	err = tx.Model(m).Save(m).Error
	return
}

// 获取最新的一条关闭信息
func (m *AppRoomCloseLog) GetLastRectifyCloseLogByRoomId(roomId int64, closeType int) (data AppRoomCloseLog, err error) {
	err = utils.GEngine.Model(m).Where("log_room_id = ? and log_type = ?", roomId, closeType).Order("log_id desc").First(&data).Error
	return
}

// 获取最新的一条关闭信息
func (m *AppRoomCloseLog) GetLastCloseInfoByRoomId(roomId int64, sysClose, adminClose int) (data AppRoomCloseLog, err error) {
	err = utils.GEngine.Model(m).Where("log_room_id = ? and (log_type = ? or log_type = ?)", roomId, sysClose, adminClose).Order("log_id desc").First(&data).Error
	return
}
