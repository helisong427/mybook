package dbmodels

import (
	"fmt"
	"gamers/utils"

	"gorm.io/gorm"
)

// 主播-公会-房间中间表 app_room_admin
type AppRoomAdmin struct {
	AdminID      int64      `json:"admin_id" gorm:"column:admin_id;primaryKey;autoIncrement"`
	AdminUnionID int64      `json:"admin_union_id"` // AdminUnionID 公会id
	AdminRoomID  int64      `json:"admin_room_id"`  // AdminRoomID 房间id
	AdminUserID  int64      `json:"admin_user_id"`  // AdminUserID 用户id
	AdminRole    int        `json:"admin_role"`     // 房间角色(1房间副管理员,2房间管理员,3房主)
	BaseModel    BaseModel  `gorm:"embedded" json:"base_model"`
	SystemUser   SystemUser `gorm:"foreignKey:AdminUserID;joinForeignKey:UserID;"`
}

const (
	ROOM_ADMIN_ROLE_NORMAL        = iota // 普通用户
	ROOM_ADMIN_ROLE_DEPUTY_ANCHOR        // 房间副管理员
	ROOM_ADMIN_ROLE_ADMIN                // 房间管理员
	ROOM_ADMIN_ROLE_LANDLORD             // 房主
)

func (AppRoomAdmin) TableName() string {
	return "app_room_admin"
}

func (m *AppRoomAdmin) Create() (err error) {
	err = utils.GEngine.Save(m).Error
	return
}
func (m *AppRoomAdmin) CreateByTransaction(tx *gorm.DB) (err error) {
	err = tx.Save(m).Error
	return
}

func (m *AppRoomAdmin) Delete(roomId int, adminUserId int) (err error) {
	err = utils.GEngine.Where("admin_room_id = ? and admin_user_id = ?", roomId, adminUserId).Delete(m).Error
	return
}

// 根据用户id查询公会id
func (m *AppRoomAdmin) GetAnchorUnionIDByUserId(id int64) (AnchorUnionID int64) {
	err := utils.GEngine.Model(m).Where("admin_user_id = ? and deleted = 0 and admin_role > 0 ", id).Select("admin_union_id").FirstOrInit(&AnchorUnionID).Error
	if err != nil {
		errstr := fmt.Sprintf("根据用户id[%s]查询公会出错，err：%s", id, err.Error())
		utils.Logger.Error(errstr)
	}
	return
}

// 根据房间id获取房主
func (m *AppRoomAdmin) GetAdminMaster(_roomId int64) (master AppRoomAdmin, err error) {
	engine := utils.GEngine
	err = engine.Model(m).Where("admin_room_id = ? and admin_role = ? and deleted <= 0", _roomId, ROOM_ADMIN_ROLE_LANDLORD).First(&master).Error
	return
}

// 根据公会Id,用户id,房间id获取对象
func (m *AppRoomAdmin) GetAnchorMasterById(_uid, _rid int64, _unionId int64) (one AppRoomAdmin, err error) {
	err = utils.GEngine.Model(m).Where("admin_union_id = ? and admin_user_id = ? and admin_room_id = ?", _unionId, _uid, _rid).First(&one).Error
	return
}

// 根据用户id,房间id获取对象
func (m *AppRoomAdmin) GetAnchorByUIdAndRId(_uid, _rid int64) (one AppRoomAdmin, err error) {
	err = utils.GEngine.Model(m).Where("admin_user_id = ? and admin_room_id = ?", _uid, _rid).First(&one).Error
	return
}

// 根据用户id,房间id获取对象
func (m *AppRoomAdmin) GetRoomIdByUser(_uid, _rid int64) (row int64, data AppRoomAdmin, err error) {
	model := utils.GEngine.Model(m).Where("admin_user_id = ? and admin_room_id = ?", _uid, _rid).First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

// 根据房间id获取管理员详情
func (m *AppRoomAdmin) GetAdminDetails(roomId int64) (row int64, data []AppRoomAdmin, err error) {
	model := utils.GEngine.Model(m).Preload("SystemUser").Preload("SystemUser.AppUserVipExperience").Where("admin_room_id = ? ", roomId).Order("admin_role desc").Find(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

// 根据用户id,房间id查询管理员是否存在
func (m *AppRoomAdmin) QueryExits(_uid, _rid int64) (row int64, err error) {
	model := utils.GEngine.Model(m).Where("admin_user_id = ? and admin_room_id = ?", _uid, _rid).First(m)
	row = model.RowsAffected
	err = model.Error
	return
}

// 查询管理员用户
func (m *AppRoomAdmin) QueryAdmin(_uid, _rid int64) (row int64, data AppRoomAdmin, err error) {
	model := utils.GEngine.Model(m).Where("admin_user_id = ? and admin_room_id = ?", _uid, _rid).Where("admin_role = ? or admin_role = ?", ROOM_ADMIN_ROLE_ADMIN, ROOM_ADMIN_ROLE_DEPUTY_ANCHOR).First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

// 查询用户身份
func (m *AppRoomAdmin) QueryUser(_uid, _rid int64) (row int64, data AppRoomAdmin, err error) {
	model := utils.GEngine.Model(m).Where("admin_user_id = ? and admin_room_id = ?", _uid, _rid).First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

// 根据用户id,房间id查询房主是否存在
func (m *AppRoomAdmin) QueryExitsMaster(_uid, _rid int64) (err error) {
	model := utils.GEngine.Model(m).Where("admin_user_id = ? and admin_room_id = ? and admin_role = 3", _uid, _rid).First(m)
	err = model.Error
	return
}

// 查询用户角色
func (m *AppRoomAdmin) GetUserRole(userId, roomId int64) (role int, err error) {
	data := struct {
		AdminRole int `gorm:"column:admin_role"` // 房间角色(1房间副管理员,2房间管理员,3房主)
	}{}
	err = utils.GEngine.Model(m).Select("admin_role").Where("admin_user_id = ? and admin_room_id = ? and deleted = 0", userId, roomId).FirstOrInit(&data).Error
	role = data.AdminRole
	return
}

// 查询房间房东信息
func (m *AppRoomAdmin) GetAnchorId(roomId int64) (userId int64, err error) {
	data := struct {
		UserId int64 `gorm:"column:admin_user_id"` // 房间角色(1房间副管理员,2房间管理员,3房主)
	}{}
	err = utils.GEngine.Model(m).Where("admin_room_id = ? and admin_role = ?", roomId, ROOM_ADMIN_ROLE_LANDLORD).Select("admin_user_id").First(&data).Error
	userId = data.UserId
	return
}
