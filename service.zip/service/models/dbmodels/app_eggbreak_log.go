package dbmodels

import (
	"sort"

	"gamers/controller/response"
	"gamers/utils"
	"gamers/utils/prop"
)

// 砸蛋记录
type AppEggBreakLog struct {
	LogId            int       `gorm:"column:log_id" json:"log_id"`
	LogRecordId      int64     `gorm:"column:log_record_id" json:"log_record_id"`             // 砸蛋记录id
	LogUserId        int64     `gorm:"column:log_user_id" json:"log_user_id"`                 // 用户id
	LogEggbreakId    int       `gorm:"column:log_eggbreak_id" json:"log_eggbreak_id"`         // 砸蛋表的id
	LogEggbreakCount int       `gorm:"column:log_eggbreak_count" json:"log_eggbreak_count"`   // 砸蛋次数(如：1次/10次/50次/100次)
	LogCostPropType  prop.Type `gorm:"column:log_cost_prop_type" json:"log_cost_prop_type"`   // 消耗物品类型(1锤子,2go币)
	LogCostPropId    int       `gorm:"column:log_cost_prop_id" json:"log_cost_prop_id"`       // 消耗物品ID
	LogCostPropCount int       `gorm:"column:log_cost_prop_count" json:"log_cost_prop_count"` // 消耗物品数量
	LogPropType      prop.Type `gorm:"column:log_prop_type" json:"log_prop_type"`             // 物品类型(0礼物,1锤子,2go币)
	LogPropId        int       `gorm:"column:log_prop_id" json:"log_prop_id"`                 // 物品ID
	LogPropCount     int       `gorm:"column:log_prop_count" json:"log_prop_count"`           // 物品被抽到次数
	LogRoomId        int       `gorm:"column:log_room_id" json:"log_room_id"`                 // 砸蛋的RoomId
	BaseModel        `gorm:"embedded" json:"base_model"`
}

func (l *AppEggBreakLog) TableName() string {
	return "app_eggbreak_log"
}

func (l *AppEggBreakLog) Query(userId int64, eggBreakId int, size, skip int) (int64, []*response.EggBreakRecord, error) {
	var rows, err = utils.GEngine.Raw(`
	select log_record_id, log_eggbreak_count, log_prop_type, log_prop_id, log_prop_count, created, log_item_count from 
		(select * from app_eggbreak_log where log_user_id = ? and log_eggbreak_id = ?) as A
	right join
		(
		select log_record_id as b_log_record_id, count(*) as log_item_count from app_eggbreak_log
		where log_user_id = ? and log_eggbreak_id = ? 
		group by log_record_id 
		order by created desc, log_record_id desc limit ?, ?
    	) as B
	on A.log_record_id = B.b_log_record_id;
	`, userId, eggBreakId,
		userId, eggBreakId,
		skip, skip+size).Rows()

	if err != nil {
		return 0, nil, err
	}
	defer rows.Close()

	var propIdMaps = map[int64]int64{}                    // select prop config
	var recordMaps = map[int64]*response.EggBreakRecord{} // map[log_record_id]record
	for rows.Next() {
		receiver := &response.EggBreakRecord{}
		if err := rows.Scan(&receiver.LogRecordId, &receiver.LogEggbreakCount,
			&receiver.LogPropType, &receiver.LogPropId, &receiver.LogPropCount,
			&receiver.Created, &receiver.LogItemCount); err != nil {
			return 0, nil, err
		}
		if _, prs := recordMaps[receiver.LogRecordId]; !prs {
			recordMaps[receiver.LogRecordId] = receiver
		}
		var item = recordMaps[receiver.LogRecordId]
		item.LogDetails = append(item.LogDetails, &response.EggBreakRecordReward{
			PropType:  receiver.LogPropType,
			PropId:    receiver.LogPropId,
			PropCount: receiver.LogPropCount,
		})
		propIdMaps[int64(receiver.LogPropId)] = int64(receiver.LogPropId)
	}

	var respData = &response.EggBreakRecordsRep{
		EggbreakId: eggBreakId,
	}
	for _, v := range recordMaps {
		respData.Records = append(respData.Records, v)
	}
	sort.Slice(respData.Records, func(i, j int) bool {
		if respData.Records[i].Created != respData.Records[j].Created {
			return respData.Records[i].Created > respData.Records[j].Created
		}
		return respData.Records[i].LogRecordId > respData.Records[j].LogRecordId
	})

	if cfgMaps, err := new(AppProp).QueryByPropIdMaps(propIdMaps); err == nil {
		for _, v := range respData.Records {
			for _, d := range v.LogDetails {
				if cfg, ok := cfgMaps[int64(d.PropId)]; ok {
					d.PropName = cfg.PropName
					d.PropIcon = cfg.PropIcon
					d.PropPrice = cfg.PropOrgPrice
				}
			}
		}
	}

	for _, v := range respData.Records {
		sort.Slice(v.LogDetails, func(i, j int) bool {
			return v.LogDetails[i].PropPrice > v.LogDetails[j].PropPrice
		})
	}

	return int64(len(respData.Records)), respData.Records, nil
}

func (l *AppEggBreakLog) Log(logs []*AppEggBreakLog) error {
	if err := utils.GEngine.Model(l).Create(logs).Error; err != nil {
		return err
	}
	return nil
}
