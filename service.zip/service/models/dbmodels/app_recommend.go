package dbmodels

import (
	"encoding/json"
	"fmt"
	"gamers/utils"
	"github.com/go-redis/redis"
	"gorm.io/gorm"
)

//推荐
type AppRecommend struct {
	RecommendId         int64 `gorm:"column:recommend_id;primaryKey;autoIncrement" json:"recommend_id"`
	RecommendPositionId int64 `gorm:"column:recommend_position_id" json:"recommend_position_id"` //推荐位id
	RecommendUserId     int64 `gorm:"column:recommend_user_id" json:"recommend_user_id"`         //推荐位用户id
	RecommendPosition   int   `gorm:"column:recommend_position" json:"recommend_position"`       //推荐位置:0--首页大神位,1--首页专属推荐位
	RecommendType       int   `gorm:"column:recommend_type" json:"recommend_type"`               //推荐类型:0--派对,1--直播,2--大神,3--视频,4--图片
	RecommendNumber     int64 `gorm:"column:recommend_number" json:"recommend_number"`           //推荐编号
	RecommendWeight     int64 `gorm:"column:recommend_weight" json:"recommend_weight"`           //推荐权重
	RecommendStatus     int   `gorm:"column:recommend_status" json:"recommend_status"`           //推荐状态:0--关闭,1--开启
	BaseModel
}

const (
	//推荐位置
	RECOMMEND_POSITION_SPARRING  int = iota //首页大神位
	RECOMMEND_POSITION_EXCLUSIVE            //首页专属推荐位
)

const (
	//推荐类型
	RECOMMEND_TYPE_PARTY    int = iota //派对
	RECOMMEND_TYPE_LIVE                //直播
	RECOMMEND_TYPE_SPARRING            //大神
)

const (
	//推荐状态
	RECOMMEND_STATUS_OFF int = iota //关闭
	RECOMMEND_STATUS_ON             //开启
)

func (AppRecommend) TableName() string {
	return "app_recommend"
}

//根据位置和类型查询
func (m *AppRecommend) QueryByPositionAndType(position int, _type int) ([]AppRecommend, error) {
	var (
		data []AppRecommend
		err  error
	)
	redisClient := utils.RedisClient
	key := fmt.Sprintf("%s%d:%d", utils.REDIS_INDEX_RECOMMEND_POSITION, position, _type)
	result, err := redisClient.Get(key).Result()
	if err != nil && err != redis.Nil {
		return nil, err
	}
	if result == "" {
		err = utils.GEngine.Where("recommend_position = ? AND recommend_type = ? AND recommend_status = ? AND deleted = 0", position, _type, RECOMMEND_STATUS_ON).Find(&data).Error
		if err != nil {
			return nil, err
		}
		marshal, err := json.Marshal(data)
		if err != nil {
			return nil, err
		}
		err = redisClient.Set(key, string(marshal), -1).Err()
		if err != nil {
			return nil, err
		}
	} else {
		err = json.Unmarshal([]byte(result), &data)
		if err != nil {
			return nil, err
		}
	}

	ids := []int64{}
	for _, v := range data {
		ids = append(ids, v.RecommendPositionId)
	}
	//根据类型预查询状态,排除非预期状态的推荐位
	if _type == RECOMMEND_TYPE_PARTY || _type == RECOMMEND_TYPE_LIVE {
		roomType := ROOM_TYPE_PARTY
		if _type == RECOMMEND_TYPE_LIVE {
			roomType = ROOM_TYPE_LIVE
		}

		row, rooms, err := new(AppLiveRoom).QueryInFilter(ids, roomType)
		if err != nil && err != gorm.ErrRecordNotFound {
			return data, err
		}
		if int(row) < len(data) {
			metaData := make(map[int64]int64)
			for _, v := range rooms {
				metaData[v.RoomId] = 1
			}
			tmpData := []AppRecommend{}
			for _, v := range data {
				if _, ok := metaData[v.RecommendPositionId]; ok {
					tmpData = append(tmpData, v)
				}
			}
			data = data[:0]
			data = tmpData
		}
	} else {
		row, skills, err := new(AppSparringSkill).QueryInFilter(ids)
		if err != nil && err != gorm.ErrRecordNotFound {
			return data, err
		}
		if int(row) < len(data) {
			metaData := make(map[int64]int64)
			for _, v := range skills {
				metaData[v.SkillID] = 1
			}
			tmpData := []AppRecommend{}
			for _, v := range data {
				if _, ok := metaData[v.RecommendPositionId]; ok {
					tmpData = append(tmpData, v)
				}
			}
			data = data[:0]
			data = tmpData
		}
	}
	return data, err
}
