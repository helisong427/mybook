/**
 * @Author: panke
 * @Description:
 * @File: app_turn_table_address
 * @Date: 2021/4/22 16:47
 */

package dbmodels

import (
	"gamers/controller/request"
	"gamers/utils"
	"github.com/pkg/errors"
	"gorm.io/gorm"
)

type AppTurnTableAddress struct {
	AddressID     int    `json:"address_id" gorm:"column:address_id"`
	AddressUserID int64  `json:"address_user_id" gorm:"column:address_user_id"` // 用户id
	AddressName   string `json:"address_name" gorm:"column:address_name"`       // 用户姓名
	AddressDetail string `json:"address_detail" gorm:"column:address_detail"`   // 地址详情
	AddressMobile string `json:"address_mobile" gorm:"column:address_mobile"`   // 用户手机号码
	AddressQq     string `json:"address_qq" gorm:"column:address_qq"`           // 用户qq
	AddressWx     string `json:"address_wx" gorm:"column:address_wx"`           // 用户微信
	BaseModel
}

func (m *AppTurnTableAddress) TableName() string {
	return "app_turn_table_address"
}

// 获取地址
func (m *AppTurnTableAddress) Get(addressId int64) (data AppTurnTableAddress, err error) {
	err = utils.GEngine.Model(m).Where("address_user_id=?", addressId).Take(&data).Error
	return
}

// 保存或更新
func (m *AppTurnTableAddress) SaveOrUpdate(userId int64, req request.TurnTableAddress) (err error) {
	if req.AddressId == 0 {
		return utils.GEngine.Transaction(func(tx *gorm.DB) error {
			// 判断是否存在
			var count int64 = 0
			if err := tx.Table("app_turn_table_address").Where("address_user_id = ?", userId).Count(&count).Error; err != nil {
				return err
			}
			if count > 0 {
				return errors.New("该用户已存在地址,请勿重复提交!")
			}

			model := AppTurnTableAddress{
				AddressUserID: userId,
				AddressName:   req.TurnTableAddressName,
				AddressDetail: req.TurnTableDetail,
				AddressMobile: req.TurnTableMobile,
				AddressQq:     req.TurnTableQQ,
				AddressWx:     req.TurnTableWX,
			}
			if err := tx.Table("app_turn_table_address").Create(&model).Error; err != nil {
				return err
			}
			return nil
		})
	} else {
		err = utils.GEngine.Model(m).Where("address_id=?", req.AddressId).Updates(map[string]interface{}{
			"address_name":   req.TurnTableAddressName,
			"address_detail": req.TurnTableDetail,
			"address_mobile": req.TurnTableMobile,
			"address_qq":     req.TurnTableQQ,
			"address_wx":     req.TurnTableWX,
		}).Error
		return
	}
}
