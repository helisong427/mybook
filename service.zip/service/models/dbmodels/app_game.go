package dbmodels

import (
	"encoding/json"
	"gamers/controller/response"
	"gamers/utils"
	"strconv"
	"sync"

	"github.com/go-redis/redis"
	"github.com/leyle/ginbase/consolelog"
)

type AppGame struct {
	GameId      int64     `json:"game_id" gorm:"column:game_id;primaryKey;autoIncrement"`
	GameName    string    `json:"game_name"`
	GameParam   string    `json:"game_param"`
	GameType    int       `json:"game_type"`
	GameIconurl string    `json:"game_iconurl"`
	BaseModel   BaseModel `gorm:"embedded" json:"base_model"`
}

func (s *AppGame) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s AppGame) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

const (
	APP_GAME_DEFAULT_KEY = 2 //默认计价单位的key
)

type AppGameStructEr struct {
	GameLevel        AppGameArray `json:"GameLevel"`
	AcceptRegion     AppGameArray `json:"AcceptRegion"`
	AcceptLevel      AppGameArray `json:"AcceptLevel"`
	GoodPosition     AppGameArray `json:"GoodPosition"`
	GoodHero         AppGameArray `json:"GoodHero"`
	SkillPrice       AppGameArray `json:"SkillPrice"`
	ApplicationLevel AppGameArray `json:"ApplicationLevel"`
	OrderTime        AppGameArray `json:"OrderTime"`
	OrderLimit       AppGameArray `json:"OrderLimit"`
}

type TmpGameStruct struct {
	AppGame         AppGame
	AppGameStructEr AppGameStructEr
}

type AppGameArray struct {
	Title string
	Value []struct {
		Key   int    `json:"key"`
		Title string `json:"title"`
	} `json:"value"`
}

func (AppGame) TableName() string {
	return "app_game"
}

//QueryByUserId 根据游戏id查询
func (m *AppGame) QueryByGameId(gameId int64) (data AppGame, err error) {
	gameid := strconv.Itoa(int(gameId))
	err = utils.RedisClient.HGet(utils.REDIS_SKILL_INFO, gameid).Scan(&data)
	if err != nil && err != redis.Nil {
		return
	}
	if err == nil {
		return
	}
	err = utils.GEngine.Model(m).Where("game_id = ? and deleted = 0 skill_status=1", gameId).First(&data).Error
	if err != nil {
		return
	}
	err = utils.RedisClient.HSet(utils.REDIS_SKILL_INFO, gameid, data).Err()
	return
}

// 查询游戏列表
func (m *AppGame) QueryGame() (data []response.QueryGameRep, err error) {
	var gameTypes []int
	err = utils.GEngine.Model(m).
		Group("game_type").
		Select("game_type").Where("deleted = 0").
		Find(&gameTypes).Error
	//fmt.Println(gameTypes)
	if err != nil || len(gameTypes) < 1 {
		return
	}
	wg := sync.WaitGroup{}
	repchan := make(chan response.QueryGameRep, len(gameTypes))
	for _, v := range gameTypes {
		wg.Add(1)
		go SearchGames(v, &wg, repchan)
	}
	wg.Wait()
	close(repchan)
	for m := range repchan {
		data = append(data, m)
	}
	return
}

func SearchGames(v int, wg *sync.WaitGroup, repchan chan response.QueryGameRep) {
	defer wg.Done()
	var games []response.GameInfoRep
	err := utils.GEngine.Model(AppGame{}).Where("game_type = ? and deleted = 0", v).Find(&games).Error
	if err != nil {
		consolelog.Logger.Errorf("", "查询游戏err：%s", err.Error())
		return
	}
	rep := response.QueryGameRep{
		GameType: v,
		Games:    games,
	}
	repchan <- rep
	return
}

//QueryGameParam 获取游戏参数
func (m *AppGame) QueryGameParam() (data []AppGame, err error) {
	err = utils.GEngine.Select("game_id,game_name,game_param").Find(&data).Error
	return
}

//获取游戏名称
func (m *AppGame) QueryGameName() (data []AppGame, err error) {
	err = utils.GEngine.Select("game_id,game_name").Find(&data).Error
	return
}

//in查询游戏名称
func (m *AppGame) QueryInGameName(ids []string) (data []AppGame, err error) {
	err = utils.GEngine.Select("game_id,game_name").Where("game_id IN ?", ids).Find(&data).Error
	return
}
