package dbmodels

import (
	"gamers/controller/response"
	"gamers/utils"
	"gorm.io/gorm"
	"time"
)

//AppRoomOpenLog 房间开播日志
type AppRoomOpenLog struct {
	LogId            int64     `json:"log_id" gorm:"column:log_id;primaryKey;autoIncrement"`
	LogAnchorId      int64     `json:"log_anchor_id"`                                         //收礼主播id
	LogRoomId        int64     `json:"log_room_id"`                                           //房间id
	LogAnchorUnionId int64     `gorm:"column:log_anchor_union_id" json:"log_anchor_union_id"` // 主播公会id
	LogUnionId       int64     `json:"log_union_id"`                                          //公会id
	LogRoomType      int       `json:"log_room_type"`                                         //类型(0音频直播,1音频派对)
	LogLiveStatus    int       `json:"log_live_status"`                                       //直播状态,直播类型才有效(0下播,1上播)
	LogRoomAttrId    int64     `json:"log_room_attr_id"`                                      //收到礼物时房间属性id
	LogStartTime     int64     `json:"log_start_time"`                                        //开始时间
	LogEndTime       int64     `json:"log_end_time"`                                          //结束时间
	BaseModel        BaseModel `gorm:"embedded" json:"base_model"`
}

func (AppRoomOpenLog) TableName() string {
	return "app_room_open_log"
}

//创建直播日志
func (m *AppRoomOpenLog) CreateOrUpdate(tx *gorm.DB, create bool) (err error) {
	if create {
		err = tx.Create(m).Error
		return
	}
	err = tx.Save(m).Error

	return

}

// 更新直播日志
func (m *AppRoomOpenLog) Update(tx *gorm.DB) (err error) {
	err = tx.Save(m).Error
	return
}

func (m *AppRoomOpenLog) GetLogInfoById(id int64) (data AppRoomOpenLog, err error) {
	err = utils.GEngine.Where("log_id = ?", id).First(&data).Error
	return
}

//统计主播直播总记录
func (m *AppRoomOpenLog) GetLiveIncome(_userId int64) (results response.GiftIncomeResult, err error) {
	engine := utils.GEngine
	err = engine.Model(m).Select(" SUM(app_room_open_log.log_end_time - app_room_open_log.log_start_time) AS time_count,SUM(ala.prop_anchor_income) as income_count").
		Where("app_room_open_log.log_anchor_id = ? and app_room_open_log.deleted = 0", _userId).
		Joins("LEFT JOIN `app_anchor_room_prop` AS ala ON ala.prop_log_id = app_room_open_log.log_id").Find(&results).Error
	return
}

// 编辑log
func (m *AppRoomOpenLog) QuitLive(tx *gorm.DB, id int64) (err error) {
	now := time.Now().Unix()
	err = tx.Model(m).Where("log_id = ?", id).Updates(map[string]interface{}{"log_end_time": now, "log_live_status": ROOM_LIVE_STATUS_OFF}).Error
	return
}
