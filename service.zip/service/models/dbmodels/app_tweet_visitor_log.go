package dbmodels

import (
	"gamers/controller/response"
	"gamers/utils"
	"gorm.io/gorm"
	"time"
)

// 朋友圈操作历史记录
type AppTweetVisitorLog struct {
	LogId            int64     `gorm:"column:log_id;primaryKey;autoIncrement" json:"log_id"`
	LogMediaType     int       `gorm:"column:log_media_type" json:"log_media_type"`
	LogMediaUrl      string    `gorm:"column:log_media_url" json:"log_media_url"`
	LogOperateUserId int64     `gorm:"column:log_operate_user_id" json:"log_operate_user_id"`
	LogComment       string    `gorm:"column:log_comment" json:"log_comment"`
	LogTips          string    `gorm:"column:log_tips" json:"log_tips"`
	LogTweetContent  string    `gorm:"column:log_tweet_content" json:"log_tweet_content"`
	LogType          int       `gorm:"column:log_type" json:"log_type"`
	LogTweetUserId   int64     `gorm:"column:log_tweet_user_id" json:"log_tweet_user_id"`
	LogTweetId       int64     `gorm:"column:log_tweet_id" json:"log_tweet_id"`
	BaseModel        BaseModel `gorm:"embedded" json:"base_model"`
}

const (
	TWEET_LOG_TYPE_LIKE    = iota // 关注
	TWEET_LOG_TYPE_COMMENT        // 评论
	TWEET_LOG_TYPE_FORWARD        // 转发
	TWEET_LOG_TYPE_REPLY          // 回复
	TWEET_LOG_TYPE_READ           // 阅读
)

func (AppTweetVisitorLog) TableName() string {
	return "app_tweet_visitor_log"
}

// 根据点赞查询是否存在
func (m *AppTweetVisitorLog) GetLogByTypeAndUserId(userId, tweetId int64, logType int) (data AppTweetVisitorLog, err error) {
	err = utils.GEngine.Model(m).Where("log_type = ? and log_operate_user_id = ? and log_tweet_id = ?",
		logType, userId, tweetId).First(&data).Error
	return
}

// 删除记录
func (m *AppTweetVisitorLog) Deleted() (err error) {
	tx := utils.GEngine
	now := time.Now().Unix()
	err = tx.Model(m).Where("log_type = ? and log_operate_user_id = ? and log_tweet_id = ?", m.LogType, m.LogOperateUserId, m.LogTweetId).
		Update("deleted = ?", now).Error
	return
}

//Create 创建操作记录
func (m *AppTweetVisitorLog) Create() (err error) {
	tx := utils.GEngine
	err = tx.Model(m).Create(m).Error
	return
}

// 查询操作记录
func (m *AppTweetVisitorLog) GetLogsByTweetUser(userId int64, size, skip int) (data []response.AppTweetLogResp, count int64, err error) {
	err = utils.GEngine.Table("app_tweet_visitor_log").Preload("OperateUser", func(db *gorm.DB) *gorm.DB {
		return db.Table("system_user").Select("user_id,user_nickname,user_iconurl")
	}).Where("log_tweet_user_id = ?", userId).Limit(size).Offset(skip).Order("edited desc").Find(&data).Count(&count).Error
	return data, count, err
}
