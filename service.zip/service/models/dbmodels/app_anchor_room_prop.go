package dbmodels

import (
	"gamers/controller/response"
	"gamers/utils"
	"gorm.io/gorm"
	"time"
)

type AppAnchorRoomProp struct {
	PropId             int64       `gorm:"column:prop_id" json:"prop_id"`
	PropUserId         int64       `gorm:"column:prop_user_id" json:"prop_user_id"`
	PropRoomId         int64       `gorm:"column:prop_room_id" json:"prop_room_id"`
	PropRoomUnionId    int64       `gorm:"column:prop_room_union_id" json:"prop_room_union_id"`
	PropRoomType       int         `gorm:"column:prop_room_type" json:"prop_room_type"`
	PropRoomAttrId     int64       `gorm:"column:prop_room_attr_id" json:"prop_room_attr_id"`
	PropAnchorId       int64       `gorm:"column:prop_anchor_id" json:"prop_anchor_id"`
	PropAnchorUnionId  int64       `gorm:"column:prop_anchor_union_id" json:"prop_anchor_union_id"`
	PropPropId         int64       `gorm:"column:prop_prop_id" json:"prop_prop_id"`
	PropPropSource     int64       `gorm:"column:prop_prop_source" json:"prop_prop_source"`
	PropPropPrice      int64       `gorm:"column:prop_prop_price" json:"prop_prop_price"`
	PropPropWealth     int64       `gorm:"column:prop_prop_wealth" json:"prop_prop_wealth"`
	PropPropCharm      int64       `gorm:"column:prop_prop_charm" json:"prop_prop_charm"`
	PropPropCount      int64       `gorm:"column:prop_prop_count" json:"prop_prop_count"`
	PropGiveTime       int64       `gorm:"column:prop_give_time" json:"prop_give_time"`
	PropIncome         int64       `gorm:"column:prop_income" json:"prop_income"`
	PropPlatformIncome int64       `gorm:"column:prop_platform_income" json:"prop_platform_income"`
	PropUnionIncome    int64       `gorm:"column:prop_union_income" json:"prop_union_income"`
	PropAnchorIncome   int64       `gorm:"column:prop_anchor_income" json:"prop_anchor_income"`
	PropLogId          int64       `gorm:"column:prop_log_id" json:"prop_log_id"`
	BaseModel          BaseModel   `gorm:"embedded"  json:"base_model"`
	AppLiveRoom        AppLiveRoom `gorm:"foreignKey:RoomId;references:PropRoomId"` //关联房间
}

func (AppAnchorRoomProp) TableName() string {
	return "app_anchor_room_prop"
}

const (
	PROP_SOURCE_BUY = iota + 1
	PROP_SOURCE_BACKPACK
)

//获取用户当日礼物贡献排序
func (m *AppAnchorRoomProp) GetContributionList(_roomId int64, length int) (results []response.GetUserGiftWealth, err error) {
	parse, _ := time.Parse("2006-01-02", time.Now().Format("2006-01-02"))
	//当天零时
	unix := parse.Unix() - 28800
	//当前时间
	_time := time.Now().Unix()
	engine := utils.GEngine
	err = engine.Select("SUM(app_anchor_room_prop.prop_prop_wealth) AS user_prop_wealth,su.user_nickname,su.user_id,su.user_iconurl").
		Model(m).Joins("LEFT JOIN system_user AS su ON app_anchor_room_prop.prop_user_id = su.user_id").
		Where("app_anchor_room_prop.prop_room_id = ? and app_anchor_room_prop.prop_give_time >= ? "+
			"AND app_anchor_room_prop.prop_give_time <= ?", _roomId, unix, _time).Limit(length).
		Order("user_prop_wealth desc").Group("app_anchor_room_prop.prop_user_id").Find(&results).Error
	if err != nil {
		return nil, err
	}
	return results, nil
}

type RankUserSendWealth struct {
	UserId       int64 `json:"user_id"`
	Wealth       int64 `json:"wealth"`
	PropGiveTime int64 `json:"-"`
}

// 获取用户财富榜
func (m *AppAnchorRoomProp) GetRankUserSendWealth(begin, end int64, length int) (results []*RankUserSendWealth, err error) {
	err = utils.GEngine.
		Model(m).
		Select("prop_user_id AS user_id, sum(prop_prop_wealth) AS wealth, max(prop_give_time) AS last_give_time").
		Where("prop_give_time >= ? AND prop_give_time <= ?", begin, end).
		Group("prop_user_id").
		Having("wealth > 0").
		Order("wealth DESC, last_give_time ASC").
		Limit(length).
		Find(&results).Error
	return
}

// 获取用户财富（针对用户财富榜）
func (m *AppAnchorRoomProp) GetRankUserSendWealthByUserId(userId int64, begin, end int64) (*RankUserSendWealth, error) {
	var ret RankUserSendWealth
	err := utils.GEngine.
		Model(m).
		Select("prop_user_id AS user_id, sum(prop_prop_wealth) AS wealth, max(prop_give_time) AS last_give_time").
		Where("prop_user_id = ? AND prop_give_time >= ? AND prop_give_time <= ?", userId, begin, end).
		Find(&ret).Error
	if err != nil {
		return nil, err
	}
	ret.UserId = userId
	return &ret, nil
}

type RankUserRecvCharm struct {
	UserId       int64 `json:"user_id"`
	Charm        int64 `json:"charm"`
	PropGiveTime int64 `json:"-"`
}

// 获取用户魅力榜
func (m *AppAnchorRoomProp) GetRankUserRecvCharm(begin, end int64, length int) (results []*RankUserRecvCharm, err error) {
	err = utils.GEngine.
		Model(m).
		Select("prop_anchor_id AS user_id, sum(prop_prop_charm) AS charm, max(prop_give_time) AS last_give_time").
		Where("prop_give_time >= ? AND prop_give_time <= ?", begin, end).
		Group("prop_anchor_id").
		Having("charm > 0").
		Order("charm DESC, last_give_time ASC").
		Limit(length).
		Find(&results).Error
	return
}

// 获取用户魅力（针对用户魅力榜）
func (m *AppAnchorRoomProp) GetRankUserRecvCharmByUserId(userId int64, begin, end int64) (*RankUserRecvCharm, error) {
	var ret RankUserRecvCharm
	err := utils.GEngine.
		Model(m).
		Select("prop_anchor_id AS user_id, sum(prop_prop_charm) AS charm, max(prop_give_time) AS last_give_time").
		Where("prop_anchor_id = ? AND prop_give_time >= ? AND prop_give_time <= ?", userId, begin, end).
		Find(&ret).Error
	if err != nil {
		return nil, err
	}
	ret.UserId = userId
	return &ret, nil
}

type RankRoomUserSendWealth struct {
	UserId       int64 `json:"user_id"`
	Wealth       int64 `json:"wealth"`
	PropGiveTime int64 `json:"-"`
}

// 获取房间用户财富榜
func (m *AppAnchorRoomProp) GetRankRoomUserSendWealth(roomId int64, begin, end int64, length int) (results []*RankRoomUserSendWealth, err error) {
	err = utils.GEngine.
		Model(m).
		Select("prop_user_id AS user_id, sum(prop_prop_wealth) AS wealth, max(prop_give_time) AS last_give_time").
		Where("prop_room_id = ? AND prop_give_time >= ? AND prop_give_time <= ?", roomId, begin, end).
		Group("prop_user_id").
		Having("wealth > 0").
		Order("wealth DESC, last_give_time ASC").
		Limit(length).
		Find(&results).Error
	return
}

// 获取房间用户财富（针对房间用户财富榜）
func (m *AppAnchorRoomProp) GetRankRoomUserSendWealthByUserId(userId int64, roomId int64, begin, end int64) (*RankRoomUserSendWealth, error) {
	var ret RankRoomUserSendWealth
	err := utils.GEngine.
		Model(m).
		Select("prop_user_id AS user_id, sum(prop_prop_wealth) AS wealth, max(prop_give_time) AS last_give_time").
		Where("prop_user_id = ? AND prop_room_id = ? AND prop_give_time >= ? AND prop_give_time <= ?", userId, roomId, begin, end).
		Find(&ret).Error
	if err != nil {
		return nil, err
	}
	ret.UserId = userId
	return &ret, nil
}

type RankRoomUserRecvCharm struct {
	UserId       int64 `json:"user_id"`
	Charm        int64 `json:"charm"`
	PropGiveTime int64 `json:"-"`
}

// 获取房间用户魅力榜
func (m *AppAnchorRoomProp) GetRankRoomUserRecvCharm(roomId int64, begin, end int64, length int) (results []*RankRoomUserRecvCharm, err error) {
	err = utils.GEngine.
		Model(m).
		Select("prop_anchor_id AS user_id, sum(prop_prop_charm) AS charm, max(prop_give_time) AS last_give_time").
		Where("prop_room_id = ? AND prop_give_time >= ? AND prop_give_time <= ?", roomId, begin, end).
		Group("prop_anchor_id").
		Having("charm > 0").
		Order("charm DESC, last_give_time ASC").
		Limit(length).
		Find(&results).Error
	return
}

// 获取房间用户魅力（针对房间用户魅力榜）
func (m *AppAnchorRoomProp) GetRankRoomUserRecvCharmByUserId(userId int64, roomId int64, begin, end int64) (*RankRoomUserRecvCharm, error) {
	var ret RankRoomUserRecvCharm
	err := utils.GEngine.
		Model(m).
		Select("prop_anchor_id AS user_id, sum(prop_prop_charm) AS charm, max(prop_give_time) AS last_give_time").
		Where("prop_anchor_id = ? AND prop_room_id = ? AND prop_give_time >= ? AND prop_give_time <= ?", userId, roomId, begin, end).
		Find(&ret).Error
	if err != nil {
		return nil, err
	}
	ret.UserId = userId
	return &ret, nil
}

// 获取用户魅力值
func (m *AppAnchorRoomProp) GetPropsCharmBySendUser(UserId int64, start int) (value UserCharm, err error) {
	err = utils.GEngine.Model(m).Where("prop_anchor_id = ? and deleted = 0 and prop_give_time > ?", UserId, start).
		Select("sum(prop_prop_charm) as charm").FirstOrInit(&value).Error
	return
}

func (m *AppAnchorRoomProp) GetLiveAnchorIncome(anchorId, roomId int64, lastLive int64, logId int64) (err error, settlement response.LiveSettlementRes) {
	now := time.Now().Unix()
	if logId != 0 {
		err = utils.GEngine.Model(m).Where("prop_anchor_id = ? and prop_room_id = ? and prop_room_type = ? and prop_log_id = ? and deleted = 0",
			anchorId, roomId, ROOM_TYPE_LIVE, logId).Select("sum(prop_anchor_income) as live_income").FirstOrInit(&settlement).Error
		if err != nil {
			return
		}
	} else {
		err = utils.GEngine.Model(m).Where("prop_anchor_id = ? and prop_room_id = ? and prop_room_type = ? and prop_give_time  BETWEEN ? AND ? and deleted = 0",
			anchorId, roomId, ROOM_TYPE_LIVE, lastLive, now).Select("sum(prop_anchor_income) as live_income").FirstOrInit(&settlement).Error
		if err != nil {
			return
		}
	}
	err = utils.GEngine.Table("app_fan").Where("fan_user_id = ? and created BETWEEN ? AND ? and deleted = 0", anchorId, lastLive, now).Count(&settlement.NewFans).Error
	return
}

type CharmCount struct {
	PropRoomId int64   `json:"prop_room_id"`
	CharmSum   float64 `json:"charm_sum"`
}

//获取指定时间每个房间的魅力值
func (m *AppAnchorRoomProp) QueryTimeCharm(startTime, endTime int64) (data []CharmCount, err error) {
	err = utils.GEngine.Model(m).
		Select("prop_room_id,sum(prop_prop_charm) AS charm_sum").
		Joins("INNER JOIN app_live_room AS a ON app_anchor_room_prop.prop_room_id = a.room_id").
		Where("prop_give_time >= ? AND prop_give_time <= ?", startTime, endTime).
		Where("a.room_password = '' AND (( a.room_type = ? AND a.room_status = ? AND a.room_live_status = ? ) OR ( a.room_type = ?  AND a.room_status = ? AND a.room_union_id > 0 ))", ROOM_TYPE_LIVE, ROOM_STATUS_OK, ROOM_LIVE_STATUS_ON, ROOM_TYPE_PARTY, ROOM_STATUS_OK).
		Group("prop_room_id").
		Find(&data).Error
	return
}

// 创建直播礼物记录表
func (m *AppAnchorRoomProp) CreateGiftAnchorAction(tx *gorm.DB, records []*AppAnchorRoomProp) (err error) {
	err = tx.Create(&records).Error
	return
}

type UserWealth struct {
	Wealth int64 `gorm:"column:wealth"`
}

// 获取用户财富值
func (m *AppAnchorRoomProp) GetGiftsWealthBySendUser(UserId int64) (value UserWealth, err error) {
	err = utils.GEngine.Model(m).Where("prop_user_id = ? and deleted = 0", UserId).
		Select("sum(prop_prop_wealth) as wealth").FirstOrInit(&value).Error
	return
}

type UserCharm struct {
	Charm int64 `gorm:"column:charm"`
}

// 获取用户魅力值
func (m *AppAnchorRoomProp) GetGiftsCharmBySendUser(UserId int64) (value UserCharm, err error) {
	err = utils.GEngine.Model(m).Where("prop_anchor_id = ? and deleted = 0", UserId).
		Select("sum(prop_prop_charm) as charm").FirstOrInit(&value).Error
	return
}

// 获取用户收礼记录m
func (m *AppAnchorRoomProp) GetGiftIncomeByAnchorId(UserId int64, size int, skip int) (total int64, data []response.AnchorIncomeResp, err error) {
	err = utils.GEngine.Table("app_anchor_room_prop").Select("system_user.user_iconurl,system_user.user_nickname,app_anchor_room_prop.prop_anchor_income,app_anchor_room_prop.prop_give_time").
		Joins("inner join system_user on app_anchor_room_prop.prop_anchor_id = system_user.user_id").
		Where("app_anchor_room_prop.prop_anchor_id = ? and app_anchor_room_prop.deleted = 0 ", UserId).Order("app_anchor_room_prop.prop_id desc").
		Count(&total).Offset(skip).Limit(size).Scan(&data).Error
	return
}

// 获取礼物总收益
func (m *AppAnchorRoomProp) GetGiftIncome(userId int64, st int64, et int64) (totalIncome int64, err error) {
	type income struct {
		TotalIncome int64 `gorm:"column:total_income"`
	}
	var in income
	err = utils.GEngine.Model(m).Where("app_anchor_room_prop.prop_anchor_id = ? and app_anchor_room_prop.deleted = 0 and app_anchor_room_prop.prop_give_time >= ? and app_anchor_room_prop.prop_give_time <?", userId, st, et).
		Select("sum(prop_anchor_income) as total_income").FirstOrInit(&in).Error
	if err == nil {
		totalIncome = in.TotalIncome
	}
	return
}

// 获取直播间礼物统计列表
func (m *AppAnchorRoomProp) GetRoomGiftsCountByRoomId(_roomId int64, limit int) (results []response.GiftCountResult, err error) {
	if limit == 0 {
		err = utils.GEngine.Select("SUM(app_anchor_room_prop.prop_prop_count) AS prop_count,app_prop.prop_url,app_anchor_room_prop.prop_prop_id,app_prop.prop_name,app_prop.prop_icon").
			Model(m).Joins("INNER JOIN app_prop ON app_anchor_room_prop.prop_prop_id = app_prop.prop_id").
			Where("app_anchor_room_prop.prop_room_id = ?", _roomId).Group("app_prop.prop_id").Find(&results).Error
		return
	}
	err = utils.GEngine.Select("SUM(app_anchor_room_prop.prop_prop_count) AS prop_count,app_prop.prop_url,app_anchor_room_prop.prop_prop_id,app_prop.prop_name,app_prop.prop_icon").
		Model(m).Joins("INNER JOIN app_prop ON app_anchor_room_prop.prop_prop_id = app_prop.prop_id").
		Where("app_anchor_room_prop.prop_room_id = ?", _roomId).Group("app_prop.prop_id").Limit(limit).Find(&results).Error
	return
}

// 获取直播间礼物
func (m *AppAnchorRoomProp) GetRoomGiftsByRoomId(roomId, startT int64, size int, skip int) (total int64, results []response.LiveRoomGiftResult, err error) {
	err = utils.GEngine.Table("app_anchor_room_prop").
		Preload("SenderInfo", func(db *gorm.DB) *gorm.DB {
			return db.Table("system_user").Select("user_id,user_nickname,user_iconurl")
		}).
		Preload("AnchorInfo", func(db *gorm.DB) *gorm.DB {
			return db.Table("system_user").Select("user_id,user_nickname,user_iconurl")
		}).
		Joins("INNER JOIN app_prop ON app_anchor_room_prop.prop_prop_id = app_prop.prop_id").
		Select("app_anchor_room_prop.prop_prop_count,app_prop.prop_icon,app_anchor_room_prop.prop_user_id,app_anchor_room_prop.prop_anchor_id,"+
			"app_anchor_room_prop.prop_prop_id,app_anchor_room_prop.prop_id,app_prop.prop_name,app_anchor_room_prop.prop_give_time").
		Where("app_anchor_room_prop.prop_room_id = ? and prop_give_time > ?", roomId, startT).Offset(skip).Limit(size).Order("app_anchor_room_prop.prop_give_time desc").
		Find(&results).Count(&total).Error
	return
}

// 获取直播间礼物
func (m *AppAnchorRoomProp) GetRoomGiftsByUserId(userId int64, size int, skip int, income bool) (total int64, results []response.GiftInfoRecordRes, err error) {
	monthTime := time.Now().Unix() - 60*60*24*30
	if income {
		err = utils.GEngine.Table("app_anchor_room_prop").
			Joins("INNER JOIN app_prop ON app_anchor_room_prop.prop_prop_id = app_prop.prop_id").
			Joins("INNER JOIN system_user ON app_anchor_room_prop.prop_anchor_id = system_user.user_id").
			Select("app_anchor_room_prop.prop_prop_count,app_anchor_room_prop.prop_give_time,app_anchor_room_prop.prop_room_id,"+
				"app_prop.prop_name,system_user.user_nickname,app_anchor_room_prop.prop_id").
			Where("app_anchor_room_prop.prop_user_id = ? and app_anchor_room_prop.prop_give_time > ?", userId, monthTime).Count(&total).
			Offset(skip).Limit(size).Order("app_anchor_room_prop.prop_give_time desc").
			Scan(&results).Error
		return
	}
	err = utils.GEngine.Table("app_anchor_room_prop").
		Joins("INNER JOIN app_prop ON app_anchor_room_prop.prop_prop_id = app_prop.prop_id").
		Joins("INNER JOIN system_user ON app_anchor_room_prop.prop_user_id = system_user.user_id").
		Select("app_anchor_room_prop.prop_prop_count,app_anchor_room_prop.prop_give_time,app_anchor_room_prop.prop_room_id,"+
			"app_prop.prop_name,system_user.user_nickname,app_anchor_room_prop.prop_id").
		Where("app_anchor_room_prop.prop_anchor_id = ? and app_anchor_room_prop.prop_give_time > ?", userId, monthTime).Count(&total).
		Offset(skip).Limit(size).Order("app_anchor_room_prop.prop_give_time desc").
		Scan(&results).Error
	return
}

//查询用户购买礼物记录
func (m *AppAnchorRoomProp) QueryUserList(page int, size int, userId int64) (total int64, data []AppAnchorRoomProp, err error) {
	err = utils.GEngine.Model(m).Where("prop_user_id = ? AND prop_prop_price > 0", userId).
		Count(&total).
		Order("created desc").
		Offset((page * size) - size).
		Limit(size).
		Find(&data).Error
	return
}

// 获取直播间实时收益
func (m *AppAnchorRoomProp) GetAnchorLiveIncome(anchorId, roomId int64, logId int64) (data response.GetAnchorLiveIncomeResp, err error) {
	err = utils.GEngine.Model(m).Where("prop_anchor_id = ? and prop_room_id = ? and prop_room_type = ? and prop_log_id = ? and deleted = 0",
		anchorId, roomId, ROOM_TYPE_LIVE, logId).Select("sum(prop_anchor_income) as live_income").FirstOrInit(&data).Error
	if err != nil {
		return
	}
	return
}
