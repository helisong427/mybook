package dbmodels

import (
	"gamers/utils"
	"gorm.io/gorm"
	"time"
)

// 访客日志表
type AppUserVisitorLog struct {
	LogId            int64      `gorm:"column:log_id;primaryKey;autoIncrement"`
	LogUserId        int64      `gorm:"column:log_user_id"`                            // 被访问个人主页
	LogType          int64      `gorm:"column:log_type"`                               // 访问类型(0个人中心, 1 大神技能页)
	LogVisitorUserId int64      `gorm:"column:log_visitor_user_id"`                    // 访问者用户id
	VisitTimes       int64      `gorm:"-" json:"visit_times"`                          // 浏览次数
	SystemUser       SystemUser `gorm:"foreignKey:UserID;references:LogVisitorUserId"` // 关联访客用户信息
	BaseModel
}

func (AppUserVisitorLog) TableName() string {
	return "app_user_visitor_log"
}

func (m *AppUserVisitorLog) Create() (err error) {
	err = utils.GEngine.Create(m).Error
	return
}

// 查询一条访问记录
func (m *AppUserVisitorLog) QueryFirst(logUserId int64, userId int64) (row int64, data AppUserVisitorLog, err error) {
	model := utils.GEngine.Where("log_user_id = ? AND log_visitor_user_id = ?", logUserId, userId).First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

// 统计用户的总访问次数
func (m *AppUserVisitorLog) QueryCont(userId int64) (row int64, err error) {
	err = utils.GEngine.Model(m).Where("log_user_id = ?", userId).Count(&row).Error
	return
}

// 更新访客记录
func (m *AppUserVisitorLog) Update(logId int64) (row int64, err error) {
	err = utils.GEngine.Model(m).Where("log_id = ?", logId).Update("edited", time.Now().Unix()).Error
	return
}

// 分页查询信息访客
func (m *AppUserVisitorLog) QueryPage(userId int64, page int, size int) (total int64, data []AppUserVisitorLog, err error) {
	err = utils.GEngine.
		Model(m).
		Preload("SystemUser", func(db *gorm.DB) *gorm.DB {
			return db.Select("user_id,user_nickname,user_iconurl,user_gender,user_birthday").Where("user_is_forwards_news = 1")
		}).
		Joins(`left join app_user_visitor auv on 
			auv.visit_visitor_user_id = app_user_visitor_log.log_visitor_user_id and 
			auv.visit_type = app_user_visitor_log.log_type`).
		Where("log_user_id = ?", userId).
		Offset((page * size) - size).
		Limit(size).
		Order("edited desc").
		Count(&total).
		Find(&data).Error
	return
}

type ConvertHistoryDataResult struct {
	LogUserId        int64 `json:"log_user_id"`
	LogVisitorUserId int64 `json:"log_visitor_user_id"`
	Created          int64 `json:"created"`
	LogType          int64 `json:"log_type"`
}

// 获取所有访问 日志 (旧表)
func (m *AppUserVisitorLog) GetList() (data []*ConvertHistoryDataResult, err error) {
	err = utils.GEngine.Model(m).Where("deleted = 0").Order("created desc").Find(&data).Error

	return
}
