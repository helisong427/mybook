package dbmodels

import (
	"encoding/json"
	"fmt"
	"gamers/controller/request"
	"gamers/utils"
	"strconv"
	"strings"

	"github.com/go-redis/redis"
	"gorm.io/gorm"
)

// 技能认证
type AppSparringSkill struct {
	SkillID                  int64                   `gorm:"column:skill_id;primaryKey;autoIncrement"`                              // 大神技能id
	SkillUserID              int64                   `gorm:"column:skill_user_id"`                                                  // 用户id
	SkillTitle               string                  `gorm:"column:skill_title"`                                                    // 技能名称
	SkillSkillID             int64                   `gorm:"column:skill_skill_id"`                                                 // 技能id
	SkillProveImage          string                  `gorm:"column:skill_prove_image"`                                              // 图片
	SkillSound               string                  `gorm:"column:skill_sound"`                                                    // 语音
	SkillSoundTime           int64                   `gorm:"column:skill_sound_time"`                                               // 语音时长
	SkillInfo                string                  `gorm:"column:skill_info"`                                                     // 技能介绍
	SkillStatus              int                     `gorm:"column:skill_status"`                                                   // 技能状态
	SkillSetInfoStatus       int                     `gorm:"column:skill_set_info_status"`                                          // 技能设置信息状态 0未设置,1为已设置
	SkillOrderCount          int64                   `gorm:"column:skill_order_count"`                                              // 服务人次
	SkillApplyTime           int64                   `gorm:"column:skill_apply_time" json:"skill_apply_time"`                       // 申请时间
	SkillDealTime            int64                   `gorm:"column:skill_deal_time" json:"skill_deal_time"`                         // 处理时间
	SkillUserIconurl         string                  `gorm:"column:skill_user_iconurl" json:"skill_user_iconurl"`                   // 申请的头像
	SkillSpeedMatchingStatus int64                   `gorm:"column:skill_speed_matching_status" json:"skill_speed_matching_status"` // 抢单开关(0关闭,1开启)
	SkillMsgStatus           int64                   `gorm:"column:skill_msg_status" json:"skill_msg_status"`                       // 抢单消息(0关闭,1开启)
	AppSparringSkillInfo     []AppSparringSkillInfo  `gorm:"foreignKey:InfoSparringSkillId;references:SkillID"`                     // 关联大神技能
	AppSparringSkillPrice    []AppSparringSkillPrice `gorm:"foreignKey:PriceSparringSkillId;references:SkillID"`                    // 关联大神价格
	SystemUser               SystemUser              `gorm:"foreignKey:UserID;references:SkillUserID"`                              // 关联用户信息
	AppSkill                 AppSkill                `gorm:"foreignKey:SkillId;references:SkillSkillID"`                            // 关联技能
	BaseModel                BaseModel               `gorm:"embedded" json:"base_model"`
}

type AppSparringSkillJoin struct {
	UserID         int64
	SkillSkillID   int64
	UserNickname   string
	UserGender     int
	UserBirthday   int64
	UserIsOnline   int
	UserLongitude  float32
	UserLatitude   float32
	SkillSound     string
	SkillSoundTime int64
	SkillID        int64 // 技能id
	// InfoSkillId     int64
	// InfoValue       int64
	// InfoPrice       int64
	SkillOrderCount int64
	SparringIconurl string
}

// TableName 会将 User 的表名重写为 `app_skill_order`
func (AppSparringSkill) TableName() string {
	return "app_sparring_skill"
}

func (s *AppSparringSkill) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s AppSparringSkill) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

const (
	SPARRING_SKILL_WITHOUT     = iota // 未认证
	SPARRING_SKILL_STATUS_INIT        // 待审核
	SPARRING_SKILL_STATUS_PASS        // 未通过
	SPARRING_SKILL_STATUS_OK          // 认证成功并上架
	SPARRING_SKILL_STATUS_OFF         // 陪练师下架
	SPARRING_SKILL_STATUS_BAN         // 管理员冻结
)

const (
	// 冻结
	SPARRING_SKILL_CLOSE_STATUS_OK  int = iota // 正常
	SPARRING_SKILL_CLOSE_STATUS_OFF            // 管理员冻结
)

const (
	SPARRING_SKILL_SET_INFO_STATUS_NO = iota // 未设置个人信息
	SPARRING_SKILL_SET_INFO_STATUS_OK        // 已设置个人信息
)

const (
	// 抢单开关
	SPARRING_SKILL_MATCHING_OFF int = iota // 关闭
	SPARRING_SKILL_MATCHING_ON             // 开启
)
const (
	// 抢单消息
	SPARRING_SKILL_MSG_OFF int = iota // 关闭
	SPARRING_SKILL_MSG_ON             // 开启
)

// skill事务操作
func (m *AppSparringSkill) SparringSkillCreateAction(sparring AppSparringSkill, skillInfo AppSparringSkillInfo, update bool) (err error) {
	err = utils.GEngine.Transaction(func(tx *gorm.DB) error {
		if update {
			if err := tx.Save(&m).Error; err != nil {
				// 返回任何错误都会回滚事务
				return err
			}
			skill := AppSparringSkillInfo{
				InfoUserId:          sparring.SkillUserID,
				InfoSkillId:         m.SkillSkillID,
				InfoSparringSkillId: m.SkillID,
			}
			// 移除之前的
			_, err = skill.DelSkillInfoByInfoKey()
			if err != nil {
				return err
			}
		} else {
			if err := tx.Create(&m).Error; err != nil {
				return err
			}
		}

		skillInfo.InfoSkillId = m.SkillSkillID
		skillInfo.InfoSparringSkillId = m.SkillID

		if err := tx.Create(&skillInfo).Error; err != nil {
			// 返回任何错误都会回滚事务
			return err
		}
		// 返回 nil 提交事务
		return nil
	})
	return
}

// Create
func (m *AppSparringSkill) UpdateBaseInfo(tx *gorm.DB) (err error) {
	err = tx.Model(m).Where("skill_id", m.SkillID).
		Updates(map[string]interface{}{"skill_prove_image": m.SkillProveImage, "skill_sound": m.SkillSound,
			"skill_sound_time": m.SkillSoundTime, "skill_info": m.SkillInfo,
			"skill_status": m.SkillStatus, "skill_user_iconurl": m.SkillUserIconurl, "skill_first_commit": 1}).Error
	if err != nil {
		return
	}
	idStr := strconv.Itoa(int(m.SkillID))
	err = utils.RedisClient.HDel(utils.REDIS_SPARRING_INFO, idStr).Err()
	if err != nil && err != redis.Nil {
		return
	}
	err = nil
	return
}

//
func (m *AppSparringSkill) UpdateSetInfo(tx *gorm.DB, skillId int64) (err error) {
	err = tx.Table("app_sparring_skill").Where("skill_id = ?", skillId).
		Updates(map[string]interface{}{"skill_set_info_status": SPARRING_SKILL_SET_INFO_STATUS_OK}).Error
	if err != nil {
		return
	}
	idStr := strconv.Itoa(int(skillId))
	err = utils.RedisClient.HDel(utils.REDIS_SPARRING_INFO, idStr).Err()
	if err != nil && err != redis.Nil {
		return
	}
	err = nil
	return
}

// QueryByUserId 根据用户id查询
func (m *AppSparringSkill) QueryByUserIdSkillSkillId(userId int64, skillId int64) (data AppSparringSkill, err error) {
	err = utils.GEngine.Preload("AppSparringSkillInfo").Where("skill_user_id = ? and skill_skill_id = ? and deleted = 0", userId, skillId).First(&data).Error
	return
}

func (m *AppSparringSkill) QueryByUserIdSkillId(userId int64, skillId int64) (data AppSparringSkill, err error) {
	err = utils.GEngine.Preload("AppSparringSkillInfo").Preload("AppSparringSkillInfo.AppSkillFieldValue").Where("skill_user_id = ? and skill_id = ? and deleted = 0", userId, skillId).First(&data).Error
	return
}

// QueryBySkillId 大神id查询
func (m *AppSparringSkill) QueryBySkillId(skillId int64) (data AppSparringSkill, err error) {
	idStr := strconv.Itoa(int(skillId))
	err = utils.RedisClient.HGet(utils.REDIS_SPARRING_INFO, idStr).Scan(&data)
	if err == nil {
		return
	}
	if err != nil && err != redis.Nil {
		return
	}

	err = utils.GEngine.Preload("AppSkill").
		Preload("AppSparringSkillInfo", "deleted = 0").
		Preload("AppSparringSkillPrice").
		Preload("SystemUser").
		Preload("AppSparringSkillPrice.AppSkillPrice").
		Preload("AppSparringSkillInfo.AppSkillFieldValue", "deleted = 0").
		Where("skill_id = ?", skillId).
		First(&data).Error
	if err != nil {
		return
	}
	err = utils.RedisClient.HSet(utils.REDIS_SPARRING_INFO, idStr, data).Err()
	// err = new(SystemUser).
	return
}

// 查询大神认证技能
func (m *AppSparringSkill) GetSparringInfo(skillId int64) (data AppSparringSkill, err error) {
	err = utils.GEngine.Preload("AppSparringSkillInfo", "deleted = 0").
		Preload("AppSparringSkillPrice").
		Preload("SystemUser").Preload("AppSkill", "deleted = 0").
		Preload("AppSkill.AppSkillFieldValue", "deleted = 0").
		Preload("AppSparringSkillPrice.AppSkillPrice", "deleted = 0").
		Preload("AppSparringSkillInfo.AppSkillFieldValue", "deleted = 0").
		Where("skill_id = ?", skillId).First(&data).Error
	return
}

// 根据用户id查询技能
func (m *AppSparringSkill) QuerySkillByUserId(userId int64) (data []AppSparringSkill, err error) {
	err = utils.GEngine.Preload("AppSkill").Where("skill_user_id = ? and skill_status != ?", userId, SPARRING_SKILL_STATUS_PASS).Find(&data).Error
	return
}

// 查询用户可接单技能
func (m *AppSparringSkill) QueryNormalSkillByUserId(userId int64) (data []AppSparringSkill, err error) {
	err = utils.GEngine.Preload("AppSkill").Where("skill_user_id = ? and skill_status = ?", userId, SPARRING_SKILL_STATUS_OK).Find(&data).Error
	return
}

// 根据用户兴趣查询
func (m *AppSparringSkill) QueryByUserSavor(skillId []string, commendIds []int) (data []AppSparringSkill, err error) {
	model := utils.GEngine.
		Preload("SystemUser").
		Preload("AppSkill").
		Preload("AppSparringSkillPrice").
		Preload("AppSparringSkillPrice.AppSkillPrice").
		Where("skill_status = ?", SPARRING_SKILL_STATUS_OK).
		Where("skill_skill_id IN ?", skillId)
	if len(commendIds) > 0 {
		model = model.Where("skill_id NOT IN ?", commendIds)
	}
	err = model.Group("skill_skill_id").Group("skill_user_id").Limit(5).Find(&data).Error
	return
}

// 根据用户兴趣查询
func (m *AppSparringSkill) QueryByIn(skillId []int) (data []AppSparringSkill, err error) {
	model := utils.GEngine.
		Preload("SystemUser").
		Preload("AppSkill").
		Preload("AppSparringSkillPrice").
		Preload("AppSparringSkillPrice.AppSkillPrice").
		Where("skill_status = ?", SPARRING_SKILL_STATUS_OK).
		Where("skill_id IN ?", skillId)
	err = model.Find(&data).Error
	return
}

// 查询一条
func (m *AppSparringSkill) QueryFirst(skillId int64) (data AppSparringSkill, err error) {
	err = utils.GEngine.Where("skill_id = ?", skillId).First(&data).Error
	return
}

// 查询其他用户的技能
func (m *AppSparringSkill) QuerySkillByOtherUserId(userId int64) (data []AppSparringSkill, err error) {
	err = utils.GEngine.Preload("AppSparringSkillInfo").
		Preload("SystemUser").
		Preload("AppSkill").
		Preload("AppSkill.AppSkillFieldValue").
		Preload("AppSparringSkillInfo.AppSkillFieldValue").
		Where("skill_user_id = ? and skill_status = ?", userId, SPARRING_SKILL_STATUS_OK).
		Find(&data).Error
	return
}

func (m AppSparringSkill) Update(id int64) error {
	err := utils.GEngine.Where("skill_id = ?", id).Updates(m).Error
	if err != nil {
		return err
	}
	idStr := strconv.Itoa(int(id))
	err = utils.RedisClient.HDel(utils.REDIS_SPARRING_INFO, idStr).Err()
	if err != nil && err != redis.Nil {
		return err
	}
	return nil
}

func (m *AppSparringSkill) UpdateBySkillId(id int64, update map[string]interface{}) (err error) {
	err = utils.GEngine.Model(m).Where("skill_id = ?", id).Updates(update).Error
	if err != nil {
		return err
	}

	idStr := strconv.Itoa(int(id))

	err = utils.RedisClient.HDel(utils.REDIS_SPARRING_INFO, idStr).Err()
	if err != nil && err != redis.Nil {
		return
	}

	return
}

// QueryByPassed 查询是否通过
func (m *AppSparringSkill) QueryByPassed(userId int64) (err error) {
	err = utils.GEngine.Where("skill_user_id = ? and skill_status = ? or skill_status = ?", userId, SPARRING_SKILL_STATUS_OK, SPARRING_SKILL_STATUS_OFF).First(m).Error
	return
}

type AppSparringIdsResult struct {
	SkillID int64 `json:"skill_id"` // 大神ID
}

// 分页随机查询陪练师列表
func (m *AppSparringSkill) QueryPageRand(paramsJSON request.SparringListReq, offset int) (total int64, data []AppSparringIdsResult, err error) {
	db := utils.GEngine
	countModel := db.Scopes(m.baseJoin())
	db = db.Scopes(m.baseJoin())
	// 游戏id筛选
	if paramsJSON.SkillId != 0 {
		db = db.Scopes(m.skillId(paramsJSON))
		countModel = countModel.Scopes(m.skillId(paramsJSON))
	}

	// 性别筛选
	if paramsJSON.Sex != 0 {
		db = db.Scopes(m.sex(paramsJSON))
		countModel = countModel.Scopes(m.sex(paramsJSON))
	}

	// 在线状态筛选
	if paramsJSON.SelectOnline != 0 {
		db = db.Scopes(m.SelectIsOnline(paramsJSON))
		countModel = countModel.Scopes(m.SelectIsOnline(paramsJSON))
	}

	// 基本条件
	db = db.Scopes(m.baseWhere())
	countModel = countModel.Scopes(m.baseWhere())

	// 其他条件筛选
	if paramsJSON.OtherCondition != "" {
		db = db.Scopes(m.otherCondition(paramsJSON))
		countModel = countModel.Scopes(m.otherCondition(paramsJSON))
	}

	if err = countModel.Count(&total).Error; err != nil {
		return
	}

	// 超出总页数不返回
	// totalPages := utils.FuncTotalPages(total, paramsJSON.Size)
	// if paramsJSON.Page > totalPages {
	// 	return
	// }

	err = db.Offset(offset).Limit(paramsJSON.Size).
		Order("score desc").
		Find(&data).Error
	return
}

// 分页查询陪练师列表
func (m *AppSparringSkill) QueryPage(paramsJSON request.SparringListReq) (total int64, data []AppSparringSkillJoin, err error) {
	db := utils.GEngine
	countModel := db.Scopes(m.baseJoin())
	db = db.Scopes(m.baseJoin())
	// 游戏id筛选
	if paramsJSON.SkillId != 0 {
		db = db.Scopes(m.skillId(paramsJSON))
		countModel = countModel.Scopes(m.skillId(paramsJSON))
	}

	// 性别筛选
	if paramsJSON.Sex != 0 {
		db = db.Scopes(m.sex(paramsJSON))
		countModel = countModel.Scopes(m.sex(paramsJSON))
	}

	// 在线状态筛选
	if paramsJSON.SelectOnline != 0 {
		db = db.Scopes(m.SelectIsOnline(paramsJSON))
		countModel = countModel.Scopes(m.SelectIsOnline(paramsJSON))
	}

	// 基本条件
	db = db.Scopes(m.baseWhere())
	countModel = countModel.Scopes(m.baseWhere())

	// 其他条件筛选
	if paramsJSON.OtherCondition != "" {
		db = db.Scopes(m.otherCondition(paramsJSON))
		countModel = countModel.Scopes(m.otherCondition(paramsJSON))
	}

	err = db.Limit(paramsJSON.Size).
		Offset((paramsJSON.Page * paramsJSON.Size) - paramsJSON.Size).
		Find(&data).Error

	err = countModel.Count(&total).Error
	return
}

// baseJoin 基本链接表
func (m *AppSparringSkill) baseJoin() func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		return db.Model(m).Select("app_sparring_skill.*,u.user_nickname,u.user_id,u.user_gender,u.user_birthday,u.user_is_online,u.user_longitude,u.user_latitude,u.user_iconurl as  sparring_iconurl, (IFNULL(score_real_score, 0) + IFNULL(score_intervention_score, 0)) as score").
			Joins("INNER JOIN system_user AS u ON  app_sparring_skill.skill_user_id = u.user_id").
			Joins(`left join app_sparring_skill_score asss on asss.score_sparring_skill_id = app_sparring_skill.skill_id`)
	}
}

// baseWhere 基本条件
func (m *AppSparringSkill) baseWhere() func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		return db.Where("app_sparring_skill.skill_status = ? AND  skill_set_info_status = ?", SPARRING_SKILL_STATUS_OK, SPARRING_SKILL_SET_INFO_STATUS_OK)
	}
}

// SelectIsOnline 筛选在线状态
func (m *AppSparringSkill) SelectIsOnline(paramsJSON request.SparringListReq) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		return db.Where("u.user_is_online = ?", paramsJSON.SelectOnline-1)
	}
}

// skillId 游戏id筛选
func (m *AppSparringSkill) skillId(paramsJSON request.SparringListReq) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		return db.Where("app_sparring_skill.skill_skill_id = ?", paramsJSON.SkillId)
	}
}

// sex 性别筛选
func (m *AppSparringSkill) sex(paramsJSON request.SparringListReq) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		return db.Where("u.user_gender = ?", paramsJSON.Sex)
	}
}

// otherCondition 其他条件
func (m *AppSparringSkill) otherCondition(paramsJSON request.SparringListReq) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		db = db.Joins("INNER JOIN app_sparring_skill_info AS aski ON app_sparring_skill.skill_id = aski.info_sparring_skill_id")
		split := strings.Split(paramsJSON.OtherCondition, ",")
		for _, v := range split {
			id, _ := strconv.Atoi(v)
			db = db.Where("aski.info_value_id = ?", id)
		}
		return db
	}
}

// 更新
func (m *AppSparringSkill) Updates(tx *gorm.DB, updates map[string]interface{}, skillId uint64) (err error) {
	err = tx.Model(m).Where("skill_id=?", skillId).Updates(updates).Error
	return
}

// 增加服务人次
func (m *AppSparringSkill) AddSkillOrderCount(tx *gorm.DB, skillId int64) (err error) {
	err = tx.Model(m).Where("skill_id = ?", skillId).Updates(map[string]interface{}{
		"skill_order_count": gorm.Expr("skill_order_count + ?", 1),
	}).Error
	if err != nil {
		return err
	}
	// 删除缓存
	idStr := strconv.Itoa(int(skillId))
	// key := fmt.Sprintf("%s%d", utils.REDIS_SPARRING_INFO, idStr)
	err = utils.RedisClient.HDel(utils.REDIS_SPARRING_INFO, idStr).Err()
	if err != nil {
		err = fmt.Errorf("删除大神缓存失败:[key = %s],[err = %s]", idStr, err.Error())
	}
	return
}

// 消息，查询大神技能列表
// 根据用户id查询技能
func (m *AppSparringSkill) MsgQuerySkillByUserId(userId int64) (data []AppSparringSkill, err error) {
	err = utils.GEngine.Preload("AppSparringSkillPrice").Preload("AppSparringSkillPrice.AppSkillPrice").Preload("AppSkill").Where("skill_user_id = ? and skill_status = ?", userId, SPARRING_SKILL_STATUS_OK).Order("skill_order_count desc,created asc").Find(&data).Error
	return
}

// 查询指定数量的大神id
func (m *AppSparringSkill) QuerySpecifiedNumberId(notInIds []int64, notInUserId []int64, number int64) (row int64, data []AppSparringSkill, err error) {
	model := utils.GEngine.Model(m).
		Select("skill_id").
		Where("skill_id NOT IN ? AND skill_user_id NOT IN ?", notInIds, notInUserId).
		Where("skill_status = ? AND skill_set_info_status = ? ", SPARRING_SKILL_STATUS_OK, SPARRING_SKILL_SET_INFO_STATUS_OK).
		Group("skill_user_id").
		Order("rand()").
		Limit(int(number)).
		Find(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

// 按照skillId的顺序in查询
func (m *AppSparringSkill) QueryOrderIn(skillId []int64) (data []AppSparringSkill, err error) {
	model := utils.GEngine.
		Preload("SystemUser").
		Preload("AppSkill").
		Preload("AppSparringSkillPrice").
		Preload("AppSparringSkillPrice.AppSkillPrice").
		Where("skill_status = ? AND skill_set_info_status = ? ", SPARRING_SKILL_STATUS_OK, SPARRING_SKILL_SET_INFO_STATUS_OK).
		Where("skill_id IN ?", skillId)
	var temp = make([]string, len(skillId))
	for k, v := range skillId {
		temp[k] = fmt.Sprintf("%d", v)
	}
	field := strings.Join(temp, ",")
	err = model.Order("field(skill_id," + field + ")").Find(&data).Error
	return
}

// 随机获取一条
func (m *AppSparringSkill) QueryNotInRand(notInIds []int64, notInUserIds []int64) (data AppSparringSkill, err error) {
	err = utils.GEngine.Model(m).
		Preload("SystemUser").
		Preload("AppSkill").
		Preload("AppSparringSkillPrice").
		Preload("AppSparringSkillPrice.AppSkillPrice").
		Where("skill_id NOT IN ? AND skill_user_id NOT IN ?", notInIds, notInUserIds).
		Where("skill_status = ? AND skill_set_info_status = ? ", SPARRING_SKILL_STATUS_OK, SPARRING_SKILL_SET_INFO_STATUS_OK).
		Group("skill_user_id").
		Order("rand()").
		Limit(1).
		First(&data).Error
	return
}

// 随机获取指定数量
func (m *AppSparringSkill) QueryNumberRand(number int) (row int64, data []AppSparringSkill, err error) {
	model := utils.GEngine.Model(m).
		Preload("SystemUser").
		Preload("AppSkill").
		Preload("AppSparringSkillPrice").
		Preload("AppSparringSkillPrice.AppSkillPrice").
		Where("skill_status = ? AND skill_set_info_status = ?", SPARRING_SKILL_STATUS_OK, SPARRING_SKILL_SET_INFO_STATUS_OK).
		Group("skill_user_id").
		Order("rand()").
		Limit(number).
		Find(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

// 随机获取指定数量
func (m *AppSparringSkill) QueryNumberRandNotIn(number int, ids []int64) (row int64, data []AppSparringSkill, err error) {
	model := utils.GEngine.Model(m).
		Preload("SystemUser").
		Preload("AppSkill").
		Preload("AppSparringSkillPrice").
		Preload("AppSparringSkillPrice.AppSkillPrice").
		Where("skill_status = ? AND skill_set_info_status = ?", SPARRING_SKILL_STATUS_OK, SPARRING_SKILL_SET_INFO_STATUS_OK)
	if len(ids) > 0 {
		model = model.Where("skill_id NOT IN ?", ids)
	}
	model = model.Group("skill_user_id").
		Order("rand()").
		Limit(number).
		Find(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

// 根据in条件筛选正常状态的大神
func (m *AppSparringSkill) QueryInFilter(ids []int64) (row int64, data []AppSparringSkill, err error) {
	model := utils.GEngine.Model(m).
		Select("skill_id").
		Where("skill_status = ? AND skill_set_info_status = ? ", SPARRING_SKILL_STATUS_OK, SPARRING_SKILL_SET_INFO_STATUS_OK).
		Where("skill_id IN ?", ids).Find(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

// 根据用户id获取用户所有的技能id，不管认证通不通过
func (m *AppSparringSkill) GetUserSkillIdsByUserId(userId int64) (skillIds []string, err error) {
	err = utils.GEngine.Model(m).Select("skill_id").Where("skill_user_id = ?", userId).Find(&skillIds).Error
	return
}

// 查询符合匹配条件的大神
func (m *AppSparringSkill) QueryMatching(skillId int64) (data []AppSparringSkill, err error) {
	err = utils.GEngine.Model(m).
		Select("skill_user_id, skill_msg_status").
		Where("skill_skill_id = ? AND skill_status = ? AND skill_speed_matching_status = ? ", skillId, SPARRING_SKILL_STATUS_OK, SPARRING_SKILL_MATCHING_ON).
		Group("skill_user_id").
		Find(&data).Error
	return
}

// 查询大神已认证技能id
func (m *AppSparringSkill) QuerySkillId(userId int64) (data []AppSparringSkill, err error) {
	err = utils.GEngine.Where("skill_user_id = ? AND skill_set_info_status = ? AND skill_status = ? AND skill_speed_matching_status=1", userId, SPARRING_SKILL_SET_INFO_STATUS_OK, SPARRING_SKILL_STATUS_OK).Find(&data).Error
	return
}

// 查询大神技能抢单开关开启数量
func (m *AppSparringSkill) QueryMatchingOnCount(userId int64) (count int64, err error) {
	err = utils.GEngine.Model(m).Where("skill_user_id = ? AND skill_speed_matching_status = ?", userId, SPARRING_SKILL_MATCHING_ON).Count(&count).Error
	return
}

// QuerySparringSkillID 根据技能认证表id,查询技能基础表id
func (m *AppSparringSkill) QuerySparringSkillID(uid, sid int64) (data AppSparringSkill, err error) {
	err = utils.GEngine.
		Select("skill_id").
		Where("skill_skill_id = ? AND skill_user_id = ?", sid, uid).
		First(&data).Error
	return
}
