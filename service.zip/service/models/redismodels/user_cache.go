package redismodels

import (
	"encoding/json"
	"fmt"
	"gamers/models/dbmodels"
	"gamers/utils"
	"strconv"

	"github.com/go-redis/redis"

	"github.com/fatih/structs"
)

// 用户缓存信息
type UserInfo struct {
	Token             string `redis:"Token"`
	UserID            int64  `redis:"UserID"`
	UserPrettyId      int64  `redis:"UserPrettyId"`      // 靓号
	UserNickname      string `redis:"UserNickname"`      // 昵称
	UserIconurl       string `redis:"UserIconurl"`       // 头像
	UserUnionId       int64  `redis:"UserUnionId"`       // 公会id
	UserSlogan        string `redis:"UserSlogan"`        // 用户签名
	UserGameSavor     string `redis:"UserGameSavor"`     // 用户游戏兴趣
	UserGameOrder     string `redis:"UserGameOrder"`     // 游戏页
	UserGender        int    `redis:"UserGender"`        // 用户性别0未知,1男,2女
	UserYouthStatus   int    `redis:"UserYouthStatus"`   // 青少年模式状态(0关闭,1开启)
	UserYouthPassword string `redis:"UserYouthPassword"` // 青少年模式密码
	UserIsOnline      int    `redis:"UserIsOnline"`      // 在线状态
	WalletTotalOver   int64  `redis:"WalletTotalOver"`   // 总余额(可用代币数)
	UserEggbreakMsg   int    `redis:"UserEggbreakMsg"`   // 是否发送砸蛋信息
	UserIsSuper       int    `redis:"UserIsSuper"`       // 是否超管：0--否，1--是
	UserAge           int    `redis:"UserAge"`           // 用户年龄
	VipLevel          int    `redis:"VipLevel"`          // 用户vip等级
	UserIsRecharge    int    `redis:"UserIsRecharge"`    // 是否首充
	CreateTime        int64  `redis:"CreateTime"`        // 用户创建时间，支付预警。
}

func (s *UserInfo) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s UserInfo) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

// 这个结构体不缓存用户token
type UserInfoUpdate struct {
	UserID            int64  `redis:"UserID"`
	UserPrettyId      int64  `redis:"UserPrettyId"`      // 靓号
	UserNickname      string `redis:"UserNickname"`      // 昵称
	UserIconurl       string `redis:"UserIconurl"`       // 头像
	UserUnionId       int64  `redis:"UserUnionId"`       // 公会id
	UserSlogan        string `redis:"UserSlogan"`        // 用户签名
	UserGameSavor     string `redis:"UserGameSavor"`     // 用户游戏兴趣
	UserGameOrder     string `redis:"UserGameOrder"`     // 游戏页
	UserGender        int    `redis:"UserGender"`        // 用户性别0未知,1男,2女
	UserYouthStatus   int    `redis:"UserYouthStatus"`   // 青少年模式状态(0关闭,1开启)
	UserYouthPassword string `redis:"UserYouthPassword"` // 青少年模式密码
	UserIsOnline      int    `redis:"UserIsOnline"`      // 在线状态
	WalletTotalOver   int64  `redis:"WalletTotalOver"`   // 总余额(可用代币数)
	UserEggbreakMsg   int    `redis:"UserEggbreakMsg"`   // 是否发送砸蛋信息
	UserIsSuper       int    `redis:"UserIsSuper"`       // 是否超管：0--否，1--是
	UserAge           int    `redis:"UserAge"`           // 用户年龄
	VipLevel          int    `redis:"VipLevel"`          // 用户vip等级
	UserIsRecharge    int    `redis:"UserIsRecharge"`    // 是否首充
	CreateTime        int64  `redis:"CreateTime"`        // 用户创建时间，支付预警。
}

const (
	USER_INFO_IS_SUPER_NO  = iota // 不是超管
	USER_INFO_IS_SUPER_YES        // 是超管
)

// 保存用户信息到redis
func (m UserInfo) SaveUserInfo(user dbmodels.SystemUser, ati string) {
	fmt.Printf("ati:%s\n", ati)
	userStr := strconv.Itoa(int(user.UserID))
	m.UserID = user.UserID
	m.UserNickname = user.UserNickname
	m.UserIconurl = user.UserIconurl
	m.Token = ati
	m.UserSlogan = user.UserSlogan
	m.UserGameSavor = user.UserGameSavor
	m.UserGameOrder = user.UserGameOrder
	m.UserYouthStatus = user.UserYouthStatus
	m.UserYouthPassword = user.UserYouthPassword
	m.UserUnionId = user.UserUnionId
	m.UserGender = user.UserGender
	m.UserIsSuper = user.UserIsSuper
	m.UserAge = utils.FuncGetAge(int(user.UserBirthday))
	m.UserIsRecharge = user.UserIsRecharge
	m.UserEggbreakMsg = user.UserEggbreakMsg
	m.UserPrettyId = user.UserPrettyId
	m.CreateTime = user.BaseModel.Created // 用户创建时间，用于支付预警。
	m.UserIsOnline = user.UserIsOnline
	// 查询用户余额
	wallet, err := new(dbmodels.AppUserWallet).Query(user.UserID)
	if err != nil {
		utils.LogErrorF("获取用户钱包失败:userId[%d],err[%s]", user.UserID, err.Error())
	} else {
		m.WalletTotalOver = wallet.WalletTotalOver
	}
	vipInfo, err := new(dbmodels.AppUserVipExperience).GetUserVipLevelByUserId(m.UserID)
	if err != nil {
		utils.LogErrorF("获取用户vip信息失败:userId[%d],err[%s]", user.UserID, err.Error())
	} else {
		m.VipLevel = vipInfo.ExperienceLevel
	}
	err = utils.RedisClient.HMSet(utils.REDIS_USER_INFO+userStr, structs.Map(m)).Err()
	if err != nil {
		utils.LogErrorF("保存用户信息到redis错误:userId[%d],err[%s]", user.UserID, err.Error())
	}
}

// 更新用户信息到redis
func (m UserInfoUpdate) UpdateUserInfo(user dbmodels.SystemUser) {
	userStr := strconv.Itoa(int(user.UserID))
	m.UserID = user.UserID
	m.UserNickname = user.UserNickname
	m.UserIconurl = user.UserIconurl
	m.UserSlogan = user.UserSlogan
	m.UserYouthStatus = user.UserYouthStatus
	m.UserYouthPassword = user.UserYouthPassword
	m.UserGameSavor = user.UserGameSavor
	m.UserGameOrder = user.UserGameOrder
	m.UserUnionId = user.UserUnionId
	m.UserGender = user.UserGender
	m.UserIsSuper = user.UserIsSuper
	m.UserAge = utils.FuncGetAge(int(user.UserBirthday))
	m.UserIsRecharge = user.UserIsRecharge
	m.UserEggbreakMsg = user.UserEggbreakMsg
	m.UserPrettyId = user.UserPrettyId
	m.CreateTime = user.BaseModel.Created // 用户创建时间，用于支付预警。
	m.UserIsOnline = dbmodels.USER_IS_ONLINE_ONLINE
	// 查询用户余额
	wallet, err := new(dbmodels.AppUserWallet).Query(user.UserID)
	if err != nil {
		utils.LogErrorF("获取用户钱包失败:userId[%d],err[%s]", user.UserID, err.Error())
	} else {
		m.WalletTotalOver = wallet.WalletTotalOver
	}
	vipInfo, err := new(dbmodels.AppUserVipExperience).GetUserVipLevelByUserId(m.UserID)
	if err != nil {
		utils.LogErrorF("获取用户vip信息失败:userId[%d],err[%s]", user.UserID, err.Error())
	} else {
		m.VipLevel = vipInfo.ExperienceLevel
	}
	err = utils.RedisClient.HMSet(utils.REDIS_USER_INFO+userStr, structs.Map(m)).Err()
	if err != nil {
		utils.LogErrorF("保存用户信息到redis错误:userId[%d],err[%s]", user.UserID, err.Error())
	}
}

// 单独设置缓存（UserEggbreakMsg）--> 只存redis
func (m *UserInfoUpdate) UpdateUserEggbreakMsg(userId int64, notice int) error {
	userStr := strconv.Itoa(int(userId))
	var err = utils.RedisClient.HSet(utils.REDIS_USER_INFO+userStr, "UserEggbreakMsg", notice).Err()
	if err != nil {
		utils.LogErrorF("保存是否发送砸蛋信息标记到redis错误:userId[%d],err[%s]", userId, err.Error())
	}
	return err
}

// 单独获取缓存
func (m *UserInfo) GetUserEggbreakMsg(userId int64) (int, error) {
	userStr := strconv.Itoa(int(userId))
	val, err := utils.RedisClient.HGet(utils.REDIS_USER_INFO+userStr, "UserEggbreakMsg").Int()
	if err != nil && err != redis.Nil {
		return 0, err
	}
	return val, nil
}

// 从缓存获取用户信息
func (m UserInfo) GetUserInfo(userId int64) (userInfo UserInfo, err error) {
	userStr := strconv.Itoa(int(userId))
	val := utils.RedisClient.HGetAll(utils.REDIS_USER_INFO + userStr).Val()
	err = utils.HashToStruct(val, &userInfo)
	return
}

// 更新用户余额
func (m UserInfo) UpdateUserWalletTotalOver(userId int64, walletTotalOver int64) (err error) {
	key := fmt.Sprintf("%s%d", utils.REDIS_USER_INFO, userId)
	err = utils.RedisClient.HSet(key, "WalletTotalOver", walletTotalOver).Err()
	return
}

// 更新用户vip信息
func (m UserInfo) UpdateUserVipLevel(userId int64, level int) (err error) {
	key := fmt.Sprintf("%s%d", utils.REDIS_USER_INFO, userId)
	err = utils.RedisClient.HSet(key, "VipLevel", level).Err()
	return
}

// 更新用户首充
func (m UserInfo) UpdateUserIsRecharge(userId int64) (err error) {
	key := fmt.Sprintf("%s%d", utils.REDIS_USER_INFO, userId)
	err = utils.RedisClient.HSet(key, "UserIsRecharge", dbmodels.USER_RECHARGE_YES).Err()
	return
}

// 获取vip等级
func (m UserInfo) GetUserVipLevel(userId int64) (level int, err error) {
	key := fmt.Sprintf("%s%d", utils.REDIS_USER_INFO, userId)
	level, err = utils.RedisClient.HGet(key, "VipLevel").Int()
	return
}

// 获取用户当前房间
func (m UserInfo) GetUserJoinRoomId(userId int64) (room int64, err error) {
	key := fmt.Sprintf("%s%d", utils.REDIS_LIVE_JOIN_USER, userId)
	err = utils.RedisClient.Get(key).Scan(&room)
	if err != nil {
		room = 0
	}
	return
}

// GetUserCreateTime 获取用户创建时间,用于支付预警功能。
func (m UserInfo) GetUserCreateTime(userID int64) (created int64, err error) {
	key := fmt.Sprintf("%s%d", utils.REDIS_USER_INFO, userID)
	return utils.RedisClient.HGet(key, "CreateTime").Int64()
}

// 获取在线状态
func (m UserInfo) GetUserOnline(userId int64) (isOnline int) {
	key := fmt.Sprintf("%s%d", utils.REDIS_USER_INFO, userId)
	isOnline, err := utils.RedisClient.HGet(key, "UserIsOnline").Int()
	if err != nil {
		isOnline = 0
	}
	return isOnline
}

func (m *UserInfo) UpdateIsOnline(userIdStr string, online int) {
	var (
		err error
	)

	// 更新用户缓存
	_, err = utils.RedisClient.HSet(utils.REDIS_USER_INFO+userIdStr, "UserIsOnline", online).Result()
	if err != nil {
		utils.LogErrorF("缓存用户[%s]上线状态失败:%s", userIdStr, err.Error())
		return
	}
}
