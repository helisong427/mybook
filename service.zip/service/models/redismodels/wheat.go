package redismodels

import (
	"encoding/json"
	"errors"
	"fmt"
	"gamers/models/dbmodels"
	"gamers/utils"
	"strconv"
	"time"

	"github.com/go-redis/redis"

	"gorm.io/gorm"
)

var (
	ErrWheatGetUserInfo       = errors.New("获取用户信息失败")
	ErrWheatGetUserAvatar     = errors.New("获取用户头像框失败")
	ErrWheatLater             = errors.New("稍后再试")
	ErrWheatUnopened          = errors.New("未开启麦位")
	ErrWheatNoFree            = errors.New("无空闲麦位")
	ErrWheatNoAuth            = errors.New("无权操作")
	ErrWheatAlready           = errors.New("已在麦位上")
	ErrWheatDoesNotExist      = errors.New("麦位不存在")
	ErrWheatNull              = errors.New("用户不在麦位上")
	ErrWheatUserNotExist      = errors.New("麦位用户不存在")
	ErrWheatNoAnchorWheat     = errors.New("不能操作主播麦位")
	ErrWheatIsAlreadyOccupied = errors.New("麦位已被占用")
	ErrWheatNotYours          = errors.New("麦位不属于你")
	ErrWheatPositionLocked    = errors.New("麦位已锁定")
	ErrWheatErr               = errors.New("麦位错误")
	ErrWheatUnlockOrLock      = errors.New("请先解锁或上锁")
	ErrWheatAlreadyQueue      = errors.New("已在麦序列表中")
	ErrWheatNotANormalUser    = errors.New("非普通用户不能排队")
	ErrWheatCantOpenLove      = errors.New("当前模式下无法开启爱意值")
	ErrWheatUserNotInTheRoom  = errors.New("用户不在当前房间")
)

const (
	WHEAT_LOVE_SWITCH = "wheat_love_switch" // 爱意开关
	WHEAT_SWITCH      = "wheat_switch"      // 麦位开关
	WHEAT_LEN         = "wheat_len"         // 麦位长度
	WHEAT_LIST        = "wheat_list"        // 麦位列表

	WHEAT_PARTY_LEN  int = 9 // 派对房麦位长度
	WHEAT_LIVE_LEN   int = 5 // 直播房麦位长度
	WHEAT_SWITCH_OFF int = 0 // 关闭麦位
	WHEAT_SWITCH_ON  int = 1 // 开启麦位

	WHEAT_HOME_KEY int = 0 // 房主麦位下标

	WHEAT_DOWN int = 0 // 下麦
	WHEAT_UP   int = 1 // 上麦

	WHEAT_STATUS_UNLOCK    int = 0 // 解锁
	WHEAT_STATUS_LOCK      int = 1 // 上锁
	WHEAT_STATUS_BAN_WHEAT int = 2 // 禁麦
)

const (
	// 爱意值开关
	WHEAT_LOVE_SWITCH_OFF    int = iota // 关闭
	WHEAT_LOVE_SWITCH_OPEN              // 开
	WHEAT_LOVE_SWITCH_FREEZE            // 冻结
)

const (
	// 用户身份
	WHEAT_ROLE_USER         int = iota // 普通用户
	WHEAT_ROLE_DEPUTY_ADMIN            // 副管理员
	WHEAT_ROLE_ADMIN                   // 管理员
	WHEAT_ROLE_ANCHOR                  // 主播
)

// 查询直播间缓存是否存在
func (m *Wheat) queryExist(key string) (exist bool) {
	exist = utils.RedisClient.HExists(key, WHEAT_SWITCH).Val()
	return
}

// 查询麦位
func (m *Wheat) queryWheat(key string) (list []WheatObj, err error) {
	data, err := utils.RedisClient.HGet(key, WHEAT_LIST).Result()
	if err != nil {
		return
	}
	err = json.Unmarshal([]byte(data), &list)
	return
}

// 更新麦位
func (m *Wheat) updateWheatObj(key string, data []WheatObj) (err error) {
	list, _ := json.Marshal(data)
	err = utils.RedisClient.HSet(key, WHEAT_LIST, string(list)).Err()
	return
}

// 更新麦位-外部调用
func (m *Wheat) UpdateWheatObj(key string, data []WheatObj) (err error) {
	list, _ := json.Marshal(data)
	err = utils.RedisClient.HSet(key, WHEAT_LIST, string(list)).Err()
	return
}

// 更新爱意值开关
func (m *Wheat) updateWheatLoveSwitch(key string, switchLove int, roomId int) (err error) {
	if switchLove == WHEAT_LOVE_SWITCH_OFF {
		switchKey := fmt.Sprintf("%s%d", utils.REDIS_LIVE_WHEAT_LOVE, roomId)
		err = utils.RedisClient.Del(switchKey).Err()
		if err != nil {
			return err
		}
	}

	err = utils.RedisClient.HSet(key, WHEAT_LOVE_SWITCH, switchLove).Err()
	return
}

// 初始化麦位
func (m *Wheat) Init(roomId int, userId int64, wheatType int, IsOpenWheat int) (err error) {
	key := utils.REDIS_LIVE_WHEAT + strconv.Itoa(roomId)
	_lockVal, islock := utils.AcquireLock(key, utils.DEFAULT_LOCK_KEY_TIMEOUT, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT)
	if !islock {
		err = ErrWheatLater
		return
	}
	defer utils.ReleaseLock(key, _lockVal)

	data := Wheat{}
	data.WheatSwitch = IsOpenWheat               // 是否开启麦位
	data.WheatLoveSwitch = WHEAT_LOVE_SWITCH_OFF // 默认关闭爱意值
	if wheatType == dbmodels.ROOM_TYPE_LIVE {
		data.WheatLen = WHEAT_LIVE_LEN
	} else {
		data.WheatLen = WHEAT_PARTY_LEN
	}
	// 获取用户信息
	info, err := new(UserInfo).GetUserInfo(userId)
	if err != nil {
		err = ErrWheatGetUserInfo
		return
	}
	// 获取头像框
	avatarDressUp, err := new(IconStyle).Get(userId)
	if err != nil {
		err = ErrWheatGetUserAvatar
		return
	}
	t := time.Now().Unix()
	for i := 0; i < data.WheatLen; i++ {
		// 设置房主
		if i == WHEAT_HOME_KEY {
			tmp := WheatObj{
				Role:              WHEAT_ROLE_ANCHOR,
				UserId:            int(userId),
				UserNickName:      info.UserNickname,
				UserIconurl:       info.UserIconurl,
				UserGender:        info.UserGender,
				UserAvatarDressUp: avatarDressUp,
				Status:            WHEAT_STATUS_BAN_WHEAT,
				LoveValue:         0,
				Position:          i,
				UpdateTime:        t,
			}
			data.WheatObj = append(data.WheatObj, tmp)
		} else {
			tmp := WheatObj{
				Role:       WHEAT_ROLE_USER,
				Position:   i,
				UpdateTime: t,
			}
			data.WheatObj = append(data.WheatObj, tmp)
		}
	}
	wheatMap := make(map[string]interface{})
	wheatMap[WHEAT_SWITCH] = data.WheatSwitch
	wheatMap[WHEAT_LOVE_SWITCH] = data.WheatLoveSwitch
	wheatMap[WHEAT_LEN] = data.WheatLen
	list, _ := json.Marshal(data.WheatObj)
	wheatMap[WHEAT_LIST] = list
	err = utils.RedisClient.HMSet(key, wheatMap).Err()
	return
}

// 切换玩法
// roomId 房间id
// userId 用户id
// _switch 开关麦位:0--关,1--开
// wheatType 房间类型
// isResetAnchor 是否重置主播麦位
// isResetWheat 是否重置麦位
func (m *Wheat) SwitchPlayWheat(roomId int, userId int64, _switch int, wheatType int, isResetAnchor bool, isResetWheat bool) (data Wheat, err error) {
	key := utils.REDIS_LIVE_WHEAT + strconv.Itoa(roomId)
	_lockVal, islock := utils.AcquireLock(key, utils.DEFAULT_LOCK_KEY_TIMEOUT, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT)
	if !islock {
		err = ErrWheatLater
		return
	}
	defer utils.ReleaseLock(key, _lockVal)

	// 查询麦位详情
	detail, err := m.QueryWheatDetail(roomId)
	if err != nil {
		err = ErrWheatErr
		return
	}

	if _switch == WHEAT_SWITCH_ON {
		data.WheatSwitch = WHEAT_SWITCH_ON
	} else {
		data.WheatSwitch = WHEAT_SWITCH_OFF
	}
	data.WheatLoveSwitch = WHEAT_LOVE_SWITCH_OFF // 默认关闭爱意值

	// 修改麦位长度
	if wheatType == dbmodels.ROOM_TYPE_LIVE {
		data.WheatLen = WHEAT_LIVE_LEN
	} else {
		data.WheatLen = WHEAT_PARTY_LEN
	}
	t := time.Now().Unix()
	if isResetWheat {
		// 重置麦位
		for i := 0; i < data.WheatLen; i++ {
			// 设置房主
			if i == WHEAT_HOME_KEY && isResetAnchor {
				userInfo, _ := new(UserInfo).GetUserInfo(userId)
				// 获取头像框
				avatarDressUp, err := new(IconStyle).Get(userId)
				if err != nil {
					err = ErrWheatGetUserAvatar
					return data, err
				}
				homeUser := WheatObj{
					Role:              WHEAT_ROLE_ANCHOR,
					UserId:            int(userId),
					UserNickName:      userInfo.UserNickname,
					UserIconurl:       userInfo.UserIconurl,
					UserGender:        userInfo.UserGender,
					UserAvatarDressUp: avatarDressUp,
					Position:          i,
					UpdateTime:        t,
				}
				// 如果主持麦位有用户,继承麦位状态
				if detail.WheatObj[WHEAT_HOME_KEY].UserId != 0 {
					homeUser.Status = detail.WheatObj[WHEAT_HOME_KEY].Status
				}

				data.WheatObj = append(data.WheatObj, homeUser)
			} else {
				tmp := WheatObj{
					Role:       WHEAT_ROLE_USER,
					Position:   i,
					UpdateTime: t,
				}
				data.WheatObj = append(data.WheatObj, tmp)
			}
		}

		wheatMap := make(map[string]interface{})
		wheatMap[WHEAT_SWITCH] = data.WheatSwitch
		wheatMap[WHEAT_LOVE_SWITCH] = data.WheatLoveSwitch
		wheatMap[WHEAT_LEN] = data.WheatLen
		list, _ := json.Marshal(data.WheatObj)
		wheatMap[WHEAT_LIST] = list
		err = utils.RedisClient.HMSet(key, wheatMap).Err()
		return
	} else {
		data, err = m.QueryWheatDetail(roomId)
		if err != nil {
			return
		}
		return
	}
}

// 开启麦位
func (m *Wheat) OpenWheat(roomId int, userId int64) (data Wheat, err error) {
	key := utils.REDIS_LIVE_WHEAT + strconv.Itoa(roomId)
	_lockVal, islock := utils.AcquireLock(key, utils.DEFAULT_LOCK_KEY_TIMEOUT, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT)
	if !islock {
		err = ErrWheatLater
		return
	}
	defer utils.ReleaseLock(key, _lockVal)

	// 查询用户身份
	role, err := m.QueryUserRole(roomId, userId)
	if err != nil {
		return
	}
	if role < WHEAT_ROLE_ADMIN {
		err = ErrWheatNoAuth
		return
	}

	// 开启麦位
	err = utils.RedisClient.HSet(key, WHEAT_SWITCH, WHEAT_SWITCH_ON).Err()
	if err != nil {
		return
	}

	// 查询麦位详情
	data, err = m.QueryWheatDetail(roomId)
	if err != nil {
		return
	}
	return
}

// 关闭麦位
func (m *Wheat) OffWheat(roomId int, userId int64) (data Wheat, err error) {
	key := utils.REDIS_LIVE_WHEAT + strconv.Itoa(roomId)
	_lockVal, islock := utils.AcquireLock(key, utils.DEFAULT_LOCK_KEY_TIMEOUT, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT)
	if !islock {
		err = ErrWheatLater
		return
	}
	defer utils.ReleaseLock(key, _lockVal)

	// 查询用户身份
	role, err := m.QueryUserRole(roomId, userId)
	if err != nil {
		return
	}
	if role < WHEAT_ROLE_ADMIN {
		err = ErrWheatNoAuth
		return
	}

	err = utils.RedisClient.HSet(key, WHEAT_SWITCH, WHEAT_SWITCH_OFF).Err()
	if err != nil {
		return
	}

	// 查询麦位详情
	detail, err := m.QueryWheatDetail(roomId)
	if err != nil {
		return
	}
	t := time.Now().Unix()
	// 踢掉1-8号麦位的用户
	for i := 1; i < detail.WheatLen; i++ {
		detail.WheatObj[i].UserId = 0
		detail.WheatObj[i].UserNickName = ""
		detail.WheatObj[i].UserIconurl = ""
		detail.WheatObj[i].UserGender = 0
		detail.WheatObj[i].UserAvatarDressUp = ""
		detail.WheatObj[i].Role = WHEAT_ROLE_USER
		detail.WheatObj[i].Status = WHEAT_STATUS_UNLOCK
		detail.WheatObj[i].UpdateTime = t
	}

	err = m.updateWheatObj(key, detail.WheatObj)
	if err != nil {
		return
	}
	// 查询麦位详情
	data, err = m.QueryWheatDetail(roomId)
	if err != nil {
		return
	}
	return
}

// 查询用户身份
func (m *Wheat) QueryUserRole(roomId int, userId int64) (role int, err error) {
	role = 0
	// 查询用户管理员身份
	row, adminData, err := new(dbmodels.AppRoomAdmin).QueryUser(userId, int64(roomId))
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	// if row > 0 && adminData.AdminRole != models.ROOM_ADMIN_ROLE_LANDLORD {
	if row > 0 {
		role = adminData.AdminRole
		return
	}

	// 查询用户主播身份
	data, err := new(dbmodels.AppLiveRoom).QueryRoomId(roomId)
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	if row > 0 && data.RoomUserId == userId {
		role = WHEAT_ROLE_ANCHOR
	}
	return
}

// 上下麦
// roomId 房间Id
// userId 上麦用户id
// wheatKey 麦位下标
// upAndDownWheat 上麦和下麦
func (m *Wheat) UpAndDownWheat(roomId int, userId int64, wheatKey int, upAndDownWheat int) (data Wheat, err error) {
	key := utils.REDIS_LIVE_WHEAT + strconv.Itoa(roomId)
	_lockVal, islock := utils.AcquireLock(key, utils.DEFAULT_LOCK_KEY_TIMEOUT, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT)
	if !islock {
		err = ErrWheatLater
		return
	}
	defer utils.ReleaseLock(key, _lockVal)

	if upAndDownWheat == WHEAT_UP {
		// 判断用户是否在房间
		if userRoomId, _ := new(UserInfo).GetUserJoinRoomId(userId); userRoomId == 0 {
			err = ErrWheatUserNotInTheRoom
			return
		}
	}

	// 查询麦位详情
	detail, err := m.QueryWheatDetail(roomId)
	if err != nil {
		return
	}
	// 查询用户身份
	role, err := m.QueryUserRole(roomId, userId)
	if err != nil {
		return
	}

	c := newWheatContext(role)
	if upAndDownWheat == WHEAT_UP {
		return c.up(detail, roomId, userId, wheatKey)
	} else {
		return c.down(detail, roomId, userId, wheatKey)
	}
}

// 抱上下麦序
// roomId 房间Id
// wheatUserId 上麦用户id
// apiUserId 请求接口用户id
// wheatKey 麦位下标
// upAndDownWheat 上麦和下麦
func (m *Wheat) HodUpAndOnWheat(roomId int, wheatUserId int64, apiUserId int64, wheatKey int, upAndDownWheat int) (data Wheat, err error) {
	key := utils.REDIS_LIVE_WHEAT + strconv.Itoa(roomId)
	_lockVal, islock := utils.AcquireLock(key, utils.DEFAULT_LOCK_KEY_TIMEOUT, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT)
	if !islock {
		err = ErrWheatLater
		return
	}
	defer utils.ReleaseLock(key, _lockVal)

	if upAndDownWheat == WHEAT_UP {
		// 判断用户是否在房间
		if userRoomId, _ := new(UserInfo).GetUserJoinRoomId(wheatUserId); userRoomId == 0 {
			err = ErrWheatUserNotInTheRoom
			return
		}
	}

	// 查询麦位详情
	detail, err := m.QueryWheatDetail(roomId)
	if err != nil {
		return
	}

	// 查询上麦用户用户身份
	wheatUserRole, err := m.QueryUserRole(roomId, wheatUserId)
	if err != nil {
		return
	}

	// 查询请求接口用户身份
	apiUserRole, err := m.QueryUserRole(roomId, apiUserId)
	if err != nil {
		return
	}
	c := newWheatHugContext(apiUserRole)
	if upAndDownWheat == WHEAT_UP {
		return c.hugUP(detail, roomId, wheatUserId, wheatKey, wheatUserRole, apiUserRole)
	} else {
		return c.hugDown(detail, roomId, wheatUserId, wheatKey, wheatUserRole, apiUserRole)
	}
}

// 锁定/解锁麦位
// roomId 房间Id
// userId 操作用户id
// wheatKey 麦位下标
// lockAndUnLockWheat 锁和解锁
func (m *Wheat) LockAndUnlockWheat(roomId int, userId int64, wheatKey int, lockAndUnLockWheat int) (data Wheat, err error) {
	key := utils.REDIS_LIVE_WHEAT + strconv.Itoa(roomId)
	_lockVal, islock := utils.AcquireLock(key, utils.DEFAULT_LOCK_KEY_TIMEOUT, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT)
	if !islock {
		err = ErrWheatLater
		return
	}
	defer utils.ReleaseLock(key, _lockVal)

	// 查询麦位详情
	detail, err := m.QueryWheatDetail(roomId)
	if err != nil {
		return
	}

	if detail.WheatSwitch == WHEAT_SWITCH_OFF {
		err = ErrWheatUnopened
		return
	}

	// 查询用户身份
	role, err := m.QueryUserRole(roomId, userId)
	if err != nil {
		return
	}
	t := time.Now().Unix()
	// 只有房主和管理员才能上锁
	if role != WHEAT_ROLE_USER {
		if detail.WheatObj[wheatKey].Status == lockAndUnLockWheat {
			err = ErrWheatUnlockOrLock
			return
		}

		if wheatKey > detail.WheatLen-1 {
			err = ErrWheatDoesNotExist
			return
		}

		// 解锁/上锁
		detail.WheatObj[wheatKey].Status = lockAndUnLockWheat
		detail.WheatObj[wheatKey].UserId = 0
		detail.WheatObj[wheatKey].UserNickName = ""
		detail.WheatObj[wheatKey].UserIconurl = ""
		detail.WheatObj[wheatKey].UserGender = 0
		detail.WheatObj[wheatKey].UserAvatarDressUp = ""
		detail.WheatObj[wheatKey].UpdateTime = t
		err = m.updateWheatObj(key, detail.WheatObj)
		if err != nil {
			return
		}

		data, err = new(Wheat).QueryWheatDetail(roomId)
		if err != nil {
			return
		}
		data.WheatObj = data.WheatObj[:0]                                // 清空
		data.WheatObj = append(data.WheatObj, detail.WheatObj[wheatKey]) // 重新赋值
		return
	} else {
		err = ErrWheatNoAuth
		return
	}
}

// 开关爱意值
// roomId 房间id
// userId 用户id
// loveSwitch 开关
func (m *Wheat) SwitchWheatLove(roomId int, userId int64, _switch int, check bool) (data Wheat, err error) {
	key := utils.REDIS_LIVE_WHEAT + strconv.Itoa(roomId)
	_lockVal, islock := utils.AcquireLock(key, utils.DEFAULT_LOCK_KEY_TIMEOUT, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT)
	if !islock {
		err = ErrWheatLater
		return
	}
	defer utils.ReleaseLock(key, _lockVal)

	// 查询麦位详情
	detail, err := m.QueryWheatDetail(roomId)
	if err != nil {
		return
	}

	if detail.WheatSwitch == WHEAT_SWITCH_OFF {
		err = ErrWheatCantOpenLove
		return
	}

	// 查询用户身份
	var role int
	if check {
		role, err = m.QueryUserRole(roomId, userId)
		if err != nil {
			return
		}
	}
	t := time.Now().Unix()
	// 只有房主和管理员开关爱意值
	if role != WHEAT_ROLE_USER || !check {
		// 重置爱意值
		for i := 0; i < detail.WheatLen; i++ {
			detail.WheatObj[i].LoveValue = 0
			detail.WheatObj[i].UpdateTime = t
		}

		err = m.updateWheatObj(key, detail.WheatObj)
		if err != nil {
			return
		}
		err = m.updateWheatLoveSwitch(key, _switch, roomId)
		if err != nil {
			return
		}
		data, err = m.QueryWheatDetail(roomId)
		if err != nil {
			return
		}
		return
	} else {
		err = ErrWheatNoAuth
		return
	}
}

// 增加爱意值
// 如果以后调用该方法
// roomId 房间id
// _keys 收到礼物的麦位key,支持批量增加爱意值
// userId 送礼用户id
// giftCharm 收到的礼物魅力值
func (m Wheat) AddLove(roomId int, addLove int) Wheat {
	key := utils.REDIS_LIVE_WHEAT + strconv.Itoa(roomId)
	_lockVal, islock := utils.AcquireLock(key, 10, utils.DEFAULT_LOCK_KEY_TIMEOUT)
	if !islock {
		utils.LogErrorF("增加爱意值加锁失败")
		return m
	}
	defer utils.ReleaseLock(key, _lockVal)

	if m.WheatSwitch == WHEAT_SWITCH_OFF {
		utils.LogErrorF("爱意值开关未打开")
		return m
	}
	// 查询麦位详情
	detail, err := m.QueryWheatDetail(roomId)
	if err != nil {
		return m
	}
	t := time.Now().Unix()
	// 爱意值
	for i, k := range detail.WheatObj {
		for _, v := range m.WheatObj {
			if v.Position == k.Position {
				detail.WheatObj[i].LoveValue += addLove
				detail.WheatObj[i].UpdateTime = t
			}
		}
	}

	err = m.updateWheatObj(key, detail.WheatObj)
	if err != nil {
		utils.LogErrorF("更新爱意值失败,err:%s", err.Error())
	}
	return m
}

// 获取麦位详情
func (m *Wheat) QueryWheatDetail(roomId int) (data Wheat, err error) {
	key := utils.REDIS_LIVE_WHEAT + strconv.Itoa(roomId)
	// exist := m.queryExist(key)
	// if !exist {
	//	err = ErrWheatErr
	//	return
	// }
	allInfo, err := utils.RedisClient.HGetAll(key).Result()
	if err != nil && err != redis.Nil {
		return
	}
	// 没有麦位,创建麦位
	if len(allInfo) == 0 {
		// 查询房间信息
		room, err := new(dbmodels.AppLiveRoom).QueryRoomId(roomId)
		if err != nil {
			return data, err
		}
		err = m.Init(roomId, room.RoomUserId, room.RoomType, WHEAT_SWITCH_ON)
		if err != nil {
			return data, err
		}
		return m.QueryWheatDetail(roomId)
	}

	wheatlist := allInfo[WHEAT_LIST]
	err = json.Unmarshal([]byte(wheatlist), &data.WheatObj)
	data.WheatLoveSwitch, _ = strconv.Atoi(allInfo[WHEAT_LOVE_SWITCH])
	// 判断爱意值如果开启
	if data.WheatLoveSwitch == WHEAT_LOVE_SWITCH_OPEN || data.WheatLoveSwitch == WHEAT_LOVE_SWITCH_FREEZE {
		data.GetLoveValue(int64(roomId))
	}
	data.WheatLen, _ = strconv.Atoi(allInfo[WHEAT_LEN])
	data.WheatSwitch, _ = strconv.Atoi(allInfo[WHEAT_SWITCH])
	return
}

// 获取麦位上爱意值
func (m *Wheat) GetLoveValue(roomId int64) {
	roomIdStr := strconv.Itoa(int(roomId))
	for i, v := range m.WheatObj {
		if v.UserId != 0 {
			userIdStr := strconv.Itoa(v.UserId)
			// 获取用户爱意值
			LoveValue, _ := utils.RedisClient.HGet(utils.REDIS_LIVE_WHEAT_LOVE+roomIdStr, userIdStr).Int64()
			m.WheatObj[i].LoveValue = int(LoveValue)
		}
	}
}

// 系统下麦
// 指定用户踢下麦位
func (m *Wheat) SystemDown(roomId int, userId int) (isChanged bool, data Wheat, position int, err error) {
	key := utils.REDIS_LIVE_WHEAT + strconv.Itoa(roomId)
	// 查询麦位详情
	detail, err := m.QueryWheatDetail(roomId)
	if err != nil {
		return
	}
	// 临时储存发生变更的下标
	tmpKey := -1
	t := time.Now().Unix()
	position = -1
	for k, v := range detail.WheatObj {
		if v.UserId == userId {
			detail.WheatObj[k].UserId = 0
			detail.WheatObj[k].UserNickName = ""
			detail.WheatObj[k].UserIconurl = ""
			detail.WheatObj[k].UserGender = 0
			detail.WheatObj[k].UserAvatarDressUp = ""
			detail.WheatObj[k].Role = 0
			detail.WheatObj[k].LoveValue = 0
			detail.WheatObj[k].Status = WHEAT_STATUS_UNLOCK
			detail.WheatObj[k].UpdateTime = t
			isChanged = true // 发生变更
			tmpKey = k
			position = v.Position
			break
		}
	}
	// 发生变更
	if isChanged {
		err = m.updateWheatObj(key, detail.WheatObj)
		if err != nil {
			return
		}
		data, err = new(Wheat).QueryWheatDetail(roomId)
		if err != nil {
			return
		}
		data.WheatObj = data.WheatObj[:0]                              // 清空
		data.WheatObj = append(data.WheatObj, detail.WheatObj[tmpKey]) // 重新赋值
	}

	return
}

// 确认下播
func (m *Wheat) ConfirmDowncast(roomId int) (detail Wheat, err error) {
	key := utils.REDIS_LIVE_WHEAT + strconv.Itoa(roomId)
	// 查询麦位详情
	detail, err = m.QueryWheatDetail(roomId)
	if err != nil {
		return
	}
	t := time.Now().Unix()
	for k, _ := range detail.WheatObj {
		detail.WheatObj[k].UserId = 0
		detail.WheatObj[k].UserNickName = ""
		detail.WheatObj[k].UserIconurl = ""
		detail.WheatObj[k].UserGender = 0
		detail.WheatObj[k].UserAvatarDressUp = ""
		detail.WheatObj[k].Role = 0
		detail.WheatObj[k].LoveValue = 0
		detail.WheatObj[k].Status = WHEAT_STATUS_UNLOCK
		detail.WheatObj[k].UpdateTime = t
	}
	err = m.updateWheatObj(key, detail.WheatObj)
	if err != nil {
		return
	}
	detail.WheatSwitch = WHEAT_SWITCH_OFF

	// 关闭麦位
	err = utils.RedisClient.HSet(key, WHEAT_SWITCH, detail.WheatSwitch).Err()
	return
}

// 禁麦
func (m *Wheat) BanWheat(roomId int, userId int64, wheatKey int, action int) (data Wheat, err error) {
	key := utils.REDIS_LIVE_WHEAT + strconv.Itoa(roomId)
	_lockVal, islock := utils.AcquireLock(key, utils.DEFAULT_LOCK_KEY_TIMEOUT, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT)
	if !islock {
		err = ErrWheatLater
		return
	}
	defer utils.ReleaseLock(key, _lockVal)
	// 查询麦位详情
	detail, err := m.QueryWheatDetail(roomId)
	if err != nil {
		return
	}

	// 如果不是主持麦位,麦位未开启禁止操作
	if detail.WheatSwitch == WHEAT_SWITCH_OFF && wheatKey > WHEAT_HOME_KEY {
		err = ErrWheatUnopened
		return
	}

	// 查询用户身份
	role, err := m.QueryUserRole(roomId, userId)
	if err != nil {
		return
	}

	if wheatKey > detail.WheatLen-1 {
		err = ErrWheatDoesNotExist
		return
	}

	if detail.WheatObj[wheatKey].UserId == 0 {
		err = ErrWheatNull
		return
	}
	// 查询麦位上用户权限
	wheatRole, err := m.QueryUserRole(roomId, int64(detail.WheatObj[wheatKey].UserId))
	if err != nil {
		return data, err
	}

	if wheatRole > role && int64(detail.WheatObj[wheatKey].UserId) != userId {
		err = ErrWheatNoAuth
		return data, err
	}

	// 解锁/上锁
	if action == WHEAT_STATUS_UNLOCK {
		detail.WheatObj[wheatKey].Status = WHEAT_STATUS_UNLOCK // 取消禁麦
	} else {
		detail.WheatObj[wheatKey].Status = WHEAT_STATUS_BAN_WHEAT // 禁麦
	}
	detail.WheatObj[wheatKey].UpdateTime = time.Now().Unix()
	err = m.updateWheatObj(key, detail.WheatObj)
	if err != nil {
		return data, err
	}
	data, err = new(Wheat).QueryWheatDetail(roomId)
	if err != nil {
		return data, err
	}
	data.WheatObj = data.WheatObj[:0]                                // 清空
	data.WheatObj = append(data.WheatObj, detail.WheatObj[wheatKey]) // 重新赋值
	return data, err

}

// 获取上麦用户信息
func (m *Wheat) GetUpWheatUserInfo(userId int64, roomId int) (userInfo UserInfo, avatarDressUp string, love int, err error) {
	// 获取用户信息
	userInfo, err = new(UserInfo).GetUserInfo(userId)
	if err != nil {
		return
	}
	// 获取头像框
	avatarDressUp, err = new(IconStyle).Get(userId)
	if err != nil {
		err = ErrWheatGetUserAvatar
		return
	}
	// 获取爱意值
	result, err := utils.RedisClient.HGet(fmt.Sprintf("%s%d", utils.REDIS_LIVE_WHEAT_LOVE, roomId), fmt.Sprintf("%d", userId)).Result()
	if err != nil && err != redis.Nil {
		return
	}
	err = nil
	if result == "" {
		love = 0
	} else {
		love, err = strconv.Atoi(result)
	}
	return
}

// 检查当前用户是否在麦位上
func (m *Wheat) CheckUserWheat(userId int) (isOnWheat bool) {
	for i := 0; i < m.WheatLen; i++ {
		if m.WheatObj[i].UserId == userId {
			isOnWheat = true
			break
		}
	}
	return
}

// 检查当前麦位上是否有人
func (m *Wheat) CheckWheatIsUser(wheatKey int) (isUser bool) {
	if m.WheatObj[wheatKey].UserId != 0 {
		isUser = true
	}
	return
}
