/**
 * @Author: panke
 * @Description:
 * @File: turn_table
 * @Date: 2021/4/22 18:29
 */

package redismodels

import (
	"encoding/json"
	"fmt"
	"gamers/models/dbmodels"
	"gamers/utils"
	"github.com/go-redis/redis"
	wr "github.com/mroth/weightedrand"
)

type TurnTable struct {
	Client        *redis.Client   // redis连接
	TurnTableId   int64           // 转盘id
	TurnTablePool []TurnTablePool // 小蛋池
}

// 小转盘池
type TurnTablePool struct {
	PoolId          int64                 `json:"pool_id"`           // 小奖池id
	PoolWeight      int64                 `json:"pool_weight"`       // 小奖池权重
	PoolRewardTotal int64                 `json:"pool_reward_total"` // 小奖池奖励总数
	RewardList      []TurnTableRewardList `json:"reward_list"`       // 奖励列表
}

// 奖励列表
type TurnTableRewardList struct {
	RewardId    int64  `json:"reward_id"`    // 奖励id
	GiftId      int64  `json:"gift_id"`      // 道具id
	GiftPrice   int64  `json:"gift_price"`   // 道具单价
	RewardName  string `json:"reward_name"`  // 奖励名称
	RewardTotal int64  `json:"reward_total"` // 奖励数量
}

// 抽奖列表
type TurnTableLotteryList struct {
	RewardId   int64  `json:"reward_id"`   // 奖励id
	GiftId     int64  `json:"gift_id"`     // 道具id
	GiftPrice  int64  `json:"gift_price"`  // 道具单价
	RewardName string `json:"reward_name"` // 奖励名称
}

func NewTurnTable() *TurnTable {
	turnTable := TurnTable{
		Client: utils.RedisClient,
	}
	return &turnTable
}

func (m *TurnTable) Init(turnTableId int64) (err error) {
	m.TurnTableId = turnTableId
	turnTableData, err := new(dbmodels.AppTurnTable).QueryByTurnTableId(turnTableId)
	if err != nil {
		return
	}

	// 尽量使用缓存奖池配置
	{
		var data []TurnTablePool
		var key = fmt.Sprintf("%s%d", utils.REDIS_TURNTABLE_POOL_NEXT, turnTableId)
		var val, err = m.Client.Get(key).Result()
		switch err {
		// 使用转盘下次更新
		case nil:
			if mErr := json.Unmarshal([]byte(val), &data); mErr != nil {
				return mErr
			}
			m.TurnTablePool = data
			goto createPool
		case redis.Nil:
			key := fmt.Sprintf("%s%d", utils.REDIS_TURNTABLE_POOL, turnTableId)
			result, err := m.Client.Get(key).Result()
			switch err {
			case nil:
				if mErr := json.Unmarshal([]byte(result), &data); mErr != nil {
					return mErr
				}
				m.TurnTablePool = data
				goto createPool
			case redis.Nil:
				goto useDBConfig
			default:
				return err
			}
		default:
			return err
		}
	}

useDBConfig:
	for _, v := range turnTableData.AppTurnTablePool {
		pool := TurnTablePool{
			PoolId:          int64(v.PoolID),
			PoolWeight:      int64(v.PoolWeight),
			PoolRewardTotal: 0,
		}
		if len(v.AppTurnTableReward) != 0 {
			for _, val := range v.AppTurnTableReward {
				rewardList := TurnTableRewardList{
					RewardId:    int64(val.RewardID),
					GiftId:      int64(val.RewardPropID),
					GiftPrice:   val.AppProp.PropPrice,
					RewardName:  val.AppProp.PropName,
					RewardTotal: int64(val.RewardPropCount),
				}
				pool.PoolRewardTotal = pool.PoolRewardTotal + val.RewardPropCount
				pool.RewardList = append(pool.RewardList, rewardList)
			}
			m.TurnTablePool = append(m.TurnTablePool, pool)
		}
	}

createPool:
	// 打乱顺序
	m.upset()

	// 储存到list
	err = m.saveLotteryList()
	if err != nil {
		return
	}

	// 储存到hash
	err = m.savePoolStatus()
	if err != nil {
		return
	}

	// 储存到redis
	key := fmt.Sprintf("%s%d", utils.REDIS_TURNTABLE_POOL, turnTableId)
	marshal, err := json.Marshal(m.TurnTablePool)
	if err != nil {
		return
	}
	err = m.Client.Set(key, marshal, 0).Err()
	if err != nil {
		return
	}

	// 删除下次更新数据
	key = fmt.Sprintf("%s%d", utils.REDIS_TURNTABLE_POOL_NEXT, turnTableId)
	err = m.Client.Del(key).Err()
	return
}

// 按照权重打乱顺序
func (m *TurnTable) upset() {
	var tmp []TurnTablePool
	// 准备随机数
	choice := []wr.Choice{}
	for _, v := range m.TurnTablePool {
		choice = append(choice, wr.NewChoice(v.PoolId, uint(v.PoolWeight)))
	}

	// 随机结果
	var choiceResult []int64
	for i := 0; i < len(m.TurnTablePool); i++ {
		chooser, _ := wr.NewChooser(choice...)
		fruit := chooser.Pick().(int64)
		// 减少参与随机的数量
		for k, v := range choice {
			if fruit == v.Item.(int64) {
				choice = append(choice[:k], choice[k+1:]...)
			}
		}
		choiceResult = append(choiceResult, fruit)
	}
	// 匹配顺序
	for _, v := range choiceResult {
		for _, val := range m.TurnTablePool {
			if v == val.PoolId {
				tmp = append(tmp, val)
			}
		}
	}
	m.TurnTablePool = m.TurnTablePool[:0]
	m.TurnTablePool = tmp
}

// 储存抽奖列表
func (m *TurnTable) saveLotteryList() (err error) {
	listKey := fmt.Sprintf("%s%d", utils.REDIS_TURNTABLE_POOL_LOTTERY_LIST, m.TurnTableId)
	// 删除之前的
	err = m.Client.Del(listKey).Err()
	for _, v := range m.TurnTablePool {
		// 奖励列表
		var lotteryList []interface{}
		for _, val := range v.RewardList {
			for i := 0; i < int(val.RewardTotal); i++ {
				lotteryList = append(lotteryList, LotteryList{
					RewardId:   val.RewardId,
					GiftId:     val.GiftId,
					GiftPrice:  val.GiftPrice,
					RewardName: val.RewardName,
				})
			}
		}
		// 打乱顺序
		utils.FuncShuffle(lotteryList)

		// 待插入数据
		var lPush []string
		for _, list := range lotteryList {
			l := list.(LotteryList)
			// 拼接格式  小蛋池id:奖励id:礼物id:礼物价格
			value := fmt.Sprintf("%d:%d:%d:%d", v.PoolId, l.RewardId, l.GiftId, l.GiftPrice)
			lPush = append(lPush, value)
		}
		if len(lPush) != 0 {
			err = m.Client.LPush(listKey, lPush).Err()
			if err != nil {
				return err
			}
		}

	}
	return
}

// 储存奖池状态
func (m *TurnTable) savePoolStatus() (err error) {
	key := fmt.Sprintf("%s%d", utils.REDIS_TURNTABLE_POOL_STATUS, m.TurnTableId)
	m.Client.Del(key)
	for _, v := range m.TurnTablePool {
		for _, val := range v.RewardList {
			// 拼接格式  小蛋池id:奖励id:礼物id:礼物价格
			hashKey := fmt.Sprintf("%d:%d:%d:%d", v.PoolId, val.RewardId, val.GiftId, val.GiftPrice)
			err = m.Client.HSet(key, hashKey, val.RewardTotal).Err()
			if err != nil {
				return err
			}
		}
	}
	return
}
