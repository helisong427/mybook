package redismodels

import (
	"encoding/json"
	"gamers/utils/tencent/tencentIm"
	"time"

	jsoniter "github.com/json-iterator/go"
)

type OrderUserInfo struct {
	UserId   int64  `json:"user_id" gorm:"column:user_id"`
	Icon     string `json:"icon" gorm:"column:user_iconurl"`      // 用户头像
	Nickname string `json:"nickname" gorm:"column:user_nickname"` // 昵称
}

// 订单msg
type SkillOrderMsg struct {
	Tips                 string         `json:"tips"`                                                          // 提示
	OrderId              int64          `json:"order_id"`                                                      // 订单id
	Remark               string         `json:"remark"`                                                        // 备注
	OrderSparringSkillId int64          `gorm:"column:order_sparring_skill_id" json:"order_sparring_skill_id"` // 大神基恩那个id
	OrderStatus          int            `json:"order_status"`                                                  // 订单状态(0待接单,1已接单,2已取消,3买家确认完成,4卖家确认完成
	OrderConfirmStatus   int            `gorm:"column:order_confirm_status" json:"order_confirm_status"`       // 接单状态(0待接单,1大神拒绝,2大神结单,3大神完成)
	OrderCancelStatus    int            `gorm:"column:order_cancel_status" json:"order_cancel_status"`         // 取消状态(0未取消,1玩家取消,2大神取消,3系统取消)
	BuyerInfo            OrderUserInfo  `json:"buyer_info" gorm:"foreignKey:UserId;references:OrderBuyUserId"`
	SkillInfo            OrderSkillInfo `json:"skill_info" gorm:"foreignKey:SkillId;references:OrderSkillId"`
	OrderPrice           int64          `json:"order_price"`                         // 单价
	OrderWay             string         `json:"order_way"`                           // 订单单位
	OrderCount           int64          `json:"order_count"`                         // 订单购买数量
	OrderAmount          int64          `json:"order_amount"`                        // 收入
	OrderTime            int64          `gorm:"column:order_time" json:"order_time"` // 陪玩方式   时长  单位秒
	Countdown            int64          `json:"countdown" gorm:"-"`                  // 倒计时
	Created              int64          `json:"created"`                             // 订单生成时间
	NotificationClose    int            `json:"notification_close"`                  // 是否关闭通知栏消息
}

// 技能详情
type OrderSkillInfo struct {
	SkillId int64  `json:"skill_id"`
	Name    string `json:"name" gorm:"column:skill_name"`
	Icon    string `json:"icon"`
}

// gogo消息
type AssistantMsg struct {
	Type              int                    `json:"type"`               // 类型：0.纯文本，1.带标题的文本，2.标题+文本+事件，3.标题+文本+图片+事件
	ActionType        int                    `json:"action_type"`        // 0.url，1.直播间
	ActionParams      map[string]interface{} `json:"action_params"`      // 跳转详情
	Title             string                 `json:"title"`              // 标题
	Text              string                 `json:"text"`               // 文本
	Action            string                 `json:"action"`             // 事件内容
	Image             string                 `json:"image"`              // 图片
	NotificationClose int                    `json:"notification_close"` // 是否关闭通知栏消息
}

type ActionParam struct {
	Key   string      `json:"key"`
	Value interface{} `json:"value"`
}

// 互动消息
type InteractiveMsg struct {
	Tips              string `json:"tips"`
	Title             string `json:"title"`              // 标题
	Text              string `json:"text"`               // 文本
	NotificationClose int    `json:"notification_close"` // 是否关闭通知栏消息
}

// 跳转样式
type ActionStyle struct {
	Start int    `json:"start"`
	End   int    `json:"end"`
	Color string `json:"color"`
}

// 私聊消息类型
type C2CMsg struct {
	Type              int                    `json:"type"`               // 类型：0.纯文本，1.带标题的文本，2.标题+文本+事件，3.标题+文本+图片+事件 4.tips
	ActionType        int                    `json:"action_type"`        // 0.url，1.订单详情,2.关注
	ActionStyle       ActionStyle            `json:"action_style"`       // 跳转类型
	ServiceType       int                    `json:"service_type"`       // 0.订单，1.关注,2.点赞
	Title             string                 `json:"title"`              // 标题
	Text              string                 `json:"text"`               // 文本
	Action            string                 `json:"action"`             // 事件内容
	ActionParams      map[string]interface{} `json:"action_params"`      // 跳转详情
	Image             string                 `json:"image"`              // 图片
	OrderInfo         *C2cOrderInfo          `json:"order_info"`         // 订单信息
	NotificationClose int                    `json:"notification_close"` // 是否关闭通知栏消息
}

type C2cOrderInfo struct {
	OrderId              int64          `json:"order_id"`                                                      // 订单id
	OrderSparringSkillId int64          `gorm:"column:order_sparring_skill_id" json:"order_sparring_skill_id"` // 大神基恩那个id
	OrderStatus          int            `json:"order_status"`                                                  // 订单状态(0待接单,1已接单,2已取消,3买家确认完成,4卖家确认完成
	OrderPayStatus       int            `gorm:"column:order_pay_status" json:"order_pay_status"`               // 支付状态(0待付款,1付款中,2已付款)
	OrderConfirmStatus   int            `gorm:"column:order_confirm_status" json:"order_confirm_status"`       // 接单状态(0待接单,1大神拒绝,2大神结单,3大神完成)
	OrderCancelStatus    int            `gorm:"column:order_cancel_status" json:"order_cancel_status"`
	OrderRefundStatus    int            `json:"order_refund_status"`                                     // 退款状态
	OrderAppealStatus    int            `json:"order_appeal_status"`                                     // 申诉状态(0未申诉,1申诉中,2待处理,3处理完成)
	OrderFinishStatus    int            `gorm:"column:order_finish_status" json:"order_finish_status"`   // 完成状态(0未完成,1系统自动完成,3玩家完成)
	OrderCommentStatus   int            `gorm:"column:order_comment_status" json:"order_comment_status"` // 评价状态(0待评价,1玩家已评价,2大神已评价)
	OrderSettleStatus    int            `gorm:"column:order_settle_status" json:"order_settle_status"`   // 订单结算(提取)状态(0未结算,1系统自动已结算,2客服结算)
	OrderBuyUserId       int64          `gorm:"column:order_buy_user_id" json:"order_buy_user_id"`       // 购买用户id
	OrderSellUserId      int64          `gorm:"column:order_sell_user_id" json:"order_sell_user_id"`     // 出售订单用户id
	OrderSkillId         int64          `gorm:"column:order_skill_id" json:"order_skill_id"`             // 购买的技能id
	OrderRefundCount     int            `gorm:"column:order_refund_count" json:"order_refund_count"`     // 退款申请次数
	SkillInfo            OrderSkillInfo `json:"skill_info" gorm:"foreignKey:SkillId;references:OrderSkillId"`
	OrderPrice           int64          `json:"order_price"`        // 单价
	OrderWay             string         `json:"order_way"`          // 订单单位
	OrderCount           int64          `json:"order_count"`        // 订单购买数量
	OrderAmount          int64          `json:"order_amount"`       // 收入
	Countdown            int64          `json:"countdown" gorm:"-"` // 倒计时
	Created              int64          `json:"created"`            // 订单生成时间
}

// 匹配完成消息
type MatchingMsg struct {
	MatchingType        int                  `json:"matching_type"` // 类型：0-用户下单,1-大神接单,2-取消订单
	MatchingUserMsg     *MatchingUserMsg     `json:"matching_user_msg"`
	MatchingSparringMsg *MatchingSparringMsg `json:"matching_sparring_msg"`
}

// 匹配用户消息
type MatchingUserMsg struct {
	UserGender int    `json:"user_gender"` // 性别
	Count      int64  `json:"count"`       // 单数
	SkillName  string `json:"skill_name"`  // 游戏名称
	SkillPrice int64  `json:"skill_price"` // 价格
	SkillWay   string `json:"skill_way"`   // 单位
}

// 匹配大神消息
type MatchingSparringMsg struct {
	UserId        int64     `json:"user_id"`        // 用户id
	Avatar        string    `json:"avatar"`         // 大神头像
	NickName      string    `json:"nick_name"`      // 昵称
	Level         string    `json:"level"`          // 大神等级
	Feature       []Feature `json:"feature"`        // 特色
	SkillIcon     string    `json:"skill_icon"`     // 技能icon
	SkillName     string    `json:"skill_name"`     // 技能名称
	SoundUrl      string    `json:"sound_url"`      // 语音url
	SoundTime     int64     `json:"sound_time"`     // 语音时长
	ServiceNumber int64     `json:"service_number"` // 服务人次
	FavorableRate int64     `json:"favorable_rate"` // 好评率
	Introduction  string    `json:"introduction"`   // 简介
	Gender        int       `json:"gender"`         // 性别
	Age           int       `json:"age"`            // 年龄
}

// 主动推荐
type ActivePush struct {
	ActivePushUserInfo *ActivePushUserInfo `json:"active_push_user_info"`
	MsgContent         string              `json:"msg_content"` // 消息内容
}

// 主动推荐用户信息
type ActivePushUserInfo struct {
	UserId   int64  `json:"user_id"`   // 用户id
	Avatar   string `json:"avatar"`    // 用户头像
	NickName string `json:"nick_name"` // 昵称
	Gender   int    `json:"gender"`    // 性别
	Age      int    `json:"age"`       // 年龄
}

type Feature struct {
	FeatureName   string   `json:"feature_name"`   // 特色名称
	FeatureValues []string `json:"feature_values"` // 特色内容
}

// 主消息结构
type AppMsg struct {
	Type              int             `json:"type"`
	OrderMsg          *SkillOrderMsg  `json:"order_msg"`          // 订单消息
	AssistantMsg      *AssistantMsg   `json:"assistant_msg"`      // 系统消息,gogo助手
	InteractiveMsg    *InteractiveMsg `json:"interactive_msg"`    // 互动消息
	LiveMsg           *LiveMsg        `json:"live_msg"`           // 直播间消息
	C2CMsg            *C2CMsg         `json:"c2c_msg"`            // 私聊消息
	HeadlineMsg       *HeadlineMsg    `json:"headline_msg"`       // 跑马灯消息
	MatchingMsg       *MatchingMsg    `json:"matching_msg"`       // 匹配消息
	ActivePush        *ActivePush     `json:"active_push"`        // 主动推荐
	NotificationClose int             `json:"notification_close"` // 是否关闭通知栏消息,1为关闭
	CreateT           int64           `json:"create_t"`           // 消息创建的时间，单位精确到秒
}

func (s *AppMsg) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s AppMsg) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

// 消息类型
const (
	MSG_EXT_TYPE_ORDER          = iota // 订单
	MSG_EXT_TYPE_ASSISTANT             // gogo助手
	MSG_EXT_TYPE_INTERACTIVEMSG        // 互动消息
	MSG_EXT_TYPE_LIVE                  // 直播消息
	MSG_EXT_TYPE_C2C                   // 私聊消息
	MSG_EXT_TYPE_HEADLINE              // 跑马灯
	MSG_EXT_TYPE_MATCHING              // 匹配消息
	MSG_EXT_TYPE_ACTIVE_PUSH           // 主动推送
)

// 管理员账号
const (
	MSG_ADMIN_USER_ORDER          = "sys_order"       // 订单消息
	MSG_ADMIN_USER_ASSISTANT      = "sys_assistant"   // 小助手消息
	MSG_ADMIN_USER_INTERACTIVEMSG = "sys_interactive" // 互动消息
	MSG_ADMIN_USER_HEADLINE       = "sys_headline"    // 互动消息
	MSG_ADMIN_USER_SUPERMASTER    = "supermaster"     // 超级管理员
)

const (
	MSG_INTERACTIVE_TYPE_COMMENT = iota // 评论
	MSG_INTERACTIVE_TYPE_LIKE           // 点赞
)

const (
	MSG_ASSISTANT_TYPE_TEXT        = iota // 纯文本
	MSG_ASSISTANT_TYPE_TITLE              // 文本+标题
	MSG_ASSISTANT_TYPE_ACTION             // 文本+标题+事件
	MSG_ASSISTANT_TYPE_IMG                // 文本+标题+图片+事件
	MSG_ASSISTANT_TYPE_TIPS               // 提示
	MSG_ASSISTANT_TYPE_TIPS_ACTION        // 提示+事件
	MSG_ASSISTANT_TYPE_COMMENT            // 订单评价
)

// 消息跳转
const (
	MSG_ACTION_TYPE_URL                 = iota // URL跳转
	MSG_ACTION_TYPE_USER_ORDER_INFO            // 用户订单详情
	MSG_ACTION_TYPE_ORDER_APPEAL               // 订单申诉
	MSG_ACTION_TYPE_ATTENTION                  // 关注
	MSG_ACTION_TYPE_SPARRING_ORDER_INFO        // 大神订单详情
	MSG_ACTION_TYPE_LIVR_ROOM                  // 房间
	MSG_ACTION_TYPE_INDEX_SKILL                // 首页游戏技能信息
	MSG_ACTION_TYPE_RECHARGE                   // 充值
	MSG_ACTION_TYPE_BACKGROUND_HOT             // 广场热门
	MSG_ACTION_TYPE_DRESS_SHOPPING             // 装扮商城
	MSG_ACTION_TYPE_TASK_CENTER                // 任务中心
	MSG_ACTION_TYPE_TWEET_INFO                 // 动态详情
	MSG_ACTION_TYPE_TWEET_CREATE               // 动态发布
	MSG_ACTION_TYPE_USER_INDEX                 // 用户主页
	MSG_ACTION_TYPE_SPARRING_APPLY             // 大神申请
	MSG_ACTION_TYPE_ANCHOR_APPLY               // 主播申请
	MSG_ACTION_TYPE_HOMERANDOMROOM             // 首页推荐房间
	MSG_ACTION_TYPE_LIAOYILIAO                 // 撩一撩
	MSG_ACTION_TYPE_COMMENT                    // 评论
	MSG_ACTION_TYPE_SPEED_MATCHING             // 极速匹配
	MSG_ACTION_TYPE_PK_RESULT                  // PK结果
)
const (
	MSG_PLACEHOLDER_SENDNAME    = "${from_account_name}" // 消息发送者
	MSG_PLACEHOLDER_OBJ_NAME    = "${cmd_obj_name}"      // cmd对象，只渲染一个
	MSG_PLACEHOLDER_OBJ_NAMES   = "${cmd_obj_names}"     // cmd对象，渲染多个
	MSG_PLACEHOLDER_PROP_NAME   = "${prop_name}"         // 道具名字
	MSG_PLACEHOLDER_PROP_NUM    = "${prop_num}"          // 道具数量
	MSG_PLACEHOLDER_DURATION    = "${cmd_duration}"      // 指令时长
	MSG_PLACEHOLDER_ANCHOR_NAME = "${anchor_name}"       // 指令时长
)

const (
	// 匹配消息类型
	MSG_MATCHING_USER     = iota // 用户下单
	MSG_MATCHING_SPARRING        // 大神接单
	MSG_MATCHING_CANCEL          // 取消订单
)

// 序列化消息
func (s AppMsg) MarshalToString() string {
	data, _ := jsoniter.Marshal(s)
	return string(data)
}

// 发送互动消息
func (m InteractiveMsg) SendInteractiveMsg(from string, target string) (err error) {
	msg := AppMsg{
		CreateT:           time.Now().Unix(),
		InteractiveMsg:    &m,
		Type:              MSG_EXT_TYPE_INTERACTIVEMSG,
		NotificationClose: m.NotificationClose,
	}
	cusMsg := tencentIm.TIMCustomElem{Data: msg.MarshalToString(), Ext: m.Tips, Desc: m.Tips}
	// 处理屏蔽
	err = tencentIm.SendCusMsg(from, target, cusMsg)
	return
}

// 发送私聊消息
func (m C2CMsg) SendC2CMsg(from, target string) (err error) {
	msg := AppMsg{
		CreateT:           time.Now().Unix(),
		C2CMsg:            &m,
		Type:              MSG_EXT_TYPE_C2C,
		NotificationClose: m.NotificationClose,
	}
	cusMsg := tencentIm.TIMCustomElem{Data: msg.MarshalToString(), Desc: m.Text}
	err = tencentIm.SendCusMsg(from, target, cusMsg)
	return
}

// 发送助手消息
func (m AssistantMsg) SendAssistantMsg(from, target string) (err error) {
	msg := AppMsg{
		CreateT:           time.Now().Unix(),
		AssistantMsg:      &m,
		Type:              MSG_EXT_TYPE_ASSISTANT,
		NotificationClose: m.NotificationClose,
	}
	cusMsg := tencentIm.TIMCustomElem{Data: msg.MarshalToString(), Ext: m.Text, Desc: m.Text}
	err = tencentIm.SendCusMsg(from, target, cusMsg)
	return
}

// 批量发送助手消息
func (m AssistantMsg) BatchSendAssistantMsg(userIds []string, from string) (err error) {
	msg := AppMsg{
		CreateT:           time.Now().Unix(),
		AssistantMsg:      &m,
		Type:              MSG_EXT_TYPE_ASSISTANT,
		NotificationClose: m.NotificationClose,
	}
	cusMsg := tencentIm.TIMCustomElem{Data: msg.MarshalToString(), Ext: m.Text, Desc: m.Text}
	err = tencentIm.BatchSendMsg(userIds, from, cusMsg)
	return
}

// 按标签推送助手消息
func (m AssistantMsg) PushAssistantMsg(from, target string) (err error) {
	msg := AppMsg{
		CreateT:           time.Now().Unix(),
		AssistantMsg:      &m,
		Type:              MSG_EXT_TYPE_ASSISTANT,
		NotificationClose: m.NotificationClose,
	}
	cusMsg := tencentIm.TIMCustomElem{Data: msg.MarshalToString(), Ext: m.Text, Desc: m.Text}
	err = tencentIm.SendNotificationByTag(from, target, cusMsg)
	return
}

// 发送订单消息
func (m SkillOrderMsg) SendOrderMsg(from, target string) (err error) {
	msg := AppMsg{
		CreateT:           time.Now().Unix(),
		OrderMsg:          &m,
		Type:              MSG_EXT_TYPE_ORDER,
		NotificationClose: m.NotificationClose,
	}
	cusMsg := tencentIm.TIMCustomElem{Data: msg.MarshalToString(), Ext: m.Tips, Desc: m.Tips}
	err = tencentIm.SendCusMsg(from, target, cusMsg)
	return
}

// 发送群聊消息
func (m LiveMsg) SendLiveMsg(target string) (err error) {
	m.MsgSource = MSG_SOURCE_SERVICE
	msg := AppMsg{
		CreateT: time.Now().Unix(),
		LiveMsg: &m,
		Type:    MSG_EXT_TYPE_LIVE,
	}
	cusMsg := tencentIm.SendGroupSystemNotificationRequest{Content: msg.MarshalToString(), GroupId: target}
	err = tencentIm.SendGroupSystemNotification(target, cusMsg)
	return
}

// 发送群聊消息
func (m HeadlineMsg) SendGroupHeadMsg(target string) (err error) {
	msg := AppMsg{
		CreateT:     time.Now().Unix(),
		HeadlineMsg: &m,
		Type:        MSG_EXT_TYPE_HEADLINE,
	}
	cusMsg := tencentIm.SendGroupSystemNotificationRequest{Content: msg.MarshalToString(), GroupId: target}
	err = tencentIm.SendGroupSystemNotification(target, cusMsg)
	return
}

// push全局推送
func (m HeadlineMsg) SendAllHeadMsg() (err error) {
	msg := AppMsg{
		CreateT:     time.Now().Unix(),
		HeadlineMsg: &m,
		Type:        MSG_EXT_TYPE_HEADLINE,
	}
	cusMsg := tencentIm.TIMCustomElem{Data: msg.MarshalToString()}
	err = tencentIm.SendSystemNotification(MSG_ADMIN_USER_HEADLINE, cusMsg)
	return
}

// 发送匹配消息
func (m *MatchingMsg) SendMatchingMsg(from string, target string) (err error) {
	msg := AppMsg{
		CreateT:           time.Now().Unix(),
		MatchingMsg:       m,
		Type:              MSG_EXT_TYPE_MATCHING,
		NotificationClose: 1,
	}
	cusMsg := tencentIm.TIMCustomElem{Data: msg.MarshalToString()}
	err = tencentIm.SendCusMsgWithoutOffline(from, target, cusMsg)
	return
}

// 批量发送匹配消息
func (m *MatchingMsg) BatchSendMatchingMsg(userIds []string, from string) (err error) {
	msg := AppMsg{
		CreateT:           time.Now().Unix(),
		MatchingMsg:       m,
		Type:              MSG_EXT_TYPE_MATCHING,
		NotificationClose: 1,
	}
	cusMsg := tencentIm.TIMCustomElem{Data: msg.MarshalToString()}
	err = tencentIm.BatchSendMsgWithoutOffline(userIds, from, cusMsg)
	return
}

// 主动推送消息
func (m *ActivePush) SendActivePush(from string, target []string) (err error) {
	msg := AppMsg{
		Type:              MSG_EXT_TYPE_ACTIVE_PUSH,
		ActivePush:        m,
		NotificationClose: 1,
		CreateT:           time.Now().Unix(),
	}
	cusMsg := tencentIm.TIMCustomElem{Data: msg.MarshalToString()}
	err = tencentIm.BatchSendMsgWithoutOffline(target, from, cusMsg)
	return
}
