package redismodels

import (
	"fmt"
	"gamers/utils"

	"github.com/fatih/structs"
	"github.com/go-redis/redis"
)

const (
	ROOM_COMMENT_MAX int64 = 5 //每次最多获取的长度
)

//房间推荐
//上次推荐的有序集合的起始位置
type RoomCommentUserZAddPosition struct {
	Start int64 `redis:"Start"` //开始位置
	End   int64 `redis:"End"`   //结束位置
}

func (m *RoomCommentUserZAddPosition) Get(userId int64) (ids []string, err error) {
	var start, end int64
	start = 0
	end = ROOM_COMMENT_MAX - 1
	key := fmt.Sprintf("%s%d", utils.REDIS_INDEX_ROOM_COMMENT, userId)
	redisClient := utils.RedisClient
	//查询用户推荐记录
	userH, err := redisClient.HGetAll(key).Result()
	if err != nil && err != redis.Nil {
		return
	}

	//如果用户有查询推荐记录
	if len(userH) > 0 {
		err = utils.HashToStruct(userH, m)
		if err != nil {
			return
		}
		start = m.Start
		end = m.End
	}

	//获取房间魅力值集合长度
	charmCount, err := redisClient.ZCard(utils.REDIS_INDEX_ROOM_CHARM).Result()
	if err != nil {
		return
	}
	if charmCount == 0 {
		return
	}

	if len(userH) > 0 {
		start = end + 1
		end = end + ROOM_COMMENT_MAX
		//如果长度超出索引，重置
		if start > charmCount-1 || end > charmCount-1 {
			start = 0
			end = ROOM_COMMENT_MAX - 1
		}
	}

	//储存本次的数据
	tmp := RoomCommentUserZAddPosition{
		Start: start,
		End:   end,
	}
	err = redisClient.HMSet(key, structs.Map(tmp)).Err()
	if err != nil {
		return
	}

	//获取房间魅力值集合
	charmZSet, err := redisClient.ZRevRangeWithScores(utils.REDIS_INDEX_ROOM_CHARM, start, end).Result()
	if err != nil {
		return
	}
	for _, v := range charmZSet {
		if v.Member.(string) == "0" {
			continue
		}
		ids = append(ids, v.Member.(string))
	}
	return
}
