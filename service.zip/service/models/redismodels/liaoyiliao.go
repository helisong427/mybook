/**
 * @Author: panke
 * @Description: 撩一撩主动推送
 * @File: liaoyiliao
 * @Date: 2021/5/18 14:25
 */

package redismodels

// 撩一撩主动推送配置
type LiaoYiLiaoActivePush struct {
	UserLoginLimit       int `json:"user_login_limit"`       // 用户登录次数限制
	SparringCount        int `json:"sparring_count"`         // 大神推荐数量
	CDTime               int `json:"cd_time"`                // 推送给用户间隔时间
	SparringReceiveCount int `json:"sparring_receive_count"` // 大神收到推荐次数
}

const (
	UserLoginLimit       = "user_login_limit"
	SparringCount        = "sparring_count"
	CDTime               = "cd_time"
	SparringReceiveCount = "sparring_receive_count"
)
