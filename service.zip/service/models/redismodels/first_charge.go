package redismodels

import (
	"encoding/json"
	"gamers/models/dbmodels"
	"gamers/utils"
	"github.com/go-redis/redis"
)

//首充缓存
type FirstCharge struct {
	PropId    int64  `json:"prop_id"`    //礼物id
	PropName  string `json:"prop_name"`  //礼物名称
	PropType  int    `json:"prop_type"`  //礼物类型
	PropIcon  string `json:"prop_icon"`  //礼物icon
	PropCount int64  `json:"prop_count"` //礼物数量
}

func (m *FirstCharge) Get() (data []FirstCharge, err error) {
	key := utils.REDIS_FIRST_CHARGE
	client := utils.RedisClient
	//获取缓存
	result, err := client.Get(key).Result()
	if err != nil && err != redis.Nil {
		return data, err
	}
	err = nil
	if result == "" {
		all, err := new(dbmodels.AppFirstCharge).QueryAll()
		if err != nil {
			return data, err
		}
		for _, v := range all {
			data = append(data, FirstCharge{
				PropId:    v.AppProp.PropId,
				PropName:  v.AppProp.PropName,
				PropType:  v.AppProp.PropType,
				PropIcon:  v.AppProp.PropIcon,
				PropCount: v.ChargePropCount,
			})
		}
		marshal, err := json.Marshal(data)
		if err != nil {
			return data, err
		}
		err = client.Set(key, marshal, -1).Err()
	} else {
		err = json.Unmarshal([]byte(result), &data)
	}
	return data, nil
}
