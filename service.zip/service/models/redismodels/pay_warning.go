package redismodels

import (
	"fmt"
	"gamers/utils"
	"time"
)

const (
	SMS_SEND_NO  = iota // 短信未发送
	SMS_SEND_YES        // 短信已发送
)

// PayWarning 支付预警短信是否已经发送，设置 48 小时过期。
type PayWarning struct {
	UserID int64 `redis:"UserID"` // 用户id
}

// SaveSendState 保存用户短信发送状态
func (p PayWarning) SaveSendState(key string, state int, exp time.Duration) (err error) {
	keys := fmt.Sprintf("%s%d", key, p.UserID)
	return utils.RedisClient.Set(keys, state, exp).Err()
}

// GetSendState 获取用户发送状态
func (p PayWarning) GetSendState(key string) (int, error) {
	keys := fmt.Sprintf("%s%d", key, p.UserID)
	return utils.RedisClient.Get(keys).Int()
}
