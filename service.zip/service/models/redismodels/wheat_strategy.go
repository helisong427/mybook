package redismodels

import (
	"gamers/mq/rabbitmqProducer"
	"gamers/utils"
	"strconv"
	"time"
)

// 麦位策略模式
type wheatStrategy interface {
	// detail 麦位详情
	// roomId 房间id
	// userId 用户id
	// wheatKey 麦位Key
	up(detail Wheat, roomId int, userId int64, wheatKey int) (data Wheat, err error)
	down(detail Wheat, roomId int, userId int64, wheatKey int) (data Wheat, err error)
}

// 普通用户
type wheatUser struct{}

// 管理员
type wheatAdmin struct{}

// 副管理员
type wheatDeputyAdmin struct{}

// 主播
type wheatAnchor struct{}

type WheatContext struct {
	Strategy wheatStrategy
}

func newWheatContext(role int) WheatContext {
	c := new(WheatContext)
	switch role {
	case WHEAT_ROLE_USER:
		c.Strategy = newWheatUser()
	case WHEAT_ROLE_DEPUTY_ADMIN:
		c.Strategy = newWheatDeputyAdmin()
	case WHEAT_ROLE_ADMIN:
		c.Strategy = newWheatAdmin()
	default:
		c.Strategy = newWheatAnchor()
	}
	return *c
}

func (w WheatContext) up(detail Wheat, roomId int, userId int64, wheatKey int) (data Wheat, err error) {
	// 通用判断
	if err = wheatComm(detail, wheatKey); err != nil {
		return
	}
	if wheatKey > len(detail.WheatObj) {
		err = ErrWheatDoesNotExist
		return
	}
	if detail.WheatObj[wheatKey].UserId != 0 {
		err = ErrWheatIsAlreadyOccupied
		return
	}
	// 如果麦位锁定状态，解锁
	if detail.WheatObj[wheatKey].Status == WHEAT_STATUS_LOCK {
		detail.WheatObj[wheatKey].Status = WHEAT_STATUS_UNLOCK
		key := utils.REDIS_LIVE_WHEAT + strconv.Itoa(roomId)
		err = detail.updateWheatObj(key, detail.WheatObj)
		if err != nil {
			return
		}
	}
	return w.Strategy.up(detail, roomId, userId, wheatKey)
}

func (w WheatContext) down(detail Wheat, roomId int, userId int64, wheatKey int) (data Wheat, err error) {
	// 通用判断
	if err = wheatComm(detail, wheatKey); err != nil {
		return
	}
	// return w.Strategy.down(detail, roomId, userId, wheatKey)

	if detail.WheatObj[wheatKey].UserId != int(userId) {
		err = ErrWheatNotYours
	}

	// 主持麦位下麦时，投递延迟关闭房间消息队列
	if wheatKey == WHEAT_HOME_KEY {
		go rabbitmqProducer.ProducerCloseRoom(roomId)
	}

	// 清空麦位
	detail.WheatObj[wheatKey].UserId = 0
	detail.WheatObj[wheatKey].UserNickName = ""
	detail.WheatObj[wheatKey].UserIconurl = ""
	detail.WheatObj[wheatKey].UserGender = 0
	detail.WheatObj[wheatKey].UserAvatarDressUp = ""
	detail.WheatObj[wheatKey].Role = WHEAT_ROLE_USER
	detail.WheatObj[wheatKey].LoveValue = 0
	detail.WheatObj[wheatKey].Status = WHEAT_STATUS_UNLOCK
	detail.WheatObj[wheatKey].UpdateTime = time.Now().Unix()
	return wheatUpdateWheat(detail, roomId, -1, wheatKey)
}

// 实例化普通用户
func newWheatUser() wheatUser {
	return *new(wheatUser)
}

func (w wheatUser) up(detail Wheat, roomId int, userId int64, wheatKey int) (data Wheat, err error) {
	if wheatKey == WHEAT_HOME_KEY {
		err = ErrWheatNoAnchorWheat
		return
	}
	if detail.WheatObj[wheatKey].Status == WHEAT_STATUS_LOCK {
		err = ErrWheatPositionLocked
		return
	}
	occupyKey, occupyLoveValue, occupyStatus := wheatOccupyKey(detail, userId)
	userInfo, avatarDressUp, love, err := detail.GetUpWheatUserInfo(userId, roomId)
	if err != nil {
		return
	}
	if occupyLoveValue == 0 {
		occupyLoveValue = love
	}

	// 主持麦位下麦时，投递延迟关闭房间消息队列
	if occupyKey == WHEAT_HOME_KEY {
		go rabbitmqProducer.ProducerCloseRoom(roomId)
	}

	// 设置麦位
	detail.WheatObj[wheatKey].UserId = int(userId)
	detail.WheatObj[wheatKey].UserNickName = userInfo.UserNickname
	detail.WheatObj[wheatKey].UserIconurl = userInfo.UserIconurl
	detail.WheatObj[wheatKey].UserGender = userInfo.UserGender
	detail.WheatObj[wheatKey].UserAvatarDressUp = avatarDressUp
	detail.WheatObj[wheatKey].Role = WHEAT_ROLE_USER
	// 上麦之前麦位状态处理
	err = upWheatStatusBeforeHandler(&detail.WheatObj[wheatKey], occupyKey, occupyStatus, roomId)
	if err != nil {
		return
	}
	detail.WheatObj[wheatKey].LoveValue = occupyLoveValue
	detail.WheatObj[wheatKey].UpdateTime = time.Now().Unix()
	return wheatUpdateWheat(detail, roomId, occupyKey, wheatKey)
}

func (w wheatUser) down(detail Wheat, roomId int, userId int64, wheatKey int) (data Wheat, err error) {
	return
}

// 实例化管理员
func newWheatAdmin() wheatAdmin {
	return *new(wheatAdmin)
}

func (w wheatAdmin) up(detail Wheat, roomId int, userId int64, wheatKey int) (data Wheat, err error) {
	occupyKey, occupyLoveValue, occupyStatus := wheatOccupyKey(detail, userId)
	userInfo, avatarDressUp, love, err := detail.GetUpWheatUserInfo(userId, roomId)
	if err != nil {
		return
	}
	if occupyLoveValue == 0 {
		occupyLoveValue = love
	}

	// 主持麦位下麦时，投递延迟关闭房间消息队列
	if occupyKey == WHEAT_HOME_KEY {
		go rabbitmqProducer.ProducerCloseRoom(roomId)
	}

	// 设置麦位
	detail.WheatObj[wheatKey].UserId = int(userId)
	detail.WheatObj[wheatKey].UserNickName = userInfo.UserNickname
	detail.WheatObj[wheatKey].UserIconurl = userInfo.UserIconurl
	detail.WheatObj[wheatKey].UserGender = userInfo.UserGender
	detail.WheatObj[wheatKey].UserAvatarDressUp = avatarDressUp
	detail.WheatObj[wheatKey].Role = WHEAT_ROLE_ADMIN
	// 上麦之前麦位状态处理
	err = upWheatStatusBeforeHandler(&detail.WheatObj[wheatKey], occupyKey, occupyStatus, roomId)
	if err != nil {
		return
	}
	detail.WheatObj[wheatKey].LoveValue = occupyLoveValue
	detail.WheatObj[wheatKey].UpdateTime = time.Now().Unix()
	return wheatUpdateWheat(detail, roomId, occupyKey, wheatKey)
}

func (w wheatAdmin) down(detail Wheat, roomId int, userId int64, wheatKey int) (data Wheat, err error) {
	return
}

// 实例化副管理员
func newWheatDeputyAdmin() wheatDeputyAdmin {
	return *new(wheatDeputyAdmin)
}

func (w wheatDeputyAdmin) up(detail Wheat, roomId int, userId int64, wheatKey int) (data Wheat, err error) {
	occupyKey, occupyLoveValue, occupyStatus := wheatOccupyKey(detail, userId)
	userInfo, avatarDressUp, love, err := detail.GetUpWheatUserInfo(userId, roomId)
	if err != nil {
		return
	}
	if occupyLoveValue == 0 {
		occupyLoveValue = love
	}

	// 主持麦位下麦时，投递延迟关闭房间消息队列
	if occupyKey == WHEAT_HOME_KEY {
		go rabbitmqProducer.ProducerCloseRoom(roomId)
	}

	// 设置麦位
	detail.WheatObj[wheatKey].UserId = int(userId)
	detail.WheatObj[wheatKey].UserNickName = userInfo.UserNickname
	detail.WheatObj[wheatKey].UserIconurl = userInfo.UserIconurl
	detail.WheatObj[wheatKey].UserGender = userInfo.UserGender
	detail.WheatObj[wheatKey].UserAvatarDressUp = avatarDressUp
	detail.WheatObj[wheatKey].Role = WHEAT_ROLE_DEPUTY_ADMIN
	// 上麦之前麦位状态处理
	err = upWheatStatusBeforeHandler(&detail.WheatObj[wheatKey], occupyKey, occupyStatus, roomId)
	if err != nil {
		return
	}
	detail.WheatObj[wheatKey].LoveValue = occupyLoveValue
	detail.WheatObj[wheatKey].UpdateTime = time.Now().Unix()
	return wheatUpdateWheat(detail, roomId, occupyKey, wheatKey)
}

func (w wheatDeputyAdmin) down(detail Wheat, roomId int, userId int64, wheatKey int) (data Wheat, err error) {
	return
}

// 实例化主播
func newWheatAnchor() wheatAnchor {
	return *new(wheatAnchor)
}

func (w wheatAnchor) up(detail Wheat, roomId int, userId int64, wheatKey int) (data Wheat, err error) {
	occupyKey, occupyLoveValue, occupyStatus := wheatOccupyKey(detail, userId)
	userInfo, avatarDressUp, love, err := detail.GetUpWheatUserInfo(userId, roomId)
	if err != nil {
		return
	}
	if occupyLoveValue == 0 {
		occupyLoveValue = love
	}

	// 主持麦位下麦时，投递延迟关闭房间消息队列
	if occupyKey == WHEAT_HOME_KEY {
		go rabbitmqProducer.ProducerCloseRoom(roomId)
	}

	// 设置麦位
	detail.WheatObj[wheatKey].UserId = int(userId)
	detail.WheatObj[wheatKey].UserNickName = userInfo.UserNickname
	detail.WheatObj[wheatKey].UserIconurl = userInfo.UserIconurl
	detail.WheatObj[wheatKey].UserGender = userInfo.UserGender
	detail.WheatObj[wheatKey].UserAvatarDressUp = avatarDressUp
	detail.WheatObj[wheatKey].Role = WHEAT_ROLE_ANCHOR
	// 上麦之前麦位状态处理
	err = upWheatStatusBeforeHandler(&detail.WheatObj[wheatKey], occupyKey, occupyStatus, roomId)
	if err != nil {
		return
	}
	detail.WheatObj[wheatKey].LoveValue = occupyLoveValue
	detail.WheatObj[wheatKey].UpdateTime = time.Now().Unix()
	return wheatUpdateWheat(detail, roomId, occupyKey, wheatKey)
}

func (w wheatAnchor) down(detail Wheat, roomId int, userId int64, wheatKey int) (data Wheat, err error) {
	return
}

func wheatComm(detail Wheat, wheatKey int) (err error) {
	if detail.WheatSwitch == WHEAT_SWITCH_OFF && wheatKey != WHEAT_HOME_KEY {
		err = ErrWheatUnopened
		return
	}
	return
}

// 查询当前用户是否在其他麦位上
func wheatOccupyKey(detail Wheat, userId int64) (occupyKey, occupyLoveValue, occupyStatus int) {
	occupyKey = -1      // 占用的索引
	occupyLoveValue = 0 // 占用的爱意值
	occupyStatus = 0    // 占用的状态
	for i := 0; i < detail.WheatLen; i++ {
		if detail.WheatObj[i].UserId == int(userId) {
			occupyKey = i
			occupyLoveValue = detail.WheatObj[i].LoveValue
			occupyStatus = detail.WheatObj[i].Status
			break
		}
	}
	return
}

// 更新麦位
// roomId 房间
// detail 麦位信息
// occupyKey 占用的麦位
// key 使用的麦位
func wheatUpdateWheat(detail Wheat, roomId int, occupyKey int, wheatKey int) (data Wheat, err error) {
	cacheKey := utils.REDIS_LIVE_WHEAT + strconv.Itoa(roomId)
	// 清除之前占用的麦位
	if occupyKey != -1 {
		detail.WheatObj[occupyKey].UserId = 0
		detail.WheatObj[occupyKey].UserNickName = ""
		detail.WheatObj[occupyKey].UserIconurl = ""
		detail.WheatObj[occupyKey].UserGender = 0
		detail.WheatObj[occupyKey].UserAvatarDressUp = ""
		detail.WheatObj[occupyKey].Role = 0
		detail.WheatObj[occupyKey].LoveValue = 0
		detail.WheatObj[occupyKey].Status = WHEAT_STATUS_UNLOCK
		detail.WheatObj[occupyKey].UpdateTime = time.Now().Unix()
	}

	// 更新麦位
	err = new(Wheat).updateWheatObj(cacheKey, detail.WheatObj)
	if err != nil {
		return
	}
	data, err = new(Wheat).QueryWheatDetail(roomId)
	if err != nil {
		return
	}
	data.WheatObj = data.WheatObj[:0]                                // 清空
	data.WheatObj = append(data.WheatObj, detail.WheatObj[wheatKey]) // 重新赋值
	if occupyKey != -1 {
		data.WheatObj = append(data.WheatObj, detail.WheatObj[occupyKey]) // 重新赋值
	}
	return
}

// 上麦前状态处理
func upWheatStatusBeforeHandler(detail *WheatObj, occupyKey int, occupyStatus int, roomId int) (err error) {
	if occupyKey == -1 {
		detail.Status = WHEAT_STATUS_BAN_WHEAT
	} else {
		detail.Status = occupyStatus
	}
	return
}
