package redismodels

import (
	"fmt"
	"strconv"
	"time"

	"github.com/go-redis/redis"

	"gamers/utils"
	"gamers/utils/ymd"
)

const (
	RankRoomItemLengthHourly      = 10
	RankRoomCacheExpireTimeHourly = time.Hour * 24 * 7
)

// 房间送礼排行（魅力榜）
type RankRoomSendCharm struct {
	tag         string
	period      int
	redisKey    string
	redisKeyOff string // 封禁/整改/关闭 缓存key
	length      int
	timeOut     time.Duration
}

func (r *RankRoomSendCharm) Init(tag string, t time.Time, length int) *RankRoomSendCharm {
	r.tag = tag
	r.length = length

	switch r.tag {
	case "hourly":
		r.period = ymd.GetHourDigit(t)
		r.timeOut = RankRoomCacheExpireTimeHourly
	default:
		panic("unexpected RankRoomSendCharm tag")
	}

	r.redisKey = fmt.Sprintf("%s%s:%d", utils.REDIS_RANK_ROOM_SEND_CHARM, r.tag, r.period)
	r.redisKeyOff = fmt.Sprintf("%s%s:%d:off", utils.REDIS_RANK_ROOM_SEND_CHARM, r.tag, r.period)

	return r
}

func (r *RankRoomSendCharm) cacheExpireTimeSecond() int64 {
	return int64(r.timeOut/time.Second + 1)
}

type RankRoomSendCharmUpdateResult struct {
	Tag        string                               `json:"tag"`
	Period     int                                  `json:"period"`
	RoomId     int64                                `json:"room_id"`
	OrgRank    int                                  `json:"org_rank"`
	OrgValue   int64                                `json:"org_value"`
	NewRank    int                                  `json:"new_rank"`
	NewValue   int64                                `json:"new_value"`
	NotifyList []*RankRoomSendCharmUpdateNotifyItem `json:"notify_list"`
}

type RankRoomSendCharmUpdateNotifyItem struct {
	Tag      string `json:"tag"`
	Period   int    `json:"period"`
	RoomId   int64  `json:"room_id"`
	OrgRank  int    `json:"org_rank"` // cal
	NewRank  int    `json:"new_rank"` // cal
	NewValue int64  `json:"new_value"`
}

func (r *RankRoomSendCharm) dealAlterResult(roomId int64, retList []interface{}, leave bool) (*RankRoomSendCharmUpdateResult, error) {
	var updateResult = RankRoomSendCharmUpdateResult{
		Tag:    r.tag,
		Period: r.period,
		RoomId: roomId,
	}

	var notifyRetList []interface{}
	for i, v := range retList {
		var vInt64 int64
		if tv, ok := v.(int64); ok {
			vInt64 = tv
		}
		var bFlag = false
		switch i {
		case 0:
			updateResult.OrgRank = int(vInt64)
		case 1:
			updateResult.OrgValue = vInt64
		case 2:
			updateResult.NewRank = int(vInt64)
		case 3:
			updateResult.NewValue = vInt64
		case 4:
			if vInt64 > 0 {
				notifyRetList = retList[5:]
			}
			bFlag = true
		}
		if bFlag {
			break
		}
	}

	if updateResult.OrgRank != updateResult.NewRank &&
		((updateResult.NewRank != 0 && updateResult.NewRank <= r.length) ||
			(updateResult.OrgRank != 0 && updateResult.OrgRank <= r.length)) {

		updateResult.NotifyList = append(updateResult.NotifyList, &RankRoomSendCharmUpdateNotifyItem{
			Tag:      updateResult.Tag,
			Period:   updateResult.Period,
			RoomId:   updateResult.RoomId,
			OrgRank:  updateResult.OrgRank,
			NewRank:  updateResult.NewRank,
			NewValue: updateResult.NewValue,
		})
	}

	var notifyRetLength = len(notifyRetList)
	for i := 0; i < notifyRetLength; i = i + 2 {
		k, err := strconv.ParseInt(notifyRetList[i].(string), 10, 64)
		if err != nil {
			return nil, err
		}
		v, err := strconv.ParseInt(notifyRetList[i+1].(string), 10, 64)
		if err != nil {
			return nil, err
		}
		var calUsed = updateResult.NewRank
		if leave {
			// 禁止进入榜单时，使用 [OrgRank - 1] 计算 --> 被禁止进入榜单位置后面位置以此向前移动一位
			calUsed = updateResult.OrgRank - 1
		}
		updateResult.NotifyList = append(updateResult.NotifyList, &RankRoomSendCharmUpdateNotifyItem{
			Tag:      r.tag,
			Period:   r.period,
			RoomId:   k,
			OrgRank:  calUsed + i/2,
			NewRank:  calUsed + i/2 + 1,
			NewValue: v,
		})
	}

	if len(updateResult.NotifyList) != 0 {
		r.Notify(updateResult.NotifyList)
	}

	return &updateResult, nil
}

// 根据规则，尝试主动通知前端排行变动
func (r *RankRoomSendCharm) Notify(notifyList []*RankRoomSendCharmUpdateNotifyItem) {
	for _, v := range notifyList {
		msg := LiveMsg{
			Type:        MSG_TYPE_RANK,
			ContentType: CONTENT_TYPE_CMD,
			CMD:         CMD_TYPE_RANK_ROOM_SEND_CLARM,
			RankInfo:    v,
		}
		err := msg.SendLiveMsg(strconv.Itoa(int(v.RoomId)))
		if err != nil {
			utils.LogErrorF("发送消息失败：", err.Error())
		}
	}
}

// 这里是不是更新房间送礼榜的redis以供查询？？？？ 是的，下方的函数有查询和获取rank
func (r *RankRoomSendCharm) Update(roomId int64, changeValue int64) (*RankRoomSendCharmUpdateResult, error) {
	var script = redis.NewScript(`
local poolKey = KEYS[1]
local poolKeyOff = KEYS[2]

local roomId = ARGV[1] -- string
local changeValue = tonumber(ARGV[2])
local rankLength = tonumber(ARGV[3])
local poolExpireTime = tonumber(ARGV[4])


local orgRank, orgScore = -1, 0
local newRank, newScore = -1, 0

-- off
do
    local offRank = redis.call("Zrevrank", poolKeyOff, roomId)
    if offRank ~= false then
        redis.call("Zincrby", poolKeyOff, changeValue, roomId)
        return {orgRank, orgScore, newRank, newScore}
    end
end

local getRankAndScore = function(sPoolKey, sRoomId)
    local retRank = -1
    local retScore = 0
    local rank = redis.call("Zrevrank", sPoolKey, sRoomId)
    if rank ~= false then
        retRank = tonumber(rank)
    end
    local score = redis.call("Zscore", sPoolKey, sRoomId)
    if score ~= false then
        retScore = tonumber(score)
    end
    return retRank, retScore
end

local poolType = redis.call("TYPE", poolKey)
if poolType["ok"] == "zset" then
    orgRank, orgScore = getRankAndScore(poolKey, roomId)
    redis.call("Zincrby", poolKey, changeValue, roomId)
    newRank, newScore = getRankAndScore(poolKey, roomId)
elseif poolType["ok"] == "none" then
    --orgRank, orgScore = getRankAndScore(poolKey, roomId)
    redis.call("Zincrby", poolKey, changeValue, roomId)
    redis.call("Expire", poolKey, poolExpireTime)
    newRank, newScore = getRankAndScore(poolKey, roomId)
else
    --orgRank, orgScore = getRankAndScore(poolKey, roomId)
    redis.call("Del", poolKey)
    redis.call("Zincrby", poolKey, changeValue, roomId)
    redis.call("Expire", poolKey, poolExpireTime)
    newRank, newScore = getRankAndScore(poolKey, roomId)
end

-- Convert to start with 1.
orgRank = orgRank + 1
newRank = newRank + 1

local notifyLength = 0
local notifyList = {}
local result = {orgRank, orgScore, newRank, newScore}
if orgRank ~= newRank and newRank <= rankLength then
    if orgRank ~= 0 and orgRank <= rankLength then
        notifyLength = orgRank - newRank
    else
        notifyLength = rankLength - newRank + 1
    end
    notifyList = redis.call("Zrevrange", poolKey, newRank, notifyLength-1, "WITHSCORES")
end
notifyLength = math.floor(#notifyList / 2) -- integer
result[#result+1] = notifyLength
for _, v in ipairs(notifyList) do
    result[#result+1] = v
end

return result
`)

	retVal, retErr := script.Eval(utils.RedisClient,
		[]string{
			r.redisKey,
			r.redisKeyOff,
		},
		fmt.Sprintf("%d", roomId),
		changeValue,
		r.length,
		r.cacheExpireTimeSecond()).
		Result()

	if retErr != nil {
		return nil, retErr
	}

	return r.dealAlterResult(roomId, retVal.([]interface{}), false)
}

// 允许进入排行
func (r *RankRoomSendCharm) Allow(roomId int64) (*RankRoomSendCharmUpdateResult, error) {
	var script = redis.NewScript(`
local poolKey = KEYS[1]
local poolKeyOff = KEYS[2]

local roomId = ARGV[1] -- string
local rankLength = tonumber(ARGV[2])
local poolExpireTime = tonumber(ARGV[3])

local getRankAndScore = function(sPoolKey, sRoomId)
    local retRank = -1
    local retScore = 0
    local rank = redis.call("Zrevrank", sPoolKey, sRoomId)
    if rank ~= false then
        retRank = tonumber(rank)
    end
    local score = redis.call("Zscore", sPoolKey, sRoomId)
    if score ~= false then
        retScore = tonumber(score)
    end
    return retRank, retScore
end

local orgRank, orgScore = -1, 0
local newRank, newScore = -1, 0

local changeValue = 0
do
    local offRank, offScore = getRankAndScore(poolKeyOff, roomId)
    if offRank == -1 then
        return {orgRank+1, orgScore, newRank+1, newScore}
    end
    redis.call("Zrem", poolKeyOff, roomId)
    changeValue = offScore
    if changeValue == 0 then
        return {orgRank+1, orgScore, newRank+1, newScore}
    end
end

local poolType = redis.call("TYPE", poolKey)
if poolType["ok"] == "zset" then
    orgRank, orgScore = getRankAndScore(poolKey, roomId)
    redis.call("Zincrby", poolKey, changeValue, roomId)
    newRank, newScore = getRankAndScore(poolKey, roomId)
elseif poolType["ok"] == "none" then
    --orgRank, orgScore = getRankAndScore(poolKey, roomId)
    redis.call("Zincrby", poolKey, changeValue, roomId)
    redis.call("Expire", poolKey, poolExpireTime)
    newRank, newScore = getRankAndScore(poolKey, roomId)
else
    --orgRank, orgScore = getRankAndScore(poolKey, roomId)
    redis.call("Del", poolKey)
    redis.call("Zincrby", poolKey, changeValue, roomId)
    redis.call("Expire", poolKey, poolExpireTime)
    newRank, newScore = getRankAndScore(poolKey, roomId)
end

-- Convert to start with 1.
orgRank = orgRank + 1
newRank = newRank + 1

local notifyLength = 0
local notifyList = {}
local result = {orgRank, orgScore, newRank, newScore}
if orgRank ~= newRank and newRank <= rankLength then
    if orgRank ~= 0 and orgRank <= rankLength then
        notifyLength = orgRank - newRank
    else
        notifyLength = rankLength - newRank + 1
    end
    notifyList = redis.call("Zrevrange", poolKey, newRank, notifyLength-1, "WITHSCORES")
end
notifyLength = math.floor(#notifyList / 2) -- integer
result[#result+1] = notifyLength
for _, v in ipairs(notifyList) do
    result[#result+1] = v
end

return result
`)

	retVal, retErr := script.Eval(utils.RedisClient,
		[]string{
			r.redisKey,
			r.redisKeyOff,
		},
		fmt.Sprintf("%d", roomId),
		r.length,
		r.cacheExpireTimeSecond()).
		Result()

	if retErr != nil {
		return nil, retErr
	}

	return r.dealAlterResult(roomId, retVal.([]interface{}), false)
}

// 不允许进入排行
func (r *RankRoomSendCharm) Ban(roomId int64) (*RankRoomSendCharmUpdateResult, error) {
	var script = redis.NewScript(`
local poolKey = KEYS[1]
local poolKeyOff = KEYS[2]

local roomId = ARGV[1] -- string
local rankLength = tonumber(ARGV[2])
local poolExpireTime = tonumber(ARGV[3])

local getRankAndScore = function(sPoolKey, sRoomId)
    local retRank = -1
    local retScore = 0
    local rank = redis.call("Zrevrank", sPoolKey, sRoomId)
    if rank ~= false then
        retRank = tonumber(rank)
    end
    local score = redis.call("Zscore", sPoolKey, sRoomId)
    if score ~= false then
        retScore = tonumber(score)
    end
    return retRank, retScore
end

local orgRank, orgScore = -1, 0
local newRank, newScore = -1, 0

local changeValue = 0
do
    orgRank, orgScore = getRankAndScore(poolKey, roomId)
    if orgRank ~= -1 then
        redis.call("Zrem", poolKey, roomId)
    end
    changeValue = orgScore
end

local poolType = redis.call("TYPE", poolKeyOff)
if poolType["ok"] == "zset" then
    redis.call("Zincrby", poolKeyOff, changeValue, roomId)
elseif poolType["ok"] == "none" then
    redis.call("Zincrby", poolKeyOff, changeValue, roomId)
    redis.call("Expire", poolKeyOff, poolExpireTime)
else
    redis.call("Del", poolKeyOff)
    redis.call("Zincrby", poolKeyOff, changeValue, roomId)
    redis.call("Expire", poolKeyOff, poolExpireTime)
end

-- Convert to start with 1.
orgRank = orgRank + 1
newRank = newRank + 1

local notifyLength = 0
local notifyList = {}
local result = {orgRank, orgScore, newRank, newScore}
if 0 < orgRank and orgRank <= rankLength then
    notifyList = redis.call("Zrevrange", poolKey, orgRank-1, notifyLength-1, "WITHSCORES")
end
notifyLength = math.floor(#notifyList / 2) -- integer
result[#result+1] = notifyLength
for _, v in ipairs(notifyList) do
    result[#result+1] = v
end

return result
`)

	retVal, retErr := script.Eval(utils.RedisClient,
		[]string{
			r.redisKey,
			r.redisKeyOff,
		},
		fmt.Sprintf("%d", roomId),
		r.length,
		r.cacheExpireTimeSecond()).
		Result()

	if retErr != nil {
		return nil, retErr
	}

	return r.dealAlterResult(roomId, retVal.([]interface{}), true)
}

func (r *RankRoomSendCharm) Query(roomId int64) (rank int, score int64) {
	var script = redis.NewScript(`
local poolKey = KEYS[1]
local sRoomId = ARGV[1]

local sRank, sScore = -1, 0

local poolType = redis.call("TYPE", poolKey)
if poolType["ok"] == "zset" then
    local rank = redis.call("Zrevrank", poolKey, sRoomId)
    if rank ~= false then
        sRank = tonumber(rank)
    end
    local score = redis.call("Zscore", poolKey, sRoomId)
    if score ~= false then
        sScore = tonumber(score)
    end
end

return {sRank+1, sScore}
`)

	retVal, retErr := script.Eval(utils.RedisClient,
		[]string{r.redisKey},
		fmt.Sprintf("%d", roomId)).
		Result()

	if retErr != nil {
		return 0, 0
	}

	var retList = retVal.([]interface{})
	for i, v := range retList {
		var vInt64 int64
		if tv, ok := v.(int64); ok {
			vInt64 = tv
		}
		switch i {
		case 0:
			rank = int(vInt64)
		case 1:
			score = vInt64
		}
	}
	return
}

type RankRoomSendCharmRankItem struct {
	RoomId int64 `json:"room_id"`
	Value  int64 `json:"value"`
}

type RankRoomSendCharmRankItemOwn struct {
	RoomId int64 `json:"room_id"`
	Rank   int   `json:"rank"`
	Value  int64 `json:"value"`
}

type RankRoomSendCharmRankResult struct {
	List []*RankRoomSendCharmRankItem
	Own  *RankRoomSendCharmRankItemOwn
}

func (r *RankRoomSendCharm) GetRank(roomId int64) (*RankRoomSendCharmRankResult, error) {
	var script = redis.NewScript(`
local poolKey = KEYS[1]

local sRoomId = ARGV[1]
local length = tonumber(ARGV[2])

local getRankAndScore = function(rPoolKey, roomId)
    local retRank = -1
    local retScore = 0
    local rank = redis.call("Zrevrank", rPoolKey, roomId)
    if rank ~= false then
        retRank = tonumber(rank)
    end
    local score = redis.call("Zscore", rPoolKey, roomId)
    if score ~= false then
        retScore = tonumber(score)
    end
    return retRank, retScore
end

local revRankList = {"0", "0"}
local poolType = redis.call("TYPE", poolKey)
if poolType["ok"] == "zset" then
    revRankList = redis.call("Zrevrange", poolKey, 0, length - 1, "WITHSCORES")
    local sRank, sScore = getRankAndScore(poolKey, sRoomId)
    revRankList[#revRankList+1] = tostring(sRank+1)
    revRankList[#revRankList+1] = tostring(sScore)
end

return revRankList
`)

	retVal, retErr := script.Eval(utils.RedisClient,
		[]string{r.redisKey},
		fmt.Sprintf("%d", roomId),
		r.length).
		Result()

	if retErr != nil {
		return nil, retErr
	}

	var data []*RankRoomSendCharmRankItem
	var retList = retVal.([]interface{})
	var length = len(retList)

	for i := 0; i < length; i = i + 2 {
		k, err := strconv.ParseInt(retList[i].(string), 10, 64)
		if err != nil {
			return nil, err
		}
		v, err := strconv.ParseInt(retList[i+1].(string), 10, 64)
		if err != nil {
			return nil, err
		}
		data = append(data, &RankRoomSendCharmRankItem{
			RoomId: k,
			Value:  v,
		})
	}

	var dataOwn = data[len(data)-1]
	var result = RankRoomSendCharmRankResult{
		List: data[0 : len(data)-1],
		Own: &RankRoomSendCharmRankItemOwn{
			RoomId: roomId,
			Rank:   int(dataOwn.RoomId),
			Value:  dataOwn.Value,
		},
	}

	return &result, nil
}
