package redismodels

import (
	"encoding/json"
	"gamers/utils"
)

// 跑马灯消息
type HeadlineMsg struct {
	Type              int           `json:"type"`               // 消息类型
	Level             int           `json:"level"`              // 推送级别
	ActionType        int           `json:"action_type"`        // 跳转类型
	Action            string        `json:"action"`             // 事件内容
	Priority          int           `json:"priority"`           // 优先级0普通
	BgUrl             string        `json:"bg_url"`             // 背景图片
	Repeat            int           `json:"repeat"`             // 播放次数
	ActionStyle       ActionStyle   `json:"action_style"`       // 跳转样式
	FromAccount       *MsgUserObj   `json:"from_account"`       // 发送者信息
	GiftInfo          []*MsgPropObj `json:"gift_info"`          // 礼物信息
	LiveInfo          *LiveInfo     `json:"live_info"`          // 直播间信息
	PropInfo          []*PropInfo   `json:"prop_info"`          // 砸蛋信息
	Content           string        `json:"content"`            // 消息具体内容，根据type，此值可能是一些指令，如：禁言，踢人等
	NotificationClose int           `json:"notification_close"` // 是否关闭通知栏消息
}

// 跑马灯job
type HeadlineJob struct {
	Type         int         `json:"type"` // 消息类型，0为本房间，1为按tag，2为全局
	LiveRoomType int         `json:"live_room_type"`
	LiveRoomId   int64       `json:"live_room_id"` // 房间号
	TagId        int64       `json:"tag_id"`       // 房间的tagId 这里为了后续减少查询
	Job          HeadlineMsg `json:"job"`          // 具体job
}

const HEADLINE_MSG_TOPIC = "HeadlineMsg"

func (s *HeadlineMsg) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s HeadlineMsg) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

func (s *HeadlineJob) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s HeadlineJob) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

// 消息类型
const (
	HEADLINE_MSG_TYPE_SYS       = iota // 系统消息
	HEADLINE_MSG_TYPE_GIFT             // 礼物消息
	HEADLINE_MSG_TYPE_EGG_BREAK        // 砸蛋消息
)

// 消息级别
const (
	HEADLINE_JOB_TYPE_ROOM = iota // 本房间
	HEADLINE_JOB_TYPE_TAG         // 同标签
	HEADLINE_JOB_TYPE_ALL         // 全局
)

const (
	HEADLINE_ACTION_TYPE_NO = iota
	HEADLINE_ACTION_TYPE_LIVE_ROOM
	HEADLINE_ACTION_TYPE_URL
)

// 消息优先级
const (
	HEADLINE_PRIORITY_NORMAL = iota
	HEADLINE_PRIORITY_HIGH
)

const (
	HEADLINE_LEVEL_ROOM          = iota // 本房间
	HEADLINE_LEVEL_CHILD_CHANNEL        // 子频道
	HEADLINE_LEVEL_CHANNEL              // 全频道
	HEADLINE_LEVEL_ALL                  // 全局
)

func (m HeadlineJob) PushMq(key string) {
	data, err := json.Marshal(m)
	if err != nil {
		utils.LogErrorF("推送消息到topic[%v]失败，err：%s", m, err.Error())
		return
	}
	err = utils.KafkaSendMsg(key, utils.FuncGenerateDataId(), data)
	if err != nil {
		utils.LogErrorF("推送消息到topic[%s]失败，err：%s", key, err.Error())
		return
	}
	return
}
