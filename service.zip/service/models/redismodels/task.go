package redismodels

import (
	"encoding/json"
	"errors"
	"fmt"
	"gamers/enum"
	db "gamers/models/dbmodels"
	"gamers/utils"
	"gamers/utils/ymd"
	"github.com/go-redis/redis"
	"sync"
	"time"
)

var (
	ErrorTaskDataUnCached = errors.New("task data uncached")
	ErrorTaskDataNotExist = errors.New("task data not exist")
)

type Task struct {
}

func (t *Task) Init() *Task {
	return t
}

func (t *Task) RedisKeyCfgBySet() string {
	return utils.REDIS_TASK_CFG_BY_SET
}

func (t *Task) RedisKeyCfgByTaskID() string {
	return utils.REDIS_TASK_CFG_BY_TASK_ID
}

func (t *Task) RedisKeyCfgByCondition(taskConditionTag string) string {
	return fmt.Sprintf("%s%s", utils.REDIS_TASK_CFG_BY_CONDITION, taskConditionTag)
}

// 构建任务配置缓存
func (t *Task) Build() (lock bool, canUseData bool, data []*db.AppTaskSet, err error) {
	t.TryLock(func() {
		lock = true

		data, err = new(db.AppTaskSet).QueryAll()
		if err != nil {
			return
		}

		canUseData = true
		err = t.build(data)
	})
	return
}

// 在已经获得锁的地方调用（并且忽略返回值）
func (t *Task) BuildIgnoreLock() {
	data, err := new(db.AppTaskSet).QueryAll()
	if err != nil {
		return
	}
	_ = t.build(data)
}

func (t *Task) build(data []*db.AppTaskSet) error {
	var (
		cfgBySetWrapper       = map[string]*TaskWrapperCfgTaskSet{}         // [setID]data
		cfgByTaskIDWrapper    = map[string]*TaskWrapperCfgTask{}            // [taskID]data
		cfgByConditionWrapper = map[string]map[string]*TaskWrapperCfgTask{} // [taskConditionTag][taskID]data
	)

	for _, v := range data {
		t.buildWrapper(v, cfgBySetWrapper, cfgByTaskIDWrapper, cfgByConditionWrapper)
	}
	// t.buildWrapperDummy(cfgBySetWrapper, cfgByTaskIDWrapper)

	var cfgBySet, cfgByTaskID, cfgByCondition, err = t.buildParam(
		cfgBySetWrapper, cfgByTaskIDWrapper, cfgByConditionWrapper,
	)
	if err != nil {
		return err
	}

	if err := t.delAll(); err != nil {
		return err
	}

	if err := t.addAll(cfgBySet, cfgByTaskID, cfgByCondition); err != nil {
		return err
	}

	return nil
}

const (
	taskDummySet    = 0
	taskDummyTaskID = 0
)

const (
	TaskSetModelTaskCenter = 0 // 任务中心
	TaskSetModelTurnTable  = 1 // 大转盘
)

type TaskWrapperCfgTaskSet struct {
	Set   *db.AppTaskSet         `json:"set"`
	Tasks map[uint32]*db.AppTask `json:"tasks"`
}

// 仅用于接收缓存数据
type TaskWrapperCfgTaskSetSubset struct {
	Set *db.AppTaskSet `json:"set"`
}

type TaskWrapperCfgTask struct {
	Set  *db.AppTaskSet `json:"set"`
	Task *db.AppTask    `json:"task"`
}

func (t *Task) CheckConditionTag(conditionTag string) bool {
	if _, ok := enum.TaskConditionTags[conditionTag]; ok {
		return true
	}
	return false
}

func (t *Task) buildWrapper(
	v *db.AppTaskSet,
	cfgBySetWrapper map[string]*TaskWrapperCfgTaskSet,
	cfgByTaskIDWrapper map[string]*TaskWrapperCfgTask,
	cfgByConditionWrapper map[string]map[string]*TaskWrapperCfgTask) {

	if v == nil {
		return
	}

	var setData = *v
	setData.SetTasks = nil // 去除额外信息
	var bySetWrapper = TaskWrapperCfgTaskSet{
		Set:   &setData,
		Tasks: map[uint32]*db.AppTask{},
	}

	for _, task := range v.SetTasks {
		if task.Deleted != 0 {
			continue
		}

		bySetWrapper.Tasks[task.TaskID] = task

		var (
			filedTaskID = fmt.Sprintf("%d", task.TaskID)
			taskWrapper = &TaskWrapperCfgTask{
				Set:  &setData,
				Task: task,
			}
		)

		cfgByTaskIDWrapper[filedTaskID] = taskWrapper

		var keyConditionTag = t.RedisKeyCfgByCondition(task.TaskConditionTag)
		if _, prs := cfgByConditionWrapper[keyConditionTag]; !prs {
			cfgByConditionWrapper[keyConditionTag] = map[string]*TaskWrapperCfgTask{}
		}
		cfgByConditionWrapper[keyConditionTag][filedTaskID] = taskWrapper
	}

	cfgBySetWrapper[fmt.Sprintf("%d", setData.SetID)] = &bySetWrapper
}

func (t *Task) buildWrapperDummy(
	cfgBySetWrapper map[string]*TaskWrapperCfgTaskSet,
	cfgByTaskIDWrapper map[string]*TaskWrapperCfgTask) {

	// Dummy --> 保证build后 redis_key 一定存在
	cfgBySetWrapper[fmt.Sprintf("%d", taskDummySet)] = &TaskWrapperCfgTaskSet{
		Set:   &db.AppTaskSet{SetID: taskDummySet},
		Tasks: map[uint32]*db.AppTask{},
	}
	cfgByTaskIDWrapper[fmt.Sprintf("%d", taskDummyTaskID)] = &TaskWrapperCfgTask{
		Set:  &db.AppTaskSet{SetID: taskDummySet},
		Task: &db.AppTask{TaskID: taskDummyTaskID},
	}
}

func (t *Task) buildParam(
	cfgBySetWrapper map[string]*TaskWrapperCfgTaskSet,
	cfgByTaskIDWrapper map[string]*TaskWrapperCfgTask,
	cfgByConditionWrapper map[string]map[string]*TaskWrapperCfgTask) (
	map[string]interface{}, map[string]interface{}, map[string]map[string]interface{}, error,
) {

	var (
		cfgBySet       = map[string]interface{}{}
		cfgByTaskID    = map[string]interface{}{}
		cfgByCondition = map[string]map[string]interface{}{}
	)

	for k, v := range cfgBySetWrapper {
		var d, err = json.Marshal(v)
		if err != nil {
			return nil, nil, nil, err
		}
		cfgBySet[k] = d
	}
	for k, v := range cfgByTaskIDWrapper {
		var d, err = json.Marshal(v)
		if err != nil {
			return nil, nil, nil, err
		}
		cfgByTaskID[k] = d
	}

	for conditionTag, v := range cfgByConditionWrapper {
		cfgByCondition[conditionTag] = map[string]interface{}{}
		for filedTaskID, t := range v {
			var d, err = json.Marshal(t)
			if err != nil {
				return nil, nil, nil, err
			}
			cfgByCondition[conditionTag][filedTaskID] = d
		}
	}

	return cfgBySet, cfgByTaskID, cfgByCondition, nil
}

func (t *Task) addAll(cfgBySet, cfgByTaskID map[string]interface{}, cfgByCondition map[string]map[string]interface{}) error {
	return t.add(cfgBySet, cfgByTaskID, cfgByCondition)
}

func (t *Task) add(cfgBySet, cfgByTaskID map[string]interface{}, cfgByCondition map[string]map[string]interface{}) error {
	if err := utils.RedisClient.HMSet(t.RedisKeyCfgBySet(), cfgBySet).Err(); err != nil {
		_ = t.delAll()
		return err
	}

	if err := utils.RedisClient.HMSet(t.RedisKeyCfgByTaskID(), cfgByTaskID).Err(); err != nil {
		_ = t.delAll()
		return err
	}

	for key, data := range cfgByCondition {
		if err := utils.RedisClient.HMSet(key, data).Err(); err != nil {
			_ = t.delAll()
			return err
		}
	}

	return nil
}

func (t *Task) delAll() error {
	var delKeys = []string{
		t.RedisKeyCfgBySet(),
		t.RedisKeyCfgByTaskID(),
	}

	for conditionTag, _ := range enum.TaskConditionTags {
		delKeys = append(delKeys, t.RedisKeyCfgByCondition(conditionTag))
	}

	if err := utils.RedisClient.Del(delKeys...).Err(); err != nil {
		return err
	}

	return nil
}

func (t *Task) IsCached() bool {
	var checkKeys = []string{
		t.RedisKeyCfgBySet(),
		t.RedisKeyCfgByTaskID(),
	}

	var retVal, retErr = utils.RedisClient.Exists(checkKeys...).Result()
	if retErr != nil {
		return false // 认为未缓存 --> ???!!!
	}

	if retVal != int64(len(checkKeys)) {
		return false
	}

	return true
}

func (t *Task) GetSetList() ([]*db.AppTaskSet, error) {
	var retVal, retErr = utils.RedisClient.HGetAll(t.RedisKeyCfgBySet()).Result()
	if retErr != nil {
		return nil, retErr
	}

	if len(retVal) == 0 {
		return nil, ErrorTaskDataUnCached
	}

	var result []*db.AppTaskSet
	for _, v := range retVal {
		var recv = TaskWrapperCfgTaskSetSubset{}
		var err = json.Unmarshal([]byte(v), &recv)
		if err != nil || recv.Set == nil {
			_ = t.delAll()
			return nil, ErrorTaskDataUnCached
		}
		if recv.Set.SetID != taskDummySet {
			result = append(result, recv.Set)
		}
	}

	return result, nil
}

func (t *Task) GetAllSetData(model int) (map[uint32]*TaskWrapperCfgTaskSet, error) {
	var retVal, retErr = utils.RedisClient.HGetAll(t.RedisKeyCfgBySet()).Result()
	if retErr != nil {
		return nil, retErr
	}

	if len(retVal) == 0 {
		return nil, ErrorTaskDataUnCached
	}

	var result = map[uint32]*TaskWrapperCfgTaskSet{}
	for _, v := range retVal {
		var recv = TaskWrapperCfgTaskSet{}
		var err = json.Unmarshal([]byte(v), &recv)
		if err != nil || recv.Set == nil {
			_ = t.delAll()
			return nil, ErrorTaskDataUnCached
		}
		if recv.Set.SetID != taskDummySet && recv.Set.SetModel == uint32(model) {
			result[recv.Set.SetID] = &recv
		}
	}
	return result, nil
}

func (t *Task) GetDataBySetID(setID uint32) (*db.AppTaskSet, error) {
	if setID == taskDummySet {
		return nil, nil
	}

	var field = fmt.Sprintf("%d", setID)
	var retVal, retErr = utils.RedisClient.HGet(t.RedisKeyCfgBySet(), field).Result()

	if retErr == redis.Nil {
		return nil, nil
	}

	if retErr != nil {
		return nil, retErr
	}

	var recv TaskWrapperCfgTaskSet
	var err = json.Unmarshal([]byte(retVal), &recv)
	if err != nil {
		_ = t.delAll()
		return nil, ErrorTaskDataUnCached
	}

	var result db.AppTaskSet
	result = *recv.Set
	result.SetTasks = nil
	for _, v := range recv.Tasks {
		result.SetTasks = append(result.SetTasks, v)
	}

	return &result, nil
}

func (t *Task) GetDataByTaskID(taskID uint32) (*TaskWrapperCfgTask, error) {
	if taskID == taskDummyTaskID {
		return nil, nil
	}

	var field = fmt.Sprintf("%d", taskID)
	var retVal, retErr = utils.RedisClient.HGet(t.RedisKeyCfgByTaskID(), field).Result()

	if retErr == redis.Nil {
		return nil, nil
	}

	if retErr != nil {
		return nil, retErr
	}

	var result TaskWrapperCfgTask
	var err = json.Unmarshal([]byte(retVal), &result)
	if err != nil {
		_ = t.delAll()
		return nil, ErrorTaskDataUnCached
	}

	return &result, nil
}

func (t *Task) GetDataByCondition(taskConditionTag string) ([]*TaskWrapperCfgTask, error) {
	if !t.CheckConditionTag(taskConditionTag) {
		return nil, nil // errors.New("unexpected task condition tag")
	}

	var retVal, retErr = utils.RedisClient.HGetAll(t.RedisKeyCfgByCondition(taskConditionTag)).Result()

	if retErr == redis.Nil {
		return nil, nil
	}

	if retErr != nil {
		return nil, retErr
	}

	var result []*TaskWrapperCfgTask
	for _, v := range retVal {
		var data TaskWrapperCfgTask
		var err = json.Unmarshal([]byte(v), &data)
		if err != nil {
			_ = t.delAll()
			return nil, ErrorTaskDataUnCached
		}
		result = append(result, &data)
	}

	return result, nil
}

func (t *Task) AddSet(data *db.AppTaskSet) error {
	if data == nil {
		return nil
	}

	var (
		cfgBySetWrapper       = map[string]*TaskWrapperCfgTaskSet{}         // [setID]data
		cfgByTaskIDWrapper    = map[string]*TaskWrapperCfgTask{}            // [taskID]data
		cfgByConditionWrapper = map[string]map[string]*TaskWrapperCfgTask{} // [taskConditionTag][taskID]data
	)
	t.buildWrapper(data, cfgBySetWrapper, cfgByTaskIDWrapper, cfgByConditionWrapper)

	var cfgBySet, cfgByTaskID, cfgByCondition, err = t.buildParam(
		cfgBySetWrapper, cfgByTaskIDWrapper, cfgByConditionWrapper,
	)
	if err != nil {
		_ = t.delAll()
		return err
	}

	if err := t.add(cfgBySet, cfgByTaskID, cfgByCondition); err != nil {
		_ = t.delAll()
		return err
	}

	return nil
}

func (t *Task) DelSet(data *db.AppTaskSet) error {
	if data == nil {
		return nil
	}

	var cfgBySetField = fmt.Sprintf("%d", data.SetID)
	var cfgByTaskIDFields []string
	var cfgByConditionFields = map[string][]string{}
	for _, task := range data.SetTasks {
		var filedTaskID = fmt.Sprintf("%d", task.TaskID)
		cfgByTaskIDFields = append(cfgByTaskIDFields, filedTaskID)
		var keyConditionTag = t.RedisKeyCfgByCondition(task.TaskConditionTag)
		if _, prs := cfgByConditionFields[keyConditionTag]; !prs {
			cfgByConditionFields[keyConditionTag] = []string{}
		}
		cfgByConditionFields[keyConditionTag] = append(cfgByConditionFields[keyConditionTag], filedTaskID)
	}

	if err := utils.RedisClient.HDel(t.RedisKeyCfgBySet(), cfgBySetField).Err(); err != nil {
		_ = t.delAll()
		return err
	}

	if err := utils.RedisClient.HDel(t.RedisKeyCfgByTaskID(), cfgByTaskIDFields...).Err(); err != nil {
		_ = t.delAll()
		return err
	}

	for k, v := range cfgByConditionFields {
		if err := utils.RedisClient.HDel(k, v...).Err(); err != nil {
			_ = t.delAll()
			return err
		}
	}

	return nil
}

func (t *Task) AddTask(data *db.AppTaskSet, task *db.AppTask) error {
	var setData = *data
	setData.SetTasks = append(setData.SetTasks, task)

	var (
		cfgBySetWrapper       = map[string]*TaskWrapperCfgTaskSet{}         // [setID]data
		cfgByTaskIDWrapper    = map[string]*TaskWrapperCfgTask{}            // [taskID]data
		cfgByConditionWrapper = map[string]map[string]*TaskWrapperCfgTask{} // [taskConditionTag][taskID]data
	)

	t.buildWrapper(&setData, cfgBySetWrapper, cfgByTaskIDWrapper, cfgByConditionWrapper)

	var cfgBySet, cfgByTaskID, cfgByCondition, err = t.buildParam(
		cfgBySetWrapper, cfgByTaskIDWrapper, cfgByConditionWrapper,
	)

	if err != nil {
		return err
	}

	if err := t.add(cfgBySet, cfgByTaskID, cfgByCondition); err != nil {
		return err
	}

	return nil
}

func (t *Task) DelTask(data *db.AppTaskSet, taskID uint32) error {
	var setData = *data
	setData.SetTasks = nil // 去除额外信息
	var bySetWrapper = TaskWrapperCfgTaskSet{
		Set:   &setData,
		Tasks: map[uint32]*db.AppTask{},
	}

	var (
		fieldTaskID    string
		byConditionKey string
	)

	for _, task := range data.SetTasks {
		if task.Deleted != 0 {
			continue
		}

		if taskID == task.TaskID {
			fieldTaskID = fmt.Sprintf("%d", taskID)
			byConditionKey = t.RedisKeyCfgByCondition(task.TaskConditionTag)
			continue
		}

		bySetWrapper.Tasks[task.TaskID] = task
	}

	if fieldTaskID == "" {
		return nil
	}

	{
		var d, err = json.Marshal(bySetWrapper)
		if err != nil {
			return err
		}
		if err := utils.RedisClient.HSet(t.RedisKeyCfgBySet(), fmt.Sprintf("%d", data.SetID), d).Err(); err != nil {
			_ = t.delAll()
			return err
		}
	}

	if err := utils.RedisClient.HDel(t.RedisKeyCfgByTaskID(), fieldTaskID).Err(); err != nil {
		_ = t.delAll()
		return err
	}

	if err := utils.RedisClient.HDel(byConditionKey, fieldTaskID).Err(); err != nil {
		_ = t.delAll()
		return err
	}

	return nil
}

func (t *Task) TryLock(tryDo func()) {
	var lockVal, isLock = utils.AcquireLock(utils.REDIS_TASK_CFG_CHANGE, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
	if !isLock {
		return
	}
	defer utils.ReleaseLock(utils.REDIS_TASK_CFG_CHANGE, lockVal)
	tryDo()
	return
}

// 上报任务条件
func (t *Task) ReportConditionTag(userID int64, conditionTag string, conditionCount uint32) error {
	if _, prs := enum.TaskConditionTags[conditionTag]; !prs {
		return nil
	}

	// 特殊的，连续签到任务不能通过此接口触发
	if conditionTag == "checkinContinuous" {
		return nil
	}

	if conditionCount < 1 {
		conditionCount = 1
	}

	if t.IsCached() {
		_, _, _, _ = t.Build()
	}

	var taskDataByConditionTag, err = t.GetDataByCondition(conditionTag)
	if err != nil {
		return err
	}

	if taskDataByConditionTag == nil {
		return nil
	}

	var nowTime = time.Now()
	var nowTimestamp = nowTime.Unix()

	var needUpdateTasks []*TaskWrapperCfgTask
	for _, task := range taskDataByConditionTag {
		if task.Set.SetStatus == enum.TaskSetStatusClose {
			continue
		}
		if task.Set.SetStartTime != 0 && task.Set.SetEndTime != 0 {
			if !(int64(task.Set.SetStartTime) <= nowTimestamp && nowTimestamp <= int64(task.Set.SetEndTime)) {
				continue
			}
		}
		if task.Task.TaskStatus == enum.TaskStatusClose {
			continue
		}
		needUpdateTasks = append(needUpdateTasks, task)
	}

	if len(needUpdateTasks) == 0 {
		return nil
	}

	var waitGroup = sync.WaitGroup{}
	waitGroup.Add(len(needUpdateTasks))

	var recordMgr = new(db.AppTaskRecord)
	for _, task := range needUpdateTasks {
		var tup = db.TaskUpdateProgress{
			UserID:            userID,
			SetID:             task.Set.SetID,
			TaskID:            task.Task.TaskID,
			ConditionTag:      task.Task.TaskConditionTag,
			ConditionCount:    task.Task.TaskConditionCount,
			AddConditionCount: conditionCount,
			RecordTime:        nowTime,
			TaskBegin:         0,
			TaskEnd:           0,
		}
		switch task.Set.SetVerifyMode {
		case enum.TaskSetVerifyModeDaily:
			tup.TaskBegin, tup.TaskEnd = ymd.GetDayBeginAndEndTimestamp(nowTime)
		case enum.TaskSetVerifyModeForever:
		default:
		}

		go func(tup *db.TaskUpdateProgress) {
			defer waitGroup.Done()
			_ = recordMgr.UpdateProgress(utils.GEngine, tup)
		}(&tup)
	}

	waitGroup.Wait()

	return nil
}
