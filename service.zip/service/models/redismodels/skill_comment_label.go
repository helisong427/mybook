package redismodels

type SkillCommentLabel struct {
	Key   string //技能id:标签id:技能名称
	Value int64  //标签数量
}
