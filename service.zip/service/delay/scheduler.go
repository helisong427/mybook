package delay

import (
	"gamers/utils"
	"time"

	"github.com/go-redis/redis"
)

var (
	// 每个定时器对应一个bucket
	timers []*time.Ticker
)

const DEFAULT_TIME_TICKER = 5

// 初始化定时器
func InitTimers() {
	defer func() {
		if r := recover(); r != nil {
			utils.LogErrorF("初始化异常：", r.(string))
		}
	}()
	timers = make([]*time.Ticker, DEFAULT_BUCKET_SIZE)
	for i := 0; i < DEFAULT_BUCKET_SIZE; i++ {
		timers[i] = time.NewTicker(DEFAULT_TIME_TICKER * time.Second)
		go waitTicker(timers[i], DEFAULT_BUCKET_NAME)
	}
}

func waitTicker(timer *time.Ticker, bucketName string) {
	for {
		select {
		case _ = <-timer.C:
			go tickHandler(bucketName)
			go flushHandler(bucketName)
		}
	}
}

// 扫描bucket，去除已过期的job
func flushHandler(bucketName string) {
	start := int64(0)
	end := time.Now().Unix() - 30
	bucketItems, err := getFromBucket(bucketName, start, end)
	if err != nil {
		utils.LogErrorF("扫描bucket错误#bucket-%s#%s", bucketName, err.Error())
		return
	}
	if bucketItems == nil {
		return
	}
	for _, item := range bucketItems {
		err := new(SystemTaskLog).Del(item)
		if err != nil && err != redis.Nil {
			utils.LogErrorF("移除Job元信息失败#bucket-%s#%s", bucketName, err.Error())
			continue
		}
		// job元信息不存在, 从bucket中删除
		removeFromBucket(bucketName, item)
		continue

	}
}

// 扫描bucket, 取出延迟时间小于当前时间的Job
func tickHandler(bucketName string) {
	start := time.Now().Unix()
	end := start + int64(DEFAULT_TIME_TICKER) - 1
	bucketItems, err := getFromBucket(bucketName, start, end)
	if err != nil {
		utils.LogErrorF("扫描bucket错误#bucket-%s#%s", bucketName, err.Error())
		return
	}
	// 集合为空
	if bucketItems == nil || len(bucketItems) == 0 {
		return
	}
	// 延迟时间小于等于当前时间, 取出Job元信息并放入ready queue
	for _, item := range bucketItems {
		job, err := new(SystemTaskLog).Pull(item)
		if err != nil {
			if err != redis.Nil {
				utils.LogErrorF("获取Job元信息失败#bucket-%s#%s", bucketName, err.Error())
				continue
			}
			go removeFromBucket(bucketName, item)
			continue
		}
		go job.PushMq()
	}

}
