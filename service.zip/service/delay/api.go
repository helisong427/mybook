package delay

import (
	"gamers/controller/response"
	"gamers/models/dbmodels"
	"gamers/utils"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/go-redis/redis"
)

type AddTaskReq struct {
	ExecuteTime *int64 `json:"execute_time" binding:"required"`
	TaskInfo    string `json:"task_info"`
	TaskType    *int   `json:"task_type" binding:"required"` // 0 即时执行 1 延时执行
	TaskTimeOut int64  `json:"task_time_out"`
	Topic       string `json:"topic" binding:"required"`
}
type GetTaskInfoReq struct {
	TaskId string `form:"task_id" binding:"required"`
}
type DelTaskReq struct {
	TaskId int64 `form:"task_id" binding:"required"`
}

type AddTaskTimeReq struct {
	TaskId   int64 `json:"task_id" binding:"required"`
	Duration int64 `json:"duration" binding:"required,min=1"`
}

const (
	TASK_TYPE_NOW   = iota // 即时执行
	TASK_TYPE_DELAY        // 延时执行
)

// 新增任务
func AddTask(c *gin.Context) {
	var form AddTaskReq
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	now := time.Now().Unix()
	if *form.TaskType == TASK_TYPE_DELAY && now >= *form.ExecuteTime {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "执行时间小于当前时间", "", "")
		return
	}
	job := dbmodels.SystemTaskLog{
		LogTaskId:          utils.FuncGenerateDataId(),
		LogTaskTopic:       form.Topic,
		LogTaskType:        *form.TaskType,
		LogTaskInfo:        form.TaskInfo,
		LogTaskExecuteTime: *form.ExecuteTime,
		LogTaskTimeoutTime: form.TaskTimeOut,
	}

	err = job.Create()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "创建任务失败", "", err.Error())
		return
	}

	task := SystemTaskLog{
		LogId:              job.LogId,
		LogTaskId:          utils.FuncGenerateDataId(),
		LogTaskTopic:       form.Topic,
		LogTaskInfo:        form.TaskInfo,
		LogTaskExecuteTime: *form.ExecuteTime,
		LogTaskTimeoutTime: form.TaskTimeOut,
	}
	// 如果是即时任务,立即推送
	if *form.TaskType == TASK_TYPE_NOW {
		err = task.PushMq()
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "创建任务失败", "", err.Error())
			return
		}
		response.ResponseOk(c, "ok", task)
		return
	}
	err = task.Push()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "创建任务失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "ok", task)
	return
}

// 获取任务
func GetTask(c *gin.Context) {
	var form GetTaskInfoReq
	err := c.ShouldBind(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	job, err := new(SystemTaskLog).Pull(form.TaskId)
	if err != nil && err != redis.Nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "获取task出错", "", err.Error())
		return
	}
	if err == redis.Nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "task不存在", "", "")
		return
	}
	response.ResponseOk(c, "ok", job)
	return
}

// 删除任务
func DelTask(c *gin.Context) {
	var form DelTaskReq
	err := c.ShouldBind(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	taskIdStr := strconv.Itoa(int(form.TaskId))
	_, err = new(SystemTaskLog).Pull(taskIdStr)
	if err != nil && err != redis.Nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "获取task出错", "", err.Error())
		return
	}
	if err == redis.Nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "task不存在", "", "")
		return
	}

	err = new(dbmodels.SystemTaskLog).Del(form.TaskId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "移除失败", "", err.Error())
		return
	}
	err = new(SystemTaskLog).Del(taskIdStr)
	if err != nil && err != redis.Nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "获取task出错", "", err.Error())
		return
	}
	if err == redis.Nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "task不存在", "", "")
		return
	}
	response.ResponseOk(c, "ok", nil)
	return
}

// 添加时间
func AddTime(c *gin.Context) {
	var form AddTaskTimeReq
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	taskIdStr := strconv.Itoa(int(form.TaskId))
	job, err := new(SystemTaskLog).Pull(taskIdStr)
	if err != nil && err != redis.Nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "获取task出错", "", err.Error())
		return
	}
	if err == redis.Nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "task不存在", "", "")
		return
	}
	err = new(dbmodels.SystemTaskLog).AddTime(form.TaskId, form.Duration)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "延迟时间失败", "", err.Error())
		return
	}

	err = job.AddTime(taskIdStr, form.Duration)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "延迟时间失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "延迟成功", job)
	return
}
