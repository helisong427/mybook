package delay

import (
	"gamers/middleware"
	"net/http"

	"github.com/gin-gonic/gin"
)

func RouterInit(engine *gin.Engine) *gin.Engine {
	// 内网路由
	localNetwork := engine.Group("/delay").Use(middleware.LocalNetwork())
	{
		localNetwork.POST("/add_task", AddTask)
		localNetwork.GET("/task-info", GetTask)
		localNetwork.GET("/del-task", DelTask)
		localNetwork.POST("/add-time", AddTime)
	}
	engine.GET("/livez", func(c *gin.Context) {
		c.String(http.StatusOK, "delay success!")
	})
	return engine
}
