package delay

import (
	"encoding/json"
	"errors"
	"fmt"
	"gamers/models/dbmodels"
	"gamers/utils"
	"strconv"
	"time"

	"github.com/go-redis/redis"
)

type SystemTaskLog struct {
	LogId                 int64  `gorm:"column:log_id" json:"log_id" binding:"required"`
	LogTaskId             string `gorm:"column:log_task_id" json:"log_task_id"` // 任务id，如果kafka则kafka
	LogTaskType           int    `gorm:"column:log_task_type" json:"log_task_type"`
	LogTaskTopic          string `gorm:"column:log_task_topic" json:"log_task_topic"`
	LogTaskFinishedStatus int64  `gorm:"column:log_task_finished_status" json:"log_task_finished_status"`
	LogTaskInfo           string `gorm:"column:log_task_info" json:"log_task_info"`
	LogTaskExecuteTime    int64  `gorm:"column:log_task_execute_time" json:"log_task_execute_time"`
	LogTaskTimeoutTime    int64  `gorm:"column:log_task_timeout_time" json:"log_task_timeout_time"`
}

const DEFAULT_BUCKET_NAME = "delayBucket"
const DEFAULT_BUCKET_SIZE = 1
const DEFAULT_JOB_POOL = "delayJob"

func (s *SystemTaskLog) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s SystemTaskLog) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

// 初始化task
func InitTasks() {
	value, err := utils.RedisClient.ZRange(DEFAULT_BUCKET_NAME, 0, 0).Result()
	if err != nil {
		utils.LogErrorF("初始化task失败，err:%s", err.Error())
		return
	}
	if len(value) == 0 {
		tasks, err := new(dbmodels.SystemTaskLog).GetTasksWithoutFinished()
		if err != nil {
			utils.LogErrorF("初始化task失败，err:%s", err.Error())
			return
		}
		for _, v := range tasks {
			t := SystemTaskLog{
				LogId:              v.LogId,
				LogTaskId:          v.LogTaskId,
				LogTaskTopic:       v.LogTaskTopic,
				LogTaskInfo:        v.LogTaskInfo,
				LogTaskTimeoutTime: v.LogTaskTimeoutTime,
				LogTaskExecuteTime: v.LogTaskExecuteTime,
				LogTaskType:        v.LogTaskType,
			}
			err = t.Push()
			if err != nil {
				utils.LogErrorF("初始化task失败，err:%s", err.Error())
				return
			}
		}
	}
}

// PUSH任务
func (task SystemTaskLog) Push() (err error) {
	if task.LogId <= 0 || task.LogTaskExecuteTime < 0 || task.LogTaskTimeoutTime < 0 {
		return errors.New("invalid job")
	}
	// 加锁
	delayLock := utils.REDIS_DELAY_LOCK + task.LogTaskId
	lock, isLock := utils.AcquireLock(delayLock, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, int(task.LogTaskExecuteTime-time.Now().Unix()))
	if !isLock {
		err = errors.New("任务已添加")
		return
	}
	// 释放锁
	defer utils.ReleaseLock(delayLock, lock)
	// 丢到job池
	IdStr := strconv.Itoa(int(task.LogId))
	err = utils.RedisClient.HSet(DEFAULT_JOB_POOL, IdStr, task).Err()
	if err != nil {
		utils.LogErrorF("添加job到job pool失败#job-%+v#%s", task, err.Error())
		return
	}

	// 添加到bucket
	err = utils.RedisClient.ZAdd(DEFAULT_BUCKET_NAME, redis.Z{Member: task.LogId, Score: float64(task.LogTaskExecuteTime)}).Err()
	if err != nil {
		utils.LogErrorF("添加job到bucket失败#job-%+v#%s", task, err.Error())
		return
	}
	return nil
}

// Pull 任务
func (task SystemTaskLog) Pull(taskId string) (data SystemTaskLog, err error) {
	err = utils.RedisClient.HGet(DEFAULT_JOB_POOL, taskId).Scan(&data)
	return
}

// del任务
func (task SystemTaskLog) Del(taskId string) (err error) {
	err = utils.RedisClient.HDel(DEFAULT_JOB_POOL, taskId).Err()
	return
}

// AddTime 添加任务时间
func (task *SystemTaskLog) AddTime(taskId string, time int64) (err error) {

	task.LogTaskExecuteTime += time
	pipeline := utils.RedisClient.Pipeline()
	err = pipeline.HSet(DEFAULT_JOB_POOL, taskId, task).Err()
	if err != nil {
		utils.LogErrorF("添加job到job pool失败#job-%+v#%s", task, err.Error())
		return
	}
	err = pipeline.ZIncrBy(DEFAULT_BUCKET_NAME, float64(time), taskId).Err()
	if err != nil {
		utils.LogErrorF("为任务[%s]新增时间出错,err:%s", taskId, err.Error())
		return
	}
	_, err = pipeline.Exec()
	if err != nil {
		return
	}
	return
}

// PushMq 添加Job到kafka队列
func (task SystemTaskLog) PushMq() (err error) {
	data, err := json.Marshal(&task)
	if err != nil {
		utils.LogErrorF("序列化task失败，err：%s", task.LogTaskTopic, err.Error())
		return
	}
	err = utils.KafkaSendMsg(task.LogTaskTopic, task.LogTaskId, data)
	if err != nil {
		utils.LogErrorF("推送消息到topic[%s]失败，err：%s", task.LogTaskTopic, err.Error())
		return
	}
	fmt.Println(string(data))
	fmt.Println("推送成功")
	return
}

// 从bucket中删除JobId
func removeFromBucket(bucket string, jobId string) error {
	err := utils.RedisClient.ZRem(bucket, jobId).Err()
	if err != nil {
		utils.LogErrorF("移除bucket[%s]的[]job失败，err:%s", bucket, jobId, err.Error())
	}
	return err
}

// 从bucket中获取延迟时间最小的JobId
func getFromBucket(key string, start, end int64) (data []string, err error) {
	startStr := strconv.Itoa(int(start))
	endStr := strconv.Itoa(int(end))
	value, err := utils.RedisClient.ZRangeByScore(key, redis.ZRangeBy{Min: startStr, Max: endStr}).Result()
	if err != nil {
		return nil, err
	}
	return value, nil

}
