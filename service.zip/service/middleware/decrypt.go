package middleware

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"gamers/controller/response"
	"io/ioutil"
	"net/url"
	"strings"

	"github.com/forgoer/openssl"
	"github.com/gin-gonic/gin"
)

type BodyData struct {
	Data string `json:"data"`
}

// splicingParameters 拼接query参数
func splicingParameters(data map[string]interface{}) (queryStr string) {
	for k, v := range data {
		queryStr += k + "=" + fmt.Sprintf("%v", v) + "&"
	}
	return
}

// interceptStr 截取字符串的一部分
func interceptStr(s string, start, end int) string {
	rs := []rune(s)
	return string(rs[start:end])
}

// getKeyAndEncryptData 从数据中获取key以及密文
func getKeyAndEncryptData(data string) (key []byte, encryptData string) {
	key = []byte(interceptStr(data, 11, 35))
	sEnc := interceptStr(data, 64, len(data))
	encryptData = interceptStr(sEnc, 0, len(sEnc)-20)
	return
}

// Decrypt 解密请求参数中间件
func Decrypt() gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Request.URL.RawQuery = strings.ReplaceAll(c.Request.URL.RawQuery, "+", "%2b")
		data := c.Query("data")
		if data != "" {
			data, err := url.PathUnescape(data)
			if err != nil {
				response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "", "", err.Error())
				c.Abort()
				return
			}
			key, encryptData := getKeyAndEncryptData(data)
			sDec, err := base64.StdEncoding.DecodeString(encryptData)
			if err != nil {
				response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "", "", err.Error())
				c.Abort()
				return
			}
			dst, err := openssl.Des3ECBDecrypt(sDec, key, openssl.PKCS7_PADDING)
			if err != nil {
				response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "", "", err.Error())
				c.Abort()
				return
			}
			var mapData map[string]interface{}
			if err = json.Unmarshal(dst, &mapData); err != nil {
				response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "", "", err.Error())
				c.Abort()
				return
			}
			c.Request.URL.RawQuery = splicingParameters(mapData)
		}
		bodyData := BodyData{}
		if err := c.ShouldBind(&bodyData); err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "", "", err.Error())
			c.Abort()
			return
		}
		if bodyData.Data != "" {
			key, encryptData := getKeyAndEncryptData(bodyData.Data)
			sDec, err := base64.StdEncoding.DecodeString(encryptData)
			if err != nil {
				response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "", "", err.Error())
				c.Abort()
				return
			}
			dst, err := openssl.Des3ECBDecrypt(sDec, key, openssl.PKCS7_PADDING)
			if err != nil {
				response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "", "", err.Error())
				c.Abort()
				return
			}
			c.Request.Body = ioutil.NopCloser(bytes.NewBuffer(dst))
		}
		c.Next()
	}
}
