package middleware

import (
	"fmt"

	"github.com/gin-gonic/gin"
	"github.com/tal-tech/go-zero/core/logx"

	"gamers/controller/response"
)

// Recovery 捕获异常
func Recovery() gin.HandlerFunc {
	return func(c *gin.Context) {
		defer func() {
			if err := recover(); err != nil {
				logx.Error(err)
				response.ResponseError(c, response.RESPONSE_UNKNOWN, "服务器错误", "", fmt.Sprintf("%s", err))
				c.Abort()
				return
			}
		}()
		c.Next()
	}
}
