package enum

// 订单评价态度(0好评 1差评)
const (
	LabelEvaluationPraise = iota
	LabelEvaluationBadReview
)

// 系统自动评价 (0不是 1是)
const (
	NotSystemEvaluation = iota
	IsSystemEvaluation
)

// 订单评论状态(0显示 1屏蔽 2折叠)
const (
	OrderEvaluationStateDisplay = iota
	OrderEvaluationStateShield
	OrderEvaluationStateFold
)

// 订单匿名
const (
	OrderEvaluationNotAnonymous = iota
	OrderEvaluationIsAnonymous
)

// 订单申述
const (
	OrderEvaluationNotRepresentation = iota
	OrderEvaluationIsRepresentation
)
