package enum

// 砸蛋配置类型(0金蛋 1银蛋)
const (
	EggBreakConfigTypeGold = iota
	EggBreakConfigTypeSilver
)
