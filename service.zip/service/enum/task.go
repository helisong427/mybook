package enum

// 任务完成条件标签 map[tag]desc
var TaskConditionTags = map[string]string{
	"checkinContinuous":             "连续签到",
	"openNotificationPermission":    "打开通知权限",
	"uploadImagePhoto":              "上传形象照",            // 1
	"applyForSparringAndPass1Skill": "申请大神并通过至少1项技能",    // 1
	"realNameAuthentication":        "完成实名认证",           // 1
	"editPersonalSignature":         "编辑个性签名",           // 1
	"eggBreakBreak":                 "砸蛋",               // 1
	"sendGift":                      "在直播间/派对房送礼",       // 1
	"stayInRoom10Minute":            "在直播间/派对房连续停留10分钟", // 1
	"finishOrder":                   "完成下单",             // 不需要结算 // 1
	"share":                         "分享",
	"followUserWithInterest":        "关注用户",      // 1
	"publishCircleOfFriend":         "发布动态（朋友圈）", // 1
	"commentCircleOfFriend":         "评论朋友圈",     // 1
	"likeCircleOfFriend":            "点赞朋友圈",
	"logInDaily":                    "每日登录",
}

// 任务完成条件标签（需要前端上报）
var TaskConditionTagsNeedReport = map[string]string{
	"openNotificationPermission": "打开通知权限",
	"share":                      "分享",
}

// 任务集合开启状态
const (
	TaskSetStatusClose = iota
	TaskSetStatusOpen
)

// 任务集合标记
const (
	TaskSetFlagNone              = iota // 通用任务集合
	TaskSetFlagCheckinContinuous        // 连续签到
)

// 任务集合检查模式
const (
	TaskSetVerifyModeForever = iota
	TaskSetVerifyModeDaily
)

// 任务集合内任务展示方式
const (
	TaskSetShowForever      = iota // 默认状态（一直展示）
	TaskSetShowHideAfterGet        // 任务领取后就隐藏
)

// 任务开启状态
const (
	TaskStatusClose = iota
	TaskStatusOpen
)

// 任务状态（进行中/已完成/已领取）
const (
	TaskStateInProgress = iota
	TaskStateFinish
	TaskStateGet
)
