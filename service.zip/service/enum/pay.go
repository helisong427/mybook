package enum

//支付方式
type PayType string

const (
	APP_PAY   PayType = "app_pay"   //app支付
	WAP_PAY   PayType = "wap_pay"   //网页支付
	JSAPI_PAY PayType = "jspai_pay" //微信公众号支付
)
