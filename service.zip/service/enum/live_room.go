package enum

//直播房间相关枚举
const (
	ROOM_SYSTEM_CLOSE_PARTY_TIME = 60 * 15 //系统关闭派对房延迟时间
)
