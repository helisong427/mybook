package controller

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/models/dbmodels"
	"gamers/utils"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// 账号上报
func Account(c *gin.Context) {
	var form request.AccountReportReq
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	var headerInfo request.ReportHeader
	err = c.ShouldBindHeader(&headerInfo)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	accountInfo := dbmodels.Action{
		ActionDevice:           form.DeviceId,
		ActionAppVersion:       headerInfo.Version,
		ActionBirthday:         form.Birthday,
		ActionChannel:          form.ChannelId,
		ActionCityId:           form.CityId,
		ActionCountryId:        form.CountryId,
		ActionDeviceBrand:      form.DeviceBrand,
		ActionDevicePattern:    form.DevicePattern,
		ActionGender:           form.Gender,
		ActionIp:               c.ClientIP(),
		ActionIsModifyInfo:     form.ModifyInfo,
		ActionLatitude:         form.Latitude,
		ActionLongitude:        form.Longitude,
		ActionMobile:           form.Mobile,
		ActionUserId:           form.UserId,
		ActionNickname:         form.Nickname,
		ActionPoint:            form.Point,
		ActionProvinceId:       form.ProvinceId,
		ActionRegionId:         form.ZoneId,
		ActionScreenResolution: form.ScreenResolution,
		ActionSystem:           *headerInfo.ClientType,
		ActionSystemVersion:    form.OsVersion,
		ActionUdid:             form.UDID,
		ActionRegTime:          0,
		ActionOperateId:        form.OperateId,
	}
	regTime := new(dbmodels.Action).GetRegTimeByUdid(form.UDID)
	accountInfo.ActionRegTime = regTime
	err = accountInfo.Create()
	if err != nil {
		utils.LogErrorF("新建设备【%s】注册信息失败,err:%s", form.UDID, err.Error())
	}
	response.ResponseOk(c, "ok", nil)
	return
}

// 登录登出
func LoginAndLogout(c *gin.Context) {
	var form request.LoginReportReq
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	var headerInfo request.ReportHeader
	err = c.ShouldBindHeader(&headerInfo)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	loginReport := dbmodels.Login{
		LoginAppVersion:       headerInfo.Version,
		LoginBirthday:         form.Birthday,
		LoginChannel:          form.ChannelId,
		LoginCityId:           form.CityId,
		LoginCountryId:        form.CountryId,
		LoginDevice:           form.DeviceId,
		LoginDeviceBrand:      form.DeviceBrand,
		LoginDevicePattern:    form.DevicePattern,
		LoginGender:           form.Gender,
		LoginHometownId:       form.HometownId,
		LoginInternet:         form.InternetType,
		LoginIp:               c.ClientIP(),
		LoginIsAnchor:         form.IsAnchor,
		LoginIsSparring:       form.IsSparring,
		LoginLatitude:         form.Latitude,
		LoginLongitude:        form.Longitude,
		LoginMobile:           form.Mobile,
		LoginNickname:         form.Nickname,
		LoginOnlineTimes:      form.OnlineDuration,
		LoginPoint:            form.Point,
		LoginProvinceId:       form.ProvinceId,
		LoginRegionId:         form.ZoneId,
		LoginRegTime:          form.UserRegTime,
		LoginRoomStatus:       form.RoomStatus,
		LoginScreenResolution: form.ScreenResolution,
		LoginStatus:           form.LoginStatus,
		LoginSystem:           *headerInfo.ClientType,
		LoginSystemVersion:    form.OsVersion,
		LoginUdid:             form.UDID,
		LoginUnionId:          form.UnionId,
		LoginUserId:           form.UserId,
		LoginVipLevel:         form.VipLevel,
	}
	err = loginReport.Create()
	if err != nil {
		utils.LogErrorF("新建设备【%s】登录信息失败,err:%s", form.UDID, err.Error())
	}
	response.ResponseOk(c, "ok", nil)
	return
}

// 广告api上报
func ReportAd(c *gin.Context) {
	var form request.AdReportReq
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	form.Ip = c.ClientIP()
	// 查询是否有数据
	channelInfo, err := new(dbmodels.AppUserChannel).GetChannelById(form.ChannelId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取渠道信息失败", "", err.Error())
		return
	}
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "渠道信息不存在", "", "")
		return
	}
	if channelInfo.ChannelKey == dbmodels.CHANNEL_KEY_WEISIDUN || channelInfo.ChannelKey == dbmodels.CHANNEL_KEY_SHUANGSHENG { //b站
		err = services.BiliBiliReport(&form)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, err.Error(), "", "")
			return
		}
	} else if channelInfo.ChannelKey == dbmodels.CHANNEL_KEY_TUIA { //推啊
		err = services.TuiAReport(&channelInfo, &form)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, err.Error(), "", "")
			return
		}
	} else if channelInfo.ChannelKey == dbmodels.CHANNEL_KEY_YIMI { //亿米平台
		err = services.YiMiReport(&channelInfo, &form)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, err.Error(), "", "")
			return
		}
	} else if channelInfo.ChannelKey == dbmodels.CHANNEL_KEY_HUAWEI { //华为平台
		err = services.HuaWeiReport(&channelInfo, &form)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, err.Error(), "", "")
			return
		}
	} else {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "未知渠道信息", "", "")
		return
	}
	response.ResponseOk(c, "ok", nil)
	return
}
