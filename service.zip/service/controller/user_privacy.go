/**
 * @Author: panke
 * @Description: 用户隐私设置
 * @File: user_privacy
 * @Date: 2021/5/17 18:13
 */

package controller

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/utils"
	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
)

// 更新用户隐私设置
func PrivacyUpdate(c *gin.Context) {
	userId := utils.FuncUserId(c)
	req := request.UserPrivacyUpdateReq{}
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	isBinding, err := services.UserPrivacyUpdate(userId, req)
	if err != nil {
		if isBinding {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, err.Error(), "", "")
		} else {
			utils.Logger.Error("隐私设置失败", zap.Error(err))
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "隐私设置失败", "", "")
		}
		return
	}
	response.ResponseOk(c, "隐私设置成功", *req.PushValue)
}

// 获取用户隐私设置
func PrivacyGet(c *gin.Context) {
	userId := utils.FuncUserId(c)
	setting, err := services.UserPrivacyGet(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户隐私设置错误", "", "")
		return
	}
	response.ResponseOk(c, "获取成功", setting)
}
