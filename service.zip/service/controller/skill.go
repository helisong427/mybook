package controller

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/controller/services/recommend"
	"gamers/models/dbmodels"
	"gamers/utils"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
	"strconv"
)

// 陪玩控制器
// 游戏列表
func SparringSkillList(c *gin.Context) {
	model := dbmodels.AppSkill{}
	userId := utils.FuncUserId(c)
	skills, err := model.GetSkillListByUserId(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	gameList := response.SkillListResp{SkillType: dbmodels.SKILL_TYPE_GAME}
	otherList := response.SkillListResp{SkillType: dbmodels.SKILL_TYPE_ENTERTAINMENT}
	for _, v := range skills {
		if v.SkillType == dbmodels.SKILL_TYPE_GAME {
			gameList.SkillItems = append(gameList.SkillItems, v)
		} else if v.SkillType == dbmodels.SKILL_TYPE_ENTERTAINMENT {
			otherList.SkillItems = append(otherList.SkillItems, v)
		}
	}
	data := append([]response.SkillListResp{}, gameList, otherList)
	response.ResponseOk(c, "ok", data)
	return
}

// 技能详情
func GetSparringSkillInfo(c *gin.Context) {
	id := c.Query("id")
	model := dbmodels.AppSkill{}
	gameId, err := strconv.Atoi(id)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "Id有误", "", err.Error())
		return
	}
	game, err := model.QueryBySkillId(int64(gameId))
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if err == gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "技能不存在", "", "")
		return
	}
	response.ResponseOk(c, "ok", game)
	return
}

// 获取大神详情
func SparringDetail(c *gin.Context) {
	var (
		msg string
	)

	userId := utils.FuncUserId(c)
	paramsJSON := request.SparringDetailReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}

	info, err := services.SparringDetail(paramsJSON.SparringId, userId)

	if err != nil {
		if info.SkillStatus == dbmodels.SPARRING_SKILL_STATUS_OFF {
			msg = "大神当前技能未开启"
		} else {
			msg = "用户不存在或已冻结"
		}

		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}
	response.ResponseOk(c, "获取详情成功", info)
	return
}

// 获取大神列表
func SparringList(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.SparringListReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}

	list, err := services.SparringList(paramsJSON, userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取列表成功", list)
	return
}

// 大神下单前
func SparringBeforePlacingOrder(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.SparringBeforePlacingOrderReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}
	order, err := services.SparringBeforePlacingOrder(paramsJSON.SparringId, userId)
	if err != nil {
		if order.SkillStatus == 0 {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "该技能已下线, 暂时无法下单", "", err.Error())
		} else {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "用户不存在或已冻结", "", err.Error())
		}
		return
	}
	response.ResponseOk(c, "获取大神下单前参数成功", order)
	return
}

// 我的技能
func SparringMySkill(c *gin.Context) {
	userId := utils.FuncUserId(c)
	list, err := services.SparringMySkill(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "我的技能列表", list)
	return
}

// 修改技能状态
func SparringUpdateSkillStatus(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.SparringUpdateSkillStatusReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}
	if paramsJSON.SkillStatus < dbmodels.SPARRING_SKILL_STATUS_OK || paramsJSON.SkillStatus > dbmodels.SPARRING_SKILL_STATUS_OFF {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "非法参数", "", "")
		return
	}

	// 查询技能
	first, err := new(dbmodels.AppSparringSkill).QueryFirst(paramsJSON.SparringId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "技能不存在", "", err.Error())
		return
	}
	if first.SkillUserID != userId {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "技能不属于该用户", "", "")
		return
	}

	if first.SkillSetInfoStatus != dbmodels.SPARRING_SKILL_SET_INFO_STATUS_OK {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "请先填写服务信息", "", "")
		return
	}

	model := &dbmodels.AppSparringSkill{}
	// model.SkillStatus = paramsJSON.SkillStatus
	// model.SkillSpeedMatchingStatus = paramsJSON.SkillSpeedMatchingStatus
	// model.SkillMsgStatus = paramsJSON.SkillMsgStatus
	if paramsJSON.SkillStatus == 4 {
		paramsJSON.SkillSpeedMatchingStatus = 0
		paramsJSON.SkillMsgStatus = 0
	}

	if paramsJSON.SkillSpeedMatchingStatus == 0 {
		paramsJSON.SkillMsgStatus = 0
	}
	err = model.UpdateBySkillId(paramsJSON.SparringId, map[string]interface{}{
		"skill_status":                paramsJSON.SkillStatus,
		"skill_speed_matching_status": paramsJSON.SkillSpeedMatchingStatus,
		"skill_msg_status":            paramsJSON.SkillMsgStatus,
	})
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	// 删除推荐缓存
	if paramsJSON.SkillStatus == dbmodels.SPARRING_SKILL_STATUS_OFF {
		go recommend.NewSparring().RemoveCache(first.SkillID, first.SkillSkillID)
	}

	// 恢复 推荐缓存
	if paramsJSON.SkillStatus == dbmodels.SPARRING_SKILL_STATUS_OK {
		go recommend.NewSparring().RecoverCache(first.SkillID, first.SkillSkillID)
	}

	response.ResponseOk(c, "修改技能状态成功", nil)
	return
}
