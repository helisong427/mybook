package controller

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/utils"
	"github.com/gin-gonic/gin"
)

//提现主页
func WithdrawHome(c *gin.Context) {
	userId := utils.FuncUserId(c)
	r, err := services.WithdrawHome(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取提现信息失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取提现信息成功", r)
	return
}

//提现绑定银行卡
func WithdrawBindBankCard(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.WithdrawBindBankCardReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}
	msg, err := services.WithdrawBindBankCard(userId, paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}
	response.ResponseOk(c, "绑定成功", nil)
}

//提现绑定支付宝
func WithdrawBindAlipay(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.WithdrawBindAlipayReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}
	msg, err := services.WithdrawBindAlipay(userId, paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}
	response.ResponseOk(c, "绑定成功", nil)
}

//提交提现申请
func WithdrawSubmit(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.WithdrawSubmitReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}
	if paramsJSON.WithdrawAmount%100 > 0 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", "")
		return
	}
	msg, err := services.WithdrawSubmit(userId, paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}
	response.ResponseOk(c, "提交成功", nil)
}
