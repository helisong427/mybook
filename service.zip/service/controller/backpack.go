package controller

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/models/dbmodels"
	"gamers/utils"
	"gamers/utils/prop"
	"github.com/gin-gonic/gin"
	"sort"
)

// 获取背包列表
func GetBackpackList(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var req = request.BackpackListReq{}
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	var data, err = (&dbmodels.AppBackpack{}).Query(userId, prop.Type(req.BackpackPropType))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取失败", "", err.Error())
		return
	}

	// 保证金银顺序
	sort.Slice(data, func(i, j int) bool {
		return data[i].BackpackPropId < data[j].BackpackPropId
	})
	response.ResponseOk(c, "获取成功", &data)
}

// 获取锤子列表
func GetHammerList(c *gin.Context) {
	userId := utils.FuncUserId(c)

	var req = request.BackpackHammerListReq{}
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	var data, err = (&dbmodels.AppBackpack{}).QueryByPropId(userId, req.BackpackPropId, prop.Type(req.BackpackPropType))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取成功", &data)
}
