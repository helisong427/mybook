package controller

import (
	"github.com/gin-gonic/gin"

	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/utils"
)

// 获取任务数据（任务中心）
func TaskGetListTaskCenter(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var data, err = services.TaskGetListTaskCenter(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取任务数据失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取任务数据成功", &data)
}

// 获取任务数据（签到任务）`
func TaskGetListCheckinContinuous(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var data, err = services.TaskGetListCheckinContinuous(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取签到数据失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取签到数据成功", &data)
}

// 上报前端任务完成条件行为来触发任务
func TaskReportCondition(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var req request.TaskReportCondition
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	if err := services.TaskReportCondition(userId, &req); err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "上报处理失败", "", err.Error())
		return
	}

	response.ResponseOk(c, "上报处理成功", nil)
}

// 领取奖励
func TaskGetReward(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var req request.TaskGetReward
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	var data, msg, err = services.TaskGetReward(userId, req.SetID, req.TaskID)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}

	response.ResponseOk(c, "领取成功", data)
}

// 连续签到
func TaskCheckin(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var req request.TaskGetReward
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	var data, msg, err = services.TaskCheckin(userId, req.SetID, req.TaskID)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}

	response.ResponseOk(c, "签到成功", data)
}
