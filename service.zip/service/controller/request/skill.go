package request

// 大神详情
type SparringDetailReq struct {
	SparringId int `form:"sparring_id" binding:"required"` // 大神id
}

// 大神列表
type SparringListReq struct {
	BasePageReq
	SkillId        int    `form:"skill_id" binding:"omitempty,min=0"`            // 技能id
	Sex            int    `form:"sex" binding:"omitempty,min=0,max=2"`           // 性别
	SelectOnline   int    `form:"select_online" binding:"omitempty,min=0,max=2"` // 筛选在线状态:0--全部,1--离线,2--在线
	OtherCondition string `form:"other_condition"`                               // 其他条件,分割
}

// 大神下单前
type SparringBeforePlacingOrderReq struct {
	SparringId int `form:"sparring_id" binding:"required"` // 大神id
}

// 切换大神技能状态
type SparringUpdateSkillStatusReq struct {
	SparringId               int64 `json:"sparring_id" binding:"required"`                              // 大神技能id
	SkillStatus              int   `json:"skill_status" binding:"required"`                             // 切换的状态
	SkillSpeedMatchingStatus int64 `json:"skill_speed_matching_status" binding:"omitempty,min=0,max=1"` // 抢单开关(0关闭,1开启)
	SkillMsgStatus           int64 `json:"skill_msg_status" binding:"omitempty,min=0,max=1"`            // 抢单消息(0关闭,1开启)
}
