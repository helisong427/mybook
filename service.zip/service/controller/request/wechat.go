package request

// 公众号获取AccessToke地址
type WechatAccessTokeUrlReq struct {
	Code string `form:"code" json:"code" binding:"required"`
}

type WechatBindingReq struct {
	Openid      string `json:"openid" binding:"required"`       // 微信用户的openid
	PhoneNumber string `json:"phone_number" binding:"required"` // 手机号
	Code        int    `json:"code" binding:"required"`         // 验证码
}

type GetWechatBindingReq struct {
	Openid string `json:"openid" binding:"required"` // 微信用户的openid
}

type WechatUnBindingReq struct {
	UserId      int64  `json:"user_id" binding:"required"`      // 用户ID
	PhoneNumber string `json:"phone_number" binding:"required"` // 手机号
	Openid      string `json:"openid" binding:"required"`       // 微信用户的openid
	Hash        string `json:"hash" binding:"required"`
}
