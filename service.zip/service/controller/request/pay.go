package request

// app下单
type PlaceOrderReq struct {
	Cash       int64 `json:"cash" binding:"required"`
	FromSystem int   `json:"from_system" binding:"omitempty,min=1,max=2"` // 来源系统:1--安卓,2--iOS
	FromWay    int   `json:"from_way" binding:"omitempty,min=0,max=2"`    // 充值来源:0--原生,1--公众号,2--网页
}

// 宝付app下单
type PlaceOrderBaofuReq struct {
	Cash       int64 `json:"cash" binding:"required"`
	FromSystem int   `json:"from_system" binding:"omitempty,min=1,max=2"` // 来源系统:1--安卓,2--iOS
	FromWay    int   `json:"from_way" binding:"omitempty,min=0,max=2"`    // 充值来源:0--原生,1--公众号,2--网页
	PayType    int   `json:"pay_type" binding:"omitempty,min=1,max=9"`    // 充值来源:1-ALI_H5:支付宝-H5支付,
	//2-ALI_NATIVE:支付宝-扫码支付,
	//3-ALI_APP:支付宝-APP支付,
	//4-ALI_APPLET:支付宝-小程序支付
	//5-WECHAT_H5:微信-H5支付
	//6-WECHAT_APP:微信-APP支付
	//7-WECHAT_NATIVE:微信-扫码支付
	//8-WECHAT_JSAPI:微信-公众号支付
	//9-WECHAT_APPLET:微信-小程序支付
}

type ApplePlaceOrderReq struct {
	ProductId  string `json:"product_id"  binding:"required"`              // 支付product_id
	FromSystem int    `json:"from_system" binding:"omitempty,min=1,max=2"` // 来源系统:1--安卓,2--iOS
	FromWay    int    `json:"from_way" binding:"omitempty,min=0,max=2"`    // 充值来源:0--原生,1--公众号,2--网页
}

// 网页-微信下单
type WapPlaceOrderWechatReq struct {
	Cash       int64 `json:"cash" binding:"required"`
	UserId     int64 `json:"user_id" binding:"required"`                  // 用户id
	FromSystem int   `json:"from_system" binding:"omitempty,min=1,max=2"` // 来源系统:1--安卓,2--iOS
	FromWay    int   `json:"from_way" binding:"omitempty,min=0,max=2"`    // 充值来源:0--原生,1--公众号,2--网页
}

// 网页-微信公众号下单
type JsapiPlaceOrderWechat struct {
	Cash       int64  `json:"cash" binding:"required"`
	UserId     int64  `json:"user_id" binding:"required"`                  // 用户id
	Openid     string `json:"openid"  binding:"required"`                  // openid
	FromSystem int    `json:"from_system" binding:"omitempty,min=1,max=2"` // 来源系统:1--安卓,2--iOS
	FromWay    int    `json:"from_way" binding:"omitempty,min=0,max=2"`    // 充值来源:0--原生,1--公众号,2--网页
}

// 支付宝网页下单
type WapPlaceOrderAlipayReq struct {
	Cash       int64 `json:"cash" binding:"required"`
	UserId     int64 `json:"user_id" binding:"required"`                  // 用户id
	FromSystem int   `json:"from_system" binding:"omitempty,min=1,max=2"` // 来源系统:1--安卓,2--iOS
	FromWay    int   `json:"from_way" binding:"omitempty,min=0,max=2"`    // 充值来源:0--原生,1--公众号,2--网页
}

// 苹果支付验证收据
type ApplePayVerifyReceiptReq struct {
	ReceiptData   string `json:"receipt_data" binding:"required"`   // 收据数据
	OutTradeNo    int64  `json:"out_trade_no" binding:"required"`   // 商户单号
	TransactionId string `json:"transaction_id" binding:"required"` // 苹果交易号
	ProductId     string `json:"product_id" binding:"required"`     // 苹果product_id
}

// 支付结果查询
type PayResultQueryReq struct {
	OutTradeNo int64 `form:"out_trade_no" binding:"required"` // 商户单号
}
