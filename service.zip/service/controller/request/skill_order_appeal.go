package request

//大神订单申诉
type SkillAppealReq struct {
	OrderId int64    `json:"order_id" binding:"required"` //订单id
	Reason  string   `json:"reason" binding:"required"`   //申诉原因
	Remark  string   `json:"remark" binding:"required"`   //申诉说明
	Images  []string `json:"images" binding:"required"`   //凭证图片
}

type SkillSparringAppealReq struct {
	OrderId int64    `json:"order_id" binding:"required"` // 订单id
	Remark  string   `json:"remark" binding:"required"`   // 申诉说明
	Images  []string `json:"images" binding:"required"`   // 凭证图片
}
