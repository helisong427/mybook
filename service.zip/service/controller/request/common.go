package request

//文字审核
type TextModerationReq struct {
	Text string `form:"text" binding:"required"` //文字
}
