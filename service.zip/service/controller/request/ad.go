package request

//广告详情
type AdListReq struct {
	AdPositionID int64 `form:"adpositionid"`
	ShowCount    int64 `form:"showcount"`
}
