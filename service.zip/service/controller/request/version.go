package request

type GetVersionInfoReq struct {
	ClientType *int   `header:"Client-Type" binding:"required"`
	Version    string `header:"App-Version" binding:"required,max=100"`
}
