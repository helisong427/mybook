package request

type WeekStarRankListSearch struct {
	PropId     *int64 `json:"prop_id" binding:"required"`     // 礼物ID
	UserId     *int64 `json:"user_id" binding:"required"`     // 用户ID
	SearchType *int64 `json:"search_type" binding:"required"` // 查询类型 1 为财富榜 2为 魅力榜
}
