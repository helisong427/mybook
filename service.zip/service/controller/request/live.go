package request

const (
	GIFT_SOURCE_BACKPACK = iota
	GIFT_SOURCE_NORMAL
)

type SwitchLoveReq struct {
	Switch int `json:"switch" binding:"omitempty,min=0,max=1"` //开关:0--关,1--开
	RoomId int `json:"room_id" binding:"required"`             //房间id
}

//上下麦位
type UpAndDownWheatReq struct {
	RoomId         int `json:"room_id" binding:"required"`                        //房间id
	WheatKey       int `json:"wheat_key" binding:"omitempty,min=0,max=8"`         //麦位key,1-8
	UpAndDownWheat int `json:"up_and_down_wheat" binding:"omitempty,min=0,max=1"` //上下麦位:0--下麦，1--上麦
}

// 邀请上麦
type InviteUpWheatReq struct {
	RoomId   int `json:"room_id" binding:"required"`                //房间id
	UserId   int `json:"user_id" binding:"required"`                // 用户id
	WheatKey int `json:"wheat_key" binding:"omitempty,min=0,max=8"` //麦位key,1-8
}

type LockAndUnlockWheatReq struct {
	RoomId             int `json:"room_id" binding:"required"`                            //房间id
	WheatKey           int `json:"wheat_key" binding:"omitempty,min=1,max=8"`             //麦位key,1-8
	LockAndUnlockWheat int `json:"lock_and_unlock_wheat" binding:"omitempty,min=0,max=1"` //解锁/锁定 麦位:0--解锁，1--锁定
}

type UpdateWheatQueueReq struct {
	RoomId int `json:"room_id" binding:"required"`             //房间id
	Action int `json:"action" binding:"omitempty,min=0,max=2"` //操作:0--删除,1--增加,2--清空
}

type GetWheatReq struct {
	RoomId int `form:"room_id" binding:"required"` //房间id
}

type GetWheatQueueListReq struct {
	RoomId int `form:"room_id" binding:"required"` // 房间id
}

// 送礼
type SendGiftReq struct {
	RoomId      int   `json:"room_id" binding:"required"`            // 房间id
	GiftId      int64 `json:"gift_id"`                               // 礼物id
	GiftNum     int   `json:"gift_num" binding:"required"`           // 礼物数量
	GiftSource  *int  `json:"gift_source" binding:"required"`        // 是否是背包礼物
	ReceiverIDS []int `json:"receiver_ids" binding:"required,min=1"` // 接收对象
}

// 赠送礼物
type SendPropReq struct {
	RoomId      int64   `json:"room_id" binding:"required"`            // 房间id
	PropId      int64   `json:"prop_id"`                               // 礼物id
	BackpackId  int64   `json:"backpack_id"`                           // 背包id
	PropCount   int64   `json:"prop_count" binding:"required,min=1"`   // 礼物数量
	PropSource  *int    `json:"prop_source" binding:"required"`        // 是否是背包礼物
	ReceiverIDS []int64 `json:"receiver_ids" binding:"required,min=1"` // 接收对象
}

const (
	SEND_PROP_TYPE_BACKPACK = iota // 背包
	SEND_PROP_TYPE_NORMAL          // 普通赠送
)

type HodUpAndOnWheatReq struct {
	RoomId   int `json:"room_id" binding:"required"`                //房间id
	UpUserId int `json:"up_user_id" binding:"omitempty,min=0"`      //上麦用户id
	WheatKey int `json:"wheat_key" binding:"omitempty,min=1,max=8"` //麦位key,1-8
	Action   int `json:"action" binding:"omitempty,min=0,max=1"`    //动作:0--下麦,1--上麦
}

type SetAdminReq struct {
	RoomId      int  `json:"room_id" binding:"required"`                 //房间id
	AdminUserId int  `json:"admin_user_id" binding:"required"`           //用户id
	AdminLevel  *int `json:"admin_level" binding:"required,min=1,max=2"` //设置的管理员级别:1--副管理员,2--管理员
}

type CancelAdminReq struct {
	RoomId        int    `json:"room_id" binding:"required"`         //房间id
	AdminUserId   int    `json:"admin_user_id" binding:"required"`   //用户id
	AdminNickName string `json:"admin_nick_name" binding:"required"` //管理员昵称
}

type AdminListReq struct {
	RoomId int `form:"room_id" binding:"required"` //房间id
}

type AdminUpAndDownWheatReq struct {
	RoomId int `json:"room_id" binding:"required"`             //房间id
	Action int `json:"action" binding:"omitempty,min=0,max=1"` //动作:0--下麦,1--上麦
}

// 禁言
type MuteReq struct {
	RoomId   int64 `json:"room_id" binding:"required"`        // 房间id
	UserId   int64 `json:"user_id" binding:"required"`        // 用户id
	Duration int64 `json:"duration" binding:"required,min=1"` // 时长 秒
}

// 黑名单
type ForbiddenUserReq struct {
	RoomId int64 `json:"room_id" binding:"required"` // 房间id
	UserId int64 `json:"user_id" binding:"required"` // 用户id
}

type LiveSwitchWheatReq struct {
	RoomId int `json:"room_id" binding:"required"`             //房间id
	Switch int `json:"switch" binding:"omitempty,min=0,max=1"` //开关:0--关,1--开
}

type LiveRoomBeforeToCheckReq struct {
	RoomId int `json:"room_id" binding:"required"` //房间id
}

type LiveConfirmToDownloadReq struct {
	RoomId int `json:"room_id" binding:"required"` //房间id
}

type LiveBackgroundReq struct {
	AttrId int `form:"attr_id" binding:"required"` //直播属性id
}

//禁麦
type LiveBanWheatReq struct {
	RoomId   int `json:"room_id" binding:"required"`                //房间id
	WheatKey int `json:"wheat_key" binding:"omitempty,min=0,max=8"` //麦位key,0-8
	Action   int `json:"action" binding:"omitempty,min=0,max=2"`    //动作:0--取消禁麦,2--禁麦
}

// 退出直播间
type QuitLive struct {
	RoomId int64 `json:"room_id" binding:"required"` //房间id
}

// 加入直播间
type JoinLive struct {
	RoomId int64 `json:"room_id" binding:"required"` //房间id
}

// 接受上麦
type AcceptUpWheatReq struct {
	RoomId int64 `json:"room_id" binding:"required"` //房间id
}
