/**
 * @Author: panke
 * @Description: 用户隐私设置
 * @File: user_privacy
 * @Date: 2021/5/17 18:16
 */

package request

const (
	PUSH_ONLINE = 0
	PUSH_DIRECT = 1
	PUSH_RAND   = 2
)

type UserPrivacyUpdateReq struct {
	// UserOnlineMessagePush *int `json:"user_online_message_push" binding:"omitempty,min=0,max=1"` // 用户上线消息推送(0推送 1不推送)
	// DirectOrderPush       *int `json:"direct_order_push" binding:"omitempty,min=0,max=1"`        // 公众号定向单推送(0推送 1不推送)
	// RandomOrderPush       *int `json:"random_order_push" binding:"omitempty,min=0,max=1"`        // 公众号随机单推送(0推送 1不推送)

	PushType  *int `json:"push_type" binding:"omitempty,min=0,max=2"`  // 推送开关类型：0用户上线消息推送，1公众号定向单推送，2公众号随机单推送
	PushValue *int `json:"push_value" binding:"omitempty,min=0,max=1"` // 推送开关值（0推送 1不推送）
}
