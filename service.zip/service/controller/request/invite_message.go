package request

// InviteMessageReq 撩一撩邀请消息请求结构体
type InviteMessageReq struct {
	ReviewID int64  `json:"review_id"`                  // 撩一撩邀请消息审查表id
	PrettyID int64  `json:"pretty_id"`                  // 用户靓号
	NickName string `json:"nickname"`                   // 用户昵称
	Content  string `json:"content" binding="required"` // 撩一撩邀请消息内容
}
