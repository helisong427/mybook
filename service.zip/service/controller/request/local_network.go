package request

// 发送直播消息
type LocalLiveMsgReq struct {
	RoomId int    `json:"room_id" binding:"required"` // 房间id
	Reason string `json:"reason"`
	EndT   int64  `json:"end_t"`
	Func   string `json:"func" binding:"required"` // 调用方法名称
}

type LocalJoinUnionMsgReq struct {
	UserId    int64  `json:"user_id"  binding:"required"`
	ApplyTime int64  `json:"apply_time"  binding:"required"`
	UnionName string `json:"union_name"  binding:"required"`
	Func      string `json:"func" binding:"required"` // 调用方法名称
}

type LocalTextMsgReq struct {
	UserIdString string `json:"userid"  binding:"required"`
	Message      string `json:"message"  binding:"required"`
}

type LocalSparringReviewMsgReq struct {
	UserId    string `json:"userid"  binding:"required"`
	SkillName string `json:"skillname"  binding:"required"`
	Reason    string `json:"reason"`
	QQ        string `json:"qq"`
	Func      string `json:"func" binding:"required"` // 调用方法名称
}

type LocalAnchorReviewMsgReq struct {
	UserId    string `json:"userid"  binding:"required"`
	SkillName string `json:"skillname"  binding:"required"`
	Url       string `json:"url"`
	ApplyT    int64  `json:"applyt"  binding:"required"`
	Func      string `json:"func" binding:"required"` // 调用方法名称
}

type LocalTransactionIdReq struct {
	UserId string `json:"userid"  binding:"required"`
}

type LocalOrderAppealMsgReq struct {
	UserId  string `json:"userid"  binding:"required"`
	OrderId string `json:"orderid"  binding:"required"`
	Amount  int    `json:"amount"  binding:"required"`
	Func    string `json:"func" binding:"required"` // 调用方法名称
}

type LocalTweetRefuseMsgReq struct {
	UserId    string `json:"userid"  binding:"required"`
	CheckTime int64  `json:"checktime"  binding:"required"`
}
type LocalMaterialRefuseMsgReq struct {
	UserId    string `json:"userid"  binding:"required"`
	CheckTime int64  `json:"checktime"  binding:"required"`
}

type LocalStudioRefuseMsgReq struct {
	UserId    string `json:"userid"  binding:"required"`
	CheckTime int64  `json:"checktime"  binding:"required"`
}
type LocalSparringForbiddenMsgReq struct {
	UserId    string `json:"userid"  binding:"required"`
	QQ        string `json:"qq"`
	SkillName string `json:"skillname"  binding:"required"`
}
type LocalExtractFailMsgReq struct {
	UserId    string `json:"userid"  binding:"required"`
	NickName  string `json:"nickname"  binding:"required"`
	ApplyTime int64  `json:"apply_time"`
	Tips      string `json:"tips"  binding:"required"`
}

type LocalExtractSuccessMsgReq struct {
	UserId    string `json:"userid"  binding:"required"`
	ApplyTime int64  `json:"applytime"  binding:"required"`
}

// LocalInviteMessageRejectMsgReq 通过gogo助手发送给用户之前提交的撩一撩邀请消息审核不通过的请求体
type LocalInviteMessageRejectMsgReq struct {
	UserID string `json:"userid" binding:"required"`
	Reason string `json:"reason" binding:"required"`
}
