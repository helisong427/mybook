package request

//身份证认证
type CardVerificationReq struct {
	IdCard string `json:"id_card" binding:"required"` //身份证号码
	Name   string `json:"name" binding:"required"`    //姓名
}

//大神技能管理参数
type UpdateSparringServiceReq struct {
	SparringSkillID int64    `json:"sparring_skill_id"` //游戏id
	Wechat          string   `json:"wechat"`
	QQ              string   `json:"qq"`
	SkillPriceIds   []int64  `json:"skill_price_ids" binding:"required"`
	SkillFields     []SField `json:"skill_fields" binding:"required"`
}
type SField struct {
	SkillField       string  `json:"skill_field" binding:"required"`        //服务价格单位
	SkillFieldValues []int64 `json:"skill_field_values" binding:"required"` //价格值(价格时使用)
}

type UpdateSparringVerificationReq struct {
	SparringSkillID int64            `json:"sparring_skill_id" binding:"required"`  // 游戏id
	SkillProveImage string           `json:"skill_prove_image" binding:"required"`  // 认证图
	SkillValues     map[string]int64 `json:"skill_values" binding:"required"`       // 技能info key values
	SkillSound      string           `json:"skill_sound"`                           // 声音介绍
	SkillSoundTime  int64            `json:"skill_sound_time"`                      // 声音介绍时长，单位秒
	SkillInfo       string           `json:"skill_info" binding:"required,max=250"` // 介绍
	SparringIconurl string           `json:"sparring_iconurl" binding:"required"`   // 认证头像
}

// 大神认证
type SparringSkillReq struct {
	SkillID         int64            `json:"skill_id" binding:"required"`           // 游戏id
	SkillProveImage string           `json:"skill_prove_image" binding:"required"`  // 认证图
	SkillValues     map[string]int64 `json:"skill_values" binding:"required"`       // 技能info key values
	SkillSound      string           `json:"skill_sound"`                           // 声音介绍
	SkillSoundTime  int64            `json:"skill_sound_time"`                      // 声音介绍时长，单位秒
	SkillInfo       string           `json:"skill_info" binding:"required,max=250"` // 介绍
	SparringIconurl string           `json:"sparring_iconurl" binding:"required"`   // 认证头像
}

type GetSkillInfoReq struct {
	SkillSkillID int64 `form:"sparring_skill_id" binding:"required"` //游戏Id
}

// 人脸识别请求
type FaceVerificationReq struct {
	SparringIconurl string `json:"sparring_iconurl" binding:"required"`
}

// 大神收益明细
type QuerySparringIncome struct {
	StartT int64 `form:"start_t"`
	EndT   int64 `form:"end_t"`
}

//是否接单
type IsOrder struct {
	SkillId     int64 `json:"skill_id" binding:"required"`     //技能id
	SkillStatus int   `json:"skill_status" binding:"required"` //需要改的技能状态
}
