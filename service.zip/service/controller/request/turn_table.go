/**
 * @Author: panke
 * @Description:
 * @File: turn_table
 * @Date: 2021/4/22 15:51
 */

package request

import "gamers/utils"

// 转盘
type TurnTableReq struct {
	TurnTableId    int `json:"turn_table_id"`
	TurnTableCount int `json:"turn_table_count"`
}

// 转盘记录
type TurnTableRecordsReq struct {
	TurnTableId int `form:"turn_table_id" json:"turn_table_id" binding:"required"`
	utils.PageSearchReq
}

// 转盘地址
type TurnTableAddress struct {
	AddressId            int64  `json:"address_id"`
	TurnTableAddressName string `json:"turn_table_address_name"` // 收货地址姓名
	TurnTableDetail      string `json:"turn_table_detail"`       // 地址详情
	TurnTableMobile      string `json:"turn_table_mobile"`       // 手机号
	TurnTableQQ          string `json:"turn_table_qq"`           // qq
	TurnTableWX          string `json:"turn_table_wx"`           // 微信
}

// 获取地址请求
type TurnTableAddressReq struct {
}

// 获取大转盘任务中心
type TurnTableTaskCenter struct {
}

// 领取奖励
type TurnTableTaskGetReward struct {
	SetID  uint32 `form:"set_id" json:"set_id" binding:"required"`   // 任务集合ID
	TaskID uint32 `form:"task_id" json:"task_id" binding:"required"` // 任务ID
}

// 请求背包数据
type TurnTableBackpackListReq struct {
	BackpackPropType int `form:"backpack_prop_type" json:"backpack_prop_type" binding:"required"`
}
