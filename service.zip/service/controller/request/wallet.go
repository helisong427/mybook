package request

type ExchangeMoneyReq struct {
	Money int64 `json:"money" binding:"required,min=1"`
}

//用户go币账单
type UserGoBillReq struct {
	Type int `form:"type" binding:"required"` //类型:1--陪玩下单,2--购买礼物,3--购买Go币,4--其他
	BasePageReq
}
