package request

type FeedbackAdd struct {
	FeedbackContent  string `json:"feedback_content" binding:"required"`
	FeedbackTerminal int    `json:"feedback_terminal"`
	FeedbackChannel  int    `json:"feedback_channel"`
}
