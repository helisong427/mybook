package request

// 用户送礼排行（财富榜）
type RankUserSendWealth struct {
	Tag    string `form:"tag" json:"tag" binding:"required,oneof=daily weekly monthly"` // tag : daily/weekly/monthly
	Period int    `form:"period" json:"period"`
}

// 用户收礼排行（魅力榜）
type RankUserRecvCharm struct {
	Tag    string `form:"tag" json:"tag" binding:"required,oneof=daily weekly monthly"` // tag : daily/weekly/monthly
	Period int    `form:"period" json:"period"`
}

// 房间送礼排行（魅力榜）
type RankRoomSendCharm struct {
	RoomId int64  `form:"room_id"`
	Tag    string `form:"tag" json:"tag" binding:"required,oneof=hourly"` // tag : hourly
	Period int    `form:"period" json:"period"`
}

// 房间送礼排行变更轮询（魅力榜）
type RankRoomSendCharmRollPolling struct {
	RoomId int64  `form:"room_id" json:"room_id"`                         // 房间id
	Tag    string `form:"tag" json:"tag" binding:"required,oneof=hourly"` // tag : hourly
	Period int    `form:"period" json:"period"`                           // 上传
	Rank   int    `form:"rank" json:"rank"`                               // 上传
	Score  int64  `form:"score" json:"score"`                             // 上传
}

// 房间内用户送礼排行（财富榜）
type RankRoomUserSendWealth struct {
	RoomId int64  `form:"room_id" json:"room_id" binding:"required"`
	Tag    string `form:"tag" json:"tag" binding:"required,oneof=daily weekly monthly"` // tag : daily/weekly/monthly
	Period int    `form:"period" json:"period"`
}

// 房间内用户收礼排行（魅力榜）
type RankRoomUserRecvCharm struct {
	RoomId int64  `form:"room_id" json:"room_id" binding:"required"`
	Tag    string `form:"tag" json:"tag" binding:"required,oneof=daily weekly monthly"` // tag : daily/weekly/monthly
	Period int    `form:"period" json:"period"`
}
