package request

// 评价标签请求
type EvaluationLabelReq struct {
	SparringSkillId int64 `json:"sparring_skill_id" binding:"required"` // 技能id
}

// 提交评论请求
type SubmitEvaluationReq struct {
	CommentOrderId    uint64 `json:"comment_order_id"`    //订单id
	CommentContent    string `json:"comment_content"`     //订单评价
	CommentSparringId uint64 `json:"comment_sparring_id"` //订单大神id
	CommentSkillId    uint64 `json:"comment_skill_id"`    //下单技能id
	CommentAttitude   uint64 `json:"comment_attitude"`    //好差评(0好评 1差评)
	CommentLabel      string `json:"comment_label"`       //评论标签 使用逗号分割
	CommentAnonymous  uint64 `json:"comment_anonymous"`   //订单是否匿名(0不匿名 1匿名)
}

// 订单评价详情请求
type OrderEvaluationDetailReq struct {
	CommentOrderId int64 `json:"comment_order_id"` //订单id
}

// 订单评价列表请求
type OrderEvaluationListReq struct {
	CommentSkillId       uint64 `json:"comment_skill_id"`        //下单技能id
	CommentListType      uint64 `json:"comment_list_type"`       //0评论列表 1折叠评论列表
	CommentFilterLabelId uint64 `json:"comment_filter_label_id"` //筛选标签id
	Page                 int    `form:"page"  binding:"gt=0"`    //第几页
	Size                 int    `form:"size"  binding:"gt=0"`    //每页数量
}
