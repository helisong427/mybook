package request

// 账号上报
type AccountReportReq struct {
	DeviceId         string `json:"device_id"`                   // 设备id
	UDID             string `json:"udid"`                        // udid
	ChannelId        string `json:"channel_id"`                  // 渠道id
	Point            string `json:"point"`                       // 子渠道
	OsVersion        string `json:"os_version"`                  // 系统版本
	DeviceBrand      string `json:"device_brand"`                // 设备品牌
	DevicePattern    string `json:"device_pattern"`              // 设备型号
	Mobile           string `json:"mobile" binding:"max=11"`     // 手机号
	ModifyInfo       int    `json:"modify_info" binding:"min=0"` // 是否编辑
	Gender           int    `json:"gender" binding:"min=0"`      // 0未知，1男，2女
	UserId           int64  `json:"user_id" binding:"min=0"`     // 用户id
	Nickname         string `json:"nickname"`                    // 昵称
	Birthday         int64  `json:"birthday" binding:"min=0"`    // 生日
	CountryId        string `json:"country_id"`                  // 国家id
	ProvinceId       string `json:"province_id"`                 // 省份id
	CityId           string `json:"city_id"`                     // 城市id
	ZoneId           string `json:"zone_id"`                     // 区县id
	Longitude        string `json:"longitude"`                   // 经度
	Latitude         string `json:"latitude"`                    // 纬度
	ScreenResolution string `json:"screen_resolution"`           // 分辨率
	OperateId        int    `json:"operate_id" binding:"min=0"`  // 操作id
}

type ReportHeader struct {
	ClientType *int   `header:"Client-Type" binding:"required"`
	Version    string `header:"App-Version" binding:"required,max=100"`
}

// 登录上报
type LoginReportReq struct {
	DeviceId         string `json:"device_id"`               // 设备id
	UDID             string `json:"udid"`                    // udid
	ChannelId        string `json:"channel_id"`              // 渠道id
	Point            string `json:"point"`                   // 子渠道
	UserId           int64  `json:"user_id" binding:"min=0"` // 用户id
	UnionId          int64  `json:"union_id" binding:"min=0"`
	Nickname         string `json:"nickname"`                        // 昵称
	Gender           int    `json:"gender" binding:"min=0"`          // 0未知，1男，2女
	Mobile           string `json:"mobile" binding:"max=11"`         // 手机号
	Birthday         int64  `json:"birthday"`                        // 生日
	VipLevel         int    `json:"vip_level" binding:"min=0"`       // vip等级
	IsSparring       int    `json:"is_sparring" binding:"min=0"`     // 是否大神 0 不是，1是
	IsAnchor         int    `json:"is_anchor" binding:"min=0"`       // 是否主播 0不是，1是
	CountryId        string `json:"country_id"`                      // 国家id
	ProvinceId       string `json:"province_id"`                     // 省份id
	HometownId       string `json:"hometown_id"`                     // 家乡id
	CityId           string `json:"city_id"`                         // 城市id
	ZoneId           string `json:"zone_id"`                         // 区县id
	Longitude        string `json:"longitude"`                       // 经度
	Latitude         string `json:"latitude"`                        // 纬度
	OsVersion        string `json:"os_version"`                      // 系统版本
	DeviceBrand      string `json:"device_brand"`                    // 设备品牌
	DevicePattern    string `json:"device_pattern"`                  // 设备型号
	ScreenResolution string `json:"screen_resolution"`               // 分辨率
	InternetType     string `json:"internet_type"`                   // 网络类型
	RoomStatus       int    `json:"room_status" binding:"min=0"`     // 房间状态
	LoginStatus      int    `json:"login_status" binding:"min=0"`    // 登录状态
	OnlineDuration   int64  `json:"online_duration" binding:"min=0"` // 在线时长
	UserRegTime      int64  `json:"user_reg_time" binding:"min=0"`   // 注册时间
}

// 广告监控上报
type AdReportReq struct {
	ChannelId int64  `form:"channel_id" json:"channel_id"`
	Imei      string `form:"imei" json:"imei"`             // 用户终端的 IMEI，原始值为 15 位 IMEI，取其 32 位 MD5 摘要。
	OAID      string `form:"oaid" json:"oaid"`             // 匿名设备标识符
	AndroidId string `form:"android_id" json:"android_id"` // 用户终端的 Android ID
	UA        string `form:"ua" json:"ua"`
	Ip        string `json:"-"`
}
