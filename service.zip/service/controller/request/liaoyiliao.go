package request

type LiaoyiliaoListReq struct {
	OffSet      int64  `form:"off_set"`                                      //当前数据游标
	CacheStatus uint8  `form:"cache_status" binding:"omitempty,min=1,max=2"` //缓存状态 1:在线 2:离线
	RegOffSet   *int64 `json:"reg_off_set" binding:"omitempty"`              // 当前注册用户游标
}

type LiaoyiliaoSendReq struct {
	UserId int64 `json:"user_id" binding:"required"`
}

type LiaoyiliaoInitReq struct {
	Action string `form:"action" binding:"required"` //动作：init--初始化,change--替换桶
}
