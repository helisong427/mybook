package request

//搜索接口列表
type SearchResultsListReq struct {
	SearchId string `form:"search_id"`                                 //搜索id
	MoreType int    `form:"more_type" binding:"omitempty,min=0,max=2"` //更多类型:0--全部，1--用户，2--房间
	RoomPage int    `form:"room_page"`                                 //房间分页
	RoomSize int    `form:"room_size"`                                 //
	UserPage int    `form:"user_page"`                                 //用户分页
	UserSize int    `form:"user_size"`                                 //
}
