package request

//下单参数
type SkillOrderPlaceReq struct {
	SparringId int64  `json:"sparring_id" binding:"required"`  //大神技能id
	Count      int64  `json:"count" binding:"required,max=99"` //购买总数
	PriceId    int64  `json:"price_id" binding:"required"`     // 价格id
	Remark     string `json:"remark" binding:"max=50"`         //备注
}

//订单结果参数
type SkillOrderPayResultReq struct {
	OrderId int `form:"order_id" binding:"required"`
}

//接受订单参数
type SkillOrderAcceptReq struct {
	OrderId int64 `json:"order_id" binding:"required"`
}

//取消订单参数
type SkillOrderRefundReq struct {
	OrderId      int64  `json:"order_id" binding:"required"`
	RefundType   *int   `json:"refund_type" binding:"required,min=0"`
	RefundReason string `json:"refund_reason" binding:"required"`
	Remark       string `json:"remark"`
}

//退款确认参数
type SkillOrderRefundConfirmReq struct {
	OrderId      int64  `json:"order_id" binding:"required"`
	Status       *int   `json:"status" binding:"required,min=0,max=1"` //是否同意，0--拒绝，1--同意
	RefundReason string `json:"refund_reason" `
	Remark       string `json:"remark"`
}

//订单详情参数
type SkillOrderDetailReq struct {
	OrderId int `form:"order_id" binding:"required"`
}

// 订单分页
type QuerySkillOrderReq struct {
	Page int `form:"page" binding:"required"`
	Size int `form:"size" binding:"required"`
}
