package request

//发布话题
type AddTopicReq struct {
	TopicTitle string `json:"topic_title" binding:"required"` //话题标题
}

//搜索话题
type SearchTopicReq struct {
	TopicTitle string `form:"topic_title" binding:"required"` //话题标题
}
