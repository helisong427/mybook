package controller

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/models/dbmodels"

	"github.com/gin-gonic/gin"
)

//ArticleList 获取文章列表
func ArticleList(gctx *gin.Context) {
	var (
		articleList []dbmodels.AppArticle
		err         error
	)
	// TODO 统一规范，涉及到列表场景，应该都需要做分页，并且分页数量要有限制
	paramsJSON := request.ArticleListReq{}
	err = gctx.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	model := dbmodels.AppArticle{}
	if paramsJSON.CategoryId > 0 {
		articleList, err = model.QueryByCategoryID(int64(paramsJSON.CategoryId))
	} else {
		articleList, err = model.QueryAll()
	}
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "获取列表失败", "", err.Error())
		return
	}

	// DONE(@chenjianjun) 此场景先做预分配，可以有效的阻止底层数组扩容的问题，调整如下
	// list := []response.ArticleListRep{}
	list := make([]response.ArticleListRep, 0, len(articleList))
	for _, v := range articleList {
		// DONE(@chenjianjun) 此场景需优化，可以直接通过append追加，不需要加中间变量，减少对象拷贝。也可把list变成存放指针的数组来优化
		resp := response.ArticleListRep{
			ArticleID:           v.ArticleID,
			ArticleCategoryID:   v.ArticleCategoryID,
			ArticleTitle:        v.ArticleTitle,
			ArticleTitleImage:   v.ArticleTitleImage,
			ArticleContentImage: v.ArticleContentImage,
			ArticleContent:      v.ArticleContent,
			ArticleStatus:       v.ArticleStatus,
			ArticleUrl:          v.ArticleUrl,
			ArticleOrder:        v.ArticleOrder,
			ArticleIntroduction: v.ArticleIntroduction,
			Created:             v.BaseModel.Created,
			Edited:              v.BaseModel.Edited,
			Deleted:             v.BaseModel.Deleted,
		}

		list = append(list, resp)
	}
	total := len(list)
	r := response.BasePageList{
		Page:       1,            //当前页
		Size:       total,        //每页条数
		Total:      int64(total), //总条数
		TotalPages: 1,            //总页数
		List:       list,         //数据列表
	}

	response.ResponseOk(gctx, "文章列表获取成功", r)
}

//文章详情
func ArticleInfo(gctx *gin.Context) {
	var (
		articleInfo dbmodels.AppArticle
		err         error
	)
	paramsJSON := request.ArticleInfoReq{}
	err = gctx.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	model := dbmodels.AppArticle{}
	if paramsJSON.ArticleID > 0 {
		articleInfo, err = model.QueryByArticleID(paramsJSON.ArticleID)
		response.ResponseOk(gctx, "文章详情获取成功", articleInfo)
	} else {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", "")
		return
	}
}

//官网全部文章
func ArticleWeball(gctx *gin.Context) {
	param, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_WEB_SITE_ARTICLE_CATEGORY_IDS)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "获取全局开关失败", "", err.Error())
		return
	}
	articleList, err := new(dbmodels.AppArticle).QueryByCategoryIDS(param["value"])
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "获取列表失败", "", err.Error())
		return
	}
	list := []response.ArticleListRep{}
	for _, v := range articleList {
		resp := response.ArticleListRep{
			ArticleID:           v.ArticleID,
			ArticleCategoryID:   v.ArticleCategoryID,
			ArticleTitle:        v.ArticleTitle,
			ArticleTitleImage:   v.ArticleTitleImage,
			ArticleContentImage: v.ArticleContentImage,
			ArticleContent:      v.ArticleContent,
			ArticleStatus:       v.ArticleStatus,
			ArticleUrl:          v.ArticleUrl,
			ArticleOrder:        v.ArticleOrder,
			ArticleIntroduction: v.ArticleIntroduction,
			Created:             v.BaseModel.Created,
			Edited:              v.BaseModel.Edited,
			Deleted:             v.BaseModel.Deleted,
		}

		list = append(list, resp)
	}
	total := len(list)
	r := response.BasePageList{
		Page:       1,            //当前页
		Size:       total,        //每页条数
		Total:      int64(total), //总条数
		TotalPages: 1,            //总页数
		List:       list,         //数据列表
	}
	response.ResponseOk(gctx, "文章列表获取成功", r)
}
