package controller

import (
	"fmt"
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/controller/services/liaoyiliao"
	"gamers/middleware"
	"gamers/models/dbmodels"
	"gamers/utils"
	"gamers/utils/chuanglan/shanyan"
	"gamers/utils/chuanglan/sms"
	"strconv"
	"time"

	"github.com/go-redis/redis"

	"gorm.io/gorm"

	"github.com/gin-gonic/gin"
)

const (
	DEFAULT_TIMEOUT = 120 * time.Second
)

// LoginCheck 检查账号是否登录
func LoginCheck(gctx *gin.Context) {
	userID, _ := gctx.Get("userID")
	data := gin.H{"userId": userID}
	response.ResponseOk(gctx, "ok", data)
}

// LoginByOpenid 第三方登录/注册
func LoginByOpenid(c *gin.Context) {
	paramsJSON := request.LoginByOpenidReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	loginFunc := services.OpenidLogin{
		Openid:    paramsJSON.Openid,
		Nickname:  paramsJSON.Nickname,
		Gender:    paramsJSON.Gender,
		Iconurl:   paramsJSON.Iconurl,
		Opentype:  paramsJSON.Opentype,
		Timestamp: paramsJSON.Timestamp,
		Uuid:      paramsJSON.Uuid,
		Sign:      paramsJSON.Sign,
	}
	login := services.NewLogin(&loginFunc)
	r, msg, err := login.Login(c)

	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}
	// 主动推送处理大神、主播上线
	services.HandleSparringAnchor(r.UserId)
	response.ResponseOk(c, "登录成功", r)
}

// LoginByMobile 手机号一键注册/登录
func LoginByMobile(gctx *gin.Context) {
	clientType, err := strconv.Atoi(gctx.Request.Header.Get("Client-Type"))
	if err != nil {
		clientType = 0
	}

	paramsJSON := request.LoginByMobile{}
	err = gctx.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	loginFunc := services.MobileLogin{
		Token:      paramsJSON.Token,
		Openid:     paramsJSON.Openid,
		Opentype:   paramsJSON.Opentype,
		ClientType: clientType,
	}
	login := services.NewLogin(&loginFunc)
	r, msg, err := login.Login(gctx)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}
	// 主动推送处理大神、主播上线
	services.HandleSparringAnchor(r.UserId)
	response.ResponseOk(gctx, "登录成功", r)
}

// LoginByPassword 密码登录
func LoginByPassword(gctx *gin.Context) {
	var paramsJSON = request.LoginByPasswordReq{}
	err := gctx.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	if !utils.FuncVerifyMobile(paramsJSON.Mobile) {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "手机号格式错误", "", "")
		return
	}
	loginFunc := services.PasswordLogin{
		Mobile:   paramsJSON.Mobile,
		Password: paramsJSON.Password,
	}
	login := services.NewLogin(&loginFunc)
	r, msg, err := login.Login(gctx)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}
	// 主动推送处理大神、主播上线
	services.HandleSparringAnchor(r.UserId)
	response.ResponseOk(gctx, "登录成功", r)
}

// LoginBySmsCode 短信验证码登录
func LoginBySmsCode(gctx *gin.Context) {
	var paramsJSON = request.LoginBySmsCodeReq{}
	err := gctx.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	loginFunc := services.SmsCodeLogin{
		Mobile: paramsJSON.Mobile,
		Code:   paramsJSON.Code,
	}
	login := services.NewLogin(&loginFunc)
	r, msg, err := login.Login(gctx)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}
	// 主动推送处理大神、主播上线
	services.HandleSparringAnchor(r.UserId)
	response.ResponseOk(gctx, "登录成功", r)
}

// LoginBySmsCode 多端短信验证码登录
func LoginByMultiSmsCode(gctx *gin.Context) {
	var paramsJSON = request.LoginBySmsCodeReq{}
	err := gctx.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	loginFunc := services.SmsCodeMultiLogin{
		Mobile: paramsJSON.Mobile,
		Code:   paramsJSON.Code,
	}
	login := services.NewLogin(&loginFunc)
	r, msg, err := login.Login(gctx)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}
	// 主动推送处理大神、主播上线
	services.HandleSparringAnchor(r.UserId)
	response.ResponseOk(gctx, "登录成功", r)
}

func getSmsCode(paramsJSON request.GetSmsCodeReq, gctx *gin.Context) {

	err := utils.FuncSmsTimestamp(paramsJSON.Timestamp)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "请检查当前系统时间", "", err.Error())
		return
	}

	// 参数签名验证
	ClientKey := utils.Config.App.ClientKey
	sign := utils.FuncMD5(fmt.Sprintf("%s%s%d%s", paramsJSON.Mobile, ClientKey, paramsJSON.Timestamp, paramsJSON.Uuid))
	if sign != paramsJSON.Sign {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "非法请求", "", "")
		return
	}

	if !utils.FuncVerifyMobile(paramsJSON.Mobile) {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "手机号格式错误", "", "")
		return
	}

	smsCodeKey := utils.REDIS_SMS_CODE + paramsJSON.Mobile
	smsIpKey := utils.REDIS_SMS_IP + gctx.ClientIP()
	smsClientKey := utils.REDIS_SMS_CLIENT_CODE + gctx.Request.Header.Get("Udid")

	// 设备信息+ip限流
	smsClient := 0
	smsIp := utils.RedisClient.Get(smsIpKey).Val()
	smsClient, _ = utils.RedisClient.Get(smsClientKey).Int()
	if smsIp != "" && smsClient >= 3000000 {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "操作过于频繁，请3分钟后再尝试", "", "")
		return
	}

	// 获取过期时间
	ttl, _ := utils.RedisClient.TTL(smsClientKey).Result()
	if ttl <= 0 {
		ttl = 60
	}

	// 生成验证码
	code := utils.FuncRandRangeInt(1000, 9999)
	// 发送验证码
	msgParams := fmt.Sprintf("%s,%d,%d", paramsJSON.Mobile, code, 5)
	go sms.SendSms(2, sms.SMS_CODE, msgParams)

	pipe := utils.RedisClient.TxPipeline()
	pipe.Set(smsCodeKey, code, 5*time.Minute)
	pipe.Set(smsIpKey, 1, 60*time.Second)
	pipe.Set(smsClientKey, smsClient+1, ttl*time.Second) // 限制每分钟3次验证码
	_, err = pipe.Exec()
	if err != nil {
		utils.LogErrorF("存储登录信息错误，err:%s", err.Error())
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "发送验证码失败，稍后再试", "", "")
		return
	}
	if !utils.FuncEnv() {
		response.ResponseOk(gctx, "发送成功", gin.H{"code": code})
		return
	} else {
		response.ResponseOk(gctx, "发送成功", nil)
		return
	}
}

// GetSms 发送验证码
func GetSmsCode(gctx *gin.Context) {
	var paramsJSON = request.GetSmsCodeReq{}
	err := gctx.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	getSmsCode(paramsJSON, gctx)

	return
	// var paramsJSON = request.GetSmsCodeReq{}
	// err := gctx.ShouldBindJSON(&paramsJSON)
	// if err != nil {
	// 	response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
	// 	return
	// }
	//
	// err = utils.FuncSmsTimestamp(paramsJSON.Timestamp)
	// if err != nil {
	// 	response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "请检查当前系统时间", "", err.Error())
	// 	return
	// }
	//
	// // 参数签名验证
	// ClientKey := utils.Config.App.ClientKey
	// sign := utils.FuncMD5(fmt.Sprintf("%s%s%d%s", paramsJSON.Mobile, ClientKey, paramsJSON.Timestamp, paramsJSON.Uuid))
	// if sign != paramsJSON.Sign {
	// 	response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "非法请求", "", "")
	// 	return
	// }
	//
	// if !utils.FuncVerifyMobile(paramsJSON.Mobile) {
	// 	response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "手机号格式错误", "", "")
	// 	return
	// }
	//
	// smsCodeKey := utils.REDIS_SMS_CODE + paramsJSON.Mobile
	// smsIpKey := utils.REDIS_SMS_IP + gctx.ClientIP()
	// smsClientKey := utils.REDIS_SMS_CLIENT_CODE + gctx.Request.Header.Get("Udid")
	//
	// // 设备信息+ip限流
	// smsClient := 0
	// smsIp := utils.RedisClient.Get(smsIpKey).Val()
	// smsClient, _ = utils.RedisClient.Get(smsClientKey).Int()
	// if smsIp != "" && smsClient >= 3000000 {
	// 	response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "操作过于频繁，请3分钟后再尝试", "", "")
	// 	return
	// }
	//
	// // 获取过期时间
	// ttl, _ := utils.RedisClient.TTL(smsClientKey).Result()
	// if ttl <= 0 {
	// 	ttl = 60
	// }
	//
	// // 生成验证码
	// code := utils.FuncRandRangeInt(1000, 9999)
	// // 发送验证码
	// msgParams := fmt.Sprintf("%s,%d,%d", paramsJSON.Mobile, code, 5)
	// go sms.SendSms(2, sms.SMS_CODE, msgParams)
	//
	// pipe := utils.RedisClient.TxPipeline()
	// pipe.Set(smsCodeKey, code, 5*time.Minute)
	// pipe.Set(smsIpKey, 1, 60*time.Second)
	// pipe.Set(smsClientKey, smsClient+1, ttl*time.Second) // 限制每分钟3次验证码
	// _, err = pipe.Exec()
	// if err != nil {
	// 	utils.LogErrorF("存储登录信息错误，err:%s", err.Error())
	// 	response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "发送验证码失败，稍后再试", "", "")
	// 	return
	// }
	// if !utils.FuncEnv() {
	// 	response.ResponseOk(gctx, "发送成功", gin.H{"code": code})
	// 	return
	// } else {
	// 	response.ResponseOk(gctx, "发送成功", nil)
	// 	return
	// }
}

// SmsBindMobile 短信绑定手机号
func SmsBindMobile(gctx *gin.Context) {
	clientType, err := strconv.Atoi(gctx.Request.Header.Get("Client-Type"))
	if err != nil {
		clientType = 0
	}
	ip := gctx.ClientIP()
	ipv4, _ := utils.FuncIPv42Int(ip)
	// 主要渠道
	regChannel, err := strconv.ParseInt(gctx.Request.Header.Get("channel"), 10, 64)
	if err != nil {
		regChannel = 0
	}
	// 二级渠道
	regPoint, err := strconv.ParseInt(gctx.Request.Header.Get("subchannel"), 10, 64)
	if err != nil {
		regPoint = 0
	}

	paramsJSON := request.SmsBindMobileReq{}
	err = gctx.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	if !utils.FuncVerifyMobile(paramsJSON.Mobile) {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "手机号格式错误", "", "")
		return
	}
	key := utils.REDIS_SMS_CODE + paramsJSON.Mobile
	// 验证验证码
	code, err := utils.RedisClient.Get(key).Int()
	if err != nil && err != redis.Nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "验证码错误", "", err.Error())
		return
	}
	if err != nil && err == redis.Nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "验证码超时,请重新获取", "", "")
		return
	}
	if paramsJSON.Code != code {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "验证码错误", "", "")
		return
	}
	openInfoModel := dbmodels.SystemUserOpeninfo{
		OpeninfoType:   int(paramsJSON.Opentype),
		OpeninfoOpenid: paramsJSON.Openid,
	}
	openInfoUser, err := openInfoModel.OpenidByUser()
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "用户不存在", "", err.Error())
		return
	}

	if openInfoUser.OpeninfoUserID != 0 {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "用户已绑定", "", "")
		return
	}

	// 查询手机号码
	row, user, err := new(dbmodels.SystemUser).MobileByUser(paramsJSON.Mobile)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	var userId int64
	// 未查询到用户
	if row == 0 {
		// 创建user表用户信息
		userModel := dbmodels.SystemUser{
			UserMobile:      paramsJSON.Mobile,
			UserRegIP:       ipv4,
			UserRegPlatform: clientType,
			UserRegChannel:  regChannel,
			UserRegPoint:    regPoint,
		}
		// 创建用户
		err = userModel.CreatUser()
		go services.ADReportRegister(regChannel, gctx.Request.Header.Get("imei"), gctx.Request.Header.Get("oaid"), gctx.ClientIP())
		go liaoyiliao.NewCacheMod().AddGlobalCache(&user)
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "手机号绑定失败", "", err.Error())
			return
		}
		userId = userModel.UserID
	} else {
		userId = user.UserID
	}

	// 绑定用户信息
	openInfoModel = dbmodels.SystemUserOpeninfo{}
	affected, err := openInfoModel.BindUserId(paramsJSON.Openid, paramsJSON.Opentype, userId)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if affected < 1 {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "用户绑定失败", "", "")
		return
	}

	byUser, err := new(dbmodels.SystemUser).UserIdByUser(userId)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	// 获取登录信息
	accessToken, refreshToken, r, err := middleware.UserLoginByMobile(byUser, ipv4)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "绑定失败", "", err.Error())
		return
	}

	gctx.Header("Access-Token", accessToken)
	gctx.Header("Refresh-Token", refreshToken)
	// 删除验证码
	utils.RedisClient.Del(key)
	// 主动推送处理大神、主播上线
	services.HandleSparringAnchor(r.UserId)
	response.ResponseOk(gctx, "登录成功", r)
}

// BindMobile 绑定手机号
func BindMobile(c *gin.Context) {
	// 客户端类型
	clientType, err := strconv.Atoi(c.Request.Header.Get("Client-Type"))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "获取客户端类型失败", "", err.Error())
		return
	}

	// 主要渠道
	regChannel, err := strconv.ParseInt(c.Request.Header.Get("channel"), 10, 64)
	if err != nil {
		regChannel = 0
	}

	// 二级渠道
	regPoint, err := strconv.ParseInt(c.Request.Header.Get("subchannel"), 10, 64)
	if err != nil {
		regPoint = 0
	}

	ip := c.ClientIP()
	ipv4, _ := utils.FuncIPv42Int(ip)

	// 参数
	paramsJSON := request.BindMobileReq{}
	err = c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	openInfoModel := dbmodels.SystemUserOpeninfo{
		OpeninfoType:   int(paramsJSON.Opentype),
		OpeninfoOpenid: paramsJSON.Openid,
	}
	openInfoUser, err := openInfoModel.OpenidByUser()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "用户不存在", "", err.Error())
		return
	}
	if openInfoUser.OpeninfoUserID != 0 {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "用户已绑定", "", "")
		return
	}

	// 查询手机号码
	mobile, err := shanyan.SdkWarp{}.QueryPhone(shanyan.ClientType(clientType), paramsJSON.Token)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询出错", "", "")
		return
	}
	row, user, err := new(dbmodels.SystemUser).MobileByUser(mobile)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	var userId int64
	// 未查询到用户
	if row == 0 {
		// 创建user表用户信息
		userModel := dbmodels.SystemUser{
			UserMobile:      mobile,
			UserRegIP:       ipv4,
			UserRegPlatform: clientType,
			UserRegChannel:  regChannel,
			UserRegPoint:    regPoint,
		}
		// 创建用户
		err = userModel.CreatUser()
		go services.ADReportRegister(regChannel, c.Request.Header.Get("imei"), c.Request.Header.Get("oaid"), c.ClientIP())
		go liaoyiliao.NewCacheMod().AddGlobalCache(&user)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "手机号绑定失败", "", err.Error())
			return
		}
		userId = userModel.UserID
	} else {
		userId = user.UserID
	}

	// 绑定用户信息
	openInfoModel = dbmodels.SystemUserOpeninfo{}
	affected, err := openInfoModel.BindUserId(paramsJSON.Openid, paramsJSON.Opentype, userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if affected < 1 {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "用户绑定失败", "", "")
		return
	}

	byUser, err := new(dbmodels.SystemUser).UserIdByUser(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	// 获取登录信息
	accessToken, refreshToken, r, err := middleware.UserLoginByMobile(byUser, ipv4)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "绑定失败", "", err.Error())
		return
	}

	c.Header("Access-Token", accessToken)
	c.Header("Refresh-Token", refreshToken)

	response.ResponseOk(c, "登录成功", r)
}

func BindingGetSmsCode(gctx *gin.Context) {

	var paramsJSON = request.GetSmsCodeReq{}
	err := gctx.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	row, _, err := new(dbmodels.SystemUser).MobileByUser(paramsJSON.Mobile)
	if err == nil || row == 1 {
		getSmsCode(paramsJSON, gctx)
	} else {
		response.ResponseError(gctx, response.RESPONSE_USER_STATUS_ERROR, "手机号暂未注册GOGO语音", "", "")
	}

}

// gogo账号绑定GOGO语音公众号
func BindingWechat(c *gin.Context) {

	paramsJSON := request.WechatBindingReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}

	binding := services.BindingWechat{
		Openid:      paramsJSON.Openid,
		PhoneNumber: paramsJSON.PhoneNumber,
		Code:        paramsJSON.Code,
	}

	userId, hash, err := binding.Binding()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, err.Error(), "", "")
		return
	}

	r := &response.GetWechatBindingRep{
		IsBinding:   0,
		Openid:      binding.Openid,
		Hash:        hash,
		UserId:      userId,
		PhoneNumber: binding.PhoneNumber,
	}

	response.ResponseOk(c, "gogo账号绑定GOGO语音公众号成功", r)
}

// gogo账号解除绑定GOGO语音公众号
func UnBindingWechat(c *gin.Context) {

	paramsJSON := request.WechatUnBindingReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}

	err = new(services.BindingWechat).UnBinding(paramsJSON.UserId, paramsJSON.PhoneNumber, paramsJSON.Hash, paramsJSON.Openid)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "gogo账号绑定GOGO语音公众号失败!", "", err.Error())
	} else {
		response.ResponseOk(c, "gogo账号绑定GOGO语音公众号成功", nil)
	}

}

// 根据openid查询用户信息
func GetBindingWechat(c *gin.Context) {

	paramsJSON := request.GetWechatBindingReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}

	userId, phoneNumber, hash, exist, err := new(services.BindingWechat).GetBindingData(paramsJSON.Openid)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "根据openid查询用户信息失败!", "", err.Error())
	} else {
		r := &response.GetWechatBindingRep{}

		if exist {
			r.IsBinding = 0
			r.Openid = paramsJSON.Openid
			r.Hash = hash
			r.PhoneNumber = phoneNumber
			r.UserId = userId
		} else {
			r.IsBinding = 1
		}
		response.ResponseOk(c, "gogo账号绑定GOGO语音公众号成功", r)
	}

}
