package controller

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/models/dbmodels"
	"gamers/utils"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// 拉黑
func BlacklistAddUser(c *gin.Context) {
	form := request.BlackListReq{}
	userId := utils.FuncUserId(c)
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	if userId == form.UserId {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "不能拉黑自己", "", "")
		return
	}
	_, err = new(dbmodels.AppBlacklist).Exists(userId, form.UserId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if err == nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "用户已被拉黑", "", "")
		return
	}
	_, err = new(dbmodels.SystemUser).UserIdByUser(form.UserId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "操作对象不存在", "", "")
		return
	}
	blacklist := dbmodels.AppBlacklist{
		BlacklistUserId:      userId,
		BlacklistBlackUserId: form.UserId,
	}
	_, err = new(dbmodels.AppAttention).QueryExist(int(userId), int(form.UserId))
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询关注失败", "", err.Error())
		return
	}
	if err == nil {
		err = new(dbmodels.AppAttention).Delete(int(userId), int(form.UserId))
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "取消关注失败", "", err.Error())
			return
		}
		err = new(dbmodels.AppFan).Delete(int(form.UserId), int(userId))
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "取消关注失败", "", err.Error())
			return
		}
		attention := services.InitAttention()
		go attention.LikeTag(int(userId), int(form.UserId), false)
	}

	err = services.BlackListAdd(userId, form.UserId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "连接im拉黑失败", "", err.Error())
		return
	}
	err = blacklist.Create()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "拉黑成功", "ok")
	return
}

// 取消拉黑
func BlacklistDelUser(c *gin.Context) {
	form := request.BlackListReq{}
	userId := utils.FuncUserId(c)
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	if userId == form.UserId {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "不能操作自己", "", "")
		return
	}
	data, err := new(dbmodels.AppBlacklist).Exists(userId, form.UserId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "取消对象不存在", "", err.Error())
		return
	}
	if data.BaseModel.Deleted != 0 {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前用户未在黑名单", "", "")
		return
	}
	err = services.BlackListDel(userId, form.UserId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "连接im取消拉黑失败", "", err.Error())
		return
	}
	err = new(dbmodels.AppBlacklist).Delete(userId, form.UserId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "取消成功", "ok")
	return
}

// 拉黑列表
func BlacklistList(c *gin.Context) {
	userId := utils.FuncUserId(c)
	//获取分页参数
	page, size, skip, err := utils.GetPageAndSize(c)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "分页参数错误", "", err.Error())
		return
	}

	result, err, total := new(dbmodels.AppBlacklist).GetBlacklistByUserId(userId, size, skip)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "未获取到黑名单", "", err.Error())
		return
	}
	data := response.BasePageList{
		Page:       page,
		Size:       size,
		Total:      total,
		TotalPages: utils.FuncTotalPages(total, size),
		List:       result,
	}
	response.ResponseOk(c, "ok", data)
	return
}
