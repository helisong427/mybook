package controller

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/models/dbmodels"
	"gamers/utils/moderation"
	"gamers/utils/tencent/cos"

	"github.com/gin-gonic/gin"
)

const (
	filePath       = "./storage/files"
	fileSize int64 = 1024 * 1024 * 5 //5M
)

//CosTempKey 获取公有临时密钥
func CosTempKey(gctx *gin.Context) {
	mapResult, err := cos.GetTmpSecretKey("")
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(gctx, "请求成功", mapResult)
}

//SecretCosTempKey 获取私有临时密钥
func SecretCosTempKey(gctx *gin.Context) {
	mapResult, err := cos.GetTmpSecretKey("secret")
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(gctx, "请求成功", mapResult)
}

//GetRegionList 获取地区列表
func GetRegionList(gctx *gin.Context) {
	model := dbmodels.SystemRegion{}
	data, err := model.QueryAll()
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	list := services.CityTree(data, 100000)
	response.ResponseOk(gctx, "获取成功", list)
}

//文字审核
func TextModeration(c *gin.Context) {
	paramsJSON := request.TextModerationReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	r := response.TextModerationRep{}
	//敏感词过滤
	moderationText := moderation.TextModeration(paramsJSON.Text)
	if len(moderationText) > 0 {
		r.Ok = 0
	} else {
		r.Ok = 1
	}
	response.ResponseOk(c, "", r)
}
