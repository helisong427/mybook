package controller

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/models/redismodels"

	"github.com/gin-gonic/gin"
)

//接收直播消息
func LocalLiveMsg(c *gin.Context) {
	paramsJSON := request.LocalLiveMsgReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	err = services.LocalLiveMsg(paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "发送直播消息成功", nil)
	return
}

//加入公会信息
func LocalJoinUnionMsg(c *gin.Context) {
	paramsJSON := request.LocalJoinUnionMsgReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	err = services.LocalJoinUnionMsg(paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "发送公会申请消息成功", nil)
	return
}

func LocalTextMsg(c *gin.Context) {
	paramsJSON := request.LocalTextMsgReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	err = services.LocalAssistantTextMsg(paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "发送反馈处理消息成功", nil)
	return
}

// 房间送礼[魅力值]排行榜（小时榜）变动消息
func LocalRankRoomSendCharmModifyMsg(c *gin.Context) {
	var notifyList []*redismodels.RankRoomSendCharmUpdateNotifyItem
	if err := c.ShouldBind(&notifyList); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	services.LocalRankRoomSendCharmModifyMsg(notifyList)
	response.ResponseOk(c, "发送房间送礼[魅力值]排行榜（小时榜）变动消息成功", nil)
}

// 大神审核消息
func LocalSparringReviewMsg(c *gin.Context) {
	paramsJSON := request.LocalSparringReviewMsgReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	err = services.LocalSparringReviewMsg(paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "发送大神审核处理消息成功", nil)
	return
}

// 主播审核消息
func LocalAnchorReviewMsg(c *gin.Context) {
	paramsJSON := request.LocalAnchorReviewMsgReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	err = services.LocalAnchorReviewMsg(paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "发送主播审核处理消息成功", nil)
	return
}

// 获取交易流水id
func LocalTransactionId(c *gin.Context) {
	paramsJSON := request.LocalTransactionIdReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	transactionId := services.LocalTransactionId(paramsJSON)
	if transactionId == "" {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", "")
		return
	}
	response.ResponseOk(c, "获取交易流水ID成功", transactionId)
	return
}

//订单申诉消息
func LocalOrderAppealMsg(c *gin.Context) {
	paramsJSON := request.LocalOrderAppealMsgReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	err = services.LocalOrderAppealMsg(paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "发送订单申诉消息成功", nil)
	return
}

//动态审核不通过消息
func LocalTweetRefuseMsg(c *gin.Context) {
	paramsJSON := request.LocalTweetRefuseMsgReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	err = services.LocalTweetRefuseMsg(paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "发送动态审核不通过消息成功", nil)
	return
}

//素材审核不通过消息
func LocalMaterialRefuseMsg(c *gin.Context) {
	paramsJSON := request.LocalMaterialRefuseMsgReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	err = services.LocalMaterialRefuseMsg(paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "发送素材审核不通过消息成功", nil)
	return
}

//房间资料不通过消息
func LocalStudioRefuseMsg(c *gin.Context) {
	paramsJSON := request.LocalStudioRefuseMsgReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	err = services.LocalStudioRefuseMsg(paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "发送房间资料不通过消息成功", nil)
	return
}

//大神冻结消息
func LocalSparringForbiddenMsg(c *gin.Context) {
	paramsJSON := request.LocalSparringForbiddenMsgReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	err = services.LocalSparringForbiddenMsg(paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "发送大神冻结消息成功", nil)
	return
}

//提现失败消息
func LocalExtractFailMsg(c *gin.Context) {
	paramsJSON := request.LocalExtractFailMsgReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	err = services.LocalExtractFailMsg(paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "发送提现失败消息成功", nil)
	return
}

//提现成功消息
func LocalExtractSuccessMsg(c *gin.Context) {
	paramsJSON := request.LocalExtractSuccessMsgReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	err = services.LocalExtractSuccessMsg(paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "发送提现成功消息成功", nil)
	return
}

// LocalInviteMessageRejectMsg 通过gogo助手发送用户提交的撩一撩邀请消息，审核不通过的原因。
// 通过后台服务器发送HTTP POST请求到 APP 服务器的消息内容，在由 APP 服务器通过腾讯 IM 给用户发送消息
func LocalInviteMessageRejectMsg(c *gin.Context) {
	paramsJSON := request.LocalInviteMessageRejectMsgReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	err = services.LocalInviteMessageRejectMsg(paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "给用户发送撩一撩邀请消息审核不通过的消息成功", nil)
}
