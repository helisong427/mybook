package controller

import (
	"fmt"
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/enum"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"gamers/utils/trydo"
	"gamers/utils/ymd"
	jsoniter "github.com/json-iterator/go"
	"sort"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
)

type EggBreakConfigType struct {
	EggBreakConfigTypeGold   int64 `json:"eggbreak_config_type_gold"`
	EggBreakConfigTypeSilver int64 `json:"eggbreak_config_type_silver"`
}

// 获取砸蛋配置（基础配置）
func EggBreakConfig(c *gin.Context) {
	data, err := new(dbmodels.AppEggbreak).QueryAll()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	param, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PARAM_KEY_ERRBREAK_CONFIG)
	if err != nil {
		utils.LogErrorF("查询砸蛋配置锤子ID参数失败，err:%s", err.Error())
		panic(err)
		return
	}
	var form EggBreakConfigType
	err = jsoniter.UnmarshalFromString(param["value"], &form)
	if err != nil {
		utils.LogErrorF("反序列化砸蛋配置锤子ID参数失败，err:%s", err.Error())
		panic(err)
		return
	}

	var resp []*response.EggBreakConfigListRep

	for _, v := range data {
		if v.EggbreakStatus != dbmodels.DB_EGGBREAK_STATUS_OPEN {
			continue
		}

		var item = &response.EggBreakConfigListRep{
			EggbreakId:            v.EggbreakId,
			EggbreakTitle:         v.EggbreakTitle,
			EggbreakDesc:          v.EggbreakDesc,
			EggbreakCostPropType:  v.EggbreakCostPropType,
			EggbreakCostPropId:    v.EggbreakCostPropId,
			EggbreakCostPropCount: v.EggbreakCostPropCount,
			EggbreakStatus:        v.EggbreakStatus,
		}

		if v.EggbreakCostPropId == form.EggBreakConfigTypeGold {
			item.EggbreakConfigType = enum.EggBreakConfigTypeGold
		} else if v.EggbreakCostPropId == form.EggBreakConfigTypeSilver {
			item.EggbreakConfigType = enum.EggBreakConfigTypeSilver
		}

		for _, r := range v.AppEggbreakRewardRate {
			item.EggbreakRewardRate = append(item.EggbreakRewardRate, &response.EggBreakRewardRate{
				PropType:     r.AppProp.PropType,
				PropId:       r.AppProp.PropId,
				PropName:     r.AppProp.PropName,
				PropPrice:    r.AppProp.PropPrice,
				PropOrgPrice: r.AppProp.PropPrice, /*r.AppProp.PropOrgPrice*/
				PropIcon:     r.AppProp.PropIcon,
				Rate:         fmt.Sprintf("%.2f%%", float64(r.RateRate)/100),
				RateValue:    r.RateRate,
			})
		}

		resp = append(resp, item)
	}

	// 保证金银顺序
	sort.Slice(resp, func(i, j int) bool {
		return resp[i].EggbreakCostPropId < resp[j].EggbreakCostPropId
	})

	for _, v := range resp {
		sort.Slice(v.EggbreakRewardRate, func(i, j int) bool {
			return v.EggbreakRewardRate[i].PropPrice < v.EggbreakRewardRate[j].PropPrice
		})
	}

	response.ResponseOk(c, "获取成功", resp)
}

// 砸蛋设置获取
func EggBreakSetting(c *gin.Context) {
	var userId int64
	if p, ok := c.Get("userID"); ok {
		var err error
		if userId, err = strconv.ParseInt(p.(string), 10, 64); err != nil || userId <= 0 {
			response.ResponseError(c, response.RESPONSE_PERMIT_ERROR, "权限不足", "", "")
			return
		}
	}

	var req = request.EggBreakSettingReq{}
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	var userEggbreakMsg, err = new(redismodels.UserInfo).GetUserEggbreakMsg(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取设置信息错误", "", err.Error())
		return
	}

	response.ResponseOk(c, "获取成功", &response.EggBreakSettingRep{
		UserEggbreakMsg: userEggbreakMsg,
	})
}

// 砸蛋设置修改
func EggBreakSettingChange(c *gin.Context) {
	var userId int64
	if p, ok := c.Get("userID"); ok {
		var err error
		if userId, err = strconv.ParseInt(p.(string), 10, 64); err != nil || userId <= 0 {
			response.ResponseError(c, response.RESPONSE_PERMIT_ERROR, "权限不足", "", "")
			return
		}
	}

	var req = request.EggBreakSettingChangeReq{}
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	var userEggbreakMsg, err = new(redismodels.UserInfo).GetUserEggbreakMsg(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取设置信息错误", "", err.Error())
		return
	}

	if userEggbreakMsg == req.UserEggbreakMsg {
		response.ResponseOk(c, "修改成功", &response.EggBreakSettingChangeRep{
			UserEggbreakMsg: req.UserEggbreakMsg,
		})
		return
	}

	update := make(map[string]interface{})
	update["user_eggbreak_msg"] = req.UserEggbreakMsg
	if err = new(dbmodels.SystemUser).Update(userId, update); err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "修改失败", "", err.Error())
		return
	}

	if err := new(redismodels.UserInfoUpdate).UpdateUserEggbreakMsg(userId, req.UserEggbreakMsg); err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "修改失败", "", err.Error())
		return
	}

	response.ResponseOk(c, "修改成功", &response.EggBreakSettingChangeRep{
		UserEggbreakMsg: req.UserEggbreakMsg,
	})
}

// 砸蛋
func EggBreak(c *gin.Context) {
	userId := utils.FuncUserId(c)

	var req = request.EggBreakReq{}
	if err := c.ShouldBindJSON(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	_, cfg, err := new(dbmodels.AppEggbreak).QueryFirst(req.EggbreakId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "获取配置数据失败", "", err.Error())
		return
	}
	if cfg.EggbreakId != int64(req.EggbreakId) || cfg.EggbreakStatus != 1 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "未开启活动", "", "")
		return
	}

	resp, msg, err := services.EggBreak(userId, &req)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, msg, msg, err.Error())
		return
	}

	response.ResponseOk(c, "砸蛋成功", resp)
}

// 砸蛋记录
func EggBreakRecords(c *gin.Context) {
	userId := utils.FuncUserId(c)

	var req = request.EggBreakRecordsReq{}
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	var eggBreakId = req.EggbreakId

	_, cfg, err := new(dbmodels.AppEggbreak).QueryFirst(req.EggbreakId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "获取数据失败", "", err.Error())
		return
	}
	if cfg.EggbreakId != int64(req.EggbreakId) || cfg.EggbreakStatus != 1 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "获取数据失败", "", "")
		return
	}

	page, size, skip, err := utils.GetPageAndSize(c)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "分页参数错误", "", err.Error())
		return
	}

	total, result, err := (&dbmodels.AppEggBreakLog{}).Query(userId, eggBreakId, size, skip)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	data := response.BasePageList{
		Page:       page,
		Size:       size,
		Total:      int64(skip) + total,
		TotalPages: utils.FuncTotalPages(int64(skip)+total, size),
		List:       result,
	}
	if result == nil {
		data.List = []string{}
	}
	response.ResponseOk(c, "ok", data)
}

// 砸蛋排行 // tag : daily/weekly
func EggBreakRank(c *gin.Context) {
	var userId int64
	if p, ok := c.Get("userID"); ok {
		var err error
		if userId, err = strconv.ParseInt(p.(string), 10, 64); err != nil || userId <= 0 {
			response.ResponseError(c, response.RESPONSE_PERMIT_ERROR, "权限不足", "", "")
			return
		}
	}

	var req = request.EggBreakRankReq{}
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	_, cfg, err := new(dbmodels.AppEggbreak).QueryFirst(req.RankEggbreakId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "获取数据失败", "", err.Error())
		return
	}
	if cfg.EggbreakId != int64(req.RankEggbreakId) || cfg.EggbreakStatus != 1 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "获取数据失败", "", "")
		return
	}

	var rankPeriod = req.RankPeriod
	var rankName, rankDetailName string
	var nowTime = time.Now()
	switch req.RankTag {
	case "daily":
		rankPeriod = ymd.GetDayDigit(nowTime)
		var r, d = &dbmodels.AppEggBreakRankDay{}, &dbmodels.AppEggBreakRankDetailDay{}
		rankName, rankDetailName = r.TableName(), d.TableName()
	case "weekly":
		rankPeriod = ymd.GetWeekDigit(nowTime)
		var r, d = &dbmodels.AppEggBreakRankWeek{}, &dbmodels.AppEggBreakRankDetailWeek{}
		rankName, rankDetailName = r.TableName(), d.TableName()
	default:
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "排行不存在", "", "")
	}

	var rankRecvData = (&dbmodels.EggBreakRecvRank{}).Init(req.RankEggbreakId, req.RankTag, rankPeriod)
	if err := rankRecvData.Get(); err == nil {
		response.ResponseOk(c, "获取成功", rankRecvData)
		return
	}

	var redisKey = rankRecvData.RedisKey()
	var lockVal, isLock = utils.AcquireLock(redisKey, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
	if !isLock {
		var succeed = trydo.Do(func() (isOver bool) {
			if err := rankRecvData.Get(); err == nil {
				response.ResponseOk(c, "获取成功", rankRecvData)
				return true
			}
			return false
		})
		if !succeed {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取排行失败", "", "")
		}
		return
	}
	defer utils.ReleaseLock(redisKey, lockVal)

	if err := rankRecvData.Query(rankName, rankDetailName); err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取排行失败", "", err.Error())
		return
	}

	_ = rankRecvData.Save()
	response.ResponseOk(c, "获取成功", rankRecvData)
}
