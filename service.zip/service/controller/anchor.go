package controller

import (
	"encoding/json"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"

	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/models/dbmodels"
	"gamers/utils"
)

// 主播申请
func ApplyAnchor(gctx *gin.Context) {
	userId := utils.FuncUserId(gctx)
	var form request.ApplyAnchorReq
	err := gctx.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}

	var userCertification dbmodels.Certification
	_, err = userCertification.VerificationByUserId(userId)
	//if err != nil && err != gorm.ErrRecordNotFound {
	//	response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
	//	return
	//}
	//if err != nil {
	//	response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "当前账户未通过实名认证", "", "")
	//	return
	//}
	// DONE(@chenjianjun) 以上注释代码做如下调整，更加清晰的表达了意图
	if err != nil {
		if err != gorm.ErrRecordNotFound {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		} else {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "当前账户未通过实名认证", "", "")
		}
		return
	}

	// 校验属性合法性
	attr := dbmodels.AppLiveAttr{}
	attr, err = attr.GetAppLiveAttrById(form.AttrID)
	//if err != nil && err != gorm.ErrRecordNotFound {
	//	response.ResponseError(gctx, response.RESPONSE_UNKNOWN, "服务器错误!", "", err.Error())
	//	return
	//}
	//if err != nil {
	//	response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "申请类型不存在", "", err.Error())
	//	return
	//}
	// DONE(@chenjianjun) 以上注释代码做如下调整，更加清晰的表达了意图
	if err != nil {
		if err != gorm.ErrRecordNotFound {
			response.ResponseError(gctx, response.RESPONSE_UNKNOWN, "服务器错误!", "", err.Error())
		} else {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "申请类型不存在", "", err.Error())
		}
		return
	}

	// 主播技能
	anchor := dbmodels.AppAnchorSkill{
		SkillStatus: dbmodels.ANCHOR_SKILL_STATUS_INIT,
		SkillUserID: userId,
		SkillAttrId: form.AttrID,
	}
	// 判断是否存在此游戏的认证
	localanchor, err := anchor.GetAnchorByAttr(form.AttrID, userId)
	//if err != nil && err != gorm.ErrRecordNotFound {
	//	response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
	//	return
	//}
	//// 此时有申请记录在审核或已通过，拒绝申请
	//if err == nil && localanchor.SkillStatus != dbmodels.ANCHOR_SKILL_STATUS_PASS {
	//	response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "您已申请过此类型主播，请不要重复申请哦", "", "")
	//	return
	//}
	//// 判断是更新还是新建,此时更新数据库
	//if err != nil {
	//	err = anchor.Create()
	//} else {
	//	localanchor.SkillStatus = dbmodels.ANCHOR_SKILL_STATUS_INIT
	//	err = localanchor.Save()
	//}
	// DONE(@chenjianjun) 以上注释代码做如下调整，更加清晰的表达了意图
	if err != nil {
		if err != gorm.ErrRecordNotFound {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}

		// 没有技能记录，则创建
		err = anchor.Create()
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_UNKNOWN, "服务器错误!", "", err.Error())
			return
		}
	} else {
		if localanchor.SkillStatus != dbmodels.ANCHOR_SKILL_STATUS_PASS {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "您已申请过此类型主播，请不要重复申请哦", "", "")
			return
		}

		// 认证失败的场景，做更新，置状态为初始状态
		localanchor.SkillStatus = dbmodels.ANCHOR_SKILL_STATUS_INIT
		err = localanchor.Save()
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_UNKNOWN, "服务器错误!", "", err.Error())
			return
		}
	}

	tip := utils.GenerateTips(3)
	response.ResponseOk(gctx, "提交成功", tip)

	return
}

// 获取属性(主播申请使用)
func GetLiveAttrByAnchor(c *gin.Context) {
	model := dbmodels.AppLiveAttr{}
	attrs, err := model.QueryAttrByAnchor()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	// DONE(@chenjianjun) 此场景先做预分配，可以有效的阻止底层数组扩容的问题，调整如下
	// data := []response.QueryAttrByAnchorRes{}
	data := make([]response.QueryAttrByAnchorRes, 0, len(attrs))
	for _, v := range attrs {
		rt := response.QueryAttrByAnchorRes{
			AttrID:         v.AttrID,
			AttrName:       v.AttrName,
			AttrDemand:     v.AttrDemand,
			AttrDirections: v.AttrDirections,
			AttrType:       v.AttrType,
			AttrSort:       v.AttrSort,
		}
		err = json.Unmarshal([]byte(v.AttrBackground), &rt.AttrBackground)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "反序列化背景图失败", "", err.Error())
			return
		}
		data = append(data, rt)
	}
	response.ResponseOk(c, "ok", data)
	return
}

// 获取礼物收入记录
func GetGiftIncome(c *gin.Context) {
	userId := utils.FuncUserId(c)
	//获取分页参数
	page, size, skip, err := utils.GetPageAndSize(c)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "分页参数错误", "", err.Error())
		return
	}
	total, result, err := new(dbmodels.AppAnchorRoomProp).GetGiftIncomeByAnchorId(userId, size, skip)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	data := response.BasePageList{
		Page:       page,
		Size:       size,
		Total:      total,
		TotalPages: utils.FuncTotalPages(total, size),
		List:       result,
	}
	if result == nil {
		data.List = []string{}
	}
	response.ResponseOk(c, "ok", data)
	return
}

// 获取审核状态
func GetCheckStatusInfo(c *gin.Context) {
	userId := utils.FuncUserId(c)
	data, err := new(dbmodels.AppAnchorSkill).GetCheckInfoByUserId(userId)
	if err != nil && err != gorm.ErrRecordNotFound {
		utils.LogInfoF("查询用户待审核状态技能失败,err:%s", err.Error())
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "ok", data)
	return
}
