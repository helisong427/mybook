package controller

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/utils"
	"github.com/gin-gonic/gin"
)

//搜索推荐
func SearchRecommend(c *gin.Context) {
	userId := utils.FuncUserId(c)
	r, err := services.SearchRecommend(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取搜索推荐成功", r)
	return
}

//搜索结果
func SearchResultsList(c *gin.Context) {
	paramsJSON := request.SearchResultsListReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}
	r, err := services.SearchResultsList(paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "搜索失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "搜索成功", r)
	return
}
