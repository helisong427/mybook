package controller

import (
	"fmt"
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/models/dbmodels"
	"gamers/utils"
	"github.com/gin-gonic/gin"
)

//商城--购买道具
func ShoppingBuyProp(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.ShoppingBuyPropReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}
	key := fmt.Sprintf("%s%d", utils.REDIS_USER_WALLET_LOCK, userId)
	lock, islock := utils.AcquireLock(key, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
	if !islock {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "请稍后再试", "", "")
		return
	}
	// 释放锁
	defer utils.ReleaseLock(key, lock)

	msg, userBuyOver, data, err := services.ShoppingBuyProp(paramsJSON, userId)
	if err != nil {
		if msg == "余额不足" {
			response.ResponseError(c, response.RESPONSE_BALANCE_ERROR, msg, "", err.Error())
		} else {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		}
		return
	}

	if paramsJSON.PropType != dbmodels.DB_PROP_TYPE_HAMMER {
		response.ResponseOk(c, "购买成功", gin.H{"user_buy_over": userBuyOver})
	} else {
		response.ResponseOk(c, "购买成功", gin.H{"user_buy_over": userBuyOver, "backpack_count": data.BackpackCount})
	}
}

//商城--装扮属性
func ShoppingDressAttr(c *gin.Context) {
	list, err := services.ShoppingDressAttr()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取装扮属性失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取装扮属性成功", list)
	return
}

//商城--装扮列表
func ShoppingDressUpList(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.ShoppingDressUpListReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}

	list, err := services.ShoppingDressUpList(paramsJSON, userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取装扮失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取装扮列表成功", list)
	return
}

//商城--使用装扮
func ShoppingDressUpUse(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.ShoppingDressUpUseReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}
	err = services.ShoppingDressUpUse(userId, paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "使用装扮失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "使用成功", nil)
	return
}

//商城--取下装扮
func ShoppingDressTakeOff(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.ShoppingDressTakeOffReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}
	err = services.ShoppingDressTakeOff(userId, paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "取下装扮失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "取下装扮成功", nil)
	return
}
