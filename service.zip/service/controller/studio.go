package controller

import (
	"encoding/json"
	"fmt"
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/mq/rabbitmqProducer"
	"gamers/utils"
	"gamers/utils/agora/token"
	"gamers/utils/moderation"
	"sort"
	"strconv"
	"time"

	"github.com/gin-gonic/gin/binding"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// 获取声网token
func AgoraToken(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.AgoraTokenReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	// 这个用户如果没有直播间
	model := dbmodels.AppLiveRoom{}
	data, err := model.QueryRoomId(paramsJSON.RoomId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间不存在", "", err.Error())
		return
	}
	rtcToken := token.CreateRTCToken(uint64(data.RoomId), uint64(userId), paramsJSON.Role)
	if rtcToken == "" {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "未获取到agoraToken", "", "")
		return
	}
	r := response.AgoraTokenRep{Token: rtcToken}
	response.ResponseOk(c, "获取成功", r)
	return
}

// 获取房间列表
func GetStudioList(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.StudioListReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	room := dbmodels.AppLiveRoom{}
	list := []dbmodels.AppLiveRoom{}
	var total int64
	// 推荐
	if paramsJSON.RoomAttrId == 0 {
		total, list, err = redismodels.NewRoomHeat().List(int64(paramsJSON.Page), int64(paramsJSON.Size), *paramsJSON.RoomType)
	} else {
		total, list, err = room.GetStudioList(userId, paramsJSON.RoomAttrId, *paramsJSON.RoomType, paramsJSON.Page, paramsJSON.Size)
	}

	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "列表查询错误", "", err.Error())
		return
	}
	r := response.GetStudioListRep{}
	for _, v := range list {
		result := response.AppLiveRoomResult{}
		result.RoomId = v.RoomId
		result.RoomAttrId = v.RoomAttrId
		result.RoomSpeakType = v.RoomSpeakType
		result.RoomUnionId = v.RoomUnionId
		result.RoomLiveStatus = v.RoomLiveStatus
		result.RoomType = v.RoomType
		result.RoomUserId = v.RoomUserId
		result.RoomUserAge = utils.FuncGetAge(int(v.SystemUser.UserBirthday))
		result.RoomUserGender = v.SystemUser.UserGender
		result.RoomCover = v.RoomCover
		result.RoomTitle = v.RoomTitle
		result.RoomOpenIm = v.RoomOpenIm
		result.RoomUserName = v.SystemUser.UserNickname
		result.RoomUserIconurl = v.SystemUser.UserIconurl
		result.RoomStatus = v.RoomStatus
		result.Hot = int(v.RoomHeat)
		result.RoomPkState = v.RoomPkState
		// 处理热度为负数
		if result.Hot < 0 {
			result.Hot = 0
		}
		if v.RoomPassword != "" {
			result.RoomIsPassword = 1
		}
		result.RoomName = v.RoomName
		result.RoomAttrName = v.RoomLiveAttr.AttrName

		// 如果是派对房
		if v.RoomType == dbmodels.ROOM_TYPE_PARTY {
			// 获取主持信息
			wheatDetail, _ := new(redismodels.Wheat).QueryWheatDetail(int(v.RoomId))
			if len(wheatDetail.WheatObj) > 0 {
				result.RoomPreside = response.RoomPreside{
					PresideName:    wheatDetail.WheatObj[0].UserNickName,
					PresideIconurl: wheatDetail.WheatObj[0].UserIconurl,
				}
			}
		}

		r.List = append(r.List, result)
	}

	// 获取用户余额
	info, err := new(redismodels.UserInfo).GetUserInfo(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户余额失败", "", err.Error())
		return
	}
	r.WalletTotalOver = info.WalletTotalOver
	r.Size = paramsJSON.Size
	r.Page = paramsJSON.Page
	r.Total = int64(total)
	r.TotalPages = utils.FuncTotalPages(int64(total), paramsJSON.Size)
	response.ResponseOk(c, "ok", r)
	return
}

// 直播准备界面
func CreateStudio(c *gin.Context) {

	userId := utils.FuncUserId(c)
	// 绑定参数
	paramJson := request.CreateStudioReq{}
	err := c.ShouldBindJSON(&paramJson)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	str := moderation.TextModeration(paramJson.RoomName)
	if len(str) > 0 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "房间名称包含敏感词", "", "")
		return
	}
	str = moderation.TextModeration(paramJson.RoomTitle)
	if len(str) > 0 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "房间标题包含敏感词", "", "")
		return
	}
	str = moderation.TextModeration(paramJson.RoomContent)
	if len(str) > 0 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "房间简介包含敏感词", "", "")
		return
	}

	// 判断麦位选择
	if *paramJson.RoomType == dbmodels.ROOM_TYPE_LIVE {
		if *paramJson.RoomSpeakType != dbmodels.SPEAK_TYPE_LIVE_WITH_MIC && *paramJson.RoomSpeakType != dbmodels.SPEAK_TYPE_LIVE_WITHOUT_MIC {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "麦位选择有误", "", "")
			return
		}
	} else {
		var userCertification dbmodels.Certification
		_, err = userCertification.VerificationByUserId(userId)
		if err != nil && err != gorm.ErrRecordNotFound {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前账户未通过实名认证", "", "")
			return
		}
		if *paramJson.RoomSpeakType != dbmodels.SPEAK_TYPE_PARTY_FREE_MIC && *paramJson.RoomSpeakType != dbmodels.SPEAK_TYPE_PARTY_WITH_MIC {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "麦位选择有误", "", "")
			return
		}
	}
	partyAttr, err := new(dbmodels.AppLiveAttr).GetPartyDefaultAttr()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取默认标签出错", "", err.Error())
		return
	}
	// 判断属性
	var attr dbmodels.AppLiveAttr
	attr, err = attr.GetAppLiveAttrByIdAndType(paramJson.RoomAttrId, *paramJson.RoomType)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询属性错误", "", err.Error())
		return
	}
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "该房间类型无此属性", "", "")
		return
	}
	// 校验是否通过主播认证
	if *paramJson.RoomType == dbmodels.ROOM_TYPE_LIVE {
		var anchor dbmodels.AppAnchorSkill
		anchor, err = anchor.GetAnchorByAttr(paramJson.RoomAttrId, userId)
		if err != nil && err != gorm.ErrRecordNotFound {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询用户直播属性错误", "", err.Error())
			return
		}
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "该用户未认证此属性", "", "")
			return
		}
	}
	userInfo, err := new(redismodels.UserInfo).GetUserInfo(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户信息失败", "", "")
		return
	}

	room, err := new(dbmodels.AppLiveRoom).GetRoomInfoByUserId(userId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户直播间出错", "", err.Error())
		return
	}
	var rep services.CreateStudioResp
	oldStatus := 1
	tx := utils.GEngine.Begin()
	// 如果新建房间，加入腾讯im群组
	if err != nil {
		err, room = services.CreateNewStudio(&paramJson, tx, &userInfo)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "创建房间失败", "", err.Error())
			tx.Rollback()
			return
		}
		rep.RoomInfo = room
	} else {
		oldStatus = room.RoomStatus
		if oldStatus == dbmodels.ROOM_STATUS_PLATFORM_RECTIFICATION || oldStatus == dbmodels.ROOM_STATUS_PLATFORM_BAN {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前房间状态不能开播", "", "")
			return
		}
		if room.RoomType == dbmodels.ROOM_TYPE_LIVE {
			if room.RoomLiveStatus == dbmodels.ROOM_LIVE_STATUS_OFF || room.RoomLiveStatus == dbmodels.ROOM_LIVE_STATUS_TIMEOUT {
				// 收益
				err, settlement := new(dbmodels.AppAnchorRoomProp).GetLiveAnchorIncome(userId, room.RoomId, room.RoomLastOffline, 0)
				if err != nil {
					response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取礼物收益失败", "", err.Error())
					return
				}
				rep.Settlement = settlement
			}
		}
		err = services.CreateUpdateStudio(&paramJson, tx, &userInfo, &room, &partyAttr)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "更新房间失败", "", err.Error())
			tx.Rollback()
			return
		}
		rep.RoomInfo = room
	}
	// 初始化麦位
	err = new(redismodels.Wheat).Init(int(room.RoomId), userId, *paramJson.RoomType, *paramJson.RoomSpeakType)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "开启麦位失败", "", err.Error())
		tx.Rollback()
		return
	}
	err = tx.Commit().Error
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "创建房间失败", "", err.Error())
		tx.Rollback()
		return
	}
	msg := services.InitLiveMsg()
	go msg.AssistantLiveStart(&room, &userInfo)
	go msg.AnnounceLiveStart(&room)
	if oldStatus == dbmodels.ROOM_STATUS_ADMIN_OFF || oldStatus == dbmodels.ROOM_STATUS_TIME_OUT_OFF {
		go msg.AssistantStudioOpen(&room, userInfo.UserNickname)
	}
	response.ResponseOk(c, "ok", rep)
	return
}

// 更新房间信息
func UpdateStudio(c *gin.Context) {
	userId := utils.FuncUserId(c)
	update := make(map[string]interface{})
	paramsJSON := request.UpdateStudioReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	str := moderation.TextModeration(paramsJSON.RoomName)
	if len(str) > 0 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "房间名称包含敏感词", "", "")
		return
	}
	str = moderation.TextModeration(paramsJSON.RoomContent)
	if len(str) > 0 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "房间简介包含敏感词", "", "")
		return
	}
	str = moderation.TextModeration(paramsJSON.RoomTitle)
	if len(str) > 0 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "房间标题包含敏感词", "", "")
		return
	}

	// 音频直播,RoomSpeakType <= 1
	if paramsJSON.RoomType == dbmodels.ROOM_TYPE_LIVE {
		if paramsJSON.RoomSpeakType > dbmodels.SPEAK_TYPE_LIVE_WITH_MIC {
			response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", "room_speak_type只能是:0或者1")
			return
		}
	} else {
		// 音频直播,RoomSpeakType >= 2
		if paramsJSON.RoomSpeakType < dbmodels.SPEAK_TYPE_PARTY_FREE_MIC {
			response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", "room_speak_type只能是:2或者3")
			return
		}

	}

	// TODO 公会派对房间不支持切换为直播房间

	// 如果设置密码
	if paramsJSON.RoomIsPassword == 1 {
		if len([]rune(paramsJSON.RoomPassword)) < 4 {
			response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "密码最小长度为4", "", "")
			return
		}
		update["room_password"] = paramsJSON.RoomPassword
	} else {
		update["room_password"] = ""
	}

	room, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(paramsJSON.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间不存在", "", err.Error())
		return
	}

	if room.RoomStatus != dbmodels.ROOM_STATUS_OK {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前房间状态不能更改房间类型,请先开启房间", "", "")
		return
	}
	oldSpeakType := room.RoomSpeakType
	oldRoomType := room.RoomType

	// 当前房间正在pk不支持修改麦位模式
	if paramsJSON.RoomSpeakType != oldSpeakType && room.RoomPkState != dbmodels.RoomPkCloseStage {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前房间正在pk不能更改麦位模式", "", "")
		return
	}

	userInfo, err := new(redismodels.UserInfo).GetUserInfo(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户信息失败", "", "")
		return
	}
	role, err := new(redismodels.Wheat).QueryUserRole(int(paramsJSON.RoomId), userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if role < redismodels.WHEAT_ROLE_ADMIN {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "无权操作", "", "")
		return
	}
	// 验证用户是否主播认证
	anchor, err := new(dbmodels.AppAnchorSkill).VerificationByUserId(userId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	// 如果状态发生改变
	if room.RoomType != paramsJSON.RoomType {
		if role != redismodels.WHEAT_ROLE_ANCHOR || err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "非房主或未认证主播,无权操作修改房间玩法", "", "")
			return
		}
		// 判断房间是否为工会房间
		if room.RoomUnionId != 0 {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "工会房间无法切换类型", "", "")
			return
		}
	}
	err = services.UpdateStudioInfo(&paramsJSON, &room, &anchor)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "更新房间失败", "", err.Error())
		return
	}
	liveInfo := redismodels.LiveInfo{
		RoomId:             room.RoomId,
		RoomPrettyId:       room.RoomPrettyId,
		RoomType:           room.RoomType,
		RoomName:           room.RoomName,
		RoomCover:          room.RoomCover,
		RoomBackground:     room.RoomBackground,
		RoomTitle:          room.RoomTitle,
		RoomContent:        room.RoomContent,
		RoomUnionId:        room.RoomUnionId,
		RoomUserId:         room.RoomUserId,
		RoomAttrId:         room.RoomAttrId,
		RoomAttrName:       room.RoomLiveAttr.AttrName,
		RoomSpeakType:      room.RoomSpeakType,
		RoomOpenIm:         room.RoomOpenIm,
		RoomLiveStatus:     room.RoomLiveStatus,
		RoomLastOnline:     room.RoomLastOnline,
		RoomEggbreakMsg:    room.RoomEggbreakMsg,
		RoomPkSwitch:       room.RoomPkSwitch,
		RoomPkState:        room.RoomPkState,
		RoomPkRecordPunish: room.RoomPkRecordPunish,
	}

	if paramsJSON.RoomIsPassword == 1 {
		liveInfo.RoomIsPassword = 1
		liveInfo.RoomPassword = paramsJSON.RoomPassword
	}

	// 发送更新麦位状态IM消息
	// 判断房间玩法是否改变
	if oldSpeakType != paramsJSON.RoomSpeakType || oldRoomType != paramsJSON.RoomType {

		// 切换模式后删除所有上麦邀请
		m := services.InviteUpWheat{
			RoomId: int(room.RoomId),
		}
		err = m.RemoveInviteUpWheatLog()
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		// 是否重置主播麦位
		isResetAnchor := false
		// 是否重置麦位
		isResetWheat := false
		if oldRoomType != paramsJSON.RoomType {
			// 修改了房间模式,重置麦位
			isResetAnchor = true
			isResetWheat = true
		}
		if paramsJSON.RoomSpeakType == dbmodels.SPEAK_TYPE_LIVE_WITHOUT_MIC || paramsJSON.RoomSpeakType == dbmodels.SPEAK_TYPE_LIVE_WITH_MIC {
			isResetAnchor = true
			isResetWheat = true
		}

		action := redismodels.WHEAT_SWITCH_ON
		wheat := redismodels.Wheat{}
		// 派对模式默认开启麦位
		if paramsJSON.RoomType == dbmodels.ROOM_TYPE_PARTY {
			wheat, err = new(redismodels.Wheat).SwitchPlayWheat(int(paramsJSON.RoomId), room.RoomUserId, redismodels.WHEAT_SWITCH_ON, paramsJSON.RoomType, isResetAnchor, isResetWheat)
		} else {
			// 音频直播无麦位
			if paramsJSON.RoomSpeakType == dbmodels.SPEAK_TYPE_LIVE_WITHOUT_MIC {
				wheat, err = new(redismodels.Wheat).SwitchPlayWheat(int(paramsJSON.RoomId), room.RoomUserId, redismodels.WHEAT_SWITCH_OFF, paramsJSON.RoomType, isResetAnchor, isResetWheat)
				action = redismodels.WHEAT_SWITCH_OFF
			} else {
				wheat, err = new(redismodels.Wheat).SwitchPlayWheat(int(paramsJSON.RoomId), room.RoomUserId, redismodels.WHEAT_SWITCH_ON, paramsJSON.RoomType, isResetAnchor, isResetWheat)
			}
		}
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, err.Error(), "", "")
			return
		}
		go new(services.LiveMsg).AnnounceSwitchWheat(&room, &wheat, action)
	}
	if paramsJSON.RoomType == dbmodels.ROOM_TYPE_LIVE {
		msg := services.InitLiveMsg()
		go msg.AssistantLiveStart(&room, &userInfo)
		go msg.AnnounceLiveStart(&room)
	}
	Anchor := &redismodels.LiveAnchorInfo{
		UserID:       liveInfo.RoomUserId,
		UserIconurl:  room.SystemUser.UserIconurl,
		UserNickname: room.SystemUser.UserNickname,
	}
	// 发送更新房间IM消息
	go new(services.LiveMsg).AnnounceUpdateRoom(&liveInfo, Anchor, userId)
	// 删除缓存
	go utils.RedisClient.Del(fmt.Sprintf("%s%d", utils.REDIS_LIVE_ROOM_INFO, paramsJSON.RoomId))

	// 切换房间热度
	if paramsJSON.RoomType != room.RoomType {
		go redismodels.NewRoomHeat().ChangeHeat(int(paramsJSON.RoomId), paramsJSON.RoomType)
	}
	response.ResponseOk(c, "ok", liveInfo)
	return
}

// 关闭直播间
func CloseStudio(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.CloseStudioReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	roomInfo, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(paramsJSON.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询房间信息错误", "", err.Error())
		return
	}
	if roomInfo.RoomStatus != dbmodels.ROOM_STATUS_OK || roomInfo.RoomType != dbmodels.ROOM_TYPE_PARTY {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前房间状态不允许关闭", "", "")
		return
	}
	// 判断是否在pk
	if roomInfo.RoomPkState != dbmodels.RoomPkCloseStage {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "pk玩法正在进行中，请结束pk后再试", "", "")
		return
	}

	userInfo, err := new(redismodels.UserInfo).GetUserInfo(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户信息失败", "", err.Error())
		return
	}
	role, err := new(redismodels.Wheat).QueryUserRole(int(paramsJSON.RoomId), userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if role < redismodels.WHEAT_ROLE_ADMIN {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "无权操作", "", "")
		return
	}
	tx := utils.GEngine.Begin()
	update := make(map[string]interface{})
	roomInfo.RoomStatus = dbmodels.ROOM_STATUS_ADMIN_OFF
	roomInfo.RoomLiveStatus = dbmodels.ROOM_LIVE_STATUS_OFF
	update["room_live_status"] = dbmodels.ROOM_LIVE_STATUS_OFF
	update["room_status"] = dbmodels.ROOM_STATUS_ADMIN_OFF
	err = new(dbmodels.AppLiveRoom).UpdateByTranslation(tx, paramsJSON.RoomId, update)
	if err != nil {
		utils.LogErrorF("关闭房间状态更新失败[%d],%s", paramsJSON.RoomId, err.Error())
		return
	}
	logModel := dbmodels.AppRoomCloseLog{
		LogRoomId:    paramsJSON.RoomId,
		LogType:      dbmodels.CLOSE_LOG_TYPE_ADMIN_CLOSE,
		LogRemark:    "关闭派对房间",
		LogStartTime: time.Now().Unix(),
	}
	err = logModel.Create(tx)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "关闭房间日志创建失败", "", err.Error())
		return
	}
	err = tx.Commit().Error
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "关闭房间失败", "", err.Error())
		return
	}
	err = utils.RedisClient.Set(utils.REDIS_LIVE_ROOM_INFO+strconv.Itoa(int(roomInfo.RoomId)), roomInfo, -1).Err()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "缓存房间信息失败", "", err.Error())
		return
	}
	_, err = new(redismodels.Wheat).SwitchWheatLove(int(roomInfo.RoomId), userId, redismodels.WHEAT_SWITCH_OFF, true)
	if err != nil && err != redismodels.ErrWheatCantOpenLove {
		utils.LogErrorF("关闭房间时，关闭爱意值失败,err:%s", err.Error())
	}
	liveMsg := services.InitLiveMsg()
	// 发送消息
	go liveMsg.AssistantStudioClose(&roomInfo, userInfo.UserNickname)
	go liveMsg.AnnounceStudioCloseAndOpen(&roomInfo, true)
	// 删除热度
	go redismodels.NewRoomHeat().Delete(int(roomInfo.RoomId))
	// 禁止排行
	go func() {
		_, _ = new(redismodels.RankRoomSendCharm).Init("hourly", time.Now(), redismodels.RankRoomItemLengthHourly).Ban(roomInfo.RoomId)
	}()
	response.ResponseOk(c, "ok", roomInfo)
	return
}

// 开启直播间
func OpenStudio(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.CloseStudioReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	roomInfo, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(paramsJSON.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询房间信息错误", "", err.Error())
		return
	}
	if roomInfo.RoomType != dbmodels.ROOM_TYPE_PARTY {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前房间状态不允许开启", "", "")
	}
	if roomInfo.RoomStatus != dbmodels.ROOM_STATUS_ADMIN_OFF && roomInfo.RoomStatus != dbmodels.ROOM_STATUS_TIME_OUT_OFF {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前房间状态不允许开启", "", "")
		return
	}
	userInfo, err := new(redismodels.UserInfo).GetUserInfo(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户信息失败", "", err.Error())
		return
	}
	role, err := new(redismodels.Wheat).QueryUserRole(int(paramsJSON.RoomId), userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if role < redismodels.WHEAT_ROLE_ADMIN {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "无权操作", "", "")
		return
	}
	closeLog, err := new(dbmodels.AppRoomCloseLog).GetLastCloseInfoByRoomId(roomInfo.RoomId, dbmodels.CLOSE_LOG_TYPE_ADMIN_CLOSE, dbmodels.CLOSE_LOG_TYPE_TIMEOUT_CLOSE)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询关闭日志错误", "", err.Error())
		return
	}
	tx := utils.GEngine.Begin()
	update := make(map[string]interface{})
	roomInfo.RoomStatus = dbmodels.ROOM_STATUS_OK
	update["room_status"] = dbmodels.ROOM_STATUS_OK
	err = new(dbmodels.AppLiveRoom).UpdateByTranslation(tx, paramsJSON.RoomId, update)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "开启房间失败", "", err.Error())
		return
	}
	closeLog.LogEndTime = time.Now().Unix()
	err = closeLog.Update(tx)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "开启房间失败", "", err.Error())
		return
	}
	err = tx.Commit().Error
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "开启房间失败", "", err.Error())
		return
	}
	err = utils.RedisClient.Set(utils.REDIS_LIVE_ROOM_INFO+strconv.Itoa(int(roomInfo.RoomId)), roomInfo, -1).Err()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "缓存房间信息失败", "", err.Error())
		return
	}
	// 如果打开房间，也推送关闭房间任务，防止不上主持麦漏处理
	rabbitmqProducer.ProducerCloseRoom(int(roomInfo.RoomId))
	liveMsg := services.InitLiveMsg()
	// 发送消息
	go liveMsg.AssistantStudioOpen(&roomInfo, userInfo.UserNickname)
	go liveMsg.AnnounceStudioCloseAndOpen(&roomInfo, false)
	// 允许排行
	go func() {
		_, _ = new(redismodels.RankRoomSendCharm).Init("hourly", time.Now(), redismodels.RankRoomItemLengthHourly).Allow(roomInfo.RoomId)
	}()
	response.ResponseOk(c, "ok", roomInfo)
	return
}

// 获取主播属性
func GetRoomAttrId(c *gin.Context) {
	userId := utils.FuncUserId(c)
	model := dbmodels.AppAnchorSkill{}
	ans, err := model.GetAnchorById(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取主播属性失败", "", err.Error())
		return
	}
	if len(ans) <= 0 {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "主播属性为空", "", "")
		return
	}
	one := response.GetAttrName{}
	result := []response.GetAttrName{}
	for _, v := range ans {
		live := dbmodels.AppLiveAttr{}
		attr, err := live.GetAppLiveAttrById(v.SkillAttrId)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "属性信息为空", "", err.Error())
			return
		}
		one.SkillAttrId = attr.AttrID
		one.AttrName = attr.AttrName
		one.AttrBackground = attr.AttrBackground
		result = append(result, one)
	}
	response.ResponseOk(c, "ok", result)
	return
}

// 结算直播
func LiveSettlement(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJson := request.LiveSettlementReq{}
	err := c.ShouldBind(&paramsJson)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	room := dbmodels.AppLiveRoom{}
	data, err := room.QueryRoomId(int(paramsJson.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "房间不存在", "", err.Error())
		return
	}
	if data.RoomUserId != userId {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "无权访问", "", "")
		return
	}
	if data.RoomType != dbmodels.ROOM_TYPE_LIVE {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "当前房间未直播", "", "")
		return
	}
	if data.RoomLiveStatus == dbmodels.ROOM_LIVE_STATUS_ON {
		// 收益
		err, settlement := new(dbmodels.AppAnchorRoomProp).GetLiveAnchorIncome(userId, paramsJson.RoomId, data.RoomLastOnline, data.RoomLogId)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取礼物收益失败", "", err.Error())
			return
		}

		settlement.LiveTime = time.Now().Unix() - data.RoomLastOnline
		response.ResponseOk(c, "ok", settlement)
		return
	}
	// 收益
	err, settlement := new(dbmodels.AppAnchorRoomProp).GetLiveAnchorIncome(data.RoomUserId, paramsJson.RoomId, data.RoomLastOffline, 0)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取礼物收益失败", "", err.Error())
		return
	}

	settlement.LiveTime = time.Now().Unix() - data.RoomLastOffline
	response.ResponseOk(c, "ok", settlement)
	return
}

// 直播间详情
func GetStudioInfo(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramJson := request.StudioCardReq{}
	err := c.ShouldBind(&paramJson)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "参数错误", "", err.Error())
		return
	}
	// 获取房间信息
	data, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(paramJson.RoomId))
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取房间信息失败", "", err.Error())
		return
	}
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间不存在", "", err.Error())
		return
	}
	// 获取系统公告
	param, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_LIVE_ANNOUNCE)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取系统公告失败", "", err.Error())
		return
	}
	room := response.GetStudioInfo{
		RoomType:           data.RoomType,
		RoomLiveStatus:     data.RoomLiveStatus,
		RoomStatus:         data.RoomStatus,
		RoomId:             data.RoomId,
		RoomPrettyId:       data.RoomPrettyId,
		RoomUserId:         data.RoomUserId,
		RoomPassword:       data.RoomPassword,
		RoomUnionId:        data.RoomUnionId,
		RoomEggbreakMsg:    data.RoomEggbreakMsg,
		RoomName:           data.RoomName,
		RoomBackground:     data.RoomBackground,
		RoomContent:        data.RoomContent,
		RoomCover:          data.RoomCover,
		RoomLastOnline:     data.RoomLastOnline,
		RoomOpenIm:         data.RoomOpenIm,
		RoomSpeakType:      data.RoomSpeakType,
		RoomTitle:          data.RoomTitle,
		RoomAttrId:         data.RoomAttrId,
		RoomPkSwitch:       data.RoomPkSwitch,
		RoomPkRecordPunish: data.RoomPkRecordPunish,
		RoomPkState:        data.RoomPkState,
		AttrName:           data.RoomLiveAttr.AttrName,
	}

	// 获取pk信息
	if data.RoomPkSwitch == dbmodels.RoomPkFunctionOpen {
		if data.RoomPkState != dbmodels.RoomPkCloseStage && data.RoomPkState != dbmodels.RoomPkReadyStage {
			pkInfo, err := new(redismodels.RoomPkDetail).GetRoomPkInfo(data.RoomId)
			if err != nil {
				response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取pk信息失败", "", err.Error())
				return
			}
			room.RoomPKMvpId = pkInfo.RoomPKMvpId
			room.RoomPKSvpId = pkInfo.RoomPKSvpId
			room.RoomPKCharmKingId = pkInfo.RoomPKCharmKingId
			room.RoomPKDetailRed = pkInfo.RoomPKDetailRed
			room.RoomPKDetailBlue = pkInfo.RoomPKDetailBlue
			room.RoomGloryStar.Icon = pkInfo.RoomPkDetailGloryStar.Icon
			room.RoomGloryStar.UserId = pkInfo.RoomPkDetailGloryStar.UserId
			room.RoomGloryStar.UserPrettyId = pkInfo.RoomPkDetailGloryStar.UserPrettyId
			room.RoomGloryStar.NickName = pkInfo.RoomPkDetailGloryStar.NickName
			room.RoomGloryStar.Gender = pkInfo.RoomPkDetailGloryStar.Gender
			room.RoomPKRemainingTime = pkInfo.RoomPKDetailExpectedEnd - time.Now().Unix()
		}
	}

	// 查询麦位列表
	detail, err := new(redismodels.Wheat).QueryWheatDetail(int(data.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询麦位列表失败", "", err.Error())
		return
	}
	resultEck := struct {
		Detail          redismodels.Wheat      `json:"detail"`           // 麦位
		RoomData        response.GetStudioInfo `json:"room_data"`        // 房间信息
		IsAdmin         int8                   `json:"is_admin"`         // 房间角色(0房间副管理员,1房间管理员,2主播,3房东)
		RecommendStudio []dbmodels.AppLiveRoom `json:"recommend_studio"` // 当前房间主播不在或下播的时候，推荐类似房间
		IsFavorite      int                    `json:"is_favorite"`      // 是否关注改房间，0未关注，1关注
		Anchor          response.AnchorInfo    `json:"anchor"`
		OnlineMemberNum int                    `json:"online_member_num"`
		LiveAnnounce    string                 `json:"live_announce"` // 直播系统公告
	}{
		LiveAnnounce: param["value"],
	}

	admin := dbmodels.AppRoomAdmin{}
	rAdmin, err := admin.GetAnchorByUIdAndRId(userId, paramJson.RoomId)
	if err != nil || rAdmin.AdminID == 0 {
		resultEck.IsAdmin = 0
	}
	if rAdmin.AdminRole > dbmodels.ROOM_ADMIN_ROLE_LANDLORD || rAdmin.AdminRole < dbmodels.ROOM_ADMIN_ROLE_NORMAL {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取当前用户角色失败", "", "")
		return
	} else {
		resultEck.IsAdmin = int8(rAdmin.AdminRole)
	}
	resultEck.Detail = detail
	resultEck.RoomData = room
	resultEck.OnlineMemberNum = services.GetOnlineMember(strconv.Itoa(int(paramJson.RoomId)))
	favorite := dbmodels.AppRoomFavorite{}
	row, err := favorite.GetIsFavoriteByUId(userId, paramJson.RoomId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取收藏记录失败", "", err.Error())
		return
	}
	if row == 1 {
		resultEck.IsFavorite = 1
	}
	var user redismodels.UserInfo
	uid := data.RoomUserId
	if data.RoomUserId == 0 {
		uid, err = new(dbmodels.AppRoomAdmin).GetAnchorId(data.RoomId)
		if err != nil {
			utils.LogErrorF("查询房主信息失败,err:%s", err.Error())
		}
	}
	user, err = user.GetUserInfo(uid)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取主播信息失败", "", err.Error())
		return
	}
	resultEck.Anchor.UserID = user.UserID
	resultEck.Anchor.UserNickname = user.UserNickname
	resultEck.Anchor.UserIconurl = user.UserIconurl

	followed, err := new(dbmodels.AppAttention).QueryFollowed(userId, user.UserID)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询用户关注信息失败", "", err.Error())
		return
	}
	if followed > 0 {
		resultEck.Anchor.IsAttention = 1
	}

	// 房间是否有密码
	if data.RoomPassword != "" {
		resultEck.RoomData.RoomIsPassword = 1
	}

	response.ResponseOk(c, "ok", resultEck)
	return
}

// 获取背包礼物信息
func GetBackpackGift(c *gin.Context) {
	userId := utils.FuncUserId(c)
	gifts, err := new(dbmodels.AppBackpack).GetBackPackByUserId(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取背包礼物失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "ok", gifts)
	return
}

// 获取房间名片
func GetStudioCard(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJson := request.StudioCardReq{}
	err := c.ShouldBind(&paramsJson)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	rep := response.StudioCardRep{}
	// 是否存在房间
	roomData, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(paramsJson.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取房间信息失败", "", err.Error())
		return
	}
	rep.RoomCover = roomData.RoomCover
	rep.RoomName = roomData.RoomName
	rep.RoomPrettyId = roomData.RoomPrettyId
	rep.RoomType = roomData.RoomType
	rep.RoomTitle = roomData.RoomTitle
	rep.RoomContent = roomData.RoomContent
	var user redismodels.UserInfo
	uid := roomData.RoomUserId
	if roomData.RoomUserId == 0 {
		uid, err = new(dbmodels.AppRoomAdmin).GetAnchorId(roomData.RoomId)
		if err != nil {
			utils.LogErrorF("查询房主信息失败,err:%s", err.Error())
		}
	}
	user, err = user.GetUserInfo(uid)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户缓存信息失败", "", err.Error())
		return
	}
	rep.RoomId = paramsJson.RoomId
	rep.AdminUserID = user.UserID
	rep.UserSlogan = user.UserSlogan
	rep.UserIconurl = user.UserIconurl
	rep.UserNickname = user.UserNickname

	// 查询用户是否收藏
	row, err := new(dbmodels.AppRoomFavorite).GetIsFavoriteByUId(userId, paramsJson.RoomId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取收藏记录失败", "", err.Error())
		return
	}
	if row == 1 {
		rep.IsFavorite = 1
	}
	data, err := new(dbmodels.AppAnchorRoomProp).GetRoomGiftsCountByRoomId(paramsJson.RoomId, 10)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取直播间礼物失败", "", err.Error())
		return
	}
	rep.GiftCount = data
	response.ResponseOk(c, "ok", rep)
	return
}

// 收藏房间
func FavoriteStudio(c *gin.Context) {
	userId := utils.FuncUserId(c)

	paramsJson := request.LiveFavoriteReq{}
	err := c.ShouldBindJSON(&paramsJson)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	favorite := dbmodels.AppRoomFavorite{}
	favorite.FavoriteUserId = userId
	favorite.FavoriteRoomId = paramsJson.RoomId
	if paramsJson.Flag == 1 {
		// 收藏
		err = favorite.Create()
		if err != nil {
			response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "收藏失败", "", err.Error())
			return
		}
	} else {
		// 取消收藏
		favorite.FavoriteUserId = userId
		favorite.FavoriteRoomId = paramsJson.RoomId
		err := favorite.Deleted()
		if err != nil {
			response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "取消收藏失败", "", err.Error())
			return
		}
	}
	response.ResponseOk(c, "ok", paramsJson.Flag)
	return
}

// 获取用户房间收藏列表
func GetFavoriteList(c *gin.Context) {
	userId := utils.FuncUserId(c)
	favorite := dbmodels.AppRoomFavorite{}
	results, err := favorite.GetListByUserId(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "获取收藏列表失败", "", err.Error())
		return
	}
	type eck struct {
		RoomId      int64  `json:"room_id" `      // 房间id
		RoomType    int    `json:"room_type"`     // 类型(0音频直播,1音频派对)
		RoomName    string `json:"room_name"`     // 房间名称
		RoomCover   string `json:"room_cover"`    // 房间封面
		RoomTitle   string `json:"room_title"`    // 房间标题(排队公告标题)
		RoomUnionId int64  `json:"room_union_id"` // 所属公会id
		RoomUserId  int64  `json:"room_user_id"`  // 所属用户id
	}
	result := []eck{}
	one := eck{}
	room := dbmodels.AppLiveRoom{}
	for _, v := range results {
		data, err := room.QueryRoomId(int(v.FavoriteRoomId))
		if err != nil {
			response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "查询房间信息失败", "", err.Error())
			return
		}
		one.RoomId = data.RoomId
		one.RoomCover = data.RoomCover
		one.RoomTitle = data.RoomTitle
		one.RoomType = data.RoomType
		one.RoomName = data.RoomName
		one.RoomUserId = data.RoomUserId
		one.RoomUnionId = data.RoomUnionId
		result = append(result, one)
	}
	response.ResponseOk(c, "ok", result)
	return
}

// 获取快捷键列表
func GetQuickList(c *gin.Context) {
	reply := dbmodels.AppQuickReply{}
	quick, err := reply.GetQuickReplyByType(dbmodels.REPLY_TYPE_GROUP)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "获取快捷键列表失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "ok", quick)
	return
}

// 主播中心
func GetAnchorCenter(c *gin.Context) {
	userId := utils.FuncUserId(c)
	// 拿到主播直播日志记录
	data, err := services.GetAnchorCenter(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取主播信息失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "ok", data)
	return
}

// 获取创建房间的属性
func GetLiveRoomAttrs(c *gin.Context) {
	var attrs dbmodels.AppLiveAttr
	userId := utils.FuncUserId(c)
	data := make([]response.GetRoomAttrRes, 0)
	attr, err := attrs.QueryAttrByLiveRoom(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取属性失败", "", err.Error())
		return
	}
	if len(attr) == 0 {
		response.ResponseOk(c, "ok", data)
		return
	}

	liveret := response.GetRoomAttrRes{
		Type:  dbmodels.LIVE_ATTR_TYPE_LIVE,
		Attrs: []response.RoomAttr{},
	}
	partyret := response.GetRoomAttrRes{
		Type:  dbmodels.LIVE_ATTR_TYPE_PARTY,
		Attrs: []response.RoomAttr{},
	}
	for _, v := range attr {
		rt := response.RoomAttr{
			AttrID:         v.AttrID,
			AttrName:       v.AttrName,
			AttrDemand:     v.AttrDemand,
			AttrDirections: v.AttrDirections,
		}
		err = json.Unmarshal([]byte(v.AttrBackground), &rt.AttrBackground)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "反序列化背景图失败", "", err.Error())
			return
		}
		if v.AttrType == dbmodels.LIVE_ATTR_TYPE_LIVE {
			liveret.Attrs = append(liveret.Attrs, rt)

		} else if v.AttrType == dbmodels.LIVE_ATTR_TYPE_PARTY {
			partyret.Attrs = append(partyret.Attrs, rt)
		}
	}
	data = append(data, liveret, partyret)
	response.ResponseOk(c, "ok", data)
	return
}

// 获取直播间礼物统计
func GetStudioCountGift(c *gin.Context) {
	paramsJson := request.StudioCardReq{}
	err := c.ShouldBind(&paramsJson)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	data, err := new(dbmodels.AppAnchorRoomProp).GetRoomGiftsCountByRoomId(paramsJson.RoomId, 0)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取直播间礼物失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "ok", data)
	return
}

// 获取直播间礼物
func GetStudioGift(c *gin.Context) {
	paramsJson := request.StudioGiftsReq{}
	err := c.ShouldBind(&paramsJson)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	// 获取分页参数
	page, size, skip, err := utils.GetPageAndSize(c)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "分页参数错误", "", err.Error())
		return
	}
	if page*size > 100 {
		list := response.BasePageList{List: make([]response.LiveRoomGiftResult, 0), Total: 100, Page: page, Size: size, TotalPages: utils.FuncTotalPages(100, size)}
		response.ResponseOk(c, "ok", list)
		return
	}
	total, data, err := new(dbmodels.AppAnchorRoomProp).GetRoomGiftsByRoomId(paramsJson.RoomId, paramsJson.StartT, size, skip)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取直播间礼物失败", "", err.Error())
		return
	}
	list := response.BasePageList{List: data, Total: total, Page: page, Size: size, TotalPages: utils.FuncTotalPages(total, size)}
	response.ResponseOk(c, "ok", list)
	return
}

// 获取用户礼物明细
func GetUserGiftRecord(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJson := request.UserGiftRecordsReq{}
	err := c.ShouldBind(&paramsJson)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	// 获取分页参数
	page, size, skip, err := utils.GetPageAndSize(c)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "分页参数错误", "", err.Error())
		return
	}
	if page*size > 600 {
		list := response.BasePageList{List: make([]response.GiftInfoRecordRes, 0), Total: 600, Page: page, Size: size, TotalPages: utils.FuncTotalPages(600, size)}
		response.ResponseOk(c, "ok", list)
		return
	}

	var income bool
	if *paramsJson.Type == request.USER_GIFT_RECORD_TYPE_INCOME {
		income = true
	}
	total, data, err := new(dbmodels.AppAnchorRoomProp).GetRoomGiftsByUserId(userId, size, skip, income)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户礼物失败", "", err.Error())
		return
	}
	list := response.BasePageList{List: data, Total: total, Page: page, Size: size, TotalPages: utils.FuncTotalPages(total, size)}
	response.ResponseOk(c, "ok", list)
	return
}

// 获取推荐的房间
func GetRecommendStudios(c *gin.Context) {
	// 获取分页参数
	data, err := new(dbmodels.AppLiveRoom).RandRoom()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取推荐房间失败", "", err.Error())
		return
	}

	resp := make([]response.AppLiveRoomResult, 0)
	for _, v := range data {
		result := response.AppLiveRoomResult{}
		result.RoomId = v.RoomId
		result.RoomPrettyId = v.RoomPrettyId
		result.RoomAttrId = v.RoomAttrId
		result.RoomSpeakType = v.RoomSpeakType
		result.RoomUnionId = v.RoomUnionId
		result.RoomLiveStatus = v.RoomLiveStatus
		result.RoomType = v.RoomType
		result.RoomUserId = v.RoomUserId
		result.RoomUserAge = utils.FuncGetAge(int(v.SystemUser.UserBirthday))
		result.RoomUserGender = v.SystemUser.UserGender
		result.RoomCover = v.RoomCover
		result.RoomTitle = v.RoomTitle
		result.RoomOpenIm = v.RoomOpenIm
		result.RoomUserName = v.SystemUser.UserNickname
		result.RoomUserIconurl = v.SystemUser.UserIconurl
		result.RoomStatus = v.RoomStatus
		result.Hot = int(v.RoomHeat)
		result.RoomName = v.RoomName
		result.RoomAttrName = v.RoomLiveAttr.AttrName
		// 处理热度为负数
		if result.Hot < 0 {
			result.Hot = 0
		}
		resp = append(resp, result)
	}
	response.ResponseOk(c, "ok", resp)
	return
}

// 进房间获取用户信息
func GetUserInfoByStudio(c *gin.Context) {
	var form request.GetOwnInfoReq
	err := c.ShouldBind(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	userId := utils.FuncUserId(c)
	userInfo, err := new(redismodels.MsgUserObj).GetMsgUserInfo(userId, map[string]bool{"icon": true, "comeIn": true, "chat": true})
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户信息失败", "", err.Error())
		return
	}
	_, err = new(dbmodels.AppLiveRoom).QueryRoomId(int(*form.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取房间信息失败", "", err.Error())
		return
	}

	resp := response.StudioUserInfoResp{
		UserId:      userId,
		Icon:        userInfo.Icon,
		IconStyle:   response.IconStyle{BgUrl: userInfo.IconStyle.BgUrl, IconId: userInfo.IconStyle.IconId, EndT: userInfo.IconStyle.EndT},
		ComeInStyle: response.ComeInStyle{EndT: userInfo.ComeInStyle.EndT, BgUrl: userInfo.ComeInStyle.BgUrl, PetUrl: userInfo.ComeInStyle.PetUrl},
		ChatStyle:   response.ChatStyle{BgUrl: userInfo.ChatStyle.BgUrl, ChatId: userInfo.ChatStyle.ChatId, EndT: userInfo.ChatStyle.EndT},
		NickName:    userInfo.NickName,
		Gender:      userInfo.Gender,
		VipLevel:    userInfo.VipLevel,
		IsSuper:     userInfo.IsSuper,
		JueLevel:    userInfo.JueLevel,
		FansLevel:   userInfo.FansLevel,
		UserOver:    userInfo.UserOver,
		UserUnionId: userInfo.UserUnionId,
	}
	role, err := new(dbmodels.AppRoomAdmin).GetUserRole(userId, *form.RoomId)
	if err != nil {
		utils.LogInfoF("获取用户角色失败")
	}
	resp.Role = role
	response.ResponseOk(c, "ok", resp)
	return
}

// 开直播获取之前房间缓存
func GetLastLiveInfo(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var form request.GetOwnInfoReq
	err := c.ShouldBind(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	roomInfo, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(*form.RoomId))
	if err != nil {
		if err != gorm.ErrRecordNotFound {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取房间信息失败", "", err.Error())
			return
		}
		resp := response.GetLastLiveInfo{}
		response.ResponseOk(c, "ok", resp)
		return
	}
	if roomInfo.RoomUserId != userId {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "无权访问", "", "")
		return
	}
	resp := response.GetLastLiveInfo{
		RoomId:         roomInfo.RoomId,
		RoomType:       roomInfo.RoomType,
		RoomLiveStatus: roomInfo.RoomLiveStatus,
		RoomName:       roomInfo.RoomName,
		RoomCover:      roomInfo.RoomCover,
		RoomBackground: roomInfo.RoomBackground,
		RoomContent:    roomInfo.RoomContent,
	}
	response.ResponseOk(c, "ok", resp)
	return
}

// 抱人上麦列表
func GetHugWheatList(c *gin.Context) {
	var req request.GetHugWheatListReq
	err := c.ShouldBind(&req)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	resp := make([]response.GetHugWheatListResp, 0)

	// TODO 判断是否为user的房间

	// 获取在线列表
	reply := utils.RedisClient.HVals(utils.REDIS_LIVE_ONLINE_MEMBER + strconv.Itoa(int(*req.RoomId))).Val()
	var info redismodels.MsgUserObj
	list, err := redismodels.SliceInterface(reply, err, info)
	if err != nil {
		return
	}
	sort.Sort(list)

	// 在线列表
	onlineListMap := make(map[int64]redismodels.MsgUserObj)
	for _, v := range list {
		onlineListMap[v.UserId] = v
	}

	respNum := redismodels.DEFAULT_ONLINE_NUMBER

	// 已经排麦
	queue := redismodels.WheatQueue{}
	queueList, err := queue.QueryList(int(*req.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, err.Error(), "", "")
		return
	}
	for _, v := range queueList {
		if onlineList, ok := onlineListMap[int64(v.UserId)]; ok {
			hugWheat := response.GetHugWheatListResp{
				Role:         onlineList.Role,
				UserId:       int(onlineList.UserId),
				UserNickName: onlineList.NickName,
				UserIconUrl:  onlineList.Icon,
				UserGender:   onlineList.Gender,
				Position:     0,
				IsSuper:      onlineList.IsSuper,
				VipLevel:     onlineList.VipLevel,
				JueLevel:     onlineList.JueLevel,
				FansLevel:    onlineList.FansLevel,
				Age:          onlineList.Age,
				HugWheatType: response.HugWheatTypeWheatQueue,
			}
			resp = append(resp, hugWheat)
			respNum--
			delete(onlineListMap, int64(v.UserId))
		}
	}

	// 在麦位上
	wheat := redismodels.Wheat{}
	wheatList, err := wheat.QueryWheatDetail(int(*req.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, err.Error(), "", "")
		return
	}
	for _, v := range wheatList.WheatObj {
		delete(onlineListMap, int64(v.UserId))
	}

	// 没有排麦
	for _, v := range list {
		if respNum <= 0 {
			break
		}
		if onlineList, ok := onlineListMap[v.UserId]; ok {
			hugWheat := response.GetHugWheatListResp{
				Role:         onlineList.Role,
				UserId:       int(onlineList.UserId),
				UserNickName: onlineList.NickName,
				UserIconUrl:  onlineList.Icon,
				UserGender:   onlineList.Gender,
				Position:     0,
				IsSuper:      onlineList.IsSuper,
				VipLevel:     onlineList.VipLevel,
				JueLevel:     onlineList.JueLevel,
				FansLevel:    onlineList.FansLevel,
				Age:          onlineList.Age,
				HugWheatType: response.HugWheatTypeOnline,
			}
			resp = append(resp, hugWheat)
			respNum--
			delete(onlineListMap, v.UserId)
		}
	}
	response.ResponseOk(c, "获取抱人上麦列表成功", resp)

}

// RoomPkSetting 房间pk设置
func RoomPkSetting(c *gin.Context) {
	userId := utils.FuncUserId(c)
	pkBaseReq := request.RoomPkBaseReq{}
	if err := c.ShouldBindBodyWith(&pkBaseReq, binding.JSON); err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "参数错误", "", err.Error())
		return
	}
	// 检查用户是否是主持人
	detail, err := new(redismodels.Wheat).QueryWheatDetail(int(pkBaseReq.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", "")
		return
	}
	if detail.WheatObj[0].UserId != int(userId) {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "无权操作", "", "")
		return
	}
	// 查询房间是否存在
	appLiveRoom, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(pkBaseReq.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间不存在", "", "")
		return
	}
	// 检验房间状态
	if appLiveRoom.RoomStatus != dbmodels.ROOM_STATUS_OK {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前直播间不允许开启pk", "", "")
		return
	}
	// 检查后台是否为房间开启pk功能
	if appLiveRoom.RoomPkSwitch == dbmodels.RoomPkFunctionClose {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "后台暂未开启此房间的pk功能", "", "")
		return
	}
	update := make(map[string]interface{})
	// 关闭pk
	if *pkBaseReq.RoomPkSwitch == dbmodels.RoomPkCloseStage {
		if appLiveRoom.RoomPkState == dbmodels.RoomPkCloseStage {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间pk已经关闭", "", "")
			return
		}
		if appLiveRoom.RoomPkState == dbmodels.RoomPkStartStage || appLiveRoom.RoomPkState == dbmodels.RoomPkPunishmentStage {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前状态不允许关闭", "", "")
			return
		}
		update["room_pk_state"] = pkBaseReq.RoomPkSwitch
	} else {
		// 开启pk
		if appLiveRoom.RoomPkState == dbmodels.RoomPkStartStage || appLiveRoom.RoomPkState == dbmodels.RoomPkPunishmentStage {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前状态不允许设置", "", "")
			return
		}
		roomOpenPkReq := request.RoomOpenPkReq{}
		if err = c.ShouldBindBodyWith(&roomOpenPkReq, binding.JSON); err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "参数错误", "", err.Error())
			return
		}
		if str := moderation.TextModeration(roomOpenPkReq.RoomPkRecordPunish); len(str) > 0 {
			response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "惩罚内容包含敏感词", "", "")
			return
		}
		// 获取时间参数配置
		param, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PARAM_KEY_LIVE_PK_SELECT)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取pk时间参数错误", "", err.Error())
			return
		}
		data := response.GetPkTimeResp{}
		err = json.Unmarshal([]byte(param["value"]), &data)
		if err != nil {
			utils.LogErrorF("反序列化pk时间参数出错，err:%s", err.Error())
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取pk时间参数错误", "", "")
			return
		}
		duration, validate := data.Validate(roomOpenPkReq.RoomPkRecordTime, response.PK_TIME_CHOOSE_PKTIME)
		if !validate {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "pk时间参数错误", "", "")
			return
		}

		update["room_pk_state"] = roomOpenPkReq.RoomPkSwitch
		update["room_speak_type"] = roomOpenPkReq.RoomSpeakType
		update["room_pk_record_time"] = duration
		update["room_pk_record_punish"] = roomOpenPkReq.RoomPkRecordPunish
	}
	if err = appLiveRoom.Update(int(pkBaseReq.RoomId), update); err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", "")
		return
	}
	// 开启/关闭爱意值
	_, err = new(redismodels.Wheat).SwitchWheatLove(int(appLiveRoom.RoomId), userId, redismodels.WHEAT_LOVE_SWITCH_OFF, false)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", "")
		return
	}

	info := services.GetLiveInfo(appLiveRoom, *pkBaseReq.RoomPkSwitch)
	info.RoomPKRemainingTime = appLiveRoom.RoomPkRecordTime
	var closeSwitch bool
	if *pkBaseReq.RoomPkSwitch == 0 {
		closeSwitch = true
	}
	if *pkBaseReq.RoomPkSwitch == 1 {
		closeSwitch = false
	}
	go new(services.LiveMsg).AnnouncePkSwitch(&detail, &info, closeSwitch)
	response.ResponseOk(c, "操作成功", "")
	return
}

// 开始pk
func RoomPkStart(c *gin.Context) {
	userId := utils.FuncUserId(c)
	pkStartReq := request.RoomPkStartReq{}
	if err := c.ShouldBind(&pkStartReq); err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "参数错误", "", "")
		return
	}

	// 检查用户是否是主持人
	detail, err := new(redismodels.Wheat).QueryWheatDetail(int(pkStartReq.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", "")
		return
	}
	if detail.WheatObj[0].UserId != int(userId) {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "无权操作", "", "")
		return
	}

	// 查询房间是否存在
	appLiveRoom, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(pkStartReq.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间不存在", "", "")
		return
	}
	// 检验房间状态
	if appLiveRoom.RoomStatus != dbmodels.ROOM_STATUS_OK {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前直播间不允许开启pk,请先开启房间", "", "")
		return
	}
	// 检查后台是否为房间开启pk功能
	if appLiveRoom.RoomPkSwitch == dbmodels.RoomPkFunctionClose {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "后台暂未开启此房间的pk功能", "", "")
		return
	}

	// 检查当前房间是否已经在pk
	if appLiveRoom.RoomPkState == dbmodels.RoomPkStartStage {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "不可重复开启pk", "", "")
		return
	}
	// 校验当前麦位是否满足
	wheat, err := new(redismodels.Wheat).QueryWheatDetail(int(pkStartReq.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取麦位信息失败", "", err.Error())
		return
	}
	var (
		red  = false
		blue = false
	)
	for _, v := range wheat.WheatObj {
		if v.UserId != 0 {
			if v.Position > 4 {
				blue = true
				continue
			} else if v.Position > 0 && v.Position < 5 {
				red = true
				continue
			}
		}
	}
	if !red || !blue {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "PK人员不足，暂时不能开启PK", "", "")
		return
	}
	err = services.RoomPkStart(userId, appLiveRoom)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "开启pk功能失败", "", "")
		return
	}

	response.ResponseOk(c, "操作成功", "")
}

// 主动结算pk
func RoomManualSettlePK(c *gin.Context) {
	userId := utils.FuncUserId(c)
	manualSettleReq := request.RoomManualSettlePkReq{}
	if err := c.ShouldBind(&manualSettleReq); err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "参数错误", "", "")
		return
	}

	// 检查用户是否是主持人
	detail, err := new(redismodels.Wheat).QueryWheatDetail(int(manualSettleReq.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", "")
		return
	}
	if detail.WheatObj[0].UserId != int(userId) {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "无权操作", "", "")
		return
	}

	// 查询房间是否存在
	appLiveRoom, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(manualSettleReq.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间不存在", "", "")
		return
	}
	// 检验房间状态
	if appLiveRoom.RoomStatus != dbmodels.ROOM_STATUS_OK {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前直播间不允许开启pk,请先开启房间", "", "")
		return
	}
	// 检查后台是否为房间开启pk功能
	if appLiveRoom.RoomPkSwitch == dbmodels.RoomPkFunctionClose {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "后台暂未开启此房间的pk功能", "", "")
		return
	}

	// 判断当前房间pk状态
	if appLiveRoom.RoomPkState != dbmodels.RoomPkStartStage {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间当前状态无法结束pk", "", "")
		return
	}
	err = services.RoomSettlePk(userId, appLiveRoom)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "主动结算pk错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "操作成功", "")
}

// 增加pk结算时间
func AddPkTime(c *gin.Context) {
	userId := utils.FuncUserId(c)
	addTimeReq := request.RoomAddPkTimeReq{}
	if err := c.ShouldBind(&addTimeReq); err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "参数错误", "", "")
		return
	}

	// 检查用户是否是主持人
	detail, err := new(redismodels.Wheat).QueryWheatDetail(int(addTimeReq.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", "")
		return
	}
	if detail.WheatObj[0].UserId != int(userId) {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "无权操作", "", "")
		return
	}

	// 查询房间是否存在
	appLiveRoom, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(addTimeReq.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间不存在", "", "")
		return
	}

	// 判断当前房间pk状态
	if appLiveRoom.RoomPkState != dbmodels.RoomPkStartStage {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间当前状态无法延长pk时间", "", "")
		return
	}

	// 获取时间参数配置
	param, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PARAM_KEY_LIVE_PK_SELECT)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取pk时间参数错误", "", err.Error())
		return
	}
	data := response.GetPkTimeResp{}
	err = json.Unmarshal([]byte(param["value"]), &data)
	if err != nil {
		utils.LogErrorF("反序列化pk时间参数出错，err:%s", err.Error())
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取pk时间参数错误", "", "")
		return
	}
	duration, validate := data.Validate(addTimeReq.RoomAddTimeKey, response.PK_TIME_CHOOSE_ADDTIME)
	if !validate {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "pk时间参数错误", "", "")
		return
	}
	err = services.AddPkTime(appLiveRoom, duration)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "pk模式延长时间失败", "", "")
		return
	}
	response.ResponseOk(c, "操作成功", "")
}

func GetTime(c *gin.Context) {
	// 充值提示
	param, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PARAM_KEY_LIVE_PK_SELECT)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取pk时间参数错误", "", err.Error())
		return
	}
	data := response.GetPkTimeResp{}
	err = json.Unmarshal([]byte(param["value"]), &data)
	if err != nil {
		utils.LogErrorF("反序列化pk时间参数出错，err:%s", err.Error())
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取pk时间参数错误", "", "")
		return
	}

	response.ResponseOk(c, "", data)
}

// pk结束惩罚阶段
func RoomPkEnd(c *gin.Context) {
	userId := utils.FuncUserId(c)
	req := request.RoomPkEndReq{}
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "参数错误", "", "")
		return
	}
	// 检查用户是否是主持人
	detail, err := new(redismodels.Wheat).QueryWheatDetail(int(req.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", "")
		return
	}
	if detail.WheatObj[0].UserId != int(userId) {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "无权操作", "", "")
		return
	}
	// 查询房间是否存在
	appLiveRoom, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(req.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间不存在", "", "")
		return
	}
	// 检验房间状态
	if appLiveRoom.RoomStatus != dbmodels.ROOM_STATUS_OK {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前直播间不允许开启pk,请先开启房间", "", "")
		return
	}
	// 检查后台是否为房间开启pk功能
	if appLiveRoom.RoomPkSwitch == dbmodels.RoomPkFunctionClose {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "后台暂未开启此房间的pk功能", "", "")
		return
	}
	// 检查当前是否为惩罚阶段
	if appLiveRoom.RoomPkState != dbmodels.RoomPkPunishmentStage {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前阶段不能结束惩罚", "", "")
		return
	}
	err = services.EndPunishStage(appLiveRoom)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", "")
		return
	}
	response.ResponseOk(c, "结束惩罚成功", "")
	return
}

// 获取pk快照
func RoomPkDetail(c *gin.Context) {
	var req request.RoomPkDetail
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", "")
		return
	}
	userId := utils.FuncUserId(c)
	data, err := services.GetPkInfo(req, userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, err.Error(), "", "")
		return
	}
	response.ResponseOk(c, "ok", data)
}

// 房间历史热度
func RoomHistoryHeat(c *gin.Context) {
	heat, err := redismodels.NewRoomHeat().RoomHistoryHeat()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "ok", heat)
	return
}
