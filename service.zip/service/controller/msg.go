package controller

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// 获取用户历史动态
func GetInteractive(c *gin.Context) {
	userId := utils.FuncUserId(c)
	//获取分页参数
	page, size, skip, err := utils.GetPageAndSize(c)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "分页参数错误", "", err.Error())
		return
	}
	one := dbmodels.AppTweetVisitorLog{}
	result, total, err := one.GetLogsByTweetUser(userId, size, skip)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "未获取订单记录", "", err.Error())
		return
	}
	data := response.BasePageList{
		Page:       page,
		Size:       size,
		Total:      total,
		TotalPages: utils.FuncTotalPages(total, size),
		List:       result,
	}
	response.ResponseOk(c, "ok", data)
	return
}

// 获取用户相关订单
func GetUserOrders(c *gin.Context) {
	userId := utils.FuncUserId(c)
	//获取分页参数
	page, size, skip, err := utils.GetPageAndSize(c)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "分页参数错误", "", err.Error())
		return
	}
	one := dbmodels.AppSkillOrder{}
	result, err, total := one.GetMsgOrdersByUserId(userId, size, skip)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "未获取订单记录", "", err.Error())
		return
	}
	data := response.BasePageList{
		Page:       page,
		Size:       size,
		Total:      total,
		TotalPages: utils.FuncTotalPages(total, size),
		List:       result,
	}
	response.ResponseOk(c, "ok", data)
	return
}

// 获取快捷回复
func GetQuickReply(c *gin.Context) {
	form := request.GetQuickByTypeReq{}
	err := c.ShouldBind(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	quick, err := new(dbmodels.AppQuickReply).GetQuickReplyByType(*form.Type)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取快捷键列表失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "ok", quick)
	return
}

// 获取大神订单或技能记录
func GetOrderOrSkills(c *gin.Context) {
	userId := utils.FuncUserId(c)
	form := request.GetOrdersAndSkillsReq{}
	err := c.ShouldBind(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	var res response.MsgSparringAndOrderInfoResp
	orders, err := new(dbmodels.AppSkillOrder).GetMsgOrdersByBuyerId(userId, form.UserId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询订单信息出错", "", err.Error())
		return
	}
	// 无订单时，查询大神技能信息
	if len(orders) == 0 {
		skills, err := new(dbmodels.AppSparringSkill).MsgQuerySkillByUserId(form.UserId)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询技能信息出错", "", err.Error())
			return
		}
		for _, i := range skills {
			skill := response.MsgSKillInfo{
				SparringId: i.SkillID,
				SkillName:  i.AppSkill.SkillName,
				SkillIcon:  i.AppSkill.SkillIconurl,
			}
			for _, p := range i.AppSparringSkillPrice {
				if p.AppSkillPrice.PriceRequired == dbmodels.PRICE_REQUIRED_TRUE {
					skill.PriceWay = p.AppSkillPrice.PriceWay
					skill.PricePrice = p.PricePrice
				}
			}
			res.Skills = append(res.Skills, skill)
		}
		res.Orders = make([]response.MsgOrderInfo, 0)
		if len(res.Skills) == 0 {
			res.Skills = make([]response.MsgSKillInfo, 0)
		}
	} else {
		res.Orders = orders
	}
	// 查询是否关注
	res.IsAttention, err = new(dbmodels.AppAttention).QueryFollowed(userId, form.UserId)
	response.ResponseOk(c, "ok", res)
	return
}

// 获取用户信息
func GetMsgUserInfo(c *gin.Context) {
	userId := utils.FuncUserId(c)
	form := request.GetOrdersAndSkillsReq{}
	err := c.ShouldBind(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	data, err := new(dbmodels.SystemUser).GetMsgUserInfo(form.UserId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户信息失败", "", err.Error())
		return
	}
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "用户不存在", "", "")
		return
	}
	data.VipLevel, err = new(redismodels.UserInfo).GetUserVipLevel(form.UserId)
	if err != nil {
		utils.LogErrorF("获取用户vip信息失败,err:%s", err.Error())
	}
	data.Age = utils.FuncGetAge(int(data.UserBirthday))
	_, err = new(dbmodels.AppBlacklist).Exists(userId, form.UserId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户黑名单信息错误", "", err.Error())
		return
	}
	if err == nil {
		data.IsBlack = response.BLACKLIST_USER_STATUS_TRUE
	}
	response.ResponseOk(c, "ok", data)
	return
}

// 获取待接单订单
func GetConfirmOrders(c *gin.Context) {
	userId := utils.FuncUserId(c)
	orders, err := new(dbmodels.AppSkillOrder).GetMsgOrdersBySellerId(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询订单信息出错", "", err.Error())
		return
	}
	response.ResponseOk(c, "ok", orders)
	return
}
