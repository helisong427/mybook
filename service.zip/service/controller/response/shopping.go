package response

//商城--装扮标签
type ShoppingDressAttr struct {
	PropTypeName string     `json:"prop_type_name"` //分类名称
	PropType     int        `json:"prop_type"`      //分类
	AttrList     []AttrList `json:"attr_list"`      //属性列表
}

//属性列表
type AttrList struct {
	AttrId   int64  `json:"attr_id"`   //属性id
	AttrName string `json:"attr_name"` //属性名称
}

//商城--装扮列表
type ShoppingDressUpList struct {
	PropId          int64  `json:"prop_id"`           //物品id
	PropName        string `json:"prop_name"`         //物品名称
	PropRemark      string `json:"prop_remark"`       //物品描述
	PropType        int    `json:"prop_type"`         //物品类型
	PropVipLevel    int    `json:"prop_vip_level"`    //需要解锁的vip等级
	PropPrice       int64  `json:"prop_price"`        //现价
	PropOrgPrice    int64  `json:"prop_org_price"`    //原价
	PropIcon        string `json:"prop_icon"`         //icon
	PropUrl         string `json:"prop_url"`          //特效地址
	PropExpiredTime int64  `json:"prop_expired_time"` //过期时间/天
	IsBuy           int    `json:"is_buy"`            //是否购买:0--否,1--是
	IsDressUp       int    `json:"is_dress_up"`       //是否装扮:0--否,1--是
	LastTime        int64  `json:"last_time"`         //剩余时间
	ProhibitedToBuy int    `json:"prohibited_to_buy"` //禁止购买:0--否,1--是
}
