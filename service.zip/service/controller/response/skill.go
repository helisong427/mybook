package response

type SkillListItem struct {
	SkillId      int64  `gorm:"column:skill_id" json:"skill_id"`
	SkillType    int    `gorm:"column:skill_type" json:"-"`                // 游戏类型(0游戏,1娱乐)
	SkillName    string `gorm:"column:skill_name" json:"skill_name"`       // 游戏名称
	SkillIconurl string `gorm:"column:skill_iconurl" json:"skill_iconurl"` // 游戏icon
	SkillStatus  int    `json:"skill_status"`                              // 认证状态
}

type SkillListResp struct {
	SkillType  int             `json:"skill_type"` // 游戏类型(0游戏,1娱乐)
	SkillItems []SkillListItem `json:"skill_items"`
}

type SkillInfoResp struct {
	SkillId                 int64    `json:"skill_id"`
	SkillType               int      `json:"skill_type"`                 // 游戏类型(0游戏,1娱乐)
	SkillName               string   `json:"skill_name"`                 // 游戏名称
	SkillIconurl            string   `json:"skill_iconurl"`              // 游戏icon
	SkillRequiredField      string   `json:"skill_required_field"`       // 必填字段id
	SkillRequiredFieldValue []string `json:"skill_required_field_value"` // 必填字段id
	SkillLevelTips          string   `json:"skill_level_tips"`           // 等级提示
	SkillLevelUrl           string   `json:"skill_level_url"`            // 等级示例图片
	SkillSoundTips          string   `json:"skill_sound_tips"`           // 技能申请提示
	SkillAvatarTips         string   `json:"skill_avatar_tips"`          // 头像提示
	SkillInfoTips           string   `json:"skill_info_tips"`            // 介绍提示
	SkillFields             string   `json:"skill_fields"`               // 游戏可选字段用,分割
}

// 大神下单前响应
type SparringBeforePlacingOrderResp struct {
	SparringId   int                       `json:"sparring_id"`
	UserNickName string                    `json:"user_nick_name"` // 昵称
	UserIconurl  string                    `json:"user_iconurl"`   // 头像
	UserAge      int                       `json:"user_age"`       // 年龄
	UserGender   int                       `json:"user_gender"`    // 性别
	UserBalance  int                       `json:"user_balance"`   // 用户余额
	SkillName    string                    `json:"skill_name"`     // 技能名称
	SkillStatus  int                       `json:"skill_status"`   // 技能状态
	SkillParams  []PlacingOrderSkillParams `json:"skill_params"`   // 下单技能参数
}

// 下单技能参数
type PlacingOrderSkillParams struct {
	PriceId    int    `json:"price_id"`    // 价格Id
	PriceWay   string `json:"price_way"`   // 陪玩方式
	PricePrice int    `json:"price_price"` // 技能价格
	PriceType  int    `json:"price_type"`  // 价格类型,0自定义,1系统默认
}

// 大神我的技能
type SparringMySkillRep struct {
	SparringId               int    `json:"sparring_id"`                 // 大神技能id
	SkillType                int    `json:"skill_type"`                  // 游戏类型(0游戏,1娱乐)
	SkillName                string `json:"skill_name"`                  // 游戏名称
	SkillIconurl             string `json:"skill_iconurl"`               // 游戏icon
	SkillStatus              int    `json:"skill_status"`                // 技能状态
	IsSetPrice               int    `json:"is_set_price"`                // 是否设置价格:0--否,1--是
	PriceWay                 string `json:"price_way"`                   // 陪玩方式
	PricePrice               int    `json:"price_price"`                 // 技能价格
	ReviewTips               string `json:"review_tips"`                 // 审核提示
	FreezeTips               string `json:"freeze_tips"`                 // 冻结提示
	SkillSetInfoStatus       int    `json:"skill_set_info_status"`       // 技能设置信息状态 0未设置,1为已设置
	SkillSpeedMatchingStatus int64  `json:"skill_speed_matching_status"` // 抢单开关(0关闭,1开启)
	SkillMsgStatus           int64  `json:"skill_msg_status"`            // 抢单消息(0关闭,1开启)
}
