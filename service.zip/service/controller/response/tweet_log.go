package response

// 获取操作记录
type AppTweetLogResp struct {
	LogId            int64            `gorm:"column:log_id;primaryKey;autoIncrement" json:"log_id"`
	LogMediaType     int              `gorm:"column:log_media_type" json:"log_media_type"`
	LogMediaUrl      string           `gorm:"column:log_media_url" json:"log_media_url"`
	LogOperateUserId int64            `gorm:"column:log_operate_user_id" json:"log_operate_user_id"`
	OperateUser      TweetLogUserInfo `json:"operate_user" gorm:"foreignKey:UserId;references:LogOperateUserId"`
	LogComment       string           `gorm:"column:log_comment" json:"log_comment"`
	LogTips          string           `gorm:"column:log_tips" json:"log_tips"`
	LogTweetContent  string           `gorm:"column:log_tweet_content" json:"log_tweet_content"`
	LogType          int              `gorm:"column:log_type" json:"log_type"`
	LogTweetUserId   int64            `gorm:"column:log_tweet_user_id" json:"log_tweet_user_id"`
	LogTweetId       int64            `gorm:"column:log_tweet_id" json:"log_tweet_id"`
	Created          int64            `json:"created" gorm:"edited"`
}

type TweetLogUserInfo struct {
	UserId   int64  `json:"user_id" gorm:"column:user_id"`
	Icon     string `json:"icon" gorm:"column:user_iconurl"`      // 用户头像
	Nickname string `json:"nickname" gorm:"column:user_nickname"` // 昵称
}

func (TweetLogUserInfo) TableName() string {
	return "system_user"
}
