package response

type AgoraTokenRep struct {
	Token string `json:"token"`
}

type GetRoomAttrId struct {
	SkillID     int64 `json:"skill_id"`
	SkillUserID int64 `json:"skill_user_id"` // 用户id
	SkillAttrId int64 `json:"skill_attr_id"`
	SkillStatus int   `json:"skill_status"` // 技能状态
}

type RoomAttr struct {
	AttrID         int64    `json:"attr_id"`
	AttrName       string   `json:"attr_name"` // AttrName 属性名称
	AttrDirections string   `json:"attr_directions"`
	AttrDemand     string   `json:"attr_demand"`
	AttrBackground []string `json:"attr_background"`
}

type GetRoomAttrRes struct {
	Type  int        `json:"type"`
	Attrs []RoomAttr `json:"attrs"`
}

type GetAttrName struct {
	SkillAttrId    int64  `json:"skill_attr_id"`   // 属性id
	AttrName       string `json:"attr_name"`       // 属性名字
	AttrBackground string `json:"attr_background"` // 房间系统默认背景图
}

type GetStudioInfo struct {
	RoomId              int64     `json:"room_id"`        // 房间id
	RoomPrettyId        int64     `json:"room_pretty_id"` // 靓号
	RoomStatus          int       `json:"room_status"`
	RoomType            int       `json:"room_type"`                                         // 类型(0音频直播,1音频派对)
	RoomName            string    `json:"room_name"`                                         // 房间名称
	RoomCover           string    `json:"room_cover"`                                        // 房间封面
	RoomBackground      string    `json:"room_background"`                                   // 房间背景
	RoomTitle           string    `json:"room_title"`                                        // 房间标题(排队公告标题)
	RoomContent         string    `json:"room_content"`                                      // 房间简介(派对公告内容)
	RoomUnionId         int64     `json:"room_union_id"`                                     // 所属公会id
	RoomUserId          int64     `json:"room_user_id"`                                      // 所属用户id
	RoomAttrId          int64     `json:"room_attr_id"`                                      // 房间属性(唱歌,脱口秀)
	AttrName            string    `json:"attr_name"`                                         // 属性名称
	RoomSpeakType       int       `json:"room_speak_type"`                                   // 麦位模式(0音频直播无麦位,1音频直播有麦位,2音频派对自由模式,3音频派对麦序模式)
	RoomOpenIm          int       `json:"room_open_im"`                                      // 是否开通公屏(图文聊天0关闭,1开通)
	RoomLiveStatus      int       `json:"room_live_status"`                                  // 直播状态,直播类型才有效(0下播,1上播)
	RoomLastOnline      int64     `json:"room_last_online"`                                  // 最后开播时间(直播)
	RoomIsPassword      int       `json:"room_is_password"`                                  // 密码房间:0--否,1--是
	RoomPassword        string    `json:"room_password"`                                     // 房间密码
	RoomEggbreakMsg     int       `gorm:"column:room_eggbreak_msg" json:"room_eggbreak_msg"` // 博彩类游戏,信息是否在公屏显示 0显示,1不显示
	RoomPkSwitch        int       `json:"room_pk_switch"`                                    // 房间开启pk功能(0未开启 1开启)
	RoomPkState         int64     `json:"room_pk_state"`                                     // 房间pk状态(0关闭 1准备 2开始 3惩罚)
	RoomPkRecordPunish  string    `json:"room_pk_record_punish"`                             // 房间pk惩罚
	RoomPKDetailRed     int64     `json:"room_pk_detail_red"`                                // 红队pk值
	RoomPKDetailBlue    int64     `json:"room_pk_detail_blue"`                               // 蓝队pk值
	RoomPKRemainingTime int64     `json:"room_pk_remaining_time"`                            // 结束倒计时
	RoomPKMvpId         int64     `json:"room_pk_mvp_id"`                                    // mvp
	RoomPKSvpId         int64     `json:"room_pk_svp_id"`                                    // svp
	RoomPKCharmKingId   int64     `json:"room_pk_charm_king_id"`                             // 魅力王
	RoomGloryStar       GloryStar `json:"room_glory_star"`                                   // 房间闪耀之星
}

// 闪耀之星
type GloryStar struct {
	UserId       int64  `json:"user_id"`
	UserPrettyId int64  `json:"user_pretty_id"`
	Icon         string `json:"icon"`                                  // icon
	Gender       int    `json:"gender" gorm:"column:user_gender"`      // 用户性别0未知,1男,2女
	NickName     string `json:"nick_name" gorm:"column:user_nickname"` // 昵称
}

type AnchorInfo struct {
	UserID       int64  `json:"user_id"`       // 用户id
	UserNickname string `json:"user_nickname"` // 昵称
	UserIconurl  string `json:"user_iconurl"`  // 头像
	// TotalCharm   int    `json:"total_charm"`
	IsAttention int `json:"is_attention"`
}

type GiftSort struct {
	CountPrice   int64  `json:"count_price"`   // 当日礼物贡献值
	UserID       int64  `json:"user_id"`       // 用户id
	UserNickname string `json:"user_nickname"` // 昵称
	UserIconurl  string `json:"user_iconurl"`  // 头像
	UserGender   int    `json:"user_gender"`   // 用户性别0未知,1男,2女
	UserBirthday int64  `json:"user_birthday"` // 出生年月日
}

type StudioCardRep struct {
	RoomId       int64             `json:"room_id"`                                   // 房间id
	RoomPrettyId int64             `json:"room_pretty_id"`                            // 靓号
	RoomType     int               `json:"room_type"`                                 // 类型(0音频直播,1音频派对)
	RoomName     string            `json:"room_name"`                                 // 房间名称
	RoomCover    string            `json:"room_cover"`                                // 房间封面
	RoomTitle    string            `json:"room_title"`                                // 房间标题(排队公告标题)
	RoomContent  string            `json:"room_content"`                              // 房间简介(派对公告内容)
	AdminUserID  int64             `json:"admin_user_id"`                             // 房主用户id
	AdminRole    int               `json:"admin_role"`                                // 房间角色(0主播,1房间管理员,2房间副管理员,3房东)
	UserIconurl  string            `gorm:"column:user_iconurl" json:"user_iconurl"`   // 房主头像
	UserSlogan   string            `gorm:"column:user_slogan" json:"user_slogan"`     // 房主签名
	UserNickname string            `gorm:"column:user_nickname" json:"user_nickname"` // 房主昵称
	IsFavorite   int               `json:"is_favorite"`                               // 是否收藏房间(0没有，1收藏)
	GiftCount    []GiftCountResult `json:"gift_count"`
}

// 直播间礼物统计
type GiftCountResult struct {
	PropId    int64  `json:"prop_id" gorm:"column:prop_prop_id"`
	PropName  string `json:"prop_name" gorm:"column:prop_name"`   // 礼物名称
	PropIcon  string `json:"prop_icon" gorm:"column:prop_icon"`   // 礼物图标
	PropCount int64  `json:"prop_count" gorm:"column:prop_count"` // 礼物数量
}

type GiftUserItem struct {
	UserId   int64  `json:"user_id" gorm:"column:user_id"`
	Icon     string `json:"icon" gorm:"column:user_iconurl"`
	Nickname string `json:"user_nickname" gorm:"column:user_nickname"`
}

// 直播间全部礼物
type LiveRoomGiftResult struct {
	SenderInfo   GiftUserItem `json:"sender_info" gorm:"foreignKey:UserId;references:PropUserId"`
	AnchorInfo   GiftUserItem `json:"anchor_info" gorm:"foreignKey:UserId;references:PropAnchorId"`
	PropUserId   int64        `gorm:"column:prop_user_id" json:"-"`
	PropAnchorId int64        `gorm:"column:prop_anchor_id" json:"-"`
	RecordId     int64        `json:"record_id" gorm:"column:prop_id"`
	PropId       int64        `json:"prop_id" gorm:"column:prop_prop_id"`
	PropName     string       `json:"prop_name" gorm:"column:prop_name"`        // 礼物名称
	PropIcon     string       `json:"prop_icon" gorm:"column:prop_icon"`        // 礼物图标
	PropCount    int64        `json:"prop_count" gorm:"column:prop_prop_count"` // 礼物数量
	PropGiveTime int64        `json:"prop_give_time"`
}

type MonthGiftResult struct {
}

// 背包礼物明细
type GiftInfoRecordRes struct {
	RecordId      int64  `json:"record_id" gorm:"column:prop_id"`
	Nickname      string `json:"nickname" gorm:"column:user_nickname"`
	PropRoomId    int64  `gorm:"column:prop_room_id" json:"room_id"`
	PropGiveTime  int64  `gorm:"column:prop_give_time" json:"prop_give_time"`
	PropPropCount int64  `gorm:"column:prop_prop_count" json:"prop_count"`
	PropName      string `json:"prop_name" gorm:"column:prop_name"`
}

// 主播中心返回
type AnchorCentreResult struct {
	AnchorTime  int64         `json:"anchor_time"`  // 直播时长
	Income      int64         `json:"income"`       // 累计收入
	AnchorSkill []AnchorSkill `json:"anchor_skill"` // 审核通过的技能列表

}

// 每个技能播出时长和收入app_anchor_gift主播礼物表
type AnchorSkill struct {
	AnchorSkillTime int64 `json:"anchor_skill_time"` // 技能播出时长
}

type GetUserGiftWealth struct {
	UserId         int64  `json:"user_id"`
	NickName       string `gorm:"column:user_nickname" json:"nick_name"`           // 昵称
	Icon           string `gorm:"column:user_iconurl" json:"icon"`                 // 头像
	GiftGiftWealth int64  `json:"gift_gift_wealth" gorm:"column:user_prop_wealth"` // 礼物财富值
}

const DEFAULT_LEADERBOARD_LENGTH = 5 // 限制排行榜长度

type GiftIncomeResult struct {
	TimeCount   int64 `json:"time_count"`   // 直播总时长
	IncomeCount int64 `json:"income_count"` // 直播总收益

}
type LiveIncome struct {
	AttrID     int64  `json:"attr_id"`     // 属性id
	AttrName   string `json:"attr_name"`   // AttrName 属性名称
	LiveTime   int64  `json:"live_time"`   // 属性房间时长
	LiveIncome int64  `json:"live_income"` // 属性房间收益
}

// 直播结算
type LiveSettlementRes struct {
	LiveTime   int64 `json:"live_time"`
	LiveIncome int64 `json:"live_income"`
	NewFans    int64 `json:"new_fans"`
}

type AppLiveRoomResult struct {
	RoomId          int64       `json:"room_id"`           // 房间id
	RoomPrettyId    int64       `json:"room_pretty_id"`    // 靓号
	RoomType        int         `json:"room_type"`         // 类型(0音频直播,1音频派对)
	RoomName        string      `json:"room_name"`         // 房间名称
	RoomCover       string      `json:"room_cover"`        // 房间封面
	RoomTitle       string      `json:"room_title"`        // 房间标题(排队公告标题)
	RoomUnionId     int64       `json:"room_union_id"`     // 所属公会id
	RoomUserId      int64       `json:"room_user_id"`      // 所属用户id
	RoomUserName    string      `json:"room_user_name"`    // 用户昵称
	RoomUserIconurl string      `json:"room_user_iconurl"` // 用户头像
	RoomUserAge     int         `json:"room_user_age"`     // 用户年龄
	RoomUserGender  int         `json:"room_user_gender"`  // 用户性别
	RoomIsPassword  int         `json:"room_is_password"`  // 是否密码房:0--否，1--是
	RoomAttrId      int64       `json:"room_attr_id"`      // 房间属性(唱歌,脱口秀)
	RoomAttrName    string      `json:"room_attr_name"`    // 房间属性名称(唱歌,脱口秀)
	RoomSpeakType   int         `json:"room_speak_type"`   // 麦位模式(0音频直播无麦位,1音频直播有麦位,2音频派对自由模式,3音频派对麦序模式)
	RoomOpenIm      int         `json:"room_open_im"`      // 是否开通公屏(图文聊天0关闭,1开通)
	RoomLiveStatus  int         `json:"room_live_status"`  // 直播状态,直播类型才有效(0下播,1上播)
	RoomStatus      int         `json:"room_status"`       // 房间状态(0正常,1管理员(房主)关闭,2超时关闭派对房间,主麦位无人时关闭,3平台整改,4平台封禁)
	UnionName       string      `json:"union_name"`        // 公会名称
	UnionCode       uint64      `json:"union_code"`        // 公会code
	Hot             int         `json:"hot"`               // 热度
	RoomPkState     int64       `json:"room_pk_state"`     // 房间pk状态(0关闭 1准备 2开始 3惩罚)
	RoomPreside     RoomPreside `json:"room_preside"`      // 房间主持信息
}

// 房间主持信息
type RoomPreside struct {
	PresideName    string `json:"preside_name"`    // 主持名称
	PresideIconurl string `json:"preside_iconurl"` // 主持头像
}

// 房间管理员信息
type RoomAdminRep struct {
	AdminUserId int64 `json:"admin_user_id"`
	AdminRole   int   `json:"admin_role"`
}

// 获取房间列表
type GetStudioListRep struct {
	Size            int                 `json:"size"`          // 分页总数
	Page            int                 `json:"page"`          // 当前页数
	Total           int64               `json:"total"`         // 总条数
	TotalPages      int                 `json:"total_pages"`   // 总页数
	WalletTotalOver int64               `json:"user_buy_over"` // 用户账户余额
	List            []AppLiveRoomResult `json:"list"`          // 返回数据
}

// 获取公会房间
type GetUnionListRep struct {
	Count int                 `json:"count"`
	List  []AppLiveRoomResult `json:"list"`
}

// 入场特效
type ComeInStyle struct {
	ComeInId int64  `json:"come_in_id"` // 装扮id
	BgUrl    string `json:"bg_url"`     // 背景url
	PetUrl   string `json:"pet_url"`    // 坐骑
	EndT     int64  `json:"end_t"`      // 过期时间
}

// 聊天气泡
type ChatStyle struct {
	ChatId int64  `json:"chat_id"` // 装扮id
	BgUrl  string `json:"bg_url"`  // url
	EndT   int64  `json:"end_t"`   // 过期时间
}

// 用户信息
type StudioUserInfoResp struct {
	UserId      int64       `json:"user_id"`
	Icon        string      `json:"icon"` // icon
	IconStyle   IconStyle   `json:"icon_style"`
	ComeInStyle ComeInStyle `json:"come_in_style"`
	ChatStyle   ChatStyle   `json:"chat_style"`
	NickName    string      `json:"nick_name" gorm:"column:user_nickname"` // 昵称
	Gender      int         `json:"gender" gorm:"column:user_gender"`      // 用户性别0未知,1男,2女
	Role        int         `json:"role" gorm:"-"`                         // 角色
	IsSuper     int         `json:"is_super"`                              // 超级管理员0不是，1是
	VipLevel    int         `json:"vip_level" gorm:"-"`                    // vip等级
	JueLevel    int         `json:"jue_level" gorm:"-"`                    // 贵族等级
	FansLevel   int         `json:"fans_level" gorm:"-"`                   // 粉丝等级
	UserOver    int64       `json:"user_over"`
	UserUnionId int64       `json:"user_union_id"` // 公会id
	UserSlogan  string      `json:"-"`
	Age         int         `json:"age"`
}

// 直播获取之前房间缓存
type GetLastLiveInfo struct {
	RoomId         int64  `json:"room_id" gorm:"column:room_id;primaryKey;autoIncrement"` // 房间id
	RoomType       int    `json:"room_type"`                                              // 类型(0音频直播,1音频派对)
	RoomLiveStatus int    `json:"room_live_status"`                                       // 直播状态,直播类型才有效(0下播,1上播,2超时下播)
	RoomName       string `json:"room_name"`                                              // 房间名称
	RoomCover      string `json:"room_cover"`                                             // 房间封面
	RoomBackground string `json:"room_background"`                                        // 房间背景
	RoomContent    string `json:"room_content"`                                           // 房间简介(派对公告内容)
}

// 抱人上麦类型
const (
	HugWheatTypeOnline     = 0 // 没有排麦
	HugWheatTypeWheatQueue = 1 // 排麦
	HugWheatTypeWheat      = 2 // 麦位上
)

// 获取抱人上麦列表
type GetHugWheatListResp struct {
	Role         int    `json:"role"`           // 1房间副管理员,2房间管理员,3房主
	UserId       int    `json:"user_id"`        // 用户id
	UserNickName string `json:"user_nick_name"` // 用户昵称
	UserIconUrl  string `json:"user_icon_url"`  // 用户头像
	UserGender   int    `json:"user_gender"`    // 用户性别
	Position     int    `json:"position"`       // 麦序值
	IsSuper      int    `json:"is_super"`       // 超级管理员0不是，1是
	VipLevel     int    `json:"vip_level"`      // vip等级
	JueLevel     int    `json:"jue_level"`      // 贵族等级
	FansLevel    int    `json:"fans_level"`     // 粉丝等级
	Age          int    `json:"age"`            // 年龄
	HugWheatType int    `json:"hug_wheat_type"` // 抱人上麦类型
}

// 房间历史热度
type RoomHistoryHeatResp struct {
	HistoryHeat        []RoomHeat `json:"history_heat"`         // 历史热度
	HistoryHeatAverage []RoomHeat `json:"history_heat_average"` // 历史平均热度
	Heat               []RoomHeat `json:"heat"`                 // 当前热度
	LiveHeat           []RoomHeat `json:"live_heat"`            // 直播房热度
	PartyLive          []RoomHeat `json:"party_live"`           // 派对房热度
}

type RoomHeat struct {
	RoomId   int64 `json:"room_id"`   // 房间id
	RoomHeat int64 `json:"room_heat"` // 房间热度
}
