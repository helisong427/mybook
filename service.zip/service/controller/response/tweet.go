package response

//获取朋友圈tag返回
type GetTweetTagRep struct {
	TagTitle string `json:"tag_title"` //标题
	TagId    int    `json:"tag_id"`    //id
	Size     int    `json:"size"`      //每页条数
}

//朋友圈详情返回
type TweetDetailRep struct {
	TweetId            int64              `json:"tweet_id"`
	TweetContent       string             `json:"tweet_content"`
	TweetAttachment    []TweetAttachments `json:"tweet_attachment"`
	TweetSound         string             `json:"tweet_sound"`      //声音
	TweetSoundTime     int64              `json:"tweet_sound_time"` //声音时长
	TweetSendRegionId  int64              `json:"tweet_send_region_id"`
	TweetSendLongitude float32            `json:"tweet_send_longitude"`
	TweetSendLatitude  float32            `json:"tweet_send_latitude"`
	TweetSendTime      int64              `json:"tweet_send_time"`
	TweetSendPosition  string             `json:"tweet_send_position"`
	TweetSendTerminal  string             `json:"tweet_send_terminal"`
	TweetLikeCount     int64              `json:"tweet_like_count"`
	TweetCommentCount  int64              `json:"tweet_comment_count"`
	TweetShareCount    int64              `json:"tweet_share_count"`
	TweetReadCount     int64              `json:"tweet_read_count"`
	IsLike             int                `json:"is_like"`      //是否点赞
	IsAttention        int                `json:"is_attention"` //是否关注
	UserInfo           TweetUserInfo      `json:"user_info"`
	Topic              []TweetTopic       `json:"topic"`
}

//朋友圈列表
type TweetListRep struct {
	TweetId            int64              `json:"tweet_id"`
	TweetContent       string             `json:"tweet_content"`
	TweetAttachment    []TweetAttachments `json:"tweet_attachment"`
	TweetSound         string             `json:"tweet_sound"`      //声音
	TweetSoundTime     int64              `json:"tweet_sound_time"` //声音时长
	TweetSendLongitude float32            `json:"tweet_send_longitude"`
	TweetSendLatitude  float32            `json:"tweet_send_latitude"`
	TweetSendTime      int64              `json:"tweet_send_time"`
	TweetSendPosition  string             `json:"tweet_send_position"`
	TweetSendRegionId  int64              `json:"tweet_send_region_id"`
	TweetSendTerminal  string             `json:"tweet_send_terminal"`
	TweetLikeCount     int64              `json:"tweet_like_count"`
	TweetCommentCount  int64              `json:"tweet_comment_count"`
	TweetShareCount    int64              `json:"tweet_share_count"`
	TweetReadCount     int64              `json:"tweet_read_count"`
	IsLike             int                `json:"is_like"`      //是否点赞
	IsAttention        int                `json:"is_attention"` //是否关注
	UserInfo           TweetUserInfo      `json:"user_info"`
	Topic              []TweetTopic       `json:"topic"`
}

//朋友圈附件内容
type TweetAttachments struct {
	Type   string `json:"type"`   //附件类型
	Url    string `json:"url"`    //附件地址
	Width  string `json:"width"`  //附件宽度
	High   string `json:"high"`   //附件高度
	Length int    `json:"length"` //时长(视频/音频)
}

//朋友圈用户
type TweetUserInfo struct {
	UserId       int64  `json:"user_id"`
	UserNickname string `json:"user_nickname"`
	UserIconurl  string `json:"user_iconurl"`
	UserAge      int    `json:"user_age"`
	UserGender   int    `json:"user_gender"`
}

//朋友圈话题
type TweetTopic struct {
	TopicID    int64  `json:"topic_id"`
	TopicTitle string `json:"topic_title"`
}

//评论列表
type TweetCommentRep struct {
	CommentID         int64             `json:"comment_id"`
	CommentUserID     int64             `json:"comment_user_id"`
	CommentToUserID   int64             `json:"comment_to_user_id"`
	CommentParentID   int64             `json:"comment_parent_id"`
	CommentToParentID int64             `json:"comment_to_parent_id"`
	CommentContent    string            `json:"comment_content"`
	CommentLikeCount  int64             `json:"comment_like_count"`
	IsLike            int64             `json:"is_like"`
	Created           int64             `json:"created"`
	UserNickname      string            `json:"user_nickname"`
	ToUserNickname    string            `json:"to_user_nickname"`
	UserIconurl       string            `json:"user_iconurl"`
	ToUserIconurl     string            `json:"to_user_iconurl"`
	CommentNumber     int64             `json:"comment_number"`
	Child             []TweetCommentRep `json:"child"`
}

//评论详情列表返回
type TweetCommentDetailListRep struct {
	CommentID         int64  `json:"comment_id"`
	CommentUserID     int64  `json:"comment_user_id"`
	CommentToUserID   int64  `json:"comment_to_user_id"`
	CommentParentID   int64  `json:"comment_parent_id"`
	CommentToParentID int64  `json:"comment_to_parent_id"`
	CommentContent    string `json:"comment_content"`
	CommentLikeCount  int64  `json:"comment_like_count"`
	IsLike            int64  `json:"is_like"`
	Created           int64  `json:"created"`
	UserNickname      string `json:"user_nickname"`
	ToUserNickname    string `json:"to_user_nickname"`
	UserIconurl       string `json:"user_iconurl"`
	ToUserIconurl     string `json:"to_user_iconurl"`
}

//点赞返回
type LikeRep struct {
	IsLike int `json:"is_like"`
}
