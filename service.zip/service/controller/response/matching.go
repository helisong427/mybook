package response

// 极速匹配 -- 匹配参数
type SMParams struct {
	SkillId           int64               `json:"skill_id"`           // 技能id
	SkillName         string              `json:"skill_name"`         // 技能名称
	SkillPrice        int64               `json:"skill_price"`        // 价格
	SkillWay          string              `json:"skill_way"`          // 计价单位
	OtherRequirements []OtherRequirements `json:"other_requirements"` // 其他要求
}

type SMParamsResp struct {
	Params      []SMParams `json:"params"`       // 参数
	UserBalance int64      `json:"user_balance"` // 用户余额
}

// 其他要求
type OtherRequirements struct {
	OtherName   string   `json:"other_name"`   // 其他名称
	OtherValues []string `json:"other_values"` // 其他内容
}

// 极速匹配 -- 状态查询
type SMQueryStatusResp struct {
	MatchingId     int64                      `json:"matching_id"`      // 匹配id
	SparringUserId int64                      `json:"sparring_user_id"` // 大神用户id
	Status         int                        `json:"status"`           // 状态:0--未匹配,1--匹配中,2--已匹配
	SparringInfo   *SMQueryStatusSparringInfo `json:"sparring_info"`    // 大神详情
}

// SMQueryStatusSparringInfo 大神详细信息
type SMQueryStatusSparringInfo struct {
	UserId        int64     `json:"user_id"`        // 用户id
	Avatar        string    `json:"avatar"`         // 大神头像
	NickName      string    `json:"nick_name"`      // 昵称
	Level         string    `json:"level"`          // 大神等级
	Feature       []Feature `json:"feature"`        // 特色
	SkillIcon     string    `json:"skill_icon"`     // 技能icon
	SoundUrl      string    `json:"sound_url"`      // 语音url
	SoundTime     int64     `json:"sound_time"`     // 语音时长
	ServiceNumber int64     `json:"service_number"` // 服务人次
	FavorableRate int64     `json:"favorable_rate"` // 好评率
	Introduction  string    `json:"introduction"`   // 简介
	SkillName     string    `json:"skill_name"`     // 技能名称
	Gender        int       `json:"gender"`         // 性别
	Age           int       `json:"age"`            // 年龄
}

// Feature 特色
type Feature struct {
	FeatureName   string   `json:"feature_name"`   // 特色名称
	FeatureValues []string `json:"feature_values"` // 特色内容
}

// 极速匹配 -- 抢单中心
type OrderGrabbingCenterResp struct {
	UserId                    int64                       `json:"user_id"`                     // 用户id
	SparringUserId            int64                       `json:"sparring_user_id"`            // 大神用户id
	Nickname                  string                      `json:"nickname"`                    // 用户昵称
	MatchingId                int64                       `json:"matching_id"`                 // 匹配id
	SkillName                 string                      `json:"skill_name"`                  // 技能名称
	SkillIcon                 string                      `json:"skill_icon"`                  // 技能icon
	MatchingPrice             int64                       `json:"matching_price"`              // 价格
	MatchingWay               string                      `json:"matching_way"`                // 单位(天/局)
	MatchingCount             int64                       `json:"matching_count"`              // 单数
	MatchingOtherRequirements []MatchingOtherRequirements `json:"matching_other_requirements"` // 其他要求
	MatchingRemark            string                      `json:"matching_remark"`             // 备注
	UserGender                int                         `json:"user_gender"`                 // 用户性别：1--男，2--女
	MatchingStatus            int                         `json:"matching_status"`             // 抢单状态(0待抢单,1已过期,2已取消,3已抢单)
}

type MatchingOtherRequirements struct {
	OtherKey   string `json:"other_key"`
	OtherValue string `json:"other_value"`
}

// 极速匹配--下单
type SMPlaceOrderResp struct {
	Balance    int64 `json:"balance"`     // 余额
	MatchingId int64 `json:"matching_id"` // 极速匹配id
}

// 极速匹配--大神抢单
type GrabbingOrdersResp struct {
	Ok     int `json:"ok"`     // 是否抢到:0--否,1--是
	Status int `json:"status"` // 当前订单状态
}
