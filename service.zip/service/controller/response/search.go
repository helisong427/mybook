package response

//搜索推荐
type SearchRecommendResp struct {
	SparringList []SearchRecommendSparring `json:"sparring_list"` //大神列表
	RoomList     []SearchRecommendRoom     `json:"room_list"`     //房间列表
}

//搜索推荐大神列表
type SearchRecommendSparring struct {
	SparringId   int64  `json:"sparring_id"`
	SkillName    string `json:"skill_name"`    //技能名称
	SkillType    int    `json:"skill_type"`    //游戏类型(0游戏,1娱乐)
	UserId       int64  `json:"user_id"`       //用户id
	UserNickname string `json:"user_nickname"` //昵称
	UserIconurl  string `json:"user_iconurl"`  //头像
	PriceWay     string `json:"price_way"`     //陪玩方式
	PricePrice   int    `json:"price_price"`   //技能价格
}

//搜索推荐房间列表
type SearchRecommendRoom struct {
	RoomId         int64  `json:"room_id"`          //房间id
	RoomPrettyId   int64  `json:"room_pretty_id"`   // 靓号id
	RoomType       int    `json:"room_type"`        //类型(0音频直播,1音频派对)
	RoomName       string `json:"room_name"`        //房间名称
	RoomCover      string `json:"room_cover"`       //房间封面
	RoomAttrId     int64  `json:"room_attr_id"`     //房间属性(唱歌,脱口秀)
	RoomAttrName   string `json:"room_attr_name"`   //房间属性名称(唱歌,脱口秀)
	RoomSpeakType  int    `json:"room_speak_type"`  //麦位模式(0音频直播无麦位,1音频直播有麦位,2音频派对自由模式,3音频派对麦序模式)
	RoomLiveStatus int    `json:"room_live_status"` //直播状态,直播类型才有效(0下播,1上播)
	RoomIsPassword int    `json:"room_is_password"` //是否密码房:0--否，1--是
	RoomStatus     int    `json:"room_status"`      //房间状态
	Hot            int64  `json:"hot"`              //TODO 热度
	//AdminList      []RoomAdminRep `json:"admin_list"`       //管理员列表
}

//搜索结果列表
type SearchResultsListResp struct {
	UserList BasePageList `json:"user_list"`
	RoomList BasePageList `json:"room_list"`
}

//搜索结果列表·用户·
type SearchResultsListUser struct {
	UserId       int64  `json:"user_id"`        //用户id
	UserPrettyId int64  `json:"user_pretty_id"` // 用户靓号
	UserNickname string `json:"user_nickname"`  //用户昵称
	UserIconurl  string `json:"user_iconurl"`   //用户头像
}
