package response

//充值参数
type RechargeParametersRep struct {
	UserBalance  int64         `json:"user_balance"`  //用户余额
	RechargeTips []string      `json:"recharge_tips"` //充值提示
	TopUpGrade   []interface{} `json:"top_up_grade"`  //充值档次
	Recharge     string        `json:"recharge_key"`  //充值校验key
}

//web端充值参数
type WebRechargeParameters struct {
	TopUpGrade []TopUpGrade `json:"top_up_grade"` //充值档次
}

type TopUpGrade struct {
	Id    string `json:"id"`
	Cash  int64  `json:"cash"`  //现金
	Token int64  `json:"token"` //代币
}

//下单
type PlaceOrderRep struct {
	OrderParameters interface{} `json:"order_parameters,omitempty"` //下单参数
	OutTradeNo      int64       `json:"out_trade_no"`               //商户单号
}

//支付结果查询
type PayResultQueryRep struct {
	Status int `json:"status"` //订单状态:0--订单不存在,1--交易中,2--交易完成,3--交易失败
}
