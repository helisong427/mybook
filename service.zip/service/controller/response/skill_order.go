package response

import (
	"gorm.io/gorm"
	"time"
)

//下单返回
type SkillOrderPlaceRes struct {
	OrderId int64 `json:"order_id"`
}

//订单结果查询返回
type SkillOrderPayRes struct {
	IsPaySuccess int `json:"is_pay_success"`
}

//订单详情
type SkillOrderDetailRep struct {
	OrderId              int64       `json:"order_id"`
	OrderBuyUserId       int64       `json:"order_buy_user_id"`       // 卖家id
	OrderSellUserId      int64       `json:"order_sell_user_id"`      // 卖家id
	OrderSkillId         int64       `json:"order_skill_id"`          // 技能id
	OrderSparringSkillId int64       `json:"order_sparring_skill_id"` // 大神基恩那个id
	OrderPrice           int64       `json:"order_price"`             // 单价
	OrderWay             string      `json:"order_way"`               // 方式
	OrderTime            int64       `json:"order_time"`              // 陪玩方式   时长  单位分钟
	OrderProtectionTime  int64       `json:"order_protection_time"`   // 保护时间
	OrderCount           int64       `json:"order_count"`             // 数量
	OrderAmount          int64       `json:"order_amount"`            // 订单总金额代币
	OrderUnionFee        int64       `json:"order_union_fee"`         // 公会手续费
	OrderFee             int64       `json:"order_fee"`               // 平台手续费代币
	OrderIncome          int64       `json:"order_income"`            // 卖家收益代币
	OrderStatus          int         `json:"order_status"`            // 订单状态(1付款,2接单,3取消,4退款,5申诉,6完成,7评价,8结算)
	OrderPayStatus       int         `json:"order_pay_status"`        // 支付状态(0待付款,1付款中,2已付款)
	OrderPayTime         int64       `json:"order_pay_time"`          // 订单支付时间
	OrderConfirmStatus   int         `json:"order_confirm_status"`    // 接单状态(0待接单,1大神拒绝,2大神结单,3大神完成)
	OrderConfirmTime     int64       `json:"order_confirm_time"`      // 接单时间
	OrderCancelStatus    int         `json:"order_cancel_status"`     // 取消状态(0未取消,1玩家取消,2大神取消,3系统取消)
	OrderCancelTime      int64       `json:"order_cancel_time"`       // 订单取消时间
	OrderCancelClient    int         `json:"order_cancel_client"`     //  取消终端(0系统取消,1Android,2ios,3web)
	OrderRefundStatus    int         `json:"order_refund_status"`     // 退款状态(0未退款,1申请退款,2取消退款,3大神同意退款,4大神拒绝退款,5系统自动退款)
	OrderRefundTime      int64       `json:"order_refund_time"`       // 退款时间
	OrderRefundId        int64       `json:"order_refund_id"`         // 当前退款id
	OrderRefundCount     int         `json:"order_refund_count"`      // 退款申请次数
	OrderAppealStatus    int         `json:"order_appeal_status"`     // 申诉状态(0未申诉,1申诉中待大神举证,2待客服处理,3处理完成大神胜诉,4处理完成玩家胜诉)
	OrderAppealTime      int64       `json:"order_appeal_time"`       // 申诉时间
	OrderFinishStatus    int         `json:"order_finish_status"`     // 完成状态(0未完成,1系统自动完成,3玩家完成)
	OrderFinishTime      int64       `json:"order_finish_time"`       // 订单完成时间
	OrderCommentStatus   int         `json:"order_comment_status"`    // 评价状态(0待评价,1玩家已评价,2大神已评价)
	OrderRemark          string      `json:"order_remark"`            // 下单备注
	OrderClient          int         `json:"order_client"`            // 下单终端(1Android,2ios,3web)
	OrderSettleStatus    int         `json:"order_settle_status"`     // 订单结算(提取)状态(0未结算,1系统自动已结算,2客服结算)
	OrderSettleTime      int64       `json:"order_settle_time"`       // 订单结算(提取)时间
	OrderDeleteStatus    int         `json:"order_delete_status"`     // 订单删除状态(0正常,1回收站,2已删除)
	BuyUserNickname      string      `json:"buy_user_nickname"`       //用户昵称
	SellUserNickname     string      `json:"sell_user_nickname"`      //大神昵称
	SkillName            string      `json:"skill_name"`              //技能名称
	SkillIconurl         string      `json:"skill_iconurl"`           //技能icon
	CountDown            int64       `json:"count_down"`              //倒计时
	ProtectionTime       int64       `json:"protection_time"`         //剩余保护时间
	CreatedTime          int64       `json:"created_time"`            //创建时间
	RefundInfo           interface{} `json:"refund_info"`             //退款信息
	AppealInfo           interface{} `json:"appeal_info"`             //申诉信息
}

type SkillOrderGameInfo struct {
	GameId      int64  `json:"game_id" json:"game_id" gorm:"column:game_id"`
	GameName    string `json:"game_name" json:"game_name" gorm:"column:game_name"`
	GameType    int    `json:"game_type" json:"game_type" gorm:"column:game_type"`
	GameIconurl string `json:"game_iconurl" json:"game_iconurl" gorm:"column:game_iconurl"`
}

func (SkillOrderGameInfo) TableName() string {
	return "app_game"
}

type SkillOrderSeller struct {
	UserId   int    `json:"user_id" gorm:"column:user_id"`        //用户id
	Nickname string `json:"nickname" gorm:"column:user_nickname"` //昵称
	Gender   int    `json:"gender" gorm:"column:user_gender"`     //性别
	Iconurl  string `json:"iconurl" gorm:"column:user_iconurl"`   //头像
}

func (SkillOrderSeller) TableName() string {
	return "system_user"
}

// 历史订单
type QuerySkillOrderRep struct {
	OrderID            int64              `json:"order_id" json:"order_id"`
	OrderGameInfo      SkillOrderGameInfo `json:"order_game_info" gorm:"embedded"`      //出售订单用户id
	OrderSkillID       int64              `json:"order_skill_id" json:"order_skill_id"` //购买的技能id
	OrderSeller        SkillOrderSeller   `json:"order_seller" gorm:"embedded"`         //购买的游戏id
	SkillPrice         int                `json:"skill_price" gorm:"column:detail_value"`
	OrderCount         int64              `json:"order_count" json:"order_count"`                   //数量
	OrderAmount        int64              `json:"order_amount" json:"order_amount"`                 //订单总金额
	OrderStatus        int                `json:"order_status" json:"order_status"`                 //订单状态(0待接单,1已接单,2买家取消,3卖家取消,4系统取消,5卖家确认完成,6买家确认完成)
	OrderPayStatus     int                `json:"order_pay_status" json:"order_pay_status"`         //支付状态(0待付款;1付款中;2已付款)
	OrderPayTime       int64              `json:"order_pay_time" json:"order_pay_time"`             //订单支付时间
	OrderRefundStatus  int                `json:"order_refund_status" json:"order_refund_status"`   //退款状态(0未退款,1退款中,2退款完成,3取消退款,4拒绝退款)
	OrderCommentStatus int                `json:"order_comment_status" json:"order_comment_status"` //评价状态(0待评价,1已评价,2已回复)
	Created            int64              `json:"created" json:"created"`
}

type BeforeOrder struct {
	SparringId    int64        `json:"sparring_id"`     //大神用户id
	SkillSkillID  int64        `json:"skill_game_id"`   //选择游戏id
	SkillGameName string       `json:"skill_game_name"` //选择的游戏名字
	SparringName  string       `json:"sparring_name"`   //大神昵称
	OrderSkills   []SkillGames `json:"order_skills"`    //大神可提供的
}
type OrderPrices struct {
	SkillInfoId int64 `json:"skill_info_id"` //skillInfo的id
	SkillPrice  int64 `json:"skill_price"`   //计价单位
	InfoPrice   int64 `json:"info_price"`    //价格数量
}

type SkillGames struct {
	GameId      int64         `json:"game_id"`
	GameName    string        `json:"game_name"`
	SkillPrices []OrderPrices `json:"skill_prices"` //技能价格
}
type OrderUserInfo struct {
	UserId   int64  `json:"user_id" gorm:"column:user_id"`
	Icon     string `json:"icon" gorm:"column:user_iconurl"`      // 用户头像
	Nickname string `json:"nickname" gorm:"column:user_nickname"` // 昵称
	Gender   int    `json:"gender" gorm:"column:user_gender"`     //用户性别0未知,1男,2女
	Birthday int64  `json:"birthday" gorm:"column:user_birthday"` //出生年月日
}

type OrderSkillInfo struct {
	SkillId int64  `json:"skill_id"`
	Name    string `json:"name" gorm:"column:skill_name"`
	Icon    string `json:"icon" gorm:"column:skill_iconurl"`
}

//
type SkillOrderBySparringRep struct {
	OrderId              int64          `json:"order_id"`                                                      // 订单id
	OrderSparringSkillId int64          `gorm:"column:order_sparring_skill_id" json:"order_sparring_skill_id"` // 大神基恩那个id
	OrderStatus          int            `json:"order_status"`                                                  // 订单状态(0待接单,1已接单,2已取消,3买家确认完成,4卖家确认完成
	OrderPayStatus       int            `gorm:"column:order_pay_status" json:"order_pay_status"`               // 支付状态(0待付款,1付款中,2已付款)
	OrderConfirmStatus   int            `gorm:"column:order_confirm_status" json:"order_confirm_status"`       // 接单状态(0待接单,1大神拒绝,2大神结单,3大神完成)
	OrderCancelStatus    int            `gorm:"column:order_cancel_status" json:"order_cancel_status"`
	OrderRefundStatus    int            `json:"order_refund_status"`                                     // 退款状态
	OrderAppealStatus    int            `json:"order_appeal_status"`                                     // 申诉状态(0未申诉,1申诉中,2待处理,3处理完成)
	OrderFinishStatus    int            `gorm:"column:order_finish_status" json:"order_finish_status"`   // 完成状态(0未完成,1系统自动完成,3玩家完成)
	OrderCommentStatus   int            `gorm:"column:order_comment_status" json:"order_comment_status"` // 评价状态(0待评价,1玩家已评价,2大神已评价)
	OrderSettleStatus    int            `gorm:"column:order_settle_status" json:"order_settle_status"`   // 订单结算(提取)状态(0未结算,1系统自动已结算,2客服结算)
	OrderBuyUserId       int64          `gorm:"column:order_buy_user_id" json:"-"`                       // 购买用户id
	OrderSellUserId      int64          `gorm:"column:order_sell_user_id" json:"-"`                      // 出售订单用户id
	OrderSkillId         int64          `gorm:"column:order_skill_id" json:"order_skill_id"`             // 购买的技能id
	OrderRefundCount     int            `gorm:"column:order_refund_count" json:"order_refund_count"`     // 退款申请次数
	SellerInfo           OrderUserInfo  `json:"seller_info" gorm:"foreignKey:UserId;references:OrderSellUserId"`
	BuyerInfo            OrderUserInfo  `json:"buyer_info" gorm:"foreignKey:UserId;references:OrderBuyUserId"`
	SkillInfo            OrderSkillInfo `json:"skill_info" gorm:"foreignKey:SkillId;references:OrderSkillId"`
	OrderPrice           int64          `json:"order_price"`        // 单价
	OrderWay             string         `json:"order_way"`          // 订单单位
	OrderCount           int64          `json:"order_count"`        // 订单购买数量
	OrderAmount          int64          `json:"order_amount"`       // 收入
	Countdown            int64          `json:"countdown" gorm:"-"` // 倒计时
	FinishTime           int64          `json:"finish_time" gorm:"column:order_finish_time"`
	OrderIsFinished      int            `json:"is_finished" gorm:"column:order_is_finished"` // 订单是否完成
	Created              int64          `json:"created"`                                     //订单生成时间
}

const DEFAULT_SKILL_ORDER_ORDER_TIME = 60 * 15 // 订单倒计时

func (u *SkillOrderBySparringRep) AfterFind(tx *gorm.DB) (err error) {
	duration := (u.Created + DEFAULT_SKILL_ORDER_ORDER_TIME) - time.Now().Unix()
	if duration < 0 {
		duration = 0
	}
	u.Countdown = duration
	return
}

// 退款详情
type SkillOrderRefundInfo struct {
	RefundId      int64  `gorm:"column:refund_id;primaryKey;autoIncrement" json:"refund_id"`
	RefundOrderId int64  `gorm:"column:refund_order_id" json:"refund_order_id"` // 申请退款的订单id
	RefundClass   int    `gorm:"column:refund_class" json:"refund_class"`       // 退款类型(0全部退款,1)
	RefundCount   int64  `gorm:"column:refund_count" json:"refund_count"`       // 退款代币数量
	RefundReason  string `gorm:"column:refund_reason" json:"refund_reason"`     // 退款申请原因
	RefundRemark  string `gorm:"column:refund_remark" json:"refund_remark"`     // 退款说明
}
