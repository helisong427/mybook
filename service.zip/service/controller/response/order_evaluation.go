package response

//订单评论回复
type OrderEvaluationResp struct {
	CommentUserNickName string   `json:"comment_user_nickname"` // 评价人姓名
	CommentUserIconURL  string   `json:"comment_user_iconurl"`  // 头像
	CommentDate         int64    `json:"comment_date"`          // 评论日期
	CommentContent      string   `json:"comment_content"`       // 订单评价
	CommentAttitude     uint64   `json:"comment_attitude"`      // 好差评(0好评 1差评)
	CommentLabel        []string `json:"comment_label"`         // 评论标签
	CommentAnonymous    uint64   `json:"comment_anonymous"`     // 订单是否匿名(0不匿名 1匿名)
	CommentDispute      bool     `json:"comment_dispute"`       // 订单是否有争议
}

// 订单评论列表回复
type OrderEvaluationListResp struct {
	OrderNum      int64                 `json:"order_num"`      // 服务人数
	FavorableRate int64                 `json:"favorable_rate"` // 好评率
	OrderList     []OrderEvaluationResp `json:"comment_list"`   // 列表
	LabelDetail   []LabelArray          `json:"label_detail"`   // 评论列表页标签数组
}
