package response

type UserGoBillRep struct {
	Desc   string `json:"desc"`   //描述
	Amount int64  `json:"amount"` //代币数
	Change int    `json:"change"` //变动:0--减少,1--增加
	Time   int64  `json:"time"`   //时间
}

//用户首充信息
type UserFirstChargeRep struct {
	UserIsRecharge  int               `json:"user_is_recharge"`  //用户是否首充
	FirstChargeList []FirstChargeList `json:"first_charge_list"` //首充列表
}

type FirstChargeList struct {
	PropName  string `json:"prop_name"`  //礼物名称
	PropIcon  string `json:"prop_icon"`  //礼物icon
	PropCount int64  `json:"prop_count"` //礼物数量
}

// 用户其他收入
type UserOtherIncomeResp struct {
	TransactionId     int64  `gorm:"column:transaction_id;primaryKey;autoIncrement" json:"transaction_id"` // 交易id
	TransactionType   int    `gorm:"column:transaction_type" json:"transaction_type"`                      // 交易类型
	TransactionAmount int64  `gorm:"column:transaction_amount" json:"transaction_amount"`                  // 涉及代币数*100
	TransactionTime   int64  `gorm:"column:edited" json:"transaction_time"`                                // 时间
	TransactionRemark string `gorm:"column:transaction_remark" json:"transaction_remark"`                  // 交易备注
	TransactionStatus int    `gorm:"column:transaction_status" json:"transaction_status"`                  // 交易状态
	TransactionIncome bool   `gorm:"-" json:"transaction_income"`
	Created           int64  `json:"-" gorm:"column:created"`
}
