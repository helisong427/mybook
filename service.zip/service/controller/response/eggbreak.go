package response

import "gamers/utils/prop"

// 砸蛋列表
type EggBreakConfigListRep struct {
	EggbreakId            int64                 `json:"eggbreak_id"`              // 奖池id
	EggbreakTitle         string                `json:"eggbreak_title"`           // 奖池名称
	EggbreakDesc          string                `json:"eggbreak_desc"`            // 奖池描述
	EggbreakCostPropType  int                   `json:"eggbreak_cost_prop_type"`  // 消耗物品类型
	EggbreakCostPropId    int64                 `json:"eggbreak_cost_prop_id"`    // 砸蛋道具id
	EggbreakCostPropCount int64                 `json:"eggbreak_cost_prop_count"` // 单次消耗数量
	EggbreakRewardRate    []*EggBreakRewardRate `json:"eggbreak_reward_rate"`     // 砸蛋奖励概率
	EggbreakStatus        int                   `json:"eggbreak_status"`          // 状态
	EggbreakConfigType    int                   `json:"eggbreak_config_type"`     // 砸蛋配置类型(0金蛋 1银蛋)
}

type EggBreakRewardRate struct {
	PropType     int    `json:"prop_type"`      // 物品类型
	PropId       int64  `json:"prop_id"`        // 物品Id
	PropName     string `json:"prop_name"`      // 物品名字
	PropPrice    int64  `json:"prop_price"`     // 物品价格
	PropOrgPrice int64  `json:"prop_org_price"` // 物品原价
	PropIcon     string `json:"prop_icon"`      // 物品图标
	Rate         string `json:"rate"`           // 0.35%
	RateValue    int64  `json:"rate_value"`     // 万分比
}

// 砸蛋设置
type EggBreakSettingRep struct {
	UserEggbreakMsg int `json:"user_eggbreak_msg" binding:"min=0,max=1"`
}

type EggBreakSettingChangeRep struct {
	UserEggbreakMsg int `json:"user_eggbreak_msg" binding:"min=0,max=1"`
}

// 砸蛋
type EggBreakRep struct {
	EggbreakId            int                     `json:"eggbreak_id"`
	EggbreakCount         int                     `json:"eggbreak_count"`
	EggbreakCostPropType  prop.Type               `json:"eggbreak_cost_prop_type"`
	EggbreakCostPropId    int                     `json:"eggbreak_cost_prop_id"`
	EggbreakCostPropCount int                     `json:"eggbreak_cost_prop_count"`
	EggbreakDetails       []*EggBreakRewardDetail `json:"eggbreak_details"` // 砸蛋详细（奖励列表）
	EggbreakTotalPrice    int64                   `json:"-"`                // 获得物品总价值
}

// 砸蛋
type EggBreakResp struct {
	EggbreakId            int                     `json:"eggbreak_id"`
	EggbreakCount         int                     `json:"eggbreak_count"`
	EggbreakCostPropType  prop.Type               `json:"eggbreak_cost_prop_type"`
	EggbreakCostPropId    int                     `json:"eggbreak_cost_prop_id"`
	EggbreakCostPropCount int                     `json:"eggbreak_cost_prop_count"`
	EggbreakDetails       []*EggBreakRewardDetail `json:"eggbreak_details"` // 砸蛋详细（奖励列表）
	EggbreakTotalPrice    int64                   `json:"-"`                // 获得物品总价值
	EggbreakHammerCount   int64                   `json:"hammer_count"`     // 砸蛋后锤子数量
}

type EggBreakRewardDetail struct {
	PropType        prop.Type `json:"prop_type"`  // 物品类型
	PropId          int       `json:"prop_id"`    // 物品ID
	PropCount       int       `json:"prop_count"` // 物品被抽到次数
	PropExpiredType int64     `json:"-"`          // 过期类型(0具体时间,1若干天后)
	PropExpiredTime int64     `json:"-"`          // 过期时间,根据limit_type确定
	PropOrgPrice    int64     `json:"-"`          // 价值(单价)
	PropGetRadio1   int64     `json:"-"`          // 获得物品是否全服广播(0不广告,1广播)
	PropName        string    `json:"prop_name"`  // 物品名字
	PropAttrId      int64     `json:"-"`          // 道具属性(礼物页签,对应app_prop_attr中的attr_id)
	PropIcon        string    `json:"prop_icon"`  // 物品图标
}

// 砸蛋记录 (仅用来暂存数据)
type EggBreakRecordsRep struct {
	EggbreakId int               `json:"eggbreak_id"` // 砸蛋记录ID
	Records    []*EggBreakRecord `json:"records"`     // 砸蛋记录
}

type EggBreakRecordReward struct {
	PropType  int    `json:"prop_type"`  // 物品类型
	PropId    int    `json:"prop_id"`    // 物品ID
	PropCount int    `json:"prop_count"` // 物品被抽到次数
	PropPrice int64  `json:"prop_price"` // 商品价格
	PropName  string `json:"prop_name"`  // 物品名字
	PropIcon  string `json:"prop_icon"`  // 物品图标
}

type EggBreakRecord struct {
	LogRecordId      int64                   `json:"log_record_id"`      // 砸蛋记录id
	LogEggbreakCount int                     `json:"log_eggbreak_count"` // 砸蛋次数(如：1次/10次/50次/100次)
	LogItemCount     int                     `json:"-"`                  // 奖励条目数（即 len(log_details)）
	LogDetails       []*EggBreakRecordReward `json:"log_details"`        // 砸蛋详细（奖励列表）
	Created          int64                   `json:"created"`            // 创建时间
	// FOR QUERY
	LogPropType  int `json:"-"` // 物品类型(0礼物,1锤子,2go币)
	LogPropId    int `json:"-"` // 物品ID
	LogPropCount int `json:"-"` // 物品被抽到次数
}
