package response

import (
	"gorm.io/gorm"
)

type SkillInfo struct {
	SkillId                  int64  `json:"skill_id"`
	SkillName                string `json:"skill_name"`
	SkillIcon                string `json:"skill_icon" gorm:"column:skill_iconurl"`
	SkillSpeedMatchingStatus int64  `json:"skill_speed_matching_status"` // 抢单开关(0关闭,1开启)
	SkillMsgStatus           int64  `json:"skill_msg_status"`            // 抢单消息(0关闭,1开启)
}

type SparringMonthIncome struct {
	MonthIncome    int64 `json:"month_income" gorm:"column:month_income"`
	UnSettleIncome int64 `json:"un_settle_income" gorm:"column:un_settle_income"`
}

// 大神主页
type SparringHomeRes struct {
	UserId             int64       `json:"user_id" gorm:"column:user_id"`
	UserPrettyId       int64       `json:"user_pretty_id" gorm:"column:user_pretty_id"`
	Icon               string      `json:"icon" gorm:"column:user_iconurl"`                           // 用户头像
	IconVerification   int         `gorm:"column:user_iconurl_verification" json:"icon_verification"` // 大神认证头像
	Nickname           string      `json:"nickname" gorm:"column:user_nickname"`                      // 昵称
	Gender             int         `json:"gender" gorm:"column:user_gender"`                          // 用户性别0未知,1男,2女
	Age                int         `json:"age" gorm:"column:user_birthday"`                           // 出生年月日
	MonthIncome        int64       `json:"month_income" gorm:"column:month_income"`
	TotalIncome        int64       `json:"total_income" gorm:"column:total_income"`
	SkillCount         int         `json:"skill_count" gorm:"-"` // 技能总数
	SkillInfos         []SkillInfo `json:"skill_infos" gorm:"-"`
	UserIsForwardsNews int64       `json:"user_is_forwards_news"` // 是否接受用户浏览消息推送
}

// 大神收益明细
type SparringIncomeRecord struct {
	OrderId         int64 `json:"order_id"`
	OrderStatus     int   `json:"order_status"`                                // 订单状态6完成,8结算
	Income          int64 `json:"income" gorm:"column:order_income"`           // 订单收益
	IncomeTime      int64 `gorm:"column:order_finish_time" json:"income_time"` // 订单结算(提取)时间
	OrderSettleTime int64 `gorm:"column:order_settle_time" json:"-"`           // 订单结算(提取)时间
}

// 标签数组
type LabelArray struct {
	LabelId   int64  `json:"label_id"`
	LabelName string `json:"label_name"`
	LabelNum  int64  `json:"label_num"`
}

// 查询钩子，处理结算时间
func (u *SparringIncomeRecord) AfterFind(tx *gorm.DB) (err error) {
	// 结算状态则显示结算时间
	if u.OrderStatus == 8 {
		u.IncomeTime = u.OrderSettleTime
	}
	return
}

type SparringInfoResult struct {
	SkillName              string               `json:"skill_name"`                // 技能名称
	SkillTitle             string               `json:"skill_title"`               // 技能标题
	SkillInfo              string               `json:"skill_info"`                // 介绍
	PriceId                int                  `json:"price_id"`                  // 价格Id
	PriceWay               string               `json:"price_way"`                 // 陪玩方式
	PricePrice             int                  `json:"price_price"`               // 技能价格
	PriceType              int                  `json:"price_type"`                // 价格类型,0自定义,1系统默认
	SkillProveImage        string               `json:"skill_prove_image"`         // 认证图
	IsAttention            bool                 `json:"is_attention"`              // 是否关注大神
	SkillSound             string               `json:"skill_sound"`               // 语音介绍
	SkillSoundTime         int                  `json:"skill_sound_time"`          // 语音长度
	SkillIconUrl           string               `json:"skill_icon_url"`            // 游戏icon
	UserId                 int64                `json:"user_id"`                   // 大神id
	UserPrettyId           int64                `json:"user_pretty_id"`            // 靓号
	UserNickName           string               `json:"user_nick_name"`            // 昵称
	UserIconurl            string               `json:"user_iconurl"`              // 头像
	UserAge                int                  `json:"user_age"`                  // 年龄
	UserGender             int                  `json:"user_gender"`               // 性别
	Images                 []string             `json:"images"`                    // 背景图
	CertifiedValue         string               `json:"certified_value"`           // 认证值
	ServiceCount           int                  `json:"service_count"`             // 服务单数
	FavorableRate          int64                `json:"favorable_rate"`            // 好评率
	SkillLabel             []string             `json:"skill_label"`               // 技能标签
	CommentNum             int64                `json:"comment_num"`               // 大神详情评论总数量
	SkillCardBackGroundUrl string               `json:"skill_card_background_url"` // 名片背景图片
	SkillStatus            int                  `json:"skill_status"`              // 大神技能状态
	SkillParams            []SkillParams        `json:"skill_params"`              // 技能参数
	SkillCardParams        []SkillParams        `json:"skill_card_params"`         // 名片可选字段
	SkillInfoParams        []SkillInfoParams    `json:"skill_info_params"`         // 技能参数-详情
	LabelDetail            []LabelArray         `json:"label_detail"`              // 大神详情页标签数组
	FirstComment           *OrderEvaluationResp `json:"first_comment"`             // 大神详情第一条评论
	SparringOtherSkill     []SparringOtherSkill `json:"sparring_other_skill"`      // 大神其他技能
}

type SparringOtherSkill struct {
	SparringId     int    `json:"sparring_id"`     // 大神技能id
	SkillType      int    `json:"skill_type"`      // 游戏类型(0游戏,1娱乐)
	SkillName      string `json:"skill_name"`      // 游戏名称
	SkillIconUrl   string `json:"skill_icon_url"`  // 游戏icon
	ServiceCount   int    `json:"service_count"`   // 服务人数
	PriceWay       string `json:"price_way"`       // 陪玩方式
	PricePrice     int    `json:"price_price"`     // 技能价格
	FavorableRate  int64  `json:"favorable_rate"`  // 好评率
	CertifiedValue string `json:"certified_value"` // 认证值
}

type SkillParams struct {
	Title string   `json:"title"` // 参数名称
	Value []string `json:"value"` // 参数值
}

type SkillInfoParams struct {
	Title string   `json:"title"` // 参数名称
	Value []string `json:"value"` // 参数值
	Icon  string   `json:"icon"`  // 图标
}

// 大神列表返回
type SparringListRes struct {
	SparringId        int64   `json:"sparring_id"`         // 大神用户id
	SkillSkillID      int64   `json:"skill_game_id"`       // 游戏id
	SparringName      string  `json:"sparring_name"`       // 大神昵称
	SparringSkillInfo string  `json:"sparring_skill_info"` // 技能介绍
	CertifiedValue    string  `json:"certified_value"`     // 认证值
	PriceWay          string  `json:"price_way"`           // 陪玩方式
	PricePrice        int     `json:"price_price"`         // 技能价格
	ServiceCount      int64   `json:"service_count"`       // 服务人数
	SkillSound        string  `json:"skill_sound"`         // 语音介绍
	SkillSoundTime    int64   `json:"skill_sound_time"`    // 语音时长
	SparringIconurl   string  `json:"sparring_iconurl"`    // 大神AI认证图片
	UserAge           int     `json:"user_age"`            // 年龄
	UserGender        int     `json:"user_gender"`         // 用户性别:0--未知,1--男,2--女
	IsCertification   int     `json:"is_certification"`    // 是否认证:0--否,1--是
	IsOnline          int     `json:"is_online"`           // 是否在线:0--否,1--是
	PraiseRate        float32 `json:"praise_rate"`         // TODO 好评率
	Longitude         float32 `json:"longitude"`           // 发送经度
	Latitude          float32 `json:"latitude"`            // 发送维度
	UserId            int64   `json:"user_id"`             // 用户ID
	IsRecommend       int64   `json:"is_recommend"`        // 是否是 为你推荐
}

const (
	SPARRING_CHOOSE_STATUS_NO = iota
	SPARRING_CHOOSE_STATUS_YES
)

type UpdateSparringSkillsResp struct {
	SkillID                int64                   `json:"skill_id"`                         // 大神技能id
	SkillUserID            int64                   `json:"skill_user_id"`                    // 用户id
	UserIconurl            string                  `json:"user_iconurl"`                     // 用户头像
	UserQQ                 string                  `json:"user_qq"`                          // 用户qq
	UserWechat             string                  `json:"user_wechat"`                      // 用户微信
	SkillTitle             string                  `json:"skill_title"`                      // 技能名称
	SkillSkillID           int64                   `json:"skill_skill_id"`                   // 技能id
	SkillProveImage        string                  `json:"skill_prove_image"`                // 图片
	SkillSound             string                  `json:"skill_sound"`                      // 语音
	SkillSoundTime         int64                   `json:"skill_sound_time"`                 // 语音时长
	SkillInfo              string                  `json:"skill_info"`                       // 技能介绍
	SkillStatus            int                     `json:"skill_status"`                     // 技能状态
	SkillCardBackGroundUrl string                  `json:"skill_card_background_url"`        // 名片背景图片
	SkillRequiredValue     []AppSkillFieldValue    `gorm:"-" json:"skill_required_value"`    // 必传字段
	GameSkillFiledValues   []GameSkillFiledValue   `gorm:"-" json:"game_skill_filed_values"` // 技能字段
	AppSparringSkillPrice  []AppSparringSkillPrice `json:"app_sparring_skill_price"`         // 关联大神价格
}

type AppSparringSkillPrice struct {
	PriceId              int64         `gorm:"column:price_id" json:"price_id"`                               // 自增长id
	PriceType            int           `json:"price_type"`                                                    // 价格类型
	PriceSkillId         int64         `gorm:"column:price_skill_id" json:"price_skill_id"`                   // 技能id
	PriceUserId          int64         `gorm:"column:price_user_id" json:"price_user_id"`                     // 用户id
	PriceSparringSkillId int64         `gorm:"column:price_sparring_skill_id" json:"price_sparring_skill_id"` // 大神技能id
	PricePriceId         int64         `gorm:"column:price_price_id" json:"price_price_id"`                   // 计价单位,对应app_skill_price的 price_id
	PricePrice           int64         `gorm:"column:price_price" json:"price_price"`                         // 价格
	PriceOrgPrice        int64         `gorm:"column:price_org_price" json:"price_org_price"`                 // 原始价格
	Choose               int           `json:"choose"`
	AppSkillPrice        AppSkillPrice `json:"app_skill_price"` // 一对一关联技能价格表
}
type AppSkillPrice struct {
	PriceSkillId        int64  `gorm:"column:price_skill_id" json:"price_skill_id"`               // 技能id
	PriceWay            string `gorm:"column:price_way" json:"price_way"`                         // 陪玩方式 局/次/天/半小时/小时
	PriceTime           int64  `gorm:"column:price_time" json:"price_time"`                       // 陪玩方式   时长  单位分钟
	PriceRequired       int    `json:"price_required" gorm:"column:price_required"`               // 必选值
	PriceProtectionTime int64  `gorm:"column:price_protection_time" json:"price_protection_time"` // 订单保护时间长,过了这个时间才能确认订单：0分钟/5分钟/7分钟/10分钟/15分钟/20分钟/30分钟（当陪玩方式选择局/次，保护时间才可选）半小时/小时/天，陪玩时长固定为30分钟/60分钟/720分钟 保护时间固定为15分钟/30分钟/360分钟

}

type AppSkillFieldValue struct {
	ValueId        int64  `gorm:"column:value_id" json:"value_id"`
	ValueSkillId   int64  `gorm:"column:value_skill_id" json:"value_skill_id"`     // 技能id
	ValueField     string `gorm:"column:value_field" json:"value_field"`           // 技能字段
	ValueFieldName string `gorm:"column:value_field_name" json:"value_field_name"` // 技能字段名称
	ValueValue     string `gorm:"column:value_value" json:"value_value"`           // 技能字段值
	ValueOrder     int64  `gorm:"column:value_order" json:"value_order"`           // 字段排序
	Choose         int    `json:"choose"`
}

type GameSkillFiledValue struct {
	ValueKey     string               `json:"value_key"`                                   // 技能字段
	ValueKeyName string               `gorm:"column:value_key_name" json:"value_key_name"` // 技能字段名称
	ShowType     int                  `json:"show_type"`                                   // 展示样式，0是之前默认样式，1是瀑布流
	MaxSize      int                  `json:"max_size"`                                    // 0为不设限制，1代表限制单选，2代表选两个
	Values       []AppSkillFieldValue `json:"values"`
}

const (
	SKILL_FILED_SHOW_TYPE_NORMAL = iota // 默认样式
	SKILL_FILED_SHOW_TYPE_FALLS         // 瀑布流
)

// 大神历史icon
type HistoryIcon struct {
	UserIconurl string `json:"user_iconurl"`
}
