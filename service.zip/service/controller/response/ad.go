package response

//AdListRep广告返回
type AdListRep struct {
	AdId         int64       `json:"ad_id"`
	AdName       string      `json:"ad_name"`        // AdName 广告名称
	AdPositionID int64       `json:"ad_position_id"` // AdPositionID 广告位id
	AdContent    string      `json:"ad_content"`     // AdContent 广告内容
	AdURL        string      `json:"ad_url"`         // AdURL 广告链接
	AdJumpType   int64       `json:"ad_jump_type"`   // AdJumpType 跳转类型:0--网站跳转,1--app内跳转
	AdURLParam   interface{} `json:"ad_url_param"`   // AdURL 广告跳转参数
	AdType       int64       `json:"ad_type"`        // AdType 广告类型(0图片,1H5)
	AdOrder      int64       `json:"ad_order"`       // AdOrder 排序
	AdStartTime  int64       `json:"ad_start_time"`  // AdStartTime 开始时间
	AdEndTime    int64       `json:"ad_end_time"`    // AdEndTime 结束时间
	AdStatus     int64       `json:"ad_status"`      // AdStatus 广告状态 0--关闭 1--开启
	Created      int64       `json:"created"`        // Created 创建时间(注册时间)
	Edited       int64       `json:"edited"`         // Edited 修改时间
	Deleted      int64       `json:"deleted"`        // Deleted 删除时间
}
