package response

// 用户登录成功用户返回信息
type UserLoginRep struct {
	UserId       int64  `json:"user_id"`
	IsBindMobile uint   `json:"is_bind_mobile"`
	IsSetInfo    uint   `json:"is_set_info"`
	Nickname     string `json:"nickname"`
	Gender       int    `json:"gender"`
	Iconurl      string `json:"iconurl"`
	IsSuper      int    `json:"is_super"`
	IsFirstOnDay int    `json:"is_first_on_day"` // 当日首次登录标记（0：不是首次登录；1：首次登录）
}
