package response

type WechatAccessTokeRep struct {
	AccessToken  string `json:"access_token"`
	ExpiresIn    int    `json:"expires_in"`
	RefreshToken string `json:"refresh_token"`
	Openid       string `json:"openid"`
	Scope        string `json:"scope"`
}

type GetWechatBindingRep struct {
	IsBinding   int    `json:"is_binding"` // 是否已经绑定， 0已绑定，1未绑定
	Openid      string `json:"openid"`     // 微信用户的openid
	UserId      int64  `json:"user_id"`
	PhoneNumber string `json:"phone_number"`
	Hash        string `json:"hash"`
}
