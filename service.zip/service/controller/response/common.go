package response

type GetRegionListRep struct {
	RegionID int64              `json:"region_id"` //地区id
	Name     string             `json:"name"`      //简称
	ParentID int64              `json:"parent_id"` //上级id
	Fullname string             `json:"fullname"`  //全名
	Level    string             `json:"level"`     //地区级别(0国家,1省,2市,3区)
	Child    []GetRegionListRep `json:"child"`     //子级
}

type TextModerationRep struct {
	Ok int `json:"ok"`
}
