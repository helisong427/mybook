package response

// 用户送礼排行（财富榜）
type RankUserSendWealth struct {
	Tag       string                     `json:"tag"` // tag : daily/weekly/monthly
	Period    int                        `json:"period"`
	Countdown int64                      `json:"countdown"`
	List      []*RankUserSendWealthItem  `json:"list"`
	Own       *RankUserSendWealthItemOwn `json:"own"`
}

const MAX_RANK_LIST_LENGTH = 10 //排行榜最大条数

type RankUserSendWealthItem struct {
	UserId        int64  `json:"user_id"`         // user_id
	Nickname      string `json:"nickname"`        // 昵称
	Gender        int    `json:"gender"`          // 性别
	Icon          string `json:"icon"`            // 头像
	AvatarDressUp string `json:"avatar_dress_up"` // 头像框
	UnionId       int64  `json:"union_id"`        // 公会id
	Wealth        int64  `json:"wealth"`          // 财富
	RoomId        int64  `json:"room_id"`         // 房间id
}

type RankUserSendWealthItemOwn struct {
	RankUserSendWealthItem
	Rank      int   `json:"rank"`       // default:0
	DiffValue int64 `json:"diff_value"` // 差值（正为超出，负为差额）
}

// 用户收礼排行（魅力榜）
type RankUserRecvCharm struct {
	Tag       string                    `json:"tag"` // tag : daily/weekly/monthly
	Period    int                       `json:"period"`
	Countdown int64                     `json:"countdown"`
	List      []*RankUserRecvCharmItem  `json:"list"`
	Own       *RankUserRecvCharmItemOwn `json:"own"`
}

type RankUserRecvCharmItem struct {
	UserId        int64  `json:"user_id"`         // user_id
	Nickname      string `json:"nickname"`        // 昵称
	Gender        int    `json:"gender"`          // 性别
	Icon          string `json:"icon"`            // 头像
	AvatarDressUp string `json:"avatar_dress_up"` // 头像框
	UnionId       int64  `json:"union_id"`        // 公会id
	Charm         int64  `json:"charm"`           // 魅力
	RoomId        int64  `json:"room_id"`
}

type RankUserRecvCharmItemOwn struct {
	RankUserRecvCharmItem
	Rank      int   `json:"rank"`       // default:0
	DiffValue int64 `json:"diff_value"` // 差值（正为超出，负为差额）
}

// 房间送礼排行（魅力榜）
type RankRoomSendCharm struct {
	Tag       string                    `json:"tag"` // tag : hourly
	Period    int                       `json:"period"`
	Countdown int64                     `json:"countdown"`
	List      []*RankRoomSendCharmItem  `json:"list"`
	Own       *RankRoomSendCharmItemOwn `json:"own"`
}

type RankRoomSendCharmItem struct {
	RoomId         int64  `json:"room_id"`           // 房间id
	RoomType       int    `json:"room_type"`         // 房间类型
	RoomName       string `json:"room_name"`         // 房间名字
	RoomCover      string `json:"room_cover"`        // 房间封面
	RoomAttrId     int64  `json:"room_attr_id"`      // 房间属性
	RoomAttrName   string `json:"room_attr_name"`    // 房间属性名字
	RoomAttrType   int    `json:"room_attr_type"`    // 房间属性分类
	RoomAttrIsShow int    `json:"room_attr_is_show"` // 是否显示
	UnionId        int64  `json:"union_id"`          // 公会id
	UnionName      string `json:"union_name"`        // 公会名字
	Charm          int64  `json:"charm"`             // 魅力
}

type RankRoomSendCharmItemOwn struct {
	RankRoomSendCharmItem
	Rank      int   `json:"rank"`       // default:0
	DiffValue int64 `json:"diff_value"` // 差值（正为超出，负为差额）
}

// 房间送礼排行变更轮询（魅力榜）
type RankRoomSendCharmRollPolling struct {
	RoomId       int64  `json:"room_id"` // 房间id
	Tag          string `json:"tag"`     // tag : hourly
	Period       int    `json:"period"`  // 原样返回
	Rank         int    `json:"rank"`    // 原样返回
	Score        int64  `json:"score"`   // 原样返回
	NewPeriod    int    `json:"new_period"`
	NewCountdown int64  `json:"new_countdown"`
	NewRank      int    `json:"new_rank"`
	NewScore     int64  `json:"new_score"`
}

// 房间内用户送礼排行（财富榜）
type RankRoomUserSendWealth struct {
	RoomId    int64                          `json:"room_id"`
	Tag       string                         `json:"tag"` // tag : daily/weekly/monthly
	Period    int                            `json:"period"`
	Countdown int64                          `json:"countdown"`
	List      []*RankRoomUserSendWealthItem  `json:"list"`
	Own       *RankRoomUserSendWealthItemOwn `json:"own"`
}

type RankRoomUserSendWealthItem struct {
	UserId            int64  `json:"user_id"`             // user_id
	Nickname          string `json:"nickname"`            // 昵称
	Gender            int    `json:"gender"`              // 性别
	Icon              string `json:"icon"`                // 头像
	AvatarDressUp     string `json:"avatar_dress_up"`     // 头像框
	VipLevel          int    `json:"vip_level"`           // vip_level
	UnionId           int64  `json:"union_id"`            // 公会id
	Wealth            int64  `json:"wealth"`              // 财富
	RoomRole          int    `json:"room_role"`           // 房间内身份
	RoomWheatPosition int    `json:"room_wheat_position"` // 房间内麦序
}

type RankRoomUserSendWealthItemOwn struct {
	RankRoomUserSendWealthItem
	Rank      int   `json:"rank"`       // default:0
	DiffValue int64 `json:"diff_value"` // 差值（正为超出，负为差额）
}

// 房间内用户收礼排行（魅力榜）
type RankRoomUserRecvCharm struct {
	RoomId    int64                         `json:"room_id"`
	Tag       string                        `json:"tag"` // tag : daily/weekly/monthly
	Period    int                           `json:"period"`
	Countdown int64                         `json:"countdown"`
	List      []*RankRoomUserRecvCharmItem  `json:"list"`
	Own       *RankRoomUserRecvCharmItemOwn `json:"own"`
}

type RankRoomUserRecvCharmItem struct {
	UserId            int64  `json:"user_id"`             // user_id
	Nickname          string `json:"nickname"`            // 昵称
	Gender            int    `json:"gender"`              // 性别
	Icon              string `json:"icon"`                // 头像
	AvatarDressUp     string `json:"avatar_dress_up"`     // 头像框
	VipLevel          int    `json:"vip_level"`           // vip_level
	UnionId           int64  `json:"union_id"`            // 公会id
	UnionName         string `json:"union_name"`          // 公会名称
	Charm             int64  `json:"charm"`               // 魅力
	RoomRole          int    `json:"room_role"`           // 房间内身份
	RoomWheatPosition int    `json:"room_wheat_position"` // 房间内麦序
}

type RankRoomUserRecvCharmItemOwn struct {
	RankRoomUserRecvCharmItem
	Rank      int   `json:"rank"`       // default:0
	DiffValue int64 `json:"diff_value"` // 差值（正为超出，负为差额）
}
