package response

// 用户信息返回
type UserInfoRep struct {
	UserId          int                `json:"user_id"`          // 用户id
	UserPrettyId    int64              `json:"user_pretty_id"`   // 靓号
	Nickname        string             `json:"nickname"`         // 昵称
	Gender          int                `json:"gender"`           // 性别
	Iconurl         string             `json:"iconurl"`          // 头像
	Mobile          string             `json:"mobile"`           // 手机号
	Birthday        int                `json:"birthday"`         // 生日
	Constellation   string             `json:"constellation"`    // 星座
	ProvinceId      int                `json:"province_id" `     // 省份id
	CityId          int                `json:"city_id" `         // 城市id
	RegionId        int                `json:"region_id"`        // 区县id
	ProvinceName    string             `json:"province_name"`    // 省份名称
	CityName        string             `json:"city_name"`        // 城市名称
	RegionName      string             `json:"region_name"`      // 县区名称
	Sound           string             `json:"sound"`            // 用户声音地址
	SoundTime       int                `json:"sound_time"`       // 用户声音时长
	Slogan          string             `json:"slogan"`           // 用户签名
	LiveSavor       []UserLiveSavorRep `json:"live_savor"`       // 直播兴趣
	GameSavor       []UserGameSavorRep `json:"game_savor"`       // 游戏兴趣
	Images          []string           `json:"images"`           // 背景图
	FansCount       int                `json:"fans_count"`       // 粉丝数量
	FollowCount     int                `json:"follow_count"`     // 关注数量
	VisitsCount     int64              `json:"visits_count"`     // 访问数量
	VisitCountNew   int                `json:"visit_count_new"`  // 最新访问次数
	IsSetPassword   int                `json:"is_set_password"`  // 是否设置密码
	IsBindMobile    int                `json:"is_bind_mobile"`   // 是否绑定手机号
	IsBigGod        int                `json:"is_big_god"`       // 是否大神
	IsIdCard        int                `json:"is_id_card"`       // 是否身份认证
	IsAnchor        int                `json:"is_anchor"`        // 是否是主播
	LiveUnionId     int64              `json:"live_union_id"`    // 公会id
	Age             int                `json:"age"`              // 年龄
	WalletTotalOver int64              `json:"user_buy_over"`    // 用户余额
	UserRoomInfo    UserRoomInfo       `json:"user_room_info"`   // 用户房间信息
	AvatarDressUp   string             `json:"avatar_dress_up"`  // 头像装扮
	ChatDressUp     string             `json:"chat_dress_up"`    // 聊天装扮
	UserIsRecharge  int                `json:"user_is_recharge"` // 用户是否首充
	VipLevel        int                `json:"vip_level"`
	CreateT         int64              `json:"create_t"`
}

// 初始化设置用户信息
// 客户端获取设备手机号
type QueryMobileRep struct {
	Mobile string `json:"mobile"` // 手机号
}

// 初始化设置用户信息
type InitSetUserInfoRep struct {
	Nickname string `json:"nickname"` // 昵称
	Iconurl  string `json:"iconurl"`  // 头像
	Birthday int64  `json:"birthday"` // 生日
}

const (
	USER_IS_ID_CARD_FALSE = iota
	USER_IS_ID_CARD_TRUE
)

type UserRoomInfo struct {
	RoomId         int64  `json:"room_id"`          // 房间id
	RoomType       int    `json:"room_type"`        // 类型(0音频直播,1音频派对)
	RoomLiveStatus int    `json:"room_live_status"` // 直播状态,直播类型才有效(0下播,1上播)
	RoomStatus     int    `json:"room_status"`
	RoomCover      string `json:"room_cover"` // 封面
}

type UserSavorRep struct {
	UserLiveSavorRep []UserLiveSavorRep `json:"user_live_savor"`
	UserGameSavorRep []UserGameSavorRep `json:"user_game_savor"`
}

// 用户直播兴趣
type UserLiveSavorRep struct {
	SavorId   int64  `json:"savor_id"`
	SavorName string `json:"savor_name"`
}

// 用户游戏兴趣
type UserGameSavorRep struct {
	GameId   int64  `json:"game_id"`
	GameName string `json:"game_name"`
}

// 用户粉丝/关注 返回
type GetUserFollowListRep struct {
	UserID    int64  `json:"user_id"`
	Nickname  string `json:"nickname"`   // 昵称
	Gender    int    `json:"gender"`     // 用户性别0未知,1男,2女
	Iconurl   string `json:"iconurl"`    // 头像
	Slogan    string `json:"slogan"`     // 用户签名
	Age       int    `json:"age"`        // 年龄
	IsClosely int    `json:"is_closely"` // 是否互相关注
	IsOnline  int    `json:"is_online"`  // 是否在线
}

// 用户钱包信息
type UserWalletRep struct {
	WalletTotalOver int64 `gorm:"column:wallet_total_over" json:"wallet_total_over"`       // 总余额(可用代币数)
	AvailableIncome int64 `gorm:"column:wallet_total_extractable" json:"available_income"` // 可用
	TotalIncome     int64 `json:"total_income" gorm:"column:total_amount"`
}

// 其他用户信息返回
type OtherUserInfoRep struct {
	UserId           int                      `json:"user_id"`            // 用户id
	UserPrettyId     int64                    `json:"user_pretty_id"`     // 靓号
	Nickname         string                   `json:"nickname"`           // 昵称
	Gender           int                      `json:"gender"`             // 性别
	Iconurl          string                   `json:"iconurl"`            // 头像
	Constellation    string                   `json:"constellation"`      // 星座
	Sound            string                   `json:"sound"`              // 用户声音地址
	SoundTime        int                      `json:"sound_time"`         // 用户声音时长
	Slogan           string                   `json:"slogan"`             // 用户签名
	LiveSavor        []UserLiveSavorRep       `json:"live_savor"`         // 直播兴趣
	GameSavor        []UserGameSavorRep       `json:"game_savor"`         // 游戏兴趣
	Images           []string                 `json:"images"`             // 背景图
	FansCount        int                      `json:"fans_count"`         // 粉丝数量
	Age              int                      `json:"age"`                // 年龄
	UserOnlineStatus int                      `json:"user_online_status"` // 用户在线状态：0--不在线,1--在线
	UserRoomInfo     UserRoomInfo             `json:"user_room_info"`     // 用户房间信息
	IsFollow         int                      `json:"is_follow"`          // 是否关注:0--否,1--是
	IsRealName       int                      `json:"is_real_name"`       // 是否实名:0--否,1--是
	IsBigGod         int                      `json:"is_big_god"`         // 是否大神:0--否,1--是
	SparringSkill    []OtherUserSparringSkill `json:"sparring_skill"`     // 大神技能
	AvatarDressUp    string                   `json:"avatar_dress_up"`    // 头像装扮
	VipLevel         int                      `json:"vip_level"`          // vip等级
	IsBlack          int                      `json:"is_black"`           // 是否拉黑
}
type OtherUserSparringSkill struct {
	SparringId     int    `json:"sparring_id"`     // 大神技能id
	SkillType      int    `json:"skill_type"`      // 游戏类型(0游戏,1娱乐)
	SkillName      string `json:"skill_name"`      // 游戏名称
	SkillIconurl   string `json:"skill_iconurl"`   // 游戏icon
	CertifiedValue string `json:"certified_value"` // 认证值
	ServiceCount   int    `json:"service_count"`   // 服务人数
	PriceWay       string `json:"price_way"`       // 陪玩方式
	PricePrice     int    `json:"price_price"`     // 技能价格
}

// 头像特效
type IconStyle struct {
	IconId int64  `json:"icon_id"` // 装扮id
	BgUrl  string `json:"bg_url"`  // url
	EndT   int64  `json:"end_t"`   // 过期时间
}

// 用户名片返回
type UserCartRep struct {
	UserId       int64     `json:"user_id"`        // 用户id
	UserPrettyId int64     `json:"user_pretty_id"` // 靓号
	Nickname     string    `json:"nickname"`       // 昵称
	Gender       int       `json:"gender"`         // 性别
	Iconurl      string    `json:"iconurl"`        // 头像
	IconStyle    IconStyle `json:"icon_style"`
	Slogan       string    `json:"slogan"`       // 用户签名
	FansCount    int64     `json:"fans_count"`   // 粉丝数量
	FollowCount  int64     `json:"follow_count"` // 关注数量
	Age          int       `json:"age"`          // 年龄
	UserRole     int       `json:"user_role"`    // 用户身份:0--房主,1--管理员,2--普通用户
	IsMute       int       `json:"is_mute"`      // 是否禁言:0--否,1--是
	IsFollow     int       `json:"is_follow"`    // 是否关注:0--否,1--是
	IsRealName   int       `json:"is_real_name"` // 是否实名:0--否,1--是
	VipLevel     int       `json:"vip_level"`
}

// 用户认证详情
type UserCertificationDetailRep struct {
	IdCode   string `json:"id_code"`   // 身份证号码
	RealName string `json:"real_name"` // 姓名
}

// 访问记录
type UserVisitorListRep struct {
	UserId     int64  `json:"user_id"`
	Nickname   string `json:"nickname"`    // 昵称
	Gender     int    `json:"gender"`      // 性别
	Iconurl    string `json:"iconurl"`     // 头像
	Age        int    `json:"age"`         // 年龄
	Time       int64  `json:"time"`        // 访问时间
	VisitTimes int64  `json:"visit_times"` // 访问次数
	VisitType  int64  `json:"visit_type"`  // 0主页, 1 大神技能页
}

// 用户收入明细（按天的总收入）
type UserIncome struct {
	Income int64 `json:"income" gorm:"column:income"`
	Expend int64 `json:"expend" gorm:"column:expend"`
}

// 用户查找
type UserFindRep struct {
	UserId        int64   `json:"user_id"`         // 用户id
	UserNickname  string  `json:"user_nickname"`   // 用户昵称
	UserIconurl   string  `json:"user_iconurl"`    // 用户头像
	Sex           int     `json:"sex"`             // 性别
	UserRegTime   int64   `json:"user_reg_time"`   // 注册时间
	DeviceId      string  `json:"device_id"`       // 设备ID
	DeviceRegTime int64   `json:"device_reg_time"` // 设备注册时间
	Vip           int     `json:"vip"`             // VIP 等级
	GroupId       int64   `json:"group_id"`        // 公会ID
	Host          int     `json:"host"`            // 是否是主播(0 不是 1 是)
	Partner       int     `json:"partner"`         // 是否是陪练师 (0不是, 1是)
	Longitude     float32 `json:"longitude"`       // 经度
	Latitude      float32 `json:"latitude"`        // 纬度
	First         int     `json:"first"`           // 首充 是否首次充值(0没有,1充值)
	FinalQuantity int64   `json:"final_quantity"`  // 剩余go币 * 100
	Balance       int64   `json:"balance"`         // 剩余可提现余额
}

// 用户认证地址
type UserLiveAuthenticationUrlRep struct {
	Url string `json:"url"`
}
