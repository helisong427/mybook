package response

// 获取live_attr

type QueryAttrByAnchorRes struct {
	AttrID         int64    `json:"attr_id"`
	AttrName       string   `json:"attr_name"` // AttrName 属性名称
	AttrSort       int64    `json:"attr_sort"` // AttrSort 排序
	AttrDirections string   `json:"attr_directions"`
	AttrDemand     string   `json:"attr_demand"`
	AttrType       int      `json:"attr_type"` // 属性分类，0直播，1派对
	AttrBackground []string `json:"attr_background"`
}

type AnchorIncomeResp struct {
	UserId     int64  `json:"user_id" gorm:"column:gift_anchor_id"`
	Icon       string `json:"icon" gorm:"column:user_iconurl"`          // 用户头像
	Nickname   string `json:"nickname" gorm:"column:user_nickname"`     // 昵称
	Income     int64  `json:"income" gorm:"column:prop_anchor_income"`  //  订单收益
	IncomeTime int64  `gorm:"column:prop_give_time" json:"income_time"` // 订单结算(提取)时间
}

// 获取技能审核状态
type GetCheckInfoResp struct {
	ApplyTime      int64  `json:"apply_time" gorm:"column:created"`
	AttrID         int64  `json:"attr_id"`
	AttrName       string `json:"attr_name"` // AttrName 属性名称
	AttrDirections string `json:"attr_directions"`
	AttrDemand     string `json:"attr_demand"`
}
