package controller

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/controller/services/recommend"
	"gamers/models/dbmodels"
	"gamers/utils"
	"gamers/utils/tencent/facecore"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/tencentcloud/tencentcloud-sdk-go/tencentcloud/common/errors"
	"gorm.io/gorm"
)

// 获取大神技能管理信息
func GetSkillInfo(c *gin.Context) {
	var form request.GetSkillInfoReq
	err := c.ShouldBind(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	data, err := services.SparringDetailByUpdate(form.SkillSkillID)
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "技能不存在", "", err.Error())
			return
		}
		response.ResponseError(c, response.RESPONSE_UNKNOWN, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "ok", data)
	return

}

// 修改大神技能管理
func UpdateSparringServiceInfo(c *gin.Context) {
	userId := utils.FuncUserId(c)
	// 获取用户id
	form := request.UpdateSparringServiceReq{}
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	updateInfo := services.UpdateSparringServiceInfo(userId, form)
	if updateInfo.Finished {
		response.ResponseOk(c, "ok", "")
		return
	}

	response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, updateInfo.Msg, "", updateInfo.Err.Error())
	return
}

// 修改大神认证信息
func UpdateSparringVerificationInfo(c *gin.Context) {
	userId := utils.FuncUserId(c)
	// 获取用户id
	form := request.UpdateSparringVerificationReq{}
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	var sparringSkill dbmodels.AppSparringSkill
	// 判断是否存在此游戏的认证
	localsparring, err := sparringSkill.QueryByUserIdSkillId(userId, form.SparringSkillID)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前用户未认证此技能", "", "")
		return
	}

	if localsparring.SkillStatus != dbmodels.SPARRING_SKILL_STATUS_OK && localsparring.SkillStatus != dbmodels.SPARRING_SKILL_STATUS_OFF {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前技能状态禁止修改", "", "")
		return
	}
	param, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_SPARRING_SKILL_CHECK)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取审核时间有误", "", "")
		return
	}
	checkTime, _ := strconv.Atoi(param["value"])
	localsparring.SkillProveImage = form.SkillProveImage
	localsparring.SkillSound = form.SkillSound
	localsparring.SkillInfo = form.SkillInfo
	localsparring.SkillSoundTime = form.SkillSoundTime
	localsparring.SkillUserIconurl = form.SparringIconurl
	localsparring.SkillApplyTime = time.Now().Unix()
	localsparring.SkillStatus = dbmodels.SPARRING_SKILL_STATUS_INIT
	// 技能info处理
	var skill dbmodels.AppSkill
	skill, err = skill.QueryBySkillId(localsparring.SkillSkillID)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "技能不存在", "", "")
		return
	}

	// 校验必穿的skill
	val := form.SkillValues[skill.SkillRequiredField]
	if val == 0 {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "认证必填字段有误", "", "")
		return
	}

	filedValue, err := new(dbmodels.AppSkillFieldValue).GetAppSkillFieldByValueId(val)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", "")
		utils.LogErrorF("查询技能filed错误,err:%s", err.Error())
		return
	}
	if err != nil || filedValue.ValueField != skill.SkillRequiredField {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "认证必填字段有误", "", "")
		return
	}
	// 修改基本信息
	tx := utils.GEngine.Begin()
	err = localsparring.UpdateBaseInfo(tx)
	if err != nil {
		utils.LogErrorF("修改认证信息出错,err:%s", err.Error())
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "修改认证信息出错", "", "")
		return
	}
	infoId := int64(0)
	// 修改大神技能段位信息
	for _, k := range localsparring.AppSparringSkillInfo {
		if k.AppSkillFieldValue.ValueField == skill.SkillRequiredField {
			infoId = k.InfoId
			break
		}
	}
	if infoId == 0 {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "未查询到用户认证信息", "", "")
		tx.Rollback()
		return
	}
	err = new(dbmodels.AppSparringSkillInfo).UpdateSkillLevel(tx, infoId, filedValue.ValueId)
	if err != nil {
		utils.LogErrorF("修改必填字段出错,err:%s", err.Error())
		tx.Rollback()
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "修改认证字段出错", "", "")
		return
	}

	err = tx.Commit().Error

	if err != nil {
		utils.LogErrorF("修改认证信息出错,err:%s", err.Error())
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "修改认证信息出错", "", "")
		return
	}

	// 删除大神陪玩游戏 列表的缓存, 并 设置score表的delete为1
	if err = new(dbmodels.AppSparringSkillScore).UpdateBySparringId(form.SparringSkillID, map[string]interface{}{
		"deleted": time.Now().Unix(),
	}); err != nil {
		utils.LogErrorF("修改认证信息出错,err:%s", err.Error())
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "修改认证信息出错", "", "")
		return
	}

	// 删除推荐缓存
	go recommend.NewSparring().RemoveCache(form.SparringSkillID, localsparring.SkillSkillID)

	// 拼接info
	tip := utils.GenerateTips(checkTime)
	response.ResponseOk(c, "提交成功", tip)
	return
}

// 技能认证
func SparringSkill(gctx *gin.Context) {
	userId, _ := gctx.Get("userID")
	userIdInt64, _ := strconv.ParseInt(userId.(string), 10, 64)
	var form request.SparringSkillReq
	err := gctx.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	key := utils.REDIS_USER_SPARRING_LOCK + strconv.Itoa(int(userIdInt64))
	lock, islock := utils.AcquireLock(key, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
	if !islock {
		utils.LogErrorF("大神申请加锁失败")
		return
	}
	// 释放锁
	defer utils.ReleaseLock(key, lock)
	var sparring dbmodels.Certification
	data, err := sparring.VerificationByUserId(userIdInt64)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "当前账户未通过实名认证", "", "")
		return
	}
	param, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_SPARRING_SKILL_CHECK)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "获取审核时间有误", "", "")
		return
	}
	// 技能info处理
	var skill dbmodels.AppSkill
	skill, err = skill.QueryBySkillId(form.SkillID)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "技能不存在", "", "")
		return
	}
	checkTime, _ := strconv.Atoi(param["value"])
	sparringSkill := dbmodels.AppSparringSkill{
		SkillUserID:      data.CertificationId,
		SkillSkillID:     form.SkillID,
		SkillProveImage:  form.SkillProveImage,
		SkillSound:       form.SkillSound,
		SkillInfo:        form.SkillInfo,
		SkillSoundTime:   form.SkillSoundTime,
		SkillApplyTime:   time.Now().Unix(),
		SkillStatus:      dbmodels.SPARRING_SKILL_STATUS_INIT,
		SkillTitle:       skill.SkillName,
		SkillUserIconurl: form.SparringIconurl,
	}
	var update bool
	// 判断是否存在此游戏的认证
	localsparring, err := sparringSkill.QueryByUserIdSkillSkillId(userIdInt64, sparringSkill.SkillSkillID)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if err == nil && localsparring.SkillStatus != dbmodels.SPARRING_SKILL_STATUS_PASS {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "当前用户已认证此游戏", "", "")
		return
	}
	if err != nil {
		update = false
	} else {
		update = true
		sparringSkill.SkillID = localsparring.SkillID
		sparringSkill.BaseModel = localsparring.BaseModel
	}

	// 校验必穿的skill
	val := form.SkillValues[skill.SkillRequiredField]
	if val == 0 {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "认证必填字段有误", "", "")
		return
	}

	filedValue, err := new(dbmodels.AppSkillFieldValue).GetAppSkillFieldByValueId(val)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", "")
		utils.LogErrorF("查询技能filed错误,err:%s", err.Error())
		return
	}
	if err != nil || filedValue.ValueField != skill.SkillRequiredField {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "认证必填字段有误", "", "")
		return
	}
	// 拼接info
	skillInfo := dbmodels.AppSparringSkillInfo{
		InfoSkillId: skill.SkillId,
		InfoUserId:  userIdInt64,
		InfoValueId: filedValue.ValueId,
	}
	err = sparringSkill.SparringSkillCreateAction(sparringSkill, skillInfo, update)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "认证失败", "", err.Error())
		return
	}
	im := services.InitSparring()
	go im.Apply(skill, sparringSkill.SkillApplyTime+int64(checkTime), strconv.Itoa(int(userIdInt64)))
	// 获取审核时间
	tip := utils.GenerateTips(checkTime)
	response.ResponseOk(gctx, "提交成功", tip)
	return
}

// AI人脸识别接口
func SparringFaceVerification(gctx *gin.Context) {
	var form request.FaceVerificationReq
	err := gctx.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	res, err := facecore.FaceImage(&form.SparringIconurl)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, err.(*errors.TencentCloudSDKError).Message, "", err.(*errors.TencentCloudSDKError).Code)
		return
	}
	if len(res.Response.FaceInfos) != 1 {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "请上传清晰单人照", "", "")
		return
	}
	faceInfo := res.Response.FaceInfos[0]

	if *faceInfo.FaceAttributesInfo.EyeOpen != true {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "请不要闭眼", "", "")
		return
	}
	if *faceInfo.FaceQualityInfo.Sharpness < facecore.FACE_EXPRESSION {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "请上传清晰图片", "", "")
		return
	}
	if *faceInfo.FaceQualityInfo.Completeness.Chin > facecore.FCAE_DETECT_LEVEL &&
		*faceInfo.FaceQualityInfo.Completeness.Eye > facecore.FCAE_DETECT_LEVEL &&
		*faceInfo.FaceQualityInfo.Completeness.Cheek > facecore.FCAE_DETECT_LEVEL &&
		*faceInfo.FaceQualityInfo.Completeness.Eyebrow > facecore.FCAE_DETECT_LEVEL &&
		*faceInfo.FaceQualityInfo.Completeness.Mouth > facecore.FCAE_DETECT_LEVEL &&
		*faceInfo.FaceQualityInfo.Completeness.Nose > facecore.FCAE_DETECT_LEVEL {
		response.ResponseOk(gctx, "审核通过", nil)
		return
	}
	response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "审核未通过", "", "")
	return
}

// 获取大神历史icon
func SparringHistoryIcon(gctx *gin.Context) {
	userId, _ := gctx.Get("userID")
	userIdInt64, _ := strconv.ParseInt(userId.(string), 10, 64)
	var user dbmodels.SystemUser
	data, err := user.GetUserIconByUserId(userIdInt64)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(gctx, "ok", data)
	return
}

// 获取大神中心
func SparringCenter(c *gin.Context) {
	userId := utils.FuncUserId(c)
	data, err := services.GetSparringCenter(userId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "ok", data)
	return
}

// 获取大神收入明细
func SparringIncome(c *gin.Context) {
	userId := utils.FuncUserId(c)
	// 获取分页参数
	page, size, skip, err := utils.GetPageAndSize(c)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "分页参数错误", "", err.Error())
		return
	}
	total, result, err := new(dbmodels.AppSkillOrder).GetSparringIncomeRecord(userId, size, skip)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	data := response.BasePageList{
		Page:       page,
		Size:       size,
		Total:      total,
		TotalPages: utils.FuncTotalPages(total, size),
		List:       result,
	}
	if result == nil {
		data.List = []string{}
	}
	response.ResponseOk(c, "ok", data)
	return
}
