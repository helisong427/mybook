/**
 * @Author: panke
 * @Description: 撩一撩主动推送
 * @File: liaoyiliao_active_push
 * @Date: 2021/5/18 16:10
 */

package services

import (
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
)

const (
	LiaoyiLiaoActivePushFirstLogin = "liaoyiliao_active_push_first_login" // 撩一撩主动推送-首次登录
	LiaoyiLiaoActivePushNotFirst   = "liaoyiliao_active_push"             // 撩一撩主动推送
)

type LiaoyiLiaoActivePush struct{}

// 消息发送
func (m *LiaoyiLiaoActivePush) MsgSend(userInfo dbmodels.SystemUser, from string, target []string) error {

	key := dbmodels.AppMsgModel{}
	var err error
	if userInfo.UserIsFirstLogin == int64(dbmodels.USER_IS_FIRST_LOGIN) {
		key, err = new(dbmodels.AppMsgModel).GetMsgByKey(LiaoyiLiaoActivePushFirstLogin)
		if err != nil {
			utils.LogErrorF("获取消息模型失败:%s", err.Error())
			return err
		}
	} else if userInfo.UserIsFirstLogin == int64(dbmodels.USER_NOT_FIRST_LOGIN) {
		key, err = new(dbmodels.AppMsgModel).GetMsgByKey(LiaoyiLiaoActivePushNotFirst)
		if err != nil {
			utils.LogErrorF("获取消息模型失败:%s", err.Error())
			return err
		}
	}

	info := &redismodels.ActivePushUserInfo{
		UserId:   userInfo.UserID,
		Avatar:   userInfo.UserIconurl,
		NickName: userInfo.UserNickname,
		Gender:   userInfo.UserGender,
		Age:      utils.FuncGetAge(int(userInfo.UserBirthday)),
	}
	msg := redismodels.ActivePush{
		ActivePushUserInfo: info,
		MsgContent:         key.MsgContent,
	}
	err = msg.SendActivePush(from, target)
	if err != nil {
		utils.LogErrorF("[给大神发匹配系统消息]推送失败,ids:%v,err:%s", target, err.Error())
		return err
	}
	return nil
}
