package services

import (
	"fmt"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"strconv"
)

type PkMsg struct {
}

const (
	ASSISTANT_PK_RESULT_PUSH = "assistant_pk_result_push" // pk详情推送
)

// 推送pk结果
func (s PkMsg) SendPkResult(recordId int64, wheat *redismodels.Wheat) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_PK_RESULT_PUSH)
	if err != nil {
		utils.LogErrorF("获取pk[%d]结束推送消息model失败,err:%s", recordId, err.Error())
		return
	}
	fmt.Println(fmt.Sprintf("record_id:%d", recordId))
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_ACTION,
		ActionType:        redismodels.MSG_ACTION_TYPE_PK_RESULT,
		Action:            fmt.Sprintf("%d", recordId),
		Title:             msgModel.MsgTitle,
		Text:              msgModel.MsgContent,
		ActionParams:      map[string]interface{}{"record_id": recordId},
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	userIds := make([]string, 0)
	for _, v := range wheat.WheatObj {
		if v.UserId != 0 {
			idStr := strconv.Itoa(v.UserId)
			userIds = append(userIds, idStr)
		}
	}
	if len(userIds) < 1 {
		utils.LogErrorF("推送pk[%d]结束推送消息失败,无有效推送对象", recordId)
		return
	}
	err = msg.AssistantMsg.BatchSendAssistantMsg(userIds, redismodels.MSG_ADMIN_USER_ASSISTANT)
	if err != nil {
		utils.LogErrorF("推送pk[%d]结束推送消息失败,err:%s", recordId, err.Error())
	}
	return
}
