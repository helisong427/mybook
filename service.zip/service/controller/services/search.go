package services

import (
	"fmt"
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"sort"
	"strconv"
	"strings"
	"time"

	"gorm.io/gorm"
)

const (
	recommendTtl = time.Minute * 1
)

type UserSearchList []response.SearchResultsListUser

func (t UserSearchList) Len() int {
	return len(t)
}

func (s UserSearchList) Swap(i, j int) {
	s[i], s[j] = s[j], s[i]
}
func (t UserSearchList) Less(i, j int) bool {
	return t[i].UserPrettyId > t[j].UserPrettyId
}

type RoomSearchList []response.SearchRecommendRoom

func (t RoomSearchList) Len() int {
	return len(t)
}
func (s RoomSearchList) Swap(i, j int) {
	s[i], s[j] = s[j], s[i]
}
func (t RoomSearchList) Less(i, j int) bool {
	return t[i].RoomPrettyId > t[j].RoomPrettyId
}

//搜索结果列表
func SearchResultsList(paramsJSON request.SearchResultsListReq) (r response.SearchResultsListResp, err error) {
	userSize := paramsJSON.UserSize
	roomSize := paramsJSON.RoomSize
	//----------------------------
	//-------------用户列表---------
	//----------------------------
	userList := make(UserSearchList, 0)
	searchId, err := strconv.ParseInt(paramsJSON.SearchId, 10, 64)
	if err != nil {
		utils.LogErrorF("解析搜索id[%s]失败,err:%s", paramsJSON.SearchId, err.Error())
		return r, err
	}
	//只有请求第一页精准搜索用户
	if paramsJSON.UserPage == 1 && (paramsJSON.MoreType == 0 || paramsJSON.MoreType == 1) {
		//精准搜索一个用户
		preciseUser, err, isPretty := new(dbmodels.SystemUser).GetSearchInfoByUserId(searchId)
		if err != nil && err != gorm.ErrRecordNotFound {
			return r, err
		}
		if err == nil {
			if isPretty || preciseUser.UserPrettyId == 0 {
				//精准搜索到用户,需要的数量-1
				paramsJSON.UserSize = paramsJSON.UserSize - 1
				userList = append(userList, preciseUser)
			}
		}
	}
	if paramsJSON.MoreType == 0 || paramsJSON.MoreType == 1 {
		//模糊搜索用户
		total, data, err := new(dbmodels.SystemUser).QueryLikeByUserId(paramsJSON.UserPage, paramsJSON.UserSize, paramsJSON.SearchId)
		if err != nil && err != gorm.ErrRecordNotFound {
			return r, err
		}
		if len(data) > 0 {
			for _, v := range data {
				// 匹配是否在靓号中
				if strings.Contains(fmt.Sprintf("%d", v.UserPrettyId), paramsJSON.SearchId) {
					paramsJSON.UserSize -= 1
					total -= 1
					userList = append(userList, v)
				} else {
					total -= 1
					paramsJSON.UserSize -= 1
					if strings.Contains(fmt.Sprintf("%d", v.UserId), paramsJSON.SearchId) && v.UserPrettyId == 0 {
						userList = append(userList, v)
					}
				}
			}
		}
		sort.Sort(userList)
		r.UserList.List = userList
		r.UserList.Page = paramsJSON.UserPage
		r.UserList.Size = paramsJSON.UserSize
		r.UserList.Total = total
		r.UserList.TotalPages = utils.FuncTotalPages(total, userSize)
	}

	//----------------------------
	//-------------房间---------
	//----------------------------
	roomList := make(RoomSearchList, 0)
	//只有请求第一页精准搜索房间
	if paramsJSON.RoomPage == 1 && (paramsJSON.MoreType == 0 || paramsJSON.MoreType == 2) {
		preciseRoom, err, isPretty := new(dbmodels.AppLiveRoom).GetSearchInfoByRoomId(searchId)
		if err != nil && err != gorm.ErrRecordNotFound {
			return r, err
		}
		if err == nil {
			if isPretty || preciseRoom.RoomPrettyId == 0 {
				paramsJSON.RoomSize = paramsJSON.RoomSize - 1
				var hot int64
				hot = preciseRoom.RoomHeat
				//处理热度为负数
				if preciseRoom.RoomHeat < 0 {
					hot = 0
				}
				room := response.SearchRecommendRoom{
					RoomId:         preciseRoom.RoomId,
					RoomType:       preciseRoom.RoomType,
					RoomPrettyId:   preciseRoom.RoomPrettyId,
					RoomName:       preciseRoom.RoomName,
					RoomCover:      preciseRoom.RoomCover,
					RoomSpeakType:  preciseRoom.RoomSpeakType,
					RoomLiveStatus: preciseRoom.RoomLiveStatus,
					RoomAttrId:     preciseRoom.RoomAttrId,
					RoomAttrName:   preciseRoom.RoomLiveAttr.AttrName,
					Hot:            hot,
				}
				if preciseRoom.RoomPassword != "" {
					room.RoomIsPassword = 1
				}
				roomList = append(roomList, room)
			}
		}
	}

	if paramsJSON.MoreType == 0 || paramsJSON.MoreType == 2 {
		total, data, err := new(dbmodels.AppLiveRoom).QueryLikeRoomId(paramsJSON.RoomPage, paramsJSON.RoomSize, paramsJSON.SearchId)
		if err != nil && err != gorm.ErrRecordNotFound {
			return r, err
		}
		if len(data) > 0 {
			for _, v := range data {
				var hot int64
				hot = v.RoomHeat
				//处理热度为负数
				if v.RoomHeat < 0 {
					hot = 0
				}
				if strings.Contains(fmt.Sprintf("%d", v.RoomPrettyId), paramsJSON.SearchId) {
					total -= 1
					paramsJSON.RoomSize -= 1
					room := response.SearchRecommendRoom{
						RoomId:         v.RoomId,
						RoomPrettyId:   v.RoomPrettyId,
						RoomName:       v.RoomName,
						RoomType:       v.RoomType,
						RoomCover:      v.RoomCover,
						RoomSpeakType:  v.RoomSpeakType,
						RoomLiveStatus: v.RoomLiveStatus,
						RoomStatus:     v.RoomStatus,
						Hot:            hot,
						RoomAttrId:     v.RoomAttrId,
						RoomAttrName:   v.RoomLiveAttr.AttrName,
					}
					if v.RoomPassword != "" {
						room.RoomIsPassword = 1
					}
					roomList = append(roomList, room)
					continue
				} else {
					if strings.Contains(fmt.Sprintf("%d", v.RoomId), paramsJSON.SearchId) && v.RoomPrettyId == 0 {
						total -= 1
						paramsJSON.RoomSize -= 1
						room := response.SearchRecommendRoom{
							RoomId:         v.RoomId,
							RoomPrettyId:   v.RoomPrettyId,
							RoomName:       v.RoomName,
							RoomType:       v.RoomType,
							RoomCover:      v.RoomCover,
							RoomSpeakType:  v.RoomSpeakType,
							RoomLiveStatus: v.RoomLiveStatus,
							RoomStatus:     v.RoomStatus,
							Hot:            hot,
							RoomAttrId:     v.RoomAttrId,
							RoomAttrName:   v.RoomLiveAttr.AttrName,
							//AdminList:      adminList,
						}
						if v.RoomPassword != "" {
							room.RoomIsPassword = 1
						}
						roomList = append(roomList, room)
					}
				}
			}
		}
		sort.Sort(&roomList)
		r.RoomList.List = roomList
		r.RoomList.Page = paramsJSON.RoomPage
		r.RoomList.Size = paramsJSON.RoomSize
		r.RoomList.Total = total
		r.RoomList.TotalPages = utils.FuncTotalPages(total, roomSize)
	}

	return
}

//搜索推荐
func SearchRecommend(userId int64) (r response.SearchRecommendResp, err error) {
	//用户兴趣
	userInfo, err := new(redismodels.UserInfo).GetUserInfo(userId)
	if err != nil {
		return r, err
	}
	savor := strings.Split(userInfo.UserGameSavor, "_")
	sparringList, err := sparringComment(userId, savor, 5, 0)
	if err != nil {
		return r, err
	}
	if len(sparringList) == 0 {
		r.SparringList = []response.SearchRecommendSparring{}
	} else {
		r.SparringList = sparringList
	}

	roomList, err := roomComment(userId)
	if err != nil {
		return r, err
	}
	if len(roomList) == 0 {
		r.RoomList = []response.SearchRecommendRoom{}
	} else {
		sort.Sort(roomList)
		r.RoomList = roomList

	}
	return
}

//房间推荐
func roomComment(userId int64) (list RoomSearchList, err error) {
	ids, err := new(redismodels.RoomCommentUserZAddPosition).Get(userId)
	if err != nil {
		return list, err
	}
	data := []dbmodels.AppLiveRoom{}
	if len(ids) == 5 {
		tmpIds := make([]int, len(ids))
		for k, v := range ids {
			idToInt, _ := strconv.Atoi(v)
			tmpIds[k] = idToInt
		}
		data, err = new(dbmodels.AppLiveRoom).QueryNotPasswordRoomId(tmpIds)
	} else {
		data, err = new(dbmodels.AppLiveRoom).QueryRandNormalStatus(5)
	}
	if err != nil {
		return list, err
	}
	for _, v := range data {
		room := response.SearchRecommendRoom{
			RoomPrettyId:   v.RoomPrettyId,
			RoomId:         v.RoomId,
			RoomType:       v.RoomType,
			RoomCover:      v.RoomCover,
			RoomName:       v.RoomName,
			RoomSpeakType:  v.RoomSpeakType,
			RoomLiveStatus: v.RoomLiveStatus,
			RoomAttrId:     v.RoomAttrId,
			RoomAttrName:   v.RoomLiveAttr.AttrName,
			RoomStatus:     v.RoomStatus,
			Hot:            v.RoomHeat,
		}
		//处理热度为负数
		if room.Hot < 0 {
			room.Hot = 0
		}
		list = append(list, room)
	}
	return
}

//大神推荐
func sparringComment(userId int64, savor []string, number int, retry int) (list []response.SearchRecommendSparring, err error) {
	//递归最多重试1次
	if retry > 1 {
		return list, err
	}
	//查询缓存
	key := fmt.Sprintf("%s%d", utils.REDIS_INDEX_RECOMMEND_SPARRING, userId)
	redisClient := utils.RedisClient
	result := redisClient.HGetAll(key).Val()
	//已经推荐过的id
	commentIds := []int{}
	for k, _ := range result {
		toInt, _ := strconv.Atoi(k)
		commentIds = append(commentIds, toInt)
	}
	sparringData := []dbmodels.AppSparringSkill{}
	groupBy := " GROUP BY t1.skill_user_id "
	where := fmt.Sprintf("WHERE skill_status = %d", dbmodels.SPARRING_SKILL_STATUS_OK)
	if len(savor) > 0 {
		sparringData, err = new(dbmodels.AppSparringSkill).QueryByUserSavor(savor, commentIds)
	} else {
		and := fmt.Sprintf("AND skill_status = %d", dbmodels.SPARRING_SKILL_STATUS_OK)
		randData := []dbmodels.AppSparringSkill{}
		err = dbmodels.QueryRandIndex("skill_id", new(dbmodels.AppSparringSkill).TableName(), number, commentIds, where, and, groupBy, &randData)
		if err != nil && err != gorm.ErrRecordNotFound {
			return
		}
		for _, v := range randData {
			savor = append(savor, fmt.Sprintf("%d", v.SkillID))
		}
		sparringData, err = new(dbmodels.AppSparringSkill).QueryByUserSavor(savor, commentIds)
	}

	if err != nil && err != gorm.ErrRecordNotFound {
		return list, err
	}
	//不足5位大神，随机补充
	if len(sparringData) < number {
		notIn := []int{}
		for _, v := range sparringData {
			notIn = append(notIn, int(v.SkillID))
		}
		and := fmt.Sprintf("AND skill_status = %d", dbmodels.SPARRING_SKILL_STATUS_OK)
		randData := []dbmodels.AppSparringSkill{}
		err = dbmodels.QueryRandIndex("skill_id", new(dbmodels.AppSparringSkill).TableName(), number-len(sparringData), notIn, where, and, groupBy, &randData)
		if err != nil {
			return
		}

		randId := []int{}
		for _, v := range randData {
			randId = append(randId, int(v.SkillID))
		}

		addData, err := new(dbmodels.AppSparringSkill).QueryByIn(randId)
		if err != nil {
			return list, err
		}
		for _, v := range addData {
			sparringData = append(sparringData, v)
		}
	}

	if len(sparringData) < number && retry < 1 {
		//如果无数据可以推荐,删除之前的缓存,重新查询
		err = redisClient.Del(key).Err()
		if err != nil {
			return list, err
		}
		retry++
		return sparringComment(userId, savor, number, retry)
	}

	//大神推荐
	for _, v := range sparringData {
		s := response.SearchRecommendSparring{
			SparringId:   v.SkillID,
			SkillName:    v.AppSkill.SkillName,
			SkillType:    v.AppSkill.SkillType,
			UserId:       v.SystemUser.UserID,
			UserNickname: v.SystemUser.UserNickname,
			UserIconurl:  v.SystemUser.UserIconurl,
		}
		s.PriceWay, s.PricePrice = skillMinPrice(v)
		list = append(list, s)
		err = redisClient.HSet(key, fmt.Sprintf("%d", v.SkillID), 1).Err()
		if err != nil {
			return list, err
		}
	}

	//设置过期时间
	err = redisClient.Expire(key, recommendTtl).Err()
	if err != nil {
		return list, err
	}
	return
}

//获取技能最小单价
func skillMinPrice(sparringSkillData dbmodels.AppSparringSkill) (priceWay string, pricePrice int) {
	min := 0
	if len(sparringSkillData.AppSparringSkillPrice) == 0 {
		return
	}
	//最小单价id
	minId := sparringSkillData.AppSparringSkillPrice[0].PricePriceId
	//查询价格的最小id
	for k, v := range sparringSkillData.AppSparringSkillPrice {
		if v.PricePriceId < minId {
			minId = v.PricePriceId
			min = k
		}
	}
	//单价(局/天)
	priceWay = sparringSkillData.AppSparringSkillPrice[min].AppSkillPrice.PriceWay
	//价格(go币)
	pricePrice = int(sparringSkillData.AppSparringSkillPrice[min].PricePrice)
	return
}
