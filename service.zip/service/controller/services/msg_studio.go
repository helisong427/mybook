package services

import (
	"fmt"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"strconv"
	"strings"
	"time"

	"github.com/go-redis/redis"
)

// 直播间信息
const (
	ASSISTANT_STUDIO_BE_CHANGE  = "assistant_studio_be_change"  // 整改
	ASSISTANT_STUDIO_BE_CLOSED  = "assistant_studio_be_closed"  // 房间被关闭
	ASSISTANT_STUDIO_BE_OPEN    = "assistant_studio_be_open"    // 房间打开
	ASSISTANT_STUDIO_BE_BAN     = "assistant_studio_be_ban"     // 房间被封禁
	ASSISTANT_STUDIO_BE_RECTIFY = "assistant_studio_be_rectify" // 房间被整改
	ASSISTANT_LIVE_START_LIVE   = "assistant_live_start_live"   // 开始直播
)

// 开播消息,公屏消息
func (s LiveMsg) AnnounceLiveStart(liveRoom *dbmodels.AppLiveRoom) {
	msg := redismodels.LiveMsg{
		Type:        redismodels.MSG_TYPE_LIVE,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		CMD:         redismodels.CMD_TYPE_LIVE_UP,
		MsgStyle: &redismodels.MsgStyle{
			PrimaryColor: redismodels.MSG_STYLE_PRIMARYCOLOR_WHITE,
			SecondColor:  redismodels.MSG_STYLE_SECOND_YELLOW,
		},
		LiveInfo: &redismodels.LiveInfo{
			RoomId:          liveRoom.RoomId,
			RoomPrettyId:    liveRoom.RoomPrettyId,
			RoomType:        liveRoom.RoomType,
			RoomLiveStatus:  liveRoom.RoomLiveStatus,
			RoomUnionId:     liveRoom.RoomUnionId,
			RoomUserId:      liveRoom.RoomUserId,
			RoomSpeakType:   liveRoom.RoomSpeakType,
			RoomAttrId:      liveRoom.RoomAttrId,
			RoomPassword:    liveRoom.RoomPassword,
			RoomOpenIm:      liveRoom.RoomOpenIm,
			RoomEggbreakMsg: liveRoom.RoomEggbreakMsg,
			RoomName:        liveRoom.RoomName,
			RoomAttrName:    liveRoom.RoomLiveAttr.AttrName,
			RoomTitle:       liveRoom.RoomTitle,
			RoomCover:       liveRoom.RoomCover,
			RoomContent:     liveRoom.RoomContent,
			RoomBackground:  liveRoom.RoomBackground,
			RoomPkSwitch:    liveRoom.RoomPkSwitch,
		},
		Anchor: &redismodels.LiveAnchorInfo{
			UserID:       liveRoom.RoomUserId,
			UserIconurl:  liveRoom.SystemUser.UserIconurl,
			UserNickname: liveRoom.SystemUser.UserNickname,
		},
	}
	charm, err := utils.RedisClient.HGet(utils.REDIS_USER_INFO+strconv.Itoa(int(liveRoom.RoomUserId)), "UserCharm").Int()
	if err != nil && err != redis.Nil {
		utils.LogErrorF("连接redis获取用户[%d]的魅力值失败，err:%s", liveRoom.RoomUserId, err.Error())
	}
	wheat, err := new(redismodels.Wheat).QueryWheatDetail(int(liveRoom.RoomId))
	if err != nil {
		utils.LogErrorF("获取房间[%d]的麦位详情失败，err:%s", liveRoom.RoomId, err.Error())
	}
	msg.Wheat = &wheat
	msg.Anchor.TotalCharm = charm
	err = msg.SendLiveMsg(strconv.Itoa(int(liveRoom.RoomId)))
	if err != nil {
		utils.LogErrorF("发送开播消息失败,err:%s", err.Error())
	}
	return
}

// 开关爱意值
func (s LiveMsg) AnnounceSwitchLove(liveRoom *dbmodels.AppLiveRoom, wheat *redismodels.Wheat, _switch int) {
	msg := redismodels.LiveMsg{
		Type:        redismodels.MSG_TYPE_MIC,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		Wheat:       wheat,
	}
	if _switch == redismodels.WHEAT_LOVE_SWITCH_OPEN {
		msg.CMD = redismodels.CMD_TYPE_LIVE_LOVE_ON
	} else {
		msg.CMD = redismodels.CMD_TYPE_LIVE_LOVE_OFF
	}

	err := msg.SendLiveMsg(strconv.Itoa(int(liveRoom.RoomId)))
	if err != nil {
		utils.LogErrorF("发送开关爱意值推送失败,err:%s", err.Error())
	}
	return
}

// 下播
func (s LiveMsg) AnnounceConfirmDownload(liveRoom *dbmodels.AppLiveRoom, isCallbackOff bool) {
	msg := redismodels.LiveMsg{
		Type:        redismodels.MSG_TYPE_LIVE,
		ContentType: redismodels.CONTENT_TYPE_CMD,
	}
	// 是否回调关闭
	if isCallbackOff {
		msg.CMD = redismodels.CMD_TYPE_LIVE_CALLBACK_DOWN
	} else {
		msg.CMD = redismodels.CMD_TYPE_LIVE_DOWN
	}

	// 推荐直播间
	room, _ := new(dbmodels.AppLiveRoom).RandRoom()
	if len(room) > 0 {
		// 设置推荐直播间数据
		for _, v := range room {
			r := redismodels.LiveRecommend{
				RoomId:    v.RoomId,
				RoomType:  v.RoomType,
				RoomName:  v.RoomName,
				RoomCover: v.RoomCover,
			}
			msg.LiveRecommend = append(msg.LiveRecommend, r)
		}
	}
	wheat, err := new(redismodels.Wheat).QueryWheatDetail(int(liveRoom.RoomId))
	if err != nil {
		utils.LogErrorF("获取房间[%d]的麦位详情失败，err:%s", liveRoom.RoomId, err.Error())
	}
	msg.Wheat = &wheat
	err = msg.SendLiveMsg(strconv.Itoa(int(liveRoom.RoomId)))
	if err != nil {
		utils.LogErrorF("发送下播推送失败,err:%s", err.Error())
	}
	return
}

// 更新房间信息判断是否pk
func (s LiveMsg) AnnounceUpdateRoomSelectPkInfo(liveInfo *redismodels.LiveInfo, msg *redismodels.LiveMsg) {
	// 判断是否在pk中
	if liveInfo.RoomPkSwitch != dbmodels.RoomPkFunctionOpen {
		return
	}
	if liveInfo.RoomPkState == dbmodels.RoomPkCloseStage || liveInfo.RoomPkState == dbmodels.RoomPkReadyStage {
		return
	}
	pkInfo, err := new(redismodels.RoomPkDetail).GetRoomPkInfo(liveInfo.RoomId)
	if err != nil {
		utils.LogErrorF("获取房间[%d]pk信息失败,err:%s", liveInfo.RoomId, err.Error())
		return
	}
	msg.LiveInfo.RoomGloryStar = pkInfo.RoomPkDetailGloryStar
	msg.LiveInfo.RoomPKDetailRed = pkInfo.RoomPKDetailRed
	msg.LiveInfo.RoomPKDetailBlue = pkInfo.RoomPKDetailBlue
	msg.LiveInfo.RoomPKRemainingTime = pkInfo.RoomPKDetailExpectedEnd - time.Now().Unix()

}

// 更新房间信息
func (s LiveMsg) AnnounceUpdateRoom(liveInfo *redismodels.LiveInfo, anchor *redismodels.LiveAnchorInfo, userId int64) {
	msg := redismodels.LiveMsg{
		Type:        redismodels.MSG_TYPE_SETTING,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		CMD:         redismodels.CMD_TYPE_LIVE_UPDATE,
		LiveInfo:    liveInfo,
		Anchor:      anchor,
	}

	info, err := new(redismodels.MsgUserObj).GetMsgUserInfo(userId, map[string]bool{})
	if err != nil {
		utils.LogErrorF("发送更新房间信息推送失败,err:%s", err.Error())
		return
	}
	msg.FromAccount = &info
	// 查询麦位
	wheat, err := new(redismodels.Wheat).QueryWheatDetail(int(liveInfo.RoomId))
	if err != nil {
		utils.LogErrorF("获取房间[%d]的麦位详情失败，err:%s", liveInfo.RoomId, err.Error())
	}
	msg.Wheat = &wheat
	s.AnnounceUpdateRoomSelectPkInfo(liveInfo, &msg)
	err = msg.SendLiveMsg(strconv.Itoa(int(liveInfo.RoomId)))
	if err != nil {
		utils.LogErrorF("发送更新房间信息推送失败,err:%s", err.Error())
	}
	return
}

// 开启房间推送
func (s LiveMsg) AssistantStudioOpen(liveRoom *dbmodels.AppLiveRoom, nickname string) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_STUDIO_BE_OPEN)
	if err != nil {
		utils.LogErrorF("获取开启房间model失败,err:%s", err.Error())
		return
	}

	tip := strings.NewReplacer("${admin_name}", nickname).Replace(msgModel.MsgContent)
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	roomUserStr := strconv.Itoa(int(liveRoom.RoomUserId))
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, roomUserStr)
	if err != nil {
		utils.LogErrorF("发送开启房间推送失败,err:%s", err.Error())
	}
	return
}

// 禁封房间
func (s LiveMsg) AnnounceBanRoom(liveRoom *dbmodels.AppLiveRoom) {
	msg := redismodels.LiveMsg{
		Type:        redismodels.MSG_TYPE_STUDIO,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		CMD:         redismodels.CMD_TYPE_LIVE_BAN,
	}
	err := msg.SendLiveMsg(strconv.Itoa(int(liveRoom.RoomId)))
	if err != nil {
		utils.LogErrorF("发送禁封房间推送失败,err:%s", err.Error())
	}
	return
}

// 取消禁封房间
func (s LiveMsg) AnnounceBanRoomCancel(liveRoom *dbmodels.AppLiveRoom) {
	msg := redismodels.LiveMsg{
		Type:        redismodels.MSG_TYPE_STUDIO,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		CMD:         redismodels.CMD_TYPE_LIVE_BAN_CANCEL,
	}
	err := msg.SendLiveMsg(strconv.Itoa(int(liveRoom.RoomId)))
	if err != nil {
		utils.LogErrorF("发送取消禁封房间推送失败,err:%s", err.Error())
	}
	return
}

// 整改房间
func (s LiveMsg) AnnounceRectifyRoom(liveRoom *dbmodels.AppLiveRoom) {
	msg := redismodels.LiveMsg{
		Type:        redismodels.MSG_TYPE_STUDIO,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		CMD:         redismodels.CMD_TYPE_LIVE_RECTIFY,
	}
	err := msg.SendLiveMsg(strconv.Itoa(int(liveRoom.RoomId)))
	if err != nil {
		utils.LogErrorF("发送整改房间推送失败,err:%s", err.Error())
	}
	return
}

// 取消整改房间
func (s LiveMsg) AnnounceRectifyRoomCancel(liveRoom *dbmodels.AppLiveRoom) {
	msg := redismodels.LiveMsg{
		Type:        redismodels.MSG_TYPE_STUDIO,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		CMD:         redismodels.CMD_TYPE_LIVE_RECTIFY_CANCEL,
	}
	err := msg.SendLiveMsg(strconv.Itoa(int(liveRoom.RoomId)))
	if err != nil {
		utils.LogErrorF("发送整改房间推送失败,err:%s", err.Error())
	}
	return
}

// 进入直播间欢迎消息
func (s LiveMsg) JoinLiveMsg(liveRoom *dbmodels.AppLiveRoom, userInfo *redismodels.MsgUserObj) {
	var cmdObjs []*redismodels.MsgUserObj
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(redismodels.LIVE_KEY_COME_IN)
	if err != nil {
		utils.LogErrorF("获取进场消息model失败,err:%s", err.Error())
		return
	}
	cmdObjs = append(cmdObjs, userInfo)
	msg := redismodels.LiveMsg{
		Type:        redismodels.MSG_TYPE_COME_IN,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		CMD:         redismodels.CMD_TYPE_COME_IN,
		Content:     msgModel.MsgContent,
		Wheat:       &redismodels.Wheat{},
		CmdObjs:     cmdObjs,
		MsgStyle: &redismodels.MsgStyle{
			PrimaryColor: redismodels.MSG_STYLE_PRIMARYCOLOR_WHITE,
			SecondColor:  redismodels.MSG_STYLE_SECOND_YELLOW,
		},
	}
	roomIdStr := strconv.Itoa(int(liveRoom.RoomId))
	err = msg.SendLiveMsg(roomIdStr)
	if err != nil {
		utils.LogErrorF(fmt.Sprintf("发送欢迎语失败:%s", err.Error()))
	}
}

// 关闭房间
func (s LiveMsg) AnnounceStudioCloseAndOpen(liveRoom *dbmodels.AppLiveRoom, close bool) {
	msg := redismodels.LiveMsg{
		Type:        redismodels.MSG_TYPE_STUDIO,
		ContentType: redismodels.CONTENT_TYPE_CMD,
	}
	// 是否回调关闭
	if !close {
		msg.CMD = redismodels.CMD_TYPE_STUDIO_ON
	} else {
		msg.CMD = redismodels.CMD_TYPE_STUDIO_OFF
	}

	// 推荐直播间
	room, _ := new(dbmodels.AppLiveRoom).RandRoom()
	if len(room) > 0 {
		// 设置推荐直播间数据
		for _, v := range room {
			r := redismodels.LiveRecommend{
				RoomId:    v.RoomId,
				RoomType:  v.RoomType,
				RoomName:  v.RoomName,
				RoomCover: v.RoomCover,
			}
			msg.LiveRecommend = append(msg.LiveRecommend, r)
		}
	}
	err := msg.SendLiveMsg(strconv.Itoa(int(liveRoom.RoomId)))
	if err != nil {
		utils.LogErrorF("发送关闭房间推送失败,err:%s", err.Error())
	}
	return
}

// 关闭房间推送
func (s LiveMsg) AssistantStudioClose(liveRoom *dbmodels.AppLiveRoom, nickname string) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_STUDIO_BE_CLOSED)
	if err != nil {
		utils.LogErrorF("获取关闭房间model失败,err:%s", err.Error())
		return
	}

	tip := strings.NewReplacer("${admin_name}", nickname).Replace(msgModel.MsgContent)
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	roomUserStr := strconv.Itoa(int(liveRoom.RoomUserId))
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, roomUserStr)
	if err != nil {
		utils.LogErrorF("发送关闭房间推送失败,err:%s", err.Error())
	}
	return
}

// 整改房间推送助手消息
func (s LiveMsg) AssistantRectifyRoom(liveRoom *dbmodels.AppLiveRoom, reason string, endT int64) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_STUDIO_BE_CHANGE)
	if err != nil {
		utils.LogErrorF("获取整改房间model失败,err:%s", err.Error())
		return
	}

	tip := strings.NewReplacer("${change_reason}", reason, "${change_time_hour}", utils.MsgTimeFormatHour(endT)).Replace(msgModel.MsgContent)
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	roomUserStr := strconv.Itoa(int(liveRoom.RoomUserId))
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, roomUserStr)
	if err != nil {
		utils.LogErrorF("发送整改房间推送失败,err:%s", err.Error())
	}
	return
}
