package services

import (
	"encoding/json"
	"errors"
	"fmt"
	"gamers/controller/request"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"strconv"
	"sync"
	"time"

	"github.com/go-redis/redis"
)

type SendGift interface {
	CheckPropByNormal()
	CheckPropByBackpack()
}

type Gift struct {
}

func InitGift() Gift {
	return Gift{}
}

type CheckUserInfo struct {
	redismodels.MsgUserObj
	LoveValue int64
	Err       error `json:"err"`
}

type SendPropInfoToMq struct {
	SendPropReq *request.SendPropReq      `json:"send_prop_req"`
	LiveRoom    *dbmodels.AppLiveRoom     `json:"live_room"`
	Prop        *dbmodels.AppProp         `json:"prop"`
	Receivers   []*redismodels.MsgPropObj `json:"receivers"`
	SenderId    int64                     `json:"send_id"`
	SendTime    int64                     `json:"send_time"` // 送礼时间
	// LoveNum     int64                     `json:"love_num"`  //
}

// 赠送礼物返回结构
type SendPropResp struct {
	UserOver int64                     `json:"user_over"`
	PropInfo []*redismodels.MsgPropObj `json:"prop_info"`
}

type RespMsgInfo struct {
	ERR error  `json:"err"`
	Msg string `json:"msg"`
}

func (s SendPropInfoToMq) PushMq() {
	topic := "GIFT"
	data, err := json.Marshal(s)
	if err != nil {
		utils.LogErrorF("推送消息到topic[%s]失败，err：%s", topic, err.Error())
		return
	}
	err = utils.KafkaSendMsg(topic, utils.FuncGenerateDataId(), data)
	if err != nil {
		utils.LogErrorF("推送消息到topic[%s]失败，err：%s", topic, err.Error())
		return
	}
	fmt.Println("消息推送到kafka成功")
	return
}

// 校验用户id是否合法
func CheckUserId(wg *sync.WaitGroup, roomId, userId int64, errInfo chan CheckUserInfo, love int) {
	defer wg.Done()
	user, err := new(redismodels.MsgUserObj).GetMsgUserInfo(userId, map[string]bool{})
	checkInfo := CheckUserInfo{}
	if err != nil {
		checkInfo.Err = err
		errInfo <- checkInfo
		return
	}
	// 如果缓存没有，查询db
	if user.UserId != userId {
		userInfo, err := new(dbmodels.SystemUser).UserIdByUser(userId)
		if err != nil {
			checkInfo.Err = err
			errInfo <- checkInfo
			return
		}
		if userInfo.BaseModel.Deleted != 0 {
			checkInfo.Err = errors.New("用户已注销")
			errInfo <- checkInfo
			return
		}
		user.UserId = userInfo.UserID
		user.UserPrettyId = userInfo.UserPrettyId
		user.NickName = userInfo.UserNickname
		user.Gender = userInfo.UserGender
	}
	if love >= redismodels.WHEAT_LOVE_SWITCH_OPEN {
		roomIdStr := strconv.Itoa(int(roomId))
		userIdStr := strconv.Itoa(int(userId))
		LoveValue, err := utils.RedisClient.HGet(utils.REDIS_LIVE_WHEAT_LOVE+roomIdStr, userIdStr).Int64()
		if err != nil && err != redis.Nil {
			checkInfo.Err = err
			errInfo <- checkInfo
			return
		}
		checkInfo.LoveValue = LoveValue
		if err == redis.Nil {
			checkInfo.LoveValue = 0
		}
	}
	checkInfo.MsgUserObj = user
	errInfo <- checkInfo
	return
}

// 校验用户信息
func (g Gift) ValidateReceiver(form *request.SendPropReq, loveSwitch int, prop *dbmodels.AppProp) (data []*redismodels.MsgPropObj, err error) {
	// 校验接收人员信息
	wg := sync.WaitGroup{}
	finished := make(chan bool, 1)
	errChan := make(chan CheckUserInfo, len(form.ReceiverIDS))
	for _, id := range form.ReceiverIDS {
		wg.Add(1)
		go CheckUserId(&wg, form.RoomId, id, errChan, loveSwitch)
	}
	go func() {
		wg.Wait()
		close(errChan)
		close(finished)
	}()
	var errIds []int64
	select {
	case <-finished:
		for m := range errChan {
			if m.Err != nil {
				errIds = append(errIds, m.UserId)
				break
			}
			addValue := prop.PropCharm * form.PropCount
			var wObj = &redismodels.MsgPropObj{
				UserInfo: m.MsgUserObj,
				Position: -1,
				PropInfo: redismodels.PropInfo{
					PropCount: form.PropCount, PropType: prop.PropType,
					PropClass: prop.PropClass, PropId: prop.PropId,
					PropAddIcon: prop.PropAddIcon, PropAttrId: prop.PropAttrId,
					PropLevel: prop.PropLevel, PropName: prop.PropName,
					PropSpecialLevel: prop.PropSpecialLevel, PropUrl: prop.PropUrl,
					PropIcon: prop.PropIcon,
				},
				FromAccountWealth: prop.PropWealth * form.PropCount * int64(len(form.ReceiverIDS)),
				LoveValue:         m.LoveValue,
			}
			if loveSwitch == redismodels.WHEAT_LOVE_SWITCH_OPEN {
				wObj.AddLoveValue = addValue
				wObj.LoveValue = m.LoveValue + addValue
			}
			data = append(data, wObj)
		}
		if len(errIds) > 0 {
			errStr := fmt.Sprintf("校验id:%v有误", errIds)
			utils.LogErrorF(errStr)
			err = errors.New(errStr)
			return
		}
	}
	return
}

// 校验普通礼物
func (g Gift) CheckPropByNormal(form *request.SendPropReq, userInfo *redismodels.MsgUserObj) (prop *dbmodels.AppProp, msg RespMsgInfo) {
	// 查询道具
	prop, msg.ERR = new(dbmodels.AppProp).GetPropConfigById(form.PropId)
	if msg.ERR != nil {
		return
	}
	// 判断道具类型
	if prop.PropType != dbmodels.DB_PROP_TYPE_GIFT {
		msg.ERR = errors.New("道具类型有误")
		msg.Msg = "道具类型有误"
		return
	}
	if prop.PropVipLevel > userInfo.VipLevel {
		msg.ERR = errors.New("vip等级不足")
		msg.Msg = "vip等级不足,请消费提升等级哦"
		return
	}
	if prop.PropClass == dbmodels.DB_CLASS_FREE {
		if len(form.ReceiverIDS) > 1 || form.PropCount > 1 {
			msg.ERR = errors.New("免费道具只能赠送一个哦")
			msg.Msg = "免费道具只能赠送一个哦"
			return
		}
	} else {
		amount := prop.PropPrice * int64(len(form.ReceiverIDS)) * form.PropCount
		if userInfo.UserOver < amount {
			msg.ERR = errors.New("余额不足")
			msg.Msg = "余额不足"
			return
		}
	}
	return
}

// 校验背包礼物
func (g Gift) CheckPropByBackpack(userId int64, form *request.SendPropReq) (backpack dbmodels.AppBackpack, msg RespMsgInfo) {
	// 查询道具
	backpack, msg.ERR = new(dbmodels.AppBackpack).GetBackPackById(userId, form.BackpackId)
	if msg.ERR != nil {
		return
	}
	if backpack.BackpackCount < 1 || backpack.BackpackCount < int64(len(form.ReceiverIDS))*form.PropCount {
		msg.ERR = errors.New("背包余额不足")
		msg.Msg = "背包余额不足"
		_ = new(dbmodels.AppBackpack).DelCache(userId, form.BackpackId)
		return
	}
	if backpack.BackpackPropType != dbmodels.DB_PROP_TYPE_GIFT {
		msg.ERR = errors.New("背包道具有误")
		msg.Msg = "背包道具有误"
		return
	}
	if backpack.BackpackExpiredTime != 0 {
		if backpack.BackpackExpiredTime < time.Now().Unix() {
			_ = new(dbmodels.AppBackpack).DelCache(userId, form.BackpackId)
			msg.ERR = errors.New("背包道具已过期")
			msg.Msg = "背包道具已过期"
			return
		}
	}
	return
}

// 赠送背包礼物
func (g Gift) SendByBackpackProp(userInfo *redismodels.MsgUserObj, backpack *dbmodels.AppBackpack, form *request.SendPropReq, room *dbmodels.AppLiveRoom, whs []*redismodels.MsgPropObj) (msg RespMsgInfo) {
	tx := utils.GEngine.Begin()
	backpackIdStr := strconv.Itoa(int(backpack.BackpackId))
	userIdStr := strconv.Itoa(int(userInfo.UserId))
	amount := backpack.AppProp.PropPrice * form.PropCount
	now := time.Now().Unix()
	var records []*dbmodels.AppAnchorRoomProp
	// 插入礼物流水表
	for _, v := range whs {
		commission, err := new(dbmodels.AppUserUnionCommission).GetCommissionByUserIdAndType(v.UserInfo.UserId, v.UserInfo.UserUnionId, dbmodels.COMMISSION_TYPE_GIFT, backpack.AppProp.PropLevel)
		if err != nil {
			msg.ERR = err
			msg.Msg = "查询分成比例失败"
			return
		}
		// 主播收入
		income := amount * commission.CommissionUser / 100
		// 公会扣除
		unionFee := amount * commission.CommissionUnion / 100
		record := &dbmodels.AppAnchorRoomProp{
			PropUserId:         userInfo.UserId,
			PropRoomId:         form.RoomId,
			PropUnionIncome:    unionFee,
			PropRoomType:       room.RoomType,
			PropAnchorId:       v.UserInfo.UserId,
			PropPropId:         backpack.AppProp.PropId,
			PropPropPrice:      backpack.AppProp.PropPrice,
			PropRoomAttrId:     room.RoomAttrId,
			PropPropCount:      form.PropCount,
			PropPropCharm:      form.PropCount * backpack.AppProp.PropCharm,
			PropPropWealth:     form.PropCount * backpack.AppProp.PropWealth,
			PropPlatformIncome: amount - unionFee - income,
			PropAnchorIncome:   income,
			PropLogId:          room.RoomLogId,
			PropAnchorUnionId:  v.UserInfo.UserUnionId,
			PropGiveTime:       now,
			PropRoomUnionId:    room.RoomUnionId,
			PropIncome:         amount,
			PropPropSource:     dbmodels.PROP_SOURCE_BACKPACK,
		}
		v.UserIncome = income
		v.UnionIncome = unionFee
		records = append(records, record)
	}
	// 创建收礼明细
	err := new(dbmodels.AppAnchorRoomProp).CreateGiftAnchorAction(tx, records)
	if err != nil {
		utils.LogErrorF("创建收礼记录失败，err:%s", err.Error())
		tx.Rollback()
		msg.ERR = err
		msg.Msg = "服务器错误"
		return
	}
	data, err := new(dbmodels.AppBackpack).UpdateBackpackCount(tx, backpack.BackpackId, false, form.PropCount*int64(len(form.ReceiverIDS)))
	if err != nil {
		utils.LogErrorF("减少背包库存失败，err:%s", err.Error())
		tx.Rollback()
		msg.ERR = err
		msg.Msg = "服务器错误"
		return
	}
	err = tx.Commit().Error
	if err != nil {
		tx.Rollback()
		return
	}
	backpack.BackpackCount = data.BackpackCount
	err = utils.RedisClient.HSet(utils.REDIS_LIVE_GIFT_BACKPACK+userIdStr, backpackIdStr, backpack).Err()
	if err != nil {
		msg.ERR = err
		msg.Msg = "服务器错误"
		return
	}
	return
}

// 赠送普通礼物
func (g Gift) SendByNormalProp(userInfo *redismodels.MsgUserObj, prop *dbmodels.AppProp, form *request.SendPropReq, room *dbmodels.AppLiveRoom, whs []*redismodels.MsgPropObj) (over int64, msg RespMsgInfo) {
	tx := utils.GEngine.Begin()
	rtx := utils.RedisClient.TxPipeline()
	var amount int64
	// 金额
	totalAmount := prop.PropPrice * int64(len(form.ReceiverIDS)) * form.PropCount
	amount = prop.PropPrice * form.PropCount
	// 免费礼物
	if prop.PropClass == dbmodels.DB_CLASS_FREE {
		key := utils.REDIS_LIVE_USER_FREE_GIFT + strconv.Itoa(int(userInfo.UserId)) + ":" + strconv.Itoa(int(prop.PropId))
		over = userInfo.UserOver
		giftNum, err := utils.RedisClient.Get(key).Int64()
		if err != nil && err != redis.Nil {
			msg.ERR = err
			msg.Msg = "服务器错误"
			return
		}
		// 如果有记录,判断是否到达
		if err == nil {
			if giftNum >= prop.PropGetMax {
				err = errors.New("今日免费礼物已达上限")
				msg.ERR = err
				msg.Msg = "今日免费礼物已达上限"
				return
			}
			// 如果没到达阈值，则加1
			err = utils.RedisClient.Incr(key).Err()
			if err != nil {
				msg.ERR = err
				msg.Msg = "服务器错误"
				return
			}
		} else {
			// 如果没记录，设置值
			expired := utils.GetExpiredByDay()
			err = utils.RedisClient.Set(key, 1, expired).Err()
			if err != nil {
				return userInfo.UserOver, msg
			}
		}
	} else {
		// 扣钱加锁
		key := utils.REDIS_USER_WALLET_LOCK + strconv.Itoa(int(userInfo.UserId))
		lock, isLock := utils.AcquireLock(key, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
		if !isLock {
			err := errors.New("送礼加锁失败")
			msg.ERR = err
			msg.Msg = "服务器错误"
			return
		}
		// 释放锁
		defer utils.ReleaseLock(key, lock)
		// 扣用户钱
		wallet, err := new(dbmodels.AppUserWallet).UpdateWalletTotalOver(tx, userInfo.UserId, false, false, totalAmount)
		if err != nil {
			utils.LogErrorF("更新用户[%d]余额失败, %s", userInfo.UserId, err.Error())
			tx.Rollback()
			msg.ERR = err
			msg.Msg = "服务器错误"
			return
		}
		over = wallet.WalletTotalOver
		err = rtx.HSet(utils.REDIS_USER_INFO+strconv.Itoa(int(userInfo.UserId)), "WalletTotalOver", over).Err()
		if err != nil {
			tx.Rollback()
			utils.LogErrorF("更新redis用户[%d]余额失败, %s", userInfo.UserId, err.Error())
			msg.ERR = err
			msg.Msg = "服务器错误"
			return
		}
	}
	now := time.Now().Unix()
	var records []*dbmodels.AppAnchorRoomProp
	// 插入礼物流水表
	for _, v := range whs {
		commission, err := new(dbmodels.AppUserUnionCommission).GetCommissionByUserIdAndType(v.UserInfo.UserId, v.UserInfo.UserUnionId, dbmodels.COMMISSION_TYPE_GIFT, prop.PropLevel)
		if err != nil {
			msg.ERR = err
			msg.Msg = "查询分成比例失败"
			return
		}
		// 主播收入
		income := amount * commission.CommissionUser / 100
		// 公会扣除
		unionFee := amount * commission.CommissionUnion / 100
		v.UserIncome = income
		v.UnionIncome = unionFee
		record := &dbmodels.AppAnchorRoomProp{
			PropUserId:         userInfo.UserId,
			PropRoomId:         form.RoomId,
			PropUnionIncome:    unionFee,
			PropRoomType:       room.RoomType,
			PropAnchorId:       v.UserInfo.UserId,
			PropPropId:         prop.PropId,
			PropPropPrice:      prop.PropPrice,
			PropRoomAttrId:     room.RoomAttrId,
			PropPropCount:      form.PropCount,
			PropPropCharm:      form.PropCount * prop.PropCharm,
			PropPropWealth:     form.PropCount * prop.PropWealth,
			PropPlatformIncome: amount - unionFee - income,
			PropAnchorIncome:   income,
			PropLogId:          room.RoomLogId,
			PropAnchorUnionId:  v.UserInfo.UserUnionId,
			PropGiveTime:       now,
			PropRoomUnionId:    room.RoomUnionId,
			PropIncome:         amount,
			PropPropSource:     dbmodels.PROP_SOURCE_BUY,
		}
		records = append(records, record)
	}
	// 创建收礼明细
	err := new(dbmodels.AppAnchorRoomProp).CreateGiftAnchorAction(tx, records)
	if err != nil {
		utils.LogErrorF("创建收礼记录失败，err:%s", err.Error())
		tx.Rollback()
		msg.ERR = err
		msg.Msg = "服务器错误"
		return
	}
	err = tx.Commit().Error
	if err != nil {
		msg.ERR = err
		msg.Msg = "服务器错误"
		return
	}
	_, err = rtx.Exec()
	if err != nil {
		msg.ERR = err
		msg.Msg = "服务器错误"
		return
	}
	// 收费礼物
	return
}
