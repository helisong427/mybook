package services

import (
	"encoding/json"
	"errors"
	"fmt"
	"strconv"
	"time"

	"gorm.io/gorm"

	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/models/dbmodels"
	"gamers/utils"
	"gamers/utils/meichai"
)

// 提现主页
func WithdrawHome(userId int64) (r response.WithdrawHomeRep, err error) {
	// 用户可提现金额
	userWallet, err := new(dbmodels.AppUserWallet).Query(userId)
	if err != nil {
		return r, err
	}
	r.WithdrawAmount = userWallet.WalletTotalExtractable

	// 是否实名认证
	certificationData, err := new(dbmodels.Certification).VerificationByUserId(userId)
	if err != nil {
		if err != gorm.ErrRecordNotFound {
			return r, err
		}
	} else {
		if certificationData.CertificationStatus == dbmodels.CERTIFICATION_STATUS_OK {
			r.IsRealName = 1
			r.RealName = certificationData.CertificationRealName
			if certificationData.CertificationLivingStatus == dbmodels.CERTIFICATION_STATUS_LIVING_YES {
				r.IsLiving = 1
			}
		}
	}

	// 查询账户信息
	_, data, err := new(dbmodels.AppUserBankcard).QueryAll(userId)
	if err != nil && err != gorm.ErrRecordNotFound {
		return r, err
	}
	bankcard := make([]response.WithdrawBankcard, 0, len(data))
	for _, v := range data {
		info := dbmodels.BankcardAccountInfo{}
		if json.Unmarshal([]byte(v.BankcardAccountInfo), &info) == nil {
			bankcard = append(bankcard, response.WithdrawBankcard{
				BankcardId:          v.BankcardId,
				BankcardAccountType: v.BankcardAccountType,
				BankcardAccountInfo: info,
				BankcardDefault:     v.BankcardDefault,
			})
		}
	}
	r.WithdrawBankcard = bankcard

	// 查询是否有提现中金额
	drawRow, _, err := new(dbmodels.AppTransaction).QueryOngoingWithDraw(userId)
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	if drawRow == 1 {
		r.IsWithdrawIng = 1
	}
	return r, nil
}

// 提现绑定前检查
func withdrawBindCheckBefore(userId int64) (msg string, certificationData dbmodels.Certification, err error) {
	msg = "服务器错误"
	certificationData, err = new(dbmodels.Certification).QueryByUserId(userId)
	if err != nil {
		if err != gorm.ErrRecordNotFound {
			return
		}
	} else {
		if certificationData.CertificationStatus != dbmodels.CERTIFICATION_STATUS_OK {
			msg = "未实名认证"
			err = errors.New(msg)
			return
		}
		if certificationData.CertificationLivingStatus != dbmodels.CERTIFICATION_STATUS_LIVING_YES {
			msg = "未活体认证"
			err = errors.New(msg)
			return
		}
	}
	return
}

// 提现绑定银行卡
func WithdrawBindBankCard(userId int64, paramsJSON request.WithdrawBindBankCardReq) (msg string, err error) {
	msg, certificationData, err := withdrawBindCheckBefore(userId)
	if err != nil {
		return msg, err
	}
	msg = "绑定失败"

	channel, err := new(dbmodels.AppTransactionChannel).QueryKey(dbmodels.TRANSACTION_CHANNEL_KEY_MEICAI)
	if err != nil {
		msg = "美差信息错误"
		return msg, err
	}
	meicaiParam := dbmodels.ChannelMeiCaiParam{}
	err = json.Unmarshal([]byte(channel["param"]), &meicaiParam)
	if err != nil {
		msg = "美差信息错误"
		return msg, err
	}

	err = meichai.New(meicaiParam.Url, meicaiParam.PrivateKey, meicaiParam.MerchantId, meicaiParam.MerchantName).
		BankCardVerify(certificationData.CertificationRealName, certificationData.CertificationIdCode, paramsJSON.Card)
	if err != nil {
		msg = "请检查身份证和银行卡是否匹配"
		return msg, err
	}
	if !utils.FuncVerifyMobile(paramsJSON.Mobile) {
		msg = "手机号非法"
		err = errors.New(msg)
		return msg, err
	}

	// 银行卡详情
	info := dbmodels.BankcardAccountInfo{
		Mobile:   paramsJSON.Mobile,
		Realname: certificationData.CertificationRealName,
		Card:     paramsJSON.Card,
		Banck:    paramsJSON.BankCardName,
		IdCard:   certificationData.CertificationIdCode,
	}
	marshal, _ := json.Marshal(info)

	// 查询是否重复绑定
	row, data, err := new(dbmodels.AppUserBankcard).QueryFirstByType(userId, dbmodels.BANKCARD_ACCOUNT_TYPE_CARD)
	if err != nil && err != gorm.ErrRecordNotFound {
		return msg, err
	}

	// 编辑
	if paramsJSON.Action == 0 {
		if row == 0 {
			msg = "银行卡信息不存在"
			err = errors.New(msg)
			return msg, err
		}
		update := make(map[string]interface{})
		update["bankcard_account_info"] = marshal
		err = new(dbmodels.AppUserBankcard).Update(data.BankcardId, update)
	} else {
		// 增加
		if row == 1 {
			msg = "请勿重复绑定"
			err = errors.New(msg)
			return msg, err
		}
		// 设置信息
		model := dbmodels.AppUserBankcard{
			BankcardUserId:      userId,
			BankcardAccountType: dbmodels.BANKCARD_ACCOUNT_TYPE_CARD,
			BankcardAccountInfo: string(marshal),
			BankcardDefault:     0,
		}
		err = model.Create()
	}
	return "", nil
}

// 提现绑定支付宝
func WithdrawBindAlipay(userId int64, paramsJSON request.WithdrawBindAlipayReq) (msg string, err error) {
	msg, certificationData, err := withdrawBindCheckBefore(userId)
	if err != nil {
		return msg, err
	}
	msg = "绑定失败"

	channel, err := new(dbmodels.AppTransactionChannel).QueryKey(dbmodels.TRANSACTION_CHANNEL_KEY_MEICAI)
	if err != nil {
		msg = "美差信息错误"
		return msg, err
	}
	meicaiParam := dbmodels.ChannelMeiCaiParam{}
	err = json.Unmarshal([]byte(channel["param"]), &meicaiParam)
	if err != nil {
		msg = "美差信息错误"
		return msg, err
	}

	err = meichai.New(meicaiParam.Url, meicaiParam.PrivateKey, meicaiParam.MerchantId, meicaiParam.MerchantName).
		AlipayCardVerify(
			certificationData.CertificationRealName,
			certificationData.CertificationIdCode,
			paramsJSON.Alipay,
			paramsJSON.Alipay,
		)
	if err != nil {
		msg = "请检查姓名和支付宝是否匹配"
		return msg, err
	}

	// 查询是否重复绑定
	row, data, err := new(dbmodels.AppUserBankcard).QueryFirstByType(userId, dbmodels.BANKCARD_ACCOUNT_TYPE_ALIPAY)
	if err != nil && err != gorm.ErrRecordNotFound {
		return msg, err
	}

	info := dbmodels.BankcardAccountInfo{
		Realname: certificationData.CertificationRealName,
		Alipay:   paramsJSON.Alipay,
		IdCard:   certificationData.CertificationIdCode,
	}
	marshal, _ := json.Marshal(info)

	if paramsJSON.Action == 0 {
		// 编辑
		if row == 0 {
			msg = "支付宝信息不存在"
			err = errors.New(msg)
			return msg, err
		}
		update := make(map[string]interface{})
		update["bankcard_account_info"] = marshal
		err = new(dbmodels.AppUserBankcard).Update(data.BankcardId, update)
	} else {
		// 增加
		if row == 1 {
			msg = "请勿重复绑定"
			err = errors.New(msg)
			return msg, err
		}
		// 设置信息
		model := dbmodels.AppUserBankcard{
			BankcardUserId:      userId,
			BankcardAccountType: dbmodels.BANKCARD_ACCOUNT_TYPE_ALIPAY,
			BankcardAccountInfo: string(marshal),
			BankcardDefault:     0,
		}
		err = model.Create()
	}
	return "", nil
}

// 提交提现申请
func WithdrawSubmit(userId int64, paramsJSON request.WithdrawSubmitReq) (msg string, err error) {
	// 金额转换
	withdrawCash := paramsJSON.WithdrawAmount / 10
	key := fmt.Sprintf("%s%d", utils.REDIS_USER_WALLET_LOCK, userId)
	lock, islock := utils.AcquireLock(key, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
	if !islock {
		msg = "请稍后再试"
		err = errors.New(msg)
		return msg, err
	}
	// 释放锁
	defer utils.ReleaseLock(key, lock)

	msg, certificationData, err := withdrawBindCheckBefore(userId)
	if err != nil {
		return msg, err
	}
	msg = "提现失败"
	params, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_WITHDRAW_RULE)
	if err != nil {
		return
	}
	ruleParams := dbmodels.WithdrawRuleParams{}
	err = json.Unmarshal([]byte(params["value"]), &ruleParams)
	if err != nil {
		return
	}
	// 今日是否提现日期
	today := time.Now().Weekday().String()
	if _, ok := ruleParams.WithdrawalDate[today]; !ok {
		msg = "不在提现日期"
		err = errors.New(msg)
		return
	}

	// 每个人在同一时间只能提交一笔提现申请
	drawRow, drawData, err := new(dbmodels.AppTransaction).QueryOngoingWithDraw(userId)
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	if drawRow == 1 {
		// 小于等于2天
		twoDay := time.Unix(drawData.Created, 0).AddDate(0, 0, 2)
		if twoDay.Unix() > time.Now().Unix() {
			msg = fmt.Sprintf(
				"您于%s提交的提现正在审核中,预计审核结束时间%s", time.Unix(drawData.Created, 0).Format("2006.01.02"), twoDay.Format("2006.01.02"),
			)
		} else {
			msg = "请联系客服"
		}
		err = errors.New(msg)
		return
	}

	// 提现金额最小值
	if withdrawCash < ruleParams.SingleMin {
		msg = fmt.Sprintf("提现金额不能小于%s元", fmt.Sprintf("%.2f", float64(ruleParams.SingleMin)/100))
		err = errors.New(msg)
		return
	}

	// 提现金额最大值
	if withdrawCash > ruleParams.SingleMax {
		msg = fmt.Sprintf("提现金额不能大于%s元", fmt.Sprintf("%.2f", float64(ruleParams.SingleMax)/100))
		err = errors.New(msg)
		return
	}

	// 查询提现账户
	row, data, err := new(dbmodels.AppUserBankcard).QueryFirstById(paramsJSON.BankcardId)
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	if row == 0 {
		err = errors.New("提现账户不存在")
		return
	}
	// 查询用户可提现余额
	userWallet, err := new(dbmodels.AppUserWallet).Query(userId)
	if err != nil {
		return
	}
	if paramsJSON.WithdrawAmount > userWallet.WalletTotalExtractable {
		err = errors.New("余额不足")
		return
	}
	// 查询本月提现总金额
	withdrawal, err := new(dbmodels.AppIdCardWithdrawal).QueryMonthFirst(certificationData.CertificationIdCode)
	if err != nil && err != gorm.ErrRecordNotFound {
		err = errors.New("服务器错误,请联系客服!")
		return
	}
	withdrawalAmount := make(map[uint64]uint64)
	if len(withdrawal) > 0 {
		for _, v := range withdrawal {
			withdrawalAmount[v.WithdrawalChannelId] = v.WithdrawalAmount
		}
	}

	// 交易渠道id
	var channelId uint64 = 0
	// 不需要客户接入
	needCustomer := 0
	// 平台手续费比例
	var platformFee float64 = 0
	// 第三方手续费比例
	var thirdFee float64 = 0

	// 检查用户提现渠道
	if certificationData.CertificationMeicaiSignup == 1 { // 签约了美差
		channelId, needCustomer, platformFee, thirdFee = getChannelInfo(dbmodels.TRANSACTION_CHANNEL_KEY_MEICAI, uint64(withdrawCash), withdrawalAmount)
	}

	if channelId == 0 && certificationData.CertificationYunyifuSignup == 1 { // 签约了云易付
		channelId, needCustomer, platformFee, thirdFee = getChannelInfo(dbmodels.TRANSACTION_CHANNEL_KEY_YUNYIFU, uint64(withdrawCash), withdrawalAmount)
	}

	if channelId == 0 && needCustomer == 0 {
		err = errors.New("提现渠道信息错误!")
		return
	}

	// 平台手续费
	fee := float64(withdrawCash) * (platformFee / float64(10000))
	// 实际打款金额
	finalCash := withdrawCash - int64(fee)
	// 涉及金额
	payableCash := float64(finalCash) + utils.FuncRound(float64(finalCash)*(thirdFee/float64(10000)), 0)

	tx := utils.GEngine.Begin()
	// 发起申请
	model := dbmodels.AppTransaction{
		TransactionId:            dbmodels.IDBuilderGetId(utils.REDIS_IDBUILDER_TRANSACTION_ID),
		TransactionType:          dbmodels.DB_TRANSACTION_TYPE_WITHDRAW,
		TransactionAmount:        paramsJSON.WithdrawAmount,
		TransactionCash:          withdrawCash,
		TransactionFee:           int64(fee),
		TransactionFinalCash:     finalCash,
		TransactionPayableCash:   int64(payableCash),
		TransactionStatus:        dbmodels.DB_TRANSACTION_ING,
		TransactionRemark:        "余额提现",
		TransactionToUserId:      userId,
		TransactionToAccountType: data.BankcardAccountType,
		TransactionToAccountInfo: data.BankcardAccountInfo,
		TransactionNeedCustomer:  needCustomer,
		TransactionFromUserId:    userId,
		TransactionChannelId:     int(channelId),
	}

	err = model.Create(tx)
	if err != nil {
		tx.Rollback()
		return
	}

	// 减少余额
	err = new(dbmodels.AppUserWallet).Withdraw(tx, userId, paramsJSON.WithdrawAmount)
	if err != nil {
		tx.Rollback()
		return
	}
	// 增加本月已提现金额
	if channelId > 0 { // 有渠道的才扣除额度
		err = new(dbmodels.AppIdCardWithdrawal).AddAmount(tx, certificationData.CertificationIdCode, channelId, uint64(withdrawCash))
		if err != nil {
			tx.Rollback()
			return
		}
	}
	tx.Commit()

	go func() {
		err = WithdrawProcessing(userId, paramsJSON.WithdrawAmount/100)
		if err != nil {
			utils.LogErrorF("[发送提现申请消息]失败：%s", err.Error())
		}
	}()

	return
}

func getChannelInfo(channelKey string, withdrawCash uint64, withdrawalAmount map[uint64]uint64) (channelId uint64, needCustomer int, platformFee, thirdFee float64) {
	var useAmount uint64 = 0
	channel, err := new(dbmodels.AppTransactionChannel).QueryKey(channelKey)
	if err == nil {
		channelId, err = strconv.ParseUint(channel["id"], 10, 64)
		if err == nil {
			channelParam := dbmodels.ChannelWithdrawal{}
			if json.Unmarshal([]byte(channel["param"]), &channelParam) == nil {
				if amount, ok := withdrawalAmount[channelId]; ok {
					useAmount = amount
				}
				if useAmount+withdrawCash > uint64(channelParam.MonthMax) {
					channelId = 0
					needCustomer = 1
				} else {
					platformFee = float64(channelParam.PlatformFee)
					thirdFee = float64(channelParam.ThirdFee)
				}
				return
			}
		}
	}
	channelId = 0
	return
}
