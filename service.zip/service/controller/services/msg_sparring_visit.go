package services

import (
	"fmt"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"strings"
)

type SparringVisitSendMsg struct {
}

func InitSparringVisitSendMsg() *SparringVisitSendMsg {
	return &SparringVisitSendMsg{}
}

// 发送 用户浏览消息 给 大神
func (m *SparringVisitSendMsg) SendGoGoMsg(userId int64, userInfo *dbmodels.SystemUser, msgModel *dbmodels.AppMsgModel) (err error) {
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              strings.Replace(msgModel.MsgSmsContent, "${nickname}", userInfo.UserNickname, -1),
		NotificationClose: msgModel.MsgNotificationClose,
	}

	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	if err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, fmt.Sprint(userId)); err != nil {
		utils.LogErrorF("发送大神消息失败,err:%s", err.Error())
	}

	return err
}

func (m *SparringVisitSendMsg) SendInteractiveMsg(msgModel *dbmodels.AppMsgModel, userId, visitUid int64, userInfo *dbmodels.SystemUser) (err error) {
	assistantMsg := &redismodels.AssistantMsg{
		Type:         redismodels.MSG_ASSISTANT_TYPE_ACTION,
		ActionType:   redismodels.MSG_ACTION_TYPE_USER_INDEX,
		Title:        msgModel.MsgTitle,
		Text:         strings.Replace(msgModel.MsgContent, "${nickname}", userInfo.UserNickname, -1),
		ActionParams: map[string]interface{}{"user_id": visitUid},
		Action:       fmt.Sprintf("%d", visitUid),
	}

	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	if err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT,
		fmt.Sprint(userId)); err != nil {
		utils.LogErrorF("用户浏览消息推送失败,err:%s", err.Error())
	}

	return
}
