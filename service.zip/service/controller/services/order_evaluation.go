package services

import (
	"gamers/controller/request"
	"gamers/enum"
	"gamers/models/dbmodels"
)

// 获取技能标签
func GetSkillLabel(sparringSkillId int64) (labelMap map[string]interface{}, err error) {

	sparringData, err := new(dbmodels.AppSparringSkill).QueryBySkillId(sparringSkillId)
	if err != nil {
		return
	}

	var (
		praise    []dbmodels.AppSkillLabel
		badReview []dbmodels.AppSkillLabel
	)
	labelMap = make(map[string]interface{})
	labels, err := new(dbmodels.AppSkillLabel).GetSkillLabel(sparringData.SkillSkillID)
	for _, v := range labels {
		if *v.LabelEvaluation == enum.LabelEvaluationPraise {
			praise = append(praise, *v)
		}
		if *v.LabelEvaluation == enum.LabelEvaluationBadReview {
			badReview = append(badReview, *v)
		}
	}
	labelMap["praise"] = praise
	labelMap["badreview"] = badReview
	labelMap["icon"] = sparringData.SystemUser.UserIconurl
	labelMap["nickname"] = sparringData.SystemUser.UserNickname
	return
}

// 获取订单评价详情
func GetOrderEvaluationDetail(commentId int64) (data dbmodels.AppSkillOrderComment, err error) {
	return dbmodels.AppSkillOrderComment{}, err
}

// 添加评论
func SubmitEvaluation(userId uint64, req request.SubmitEvaluationReq) error {
	return nil
}
