package services

import (
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"sync"
	"time"

	jsoniter "github.com/json-iterator/go"

	"gamers/controller/request"
	"gamers/models/dbmodels"
	"gamers/utils"
	"gamers/utils/fdd"
	"gamers/utils/meichai"
	"gamers/utils/tencent/cos"
	"gamers/utils/yunyifu"
)

type FddCallbackHandler struct {
	FddClient *fdd.Client
	CosClient *cos.Clienter
	Mu        sync.WaitGroup
	Done      chan bool
	ErrChan   chan error        //错误信息
	Url       map[string]string //图片地址
}

//法大大回调
func FddCallback(paramsJSON request.FddCallbackReq) (err error) {
	var number string
	if paramsJSON.SerialNo != "" {
		number = paramsJSON.SerialNo
	} else {
		number = paramsJSON.TransactionId
	}

	_, data, err := new(dbmodels.Certification).QueryFddCallback(number)
	if err != nil {
		return err
	}
	if data.CertificationLivingStatus == dbmodels.CERTIFICATION_STATUS_LIVING_YES {
		err = errors.New("用户认证已通过")
		return
	}

	if paramsJSON.Status == fdd.PERSON_STATUS_PASSED || paramsJSON.ResultCode == "3000" {
		go updateFdd(data)
	}
	return
}

//更新fdd
func updateFdd(data dbmodels.Certification) {
	f := FddCallbackHandler{
		FddClient: fdd.NewFdd(),
		CosClient: cos.New(),
		ErrChan:   make(chan error),
		Url:       make(map[string]string),
	}

	//查询认证信息
	personCertInfo, err := f.FddClient.FindPersonCertInfoResponse(data.CertificationAuthenticationNumber)
	if err != nil {
		utils.LogErrorF("[fdd回调]用户认证信息失败:%s", err.Error())
		return
	}

	f.Mu.Add(3)
	go getFddFile(&f, "positive_url", personCertInfo.Data.Person.HeadPhotoPath)
	go getFddFile(&f, "negative_url", personCertInfo.Data.Person.PhotoUuid)
	go getFddFile(&f, "face_url", personCertInfo.Data.Person.PhotoUuid)

	go func() {
		f.Mu.Wait()
		close(f.Done)
	}()

	select {
	case err = <-f.ErrChan: //读取到错误直接返回
		utils.LogErrorF("[fdd回调]获取图片文件失败:%s", err.Error())
		return
	case <-f.Done:
	case <-time.After(5 * time.Second): //最多等待5秒
	}

	model := dbmodels.Certification{}
	model.CertificationRealName = personCertInfo.Data.Person.PersonName
	model.CertificationIdCode = personCertInfo.Data.Person.IdCard
	model.CertificationPositiveUrl = f.Url["positive_url"]
	model.CertificationNegativeUrl = f.Url["negative_url"]
	model.CertificationFaceUrl = f.Url["face_url"]
	if data.CertificationPhoto == "" {
		model.CertificationPhoto = f.Url["face_url"]
	}
	model.CertificationStatus = dbmodels.CERTIFICATION_STATUS_OK
	model.CertificationLivingStatus = dbmodels.CERTIFICATION_STATUS_LIVING_YES
	_, err = model.Update(data.CertificationId)
	if err != nil {
		utils.LogErrorF("[fdd回调]更新用户认证信息失败:%s", err.Error())
		return
	}
	info, err := new(dbmodels.SystemUser).UserIdByUser(data.CertificationId)
	if err != nil {
		utils.LogErrorF("[fdd回调]查询用户信息失败:%s", err.Error())
		return
	}

	contractUrl := fddExtSignAuto(&f, data.CertificationId, data.CertificationAuthenticationNumber, data.CertificationId, data.CertificationContractId)
	if contractUrl != "" {
		//签约美差服务
		if meiChaiAutoSign(data.CertificationId, model.CertificationRealName, model.CertificationIdCode, info.UserMobile) {
			//云易付签约
			yunyifuAutoRegister(data.CertificationId, model.CertificationRealName, model.CertificationIdCode, info.UserMobile, model.CertificationPhoto, contractUrl)
		}
	}
	return
}

//获取法大大文件
func getFddFile(f *FddCallbackHandler, mapKey string, fileUuid string) {
	defer f.Mu.Wait()
	//获取身份证正面照片
	file, err := f.FddClient.GetFile(fileUuid)
	if err != nil {
		f.ErrChan <- err
		return
	}
	filePath := "/gogo/secret/"
	if utils.Config.App.Env == "staging" {
		filePath = "/gogo-staging/secret/"
	}
	fileUrl, err := f.CosClient.ObjectPut(filePath, fmt.Sprintf("%d-%s.jpg", time.Now().Unix(), utils.FuncRandString(10)), file)
	if err != nil {
		f.ErrChan <- err
		return
	}
	f.Url[mapKey] = fileUrl
	return
}

//美差静默签约
func meiChaiAutoSign(userId int64, realName string, idCard string, mobile string) (signStatus bool) {
	param, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PARAM_KEY_MEICHAI_AUTO_SIGN_IMG)
	if err != nil {
		utils.LogErrorF("[fdd回调]获取美差静默签图片失败:%s", err.Error())
		return false
	}
	url := param["value"]

	channel, err := new(dbmodels.AppTransactionChannel).QueryKey(dbmodels.TRANSACTION_CHANNEL_KEY_MEICAI)
	if err != nil {
		utils.LogErrorF("美差信息错误!:[%s]", channel)
		return false
	}
	meicaiParam := dbmodels.ChannelMeiCaiParam{}
	err = json.Unmarshal([]byte(channel["param"]), &meicaiParam)
	if err != nil {
		utils.LogErrorF("美差信息错误:[%s]", channel["param"])
		return false
	}

	sign := meichai.ServiceAutoSignRequest{
		OutTradeNo:       fmt.Sprintf("%d", time.Now().Unix()),
		ContractTemplate: meicaiParam.ContractTemplate,
		UserName:         realName,
		UserIdcard:       idCard,
		FrontUrl:         url,
		BackUrl:          url,
		UserMobile:       mobile,
	}
	err = meichai.New(meicaiParam.Url, meicaiParam.PrivateKey, meicaiParam.MerchantId, meicaiParam.MerchantName).ServiceAutoSign(sign)
	if err != nil {
		utils.LogErrorF("[fdd回调]美差服务签约失败:[userId:%d],[err:%s]", userId, err.Error())
		//如果错误信息中找到"禁止重复签约"字符,也代表签约成功
		if strings.Index(err.Error(), "禁止重复签约") <= 0 {
			return false
		}
	}
	model := dbmodels.Certification{}
	model.CertificationMeicaiSignup = dbmodels.CERTIFICATION_MEICHAI_SIGN_YES
	_, err = model.Update(userId)
	if err != nil {
		utils.LogErrorF("[fdd回调]美差服务签约更新数据库失败:[userId:%d],[err:%s]", userId, err.Error())
		return false
	}
	return true
}

//云易付
func yunyifuAutoRegister(userId int64, realName string, idCard string, mobile string, faceUrl, contractUrl string) {
	channel, err := new(dbmodels.AppTransactionChannel).QueryKey(dbmodels.TRANSACTION_CHANNEL_KEY_YUNYIFU)
	if err != nil {
		utils.LogErrorF("云易付渠道信息错误!:[%s]", channel)
		return
	}
	yunyifuParam := dbmodels.ChannelYunyifuParam{}
	err = json.Unmarshal([]byte(channel["param"]), &yunyifuParam)
	if err != nil {
		utils.LogErrorF("云易付渠道信息错误:[%s]", channel["param"])
		return
	}
	yunyifuUserId := "a" + utils.Func16MD5(idCard)
	register := yunyifu.UserRegisterReq{
		DealerUserId: yunyifuUserId,
		RealName:     realName,
		IdNumber:     idCard,
		Phone:        mobile,
		ContractUrl:  contractUrl,
		FaceUrl:      faceUrl,
		SignTime:     time.Now().Format("2006-01-02 15:04:05"),
		Timestamp:    time.Now().Unix(),
	}

	err = yunyifu.New(yunyifuParam.Host, yunyifuParam.AppId, yunyifuParam.AppSecret).UserRegister(register)
	if err != nil {
		utils.LogErrorF("[fdd回调]云易付注册失败:[userId:%d],[err:%s]", userId, err.Error())
	}

	model := dbmodels.Certification{}
	model.CertificationYunyifuSignup = dbmodels.CERTIFICATION_YUNYIFU_SIGN_YES
	_, err = model.Update(userId)
	if err != nil {
		utils.LogErrorF("[fdd回调]云易付服务注册更新数据库失败:[userId:%d],[err:%s]", userId, err.Error())
		return
	}
}

//法大大自动签
func fddExtSignAuto(f *FddCallbackHandler, certificationId int64, serialNo string, userId int64, contractId string) (contractUrl string) {
	auto, err := f.FddClient.ExtSignAuto(serialNo, contractId)
	if err != nil {
		utils.LogErrorF("[fdd回调]法大大自动签失败:[userId:%d],[err:%s]", userId, err.Error())
		return ""
	}
	auto.DownloadUrl = strings.Replace(auto.DownloadUrl, "\\u0026", "&", -1)
	//更新合同地址
	model := dbmodels.Certification{
		//CertificationContractUrl: auto.ViewpdfUrl,
		CertificationContractUrl: auto.DownloadUrl,
	}
	_, err = model.Update(certificationId)
	if err != nil {
		utils.LogErrorF("[fdd回调]更新合同地失败:[userId:%d],[err:%s]", userId, err.Error())
		return ""
	}

	//合同归档
	err = f.FddClient.ContractFiling(contractId)
	if err != nil {
		utils.LogErrorF("[fdd回调]合同归档失败:[userId:%d],[err:%s]", userId, err.Error())
		return ""
	}
	return auto.DownloadUrl
}

const (
	DEFAULT_SAVE_CHANNEL_TIMEOUT = 60 * 60 * 24 * 7 * time.Second
)

// 缓存渠道到redis
func SaveChannelToRedis(key string, data interface{}) (err error) {
	jsStr, err := jsoniter.Marshal(data)
	if err != nil {
		utils.LogErrorF("序列化渠道数据失败,err:%s", err.Error())
		return
	}
	err = utils.RedisClient.Set(utils.REDIS_CHANNEL_CALLBACK+key, jsStr, DEFAULT_SAVE_CHANNEL_TIMEOUT).Err()
	return
}
