package services

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
)

// 查找公会
func UnionSearch(userID int64, req *request.UnionSearch) (*response.UnionSearch, error) {
	var data, err = new(dbmodels.AppUnion).Search(userID, &dbmodels.AppUnionSearch{
		InviteKey: req.InviteKey,
	})
	if err != nil {
		return nil, err
	}

	var ret = response.UnionSearch{
		List: nil,
	}
	for _, v := range data {
		ret.List = append(ret.List, &response.UnionSearchItem{
			UnionID:            v.UnionID,
			UnionCode:          v.UnionCode,
			UnionName:          v.UnionName,
			UnionInviteKey:     v.UnionInviteKey,
			ApplyForJoinStatus: v.ApplyForJoinStatus,
		})
	}

	return &ret, nil
}

// 申请加入公会
func UnionApplyForJoin(userID int64, req *request.UnionApplyForJoin) (string, error) {
	return new(dbmodels.AppUserUnionLog).ApplyForJoin(userID, req.UnionID)
}

// 获取自己所在公会房间
func UnionMineUnionRooms(userID int64, req *request.UnionMineUnionRooms) (*response.BasePageList, error) {
	if req.Page == 0 || req.Size == 0 {
		req.Page = 1
		req.Size = 30
	}

	var unionID int64
	var userInfo, err = new(redismodels.UserInfo).GetUserInfo(userID)
	if err == nil && userInfo.UserID == userID {
		unionID = userInfo.UserUnionId
	} else {
		var userData, err = new(dbmodels.SystemUser).UserIdByUser(userID)
		if err != nil {
			return nil, err
		}
		unionID = userData.UserUnionId
	}

	// 不在公会，直接返回
	if unionID <= 0 {
		return nil, nil
	}

	total, data, err := new(dbmodels.AppLiveRoom).SearchByUnionID(&dbmodels.AppLiveRoomSearchByUnionID{
		UnionID:  unionID,
		Page:     req.Page,
		PageSize: req.Size,
	})
	if err != nil {
		return nil, err
	}

	var ret = response.BasePageList{
		Page:       req.Page,
		Size:       req.Size,
		Total:      total,
		TotalPages: utils.FuncTotalPages(total, req.Size),
		List:       nil,
	}
	var roomList []*response.AppLiveRoomResult
	for _, v := range data {
		var itemData = &response.AppLiveRoomResult{
			RoomId:          v.RoomId,
			RoomPrettyId:    v.RoomPrettyId,
			RoomType:        v.RoomType,
			RoomName:        v.RoomName,
			RoomCover:       v.RoomCover,
			RoomTitle:       v.RoomTitle,
			RoomUnionId:     v.RoomUnionId,
			RoomUserId:      v.RoomUserId,
			RoomUserName:    v.SystemUser.UserNickname,
			RoomUserIconurl: v.SystemUser.UserIconurl,
			RoomUserAge:     utils.FuncGetAge(int(v.SystemUser.UserBirthday)),
			RoomUserGender:  v.SystemUser.UserGender,
			RoomIsPassword:  0,
			RoomAttrId:      v.RoomAttrId,
			RoomAttrName:    v.RoomLiveAttr.AttrName,
			RoomSpeakType:   v.RoomSpeakType,
			RoomOpenIm:      v.RoomOpenIm,
			RoomLiveStatus:  v.RoomLiveStatus,
			RoomStatus:      v.RoomStatus,
			UnionName:       v.AppUnion.UnionName,
			UnionCode:       v.AppUnion.UnionCode,
			Hot:             int(v.RoomHeat),
		}
		if v.RoomPassword != "" {
			itemData.RoomIsPassword = 1
		}
		//处理热度为负数
		if v.RoomHeat < 0 {
			itemData.Hot = 0
		}

		//获取主持信息
		wheatDetail, _ := new(redismodels.Wheat).QueryWheatDetail(int(v.RoomId))
		if len(wheatDetail.WheatObj) > 0 {
			itemData.RoomPreside = response.RoomPreside{
				PresideName:    wheatDetail.WheatObj[0].UserNickName,
				PresideIconurl: wheatDetail.WheatObj[0].UserIconurl,
			}
		}

		roomList = append(roomList, itemData)
	}
	ret.List = roomList

	return &ret, nil
}
