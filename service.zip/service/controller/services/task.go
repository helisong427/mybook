package services

import (
	"errors"
	"fmt"
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/enum"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"gamers/utils/prop"
	"gamers/utils/ymd"
	"sort"
	"strconv"
	"strings"
	"time"

	"gorm.io/gorm"
)

// 获取任务数据（任务中心）
func TaskGetListTaskCenter(userID int64) (*response.TaskListData, error) {

	// 用户完成10分钟在房间的任务 start
	userIdStr := strconv.Itoa(int(userID))
	// 1.判断是否在房间
	roomIdStr, err := utils.RedisClient.Get(utils.REDIS_LIVE_JOIN_USER + userIdStr).Result()
	if err == nil { // 用户在房间
		// 2.在房间是否超过10分钟
		var room JoinRoomCache
		err := utils.RedisClient.HGet(utils.REDIS_LIVE_ONLINE_MEMBER+roomIdStr, userIdStr).Scan(&room)
		if err == nil {
			if room.JoinT+DEFAULT_JOIN_ROOM_TASK_TIME <= time.Now().Unix() {
				// 任务埋点：在派对房/直播间呆10分钟
				_ = new(redismodels.Task).Init().ReportConditionTag(room.UserId, "stayInRoom10Minute", 1)
			}
		}
	}
	// 用户完成10分钟在房间的任务 end

	return taskGetTaskListDataByFlags(userID, []uint32{
		enum.TaskSetFlagNone,
	}, redismodels.TaskSetModelTaskCenter)
}

// 获取大转盘任务中心
func TaskGetListTurnTable(userID int64) (*response.TaskListData, error) {

	// 用户完成10分钟在房间的任务 start
	userIdStr := strconv.Itoa(int(userID))
	// 1.判断是否在房间
	roomIdStr, err := utils.RedisClient.Get(utils.REDIS_LIVE_JOIN_USER + userIdStr).Result()
	if err == nil { // 用户在房间
		// 2.在房间是否超过10分钟
		var room JoinRoomCache
		err := utils.RedisClient.HGet(utils.REDIS_LIVE_ONLINE_MEMBER+roomIdStr, userIdStr).Scan(&room)
		if err == nil {
			if room.JoinT+DEFAULT_JOIN_ROOM_TASK_TIME <= time.Now().Unix() {
				// 任务埋点：在派对房/直播间呆10分钟
				_ = new(redismodels.Task).Init().ReportConditionTag(room.UserId, "stayInRoom10Minute", 1)
			}
		}
	}
	// 用户完成10分钟在房间的任务 end

	return taskGetTaskListDataByFlags(userID, []uint32{
		enum.TaskSetFlagNone,
	}, redismodels.TaskSetModelTurnTable)
}

// 获取任务数据（签到任务）
func TaskGetListCheckinContinuous(userID int64) (*response.TaskListData, error) {
	go LiaoyiliaoDailyMsg(userID)
	return taskGetTaskListDataByFlags(userID, []uint32{
		enum.TaskSetFlagCheckinContinuous,
	}, redismodels.TaskSetModelTaskCenter)
}

// task通过标志获取任务列表数据
func taskGetTaskListDataByFlags(userID int64, flags []uint32, model int) (*response.TaskListData, error) {
	// 任务标签map  匹配通用任务集合 连续签到
	var flagMaps = map[uint32]uint32{}
	for _, v := range flags {
		flagMaps[v] = v
	}
	if len(flagMaps) == 0 {
		return nil, errors.New("error flags")
	}

	var redisTaskMgr = new(redismodels.Task).Init()
	if !redisTaskMgr.IsCached() {
		_, _, _, _ = redisTaskMgr.Build()
	}

	var nowTime = time.Now()
	var nowTimestamp = nowTime.Unix()
	var result = &response.TaskListData{
		GeneratedTime: nowTime,
		GeneratedAt:   nowTimestamp,
		List:          nil,
	}

	// 获取所有集合 所有任务
	var data, err = redisTaskMgr.GetAllSetData(model)
	if err != nil {
		return nil, err
	}

	if data == nil {
		return result, nil
	}

	// 根据flag 填充任务集合
	var needFillRecordMaps = map[uint32]*redismodels.TaskWrapperCfgTaskSet{}
	for _, v := range data {
		if v.Set.SetStatus == enum.TaskSetStatusClose {
			continue
		}
		if v.Set.SetStartTime != 0 && v.Set.SetEndTime != 0 {
			if !(int64(v.Set.SetStartTime) <= nowTimestamp && nowTimestamp <= int64(v.Set.SetEndTime)) {
				continue
			}
		}
		if _, prs := flagMaps[v.Set.SetFlag]; prs {
			needFillRecordMaps[v.Set.SetID] = v
		}
	}

	var recordsMaps, queryErr = TaskQueryRecords(userID, nowTime, needFillRecordMaps)
	if queryErr != nil {
		return nil, queryErr
	}

	for _, v := range needFillRecordMaps {
		switch v.Set.SetFlag {
		// 连续签到
		case enum.TaskSetFlagCheckinContinuous:
			result.List = append(result.List, TaskFillRespTaskSetFlagCheckinContinuous(nowTime, v, recordsMaps[v.Set.SetID]))
		default:
			// 集合内无需要展示的任务不发送给客户端
			var respTaskSetData = TaskFillRespTaskSet(v, recordsMaps[v.Set.SetID])
			if len(respTaskSetData.SetTasks) == 0 {
				continue
			}
			result.List = append(result.List, respTaskSetData)
		}
	}

	if len(result.List) > 0 {
		sort.Slice(result.List, func(i, j int) bool {
			if result.List[i].SetSort != result.List[j].SetSort {
				return result.List[i].SetSort < result.List[j].SetSort
			}
			return result.List[i].SetID < result.List[j].SetID
		})
	}

	return result, nil
}

// 根据任务集合模式 返回任务记录
func TaskQueryRecords(userID int64, queryTime time.Time, data map[uint32]*redismodels.TaskWrapperCfgTaskSet) (map[uint32]map[uint32]*dbmodels.AppTaskRecord, error) {
	var ret = map[uint32]map[uint32]*dbmodels.AppTaskRecord{}

	var rawElem []string
	var rawArgs []interface{}

	for _, v := range data {
		ret[v.Set.SetID] = map[uint32]*dbmodels.AppTaskRecord{}

		if v.Set.SetFlag == enum.TaskSetFlagCheckinContinuous {
			stmt := utils.GEngine.Session(&gorm.Session{DryRun: true}).
				Model(new(dbmodels.AppTaskCheckinContinuousRecord)).
				Select("*").
				Where("record_user_id = ? AND record_set_id = ?", userID, v.Set.SetID).
				Order("record_time DESC").Limit(1).
				Find(&[]dbmodels.AppTaskCheckinContinuousRecord{}).Statement

			rawElem = append(rawElem, fmt.Sprintf("\n(%s)\n", stmt.SQL.String()))
			rawArgs = append(rawArgs, userID)
			rawArgs = append(rawArgs, v.Set.SetID)
			continue
		}

		// 任务集合检查模式
		switch v.Set.SetVerifyMode {
		// 永久
		case enum.TaskSetVerifyModeForever:
			stmt := utils.GEngine.Session(&gorm.Session{DryRun: true}).
				Model(new(dbmodels.AppTaskRecord)).
				Select("*").
				Where("record_user_id = ? AND record_set_id = ?", userID, v.Set.SetID).
				Find(&[]dbmodels.AppTaskRecord{}).Statement
			rawElem = append(rawElem, fmt.Sprintf("\n(%s)\n", stmt.SQL.String()))
			rawArgs = append(rawArgs, userID)
			rawArgs = append(rawArgs, v.Set.SetID)

		// 每日更新
		case enum.TaskSetVerifyModeDaily:
			var begin, end = ymd.GetDayBeginAndEndTimestamp(queryTime)
			stmt := utils.GEngine.Session(&gorm.Session{DryRun: true}).
				Model(new(dbmodels.AppTaskRecord)).
				Select("*").
				Where("record_user_id = ? AND record_set_id = ?", userID, v.Set.SetID).
				Where("record_time >= ? and record_time <= ?", begin, end).
				Find(&[]dbmodels.AppTaskRecord{}).Statement
			rawElem = append(rawElem, fmt.Sprintf("\n(%s)\n", stmt.SQL.String()))
			rawArgs = append(rawArgs, userID)
			rawArgs = append(rawArgs, v.Set.SetID)
			rawArgs = append(rawArgs, begin)
			rawArgs = append(rawArgs, end)

		default:
			return nil, errors.New("get record failed")
		}
	}

	var results []*dbmodels.AppTaskRecord
	var sql = strings.Join(rawElem, "UNION ALL")
	if err := utils.GEngine.Raw(sql, rawArgs...).Scan(&results).Error; err != nil {
		return nil, err
	}

	for _, v := range results {
		ret[v.RecordSetID][v.RecordTaskID] = v
	}

	return ret, nil
}

func TaskFillRespTaskSetFlagCheckinContinuous(queryTime time.Time, data *redismodels.TaskWrapperCfgTaskSet, records map[uint32]*dbmodels.AppTaskRecord) *response.TaskSet {
	var record *dbmodels.AppTaskRecord
	for _, r := range records {
		record = r
		break
	}

	var pCount uint32 // 签到到第几天(以 queryTime 当作今天)
	var pCurDay bool
	var pState uint32 = enum.TaskStateInProgress
	if record != nil {
		if ymd.IsSameDay(queryTime, time.Unix(record.RecordTime, 0)) {
			pCurDay = true
			pCount = record.RecordProgress
			pState = record.RecordState
		} else if ymd.IsSameDay(queryTime.AddDate(0, 0, -1), time.Unix(record.RecordTime, 0)) {
			pCount = record.RecordProgress + 1
			pState = enum.TaskStateInProgress
		} else {
			pCount = 1
			pState = enum.TaskStateInProgress
		}
	} else {
		pCount = 1
		pState = enum.TaskStateInProgress
	}
	if pCount > uint32(len(data.Tasks)) {
		pCount = 1
		pState = enum.TaskStateInProgress
	}

	var retTaskSet = &response.TaskSet{
		SetID:         data.Set.SetID,
		SetName:       data.Set.SetName,
		SetDesc:       data.Set.SetDesc,
		SetFlag:       data.Set.SetFlag,
		SetVerifyMode: data.Set.SetVerifyMode,
		SetShow:       data.Set.SetShow,
		SetSort:       data.Set.SetSort,
		SetStatus:     data.Set.SetStatus,
		SetStartTime:  data.Set.SetStartTime,
		SetEndTime:    data.Set.SetEndTime,
		SetTasks:      nil,
	}

	for _, task := range data.Tasks {
		if task.TaskStatus == enum.TaskStatusClose {
			continue
		}

		var retTaskData = &response.TaskTask{
			TaskID:             task.TaskID,
			TaskSetID:          task.TaskSetID,
			TaskName:           task.TaskName,
			TaskConditionTag:   task.TaskConditionTag,
			TaskConditionCount: task.TaskConditionCount,
			TaskRewardQuota:    task.TaskRewardQuota,
			TaskIcon:           task.TaskIcon,
			TaskSort:           task.TaskSort,
			TaskStatus:         task.TaskStatus,
			TaskRewards:        nil,
		}
		for _, reward := range task.TaskRewards {
			retTaskData.TaskRewards = append(retTaskData.TaskRewards, &response.TaskReward{
				RewardPropType:  reward.RewardPropType,
				RewardPropID:    reward.RewardPropID,
				RewardPropCount: reward.RewardPropCount,
				PropName:        reward.AppProp.PropName,
				PropIcon:        reward.AppProp.PropIcon,
			})
		}

		retTaskSet.SetTasks = append(retTaskSet.SetTasks, retTaskData)
	}

	if len(retTaskSet.SetTasks) != 0 {
		sort.Slice(retTaskSet.SetTasks, func(i, j int) bool {
			return retTaskSet.SetTasks[i].TaskConditionCount < retTaskSet.SetTasks[j].TaskConditionCount
		})
	}

	// 必须在排序后处理
	var isSetCurTaskFlag = false
	for _, task := range retTaskSet.SetTasks {
		if task.TaskConditionCount < pCount {
			task.RecordState = enum.TaskStateGet
			task.RecordProgress = task.TaskConditionCount
		} else if task.TaskConditionCount == pCount {
			task.RecordCurrent = true
			isSetCurTaskFlag = true
			if pCurDay {
				if pState == enum.TaskStateGet {
					task.RecordState = enum.TaskStateGet
					task.RecordProgress = task.TaskConditionCount
				} else {
					task.RecordState = enum.TaskStateFinish
					task.RecordProgress = task.TaskConditionCount
				}
			} else {
				task.RecordState = enum.TaskStateInProgress
				task.RecordProgress = pCount
			}
		} else {
			task.RecordState = enum.TaskStateInProgress
			task.RecordProgress = pCount
			if !isSetCurTaskFlag {
				task.RecordCurrent = true
				isSetCurTaskFlag = true
			}
		}
	}

	return retTaskSet
}

func TaskFillRespTaskSet(data *redismodels.TaskWrapperCfgTaskSet, records map[uint32]*dbmodels.AppTaskRecord) *response.TaskSet {
	var retTaskSet = &response.TaskSet{
		SetID:         data.Set.SetID,
		SetName:       data.Set.SetName,
		SetDesc:       data.Set.SetDesc,
		SetFlag:       data.Set.SetFlag,
		SetVerifyMode: data.Set.SetVerifyMode,
		SetShow:       data.Set.SetShow,
		SetSort:       data.Set.SetSort,
		SetStatus:     data.Set.SetStatus,
		SetStartTime:  data.Set.SetStartTime,
		SetEndTime:    data.Set.SetEndTime,
		SetTasks:      nil,
	}

	for _, task := range data.Tasks {
		if task.TaskStatus == enum.TaskStatusClose {
			continue
		}
		var record, ok = records[task.TaskID]

		// 如果任务领取后就隐藏
		if data.Set.SetShow == enum.TaskSetShowHideAfterGet {
			// 任务已领取
			if ok && record.RecordState == enum.TaskStateGet {
				continue
			}
		}

		var retTaskData = &response.TaskTask{
			TaskID:             task.TaskID,
			TaskSetID:          task.TaskSetID,
			TaskName:           task.TaskName,
			TaskConditionTag:   task.TaskConditionTag,
			TaskConditionCount: task.TaskConditionCount,
			TaskRewardQuota:    task.TaskRewardQuota,
			TaskIcon:           task.TaskIcon,
			TaskSort:           task.TaskSort,
			TaskStatus:         task.TaskStatus,
			TaskRewards:        nil,
		}
		// 填充任务奖励
		for _, reward := range task.TaskRewards {
			retTaskData.TaskRewards = append(retTaskData.TaskRewards, &response.TaskReward{
				RewardPropType:  reward.RewardPropType,
				RewardPropID:    reward.RewardPropID,
				RewardPropCount: reward.RewardPropCount,
				PropName:        reward.AppProp.PropName,
				PropIcon:        reward.AppProp.PropIcon,
			})
		}

		if ok {
			retTaskData.RecordState = record.RecordState
			retTaskData.RecordProgress = record.RecordProgress
		}

		retTaskSet.SetTasks = append(retTaskSet.SetTasks, retTaskData)
	}

	if len(retTaskSet.SetTasks) > 0 {
		sort.Slice(retTaskSet.SetTasks, func(i, j int) bool {
			if retTaskSet.SetTasks[i].RecordState != retTaskSet.SetTasks[j].RecordState {
				if retTaskSet.SetTasks[i].RecordState == enum.TaskStateFinish {
					return true
				} else if retTaskSet.SetTasks[i].RecordState == enum.TaskStateGet {
					return false
				} else { // retTaskSet.SetTasks[i].RecordState == enum.TaskStateInProgress
					if retTaskSet.SetTasks[j].RecordState == enum.TaskStateFinish {
						return false
					} else { // retTaskSet.SetTasks[j].RecordState == enum.TaskStateGet
						return true
					}
				}
			}
			if retTaskSet.SetTasks[i].TaskSort != retTaskSet.SetTasks[j].TaskSort {
				return retTaskSet.SetTasks[i].TaskSort < retTaskSet.SetTasks[j].TaskSort
			}
			return retTaskSet.SetTasks[i].TaskID < retTaskSet.SetTasks[j].TaskID
		})
	}

	return retTaskSet
}

// 上报前端任务完成条件行为来触发任务
func TaskReportCondition(userId int64, req *request.TaskReportCondition) error {
	if _, prs := enum.TaskConditionTagsNeedReport[req.ConditionTag]; !prs {
		return errors.New("conditionTag can't be reported")
	}
	return new(redismodels.Task).Init().ReportConditionTag(userId, req.ConditionTag, req.ConditionCount)
}

// 领取奖励
func TaskGetReward(userId int64, setID uint32, taskID uint32) (*response.TaskGetReward, string, error) {
	var redisTaskMgr = new(redismodels.Task).Init()
	if !redisTaskMgr.IsCached() {
		_, _, _, _ = redisTaskMgr.Build()
	}

	var taskData, err = redisTaskMgr.GetDataByTaskID(taskID)
	if err != nil {
		return nil, "领取任务奖励失败", err
	}
	if taskData == nil {
		return nil, "领取任务奖励失败", errors.New("task data is miss")
	}

	if taskData.Set.SetID != setID {
		return nil, "领取任务奖励失败", errors.New("task set_id is error")
	}

	if taskData.Task.TaskStatus == enum.TaskStatusClose {
		return nil, "领取任务奖励失败", errors.New("task is close")
	}

	if taskData.Set.SetStatus == enum.TaskSetStatusClose {
		return nil, "领取任务奖励失败", errors.New("task set is close")
	}

	var nowTime = time.Now()
	var nowTimestamp = nowTime.Unix()
	if taskData.Set.SetStartTime != 0 && taskData.Set.SetEndTime != 0 {
		if !(int64(taskData.Set.SetStartTime) <= nowTimestamp && nowTimestamp <= int64(taskData.Set.SetEndTime)) {
			return nil, "领取任务奖励失败", errors.New("task set is close")
		}
	}

	if taskData.Set.SetFlag == enum.TaskSetFlagCheckinContinuous {
		return nil, "领取任务奖励失败", errors.New("can't deal with checkin")
	}

	return taskGetRewardNormal(userId, setID, taskID, nowTime, taskData)
}

// 任务获得奖励
func taskGetRewardNormal(userId int64, setID uint32, taskID uint32, getTime time.Time, taskData *redismodels.TaskWrapperCfgTask) (*response.TaskGetReward, string, error) {
	var taskBegin, taskEnd int64
	if taskData.Set.SetVerifyMode == enum.TaskSetVerifyModeDaily {
		taskBegin, taskEnd = ymd.GetDayBeginAndEndTimestamp(getTime)
	}

	if msg, err := new(dbmodels.AppTaskRecord).FinishTask(utils.GEngine, &dbmodels.TaskFinishTask{
		UserID:     userId,
		SetID:      setID,
		TaskID:     taskID,
		RecordTime: getTime,
		TaskBegin:  taskBegin,
		TaskEnd:    taskEnd,
	}); err != nil {
		return nil, msg, err
	}

	if err := taskGiveRewardByTask(userId, taskData); err != nil {
		utils.LogErrorF("领取任务奖励失败：set_id[%d], set_name[%s], task_id[%d], task_name[%s], err[%s]",
			taskData.Set.SetID, taskData.Set.SetName, taskData.Task.TaskID, taskData.Task.TaskName, err.Error())
		return nil, "领取任务奖励失败", errors.New("give reward failed")
	}

	var resp = response.TaskGetReward{
		SetID:   setID,
		TaskID:  taskID,
		Rewards: nil,
	}
	for _, v := range taskData.Task.TaskRewards {
		resp.Rewards = append(resp.Rewards, &response.TaskRewardGet{
			RewardPropType:  v.RewardPropType,
			RewardPropID:    v.RewardPropID,
			RewardPropCount: v.RewardPropCount,
			PropName:        v.AppProp.PropName,
			PropIcon:        v.AppProp.PropIcon,
			PropRemark:      v.AppProp.PropRemark,
		})
	}

	return &resp, "", nil
}

// 签到
func TaskCheckin(userId int64, setID uint32, _ uint32) (*response.TaskGetRewardCheckinContinuous, string, error) {
	var redisTaskMgr = new(redismodels.Task).Init()
	if !redisTaskMgr.IsCached() {
		_, _, _, _ = redisTaskMgr.Build()
	}

	var setData, err = redisTaskMgr.GetDataBySetID(setID)
	if err != nil {
		return nil, "签到失败", errors.New("task set is miss")
	}
	if setData == nil {
		return nil, "签到失败", errors.New("task set is miss")
	}

	var nowTime = time.Now()
	var nowTimestamp = nowTime.Unix()
	if setData.SetStartTime != 0 && setData.SetEndTime != 0 {
		if !(int64(setData.SetStartTime) <= nowTimestamp && nowTimestamp <= int64(setData.SetEndTime)) {
			return nil, "签到失败", errors.New("task set is close")
		}
	}

	if setData.SetFlag != enum.TaskSetFlagCheckinContinuous {
		return nil, "签到失败", errors.New("only deal with checkin task")
	}

	return taskGetRewardCheckinContinuous(userId, setID, 0, nowTime, setData)
}

// 签到任务集合获取有效任务数据
func taskSetCheckinContinuousGetValidTasks(setData *dbmodels.AppTaskSet) (uint32, []*dbmodels.AppTask, map[uint32]*dbmodels.AppTask) {
	if len(setData.SetTasks) == 0 {
		return 0, nil, map[uint32]*dbmodels.AppTask{}
	}

	var maxConditionCount uint32
	var tasks []*dbmodels.AppTask
	var taskMaps = map[uint32]*dbmodels.AppTask{}
	for _, task := range setData.SetTasks {
		if task.TaskStatus == enum.TaskStatusClose {
			continue
		}
		tasks = append(tasks, task)
		taskMaps[task.TaskConditionCount] = task
	}

	if len(tasks) > 0 {
		sort.Slice(tasks, func(i, j int) bool {
			return tasks[i].TaskConditionCount < tasks[j].TaskConditionCount
		})
		maxConditionCount = tasks[len(tasks)-1].TaskConditionCount
	}

	return maxConditionCount, tasks, taskMaps
}

// 签到任务签到（触发并领取奖励）
func taskGetRewardCheckinContinuous(userId int64, setID uint32, _ uint32, getTime time.Time, setData *dbmodels.AppTaskSet) (*response.TaskGetRewardCheckinContinuous, string, error) {
	var maxConditionCount, tasks, taskMaps = taskSetCheckinContinuousGetValidTasks(setData)
	if maxConditionCount < 1 {
		return nil, "签到失败", errors.New("no checkin task")
	}

	var dbCheckin = dbmodels.TaskCheckinContinuous{
		UserID:            userId,
		SetID:             setID,
		RecordTime:        getTime,
		MaxConditionCount: maxConditionCount,
		Tasks:             tasks,
		TaskMaps:          taskMaps,
		CurConditionCount: 0,   // 当前进度
		CurTask:           nil, // 由记录补全
	}
	if msg, err := new(dbmodels.AppTaskCheckinContinuousRecord).Checkin(&dbCheckin); err != nil {
		return nil, msg, err
	}

	// 无奖励签到
	if dbCheckin.CurTask == nil {
		var resp = response.TaskGetRewardCheckinContinuous{
			TaskGetReward: response.TaskGetReward{
				SetID:   setID,
				TaskID:  0,
				Rewards: nil,
			},
			Progress: dbCheckin.CurConditionCount,
		}
		return &resp, "", nil
	}

	var taskData = redismodels.TaskWrapperCfgTask{
		Set:  setData,
		Task: dbCheckin.CurTask,
	}

	if err := taskGiveRewardByTask(userId, &taskData); err != nil {
		utils.LogErrorF("签到失败：set_id[%d], set_name[%s], task_id[%d], task_name[%s], err[%s]",
			taskData.Set.SetID, taskData.Set.SetName, taskData.Task.TaskID, taskData.Task.TaskName, err.Error())
		return nil, "签到失败", errors.New("give reward failed")
	}

	var resp = response.TaskGetRewardCheckinContinuous{
		TaskGetReward: response.TaskGetReward{
			SetID:   setID,
			TaskID:  taskData.Task.TaskID,
			Rewards: nil,
		},
		Progress: taskData.Task.TaskConditionCount,
	}
	for _, v := range taskData.Task.TaskRewards {
		resp.Rewards = append(resp.Rewards, &response.TaskRewardGet{
			RewardPropType:  v.RewardPropType,
			RewardPropID:    v.RewardPropID,
			RewardPropCount: v.RewardPropCount,
			PropName:        v.AppProp.PropName,
			PropIcon:        v.AppProp.PropIcon,
		})
	}

	return &resp, "", nil
}

func taskGiveRewardByTask(userID int64, taskData *redismodels.TaskWrapperCfgTask) error {
	var alteredBackpackList []*dbmodels.AppBackpack
	var tx = utils.GEngine.Begin()
	for _, v := range taskData.Task.TaskRewards {
		rewardPropCount := int64(v.RewardPropCount)
		var logTypeId int64 = 0
		var needCreate bool = true

		if v.AppProp.PropType == dbmodels.DB_PROP_TYPE_AVATAR ||
			v.AppProp.PropType == dbmodels.DB_PROP_TYPE_CHAT ||
			v.AppProp.PropType == dbmodels.DB_PROP_TYPE_CAR { //不可叠加数量
			row, data, err := new(dbmodels.AppBackpack).QueryNoStackable(tx, userID, v.AppProp.PropId, v.AppProp.PropType)
			if err != nil && err != gorm.ErrRecordNotFound {
				tx.Rollback()
				err = fmt.Errorf("[taskGiveRewardByTask]查询用户不叠加物品失败:[%s]", err.Error())
				utils.LogErrorF(err.Error())
				return err
			}
			if row > 0 {
				needCreate = false
				update := make(map[string]interface{})
				if v.AppProp.PropExpiredTime > 0 {
					update["backpack_expired_time"] = data.BackpackExpiredTime + v.AppProp.PropExpiredTime*60*60*24
				} else {
					update["backpack_expired_time"] = 0
				}
				err = new(dbmodels.AppBackpack).Update(tx, data.BackpackId, update)
				if err != nil {
					tx.Rollback()
					err = fmt.Errorf("[taskGiveRewardByTask]不叠加物品领取失败:[%s]", err.Error())
					utils.LogErrorF(err.Error())
					return err
				}
				logTypeId = data.BackpackId
			}
		} else { // 可叠加数量类
			row, data, err := new(dbmodels.AppBackpack).QueryStackable(tx, userID, v.AppProp.PropId, v.AppProp.PropType)
			if err != nil && err != gorm.ErrRecordNotFound {
				tx.Rollback()
				err = fmt.Errorf("[taskGiveRewardByTask]查询用户可叠加物品失败:[%s]", err.Error())
				utils.LogErrorF(err.Error())
				return err
			}
			// 增加物品数量
			if row > 0 {
				needCreate = false
				_, err := new(dbmodels.AppBackpack).AddCount(tx, data.BackpackId, rewardPropCount)
				if err != nil {
					tx.Rollback()
					err = fmt.Errorf("[taskGiveRewardByTask]增加可叠加物品数量失败:[%s]", err.Error())
					utils.LogErrorF(err.Error())
					return err
				}
				logTypeId = data.BackpackId
			}
		}

		if needCreate { // 创建物品信息
			var expiredTime int64 = 0
			if v.AppProp.PropExpiredTime > 0 {
				expiredTime = v.AppProp.PropExpiredTime*60*60*24 + time.Now().Unix()
			}
			model := dbmodels.AppBackpack{
				BackpackUserId:      userID,
				BackpackPropType:    v.AppProp.PropType,
				BackpackPropId:      v.AppProp.PropId,
				BackpackCount:       rewardPropCount,
				BackpackPropAttrId:  v.AppProp.PropAttrId,
				BackpackExpiredTime: expiredTime,
			}
			_, err := model.Create(tx)
			if err != nil {
				tx.Rollback()
				err = fmt.Errorf("[taskGiveRewardByTask]加物品失败:[%s]", err.Error())
				utils.LogErrorF(err.Error())
				return err
			}
			logTypeId = model.BackpackId
		}
		//背包日志
		modelLog := dbmodels.AppBackpackLog{
			LogType:     dbmodels.DB_APP_BACK_PACK_LOG_LOG_TYPE_GIFT,
			LogTypeId:   logTypeId,
			LogUserId:   userID,
			LogPropId:   v.AppProp.PropId,
			LogPropType: v.AppProp.PropType,
			LogCount:    rewardPropCount,
		}
		err := modelLog.Create(tx)
		if err != nil {
			tx.Rollback()
			err = fmt.Errorf("[taskGiveRewardByTask]加物品日志记录失败:[%s]", err.Error())
			utils.LogErrorF(err.Error())
			return err
		}

		var backpack = &dbmodels.AppBackpack{
			BackpackPropType: v.AppProp.PropType,
			BackpackId:       logTypeId,
		}
		alteredBackpackList = append(alteredBackpackList, backpack)
	}
	var err = tx.Commit().Error

	if err == nil {
		var redisFields []string
		for _, v := range alteredBackpackList {
			if prop.Type(v.BackpackPropType) == prop.TypeGift {
				var field = fmt.Sprintf("%d", v.BackpackId)
				redisFields = append(redisFields, field)
			}
		}
		if len(redisFields) > 0 {
			// 直接删除缓存
			var redisKey = fmt.Sprintf("%s%d", utils.REDIS_LIVE_GIFT_BACKPACK, userID)
			_ = utils.RedisClient.HDel(redisKey, redisFields...).Err()
		}
	}

	return err
}
