package services

import (
	"gamers/enum"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"gamers/utils/tencent/tencentIm"
	"strings"
)

const (
	ASSISTANT_ANCHOR_REFUSE = "assistant_anchor_refuse" // 拒绝主播申请
	ASSISTANT_ANCHOR_AGREE  = "assistant_anchor_agree"  // 同意主播申请
)

type Anchor struct {
}

// 通过主播
func (s Anchor) Agree(skillName, userId, url string, applyT int64) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_ANCHOR_AGREE)
	if err != nil {
		utils.LogErrorF("获取同意主播消息model失败,err:%s", err.Error())
		return
	}
	tmStr := utils.MsgTimeFormatDay(applyT)
	tip := strings.NewReplacer("${skill_name}", skillName, "${apply_date}", tmStr).Replace(msgModel.MsgContent)
	skillMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              tip,
		ActionType:        redismodels.MSG_ACTION_TYPE_URL,
		ActionParams:      map[string]interface{}{"url": url},
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: skillMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId)
	if err != nil {
		utils.LogErrorF("发送同意主播消息失败,err:%s", err.Error())
	}
	item := make(map[string]string)
	item[enum.IM_USER_ATTR_ANCHOR] = "1"
	err = tencentIm.AddUserAttr(userId, item)
	if err != nil {
		utils.LogErrorF("设置用户大神属性失败,err:%s", err.Error())
	}
	return
}

// 拒绝主播
func (s Anchor) Refuse(skillName, userId string, applyT int64) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_ANCHOR_REFUSE)
	if err != nil {
		utils.LogErrorF("获取拒绝主播消息model失败,err:%s", err.Error())
		return
	}
	tmStr := utils.MsgTimeFormatDay(applyT)

	param, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PARAM_KEY_ANCHOR_REFUSE_QQ_GROUP)
	if err != nil {
		utils.LogErrorF("获取主播审核失败qq群失败")
		return
	}
	tip := strings.NewReplacer("${skill_name}", skillName, "${apply_date}", tmStr, "${qq_group}", param["value"]).Replace(msgModel.MsgContent)
	skillMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: skillMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId)
	if err != nil {
		utils.LogErrorF("发送拒绝主播消息失败,err:%s", err.Error())
	}
	return
}
