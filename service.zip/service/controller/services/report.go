package services

import (
	"encoding/json"
	"errors"
	"fmt"
	"gamers/controller/request"
	"gamers/models/dbmodels"
	"gamers/utils"
	"gamers/utils/bilibili"
	"gamers/utils/huawei"
	"gamers/utils/tuia"
	"gamers/utils/yimi"

	ua "github.com/mileusna/useragent"
)

type TuiACallbackReq struct {
	TuiAId      string `form:"tui_a_id" binding:"required"` // 推啊用户id
	TuiAOrderId string `form:"tui_a_order_id"`
	Ip          string `form:"ip" json:"ip"`
	UA          string `form:"ua" json:"ua"`     // 数据上报终端设备的 User Agent
	Imei        string `form:"imei" json:"imei"` // 加密imei，原值MD5 32位加密小写
	IDFA        string `form:"idfa" json:"idfa"` // iOS IDFA，适用于 iOS6 及以上
	AAID        string `form:"aaid" json:"aaid"` // Android Advertising ID
	Device      string `form:"device"`           // 推啊的imeiMd5>idfaMd5>oaidMd5参数值替换
}

func (s *TuiACallbackReq) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s TuiACallbackReq) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

func (m TuiACallbackReq) GetChannelInfo(key string) (data TuiACallbackReq, err error) {
	key = utils.REDIS_CHANNEL_CALLBACK + key
	err = utils.RedisClient.Get(key).Scan(&data)
	return
}

func (m TuiACallbackReq) Del(key string) (err error) {
	key = utils.REDIS_CHANNEL_CALLBACK + key
	err = utils.RedisClient.Del(key).Err()
	return
}

func BiliBiliReport(form *request.AdReportReq) (err error) {
	key := ""
	if form.Imei != "" {
		key = fmt.Sprintf("%d:IMEI:%s", form.ChannelId, form.Imei)

	} else if form.OAID != "" {
		key = fmt.Sprintf("%d:OAID:%s", form.ChannelId, utils.FuncMD5(form.OAID))
	} else if form.UA != "" {
		userAgent := ua.Parse(form.UA)
		ukey := userAgent.OS + userAgent.OSVersion + userAgent.Device + form.Ip
		key = fmt.Sprintf("%d:UaIp:%s", form.ChannelId, ukey)
	}
	if key == "" {
		err = errors.New("未解析到有效参数,请检查")
		return
	}
	channelInfo, err := new(bilibili.BiliBiliAdCallbackReq).GetChannelInfo(key)
	if err != nil {
		utils.LogErrorF("获取b站渠道信息失败，key:%s", key)
		err = errors.New("渠道信息不存在")
		return
	}
	go channelInfo.Send(key)
	return
}

func TuiAReport(channelData *dbmodels.AppUserChannel, form *request.AdReportReq) (err error) {
	userAgent := ua.Parse(form.UA)
	ukey := userAgent.OS + userAgent.OSVersion + ":" + form.Ip
	key := fmt.Sprintf("%d:UaIp:%s", form.ChannelId, ukey)
	channelInfo, err := new(tuia.TuiACallbackReq).GetChannelInfo(key)
	if err != nil {
		utils.LogErrorF("获取推啊渠道信息失败，key:%s", key)
		err = errors.New("渠道信息不存在")
		return
	}
	go channelInfo.Send(key, channelData.ChannelConfig)
	return
}

func YiMiReport(channelInfo *dbmodels.AppUserChannel, form *request.AdReportReq) (err error) {
	YiMiReq := yimi.YiMiCallbackReq{}
	err = json.Unmarshal([]byte(channelInfo.ChannelConfig), &YiMiReq)
	if err == nil {
		sendData := yimi.YiMiSendData{Type: 0, IMEI: form.Imei, OAID: form.OAID, IP: form.Ip}
		go YiMiReq.Send(sendData)
	}
	return
}

func HuaWeiReport(channelData *dbmodels.AppUserChannel, form *request.AdReportReq) (err error) {
	ukey := utils.FuncMD5(form.OAID)
	key := fmt.Sprintf("%d:UaIp:%s", form.ChannelId, ukey)
	channelInfo, err := new(huawei.HuaWeiCallbackReq).GetChannelInfo(key)
	if err != nil {
		utils.LogErrorF("获取华为渠道信息失败，key:%s", key)
		err = errors.New("渠道信息不存在")
		return
	}
	go channelInfo.Send(channelData.ChannelConfig, "activate")
	return
}

func ADReportRegister(channelId int64, imei, oaid, ip string) error {
	channelInfo, err := new(dbmodels.AppUserChannel).GetChannelById(int64(channelId))
	if err != nil {
		return errors.New("获取渠道信息失败")
	}
	if channelInfo.ChannelKey == dbmodels.CHANNEL_KEY_YIMI { //亿米平台
		YiMiReq := yimi.YiMiCallbackReq{}
		err = json.Unmarshal([]byte(channelInfo.ChannelConfig), &YiMiReq)
		if err == nil {
			imei = utils.FuncMD5(imei)
			sendData := yimi.YiMiSendData{Type: 1, IMEI: imei, OAID: oaid, IP: ip}
			go YiMiReq.Send(sendData)
		}
		return err
	} else if channelInfo.ChannelKey == dbmodels.CHANNEL_KEY_HUAWEI { //华为平台
		ukey := utils.FuncMD5(oaid)
		key := fmt.Sprintf("%d:UaIp:%s", channelId, ukey)
		channelInfo, err := new(huawei.HuaWeiCallbackReq).GetChannelInfo(key)
		if err != nil {
			utils.LogErrorF("获取华为渠道信息失败，key:%s", key)
			err = errors.New("渠道信息不存在")
			return err
		}
		go channelInfo.Send(channelInfo.ChannelConfig, "register")
	}
	return nil
}

func ADReportRegisterV2(channelId int, imei, oaid, ip string) error {
	cid := int64(channelId)
	info, err := new(dbmodels.AppUserChannel).GetChannelById(cid)
	if err != nil {
		return errors.New("获取渠道信息失败")
	}

	// 亿米平台
	if info.ChannelKey == dbmodels.CHANNEL_KEY_YIMI {
		req := &yimi.YiMiCallbackReq{}
		err = json.Unmarshal([]byte(info.ChannelConfig), req)
		if err != nil {
			return err
		}

		ym := &YiMi{
			AppId:      req.AppId,
			SignKey:    req.SignKey,
			EncryptKey: req.EncryptKey,
			CustomerId: req.CustomerId,
			IMEI:       imei,
			OAId:       oaid,
			IP:         ip,
			Type:       YiMiLogin,
		}
		return ym.Send()
	}

	if info.ChannelKey == dbmodels.CHANNEL_KEY_HUAWEI {
		enc := utils.FuncMD5(oaid)
		rk := fmt.Sprintf("%d:UaIp:%s", channelId, enc)
		tmpInfo, err := new(huawei.HuaWeiCallbackReq).GetChannelInfo(rk)
		if err != nil {
			utils.LogErrorF("获取华为渠道信息失败，key:%s", rk)
			err = errors.New("渠道信息不存在")
			return err
		}

		hw := &HuaWei{
			ChannelId:       tmpInfo.ChannelId,
			ContentId:       tmpInfo.ContentId,
			ADGroupId:       tmpInfo.ADGroupId,
			CampaignId:      tmpInfo.CampaignId,
			OAId:            tmpInfo.OAID,
			TrackingEnabled: tmpInfo.TrackingEnabled,
			IP:              tmpInfo.IP,
			UserAgent:       tmpInfo.UserAgent,
			EventType:       tmpInfo.EventType,
			TraceTime:       tmpInfo.TraceTime,
			Callback:        tmpInfo.Callback,
			CorpId:          tmpInfo.CorpId,
			AppId:           tmpInfo.AppId,
			ChannelConfig:   tmpInfo.ChannelConfig,
		}

		return hw.Send()
	}
	return nil
}
