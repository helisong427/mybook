package services

import (
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"strconv"
	"strings"
	"time"
)

// 直播管理信息
const (
	ASSISTANT_LIVE_BE_MANAGER            = "assistant_live_be_manager"            // 成为管理员
	ASSISTANT_LIVE_BE_SECOND_MANAGER     = "assistant_live_be_second_manager"     // 成为副管理员
	ASSISTANT_LIVE_BE_KICK               = "assistant_live_be_kick"               // 被踢了
	ASSISTANT_LIVE_BE_BAN                = "assistant_live_be_ban"                // 被拉黑
	ASSISTANT_LIVE_BE_MUTE               = "assistant_live_be_mute"               // 被禁言
	ASSISTANT_LIVE_CANCEL_BAN            = "assistant_live_cancel_ban"            // 取消拉黑
	ASSISTANT_LIVE_CANCEL_KICK           = "assistant_live_cancel_kick"           // 取消被踢
	ASSISTANT_LIVE_CANCEL_MUTE           = "assistant_live_cancel_mute"           // 取消禁言
	ASSISTANT_LIVE_CANCEL_SECOND_MANAGER = "assistant_live_cancel_second_manager" // 取消副管理
	ASSISTANT_LIVE_CANCEL_MANAGER        = "assistant_live_cancel_manager"        // 取消管理

)

// 公屏消息
const (
	LIVE_KEY_SET_MANAGER         = "live_set_manager"         // 设置管理员
	LIVE_KEY_SET_SECOND_MANAGER  = "live_set_second_manager"  // 设置副管理员
	LIVE_KEY_SET_KICK            = "live_set_kick"            // 被踢了
	LIVE_KEY_SET_FORBIDDEN       = "live_set_forbidden"       // 被拉黑
	LIVE_KEY_SET_MUTE            = "live_set_mute"            // 被禁言
	LIVE_KEY_SET_UNMUTE          = "live_set_unmute"          // 取消被禁言
	LIVE_KEY_SEND_GIFT           = "live_send_gift"           // 送单个礼物
	LIVE_KEY_SEND_GIFTS          = "live_send_gifts"          // 送多个礼物
	LIVE_KEY_BREAK_EGG           = "live_break_egg"           // 砸蛋消息
	LIVE_KEY_PK_EXTEND_TIME      = "live_pk_extend_time"      // 延迟pk时间
	LIVE_KEY_PK_ADVANCE_FINISHED = "live_pk_advance_finished" // 提前结束pk
	HEADLINE_KEY_BREAK_EGG       = "headline_break_egg"       // 砸蛋消息
	HEADLINE_KEY_SEND_GIFT       = "headline_send_gift"       // 送礼消息
	LIVE_KEY_COME_IN             = "live_come_in"             // 进入直播间
)

type LiveMsg struct {
}

func InitLiveMsg() LiveMsg {
	return LiveMsg{}
}

// 获取角色
func GetRoleName(role int) (name string) {
	switch role {
	case dbmodels.ROOM_ADMIN_ROLE_NORMAL:
		name = "普通用户"
	case dbmodels.ROOM_ADMIN_ROLE_ADMIN:
		name = "高级管理员"
	case dbmodels.ROOM_ADMIN_ROLE_DEPUTY_ANCHOR:
		name = "管理员"
	case dbmodels.ROOM_ADMIN_ROLE_LANDLORD:
		name = "房主"
	default:
	}
	return
}

// 成为房管私聊消息
func (s LiveMsg) AssistantBeManager(liveRoom *dbmodels.AppLiveRoom, userId string, role, admin int) {
	key := ASSISTANT_LIVE_BE_MANAGER
	if role == dbmodels.ROOM_ADMIN_ROLE_DEPUTY_ANCHOR {
		key = ASSISTANT_LIVE_BE_SECOND_MANAGER
	}
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(key)
	if err != nil {
		utils.LogErrorF("获取成为房管消息model失败,err:%s", err.Error())
		return
	}
	tip := strings.NewReplacer("${room_name}", liveRoom.RoomName).Replace(msgModel.MsgContent)
	if role == dbmodels.ROOM_ADMIN_ROLE_DEPUTY_ANCHOR {
		tip = strings.NewReplacer("${admin_role}", GetRoleName(admin)).Replace(tip)
	}
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TEXT,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId)
	if err != nil {
		utils.LogErrorF("发送成为房管推送失败,err:%s", err.Error())
	}
	return
}

// 取消房管私聊消息
// role 用户身份
func (s LiveMsg) AssistantCancelManager(liveRoom *dbmodels.AppLiveRoom, userId string, role, admin int) {
	key := ASSISTANT_LIVE_CANCEL_MANAGER
	if role == dbmodels.ROOM_ADMIN_ROLE_DEPUTY_ANCHOR {
		key = ASSISTANT_LIVE_CANCEL_SECOND_MANAGER
	}
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(key)
	if err != nil {
		utils.LogErrorF("获取取消房管消息model失败,err:%s", err.Error())
		return
	}
	tip := strings.NewReplacer("${room_name}", liveRoom.RoomName).Replace(msgModel.MsgContent)
	if role == dbmodels.ROOM_ADMIN_ROLE_DEPUTY_ANCHOR {
		tip = strings.NewReplacer("${admin_role}", GetRoleName(admin)).Replace(tip)
	}
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TEXT,
		NotificationClose: msgModel.MsgNotificationClose,
		Text:              tip,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId)
	if err != nil {
		utils.LogErrorF("发送取消房管推送失败,err:%s", err.Error())
	}
	return
}

// 成为房管
// role 用户身份
func (s LiveMsg) AnnounceBeManager(liveRoom *dbmodels.AppLiveRoom, cmdObj *redismodels.UserInfo, role int, admin *redismodels.MsgUserObj) {
	key := LIVE_KEY_SET_MANAGER
	if role == dbmodels.ROOM_ADMIN_ROLE_DEPUTY_ANCHOR {
		key = LIVE_KEY_SET_SECOND_MANAGER
	}
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(key)
	if err != nil {
		utils.LogErrorF("获取成为房管消息model失败,err:%s", err.Error())
		return
	}
	var cmdObjs []*redismodels.MsgUserObj
	cmdObjs = append(cmdObjs, &redismodels.MsgUserObj{UserId: cmdObj.UserID, NickName: cmdObj.UserNickname, Role: role})
	msg := redismodels.LiveMsg{
		FromAccount: admin,
		Type:        redismodels.MSG_TYPE_MANAGER,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		CMD:         redismodels.CMD_TYPE_SET_ADMIN,
		Content:     msgModel.MsgContent,
		Wheat:       &redismodels.Wheat{},
		CmdObjs:     cmdObjs,
		MsgStyle: &redismodels.MsgStyle{
			PrimaryColor: redismodels.MSG_STYLE_PRIMARYCOLOR_WHITE,
			SecondColor:  redismodels.MSG_STYLE_SECOND_YELLOW,
		},
	}
	err = msg.SendLiveMsg(strconv.Itoa(int(liveRoom.RoomId)))
	if err != nil {
		utils.LogErrorF("发送成为房管推送失败,err:%s", err.Error())
	}
	return
}

// 取消房管
// role 用户身份
func (s LiveMsg) AnnounceCancelManager(liveRoom *dbmodels.AppLiveRoom, cmdObj *redismodels.UserInfo) {
	var cmdObjs []*redismodels.MsgUserObj
	cmdObjs = append(cmdObjs, &redismodels.MsgUserObj{UserId: cmdObj.UserID, NickName: cmdObj.UserNickname})
	msg := redismodels.LiveMsg{
		Type:        redismodels.MSG_TYPE_MANAGER,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		CMD:         redismodels.CMD_TYPE_CANCEL_ADMIN,
		Wheat:       &redismodels.Wheat{},
		CmdObjs:     cmdObjs,
		MsgStyle: &redismodels.MsgStyle{
			PrimaryColor: redismodels.MSG_STYLE_PRIMARYCOLOR_WHITE,
			SecondColor:  redismodels.MSG_STYLE_SECOND_YELLOW,
		},
	}
	err := msg.SendLiveMsg(strconv.Itoa(int(liveRoom.RoomId)))
	if err != nil {
		utils.LogErrorF("发送取消房管推送失败,err:%s", err.Error())
	}
	return
}

// 被提出房间
func (s LiveMsg) AssistantBeKick(liveRoom *dbmodels.AppLiveRoom, userId string, endT int64, role int) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_LIVE_BE_KICK)
	if err != nil {
		utils.LogErrorF("获取被踢房间消息model失败,err:%s", err.Error())
		return
	}

	tmStr := utils.MsgTimeFormatSecond(endT)
	tip := strings.NewReplacer("${room_name}", liveRoom.RoomName, "${kick_time_seconds}", tmStr, "${admin_role}", GetRoleName(role)).Replace(msgModel.MsgContent)
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TEXT,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId)
	if err != nil {
		utils.LogErrorF("发送被踢房间推送失败,err:%s", err.Error())
	}
	return
}

// 被拉黑
func (s LiveMsg) AssistantBeBan(liveRoom *dbmodels.AppLiveRoom, userId string, role int) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_LIVE_BE_BAN)
	if err != nil {
		utils.LogErrorF("获取被拉黑消息model失败,err:%s", err.Error())
		return
	}

	tip := strings.NewReplacer("${room_name}", liveRoom.RoomName, "${admin_role}", GetRoleName(role)).Replace(msgModel.MsgContent)
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TEXT,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId)
	if err != nil {
		utils.LogErrorF("发送被拉黑推送失败,err:%s", err.Error())
	}
	return
}

// 被禁言
func (s LiveMsg) AssistantBeMute(liveRoom *dbmodels.AppLiveRoom, userId string, endT int64, role int) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_LIVE_BE_MUTE)
	if err != nil {
		utils.LogErrorF("获取被禁言消息model失败,err:%s", err.Error())
		return
	}

	tmStr := utils.MsgTimeFormatSecond(endT)
	tip := strings.NewReplacer("${room_name}", liveRoom.RoomName, "${mute_time_seconds}", tmStr, "${admin_role}", GetRoleName(role)).Replace(msgModel.MsgContent)
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TEXT,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId)
	if err != nil {
		utils.LogErrorF("发送被禁言推送失败,err:%s", err.Error())
	}
	return
}

// 取消被提出房间
func (s LiveMsg) AssistantCancelKick(liveRoom *dbmodels.AppLiveRoom, userId string, role int) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_LIVE_CANCEL_KICK)
	if err != nil {
		utils.LogErrorF("获取取消被踢房间消息model失败,err:%s", err.Error())
		return
	}

	tip := strings.NewReplacer("${room_name}", liveRoom.RoomName, "${admin_role}", GetRoleName(role)).Replace(msgModel.MsgContent)
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TEXT,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId)
	if err != nil {
		utils.LogErrorF("发送被踢房间推送失败,err:%s", err.Error())
	}
	return
}

// 被拉黑
func (s LiveMsg) AssistantCancelBan(liveRoom *dbmodels.AppLiveRoom, userId string, role int) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_LIVE_CANCEL_BAN)
	if err != nil {
		utils.LogErrorF("获取取消被拉黑消息model失败,err:%s", err.Error())
		return
	}

	tip := strings.NewReplacer("${room_name}", liveRoom.RoomName, "${admin_role}", GetRoleName(role)).Replace(msgModel.MsgContent)
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TEXT,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId)
	if err != nil {
		utils.LogErrorF("发送取消被拉黑推送失败,err:%s", err.Error())
	}
	return
}

// 取消禁言
func (s LiveMsg) AssistantCancelMute(liveRoom *dbmodels.AppLiveRoom, userId string, role int) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_LIVE_CANCEL_MUTE)
	if err != nil {
		utils.LogErrorF("获取被禁言消息model失败,err:%s", err.Error())
		return
	}

	tip := strings.NewReplacer("${room_name}", liveRoom.RoomName, "${admin_role}", GetRoleName(role)).Replace(msgModel.MsgContent)
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TEXT,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId)
	if err != nil {
		utils.LogErrorF("发送被禁言推送失败,err:%s", err.Error())
	}
	return
}

// 开播提醒
func (s LiveMsg) AssistantLiveStart(liveRoom *dbmodels.AppLiveRoom, userInfo *redismodels.UserInfo) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_LIVE_START_LIVE)
	if err != nil {
		utils.LogErrorF("获取开播消息消息model失败,err:%s", err.Error())
		return
	}
	roomIdStr := strconv.Itoa(int(liveRoom.RoomId))
	userIdStr := strconv.Itoa(int(userInfo.UserID))
	tip := strings.NewReplacer(redismodels.MSG_PLACEHOLDER_ANCHOR_NAME, userInfo.UserNickname).Replace(msgModel.MsgContent)
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_ACTION,
		ActionType:        redismodels.MSG_ACTION_TYPE_LIVR_ROOM,
		Action:            roomIdStr,
		Title:             msgModel.MsgTitle,
		Text:              tip,
		ActionParams:      map[string]interface{}{"room_id": liveRoom.RoomId},
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err = msg.AssistantMsg.PushAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userIdStr)
	if err != nil {
		utils.LogErrorF("发送开播消息消息推送失败,err:%s", err.Error())
	}
	return
}

// 踢人
func (s LiveMsg) AnnounceKick(liveRoom *dbmodels.AppLiveRoom, cmdObj *redismodels.UserInfo, start, end int64, wheat *redismodels.Wheat, admin *redismodels.MsgUserObj) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(LIVE_KEY_SET_KICK)
	if err != nil {
		utils.LogErrorF("获取踢人消息model失败,err:%s", err.Error())
		return
	}
	var cmdObjs []*redismodels.MsgUserObj
	cmdObjs = append(cmdObjs, &redismodels.MsgUserObj{UserId: cmdObj.UserID, NickName: cmdObj.UserNickname})
	msg := redismodels.LiveMsg{
		FromAccount:  admin,
		Type:         redismodels.MSG_TYPE_KICK,
		ContentType:  redismodels.CONTENT_TYPE_CMD,
		CMD:          redismodels.CMD_TYPE_KICK,
		Content:      msgModel.MsgContent,
		Wheat:        wheat,
		CmdObjs:      cmdObjs,
		CmdStartTime: start,
		CmdEntTime:   end,
		MsgStyle: &redismodels.MsgStyle{
			PrimaryColor: redismodels.MSG_STYLE_PRIMARYCOLOR_WHITE,
			SecondColor:  redismodels.MSG_STYLE_SECOND_YELLOW,
		},
	}
	err = msg.SendLiveMsg(strconv.Itoa(int(liveRoom.RoomId)))
	if err != nil {
		utils.LogErrorF("发送踢人推送失败,err:%s", err.Error())
	}
	return
}

// 拉黑
func (s LiveMsg) AnnounceForbidden(liveRoom *dbmodels.AppLiveRoom, cmdObj *redismodels.UserInfo, wheat *redismodels.Wheat, admin *redismodels.MsgUserObj) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(LIVE_KEY_SET_FORBIDDEN)
	if err != nil {
		utils.LogErrorF("获取拉黑消息model失败,err:%s", err.Error())
		return
	}
	var cmdObjs []*redismodels.MsgUserObj
	cmdObjs = append(cmdObjs, &redismodels.MsgUserObj{UserId: cmdObj.UserID, NickName: cmdObj.UserNickname})
	msg := redismodels.LiveMsg{
		FromAccount: admin,
		Type:        redismodels.MSG_TYPE_FORBID,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		CMD:         redismodels.CMD_TYPE_FORBID,
		Content:     msgModel.MsgContent,
		Wheat:       wheat,
		CmdObjs:     cmdObjs,
		MsgStyle: &redismodels.MsgStyle{
			PrimaryColor: redismodels.MSG_STYLE_PRIMARYCOLOR_WHITE,
			SecondColor:  redismodels.MSG_STYLE_SECOND_YELLOW,
		},
	}
	err = msg.SendLiveMsg(strconv.Itoa(int(liveRoom.RoomId)))
	if err != nil {
		utils.LogErrorF("发送拉黑推送失败,err:%s", err.Error())
	}
	utils.LogInfoF("发送房间[%d]拉黑信息成功", liveRoom.RoomId)
	return
}

// 禁言
func (s LiveMsg) AnnounceMute(liveRoom *dbmodels.AppLiveRoom, cmdObj *redismodels.UserInfo, start, end int64, admin *redismodels.MsgUserObj) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(LIVE_KEY_SET_MUTE)
	if err != nil {
		utils.LogErrorF("获取禁言消息model失败,err:%s", err.Error())
		return
	}
	var cmdObjs []*redismodels.MsgUserObj
	cmdObjs = append(cmdObjs, &redismodels.MsgUserObj{UserId: cmdObj.UserID, NickName: cmdObj.UserNickname})
	msg := redismodels.LiveMsg{
		FromAccount:  admin,
		Type:         redismodels.MSG_TYPE_MUTE,
		ContentType:  redismodels.CONTENT_TYPE_CMD,
		CMD:          redismodels.CMD_TYPE_MUTE,
		Content:      msgModel.MsgContent,
		Wheat:        &redismodels.Wheat{},
		CmdObjs:      cmdObjs,
		CmdStartTime: start,
		CmdEntTime:   end,
		MsgStyle: &redismodels.MsgStyle{
			PrimaryColor: redismodels.MSG_STYLE_PRIMARYCOLOR_WHITE,
			SecondColor:  redismodels.MSG_STYLE_SECOND_YELLOW,
		},
	}
	err = msg.SendLiveMsg(strconv.Itoa(int(liveRoom.RoomId)))
	if err != nil {
		utils.LogErrorF("发送禁言推送失败,err:%s", err.Error())
	}
	return
}

// 取消禁言
func (s LiveMsg) AnnounceUnmute(liveRoom *dbmodels.AppLiveRoom, cmdObj *redismodels.UserInfo, admin *redismodels.MsgUserObj) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(LIVE_KEY_SET_UNMUTE)
	if err != nil {
		utils.LogErrorF("获取拉黑消息model失败,err:%s", err.Error())
		return
	}
	var cmdObjs []*redismodels.MsgUserObj
	cmdObjs = append(cmdObjs, &redismodels.MsgUserObj{UserId: cmdObj.UserID, NickName: cmdObj.UserNickname})
	msg := redismodels.LiveMsg{
		FromAccount: admin,
		Type:        redismodels.MSG_TYPE_MUTE,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		CMD:         redismodels.CMD_TYPE_UNMUTE,
		Content:     msgModel.MsgContent,
		Wheat:       &redismodels.Wheat{},
		CmdObjs:     cmdObjs,
		MsgStyle: &redismodels.MsgStyle{
			PrimaryColor: redismodels.MSG_STYLE_PRIMARYCOLOR_WHITE,
			SecondColor:  redismodels.MSG_STYLE_SECOND_YELLOW,
		},
	}
	err = msg.SendLiveMsg(strconv.Itoa(int(liveRoom.RoomId)))
	if err != nil {
		utils.LogErrorF("发送拉黑推送失败,err:%s", err.Error())
	}
	return
}

// 取消拉黑
func (s LiveMsg) AnnounceUnForbidden(liveRoom *dbmodels.AppLiveRoom, cmdObj *redismodels.UserInfo) {
	var cmdObjs []*redismodels.MsgUserObj
	cmdObjs = append(cmdObjs, &redismodels.MsgUserObj{UserId: cmdObj.UserID, NickName: cmdObj.UserNickname})
	msg := redismodels.LiveMsg{
		Type:        redismodels.MSG_TYPE_FORBID,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		CMD:         redismodels.CMD_TYPE_UNFORBID,
		Wheat:       &redismodels.Wheat{},
		CmdObjs:     cmdObjs,
		MsgStyle: &redismodels.MsgStyle{
			PrimaryColor: redismodels.MSG_STYLE_PRIMARYCOLOR_WHITE,
			SecondColor:  redismodels.MSG_STYLE_SECOND_YELLOW,
		},
	}
	err := msg.SendLiveMsg(strconv.Itoa(int(liveRoom.RoomId)))
	if err != nil {
		utils.LogErrorF("发送拉黑推送失败,err:%s", err.Error())
	}
	return
}

// 取消踢人
func (s LiveMsg) AnnounceUnKick(liveRoom *dbmodels.AppLiveRoom, cmdObj *redismodels.UserInfo, start, end int64) {
	var cmdObjs []*redismodels.MsgUserObj
	cmdObjs = append(cmdObjs, &redismodels.MsgUserObj{UserId: cmdObj.UserID, NickName: cmdObj.UserNickname})
	msg := redismodels.LiveMsg{
		Type:         redismodels.MSG_TYPE_KICK,
		ContentType:  redismodels.CONTENT_TYPE_CMD,
		CMD:          redismodels.CMD_TYPE_UNKICK,
		Wheat:        &redismodels.Wheat{},
		CmdObjs:      cmdObjs,
		CmdStartTime: start,
		CmdEntTime:   end,
		MsgStyle: &redismodels.MsgStyle{
			PrimaryColor: redismodels.MSG_STYLE_PRIMARYCOLOR_WHITE,
			SecondColor:  redismodels.MSG_STYLE_SECOND_YELLOW,
		},
	}
	err := msg.SendLiveMsg(strconv.Itoa(int(liveRoom.RoomId)))
	if err != nil {
		utils.LogErrorF("发送取消踢人推送失败,err:%s", err.Error())
	}
	return
}

// 上下麦位
func (s LiveMsg) AnnounceUpDownWheat(liveRoom *dbmodels.AppLiveRoom, wheat *redismodels.Wheat, action int, userId int64) {
	msg := redismodels.LiveMsg{
		Type:        redismodels.MSG_TYPE_MIC,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		Wheat:       wheat,
	}
	if action == redismodels.WHEAT_DOWN {
		// 下麦
		msg.CMD = redismodels.CMD_TYPE_MIC_OFF
	} else {
		// 上麦
		msg.CMD = redismodels.CMD_TYPE_MIC_ON
	}
	info, err := new(redismodels.MsgUserObj).GetMsgUserInfo(userId, map[string]bool{"icon": true})
	if err != nil {
		utils.LogErrorF("发送上下麦位推送失败,err:%s", err.Error())
		return
	}
	msg.FromAccount = &info
	err = msg.SendLiveMsg(strconv.Itoa(int(liveRoom.RoomId)))
	if err != nil {
		utils.LogErrorF("发送上下麦位推送失败,err:%s", err.Error())
	}
	return
}

// 解锁/锁定麦位
func (s LiveMsg) AnnounceLockUnlockWheat(liveRoom *dbmodels.AppLiveRoom, wheat *redismodels.Wheat, action int) {
	msg := redismodels.LiveMsg{
		Type:        redismodels.MSG_TYPE_MIC,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		Wheat:       wheat,
	}
	if action == redismodels.WHEAT_STATUS_UNLOCK {
		msg.CMD = redismodels.CMD_TYPE_MIC_UNLOCK
	} else {
		msg.CMD = redismodels.CMD_TYPE_MIC_LOCK
	}

	err := msg.SendLiveMsg(strconv.Itoa(int(liveRoom.RoomId)))
	if err != nil {
		utils.LogErrorF("发送解锁/锁定麦位推送失败,err:%s", err.Error())
	}
	return
}

// 更新麦序列表
func (s LiveMsg) AnnounceUpdateWheatQueue(liveRoom *dbmodels.AppLiveRoom, wheatQueue interface{}, action int) {
	msg := redismodels.LiveMsg{
		Type:        redismodels.MSG_TYPE_MIC,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		WheatQueue:  wheatQueue,
	}
	switch action {
	case redismodels.WHEAT_QUEUE_ACTION_ADD: // 增加
		msg.CMD = redismodels.CMD_TYPE_MIC_APPLY
	case redismodels.WHEAT_QUEUE_ACTION_DEL: // 删除
		msg.CMD = redismodels.CMD_TYPE_MIC_QUIT
	default: // 清空
		msg.CMD = redismodels.CMD_TYPE_MIC_WAIT_CLEAR
	}
	err := msg.SendLiveMsg(strconv.Itoa(int(liveRoom.RoomId)))
	if err != nil {
		utils.LogErrorF("发送更新麦序列表推送失败,err:%s", err.Error())
	}
	return
}

// 取消排麦
func (s LiveMsg) AnnounceChancelWheatQueue(liveRoom *dbmodels.AppLiveRoom, wheatQueue interface{}) {
	msg := redismodels.LiveMsg{
		Type:        redismodels.MSG_TYPE_MIC,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		WheatQueue:  wheatQueue,
		CMD:         redismodels.CMD_TYPE_MIC_QUIT,
	}
	err := msg.SendLiveMsg(strconv.Itoa(int(liveRoom.RoomId)))
	if err != nil {
		utils.LogErrorF("发送取消排麦推送失败,err:%s", err.Error())
	}
	return
}

// 开关麦位
func (s LiveMsg) AnnounceSwitchWheat(liveRoom *dbmodels.AppLiveRoom, wheat *redismodels.Wheat, action int) {
	msg := redismodels.LiveMsg{
		Type:        redismodels.MSG_TYPE_MIC,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		Wheat:       wheat,
	}
	if action == 1 {
		msg.CMD = redismodels.CMD_TYPE_WHEAT_ON
	} else {
		msg.CMD = redismodels.CMD_TYPE_WHEAT_OFF
	}

	err := msg.SendLiveMsg(strconv.Itoa(int(liveRoom.RoomId)))
	if err != nil {
		utils.LogErrorF("发送开关麦位推送失败,err:%s", err.Error())
	}
	return
}

// 开关禁麦
func (s LiveMsg) AnnounceSwitchBanWheat(liveRoom *dbmodels.AppLiveRoom, wheat *redismodels.Wheat, action int, userId int64) {
	msg := redismodels.LiveMsg{
		Type:        redismodels.MSG_TYPE_MIC,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		Wheat:       wheat,
	}
	if action == redismodels.WHEAT_STATUS_UNLOCK {
		// 取消禁麦
		msg.CMD = redismodels.MIC_CANCEL_BAN_WHEAT
	} else {
		// 禁麦
		msg.CMD = redismodels.CMD_TYPE_MIC_BAN_WHEAT
	}
	info, err := new(redismodels.MsgUserObj).GetMsgUserInfo(userId, map[string]bool{"icon": true})
	if err != nil {
		utils.LogErrorF("发送开关禁麦麦推送失败,err:%s", err.Error())
		return
	}
	msg.FromAccount = &info

	err = msg.SendLiveMsg(strconv.Itoa(int(liveRoom.RoomId)))
	if err != nil {
		utils.LogErrorF("发送开关禁麦麦推送失败,err:%s", err.Error())
	}
	return
}

func (s LiveMsg) SendGiftGetPkInfo(liveRoom *dbmodels.AppLiveRoom, propInfo []*redismodels.MsgPropObj, fromAccount *redismodels.MsgUserObj, msg *redismodels.LiveMsg) {
	roomIdStr := strconv.Itoa(int(liveRoom.RoomId))
	if liveRoom.RoomPkSwitch != dbmodels.RoomPkFunctionOpen {
		return
	}
	if liveRoom.RoomPkState == dbmodels.RoomPkCloseStage || liveRoom.RoomPkState == dbmodels.RoomPkReadyStage {
		return
	}
	pkInfo, err := new(redismodels.RoomPkDetail).GetRoomPkInfo(liveRoom.RoomId)
	if err != nil {
		utils.LogErrorF("获取房间[%d]pk信息失败,err:%s", liveRoom.RoomId, err.Error())
		return
	}
	// 获取本次加的pk值
	for _, v := range propInfo {
		switch v.Position {
		case 1, 2, 3, 4:
			pkInfo.RoomPKDetailRed += v.AddLoveValue
		case 5, 6, 7, 8:
			pkInfo.RoomPKDetailBlue += v.AddLoveValue
		}
	}
	msg.LiveInfo.RoomGloryStar = pkInfo.RoomPkDetailGloryStar
	msg.LiveInfo.RoomPKDetailRed = pkInfo.RoomPKDetailRed
	msg.LiveInfo.RoomPKDetailBlue = pkInfo.RoomPKDetailBlue
	msg.LiveInfo.RoomPKRemainingTime = pkInfo.RoomPKDetailExpectedEnd - time.Now().Unix()
	// 判断财富值是否达标
	wealth := utils.RedisClient.ZScore(utils.RedisRoomPkGloryStar+roomIdStr, strconv.Itoa(int(fromAccount.UserId))).Val()
	fromAccountWealth := int64(wealth) + propInfo[0].FromAccountWealth
	// 如果已经超了当前的闪耀之星，则替换为送礼者
	if fromAccountWealth > pkInfo.RoomPkDetailGloryStarValue && fromAccountWealth > redismodels.MIN_GLORY_SCORE_VALUE &&
		liveRoom.RoomPkState == dbmodels.RoomPkStartStage {
		msg.LiveInfo.RoomGloryStar = *fromAccount
	}
	return
}

// 赠送礼物消息
func (s LiveMsg) AnnounceSendGift(liveRoom *dbmodels.AppLiveRoom, propInfo []*redismodels.MsgPropObj, fromAccount *redismodels.MsgUserObj) {
	key := LIVE_KEY_SEND_GIFT
	if len(propInfo) > 1 {
		key = LIVE_KEY_SEND_GIFTS
	}
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(key)
	if err != nil {
		utils.LogErrorF("获取礼物消息model失败,err:%s", err.Error())
		return
	}
	roomIdStr := strconv.Itoa(int(liveRoom.RoomId))
	msg := redismodels.LiveMsg{
		FromAccount: fromAccount,
		Type:        redismodels.MSG_TYPE_GIFT,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		CMD:         redismodels.CMD_TYPE_GIFT_SEND,
		GiftInfo:    propInfo,
		Content:     msgModel.MsgContent,
		LiveInfo: &redismodels.LiveInfo{
			RoomId:             liveRoom.RoomId,
			RoomPrettyId:       liveRoom.RoomPrettyId,
			RoomType:           liveRoom.RoomType,
			RoomName:           liveRoom.RoomName,
			RoomCover:          liveRoom.RoomCover,
			RoomBackground:     liveRoom.RoomBackground,
			RoomTitle:          liveRoom.RoomTitle,
			RoomContent:        liveRoom.RoomContent,
			RoomUnionId:        liveRoom.RoomUnionId,
			RoomUserId:         liveRoom.RoomUserId,
			RoomAttrId:         liveRoom.RoomAttrId,
			RoomAttrName:       liveRoom.RoomLiveAttr.AttrName,
			RoomSpeakType:      liveRoom.RoomSpeakType,
			RoomOpenIm:         liveRoom.RoomOpenIm,
			RoomPkSwitch:       liveRoom.RoomPkSwitch,
			RoomLiveStatus:     liveRoom.RoomLiveStatus,
			RoomLastOnline:     liveRoom.RoomLastOnline,
			RoomEggbreakMsg:    liveRoom.RoomEggbreakMsg,
			RoomPkRecordTime:   liveRoom.RoomPkRecordTime,
			RoomPkRecordPunish: liveRoom.RoomPkRecordPunish,
			RoomPkState:        liveRoom.RoomPkState,
		},
	}
	s.SendGiftGetPkInfo(liveRoom, propInfo, fromAccount, &msg)
	err = msg.SendLiveMsg(roomIdStr)
	if err != nil {
		utils.LogErrorF("发送礼物消息推送失败,err:%s", err.Error())
	}
	return
}

// 送礼跑马灯消息
func (s LiveMsg) HeadlineMsgSendGift(liveRoom *dbmodels.AppLiveRoom, propInfo []*redismodels.MsgPropObj, fromAccount *redismodels.MsgUserObj, prop *dbmodels.AppProp) {
	roomIdStr := strconv.Itoa(int(liveRoom.RoomId))
	headlineModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(HEADLINE_KEY_SEND_GIFT)
	if err != nil {
		utils.LogErrorF("获取礼物消息跑马灯model失败,err:%s", err.Error())
		return
	}
	job := redismodels.HeadlineJob{
		LiveRoomId:   liveRoom.RoomId,
		LiveRoomType: liveRoom.RoomType,
		Job: redismodels.HeadlineMsg{
			FromAccount: fromAccount,
			Type:        redismodels.HEADLINE_MSG_TYPE_GIFT,
			Action:      roomIdStr,
			ActionType:  redismodels.HEADLINE_ACTION_TYPE_LIVE_ROOM,
			Repeat:      1,
			GiftInfo:    propInfo,
			Content:     headlineModel.MsgContent,
		},
		TagId: liveRoom.RoomAttrId,
	}
	if propInfo[0].PropInfo.PropCount >= prop.PropRadioCount3 {
		if prop.PropRadioCount3 != 0 {
			job.Type = redismodels.HEADLINE_JOB_TYPE_ALL
			job.Job.Level = redismodels.HEADLINE_LEVEL_CHANNEL
			job.PushMq(redismodels.HEADLINE_MSG_TOPIC)
			return
		}
	}
	if propInfo[0].PropInfo.PropCount >= prop.PropRadioCount2 {
		if prop.PropRadioCount2 != 0 {
			job.Type = redismodels.HEADLINE_JOB_TYPE_TAG
			job.Job.Level = redismodels.HEADLINE_LEVEL_CHILD_CHANNEL
			job.PushMq(redismodels.HEADLINE_MSG_TOPIC)
			return
		}
	}
	if propInfo[0].PropInfo.PropCount >= prop.PropRadioCount1 {
		if prop.PropRadioCount1 != 0 {
			job.Type = redismodels.HEADLINE_JOB_TYPE_ROOM
			job.Job.Level = redismodels.HEADLINE_LEVEL_ROOM
			job.PushMq(redismodels.HEADLINE_MSG_TOPIC)
			return
		}
	}
	return
}

// 砸蛋跑马灯消息
func (s LiveMsg) HeadlineMsgBreakEgg(roomData *dbmodels.AppLiveRoom, triggerMsgUserObj *redismodels.MsgUserObj, headlineNtcPropInfos []*redismodels.PropInfo) {
	roomIdStr := strconv.Itoa(int(roomData.RoomId))
	headlineModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(HEADLINE_KEY_BREAK_EGG)
	if err != nil {
		utils.LogErrorF("获取砸蛋消息跑马灯model失败,err:%s", err.Error())
		return
	}

	var length = len(headlineNtcPropInfos)
	for i := 0; i < length; i++ {
		job := redismodels.HeadlineJob{
			Type:       redismodels.HEADLINE_JOB_TYPE_ALL,
			LiveRoomId: roomData.RoomId,
			Job: redismodels.HeadlineMsg{
				Type:        redismodels.HEADLINE_MSG_TYPE_EGG_BREAK,
				Level:       redismodels.HEADLINE_LEVEL_CHANNEL,
				Action:      roomIdStr,
				ActionType:  redismodels.HEADLINE_ACTION_TYPE_LIVE_ROOM,
				Repeat:      1,
				FromAccount: triggerMsgUserObj,
				LiveInfo: &redismodels.LiveInfo{
					RoomId:   roomData.RoomId,
					RoomType: roomData.RoomType,
					RoomName: roomData.RoomName,
				},
				PropInfo: headlineNtcPropInfos[i : i+1],
				Content:  headlineModel.MsgContent,
			},
			TagId: roomData.RoomAttrId,
		}
		switch headlineNtcPropInfos[i].PropGetRadio1 {
		case 1:
			job.Type = redismodels.HEADLINE_JOB_TYPE_ROOM
			job.Job.Level = redismodels.HEADLINE_LEVEL_ROOM
		case 2:
			job.Type = redismodels.HEADLINE_JOB_TYPE_TAG
			job.Job.Level = redismodels.HEADLINE_LEVEL_CHILD_CHANNEL
		case 3:
			job.Type = redismodels.HEADLINE_JOB_TYPE_ALL
			job.Job.Level = redismodels.HEADLINE_LEVEL_CHANNEL
		default:
			continue
		}
		job.PushMq(redismodels.HEADLINE_MSG_TOPIC)
	}
}

// InvitedWheat 邀请上麦推送
func (s LiveMsg) InvitedWheat(invitedInfo *redismodels.InviteUpWheat) {
	msg := redismodels.LiveMsg{
		Type:          redismodels.MSG_TYPE_MIC,
		ContentType:   redismodels.CONTENT_TYPE_CMD,
		CMD:           redismodels.CMD_TYPE_LIVE_INVITED_USER_MIC,
		InviteUpWheat: invitedInfo,
	}

	err := msg.SendLiveMsg(strconv.Itoa(int(invitedInfo.RoomId)))
	if err != nil {
		utils.LogErrorF("发送邀请上麦信息推送失败,err:%s", err.Error())
	}
	return
}

// AnnouncePkSwitch 开启/关闭pk推送
func (s LiveMsg) AnnouncePkSwitch(wheat *redismodels.Wheat, liveInfo *redismodels.LiveInfo, close bool) {
	msg := redismodels.LiveMsg{
		Type:        redismodels.MSG_TYPE_PK,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		CMD:         redismodels.CMD_TYPE_LIVE_PK_SWITCH_ON,
		LiveInfo:    liveInfo,
		// 这里是最新的房间信息，请传更新过后的房间信息
		Wheat: wheat,
	}
	if close {
		msg.CMD = redismodels.CMD_TYPE_LIVE_PK_SWITCH_OFF
	}
	err := msg.SendLiveMsg(strconv.Itoa(int(liveInfo.RoomId)))
	if err != nil {
		utils.LogErrorF("发送开启关闭pk信息推送失败,err:%s", err.Error())
	}
	return
}

// AnnouncePkFinished pk结束推送
func (s LiveMsg) AnnouncePkFinished(wheat *redismodels.Wheat, liveInfo *redismodels.LiveInfo, sysFinished bool) {
	// sysFinished 1手动结束，0系统结束
	msg := redismodels.LiveMsg{
		Type:        redismodels.MSG_TYPE_PK,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		CMD:         redismodels.CMD_TYPE_LIVE_PK_SYS_FINISHED,
		LiveInfo:    liveInfo,
		// 这里是最新的房间信息，请传更新过后的房间信息
		Wheat: wheat,
	}
	if !sysFinished {
		msg.CMD = redismodels.CMD_TYPE_LIVE_PK_ADVANCE_FINISHED
		msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(LIVE_KEY_PK_ADVANCE_FINISHED)
		if err != nil {
			utils.LogErrorF("获取系统结束pkmodel失败,err:%s", err.Error())
			return
		}
		msg.Content = msgModel.MsgContent
	} else {
		// 获取pk详情
		pkInfo, err := new(redismodels.RoomPkDetail).GetRoomPkInfo(liveInfo.RoomId)
		if err != nil {
			utils.LogErrorF("获取系统结束pk详情失败,err:%s", err.Error())
			return
		}
		liveInfo.RoomPKMvpId = pkInfo.RoomPKMvpId
		liveInfo.RoomPKSvpId = pkInfo.RoomPKSvpId
		liveInfo.RoomPKDetailRed = pkInfo.RoomPKDetailRed
		liveInfo.RoomPKDetailBlue = pkInfo.RoomPKDetailBlue
		liveInfo.RoomPKCharmKingId = pkInfo.RoomPKCharmKingId
		liveInfo.RoomGloryStar = pkInfo.RoomPkDetailGloryStar

	}
	err := msg.SendLiveMsg(strconv.Itoa(int(liveInfo.RoomId)))
	if err != nil {
		utils.LogErrorF("发送结束pk推送失败,err:%s", err.Error())
	}
	return
}

// AnnounceExtendPkTime 延迟时长
func (s LiveMsg) AnnounceExtendPkTime(roomId, duration int64) {
	msg := redismodels.LiveMsg{
		Type:        redismodels.MSG_TYPE_PK,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		CMD:         redismodels.CMD_TYPE_LIVE_PK_EXTEND_TIME,
		CmdDuration: duration,
	}
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(LIVE_KEY_PK_EXTEND_TIME)
	if err != nil {
		utils.LogErrorF("获取延迟pkmodel失败,err:%s", err.Error())
		return
	}
	msg.Content = msgModel.MsgContent
	err = msg.SendLiveMsg(strconv.Itoa(int(roomId)))
	if err != nil {
		utils.LogErrorF("发送延迟pk信息推送失败,err:%s", err.Error())
	}
	return
}

// AnnouncePkPunishFinished pk惩罚结束推送
func (s LiveMsg) AnnouncePkPunishFinished(wheat *redismodels.Wheat, liveInfo *redismodels.LiveInfo) {
	// sysFinished 0手动结束，1系统结束
	msg := redismodels.LiveMsg{
		Type:        redismodels.MSG_TYPE_PK,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		CMD:         redismodels.CMD_TYPE_LIVE_PK_PUNISH_FINISHED,
		LiveInfo:    liveInfo,
		// 这里是最新的房间信息，请传更新过后的房间信息
		Wheat: wheat,
	}
	err := msg.SendLiveMsg(strconv.Itoa(int(liveInfo.RoomId)))
	if err != nil {
		utils.LogErrorF("发送结束pk惩罚推送失败,err:%s", err.Error())
	}
	return
}

// PK开始推送
func (s LiveMsg) AnnouncePkStart(wheat *redismodels.Wheat, liveInfo *redismodels.LiveInfo) {
	// sysFinished 0手动结束，1系统结束
	msg := redismodels.LiveMsg{
		Type:        redismodels.MSG_TYPE_PK,
		ContentType: redismodels.CONTENT_TYPE_CMD,
		CMD:         redismodels.CMD_TYPE_LIVE_PK_START,
		LiveInfo:    liveInfo,
		// 这里是最新的房间信息，请传更新过后的房间信息
		Wheat: wheat,
	}

	err := msg.SendLiveMsg(strconv.Itoa(int(liveInfo.RoomId)))
	if err != nil {
		utils.LogErrorF("发送开始pk推送失败,err:%s", err.Error())
	}
	return
}
