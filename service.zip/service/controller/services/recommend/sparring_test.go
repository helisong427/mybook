package recommend

import (
	"testing"
)

// 测试获取大神推荐
func TestGetCommend(t *testing.T) {
	// _, data, _ := new(dbmodels.AppSparringSkill).QueryNumberRand(30)
	// for _, v := range data {
	// 	s := SparringGlobal{
	// 		UserId:          v.SkillUserID,
	// 		SparringSkillId: v.SkillID,
	// 		SkillId:         v.SkillSkillID,
	// 		Fraction:        v.SkillID,
	// 	}
	// 	marshal, _ := json.Marshal(s)
	// 	utils.RedisClient.HSet(utils.REDIS_RECOMMEND_SPARRING_GLOBAL, fmt.Sprint(v.SkillID), string(marshal))
	//
	// 	utils.RedisClient.ZAdd(utils.REDIS_RECOMMEND_SPARRING_ONLINE, redis.Z{
	// 		Score:  float64(v.SkillID),
	// 		Member: v.SkillID,
	// 	})
	// }

	sp := GetRecommendParams{
		UserId:     10,
		TotalSize:  7,
		PositionId: []int64{},
	}
	recommend, err := NewSparring().GetRecommend(&sp)
	if err != nil {
		t.Log(err)
		return
	}
	t.Log(recommend)
}

// 测试获取大神推荐位
func TestGetIndexSparring(t *testing.T) {
	list, err := NewRecommendPosition().GetIndexSparring()
	if err != nil {
		t.Error(err)
		return
	}
	t.Log(list)
}

// 测试获取专属推荐位
func TestGetExclusiveRecommend(t *testing.T) {
	list, err := NewRecommendPosition().GetExclusiveRecommend(1, 1)
	if err != nil {
		t.Error(err)
		return
	}
	t.Log(list)
	t.Log("OK")
}

// 测试删除推荐位
func TestDelPosition(t *testing.T) {
	NewSparring().RemoveCache(331, 1)
}
