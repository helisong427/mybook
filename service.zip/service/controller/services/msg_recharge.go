package services

import (
	"fmt"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"strconv"
	"strings"
)

const ASSISTANT_RECHARGE_OK = "assistant_recharge_ok"
const ASSISTANT_FIRST_RECHARGE = "assistant_first_recharge"

type RechargeMsg struct {
}

func InitRechargeMsg() RechargeMsg {
	return RechargeMsg{}
}

// 充值成功
func (m RechargeMsg) AssistantRechargeOk(userId, amount int64) {
	key := ASSISTANT_RECHARGE_OK
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(key)
	if err != nil {
		utils.LogErrorF("获取充值成功消息model失败,err:%s", err.Error())
		return
	}
	userIdStr := strconv.Itoa(int(userId))
	amountStr := fmt.Sprintf("%d", amount/100)
	tip := strings.NewReplacer("${amount}", amountStr).Replace(msgModel.MsgContent)
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userIdStr)
	if err != nil {
		utils.LogErrorF("发送充值成功推送失败,err:%s", err.Error())
	}
	return
}

// 首充
func (m RechargeMsg) AssistantFirstRecharge(userId int64) {
	key := ASSISTANT_FIRST_RECHARGE
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(key)
	if err != nil {
		utils.LogErrorF("获取充值成功消息model失败,err:%s", err.Error())
		return
	}
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              msgModel.MsgContent,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, fmt.Sprint(userId))
	if err != nil {
		utils.LogErrorF("发送首充推送失败,err:%s", err.Error())
	}
	return
}
