package services

import (
	"encoding/json"
	"errors"
	"fmt"
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/enum"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/mq/rabbitmqProducer"
	"gamers/utils"
	"strconv"
	"strings"
	"time"

	"gorm.io/gorm"
)

// 大神订单
type SkillOrder struct {
	Pay     // 支付(下单)
	Confirm // 接单
	Cancel  // 取消
	Refund  // 退款
	Appeal  // 申诉
	Finish  // 完成
	Comment // 评价
	Settle  // 结算
}
type Pay struct{}
type Confirm struct{}
type Cancel struct{}
type Refund struct{}
type Appeal struct{}
type Finish struct{}
type Comment struct{}
type Settle struct{}

func NewSkillOrder() SkillOrder {
	return SkillOrder{}
}

func (Confirm) SparringContact() {
	fmt.Println("大神接单")
}

func (Confirm) SparringRefuse() {
	fmt.Println("大神拒绝")
}

// 系统取消订单
func (m Confirm) System(order dbmodels.AppSkillOrder) (err error) {
	tx := utils.GEngine.Begin()
	model := dbmodels.AppSkillOrder{}
	model.OrderStatus = dbmodels.SKILL_ORDER_STATUS_CANCEL              // 系统取消
	model.OrderCancelStatus = dbmodels.SKILL_ORDER_CANCEL_STATUS_SYSTEM // 系统取消
	model.OrderCancelTime = time.Now().Unix()
	model.OrderIsFinished = dbmodels.SKILL_ORDER_IS_FINISHED_OK
	err = model.Update(tx, order.OrderId)
	if err != nil {
		tx.Rollback()
		err = errors.New(fmt.Sprintf("取消订单失败,order_id = %d,err = %s", order.OrderId, err.Error()))
		return
	}
	// 操作用户余额
	wallet, err := new(dbmodels.AppUserWallet).UpdateWalletTotalOver(tx, int64(order.OrderBuyUserId), true, true, int64(order.OrderAmount))
	if err != nil {
		tx.Rollback()
		err = errors.New(fmt.Sprintf("取消订单失败,用户余额操作失败,order_id = %d,err = %s", order.OrderId, err.Error()))
		return
	}
	err = tx.Commit().Error
	if err != nil {
		return err
	}
	err = utils.RedisClient.HSet(utils.REDIS_USER_INFO+strconv.Itoa(int(order.OrderBuyUserId)), "WalletTotalOver", wallet.WalletTotalOver).Err()
	if err != nil {
		err = errors.New(fmt.Sprintf("更新用户[%d]余额失败, %s", order.OrderBuyUserId, err.Error()))
		return
	}

	go m.OrderSparringMsgConfirmTimeout(&order)
	go m.OrderUserMsgConfirmTimeout(&order)
	go m.SparringMsgConfirmTimeout(&order)
	go m.UserMsgConfirmTimeout(&order)
	return
}

// 申述超时系统处理
func (m Appeal) TimeOutSystem(order *dbmodels.AppSkillOrder) (err error) {
	tx := utils.GEngine
	order.OrderFinishTime = time.Now().Unix()
	order.OrderIsFinished = dbmodels.SKILL_ORDER_IS_FINISHED_OK          // 订单已完成
	order.OrderFinishStatus = dbmodels.SKILL_ORDER_FINISH_STATUS_SYSTEM  // 系统完成
	order.OrderAppealStatus = dbmodels.SKILL_ORDER_APPEAL_STATUS_USER_OK // 处理完成,用户胜利
	err = order.Update(tx, order.OrderId)
	if err != nil {
		tx.Rollback()
		err = fmt.Errorf("[申述超时系统处理]改变订单表申诉状态失败:[orderId = %d],[err = %s]", order.OrderId, err.Error())
		return err
	}

	_, data, err := new(dbmodels.AppSkillOrderAppeal).QueryByOrderId(order.OrderId)
	if err != nil {
		tx.Rollback()
		err = fmt.Errorf("[申述超时系统处理]查询订单申述信息失败:[orderId = %d],[err = %s]", order.OrderId, err.Error())
		return err
	}

	// 更新申述表
	update := make(map[string]interface{})
	update["appeal_process"] = "超时系统自动处理"
	update["appeal_process_time"] = time.Now().Unix()
	update["appeal_appeal_status"] = dbmodels.SKILL_APPEAL_STATUS_OK
	update["appeal_process_result"] = dbmodels.SKILL_APPEAL_RESULT_SUCCESS

	err = new(dbmodels.AppSkillOrderAppeal).Updates(tx, order.OrderId, update)
	if err != nil {
		tx.Rollback()
		err = fmt.Errorf("[申述超时系统处理]更新申述表失败:[orderId = %d],[err = %s]", order.OrderId, err.Error())
		return err
	}

	// 退款
	wallet, err := new(dbmodels.AppUserWallet).UpdateWalletTotalOver(tx, order.OrderBuyUserId, true, false, data.AppealCount)
	if err != nil {
		tx.Rollback()
		err = fmt.Errorf("[申述超时系统处理]退款失败:[orderId = %d],[err = %s]", order.OrderId, err.Error())
		return err
	}
	tx.Commit()

	// 增加缓存金额
	err = utils.RedisClient.HSet(fmt.Sprintf("%s%d", utils.REDIS_USER_INFO, order.OrderBuyUserId), "WalletTotalOver", wallet.WalletTotalOver).Err()
	if err != nil {
		err = errors.New(fmt.Sprintf("[申述超时系统处理]增加用户redis金额失败:[orderId = %d],[err = %s]", order.OrderId, err.Error()))
		return
	}

	// 发送消息
	m.SparringAppealTimeout(order)
	return
}

// 系统退款
func (m Refund) System(order dbmodels.AppSkillOrder) (err error) {
	tx := utils.GEngine.Begin()
	order.OrderStatus = dbmodels.SKILL_ORDER_STATUS_REFUND              // 系统退款完成
	order.OrderRefundStatus = dbmodels.SKILL_ORDER_REFUND_STATUS_SYS_OK // 退款完成
	order.OrderRefundTime = time.Now().Unix()
	order.OrderIsFinished = dbmodels.SKILL_ORDER_IS_FINISHED_OK
	err = order.Update(tx, order.OrderId)
	if err != nil {
		tx.Rollback()
		err = errors.New(fmt.Sprintf("取消订单失败:%s", err.Error()))
		return
	}

	// 查询退款订单的退款金额
	refundData, err := new(dbmodels.AppSkillOrderRefund).GetAppSkillOrderRefundById(order.OrderRefundId)
	if err != nil {
		tx.Rollback()
		err = errors.New(fmt.Sprintf("未查询到退款订单的信息:%s", err.Error()))
		return
	}

	// 操作用户余额
	wallet, err := new(dbmodels.AppUserWallet).UpdateWalletTotalOver(tx, order.OrderBuyUserId, true, true, int64(refundData.RefundCount))
	if err != nil {
		tx.Rollback()
		err = errors.New(fmt.Sprintf("用户余额操作失败:%s", err.Error()))
		return
	}
	err = tx.Commit().Error
	if err != nil {
		tx.Rollback()
		return
	}

	err = utils.RedisClient.HSet(utils.REDIS_USER_INFO+strconv.Itoa(int(order.OrderBuyUserId)), "WalletTotalOver", wallet.WalletTotalOver).Err()
	if err != nil {
		err = errors.New(fmt.Sprintf("更新用户[%d]余额失败, %s", order.OrderBuyUserId, err.Error()))
		return
	}
	go m.SparringRefundSys(&order)
	go m.UserRefundSys(&order)
	return
}

// 拒绝退款恢复
func (m Refund) SystemRecover(order dbmodels.AppSkillOrder) (err error) {
	tx := utils.GEngine.Begin()
	refundInfo, err := new(dbmodels.AppSkillOrderRefund).GetAppSkillOrderRefundById(order.OrderRefundId)
	if err != nil && err != gorm.ErrRecordNotFound {
		utils.LogErrorF("查询退款信息失败:%s", err.Error())
		return
	}
	if err != nil {
		utils.LogErrorF("未查询到退款信息失败:%s", err.Error())
		return
	}
	order.OrderStatus = refundInfo.RefundOldStatus // 系统退款完成
	order.OrderIsFinished = dbmodels.SKILL_ORDER_IS_FINISHED_NO
	err = order.Update(tx, order.OrderId)
	if err != nil {
		tx.Rollback()
		err = errors.New(fmt.Sprintf("更新订单失败:%s", err.Error()))
		return
	}

	err = tx.Commit().Error
	return
}

// 系统完成订单
func (Finish) System(orderId int64) (err error) {
	err = new(dbmodels.AppSkillOrder).SystemCompleteOrder(orderId)
	if err == nil {
		// 投递延迟任务,用于结算订单
		go func() {
			rabbitmqProducer.ProducerOrder(orderId, dbmodels.SKILL_ORDER_STATUS_FINISH, dbmodels.SKILL_ORDER_SETTLE_TIME)
			_, order, err := new(dbmodels.AppSkillOrder).QueryByOrderId(orderId)
			if err != nil {
				utils.LogErrorF("[系统完成订单查询订单]失败:[orderId:%d],[err:%s]", orderId, err.Error())
			}
			// 顺序发送订单完成 订单评价消息
			new(Finish).UserFinishBySys(&order)
			new(Finish).SendCommendMsgByUser(&order)
		}()
	}
	return
}

// 系统结算
func (Settle) System(order dbmodels.AppSkillOrder) (err error) {
	tx := utils.GEngine.Begin()
	model := dbmodels.AppSkillOrder{
		OrderStatus:       dbmodels.SKILL_ORDER_STATUS_SETTLEMENT,
		OrderSettleStatus: dbmodels.SKILL_ORDER_SETTLE_STATUS_SYS_OK,
		OrderSettleTime:   time.Now().Unix(),
		OrderIsFinished:   dbmodels.SKILL_ORDER_IS_FINISHED_OK,
	}
	err = model.Update(tx, order.OrderId)
	if err != nil {
		tx.Rollback()
		err = errors.New(fmt.Sprintf("[大神订单结算]结算失败, %s", err.Error()))
		return
	}

	err = new(dbmodels.AppUserWallet).UpdateUserSparringIncome(tx, true, order.OrderSellUserId, order.OrderIncome)
	if err != nil {
		tx.Rollback()
		err = errors.New(fmt.Sprintf("[大神订单结算]增加大神收益失败, %s", err.Error()))
		return
	}

	err = new(dbmodels.SystemUser).AddSkillOrderCount(tx, order.OrderSellUserId)
	if err != nil {
		tx.Rollback()
		err = errors.New(fmt.Sprintf("[大神订单结算]增加大神服务人次失败, %s", err.Error()))
		return
	}

	err = new(dbmodels.AppSparringSkill).AddSkillOrderCount(tx, order.OrderSparringSkillId)
	if err != nil {
		tx.Rollback()
		err = errors.New(fmt.Sprintf("[大神订单结算]增加大神技能服务人次失败, %s", err.Error()))
		return
	}
	now := time.Now().Unix()
	getInputDate, _ := time.ParseInLocation("2006-01-02 15:04:05", "2021-04-05 00:00:00", time.Local)
	// 当前时间大于2021-04-05日 增加公会收入
	if now >= getInputDate.Unix() && order.OrderSellUserUnionId != 0 && order.OrderUnionFee != 0 {
		err = new(dbmodels.AppUnionWithdrawalBalance).AddAmount(tx, order.OrderSellUserUnionId, order.OrderUnionFee)
		if err != nil {
			tx.Rollback()
			err = errors.New(fmt.Sprintf("[大神订单结算]增加公会收人失败, %s", err.Error()))
			return
		}
	}

	tx.Commit()
	go func() {
		vip := dbmodels.PushUserExperience{UserId: order.OrderBuyUserId, Experience: order.OrderAmount}
		vip.PushMq()
	}()
	return
}

// 提交订单
func (m Confirm) Commit(order *dbmodels.AppSkillOrder, sparring dbmodels.AppSparringSkill, userInfo redismodels.UserInfo) (err error) {
	// 数据库扣钱
	tx := utils.GEngine.Begin()
	wallet, err := new(dbmodels.AppUserWallet).UpdateWalletTotalOver(tx, order.OrderBuyUserId, false, true, order.OrderAmount)
	if err != nil {
		utils.LogErrorF("更新用户[%d]余额失败, %s", order.OrderBuyUserId, err.Error())
		tx.Rollback()
		return
	}
	// 创建订单
	err = order.Create(tx)
	if err != nil {
		tx.Rollback()
		return
	}
	var infos []dbmodels.AppSkillOrderInfo
	for _, v := range sparring.AppSparringSkillInfo {
		orderInfo := dbmodels.AppSkillOrderInfo{
			InfoOrderId:         order.OrderId,
			InfoSkillId:         order.OrderSkillId,
			InfoSparringSkillId: order.OrderSparringSkillId,
			InfoValueId:         v.InfoValueId,
			InfoValue:           v.AppSkillFieldValue.ValueValue,
			InfoField:           v.AppSkillFieldValue.ValueField,
			InfoFieldName:       v.AppSkillFieldValue.ValueFieldName,
		}
		infos = append(infos, orderInfo)
	}
	err = new(dbmodels.AppSkillOrderInfo).BatchSave(tx, infos)
	if err != nil {
		tx.Rollback()
		return
	}
	err = tx.Commit().Error
	if err != nil {
		tx.Rollback()
		return
	}
	err = utils.RedisClient.HSet(utils.REDIS_USER_INFO+strconv.Itoa(int(userInfo.UserID)), "WalletTotalOver", wallet.WalletTotalOver).Err()
	if err != nil {
		utils.LogErrorF("更新redis用户[%d]余额失败, %s", userInfo.UserID, err.Error())
		return
	}
	order.AppSkill = sparring.AppSkill
	go rabbitmqProducer.ProducerOrder(order.OrderId, order.OrderStatus, dbmodels.SKILL_ORDER_ORDER_TIME)
	go m.OrderMsgConfirmWaitAccept(order, &userInfo, &sparring)
	go m.SparringMsgConfirmWaitAccept(order)
	go m.UserMsgConfirmWaitAccept(order)
	go func() {
		_ = new(redismodels.Task).Init().ReportConditionTag(userInfo.UserID, "finishOrder", 1)
	}()

	// 向用户微信公众号推送订单提醒消息
	go SendTemplateMsg(dbmodels.SKILL_TYPE_ORIENTATION, []int64{sparring.SkillUserID}, time.Now().Unix(), order.OrderCount,
		sparring.SkillTitle, order.OrderWay, order.OrderAmount)

	// 投递语音提示消息
	rabbitmqProducer.ProducerVmsOrder(order.OrderId)
	return nil
}

// 拒绝接单
func (m Confirm) Refuse(orderInfo dbmodels.AppSkillOrder, userInfo redismodels.UserInfo) (err error) {
	// 大神取消
	orderInfo.OrderStatus = dbmodels.SKILL_ORDER_STATUS_CONFIRM
	// 大神取消直接退款
	orderInfo.OrderConfirmStatus = dbmodels.SKILL_ORDER_CONFIRM_STATUS_REFUSE

	tx := utils.GEngine.Begin()
	orderInfo.OrderConfirmTime = time.Now().Unix()
	orderInfo.OrderIsFinished = dbmodels.SKILL_ORDER_IS_FINISHED_OK
	err = orderInfo.Update(tx, orderInfo.OrderId)
	if err != nil {
		tx.Rollback()
		utils.LogErrorF("更新订单信息[%d]失败, %s", orderInfo.OrderId, err.Error())
		return
	}
	// 操作用户余额
	wallet, err := new(dbmodels.AppUserWallet).UpdateWalletTotalOver(tx, orderInfo.OrderBuyUserId, true, true, int64(orderInfo.OrderAmount))
	if err != nil {
		tx.Rollback()
		utils.LogErrorF("更新用户[%d]余额失败, %s", orderInfo.OrderBuyUserId, err.Error())
		return
	}
	err = tx.Commit().Error
	if err != nil {
		tx.Rollback()
		utils.LogErrorF("拒绝退款失败, %d, %s", orderInfo.OrderBuyUserId, err.Error())
		return
	}
	err = utils.RedisClient.HSet(utils.REDIS_USER_INFO+strconv.Itoa(int(orderInfo.OrderBuyUserId)), "WalletTotalOver", wallet.WalletTotalOver).Err()
	if err != nil {
		utils.LogErrorF("更新用户[%d]余额失败, %s", userInfo.UserID, err.Error())
		return
	}
	go m.OrderSparringMsgConfirmRefuse(&orderInfo)
	go m.OrderUserMsgConfirmRefuse(&orderInfo)
	go m.UserMsgConfirmRefuse(&orderInfo)
	return

}

// 大神接单
func (m Confirm) Accept(orderInfo dbmodels.AppSkillOrder) (err error) {
	tx := utils.GEngine.Begin()
	orderInfo.OrderConfirmStatus = dbmodels.SKILL_ORDER_CONFIRM_STATUS_ACCEPT
	orderInfo.OrderStatus = dbmodels.SKILL_ORDER_STATUS_CONFIRM
	orderInfo.OrderConfirmTime = time.Now().Unix()
	err = orderInfo.Update(tx, orderInfo.OrderId)
	if err != nil {
		tx.Rollback()
		utils.LogErrorF("更新订单信息[%d]失败, %s", orderInfo.OrderId, err.Error())
		return
	}
	err = tx.Commit().Error
	m.OrdersHandler(&orderInfo)
	return
}

// 接单后处理
func (m Confirm) OrdersHandler(orderInfo *dbmodels.AppSkillOrder) {
	go m.UserMsgConfirmAccept(orderInfo)
	go m.SparringMsgConfirmAccept(orderInfo)
	go rabbitmqProducer.ProducerOrder(orderInfo.OrderId, orderInfo.OrderStatus, int(orderInfo.OrderTime)+dbmodels.SKILL_ORDER_CONFIRM_TIME)
}

// 大神完成
func (m Confirm) Finish(orderInfo dbmodels.AppSkillOrder) (err error) {
	tx := utils.GEngine.Begin()
	orderInfo.OrderConfirmStatus = dbmodels.SKILL_ORDER_CONFIRM_STATUS_FINISH
	err = orderInfo.Update(tx, orderInfo.OrderId)
	if err != nil {
		tx.Rollback()
		utils.LogErrorF("更新订单信息[%d]失败, %s", orderInfo.OrderId, err.Error())
		return
	}

	// 更新大神总收益
	err = tx.Commit().Error
	go rabbitmqProducer.ProducerOrder(orderInfo.OrderId, orderInfo.OrderStatus, dbmodels.SKILL_ORDER_CONFIRM_TIME)
	go m.UserMsgConfirmFinish(&orderInfo)
	return

}

// 用户取消
func (m Cancel) Cancel(orderInfo dbmodels.AppSkillOrder) (err error) {
	// 用户取消
	orderInfo.OrderStatus = dbmodels.SKILL_ORDER_STATUS_CANCEL
	// 用户取消直接退款
	orderInfo.OrderCancelStatus = dbmodels.SKILL_ORDER_CANCEL_STATUS_USER
	orderInfo.OrderCancelTime = time.Now().Unix()
	orderInfo.OrderIsFinished = dbmodels.SKILL_ORDER_IS_FINISHED_OK
	// redis 扣钱

	tx := utils.GEngine.Begin()
	orderInfo.OrderCancelTime = time.Now().Unix()
	err = orderInfo.Update(tx, orderInfo.OrderId)
	if err != nil {
		tx.Rollback()
		utils.LogErrorF("更新订单信息[%d]失败, %s", orderInfo.OrderId, err.Error())
		return
	}
	// 操作用户余额
	wallet, err := new(dbmodels.AppUserWallet).UpdateWalletTotalOver(tx, orderInfo.OrderBuyUserId, true, true, int64(orderInfo.OrderAmount))
	if err != nil {
		tx.Rollback()
		utils.LogErrorF("更新用户钱包[%d]失败, %s", orderInfo.OrderId, err.Error())
		return
	}
	err = tx.Commit().Error
	if err != nil {
		tx.Rollback()
		utils.LogErrorF("取消订单失败, %d, %s", orderInfo.OrderBuyUserId, err.Error())
		return
	}
	err = utils.RedisClient.HSet(utils.REDIS_USER_INFO+strconv.Itoa(int(orderInfo.OrderBuyUserId)), "WalletTotalOver", wallet.WalletTotalOver).Err()
	if err != nil {
		utils.LogErrorF("更新用户[%d]余额失败, %s", orderInfo.OrderBuyUserId, err.Error())
		return
	}
	go m.OrderSparringMsgCancelCancel(&orderInfo)
	go m.SparringCancelCancel(&orderInfo)
	go m.OrderUserMsgCancelCancel(&orderInfo)
	return

}

// 用户完成
func (m Finish) FinishByUser(orderInfo dbmodels.AppSkillOrder) (err error) {
	tx := utils.GEngine.Begin()
	orderInfo.OrderStatus = dbmodels.SKILL_ORDER_STATUS_FINISH
	orderInfo.OrderFinishStatus = dbmodels.SKILL_ORDER_FINISH_STATUS_USER
	orderInfo.OrderFinishTime = time.Now().Unix()
	orderInfo.OrderIsFinished = dbmodels.SKILL_ORDER_IS_FINISHED_OK
	orderInfo.OrderCommentStatus = dbmodels.SKILL_ORDER_COMMENT_STATUS_WAIT
	err = orderInfo.Update(tx, orderInfo.OrderId)
	if err != nil {
		tx.Rollback()
		utils.LogErrorF("更新订单信息[%d]失败: %s", orderInfo.OrderId, err.Error())
		return
	}
	err = tx.Commit().Error
	// 更新大神总收益
	go rabbitmqProducer.ProducerOrder(orderInfo.OrderId, orderInfo.OrderStatus, dbmodels.SKILL_ORDER_SETTLE_TIME)

	// 顺序发送订单完成 订单评价消息
	m.UserFinishByUser(&orderInfo)
	m.SendCommendMsgByUser(&orderInfo)
	return

}

// 用户退款申请
func (m Refund) RefundApply(orderInfo dbmodels.AppSkillOrder, refundInfo dbmodels.AppSkillOrderRefund) (err error) {

	// 大神取消直接退款
	orderInfo.OrderStatus = dbmodels.SKILL_ORDER_STATUS_REFUND
	orderInfo.OrderRefundStatus = dbmodels.SKILL_ORDER_REFUND_STATUS_REFUNDING
	orderInfo.OrderIsFinished = dbmodels.SKILL_ORDER_IS_FINISHED_NO
	tx := utils.GEngine.Begin()
	err = refundInfo.Create(tx)
	if err != nil {
		tx.Rollback()
		utils.LogErrorF("更新订单信息[%d]失败, %s", orderInfo.OrderId, err.Error())
		return
	}
	orderInfo.OrderCancelTime = time.Now().Unix()
	orderInfo.OrderRefundId = refundInfo.RefundId
	orderInfo.OrderRefundCount += 1
	err = orderInfo.Update(tx, orderInfo.OrderId)
	if err != nil {
		tx.Rollback()
		utils.LogErrorF("更新订单信息[%d]失败, %s", orderInfo.OrderId, err.Error())
		return
	}

	err = tx.Commit().Error
	go rabbitmqProducer.ProducerOrder(orderInfo.OrderId, orderInfo.OrderStatus, dbmodels.SKILL_ORDER_REFUND_TIME)
	go m.UserRefundApply(&orderInfo)
	go m.SparringRefundApply(&orderInfo)
	return

}

// 大神同意退款
func (m Refund) RefundSparringSure(orderInfo dbmodels.AppSkillOrder, userInfo redismodels.UserInfo) (err error) {
	tx := utils.GEngine.Begin()
	orderInfo.OrderRefundStatus = dbmodels.SKILL_ORDER_REFUND_STATUS_SPARRING_OK
	orderInfo.OrderRefundTime = time.Now().Unix()
	orderInfo.OrderStatus = dbmodels.SKILL_ORDER_STATUS_REFUND
	orderInfo.OrderIsFinished = dbmodels.SKILL_ORDER_IS_FINISHED_OK
	err = orderInfo.Update(tx, orderInfo.OrderId)
	if err != nil {
		tx.Rollback()
		return
	}
	// 操作用户余额
	wallet, err := new(dbmodels.AppUserWallet).UpdateWalletTotalOver(tx, orderInfo.OrderBuyUserId, true, true, orderInfo.OrderAmount)
	if err != nil {
		tx.Rollback()
		return
	}
	err = tx.Commit().Error
	if err != nil {
		tx.Rollback()
		utils.LogErrorF("拒绝退款失败, %d, %s", orderInfo.OrderBuyUserId, err.Error())
		return
	}
	err = utils.RedisClient.HSet(utils.REDIS_USER_INFO+strconv.Itoa(int(orderInfo.OrderBuyUserId)), "WalletTotalOver", wallet.WalletTotalOver).Err()
	if err != nil {
		utils.LogErrorF("更新用户[%d]余额失败, %s", userInfo.UserID, err.Error())
		return
	}
	go m.SparringRefundSure(&orderInfo)
	go m.UserRefundSure(&orderInfo)
	return

}

// 大神拒绝退款
func (m Refund) RefundSparringRefuse(orderInfo dbmodels.AppSkillOrder, form request.SkillOrderRefundConfirmReq) (err error) {
	tx := utils.GEngine.Begin()
	if form.RefundReason == "" {
		err = errors.New("退款原因必传")
		return
	}
	refundInfo, err := new(dbmodels.AppSkillOrderRefund).GetAppSkillOrderRefundById(orderInfo.OrderRefundId)
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	if err != nil {
		err = errors.New("退款详情不存在")
		return
	}
	orderInfo.OrderStatus = dbmodels.SKILL_ORDER_STATUS_REFUND
	orderInfo.OrderRefundStatus = dbmodels.SKILL_ORDER_REFUND_STATUS_SPARRING_REFUSE
	refundInfo.RefundSparringRefuse = form.RefundReason
	refundInfo.RefundSparringRemark = form.Remark
	err = orderInfo.Update(tx, orderInfo.OrderId)
	if err != nil {
		tx.Rollback()
		return
	}
	err = refundInfo.Update(tx, refundInfo.RefundId)
	if err != nil {
		tx.Rollback()
		return
	}
	err = tx.Commit().Error
	go m.UserRefundSparring(&orderInfo)
	go rabbitmqProducer.ProducerOrder(orderInfo.OrderId, orderInfo.OrderStatus, dbmodels.SKILL_ORDER_CONFIRM_TIME)
	return

}

// 用户申诉
func (m Appeal) Apply(orderInfo dbmodels.AppSkillOrder, paramsJSON request.SkillAppealReq) (err error) {
	tx := utils.GEngine.Begin()
	image, _ := json.Marshal(paramsJSON.Images)
	// 创建申诉信息
	model := dbmodels.AppSkillOrderAppeal{
		AppealOrderId:      paramsJSON.OrderId,
		AppealCount:        orderInfo.OrderAmount,
		AppealReason:       paramsJSON.Reason,
		AppealRemark:       paramsJSON.Remark,
		AppealImage:        string(image),
		AppealAppealStatus: dbmodels.SKILL_APPEAL_STATUS_ING,
	}
	err = model.Create(tx)
	if err != nil {
		utils.LogErrorF("创建申诉信息失败,err:%s", err.Error())
		tx.Rollback()
		return
	}
	orderInfo.OrderStatus = dbmodels.SKILL_ORDER_STATUS_APPEAL
	orderInfo.OrderAppealStatus = dbmodels.SKILL_APPEAL_STATUS_ING
	orderInfo.OrderAppealTime = time.Now().Unix()
	orderInfo.OrderIsFinished = dbmodels.SKILL_ORDER_IS_FINISHED_NO
	err = orderInfo.Update(tx, orderInfo.OrderId)
	if err != nil {
		tx.Rollback()
		utils.LogErrorF("更新订单信息失败,err:%s", err.Error())
		return
	}
	err = tx.Commit().Error
	go m.SparringAppealApply(&orderInfo)
	// 投递订单申述延迟队列
	go rabbitmqProducer.ProducerAppealOrder(orderInfo.OrderId)
	return
}

// 提交订单评价
func (m Comment) SubmitEvaluation(userId uint64, orderInfo dbmodels.AppSkillOrder, req request.SubmitEvaluationReq) (err error) {

	tx := utils.GEngine.Begin()
	// 创建订单评价详情
	appSkillOrderComment := &dbmodels.AppSkillOrderComment{
		CommentOrderID:     req.CommentOrderId,
		CommentOrderUserID: userId,
		CommentSparringID:  req.CommentSparringId,
		CommentSkillID:     req.CommentSkillId,
		CommentAttitude:    req.CommentAttitude,
		CommentContent:     req.CommentContent,
		CommentLabel:       req.CommentLabel,
		CommentAnonymous:   req.CommentAnonymous,
		CommentState:       enum.OrderEvaluationStateDisplay,
		CommentSystem:      enum.NotSystemEvaluation,
		BaseModel:          dbmodels.BaseModel{Created: time.Now().Unix()},
	}

	// 评价内容为空
	if req.CommentContent == "" {
		// 评价标签为空
		if req.CommentLabel == "" {
			appSkillOrderComment.CommentState = enum.OrderEvaluationStateShield
		} else {
			appSkillOrderComment.CommentState = enum.OrderEvaluationStateFold
		}
	}

	err = appSkillOrderComment.Create(tx)
	if err != nil {
		utils.LogErrorF("创建订单评价失败,err:%s", err.Error())
		tx.Rollback()
		return
	}

	// 更新订单评价状态
	orderInfo.OrderCommentStatus = dbmodels.SKILL_ORDER_COMMENT_STATUS_OK
	err = orderInfo.Update(tx, orderInfo.OrderId)
	if err != nil {
		tx.Rollback()
		utils.LogErrorF("更新订单状态失败,err:%s", err.Error())
		return
	}

	// 更新大神技能标签数量
	for _, v := range strings.Split(req.CommentLabel, ",") {
		labelId, _ := strconv.Atoi(v)
		if labelId == 0 {
			continue
		}
		err := new(dbmodels.AppSparringSkillLabel).Update(tx, int64(req.CommentSparringId), int64(req.CommentSkillId), int64(labelId))
		if err != nil {
			tx.Rollback()
			utils.LogErrorF("更新订单信息失败,err:%s", err.Error())
		}
	}

	// 更新大神分
	praiseNum, badNum, err := new(dbmodels.AppSkillOrderComment).QuerySparringNum(tx, int64(req.CommentSkillId))
	if err != nil {
		tx.Rollback()
		utils.LogErrorF("查询大神好差评数量失败,err:%s", err.Error())
		return
	}
	if req.CommentAttitude == enum.LabelEvaluationPraise {
		praiseNum += 1
	}
	if req.CommentAttitude == enum.LabelEvaluationBadReview {
		badNum += 1
	}

	updates := make(map[string]interface{})
	updates["skill_wilson_score"] = utils.FuncWilson(praiseNum, badNum)
	err = new(dbmodels.AppSparringSkill).Updates(tx, updates, req.CommentSkillId)
	if err != nil {
		tx.Rollback()
		utils.LogErrorF("更新大神威尔逊分失败,err:%s", err.Error())
		return
	}
	err = tx.Commit().Error

	utils.RedisClient.Del(fmt.Sprintf("%s%d", utils.REDIS_SPARRING_SKILL_LABEL, req.CommentSkillId))
	return
}

// 系统自动评价
func (m Comment) SystemAutoComment(orderInfo dbmodels.AppSkillOrder) (err error) {
	tx := utils.GEngine.Begin()
	// 创建订单评价详情
	appSkillOrderComment := &dbmodels.AppSkillOrderComment{
		CommentOrderID:     uint64(orderInfo.OrderId),
		CommentOrderUserID: uint64(orderInfo.OrderBuyUserId),
		CommentSparringID:  uint64(orderInfo.OrderSellUserId),
		CommentSkillID:     uint64(orderInfo.OrderSparringSkillId),
		CommentAttitude:    enum.LabelEvaluationPraise,
		CommentContent:     "系统默认好评！",
		CommentLabel:       "",
		CommentState:       enum.OrderEvaluationStateFold,
		CommentSystem:      enum.IsSystemEvaluation,
		CommentAnonymous:   enum.OrderEvaluationIsAnonymous,
		BaseModel:          dbmodels.BaseModel{Created: time.Now().Unix()},
	}
	err = appSkillOrderComment.Create(tx)
	if err != nil {
		utils.LogErrorF("提交订单评价失败,err:%s", err.Error())
		tx.Rollback()
		return
	}
	orderInfo.OrderCommentStatus = dbmodels.SKILL_ORDER_COMMENT_STATUS_OK
	err = orderInfo.Update(tx, orderInfo.OrderId)
	if err != nil {
		tx.Rollback()
		utils.LogErrorF("更新订单信息失败,err:%s", err.Error())
		return
	}

	// 更新大神分
	praiseNum, badNum, err := new(dbmodels.AppSkillOrderComment).QuerySparringNum(tx, orderInfo.OrderSparringSkillId)
	if err != nil {
		utils.LogErrorF("查询大神好差评数量失败,err:%s", err.Error())
	}
	err = new(dbmodels.AppSparringSkill).Updates(tx, map[string]interface{}{"skill_wilson_score": utils.FuncWilson(praiseNum+1, badNum)}, uint64(orderInfo.OrderSparringSkillId))
	if err != nil {
		tx.Rollback()
		utils.LogErrorF("更新大神威尔逊分失败,err:%s", err.Error())
		return
	}
	err = tx.Commit().Error
	return
}

// 获取订单评论
func (m Comment) GetOrderEvaluationDetail(commentId int64) (resp *response.OrderEvaluationResp, err error) {

	resp = new(response.OrderEvaluationResp)
	commentInfo, err := new(dbmodels.AppSkillOrderComment).GetByOrderId(commentId)
	if err != nil {
		return nil, err
	}

	sparringData, err := new(dbmodels.AppSparringSkill).QueryBySkillId(int64(commentInfo.CommentSkillID))
	if err != nil {
		return
	}

	labels, err := new(dbmodels.AppSkillLabel).GetSkillLabelById(strings.Split(commentInfo.CommentLabel, ","))
	if err != nil {
		return nil, err
	}
	resp.CommentAttitude = commentInfo.CommentAttitude
	resp.CommentContent = commentInfo.CommentContent
	resp.CommentAnonymous = commentInfo.CommentAnonymous
	resp.CommentLabel = labels
	resp.CommentUserIconURL = sparringData.SystemUser.UserIconurl
	resp.CommentUserNickName = sparringData.SystemUser.UserNickname
	return
}

// 获取订单评论列表
func (m Comment) GetOrderEvaluationList(req request.OrderEvaluationListReq) (resp *response.OrderEvaluationListResp, err error) {

	resp = new(response.OrderEvaluationListResp)
	data, _, err := new(dbmodels.AppSkillOrderComment).PageList(req)
	if err != nil {
		return nil, err
	}

	// 服务人数 好评单 好评率 订单总数
	servicePeopleNum, _, favorableRate, _, err := new(dbmodels.AppSkillOrderComment).OrderNum(req)
	if err != nil {
		return nil, err
	}

	if favorableRate < 0 {
		resp.FavorableRate = 0
	}

	// 折叠评论列表 获取匿名评价默认头像
	var anonymousIconUrl string
	anonymousParam, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_DEFAULTANONYMOUSEVALUATIONICONURL)
	if err != nil {
		return nil, err
	}
	if anonymousParam["value"] != "" {
		anonymousIconUrl = anonymousParam["value"]
	}

	var OrderList []response.OrderEvaluationResp
	for _, v := range data {
		order := response.OrderEvaluationResp{}

		order.CommentUserNickName = v.SystemUser.UserNickname
		order.CommentUserIconURL = v.SystemUser.UserIconurl

		order.CommentDate = v.Created
		order.CommentContent = v.CommentContent
		order.CommentAttitude = v.CommentAttitude

		// 获取评论标签名称
		labelName, err := new(dbmodels.AppSkillLabel).GetSkillLabelById(strings.Split(v.CommentLabel, ","))
		if err != nil {
			continue
		}
		order.CommentLabel = labelName

		if v.CommentAnonymous == enum.OrderEvaluationIsAnonymous {
			order.CommentUserNickName = "匿名"
			order.CommentUserIconURL = anonymousIconUrl
		}
		if req.CommentListType == enum.OrderEvaluationStateFold && v.CommentSystem == enum.NotSystemEvaluation && v.CommentContent != "" {
			order.CommentDispute = true
		}

		OrderList = append(OrderList, order)
	}

	sparringSkillLabel, err := new(dbmodels.AppSparringSkillLabel).Query(int64(req.CommentSkillId))
	if err != nil {
		return nil, err
	}

	var skillTotal int64
	resp.LabelDetail = append(resp.LabelDetail, response.LabelArray{LabelId: 0, LabelName: "全部"})
	for _, v := range sparringSkillLabel {
		// 因为运营后台删除标签 导致查询不到标签名称 则不返回给前端
		if v.SparringLabelName == "" {
			continue
		}
		skillTotal += v.SparringLabelNum
		labelArray := response.LabelArray{LabelId: v.SparringLabelID, LabelName: v.SparringLabelName, LabelNum: v.SparringLabelNum}
		resp.LabelDetail = append(resp.LabelDetail, labelArray)
	}
	// 如果全部标签不为0则显示标签列表 为0则隐藏
	if skillTotal != 0 {
		resp.LabelDetail[0].LabelNum = skillTotal
	} else {
		resp.LabelDetail = []response.LabelArray{}
	}

	resp.OrderList = OrderList
	resp.OrderNum = servicePeopleNum
	resp.FavorableRate = favorableRate
	return
}
