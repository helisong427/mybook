/**
 * @Author: 何玉峰
 * @Date: 2021/5/17 下午5:15
 * @Description: 微信公众号模板消息推送
 */
package services

import (
	"encoding/json"
	"fmt"
	"gamers/models/dbmodels"
	"gamers/utils"
	"gamers/utils/wechat"
	"github.com/guonaihong/gout"
	"go.uber.org/zap"
	"time"
)

const (
	WECHAT_TEMPLATE_MSG_PUSH_URL = "https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=%s"
)

type TemplateMsgDataItem struct {
	Value string `json:"value"`
	Color string `json:"color"`
}

type TemplateMsgData struct {
	First    TemplateMsgDataItem `json:"first"`
	Keyword1 TemplateMsgDataItem `json:"keyword1"`
	Keyword2 TemplateMsgDataItem `json:"keyword2"`
	Keyword3 TemplateMsgDataItem `json:"keyword3"`
	Keyword4 TemplateMsgDataItem `json:"keyword4"`
	// Keyword5 TemplateMsgDataItem `json:"keyword5"`
	Remark TemplateMsgDataItem `json:"remark"`
}

type TemplateMsg struct {
	ToUser     string          `json:"touser"`
	TemplateId string          `json:"template_id"`
	Data       TemplateMsgData `json:"data"`
}

// 微信公众号，推送随机单提醒消息
func SendTemplateMsg(orderType int, userIds []int64, orderTime, orderCount int64, skillName, unit string, price int64) {

	timeTemp := time.Unix(orderTime, 0).Format("1月2日 15:04")
	orderName := fmt.Sprintf("%s*%d%s", skillName, orderCount, unit)
	amountDesc := fmt.Sprintf("%dGO币", price/100)
	for _, userId := range userIds {

		// 判断用户判断用户是否已经绑定微信公众号推送
		binding, err := new(dbmodels.SystemUserBinding).GetByUserId(userId, dbmodels.PLATFORM_TYPE_WECHAT)
		if err != nil {
			utils.Logger.Error("查询用户绑定openid信息失败", zap.Error(err))
			continue
		}

		// 用户未绑定，则不发送
		if binding == nil {
			continue
		}

		setting, err := new(dbmodels.SystemUserPrivacySetting).GetPrivacySetting(userId)
		if err != nil {
			utils.Logger.Error("获取大神的接收开关信息失败", zap.Error(err))
			continue
		}

		var templateId = "96nEuyugr_ft5fxCV377d3F4HyU7Suk__JBQT8vlKHA"
		var templateMsgData = TemplateMsgData{
			Keyword1: newItem("请前往APP内查看"),
			Keyword2: newItem(timeTemp),
			Keyword3: newItem(amountDesc),
			Keyword4: newItem(orderName),
		}

		// 定向单
		if orderType == dbmodels.SKILL_TYPE_ORIENTATION {
			// 断开关是否开启
			if setting.DirectOrderPush != 0 {
				continue
			}

			templateMsgData.First = newItem("您有新的定向单，请赶快接单吧")
			templateMsgData.Remark = newItem("请前往APP内立即领取")

		} else if orderType == dbmodels.SKILL_TYPE_RAND {
			// 随机单

			// 断开关是否开启
			if setting.RandomOrderPush != 0 {
				continue
			}

			templateMsgData.First = newItem("您有新的极速匹配订单，请赶快抢单吧")
			templateMsgData.Remark = newItem("请前往APP内立即抢单")
		} else {
			utils.Logger.Error("推送的模板消息类型错误", zap.Int("orderType", orderType))
			continue
		}

		body := TemplateMsg{
			ToUser:     binding[0].BindingId,
			TemplateId: templateId,
			Data:       templateMsgData,
		}

		// 获取access token
		token, err := getAccessToken()
		if err != nil {
			utils.Logger.Error("获取Access token失败", zap.Error(err))
			return
		}

		url := fmt.Sprintf(WECHAT_TEMPLATE_MSG_PUSH_URL, token)

		resp := struct {
			Errcode int    `json:"errcode"`
			Errmsg  string `json:"errmsg"`
			Msgid   int64  `json:"msgid"`
		}{}

		// 推送消息
		err = gout.POST(url).Debug(true).SetJSON(body).BindJSON(&resp).Do()
		if err != nil {
			utils.Logger.Error("推送微信公众号模板消息失败", zap.Error(err))
		}

		if resp.Errcode != 0 {
			utils.Logger.Error("推送模板消息失败", zap.Reflect("推送消息", body), zap.Reflect("推送返回消息", resp))
		}
	}

}

// 获取access token
func getAccessToken() (string, error) {

	// 从缓存中获取access token
	token, exist, err := dbmodels.GetAccessToken()
	if err != nil {
		return "", err
	}

	if exist {
		return token, nil
	}

	param, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PARAM_KEY_WEICHAT_BINDING)
	if err != nil {
		return "", err
	}

	wechatBindingParam := dbmodels.WechatBindingParam{}
	err = json.Unmarshal([]byte(param["value"]), &wechatBindingParam)
	if err != nil {
		return "", err
	}

	w := wechat.Wechat{
		AppId:  wechatBindingParam.AppId,
		Secret: wechatBindingParam.Secret,
	}

	r, err := w.GetWechatAccessToken()
	if err != nil {
		return "", err
	}

	if r.ErrCode != 0 {
		return "", fmt.Errorf(r.ErrMsg)
	}

	_ = dbmodels.SetAccessToken(r.AccessToken, r.ExpiresIn)

	return r.AccessToken, nil

}

func newItem(data string) TemplateMsgDataItem {
	return TemplateMsgDataItem{
		Value: data,
		Color: "#173177",
	}
}
