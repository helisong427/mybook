package services

import "gamers/models/dbmodels"

// 连接腾讯im拉黑
func FeedbackAdd(userId int64, content string, terminal int, channel int) (err error) {
	model := dbmodels.AppFeedback{
		FeedbackUserId:   userId,
		FeedbackContent:  content,
		FeedbackChannel:  terminal,
		FeedbackTerminal: channel,
		FeedbackStatus:   0,
	}
	err = model.FeedbackAdd()
	return
}
