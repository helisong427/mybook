/**
 * @Author: panke
 * @Description: 用户隐私设置
 * @File: user_privacy
 * @Date: 2021/5/17 18:25
 */

package services

import (
	"fmt"
	"gamers/controller/request"
	"gamers/models/dbmodels"
	"gamers/utils"
)

// 更新用户隐私设置
func UserPrivacyUpdate(userId int64, req request.UserPrivacyUpdateReq) (bool, error) {

	switch *req.PushType {
	case request.PUSH_ONLINE:
		if *req.PushValue == 1 {

			userInfo, err := new(dbmodels.SystemUser).QueryById(userId)
			if err != nil {
				return false, err
			}
			if userInfo.UserIsSparring == dbmodels.USER_IS_SPARRING_YES || userInfo.UserIsAnchor == dbmodels.USER_IS_ANCHOR_YES {
				_ = utils.RedisClient.SRem(utils.Redis_Active_Push_Sparring_Set, userInfo.UserID)
			}
		}
	case request.PUSH_DIRECT, request.PUSH_RAND:
		data, err := new(dbmodels.SystemUserBinding).GetByUserId(userId, dbmodels.PLATFORM_TYPE_WECHAT)
		if err != nil {
			return false, err
		}

		if data == nil {
			return true, fmt.Errorf("你还未绑定微信公众号，请前往微信公众号绑定")
		}

	default:
		return false, fmt.Errorf("更新开关类型错误！")
	}

	err := new(dbmodels.SystemUserPrivacySetting).Updates(userId, *req.PushValue, *req.PushType)
	if err != nil {
		utils.LogInfoF(fmt.Sprintf("更新用户隐私设置错误:%s", err.Error()))
		return false, err
	}
	return false, nil
}

// 获取用户隐私设置
func UserPrivacyGet(userId int64) (setting dbmodels.UserPrivacySetting, err error) {
	setting, err = new(dbmodels.SystemUserPrivacySetting).GetPrivacySetting(userId)
	if err != nil {
		return dbmodels.UserPrivacySetting{}, err
	}
	return
}
