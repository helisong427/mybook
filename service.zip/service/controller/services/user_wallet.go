package services

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"gorm.io/gorm"
)

//Go币明细
func UserGoBill(paramsJSON request.UserGoBillReq, userId int64) (r response.BasePageList, err error) {
	r.Page = paramsJSON.Page
	r.Size = paramsJSON.Size
	list := []response.UserGoBillRep{}
	if paramsJSON.Type == 1 { //1--陪玩下单
		total, data, err := new(dbmodels.AppSkillOrder).QueryBill(paramsJSON.Page, paramsJSON.Size, userId)
		if err != nil && err != gorm.ErrRecordNotFound {
			return r, err
		}
		err = nil
		if total == 0 {
			return r, err
		}
		r.Total = total
		for _, v := range data {
			// 大于等于接单状态,判定是否退款成功
			if v.OrderStatus >= dbmodels.SKILL_ORDER_STATUS_CONFIRM {
				var isRefund bool //是否有退款
				switch v.OrderStatus {
				case dbmodels.SKILL_ORDER_STATUS_CONFIRM: //接单状态
					//大神拒绝接单
					if v.OrderConfirmStatus == dbmodels.SKILL_ORDER_CONFIRM_STATUS_REFUSE {
						isRefund = true
					}
				case dbmodels.SKILL_ORDER_STATUS_CANCEL: // 取消状态
					// 用户、大神、系统取消
					if v.OrderCancelStatus >= dbmodels.SKILL_ORDER_CANCEL_STATUS_USER {
						isRefund = true
					}
				case dbmodels.SKILL_ORDER_STATUS_REFUND: // 退款状态
					//大神同意退款、系统自动退款
					if v.OrderRefundStatus == dbmodels.SKILL_ORDER_REFUND_STATUS_SPARRING_OK || v.OrderRefundStatus == dbmodels.SKILL_ORDER_REFUND_STATUS_SYS_OK {
						isRefund = true
					}
				case dbmodels.SKILL_ORDER_STATUS_APPEAL: // 申述状态
					//用户胜诉
					if v.OrderAppealStatus == dbmodels.SKILL_ORDER_APPEAL_STATUS_USER_OK {
						isRefund = true
					}
				default:
				}
				if isRefund {
					l := response.UserGoBillRep{
						Desc:   "陪玩退款",
						Amount: v.OrderAmount,
						Change: 1,
						Time:   v.BaseModel.Edited,
					}
					list = append(list, l)
				}
			}

			//默认增加一条扣款记录
			l := response.UserGoBillRep{
				Desc:   "陪玩下单",
				Amount: v.OrderAmount,
				Change: 0,
				Time:   v.BaseModel.Created,
			}
			list = append(list, l)
		}
	} else if paramsJSON.Type == 2 { //2--购买礼物
		total, data, err := new(dbmodels.AppAnchorRoomProp).QueryUserList(paramsJSON.Page, paramsJSON.Size, userId)
		if err != nil && err != gorm.ErrRecordNotFound {
			return r, err
		}
		err = nil
		if total == 0 {
			return r, err
		}
		r.Total = total
		for _, v := range data {
			l := response.UserGoBillRep{
				Desc:   "购买礼物",
				Amount: v.PropPropPrice * v.PropPropCount,
				Change: 0,
				Time:   v.BaseModel.Created,
			}
			list = append(list, l)
		}
	} else if paramsJSON.Type == 3 { //3--购买Go币
		total, data, err := new(dbmodels.AppTransaction).QueryGoList(paramsJSON.Page, paramsJSON.Size, userId)
		if err != nil && err != gorm.ErrRecordNotFound {
			return r, err
		}
		err = nil
		if total == 0 {
			return r, err
		}
		r.Total = total
		for _, v := range data {
			l := response.UserGoBillRep{
				Desc:   "购买Go币",
				Amount: v.TransactionAmount,
				Change: 1,
				Time:   v.BaseModel.Created,
			}
			list = append(list, l)
		}
	} else { //4--其他
		total, data, err := new(dbmodels.AppTransaction).QueryOtherList(paramsJSON.Page, paramsJSON.Size, userId)
		if err != nil && err != gorm.ErrRecordNotFound {
			return r, err
		}
		err = nil
		if total == 0 {
			return r, err
		}
		r.Total = total
		for _, v := range data {
			l := response.UserGoBillRep{
				Amount: v.TransactionAmount,
				Change: 0,
				Time:   v.BaseModel.Created,
			}
			if v.TransactionType == dbmodels.DB_TRANSACTION_TYPE_BALANCE_TO_GO || v.TransactionType == dbmodels.DB_TRANSACTION_TYPE_SYSTEM_GIFT ||
				v.TransactionType == dbmodels.DB_TRANSACTION_TYPE_ACTIVITY_GIVE {
				l.Change = 1
			}
			if desc, ok := dbmodels.TransactionTypeMapString[v.TransactionType]; ok {
				l.Desc = desc
			}
			list = append(list, l)
		}
	}
	r.List = list
	r.TotalPages = utils.FuncTotalPages(r.Total, paramsJSON.Size)
	return r, err
}

//用户首充
func UserFirstCharge(userId int64) (r response.UserFirstChargeRep, err error) {
	info, err := new(redismodels.UserInfo).GetUserInfo(userId)
	if err != nil {
		return
	}
	r.UserIsRecharge = info.UserIsRecharge
	data, err := new(redismodels.FirstCharge).Get()
	if err != nil {
		return
	}
	list := []response.FirstChargeList{}
	for _, v := range data {
		list = append(list, response.FirstChargeList{
			PropName:  v.PropName,
			PropIcon:  v.PropIcon,
			PropCount: v.PropCount,
		})
	}
	r.FirstChargeList = list
	return
}

// 获取用户其他收入
func UserOtherIncome(userId int64, page, size, skip int) (resp response.BasePageList, err error) {
	total, data, err := new(dbmodels.AppTransaction).GetOtherUserIncome(userId, size, skip)
	if err != nil {
		return
	}
	resp.Total = total
	var newData []response.UserOtherIncomeResp
	for i, v := range data {
		if v.TransactionType == dbmodels.DB_TRANSACTION_TYPE_WITHDRAW {
			if v.TransactionStatus == dbmodels.DB_TRANSACTION_FAIL {
				income := response.UserOtherIncomeResp{
					TransactionId:     v.TransactionId,
					TransactionStatus: dbmodels.DB_TRANSACTION_ING,
					TransactionType:   dbmodels.DB_TRANSACTION_TYPE_WITHDRAW,
					TransactionAmount: v.TransactionAmount,
					TransactionTime:   v.Created,
					TransactionRemark: "余额提现",
					TransactionIncome: false,
				}
				newData = append(newData, income)
				data[i].TransactionRemark = "提现失败"
				data[i].TransactionIncome = true
			}
		} else if v.TransactionType == dbmodels.DB_TRANSACTION_TYPE_SYSTEM_COMPENSATION {
			data[i].TransactionIncome = true
		}
	}
	data = append(data, newData...)
	resp.Total = total
	resp.List = data
	resp.Page = page
	resp.Size = size
	resp.TotalPages = utils.FuncTotalPages(total, size)
	return
}
