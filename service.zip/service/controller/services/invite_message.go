package services

import (
	"errors"
	"fmt"
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/models/dbmodels"
	"gamers/utils"
	"time"

	"github.com/go-redis/redis"
)

const (
	InviteMessageEditStatusOk = 1 // 用户撩一撩邀请消息今天之内已修改，明天零点过期。
)

var (
	ErrInviteMessageEdited = errors.New("您的修改次数已达上限") // 用户撩一撩今日修改次数已达上限
)

// InviteMessageQuery 根据用户id查询是否存在之前提交过的撩一撩邀请消息，不存在返回默认结构体
func InviteMessageQuery(userID int64) (data response.InviteMessageResp, err error) {
	r := dbmodels.AppInviteMessageReview{
		ReviewUserID: userID,
	}
	data, err = r.GetContentAndStatus()
	if err != nil {
		utils.LogErrorF("查询用户撩一撩邀请消息失败：%v", err)
		return
	}
	return
}

// InviteMessageAdd 增加一条用户提交的撩一撩邀请消息审核记录
func InviteMessageAdd(userID int64, params request.InviteMessageReq) (reviewID int64, err error) {
	r := dbmodels.AppInviteMessageReview{
		ReviewUserID:       userID,
		ReviewUserPrettyID: params.PrettyID,
		ReviewUserNickName: params.NickName,
		ReviewContent:      params.Content,
	}
	err = r.Add()
	if err != nil {
		utils.LogErrorF("增加撩一撩邀请消息审核记录失败：%v", err)
		return
	}
	reviewID = r.ReviewID
	return
}

// InviteMessageEdit 修改撩一撩邀请消息内容，每天只能修改一次，第二天零点可以修改。
func InviteMessageEdit(userID int64, params request.InviteMessageReq) (err error) {
	r := dbmodels.AppInviteMessageReview{
		ReviewID:           params.ReviewID,
		ReviewUserID:       userID,
		ReviewUserNickName: params.NickName,
		ReviewContent:      params.Content,
	}
	// 查询用户的审核状态
	reviewStatus, err := r.GetStatus()
	if err != nil {
		utils.LogErrorF("获取用户撩一撩邀请消息审核状态失败：%v", err)
		return
	}

	// 审核被拒绝，可以继续修改。
	if reviewStatus == 2 {
		err = r.Edit()
		if err != nil {
			utils.LogErrorF("修改撩一撩邀请消息失败：%v", err)
			return
		}
		return
	}

	// 审核通过，一天只能修改一次。
	key := fmt.Sprintf("%s%d", utils.REDIS_INVITE_MESSAGE, userID)
	status, err := utils.RedisClient.Get(key).Int()
	if err != nil && err != redis.Nil {
		utils.LogErrorF("获取用户撩一撩邀请消息修改状态失败：%v", err)
		return
	}
	if status == InviteMessageEditStatusOk {
		utils.LogErrorF("用户：%s，今天之内邀请消息已经修改过", params.NickName)
		return ErrInviteMessageEdited
	}

	err = r.Edit()
	if err != nil {
		utils.LogErrorF("修改撩一撩邀请消息失败：%v", err)
		return
	}

	// 计算当前时间到第二天凌晨还剩余多长时间
	now := time.Now()
	zeroTime := time.Date(now.Year(), now.Month(), now.Day(),
		0, 0, 0, 0, now.Location())
	sec := zeroTime.AddDate(0, 0, 1)
	exp := sec.Sub(now)

	// 设置用户撩一撩邀请消息修改状态
	err = utils.RedisClient.Set(key, 1, exp).Err()
	if err != nil {
		utils.LogErrorF("设置用户撩一撩邀请消息修改状态失败：%v", err)
		return
	}
	return
}
