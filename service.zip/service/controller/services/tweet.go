package services

import (
	"encoding/json"
	"errors"
	"fmt"
	"gamers/controller/request"
	"gamers/models/dbmodels"
	"gamers/utils"
	"github.com/go-redis/redis"
	"gorm.io/gorm"
	"math"
	"time"
)

const (
	//统计热门朋友圈公式基数
	tweetPopularCountA int64 = 5 //阅读次数
	tweetPopularCountB int64 = 3 //评论数量

	tweetPopularCountC int64 = 1 //阅读系数
	tweetPopularCountD int64 = 2 //点赞系数
	tweetPopularCountE int64 = 5 //评论系数

	tweetPopularCountF float64 = -1   //发布时间与当前时间差 + e
	tweetPopularCountG float64 = 1.05 //次方

	tweetPopularCountH int64 = 48 //48小时
	tweetPopularCountI int64 = 2  //48小时内2倍
)

//统计热门朋友圈
func TweetPopularCount() (err error) {
	key := utils.REDIS_TWEET_POPULAR_COUNT
	model := dbmodels.AppTweet{}
	results := []dbmodels.AppTweet{}

	timeStr := time.Now().AddDate(0, 0, -30).Format("2006-01-02")
	tim, _ := time.Parse("2006-01-02", timeStr)
	timeNumber := tim.Unix()

	heats := []redis.Z{}
	utils.LogErrorF("[朋友圈热度统计]开始")
	//迭代批量处理
	var allCount int64 = 0
	err = utils.GEngine.Model(model).Where("deleted = 0 AND tweet_status = ? AND tweet_visible = ? AND  created>=?", dbmodels.TWEET_STATUS_OK, dbmodels.TWEET_VISIBLE_UNLIMITED, timeNumber).Count(&allCount).Error
	if err != nil || allCount <= 0 {
		err = fmt.Errorf("迭代批量查询失败:%s", err.Error())
		return
	}
	err = utils.GEngine.Model(model).Where("deleted = 0 AND  tweet_status = ? AND tweet_visible = ? AND created>=?", dbmodels.TWEET_STATUS_OK, dbmodels.TWEET_VISIBLE_UNLIMITED, timeNumber).FindInBatches(&results, int(allCount), func(tx *gorm.DB, batch int) error {
		for _, result := range results {
			// 批量处理找到的记录
			var baseHeat int64
			if result.TweetType == 0 {
				if result.TweetSoundTime > 0 {
					baseHeat += 10 //声音分
				} else {
					baseHeat += 5 //文字分
				}
			} else if result.TweetType == 1 {
				baseHeat += 20 //图片分
			} else if result.TweetType == 2 {
				baseHeat += 50 //视频分
			}
			f := result.BaseModel.Created + tweetPopularCountH*3600
			var (
				fLike    int64 = 0
				bLike    int64 = 0
				fComment int64 = 0
				bComment int64 = 0
				fRead    int64 = 0
				bRead    int64 = 0
			)
			//48小时内的点赞数量
			utils.GEngine.Raw("SELECT COUNT(log_id) FROM app_tweet_visitor_log WHERE log_type=0 AND `log_tweet_id` = ? and  created<=?", result.TweetID, f).Count(&fLike)
			//48小时内的评论数量
			utils.GEngine.Raw("SELECT IFNULL(SUM(commoncount),0) FROM (SELECT  log_operate_user_id,IF (COUNT( log_id ) > ?, ?, COUNT( log_id ) ) AS commoncount FROM app_tweet_visitor_log WHERE `log_tweet_id` =?  and  created<=? AND log_type = 1 GROUP BY log_operate_user_id,log_tweet_id ) AS a", tweetPopularCountB, tweetPopularCountB, result.TweetID, f).Count(&fComment)
			//48小时内的阅读数量
			utils.GEngine.Raw("SELECT IFNULL(SUM(commoncount),0) FROM (SELECT  log_operate_user_id,IF (COUNT( log_id ) > ?, ?, COUNT( log_id ) ) AS commoncount FROM app_tweet_visitor_log WHERE `log_tweet_id` =?  and  created<=? AND log_type = 4 GROUP BY log_operate_user_id,log_tweet_id ) AS a", tweetPopularCountA, tweetPopularCountA, result.TweetID, f).Count(&fRead)
			var activityHeat float64 = 0.0
			if time.Now().Unix()-tweetPopularCountH*3600 > result.BaseModel.Created { //48小时发布后的
				//48小时后的点赞数量
				utils.GEngine.Raw("SELECT COUNT(log_id) FROM app_tweet_visitor_log WHERE log_type=0 AND `log_tweet_id` = ? and  created>?", result.TweetID, f).Count(&bLike)
				//48小时后的评论数量
				utils.GEngine.Raw("SELECT IFNULL(SUM(commoncount),0) FROM (SELECT  log_operate_user_id,IF (COUNT( log_id ) > ?, ?, COUNT( log_id ) ) AS commoncount FROM app_tweet_visitor_log WHERE `log_tweet_id` =?  and  created>? AND log_type = 1 GROUP BY log_operate_user_id,log_tweet_id ) AS a", tweetPopularCountB, tweetPopularCountB, result.TweetID, f).Count(&bComment)
				//48小时后的阅读数量
				utils.GEngine.Raw("SELECT IFNULL(SUM(commoncount),0) FROM (SELECT  log_operate_user_id,IF (COUNT( log_id ) > ?, ?, COUNT( log_id ) ) AS commoncount FROM app_tweet_visitor_log WHERE `log_tweet_id` =?  and  created>? AND log_type = 4 GROUP BY log_operate_user_id,log_tweet_id ) AS a", tweetPopularCountA, tweetPopularCountA, result.TweetID, f).Count(&bRead)
				activityHeat = float64(((fRead*tweetPopularCountC+fLike*tweetPopularCountD+fComment*tweetPopularCountE)*tweetPopularCountI +
					(bRead*tweetPopularCountC + bLike*tweetPopularCountD + bComment*tweetPopularCountE))) /
					math.Pow((float64(time.Now().Unix())-float64(result.BaseModel.Created))/86400+tweetPopularCountF, tweetPopularCountG)
			} else {
				activityHeat = float64((fRead*tweetPopularCountC + fLike*tweetPopularCountD + fComment*tweetPopularCountE) * tweetPopularCountI)
			}
			utils.GEngine.Exec("update app_tweet set tweet_score=? where tweet_id=?  ", int64(activityHeat)+baseHeat, result.TweetID)
			heat := float64(result.TweetInterventionScore) + activityHeat + float64(baseHeat)
			heats = append(heats, redis.Z{
				Score:  heat,
				Member: result.TweetID,
			})
		}
		return nil
	}).Error
	if err != nil {
		err = fmt.Errorf("迭代批量查询失败:%s", err.Error())
		return
	}

	if len(heats) > 0 {
		//删除旧缓存
		err = utils.RedisClient.Del(key).Err()
		if err != nil {
			err = fmt.Errorf("删除旧缓存失败:%s", err.Error())
			return
		}
		err = utils.RedisClient.ZAdd(key, heats...).Err()
		if err != nil {
			err = fmt.Errorf("批量插入有序集合失败:%s", err.Error())
			return
		}
	}
	return
}

//朋友圈热门
type TweetPopular struct {
	redisClient         *redis.Client
	userId              int64         //用户id
	popularLength       int64         //热门数据长度
	userKey             string        //用户已查询redis key
	countKey            string        //热门统计redis key
	userCacheMap        map[int64]int //用户已查询缓存数据,map方便去重
	front, middle, back float64       //随机获取数据时各个区域的结束范围，比例：5:3:2
}

//初始化热门
func NewTweetPopular(userId int64) (*TweetPopular, error) {
	m := TweetPopular{}
	m.userId = userId
	m.redisClient = utils.RedisClient
	m.userKey = fmt.Sprintf("%s%d", utils.REDIS_TWEET_POPULAR_ID_LIST, userId)
	m.countKey = utils.REDIS_TWEET_POPULAR_COUNT
	m.popularLength = m.redisClient.ZCard(m.countKey).Val()
	m.userCacheMap = make(map[int64]int)
	userCache, err := m.redisClient.Get(m.userKey).Result()
	if err != nil && err != redis.Nil {
		err = fmt.Errorf("get %s error:%s", m.userKey, err.Error())
		return nil, err
	}
	if userCache != "" {
		err = json.Unmarshal([]byte(userCache), &m.userCacheMap)
		if err != nil {
			err = fmt.Errorf("json.Unmarshal %s error:%s", m.userKey, err.Error())
			return nil, err
		}
	}
	if len(m.userCacheMap) >= int(m.popularLength) {
		m.userCacheMap = make(map[int64]int)
	}

	//随机比例：5%:5%-15%:30%
	//计算比例区域的起始值
	m.front = math.Ceil(float64(m.popularLength) * 0.05)
	m.middle = math.Ceil(float64(m.popularLength)*0.15) + m.front
	m.back = math.Ceil(float64(m.popularLength)*0.3) + m.middle

	return &m, nil
}

//热门朋友圈列表
func (m *TweetPopular) GetPopularList(paramJSON request.TweetListReq) (total int64, list []dbmodels.AppTweetJoin, err error) {
	//每页固定10条
	paramJSON.Size = 10
	//热门数据小于等于10条,直接查询该数据并且返回
	if m.popularLength <= 10 {
		ids := []int{}
		err = m.redisClient.ZRevRange(m.countKey, 0, m.popularLength).ScanSlice(&ids)
		list, err = new(dbmodels.AppTweet).QueryPopularIn(ids, m.userId)
		return
	}
	tweet, err := m.getTweet(0, m.front, 6)
	if err != nil {
		return
	}
	list = append(list, tweet...)
	tweet, err = m.getTweet(m.front, m.middle, 3)
	if err != nil {
		return
	}
	list = append(list, tweet...)
	tweet, err = m.getTweet(m.middle, m.back, 1)
	if err != nil {
		return
	}
	list = append(list, tweet...)

	if len(list) < paramJSON.Size {
		tweet, err = m.getTweet(0, float64(m.popularLength), paramJSON.Size-len(list))
		if err != nil {
			return
		}
		list = append(list, tweet...)
	}

	//保存查询记录
	marshal, _ := json.Marshal(m.userCacheMap)
	err = m.redisClient.Set(m.userKey, marshal, time.Hour).Err()
	if err != nil {
		err = fmt.Errorf("set %s err:%s", m.userKey, err.Error())
	}
	total = m.popularLength
	return
}

//获取朋友圈
func (m *TweetPopular) getTweet(start, end float64, getNumber int) (list []dbmodels.AppTweetJoin, err error) {
	ids := []int{}
	err = m.redisClient.ZRevRange(m.countKey, int64(start), int64(end)).ScanSlice(&ids)
	if err != nil {
		return
	}
	slice := []int{}
	for _, v := range ids {
		//如果上次已经查询过则删除
		if _, ok := m.userCacheMap[int64(v)]; !ok {
			slice = append(slice, v)
		}
	}
	if len(slice) > 0 {
		slice = utils.FuncRandSlice(slice, getNumber)
		list, err = new(dbmodels.AppTweet).QueryPopularIn(slice, m.userId)
		if err != nil {
			return
		}
		//保存已查询的朋友圈id
		for _, v := range slice {
			m.userCacheMap[int64(v)] = 0
		}
	}
	return
}

//删除朋友圈
func TweetDelete(userId int64, tweetId int64) (msg string, err error) {
	//查询朋友圈
	exist, data, err := new(dbmodels.AppTweet).QueryExist(tweetId)
	if err != nil && err != gorm.ErrRecordNotFound {
		return "删除失败", err
	}
	if exist == 0 {
		return "朋友圈不存在", errors.New("tweetId error")
	}
	if data.TweetUserID != userId {
		return "非法操作", errors.New("tweet not belong to user")
	}
	err = new(dbmodels.AppTweet).SoftDelete(tweetId)
	if err != nil {
		return "删除失败", err
	}

	return "", nil
}
