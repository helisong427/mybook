/**
 * @Author: panke
 * @Description:
 * @File: liaoyiliao_active_push_test
 * @Date: 2021/5/24 11:06
 */

package services

import (
	"fmt"
	"testing"

	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
)

func Pre() {
	conf := utils.Config.App.Env
	if conf == "" {
		conf = "debug"
	}
	// 配置文件初始化
	utils.ConfigInitLocal()
	// 初始化日志
	utils.LoggerInit()

	// 建立连接池
	utils.GDBInit()
	utils.RedisInit()
}

func TestLiaoyiLiaoActivePush_MsgSend(t *testing.T) {

	Pre()

	userInfo, _ := new(dbmodels.SystemUser).QueryById(1000353909)

	new(LiaoyiLiaoActivePush).MsgSend(userInfo, redismodels.MSG_ADMIN_USER_SUPERMASTER, []string{"1000080301"})
	fmt.Println("发送成功")
}
