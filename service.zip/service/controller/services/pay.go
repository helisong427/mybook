package services

import (
	"encoding/json"
	"errors"
	"fmt"
	"strconv"

	"gamers/controller/response"
	"gamers/enum"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"gamers/utils/pay"
	"gamers/utils/pay/warning"

	"github.com/iGoogle-ink/gopay/wechat"
	"gorm.io/gorm"
)

// 充值参数
func RechargeParameters(userId int64, client int) (r response.RechargeParametersRep, err error) {
	// 充值提示
	param, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_RECHARGE_TIPS)
	if err != nil {
		return
	}
	err = json.Unmarshal([]byte(param["value"]), &r.RechargeTips)
	if err != nil {
		return r, err
	}

	rechargeParam, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_RECHARGE_WAP)
	if client == enum.USER_CLIENT_TYPE_ANDROID {
		rechargeParam, err = new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_RECHARGE_ANDROID)
	} else if client == enum.USER_CLIENT_TYPE_IOS {
		rechargeParam, err = new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_RECHARGE_IOS)
	}
	if err != nil {
		return r, err
	}
	rechargeParams := []dbmodels.RechargeParams{}
	err = json.Unmarshal([]byte(rechargeParam["value"]), &rechargeParams)
	if err != nil {
		return r, err
	}
	for _, v := range rechargeParams {
		r.TopUpGrade = append(r.TopUpGrade, response.TopUpGrade{
			Id:    v.Id,
			Cash:  v.Cash,
			Token: v.Token,
		})
	}

	//r.Recharge = utils.FuncMD5(utils.FuncMD5(utils.Config.App.Appkey + utils.FuncRandString(5)))
	//utils.RedisClient.Set(utils.REDIS_RECHARGE, r.Recharge, time.Minute) //1分钟过期

	if userId > 0 {
		info, err := new(redismodels.UserInfo).GetUserInfo(userId)
		if err != nil {
			return r, err
		}
		r.UserBalance = info.WalletTotalOver
	}
	return
}

// 微信下单
func PlaceOrderWechat(amount, cash int64, fromSystem int, fromWay int, ip string, userId int64, payType enum.PayType) (r response.PlaceOrderRep, err error) {
	outTradeNo := dbmodels.IDBuilderGetId(utils.REDIS_IDBUILDER_TRANSACTION_ID)
	r.OutTradeNo = outTradeNo
	//交易渠道id
	channel, err := new(dbmodels.AppTransactionChannel).QueryKey(dbmodels.TRANSACTION_CHANNEL_KEY_WECHATPAY)
	if err != nil {
		err = errors.New("充值参数错误")
		return
	}
	channelId, err := strconv.Atoi(channel["id"])
	if err != nil {
		err = errors.New("充值参数错误")
		return
	}
	wechatPayParam := dbmodels.ChannelWechatPayParam{}
	err = json.Unmarshal([]byte(channel["param"]), &wechatPayParam)
	if err != nil {
		err = errors.New("充值参数错误")
		return
	}

	weChatpay := pay.NewWheatPay(wechatPayParam.AppId, wechatPayParam.ApiKey, wechatPayParam.MerchantId, wechatPayParam.NotifyURL)
	weChatpay.Price = cash //单位分
	weChatpay.Ip = ip
	weChatpay.Desc = "充值go币"
	weChatpay.OutTradeNo = outTradeNo

	// 支付方式
	if payType == enum.APP_PAY {
		weChatpay.TradeType = wechat.TradeType_App
		r.OrderParameters, err = weChatpay.PlaceOrder()
	} else if payType == enum.WAP_PAY {
		weChatpay.TradeType = wechat.TradeType_H5
		r.OrderParameters, err = weChatpay.PlaceOrder()
	} else {
		err = errors.New("支付方式不存在")
	}
	if err != nil {
		err = errors.New("充值参数错误")
		return
	}

	model := dbmodels.AppTransaction{
		TransactionId:              weChatpay.OutTradeNo,
		TransactionType:            dbmodels.DB_TRANSACTION_TYPE_GO,
		TransactionAmount:          amount, // 转换金额
		TransactionCash:            cash,
		TransactionStatus:          dbmodels.DB_TRANSACTION_ING,
		TransactionRemark:          weChatpay.Desc,
		TransactionFromUserId:      userId,
		TransactionFromAccountType: int64(dbmodels.DB_ACCOUNT_TYPE_WEHCHAT),
		TransactionFromSystem:      fromSystem,
		TransactionFromWay:         fromWay,
		TransactionToUserId:        userId,
		TransactionChannelId:       channelId,
	}

	tx := utils.GEngine
	err = model.Create(tx)

	// 推送充值消息，进行告警处理。
	warning.Queue().PushMessage(warning.Message{
		UserID:          userId,
		TransactionID:   outTradeNo,
		TransactionTime: model.Created,
		Type:            int64(dbmodels.DB_ACCOUNT_TYPE_WEHCHAT),
		Cash:            cash,
	})
	return
}

// 微信公众号支付
func PlaceOrderWechatJsapi(amount, cash int64, fromSystem int, fromWay int, userId int64, ip string, openid string) (r response.PlaceOrderRep, err error) {
	outTradeNo := dbmodels.IDBuilderGetId(utils.REDIS_IDBUILDER_TRANSACTION_ID)
	r.OutTradeNo = outTradeNo

	//交易渠道id
	channel, err := new(dbmodels.AppTransactionChannel).QueryKey(dbmodels.TRANSACTION_CHANNEL_KEY_WECHATJSAPIPAY)
	if err != nil {
		err = errors.New("充值参数错误")
		return
	}
	channelId, err := strconv.Atoi(channel["id"])
	if err != nil {
		err = errors.New("充值参数错误")
		return
	}
	wechatJSAPIPayParam := dbmodels.ChannelWechatJSAPIPayParam{}
	err = json.Unmarshal([]byte(channel["param"]), &wechatJSAPIPayParam)
	if err != nil {
		err = errors.New("充值参数错误")
		return
	}

	wechatJSAPIPay := pay.NewJsapiPay(wechatJSAPIPayParam.AppId, wechatJSAPIPayParam.ApiKey, wechatJSAPIPayParam.MerchantId, wechatJSAPIPayParam.NotifyURL)
	wechatJSAPIPay.Price = cash
	wechatJSAPIPay.Ip = ip
	wechatJSAPIPay.Desc = "充值go币"
	wechatJSAPIPay.OutTradeNo = outTradeNo
	wechatJSAPIPay.Openid = openid
	r.OrderParameters, err = wechatJSAPIPay.PlaceOrder()

	model := dbmodels.AppTransaction{
		TransactionId:              wechatJSAPIPay.OutTradeNo,
		TransactionType:            dbmodels.DB_TRANSACTION_TYPE_GO,
		TransactionAmount:          amount,
		TransactionCash:            cash,
		TransactionStatus:          dbmodels.DB_TRANSACTION_ING,
		TransactionRemark:          wechatJSAPIPay.Desc,
		TransactionFromUserId:      userId,
		TransactionFromAccountType: int64(dbmodels.DB_ACCOUNT_TYPE_WEHCHAT),
		TransactionFromSystem:      fromSystem,
		TransactionFromWay:         fromWay,
		TransactionToUserId:        userId,
		TransactionChannelId:       channelId,
	}

	tx := utils.GEngine
	err = model.Create(tx)

	// 推送充值消息，进行告警处理。
	warning.Queue().PushMessage(warning.Message{
		UserID:          userId,
		TransactionID:   outTradeNo,
		TransactionTime: model.Created,
		Type:            int64(dbmodels.DB_ACCOUNT_TYPE_WEHCHAT),
		Cash:            cash,
	})
	return
}

// 支付宝App下单
func PlaceOrderAlipay(amount, cash int64, fromSystem int, fromWay int, userId int64, payType enum.PayType) (r response.PlaceOrderRep, err error) {
	outTradeNo := dbmodels.IDBuilderGetId(utils.REDIS_IDBUILDER_TRANSACTION_ID)
	r.OutTradeNo = outTradeNo

	//交易渠道id
	channel, err := new(dbmodels.AppTransactionChannel).QueryKey(dbmodels.TRANSACTION_CHANNEL_KEY_ALIPAY)
	if err != nil {
		err = errors.New("充值参数错误")
		return
	}
	channelId, err := strconv.Atoi(channel["id"])
	if err != nil {
		err = errors.New("充值参数错误")
		return
	}
	aliPayParam := dbmodels.ChannelAliPayParam{}
	err = json.Unmarshal([]byte(channel["param"]), &aliPayParam)
	if err != nil {
		err = errors.New("充值参数错误")
		return
	}

	aliPay := pay.NewAlipay(aliPayParam.AppId, aliPayParam.PrivateKey, aliPayParam.PublicKey, aliPayParam.NotifyURL, aliPayParam.ReturnURL)
	aliPay.Price = cash
	aliPay.Desc = "充值go币"
	aliPay.OutTradeNo = outTradeNo

	// 支付方式
	if payType == enum.APP_PAY {
		r.OrderParameters, err = aliPay.AppPlaceOrder()
	} else if payType == enum.WAP_PAY {
		r.OrderParameters, err = aliPay.WapPlaceOrder()
	} else {
		err = errors.New("充值方式不存在")
	}
	if err != nil {
		err = errors.New("充值参数错误")
		return
	}

	model := dbmodels.AppTransaction{
		TransactionId:              aliPay.OutTradeNo,
		TransactionType:            dbmodels.DB_TRANSACTION_TYPE_GO,
		TransactionAmount:          amount,
		TransactionCash:            cash,
		TransactionStatus:          dbmodels.DB_TRANSACTION_ING,
		TransactionRemark:          aliPay.Desc,
		TransactionFromUserId:      userId,
		TransactionFromAccountType: int64(dbmodels.DB_ACCOUNT_TYPE_ALIPAY),
		TransactionFromSystem:      fromSystem,
		TransactionFromWay:         fromWay,
		TransactionToUserId:        userId,
		TransactionChannelId:       channelId,
	}

	tx := utils.GEngine
	err = model.Create(tx)

	// 推送充值消息，进行告警处理。
	warning.Queue().PushMessage(warning.Message{
		UserID:          userId,
		TransactionID:   outTradeNo,
		TransactionTime: model.Created,
		Type:            int64(dbmodels.DB_ACCOUNT_TYPE_ALIPAY),
		Cash:            cash,
	})
	return
}

// 苹果支付下单
func PlaceOrderApplePay(amount, cash int64, productId string, userId int64) (r response.PlaceOrderRep, err error) {
	//交易渠道id
	channel, err := new(dbmodels.AppTransactionChannel).QueryKey(dbmodels.TRANSACTION_CHANNEL_KEY_APPLEPAY)
	if err != nil {
		err = errors.New("充值参数错误")
		return
	}
	channelId, err := strconv.Atoi(channel["id"])
	if err != nil {
		channelId = 0
	}
	// 由于苹果支付是使用客户端SDK下单,这里只生成订单号,不请求苹果服务器
	outTradeNo := dbmodels.IDBuilderGetId(utils.REDIS_IDBUILDER_TRANSACTION_ID)
	r.OutTradeNo = outTradeNo
	model := dbmodels.AppTransaction{
		TransactionId:              outTradeNo,
		TransactionType:            dbmodels.DB_TRANSACTION_TYPE_GO,
		TransactionAmount:          amount,
		TransactionCash:            cash,
		TransactionStatus:          dbmodels.DB_TRANSACTION_ING,
		TransactionRemark:          "充值go币",
		TransactionFromUserId:      userId,
		TransactionFromAccountType: int64(dbmodels.DB_ACCOUNT_TYPE_APPLEPAY),
		TransactionFromSystem:      enum.USER_CLIENT_TYPE_IOS,
		TransactionFromWay:         0,
		TransactionToUserId:        userId,
		TransactionThirdProductid:  productId,
		TransactionChannelId:       channelId,
	}
	tx := utils.GEngine
	err = model.Create(tx)

	// 推送充值消息，进行告警处理。
	warning.Queue().PushMessage(warning.Message{
		UserID:          userId,
		TransactionID:   outTradeNo,
		TransactionTime: model.Created,
		Type:            int64(dbmodels.DB_ACCOUNT_TYPE_APPLEPAY),
		Cash:            cash,
	})
	return
}

// 苹果支付收据验证
func ApplePayVerifyReceipt(productId string, outTradeNo int64, transactionId, receiptData string, userId int64) (walletTotalOver int64, err error) {
	thirdNo := utils.FuncMD5(receiptData)
	// 使用收据加锁
	key := fmt.Sprintf("%s%s", utils.REDIS_USER_WALLET_LOCK, thirdNo)
	lock, islock := utils.AcquireLock(key, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
	if !islock {
		err = fmt.Errorf("加锁失败:[%d]", outTradeNo)
		return walletTotalOver, err
	}
	// 释放锁
	defer utils.ReleaseLock(key, lock)

	// 交易渠道id
	channel, err := new(dbmodels.AppTransactionChannel).QueryKey(dbmodels.TRANSACTION_CHANNEL_KEY_APPLEPAY)
	if err != nil {
		err = errors.New("渠道信息参数错误")
		return walletTotalOver, err
	}
	channelId, err := strconv.Atoi(channel["id"])
	if err != nil {
		channelId = 0
	}
	applePayParam := dbmodels.ChannelApplePayParam{}
	err = json.Unmarshal([]byte(channel["param"]), &applePayParam)
	if err != nil {
		err = errors.New("充值参数错误")
		return
	}

	// 查询订单
	first, data, err := new(dbmodels.AppTransaction).QueryFirstByRecharge(outTradeNo)
	if err != nil && err != gorm.ErrRecordNotFound {
		return 0, err
	}
	if first == 0 {
		return 0, errors.New("订单信息错误")
	}

	// 订单不属于该用户,第三方id不为空,TransactionThirdProductid不一致,交易渠道id不一致,不处理
	if data.TransactionToUserId != userId || data.TransactionThirdOrderid != "" ||
		productId != data.TransactionThirdProductid || data.TransactionChannelId != channelId {
		return 0, errors.New("订单已支付")
	}

	// 验证第三方id是否已经使用
	count, err := new(dbmodels.AppTransaction).QueryByThirdNo(thirdNo)
	if err != nil || count != 0 {
		return 0, errors.New("订单信息错误")
	}
	url := applePayParam.ProdURL
	env := utils.Config.App.Env
	if env == "" || env == "debug" || env == "test" || env == "staging" { //非正式环境走沙盒
		url = applePayParam.SandboxURL
	}
	// 验证签名
	_, err = pay.NewApplePay().VerifyReceipt(url, productId, transactionId, applePayParam.BundleId, receiptData)
	if err != nil {
		return
	}
	walletTotalOver, err = PayCallbackHandler(&data, dbmodels.DB_TRANSACTION_COMPLETE, thirdNo)
	return
}

// 状态结果查询
func PayResultQuery(outTradeNo int64) (r response.PayResultQueryRep, err error) {
	first, data, err := new(dbmodels.AppTransaction).QueryFirst(outTradeNo)
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	err = nil
	if first == 0 {
		return
	}
	r.Status = data.TransactionStatus
	return
}

// 支付回调处理
func PayCallbackHandler(data *dbmodels.AppTransaction, transactionStatus int, thirdNo string) (walletTotalOver int64, err error) {
	key := fmt.Sprintf("%s%d", utils.REDIS_USER_WALLET_LOCK, data.TransactionFromUserId)
	lock, islock := utils.AcquireLock(key, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
	if !islock {
		err = fmt.Errorf("支付回调加锁失败:[%d]", data.TransactionId)
		utils.LogErrorF(err.Error())
		return walletTotalOver, err
	}
	// 释放锁
	defer utils.ReleaseLock(key, lock)
	userId := data.TransactionFromUserId
	if data.TransactionStatus != dbmodels.DB_TRANSACTION_ING {
		err = fmt.Errorf("订单已完成,无法重复操作:[%d]", data.TransactionId)
		utils.LogErrorF(err.Error())
		return walletTotalOver, err
	}

	// 获取用户信息
	info, err := new(redismodels.UserInfo).GetUserInfo(userId)
	if err != nil {
		err = fmt.Errorf("获取用户信息失败:[%d],[%s]", data.TransactionId, err.Error())
		return
	}

	// 操作数据库
	tx := utils.GEngine.Begin()
	err = new(dbmodels.AppTransaction).UpdateStatus(tx, data.TransactionId, transactionStatus, thirdNo)
	if err != nil {
		tx.Rollback()
		err = fmt.Errorf("更新订单状态失败:[%d],[%s]", data.TransactionId, err.Error())
		utils.LogErrorF(err.Error())
		return walletTotalOver, err
	}

	// 支付成功才修改用户余额
	if transactionStatus == dbmodels.DB_TRANSACTION_COMPLETE {
		over, err := new(dbmodels.AppUserWallet).UpdateWalletRecharge(tx, userId, data.TransactionAmount, data.TransactionCash)
		if err != nil {
			tx.Rollback()
			err = fmt.Errorf("更新用户余额失败:[%d],[%s]", data.TransactionId, err.Error())
			utils.LogErrorF(err.Error())
			return walletTotalOver, err
		}
		err = new(redismodels.UserInfo).UpdateUserWalletTotalOver(userId, over.WalletTotalOver)
		if err != nil {
			tx.Rollback()
			err = fmt.Errorf("更新redis用户余额失败:[%d],[%s]", data.TransactionId, err.Error())
			utils.LogErrorF(err.Error())
			return walletTotalOver, err
		}
		walletTotalOver = over.WalletTotalOver
	}

	// 查询首充配置
	firstRechargeCash := 999999999999999
	param, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_FIRST_RECHARGE_CASH)
	if err != nil {
		err = fmt.Errorf("获取首充金额失败:[%d],[%s]", data.TransactionId, err.Error())
		utils.LogErrorF(err.Error())
	} else {
		firstRechargeCash, _ = strconv.Atoi(param["value"])
	}
	// 查询用户是否首充,赠送首充奖励
	// 是否达到首充阈值
	if info.UserIsRecharge == dbmodels.USER_RECHARGE_NO && data.TransactionCash >= int64(firstRechargeCash) {
		updateMap := make(map[string]interface{})
		updateMap["user_is_recharge"] = dbmodels.USER_RECHARGE_YES
		err := new(dbmodels.SystemUser).Update(userId, updateMap)
		if err != nil {
			tx.Rollback()
			err = fmt.Errorf("更新用户首充状态失败:[%d],[%s]", data.TransactionId, err.Error())
			utils.LogErrorF(err.Error())
			return walletTotalOver, err
		}
		// 首充赠送礼物
		firstData, err := new(redismodels.FirstCharge).Get()
		if err != nil {
			err = fmt.Errorf("获取首充物品失败:[%d],[%s]", data.TransactionId, err.Error())
		}
		if len(firstData) > 0 {
			go FirstChargeGift(userId, firstData)
		}

		err = new(redismodels.UserInfo).UpdateUserIsRecharge(userId)
		if err != nil {
			tx.Rollback()
			err = fmt.Errorf("更新redis用户首充状态失败:[%d],[%s]", data.TransactionId, err.Error())
			utils.LogErrorF(err.Error())
			return walletTotalOver, err
		}
	}
	tx.Commit()
	if transactionStatus == dbmodels.DB_TRANSACTION_COMPLETE {
		go new(RechargeMsg).AssistantRechargeOk(userId, data.TransactionAmount)
	}

	// 支付成功埋点上报
	r := PayReport{
		Type:    PayLog,
		UserId:  userId,
		OrderId: strconv.Itoa(int(data.TransactionId)),
		Status:  uint32(transactionStatus),
	}
	go r.Send()
	return
}

// 首充赠送
func FirstChargeGift(userId int64, firstData []redismodels.FirstCharge) {
	// 单独开事务操作,不影响充值业务
	tx := utils.GEngine.Begin()
	ids := []int64{}
	for _, v := range firstData {
		ids = append(ids, v.PropId)
	}
	row, propData, err := new(dbmodels.AppProp).QueryByIn(ids)
	if err != nil {
		err = fmt.Errorf("[首充业务]获取礼物信息失败:[%s]", err.Error())
		utils.LogErrorF(err.Error())
		return
	}
	if row > 0 {
		for _, v := range propData {
			for _, val := range firstData {
				if v.PropId == val.PropId {

					var logTypeId int64 = 0
					var needCreate bool = true

					if v.PropType != dbmodels.DB_PROP_TYPE_AVATAR &&
						v.PropType != dbmodels.DB_PROP_TYPE_CHAT &&
						v.PropType != dbmodels.DB_PROP_TYPE_CAR {
						// 可叠加数量类
						row, data, err := new(dbmodels.AppBackpack).QueryStackable(tx, userId, v.PropId, v.PropType)
						if err != nil && err != gorm.ErrRecordNotFound {
							tx.Rollback()
							err = fmt.Errorf("[首充业务]查询用户可叠加物品失败:[%s]", err.Error())
							utils.LogErrorF(err.Error())
							return
						}
						// 增加物品数量
						if row > 0 {
							needCreate = false
							_, err := new(dbmodels.AppBackpack).AddCount(tx, data.BackpackId, val.PropCount)
							if err != nil {
								tx.Rollback()
								err = fmt.Errorf("[首充业务]增加可叠加物品数量失败:[%s]", err.Error())
								utils.LogErrorF(err.Error())
								return
							}
							logTypeId = data.BackpackId
						}
					} else {
						// 不可叠加数量类
						row, data, err := new(dbmodels.AppBackpack).QueryNoStackable(tx, userId, v.PropId, v.PropType)
						if err != nil && err != gorm.ErrRecordNotFound {
							tx.Rollback()
							err = fmt.Errorf("[首充业务]查询用户不叠加物品失败:[%s]", err.Error())
							utils.LogErrorF(err.Error())
							return
						}
						if row > 0 {
							needCreate = false
							update := make(map[string]interface{})
							// 具有有效时间的物品延长物品的使用时间
							if v.PropExpiredTime > 0 {
								update["backpack_expired_time"] = data.BackpackExpiredTime + v.PropExpiredTime*60*60*24
							} else {
								update["backpack_expired_time"] = 0
							}
							err := new(dbmodels.AppBackpack).Update(tx, data.BackpackId, update)
							if err != nil {
								tx.Rollback()
								err = fmt.Errorf("[首充业务]延长物品使用时间失败:[%s]", err.Error())
								utils.LogErrorF(err.Error())
								return
							}
							logTypeId = data.BackpackId
						}
					}
					if needCreate {
						// 创建物品信息
						model := dbmodels.AppBackpack{
							BackpackUserId:     userId,
							BackpackPropType:   v.PropType,
							BackpackPropId:     v.PropId,
							BackpackCount:      val.PropCount,
							BackpackPropAttrId: v.PropAttrId,
						}
						_, err = model.Create(tx)
						if err != nil {
							tx.Rollback()
							err = fmt.Errorf("[首充业务]创建物品失败:[%s]", err.Error())
							utils.LogErrorF(err.Error())
							return
						}
					}
					modelLog := dbmodels.AppBackpackLog{
						LogType:     dbmodels.DB_APP_BACK_PACK_LOG_LOG_TYPE_GIFT,
						LogTypeId:   logTypeId,
						LogUserId:   userId,
						LogPropId:   v.PropId,
						LogPropType: v.PropType,
						LogCount:    val.PropCount,
					}
					err = modelLog.Create(tx)
					if err != nil {
						tx.Rollback()
						err = fmt.Errorf("[首充业务]创建加物品日志记录失败:[%s]", err.Error())
						utils.LogErrorF(err.Error())
						return
					}

				}
			}
		}
	}

	tx.Commit()
	go new(RechargeMsg).AssistantFirstRecharge(userId)
	return
}
