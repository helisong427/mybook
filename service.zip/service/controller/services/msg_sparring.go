package services

import (
	"gamers/enum"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"gamers/utils/tencent/tencentIm"
	"strings"
)

type SparringAction interface {
	Apply()
	Agree()
	Refuse()
	Forbidden()
}

type Sparring struct {
}

func InitSparring() Sparring {
	return Sparring{}
}

const (
	ASSISTANT_SPARRING_KEY_APPLY = "assistant_sparring_apply"     // 申请
	ASSISTANT_SPARRING_KEY_OK    = "assistant_sparring_ok"        // 通过
	ASSISTANT_SPARRING_FAIL      = "assistant_sparring_fail"      // 拒绝
	ASSISTANT_SPARRING_FORBIDDEN = "assistant_sparring_forbidden" // 冻结
)

const (
	APPLY_SPARRING_PLACEHOLDER_SKILL_NAME      = "skill_name"
	APPLY_SPARRING_PLACEHOLDER_CHECK_TIME_HOUR = "check_time_hour"
)

// 申请大神
func (s Sparring) Apply(skill dbmodels.AppSkill, checkTime int64, userId string) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_SPARRING_KEY_APPLY)
	if err != nil {
		utils.LogErrorF("获取申请大神消息model失败,err:%s", err.Error())
		return
	}
	tmStr := utils.MsgTimeFormatHour(checkTime)
	tip := strings.NewReplacer("${skill_name}", skill.SkillName, "${check_time_hour}", tmStr).Replace(msgModel.MsgContent)
	skillMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: skillMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId)
	if err != nil {
		utils.LogErrorF("发送大神申请推送失败,err:%s", err.Error())
	}
	return
}

// 通过大神
func (s Sparring) Agree(skillName, userId string) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_SPARRING_KEY_OK)
	if err != nil {
		utils.LogErrorF("获取同意大神消息model失败,err:%s", err.Error())
		return
	}
	tip := strings.NewReplacer("${skill_name}", skillName).Replace(msgModel.MsgContent)
	skillMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: skillMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId)
	if err != nil {
		utils.LogErrorF("发送同意大神推送失败,err:%s", err.Error())
	}
	item := make(map[string]string)
	item[enum.IM_USER_ATTR_SPARRING] = "1"
	err = tencentIm.AddUserAttr(userId, item)
	if err != nil {
		utils.LogErrorF("设置用户大神属性失败,err:%s", err.Error())
	}
	return
}

// 拒绝
func (s Sparring) Refuse(skillName, reason, qq, userId string) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_SPARRING_FAIL)
	if err != nil {
		utils.LogErrorF("获取拒绝大神消息model失败,err:%s", err.Error())
		return
	}
	tip := strings.NewReplacer("${skill_name}", skillName, "${refuse_reason}", reason, "${qq}", qq).Replace(msgModel.MsgContent)
	skillMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: skillMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId)
	if err != nil {
		utils.LogErrorF("发送拒绝大神推送失败,err:%s", err.Error())
	}
	return
}
