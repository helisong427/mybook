package speedmatching

import (
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/mq/rabbitmqProducer"
	"gamers/utils"

	"github.com/go-redis/redis"
	"gorm.io/gorm"
)

var (
	UserBalanceErr = errors.New("user balance error")
)

// 极速匹配
type SpeedMatching struct {
	redis                    *redis.Client
	cacheKeySparringMaterial string // 大神素材缓存
	lockKeyMatchingSpeed     string // 极速匹配锁
}

// 大神素材
type SMMaterialResp struct {
	AvatarList    []string `json:"avatar_list"`    // 头像列表
	SparringCount int64    `json:"sparring_count"` // 大神数量
}

type sendMatchMsgTxt struct {
	SkillId        int64  `json:"skill_id"`        // 游戏id
	Gender         int    `json:"gender"`          // 性别：0--不限，1--男，2--女
	Count          int64  `json:"count"`           // 数量
	MatchingRemark string `json:"matching_remark"` // 备注
}

func (s *SMMaterialResp) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s *SMMaterialResp) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

func New() *SpeedMatching {
	return &SpeedMatching{
		redis:                    utils.RedisClient,
		cacheKeySparringMaterial: utils.REDIS_MATCHING_SPARRING_MATERIAL,
		lockKeyMatchingSpeed:     utils.REDIS_MATCHING_GRABBING_LOCK,
	}
}

// 匹配参数
func (s *SpeedMatching) Params(userId int64) (data response.SMParamsResp, err error) {
	// 获取游戏
	all, err := new(dbmodels.AppSkill).QuerySkillAll()
	if err != nil {
		return
	}

	for _, v := range all {
		skill, err := new(dbmodels.AppSkill).QueryBySkillId(v.SkillId)
		if err != nil {
			return data, err
		}
		if len(skill.AppSkillPrice) > 0 && skill.AppSkillPrice[0].PricePriceRand > 0 {
			r := response.SMParams{
				SkillId:    skill.SkillId,
				SkillName:  skill.SkillName,
				SkillPrice: skill.AppSkillPrice[0].PricePriceRand,
				SkillWay:   skill.AppSkillPrice[0].PriceWay,
			}
			// 取出必填字段
			var others []response.OtherRequirements
			// others := []response.OtherRequirements{}
			fields := strings.Split(skill.SkillFields, ",")
			for _, filed := range fields {
				// 遍历必填字段
				for _, fieldValue := range skill.GameSkillFiledValues {
					if filed == fieldValue.ValueKey && (fieldValue.ValueKey == "can_region" || fieldValue.ValueKey == "accept_level") {
						other := response.OtherRequirements{
							OtherName: fieldValue.ValueKeyName,
						}
						for _, fieldValueValue := range fieldValue.Values {
							other.OtherValues = append(other.OtherValues, fieldValueValue.ValueValue)
						}
						others = append(others, other)
						break
					}
				}
			}
			r.OtherRequirements = others
			data.Params = append(data.Params, r)
		}
	}

	// 查询余额
	wallet, err := new(dbmodels.AppUserWallet).Query(userId)
	if err != nil {
		return data, err
	}
	data.UserBalance = wallet.WalletTotalOver

	return data, nil
}

// 大神素材
func (s *SpeedMatching) SparringMaterial() (data SMMaterialResp, err error) {
	err = s.redis.Get(s.cacheKeySparringMaterial).Scan(&data)
	if err != nil && err != redis.Nil {
		return data, err
	}

	if err != nil && err == redis.Nil {
		// 防止缓存击穿
		do, err, _ := utils.SingLefLighter.Do(s.cacheKeySparringMaterial, s.getSparringMaterial)
		if err != nil {
			return data, err
		}
		data = do.(SMMaterialResp)
		binary, err := data.MarshalBinary()
		if err != nil {
			return data, err
		}

		err = s.redis.Set(s.cacheKeySparringMaterial, string(binary), time.Hour*24*7).Err()
		if err != nil {
			return data, err
		}
	}

	return data, nil
}

// 用户下单
func (s *SpeedMatching) PlaceOrder(paramsJSON *request.SMPlaceOrderReq, userId int64) (msg string, r response.SMPlaceOrderResp, err error) {
	key := fmt.Sprintf("%s%d", utils.REDIS_USER_WALLET_LOCK, userId)
	lock, isLock := utils.AcquireLock(key, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
	if !isLock {
		return "请稍后再试", r, errors.New("lock fail")
	}
	// 释放锁
	defer utils.ReleaseLock(key, lock)

	// 查询是否有进行中
	count, err := new(dbmodels.AppSkillOrderSpeedMatching).QueryPendingOrder(userId)
	if err != nil {
		return "查询进行中订单失败", r, err
	}

	if count > 0 {
		return "您有订单进行中", r, errors.New("order pending")
	}

	// 查询随机单价格
	skill, err := new(dbmodels.AppSkill).QueryBySkillId(paramsJSON.SkillId)
	if err != nil {
		return "查询技能详情失败", r, err
	}
	if len(skill.AppSkillPrice) == 0 {
		return "游戏参数有误", r, errors.New("skill params error")
	}

	if skill.AppSkillPrice[0].PricePriceRand == 0 {
		return "游戏价格有误", r, errors.New("skill price error")
	}

	// 单价
	unitPrice := skill.AppSkillPrice[0].PricePriceRand
	// 订单总金额
	price := unitPrice * paramsJSON.Count
	// 单位
	way := skill.AppSkillPrice[0].PriceWay
	// 查询余额
	info, err := new(redismodels.UserInfo).GetUserInfo(userId)
	if err != nil {
		return "查询用户余额失败", r, err
	}
	if info.WalletTotalOver < price {
		return "用户余额不足", r, UserBalanceErr
	}

	tx := utils.GEngine.Begin()
	// 创建
	model := new(dbmodels.AppSkillOrderSpeedMatching)
	model.MatchingUserId = userId
	model.MatchingSkillId = paramsJSON.SkillId
	model.MatchingPrice = unitPrice
	model.MatchingWay = way
	model.MatchingCount = paramsJSON.Count
	model.MatchingGender = paramsJSON.Gender
	model.MatchingRemark = paramsJSON.MatchingRemark
	marshal, err := json.Marshal(paramsJSON.MatchingOtherRequirements)
	if err != nil {
		return "格式化其他要求失败", r, err
	}
	if len(marshal) > 0 {
		model.MatchingOtherRequirements = string(marshal)
	}
	model.MatchingStatus = dbmodels.SPEED_MATCHING_STATUS_PENDING
	err = model.Create(tx)
	if err != nil {
		tx.Rollback()
		return "创建极速匹配单失败", r, err
	}

	// 减少用户余额
	over, err := new(dbmodels.AppUserWallet).UpdateWalletTotalOver(tx, userId, false, true, price)
	if err != nil {
		tx.Rollback()
		return "减少用户余额失败", r, err
	}
	// 更新缓存金额
	err = new(redismodels.UserInfo).UpdateUserWalletTotalOver(userId, over.WalletTotalOver)
	if err != nil {
		tx.Rollback()
		return "更新用户缓存余额失败", r, err
	}
	tx.Commit()
	// 给大神发送消息
	content := &sendMatchMsgTxt{
		SkillId:        paramsJSON.SkillId,
		Gender:         paramsJSON.Gender,
		Count:          paramsJSON.Count,
		MatchingRemark: paramsJSON.MatchingRemark,
	}
	go s.sendMatchMsg(content, model.MatchingId, model.MatchingPrice, model.MatchingWay, skill.SkillName, userId)

	// 创建延迟队列,自动取消极速匹配订单
	go rabbitmqProducer.MatchingCancel(model.MatchingId)

	r.Balance = over.WalletTotalOver
	r.MatchingId = model.MatchingId
	return "", r, nil
}

// 退款处理
func (s *SpeedMatching) Refund(matchingId int64, updateStatus int, userId int64) (msg string, status int, resp *response.SMQueryStatusSparringInfo, err error) {
	key := fmt.Sprintf("%s%d", s.lockKeyMatchingSpeed, matchingId)
	lock, isLock := utils.AcquireLock(key, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
	if !isLock {
		return "请稍后再试", status, nil, errors.New("lock fail")
	}
	// 释放锁
	defer utils.ReleaseLock(key, lock)

	matching, err := new(dbmodels.AppSkillOrderSpeedMatching).QueryByMatchingId(matchingId)
	if err != nil {
		return "查询订单失败", status, nil, err
	}
	status = matching.MatchingStatus
	// 过期
	if matching.MatchingStatus == dbmodels.SPEED_MATCHING_STATUS_EXPIRED {
		return "匹配已取消", status, nil, nil
	}
	// 取消
	if matching.MatchingStatus == dbmodels.SPEED_MATCHING_STATUS_CANCEL {
		return "匹配已取消", status, nil, nil
	}
	// 接单
	if matching.MatchingStatus == dbmodels.SPEED_MATCHING_STATUS_COMPLETED {
		// 获取大神信息
		info, err := s.getSparringInfo(matching.MatchingSparringUserId, matching.MatchingSkillId)
		if err != nil {
			return "获取大神信息失败", status, nil, err
		}
		return "取消失败，大神已抢单", status, info.SparringInfo, nil
	}
	// 自动取消获取不到userId所以userId为0不判断其合法性
	if userId != 0 && matching.MatchingUserId != userId {
		return "非法请求", status, nil, errors.New("user error")
	}

	amount := matching.MatchingPrice * matching.MatchingCount

	tx := utils.GEngine.Begin()
	update := make(map[string]interface{})
	update["matching_status"] = updateStatus // 延迟队列更新:"已过期",手动取消:"已取消"
	update["matching_success_status"] = dbmodels.SPEED_MATCHING_SUCCESS_STATUS_YES
	err = new(dbmodels.AppSkillOrderSpeedMatching).Update(tx, matchingId, update)
	if err != nil {
		tx.Rollback()
		return "更新极速匹配状态失败", status, nil, err
	}

	// 增加用户余额
	over, err := new(dbmodels.AppUserWallet).UpdateWalletTotalOver(tx, matching.MatchingUserId, true, true, amount)
	if err != nil {
		tx.Rollback()
		return "增加用户余额失败", status, nil, err
	}
	// 更新缓存金额
	err = new(redismodels.UserInfo).UpdateUserWalletTotalOver(matching.MatchingUserId, over.WalletTotalOver)
	if err != nil {
		tx.Rollback()
		return "更新用户缓存余额失败", status, nil, err
	}
	tx.Commit()
	if updateStatus == dbmodels.SPEED_MATCHING_STATUS_EXPIRED {
		// 自动取消发消息
		go s.sendGoGoCancelMsg(matching.MatchingUserId)
	}
	return "取消成功", dbmodels.SPEED_MATCHING_STATUS_CANCEL, nil, nil
}

// 获取大神素材
func (s *SpeedMatching) getSparringMaterial() (interface{}, error) {
	// 可能出现大批量默认头像,使用map做去重处理
	avatarMap := make(map[string]struct{})
	data := SMMaterialResp{}
	// 获取通过认证的大神头像
	avatar, err := new(dbmodels.SystemUser).QuerySparringAvatar(100)
	if err != nil {
		return data, err
	}
	for _, v := range avatar {
		if _, ok := avatarMap[v.UserIconurl]; ok {
			continue
		}
		avatarMap[v.UserIconurl] = struct{}{}
		data.AvatarList = append(data.AvatarList, v.UserIconurl)
	}

	// 获取大神数量
	count, err := new(dbmodels.SystemUser).QuerySparringCount()
	if err != nil {
		return data, err
	}
	data.SparringCount = count + int64(float64(count)*0.1)
	return data, nil
}

// 给大神发送匹配消息
func (s *SpeedMatching) sendMatchMsg(content *sendMatchMsgTxt, matchingId int64, price int64, way string, skillName string, userId int64) {
	// 待发送消息用户id
	var userIds, wechatIds []int64
	// 查询符合推送条件的大神
	matching, err := new(dbmodels.AppSparringSkill).QueryMatching(content.SkillId)
	if err != nil {
		utils.LogErrorF("[给大神发送匹配消息][%d]失败:%s", matchingId, err.Error())
		return
	}
	if len(matching) == 0 {
		utils.LogErrorF("[给大神发送匹配消息][%d]符合游戏条件的大神", matchingId)
		return
	}

	for _, v := range matching {
		// 不给自己发
		if v.SkillUserID == userId {
			continue
		}

		// 判断用户状态和性别
		info, _ := new(redismodels.UserInfo).GetUserInfo(v.SkillUserID)
		// if info.UserID != 0 && info.UserIsOnline == 1 {
		// 	if content.Gender == 0 || info.UserGender == content.Gender {
		//
		// 		if int(v.SkillMsgStatus) == dbmodels.SPARRING_SKILL_MSG_ON {
		// 			userIds = append(userIds, v.SkillUserID)
		// 		}
		// 		wechatIds = append(wechatIds, v.SkillUserID)
		// 	}
		// }

		if info.UserID != 0 {
			// 判断性别
			if content.Gender == 0 || info.UserGender == content.Gender {
				// 消息开关关闭、不在线的情况大神不发
				if info.UserIsOnline == 1 && int(v.SkillMsgStatus) == dbmodels.SPARRING_SKILL_MSG_ON {
					userIds = append(userIds, v.SkillUserID)
				}
				wechatIds = append(wechatIds, v.SkillUserID)
			}
		}
	}
	// 发送消息
	msg := redismodels.MatchingUserMsg{
		UserGender: content.Gender,
		Count:      content.Count,
		SkillName:  skillName,
		SkillPrice: price,
		SkillWay:   way,
	}
	go s.sendMatchingSparringMsg(userIds, &msg)

	// 向用户微信公众号推送订单提醒消息
	go services.SendTemplateMsg(dbmodels.SKILL_TYPE_RAND, wechatIds, time.Now().Unix(), content.Count,
		skillName, way, price)
}

// 状态查询
func (s *SpeedMatching) QueryStatus(userId int64) (data response.SMQueryStatusResp, err error) {
	last, err := new(dbmodels.AppSkillOrderSpeedMatching).QueryLast(userId)
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	// 忽略记录未找到错误
	if err == gorm.ErrRecordNotFound {
		return data, nil
	}

	data.MatchingId = last.MatchingId
	// 进行中
	if last.MatchingStatus == dbmodels.SPEED_MATCHING_STATUS_PENDING {
		data.Status = 1
	}
	if last.MatchingStatus == dbmodels.SPEED_MATCHING_STATUS_COMPLETED {
		// 已经匹配直接返回
		if last.MatchingSuccessStatus == 1 {
			return
		}

		// 获取大神信息
		info, err := s.getSparringInfo(last.MatchingSparringUserId, last.MatchingSkillId)
		if err != nil {
			return data, err
		}
		data.SparringUserId = info.SparringUserId
		data.Status = info.Status
		data.SparringInfo = info.SparringInfo
	}

	return
}

// 完成处理
func (s *SpeedMatching) Success(matchingId int64, userId int64) (err error) {
	_, err = new(dbmodels.AppSkillOrderSpeedMatching).SuccessUpdate(matchingId, userId)
	return
}

// 抢单中心
func (s *SpeedMatching) OrderGrabbingCenter(page, size int, userId int64) (msg string, r response.BasePageList, err error) {
	var (
		max      = 50    // 最大条数
		gender   int     // 性别
		skillIds []int64 // 大神id
	)
	list := make([]response.OrderGrabbingCenterResp, 0)

	// 防止size传的过大导致50条的约束出错
	if size > 10 {
		size = 10
	}
	// 最多返回50条
	if page*size > max {
		return
	}
	info, err := new(redismodels.UserInfo).GetUserInfo(userId)
	if err != nil {
		return "获取用户信息失败", r, err
	}

	gender = info.UserGender

	count, err := new(dbmodels.AppSparringSkill).QueryMatchingOnCount(userId)
	if err != nil {
		return "查询用户抢单开关失败", r, err
	}
	if count == 0 {
		return "暂无技能打开抢单开关", r, errors.New("matching off")
	}

	// 获取用户所有认证游戏id
	skillIdData, err := new(dbmodels.AppSparringSkill).QuerySkillId(userId)
	if err != nil {
		return "查询用户认证游戏失败", r, err
	}
	for _, v := range skillIdData {
		skillIds = append(skillIds, v.SkillSkillID)
	}

	// 置顶数据获取
	_, topData, topErr := new(dbmodels.AppSkillOrderSpeedMatching).QueryPageSkillIdByTime(page, size, skillIds, gender, userId)
	if topErr != nil {
		return "查询数据失败", r, err
	}

	total, data, err := new(dbmodels.AppSkillOrderSpeedMatching).QueryPageSkillId(page, size, skillIds, gender)
	if err != nil {
		return "查询用户极速匹配列表失败", r, err
	}

	// 转为map,稍后进行去重
	topMap := make(map[int64]int64)
	if msg, list, err = s.handleSpeedListData(topData, list, func(v dbmodels.AppSkillOrderSpeedMatching) bool {
		topMap[v.MatchingId] = 1

		// 如果是之后的页数, 直接跳过数据拼接
		return page <= 1
	}); err != nil {
		return
	}

	if msg, list, err = s.handleSpeedListData(data, list, func(v dbmodels.AppSkillOrderSpeedMatching) bool {
		return topMap[v.MatchingId] <= 0
	}); err != nil {
		return
	}

	r.Page = page
	r.Size = size
	r.Total = total
	r.TotalPages = utils.FuncTotalPages(total, size)
	r.List = list

	return
}

// 格式化其他要求 并且拼接 大神中心的列表数据
func (s *SpeedMatching) handleSpeedListData(data []dbmodels.AppSkillOrderSpeedMatching, list []response.OrderGrabbingCenterResp, fn func(dbmodels.AppSkillOrderSpeedMatching) bool) (msg string, result []response.OrderGrabbingCenterResp, err error) {
	for _, v := range data {
		// 去重
		if !fn(v) {
			continue
		}

		var other []response.MatchingOtherRequirements

		if v.MatchingOtherRequirements != "" && v.MatchingOtherRequirements != "null" {
			err = json.Unmarshal([]byte(v.MatchingOtherRequirements), &other)
			if err != nil {
				return "格式化其他要求失败", result, err
			}
		}

		list = append(list, response.OrderGrabbingCenterResp{
			UserId:                    v.MatchingUserId,
			SparringUserId:            v.MatchingSparringUserId,
			Nickname:                  v.SystemUser.UserNickname,
			MatchingId:                v.MatchingId,
			SkillName:                 v.AppSkill.SkillName,
			SkillIcon:                 v.AppSkill.SkillIconurl,
			MatchingPrice:             v.MatchingPrice,
			MatchingWay:               v.MatchingWay,
			MatchingCount:             v.MatchingCount,
			MatchingOtherRequirements: other,
			MatchingRemark:            v.MatchingRemark,
			UserGender:                v.MatchingGender,
			MatchingStatus:            v.MatchingStatus,
		})
	}

	result = list

	return
}

// 大神抢单
func (s *SpeedMatching) GrabbingOrders(matchingId int64, userId int64) (msg string, r response.GrabbingOrdersResp, err error) {
	var (
		amount         int64 // 计算价格
		income         int64 // 主播收入
		unionFee       int64 // 公会扣除
		protectionTime int64 // 保护时间
	)
	key := fmt.Sprintf("%s%d", s.lockKeyMatchingSpeed, matchingId)
	lock, isLock := utils.AcquireLock(key, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
	if !isLock {
		r.Status = dbmodels.SPEED_MATCHING_STATUS_COMPLETED
		return "手慢了，订单已被其他大神抢先一步", r, nil
	}
	// 释放锁
	defer utils.ReleaseLock(key, lock)

	// 查询极速匹配id
	speedMatching, err := new(dbmodels.AppSkillOrderSpeedMatching).QueryByMatchingId(matchingId)
	if err != nil {
		return "查询极速匹配信息失败", r, err
	}
	if speedMatching.MatchingStatus == dbmodels.SPEED_MATCHING_STATUS_EXPIRED {
		r.Status = dbmodels.SPEED_MATCHING_STATUS_EXPIRED
		return "订单已过期", r, nil
	}
	if speedMatching.MatchingStatus == dbmodels.SPEED_MATCHING_STATUS_CANCEL {
		r.Status = dbmodels.SPEED_MATCHING_STATUS_CANCEL
		return "订单已被取消", r, nil
	}
	if speedMatching.MatchingStatus == dbmodels.SPEED_MATCHING_STATUS_COMPLETED {
		r.Status = dbmodels.SPEED_MATCHING_STATUS_COMPLETED
		return "手慢了，订单已被其他大神抢先一步", r, nil
	}

	if speedMatching.MatchingUserId == userId {
		return "不能抢自己的单", r, errors.New("user error")
	}

	// 查询大神是否支持抢单
	sparring, err := new(dbmodels.AppSparringSkill).QueryByUserIdSkillSkillId(userId, speedMatching.MatchingSkillId)
	if err != nil {
		return "查询用户是否支持抢单失败", r, err
	}

	if sparring.SkillStatus != dbmodels.SPARRING_SKILL_STATUS_OK || sparring.SkillSetInfoStatus != dbmodels.SPARRING_SKILL_SET_INFO_STATUS_OK {
		return "您的技能状态不支持抢单", r, errors.New("status error")
	}

	// 查询下单用户信息
	user, err := new(dbmodels.SystemUser).UserIdByUser(speedMatching.MatchingUserId)
	if err != nil {
		return "查询下单用户信息失败", r, err
	}

	// 查询大神用户信息
	sparringInfo, err := new(dbmodels.SystemUser).UserIdByUser(userId)
	if err != nil {
		return "查询下单用户信息失败", r, err
	}

	// 查询技能详情
	skill, err := new(dbmodels.AppSkill).QueryBySkillId(speedMatching.MatchingSkillId)
	if err != nil {
		return "查询技能详情失败", r, err
	}
	if len(skill.AppSkillPrice) == 0 {
		return "获取单价失败", r, errors.New("price error")
	}
	protectionTime = skill.AppSkillPrice[0].PriceProtectionTime * speedMatching.MatchingCount
	orderTime := skill.AppSkillPrice[0].PriceTime * speedMatching.MatchingCount

	// 查询抽成
	commission, err := new(dbmodels.AppUserUnionCommission).GetCommissionByUserIdAndType(sparring.SkillUserID, sparringInfo.UserUnionId, dbmodels.COMMISSION_TYPE_SKILL_ORDER, dbmodels.DEFAULT_SKILL_ORDER_COMMISSION_LEVEL)
	if err != nil {
		return "查询抽成失败", r, err
	}

	// 计算价格
	amount = speedMatching.MatchingPrice * speedMatching.MatchingCount
	// 主播收入
	income = amount * commission.CommissionUser / 100
	// 公会扣除
	unionFee = amount * commission.CommissionUnion / 100

	now := time.Now().Unix()
	// 开始创建进行中订单
	tx := utils.GEngine.Begin()
	oderBaseId := dbmodels.IDBuilderGetId(utils.REDIS_IDBUILDER_ORDER_ID)
	model := dbmodels.AppSkillOrder{
		OrderId:              oderBaseId,
		OrderBuyUserId:       speedMatching.MatchingUserId,
		OrderBuyUserUnionId:  user.UserUnionId,
		OrderSellUserId:      userId,
		OrderSellUserUnionId: sparringInfo.UserUnionId,
		OrderSkillId:         speedMatching.MatchingSkillId,
		OrderSparringSkillId: sparring.SkillID,
		OrderPrice:           speedMatching.MatchingPrice,
		OrderWay:             speedMatching.MatchingWay,
		OrderTime:            orderTime,
		OrderProtectionTime:  protectionTime, // 保护时间
		OrderCount:           speedMatching.MatchingCount,
		OrderAmount:          amount,
		OrderUnionFee:        amount - income - unionFee,
		OrderFee:             unionFee,
		OrderIncome:          income,
		OrderStatus:          dbmodels.SKILL_ORDER_STATUS_CONFIRM,  // 进入接单状态
		OrderType:            dbmodels.SKILL_TYPE_RAND,             // 定向单
		OrderPayStatus:       dbmodels.SKILL_ORDER_PAY_STATUS_PAID, // 已支付
		OrderPayTime:         now,
		OrderConfirmStatus:   dbmodels.SKILL_ORDER_CONFIRM_STATUS_ACCEPT,
		OrderConfirmTime:     now,
		OrderRemark:          speedMatching.MatchingRemark,
	}

	err = model.Create(tx)
	if err != nil {
		tx.Rollback()
		return "创建进行中订单失败", r, err
	}

	update := make(map[string]interface{})
	update["matching_sparring_user_id"] = userId
	update["matching_status"] = dbmodels.SPEED_MATCHING_STATUS_COMPLETED
	update["matching_order_id"] = oderBaseId

	err = new(dbmodels.AppSkillOrderSpeedMatching).Update(tx, matchingId, update)
	if err != nil {
		tx.Rollback()
		return "更新极速匹配状态失败", r, err
	}

	tx.Commit()

	// 查询订单详情
	_, orderInfo, err := new(dbmodels.AppSkillOrder).QueryByOrderId(model.OrderId)
	if err != nil {
		return "查询订单详情失败", r, err
	}

	// 投递队列,接单后处理
	services.NewSkillOrder().Confirm.OrdersHandler(&orderInfo)

	// 给用户发送匹配结果
	go s.sendMatchingResultMsg(sparringInfo.UserID, speedMatching.MatchingUserId, sparring.SkillID)
	r.Ok = 1
	r.Status = dbmodels.SPEED_MATCHING_STATUS_COMPLETED
	return "抢单成功", r, nil
}

// Rematch 重新匹配
func (s *SpeedMatching) Rematch(userId int64) (msg string, r response.SMPlaceOrderResp, err error) {
	key := fmt.Sprintf("%s%d", utils.REDIS_USER_WALLET_LOCK, userId)
	lock, isLock := utils.AcquireLock(key, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
	if !isLock {
		return "请稍后再试", r, errors.New("lock fail")
	}
	// 释放锁
	defer utils.ReleaseLock(key, lock)
	// 查询是否有进行中
	count, err := new(dbmodels.AppSkillOrderSpeedMatching).QueryPendingOrder(userId)
	if err != nil {
		return "查询进行中订单失败", r, err
	}

	if count > 0 {
		return "您有订单进行中", r, errors.New("order pending")
	}

	// 查询最后一单详情
	last, err := new(dbmodels.AppSkillOrderSpeedMatching).QueryLast(userId)
	if err != nil {
		return "查询最后一单失败", r, err
	}
	if last.MatchingStatus != dbmodels.SPEED_MATCHING_STATUS_EXPIRED {
		return "不符合重新匹配条件", r, errors.New("matching error")
	}

	// 查询随机单价格
	skill, err := new(dbmodels.AppSkill).QueryBySkillId(last.MatchingSkillId)
	if err != nil {
		return "查询技能详情失败", r, err
	}

	if len(skill.AppSkillPrice) == 0 {
		return "游戏参数有误", r, errors.New("skill params error")
	}

	if skill.AppSkillPrice[0].PricePriceRand == 0 {
		return "游戏价格有误", r, errors.New("skill price error")
	}

	tx := utils.GEngine.Begin()
	// 创建
	model := &dbmodels.AppSkillOrderSpeedMatching{
		MatchingUserId:  userId,
		MatchingSkillId: last.MatchingSkillId,
		MatchingPrice:   last.MatchingPrice,
		MatchingWay:     last.MatchingWay,
		MatchingCount:   last.MatchingCount,
		MatchingGender:  last.MatchingGender,
		MatchingRemark:  last.MatchingRemark,
		MatchingStatus:  dbmodels.SPEED_MATCHING_STATUS_PENDING,
	}
	if last.MatchingOtherRequirements != "" {
		model.MatchingOtherRequirements = last.MatchingOtherRequirements
	}

	err = model.Create(tx)
	if err != nil {
		tx.Rollback()
		return "创建极速匹配单失败", r, err
	}

	// 减少用户余额
	over, err := new(dbmodels.AppUserWallet).UpdateWalletTotalOver(tx, userId, false, true, last.MatchingPrice*last.MatchingCount)
	if err != nil {
		tx.Rollback()
		return "减少用户余额失败", r, err
	}
	// 更新缓存金额
	err = new(redismodels.UserInfo).UpdateUserWalletTotalOver(userId, over.WalletTotalOver)
	if err != nil {
		tx.Rollback()
		return "更新用户缓存余额失败", r, err
	}

	tx.Commit()

	content := &sendMatchMsgTxt{
		SkillId:        last.MatchingSkillId,
		Gender:         last.MatchingGender,
		Count:          last.MatchingCount,
		MatchingRemark: last.MatchingRemark,
	}
	// 给大神发送消息
	go s.sendMatchMsg(content, model.MatchingId, model.MatchingPrice, model.MatchingWay, skill.SkillName, last.MatchingUserId)

	// 创建延迟队列,自动取消极速匹配订单
	go rabbitmqProducer.MatchingCancel(model.MatchingId)

	r.Balance = over.WalletTotalOver
	r.MatchingId = model.MatchingId
	return "", r, nil
}

// 获取大神信息
func (s *SpeedMatching) getSparringInfo(uid, sid int64) (data response.SMQueryStatusResp, err error) {
	// 查询大神详情
	sparring, err := new(dbmodels.AppSparringSkill).QuerySparringSkillID(uid, sid)
	if err != nil {
		return data, err
	}
	msg, err := s.querySparringInfo(sparring.SkillID)
	if err != nil {
		return data, err
	}
	data.Status = 2

	// 转换类型
	tmp := msg.MatchingSparringMsg.Feature
	l := len(tmp)
	feature := make([]response.Feature, 0, l)
	for i := 0; i < l; i++ {
		f := response.Feature{
			FeatureName:   tmp[i].FeatureName,
			FeatureValues: tmp[i].FeatureValues,
		}
		feature = append(feature, f)
	}
	data.SparringUserId = uid
	data.SparringInfo = &response.SMQueryStatusSparringInfo{
		UserId:        uid,
		Avatar:        msg.MatchingSparringMsg.Avatar,
		NickName:      msg.MatchingSparringMsg.NickName,
		Level:         msg.MatchingSparringMsg.Level,
		Feature:       feature,
		SkillIcon:     msg.MatchingSparringMsg.SkillIcon,
		SoundUrl:      msg.MatchingSparringMsg.SoundUrl,
		SoundTime:     msg.MatchingSparringMsg.SoundTime,
		ServiceNumber: msg.MatchingSparringMsg.ServiceNumber,
		FavorableRate: msg.MatchingSparringMsg.FavorableRate,
		Introduction:  msg.MatchingSparringMsg.Introduction,
		SkillName:     msg.MatchingSparringMsg.SkillName,
		Gender:        msg.MatchingSparringMsg.Gender,
		Age:           msg.MatchingSparringMsg.Age,
	}
	return
}
