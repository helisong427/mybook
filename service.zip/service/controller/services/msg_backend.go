package services

import (
	"fmt"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"gamers/utils/chuanglan/sms"
	"strconv"
	"strings"
)

// 后台审核的一些消息
type Backend struct {
}

func InitBackend() Backend {
	return Backend{}
}

const (
	ASSISTANT_MATERIAL_REFUSE                             = "assistant_material_refuse"                         // 素材审核不通过
	ASSISTANT_TWEET_REFUSE                                = "assistant_tweet_refuse"                            // 动态审核不通过
	ASSISTANT_EXTRACT_FAIL                                = "assistant_order_extract_fail"                      // 提现失败
	ASSISTANT_EXTRACT_SUCCESS                             = "assistant_order_extract_success"                   // 提现成功
	ASSISTANT_ORDER_SPARRING_KEY_APPEAL_OK_FOR_SPARRING   = "assistant_order_sparring_appeal_ok_for_sparring"   // 申诉成功（全额退款）
	ASSISTANT_ORDER_SPARRING_KEY_APPEAL_FAIL_FOR_SPARRING = "assistant_order_sparring_appeal_fail_for_sparring" // 申诉失败
	ASSISTANT_ORDER_USER_KEY_APPEAL_OK_FOR_USER           = "assistant_order_user_appeal_ok_for_user"           // 申诉成功（全额退款）
	ASSISTANT_ORDER_USER_KEY_APPEAL_FAIL_FOR_USER         = "assistant_order_user_appeal_fail_for_user"         // 申诉失败
	ASSISTANT_STUDIO_BE_CHECKED                           = "assistant_studio_be_checked"                       // 房间资料被审核
)

// 动态审核不通过
func (s Backend) TweetRefuse(checkTime int64, userId string) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_TWEET_REFUSE)
	if err != nil {
		utils.LogErrorF("获取动态审核消息model失败,err:%s", err.Error())
		return
	}
	tmStr := utils.MsgTimeFormatSecond(checkTime)
	tip := strings.NewReplacer("${check_time_second}", tmStr).Replace(msgModel.MsgContent)
	skillMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: skillMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId)
	if err != nil {
		utils.LogErrorF("发送动态审核推送失败,err:%s", err.Error())
	}
	return
}

// 素材审核不通过
func (s Backend) MaterialRefuse(checkTime int64, userId string) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_MATERIAL_REFUSE)
	if err != nil {
		utils.LogErrorF("获取素材审核消息model失败,err:%s", err.Error())
		return
	}
	tmStr := utils.MsgTimeFormatSecond(checkTime)
	tip := strings.NewReplacer("${check_time_second}", tmStr).Replace(msgModel.MsgContent)
	skillMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: skillMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId)
	if err != nil {
		utils.LogErrorF("发送素材审核推送失败,err:%s", err.Error())
	}
	return
}

// 房间信息审核
func (s Backend) StudioRefuse(checkTime int64, userId string) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_STUDIO_BE_CHECKED)
	if err != nil {
		utils.LogErrorF("获取房间审核消息model失败,err:%s", err.Error())
		return
	}
	tmStr := utils.MsgTimeFormatSecond(checkTime)
	tip := strings.NewReplacer("${check_time_second}", tmStr).Replace(msgModel.MsgContent)
	skillMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: skillMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId)
	if err != nil {
		utils.LogErrorF("发送房间审核推送失败,err:%s", err.Error())
	}
	return
}

// 大神冻结
func (s Backend) SparringForbidden(skillName, qq, userId string) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_SPARRING_FORBIDDEN)
	if err != nil {
		utils.LogErrorF("获取冻结大神消息model失败,err:%s", err.Error())
		return
	}
	tip := strings.NewReplacer("${skill_name}", skillName, "${qq}", qq).Replace(msgModel.MsgContent)
	skillMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: skillMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId)
	if err != nil {
		utils.LogErrorF("发送冻结大神推送失败,err:%s", err.Error())
	}
	return
}

// 提现失败
func (s Backend) ExtractFail(tips, userId, nickname string, applyTime int64) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_EXTRACT_FAIL)
	if err != nil {
		utils.LogErrorF("获取提现失败消息model失败,err:%s", err.Error())
		return
	}
	tmStr := utils.MsgTimeFormatDay(applyTime)
	param, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_SERVICE_QQ)
	if err != nil {
		utils.LogErrorF("获取客服qq出错,err:%s", err.Error())
	}
	tip := strings.NewReplacer("${review_tips}", tips, "${date}", tmStr, "${qq}", param["value"]).Replace(msgModel.MsgContent)
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId)
	if err != nil {
		utils.LogErrorF("发送提现失败推送失败,err:%s", err.Error())
	}
	if msgModel.MsgSmsSend == dbmodels.MSG_SEND_SMS_YES {
		uid, err := strconv.ParseInt(userId, 10, 64)
		if err != nil {
			utils.LogErrorF("发送提现失败成功推送失败,无法解析用户id,err:%s", err.Error())
		}
		mobile, err := new(dbmodels.SystemUser).GetUserMobile(uid)
		if err != nil {
			utils.LogErrorF("发送用户提现失败短信推送失败,获取用户手机号失败,err:%s", err.Error())
		}
		sms.SendSms(1, msgModel.MsgSmsContent, fmt.Sprintf("%s,%s,%s", mobile, tips, tmStr))
	}
}

// 提现成功
func (s Backend) ExtractSuccess(userId string, applyTime int64) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_EXTRACT_SUCCESS)
	if err != nil {
		utils.LogErrorF("获取提现成功消息model失败,err:%s", err.Error())
		return
	}
	tmStr := utils.MsgTimeFormatDay(applyTime)
	tip := strings.NewReplacer("${date}", tmStr).Replace(msgModel.MsgContent)
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId)
	if err != nil {
		utils.LogErrorF("发送提现成功推送失败,err:%s", err.Error())
	}
	if msgModel.MsgSmsSend == dbmodels.MSG_SEND_SMS_YES {
		uid, err := strconv.ParseInt(userId, 10, 64)
		if err != nil {
			utils.LogErrorF("发送提现失败成功推送失败,无法解析用户id,err:%s", err.Error())
		}
		mobile, err := new(dbmodels.SystemUser).GetUserMobile(uid)
		if err != nil {
			utils.LogErrorF("发送用户提现失败短信推送失败,获取用户手机号失败,err:%s", err.Error())
		}
		sms.SendSms(1, msgModel.MsgSmsContent, fmt.Sprintf("%s,%s", mobile, tmStr))
	}
}

// 用户申诉失败,用户消息
func (s Backend) OrderUserAppealFailToUser(orderId, userId string) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_ORDER_USER_KEY_APPEAL_FAIL_FOR_USER)
	if err != nil {
		utils.LogErrorF("获取用户申诉成功消息model失败,err:%s", err.Error())
		return
	}
	param, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_SERVICE_QQ)
	if err != nil {
		utils.LogErrorF("获取客服qq出错,err:%s", err.Error())
	}
	tip := strings.NewReplacer("${order_id}", orderId, "${qq}", param["value"]).Replace(msgModel.MsgContent)
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId)
	if err != nil {
		utils.LogErrorF("发送用户申诉成功推送失败,err:%s", err.Error())
	}
	if msgModel.MsgSmsSend == dbmodels.MSG_SEND_SMS_YES {
		uid, err := strconv.ParseInt(userId, 10, 64)
		if err != nil {
			utils.LogErrorF("发送用户申诉成功推送失败,无法解析用户id,err:%s", err.Error())
		}
		mobile, err := new(dbmodels.SystemUser).GetUserMobile(uid)
		if err != nil {
			utils.LogErrorF("发送用户申诉成功短信推送失败,获取用户手机号失败,err:%s", err.Error())
		}
		sms.SendSms(1, msgModel.MsgSmsContent, fmt.Sprintf("%s,%s", mobile, orderId))
	}
}

// 用户申诉失败,大神消息
func (s Backend) OrderUserAppealFailToSparring(orderId, userId string) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_ORDER_SPARRING_KEY_APPEAL_OK_FOR_SPARRING)
	if err != nil {
		utils.LogErrorF("获取用户申诉成功消息model失败,err:%s", err.Error())
		return
	}
	tip := strings.NewReplacer("${order_id}", orderId).Replace(msgModel.MsgContent)
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId)
	if err != nil {
		utils.LogErrorF("发送用户申诉成功推送失败,err:%s", err.Error())
	}
}

// 用户申诉成功,用户消息
func (s Backend) OrderUserAppealSuccessToUser(orderId, userId string, amount int) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_ORDER_USER_KEY_APPEAL_OK_FOR_USER)
	if err != nil {
		utils.LogErrorF("获取用户申诉成功消息model失败,err:%s", err.Error())
		return
	}
	tip := strings.NewReplacer("${order_id}", orderId, "${refund_amount}", strconv.Itoa(amount/100)).Replace(msgModel.MsgContent)
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId)
	if err != nil {
		utils.LogErrorF("发送用户申诉成功推送失败,err:%s", err.Error())
	}
}

// 用户申诉成功,大神消息
func (s Backend) OrderUserAppealSuccessToSparring(orderId, userId string, amount int) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_ORDER_SPARRING_KEY_APPEAL_FAIL_FOR_SPARRING)
	if err != nil {
		utils.LogErrorF("获取大神申诉失败消息model失败,err:%s", err.Error())
		return
	}
	tip := strings.NewReplacer("${order_id}", orderId, "${refund_amount}", strconv.Itoa(amount/100)).Replace(msgModel.MsgContent)
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId)
	if err != nil {
		utils.LogErrorF("发送大神申诉失败推送失败,err:%s", err.Error())
	}
}
