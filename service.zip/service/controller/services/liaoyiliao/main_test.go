/**
 * @Author: 陈建君
 * @Date: 2021/3/14 2:30 下午
 * @Description:
 */

package liaoyiliao

import (
	"fmt"
	"os"
	"testing"

	"github.com/go-redis/redis"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"

	"gamers/utils"
)

func TestMain(m *testing.M) {
	// utils.Config = &config.FileConfig{}
	//
	// utils.LoggerInit()

	reportConfig := mysql.New(mysql.Config{
		DSN:               "root:123456@tcp(127.0.0.1:3306)/dig?charset=utf8&parseTime=True&loc=Local",
		DefaultStringSize: 1024, // string 类型字段的默认长度
	})
	//newLogger := utils.NewGormLog(
	//	log.New(os.Stdout, "\r\n", log.LstdFlags), // io writer
	//	logger.Config{
	//		SlowThreshold: time.Second, // 慢 SQL 阈值
	//		LogLevel:      logger.Info, // Log level
	//		Colorful:      true,        // 禁用彩色打印
	//	},
	//)
	var err error
	utils.GEngine, err = gorm.Open(reportConfig, &gorm.Config{
		// Logger:      newLogger,
		QueryFields: true,
	})
	if err != nil {
		fmt.Println("初始化主数据库失败" + err.Error())
		return
	}

	addr := fmt.Sprintf("%s:%s", "127.0.0.1", "6379")
	rOpt := &redis.Options{
		Addr:     addr,
		Password: "",
		DB:       0,
		PoolSize: 20,
	}
	utils.RedisClient = redis.NewClient(rOpt)

	_, err = utils.RedisClient.Ping().Result()
	if err != nil {
		fmt.Printf("ping redis[%s]失败, %s", addr, err.Error())
		return
	}
	fmt.Println("连接redis成功")

	os.Exit(m.Run())
}
