/**
 * @Author: 陈建君
 * @Date: 2021/3/13 10:04 上午
 * @Description: 聊一聊用户数据缓存模型
 */

package liaoyiliao

import (
	"fmt"
	"strconv"
	"time"

	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"

	"github.com/go-redis/redis"
	"gorm.io/gorm"
)

type (
	CacheMod struct {
		redisClient *redis.Client
		gdb         *gorm.DB
	}

	// 用户模型
	UserList struct {
		List        []*UserInfo `json:"list"`         // 用户列表
		OffSet      int64       `json:"off_set"`      // 当前数据游标
		RegOffSet   int64       `json:"reg_off_set"`  // 当前注册用户游标
		CacheStatus uint8       `json:"cache_Status"` // 缓存状态 1:在线 2:离线 TODO 新版本全部更新完成以后删除
	}

	UserInfo struct {
		UserId       int64  `json:"user_id"`       // 用户id
		UserNickname string `json:"user_nickname"` // 用户昵称
		UserIconurl  string `json:"user_iconurl"`  // 用户头像
		UserGender   int    `json:"user_gender"`   // 用户性别
		UserAge      int    `json:"user_age"`      // 用户年龄
	}

	// 配置信息
	configMod struct {
		// 注册时间(离当前时间的时间戳)
		RegTimes int64
		// 撩的次数
		Num uint32
	}
)

var (
	// 全局缓存数据key
	globalCacheKey = "liaoyiliao:global:cache:users"

	// 缓存桶key(获取撩一撩列表数据的时候，先通过这个拿到对应的桶key,再组合"offline""online")
	cacheNodeKey = "liaoyiliao:cache:node:key"
	// 当前在线用户桶
	cacheNodeOnline = "online"
	// 加载以后新注册的用户桶
	cacheNodeReg = "register"
)

func NewCacheMod() *CacheMod {
	return &CacheMod{
		redisClient: utils.RedisClient,
		gdb:         utils.GEngine,
	}
}

// 读取配置信息
func (its *CacheMod) loadConfig() (config []configMod, err error) {
	// 从数据库加载配置信息
	configs, err := new(dbmodels.SystemLiaoyiliaoConfig).QueryAll()
	if err != nil {
		return
	}
	for _, v := range configs {
		config = append(config, configMod{
			RegTimes: time.Hour.Milliseconds() * v.RegisterTime,
			Num:      v.Amount,
		})
	}
	return
}

// 初始化全局缓存对象,在每日定时时间到的时候重新初始化内存对象
func (its *CacheMod) InitGlobalCache() {
	// 获取配置信息
	config, err := its.loadConfig()
	if err != nil {
		utils.Logger.Error("获取配置信息失败")
		return
	}

	// 删除全局数据，从数据库重新加载
	err = its.redisClient.Del(globalCacheKey, cacheNodeReg).Err()
	if err != nil {
		utils.Logger.Error("初始化缓存数据，删除redis全局缓存失败")
		return
	}

	limit, offset := 1000, 0
	for {
		var users []dbmodels.SystemUser
		err := its.gdb.Select("user_id, created").
			Where("user_status < ?", dbmodels.USER_STATUS_LOCK).
			Order("created desc").
			Limit(limit).
			Offset(offset).
			Find(&users).
			Error
		if err != nil {
			utils.LogErrorF("获取用户信息失败:err[%s]", err.Error())
			return
		}

		// 根据用户id从redis获取信息
		for _, v := range users {
			num := 1

			// 计算注册时间与当前时间的差时, 根据时间差计算能被撩的次数
			subT := time.Now().Unix() - v.BaseModel.Created
			for k := range config {
				if subT < config[k].RegTimes {
					num = int(config[k].Num)
					break
				}
			}

			// 保存用户id与对应的次数
			its.redisClient.HSet(globalCacheKey, strconv.FormatInt(v.UserID, 10), strconv.Itoa(num))
		}

		if len(users) < limit {
			break
		} else {
			offset += limit
			// 从数据库检索二十万的数据出来（防止用户量过大）
			if offset > 200000 {
				break
			}
		}
	}
}

// 替换缓存桶
func (its *CacheMod) RepCacheData() {
	// 获取当前kye值
	currentKey, _ := its.redisClient.Get(cacheNodeKey).Result()

	// 从全局数据生成预备缓存
	var (
		cursor uint64 = 0
		keys   []string
		uRMod  = &redismodels.UserInfo{}
		// 新的缓存key
		cacheKey = fmt.Sprintf("%s:%d:", cacheNodeKey, time.Now().Unix())
	)
	for {
		keys, cursor, _ = its.redisClient.HScan(globalCacheKey, cursor, "", 1000).Result()
		for i := 0; i < len(keys); i += 2 {
			userId, _ := strconv.ParseInt(keys[i], 10, 64)
			num, _ := strconv.Atoi(keys[i+1])
			// 次数小于0的数据过滤
			if num <= 0 {
				continue
			}
			// 查询用户状态,把在线与离线的用户分开
			uInfo, err := uRMod.GetUserInfo(userId)
			if err != nil {
				continue
			}

			// 过滤错误数据
			if uInfo.UserID == 0 ||
				uInfo.UserIsOnline != dbmodels.USER_IS_ONLINE_ONLINE ||
				uInfo.UserNickname == "" ||
				uInfo.UserIconurl == "" {
				continue
			}

			// 序列化数据
			bStr, _ := uInfo.MarshalBinary()
			_, _ = its.redisClient.LPush(cacheKey+cacheNodeOnline, bStr).Result()
		}

		if cursor == 0 {
			break
		}
	}

	// 设置新的key
	its.redisClient.Set(cacheNodeKey, cacheKey, 0)
	// 删除旧的key
	its.redisClient.Del(currentKey)
	its.redisClient.Del(currentKey + cacheNodeOnline)
	// its.redisClient.Del(currentKey + cacheNodeOffline)
}

// 递减用户次数
func (its *CacheMod) DecreaseUserNum(userId int64) (err error) {
	// eval脚本，用于对用户被撩次数减一
	var script = redis.NewScript(`
		for i,v in pairs(KEYS) do
		redis.call('hset', ARGV[1], v, tostring(tonumber(redis.call('hget', ARGV[1], v))-1))
		end;
		return 0`)

	_, err = script.Eval(
		its.redisClient,
		[]string{
			strconv.FormatInt(userId, 10),
		},
		globalCacheKey,
	).Result()

	return
}

// 获取撩一撩列表
// offSet: 当前在线用户队列游标
// regOffSet: 当前注册用户队列游标
// userId: 当前获取列表的用户id
// limit: 获取数量
func (its *CacheMod) UserList(
	offSet int64,
	regOffSet int64,
	userId int64,
	limit int64,
) (
	data UserList,
	err error,
) {
	// 获取key
	key, err := its.redisClient.Get(cacheNodeKey).Result()
	if err != nil {
		utils.Logger.Error(fmt.Sprintf("撩一撩列表，获取撩一撩缓存key失败[%s]", err))
		return
	}

	cacheKey := key + cacheNodeOnline
	regCacheKey := key + cacheNodeReg

	// 获取列表数据
	newOffSet, newRegOffSet, kvList, err := its.getData(offSet, regOffSet, limit, cacheKey, regCacheKey)
	if err != nil {
		utils.Logger.Error("撩一撩列表，获取撩一撩缓存数据失败")
		return
	}

	userList := make([]*UserInfo, 0, len(kvList))
	for i := 0; i < len(kvList); i++ {
		info := redismodels.UserInfo{}
		err = info.UnmarshalBinary([]byte(kvList[i]))
		if err != nil {
			continue
		}

		// 过滤掉是自己的数据
		if userId == info.UserID {
			continue
		}

		userList = append(userList, &UserInfo{
			UserId:       info.UserID,
			UserNickname: info.UserNickname,
			UserIconurl:  info.UserIconurl,
			UserGender:   info.UserGender,
			UserAge:      info.UserAge,
		})
	}
	data.List = userList
	data.OffSet = newOffSet
	data.RegOffSet = newRegOffSet

	return
}

func (its *CacheMod) getData(
	offSet int64,
	regOffSet int64,
	limit int64,
	cacheKey string,
	regCacheKey string,
) (
	newOffSet int64,
	newRegOffSet int64,
	kvList []string,
	err error,
) {
	// 获取总长度
	sum, err := its.redisClient.LLen(cacheKey).Result()
	if err != nil {
		return
	}

	if regOffSet < 0 { // TODO 新版本上线以后直接删除
		var onlineList []string

		stop := offSet + limit - 1
		// 根据总数计算结束游标
		if offSet+limit >= sum {
			stop = sum - 1
		}
		// 获取数据
		onlineList, err = its.redisClient.LRange(cacheKey, offSet, stop).Result()
		if err != nil {
			return
		}
		kvList = append(kvList, onlineList...)

		if int64(len(onlineList)) < limit && offSet > 0 {
			// 计算结束游标
			offSet = 0
			stop = limit - int64(len(kvList)) - 1
			if (sum - int64(len(kvList))) < stop {
				stop = sum - int64(len(kvList)) - 1
			}
			kvCList, _ := its.redisClient.LRange(cacheKey, 0, stop).Result()
			kvList = append(kvList, kvCList...)
			newOffSet = stop
		} else {
			newOffSet = offSet + int64(len(kvList))
		}

		return
		// // 如果没有获取到数据或者获取到的数据不够
		// if sum >= int64(len(onlineList)) && (len(onlineList) == 0 || int64(len(onlineList)) < limit) {
		// 	// 从头取
		// 	offSet = 0
		// 	// 计算取到那个位置
		// 	limit = limit - int64(len(kvList))
		// 	if (old - offSet) < limit  {
		// 		limit = old - offSet
		// 	}
		//
		// 	// 可以忽略err，失败也会返回前面查询到的数据
		// 	kvCList, _ := its.redisClient.LRange(cacheKey, offSet, offSet+limit-1).Result()
		// 	kvList = append(kvList, kvCList...)
		// }
		//
		// newOffSet = offSet + int64(len(kvList))
		//
		// return
	}

	// 注册列表默认取五个
	var r int64 = 5

	// 获取新注册的用户，取r条
	regList, _ := its.redisClient.LRange(regCacheKey, regOffSet, regOffSet+r-1).Result()
	kvList = append(kvList, regList...)
	if int64(len(kvList)) >= limit {
		newRegOffSet = regOffSet + r
		return
	}
	r = int64(len(kvList))
	newRegOffSet = regOffSet + r
	// 扣除已取的
	limit = limit - r

	// 根据总数计算结束游标
	stop := offSet + limit - 1
	if offSet+limit >= sum {
		stop = sum - 1
	}
	// 获取数据
	onlineList, err := its.redisClient.LRange(cacheKey, offSet, stop).Result()
	if err != nil {
		return
	}
	kvList = append(kvList, onlineList...)
	if int64(len(onlineList)) < limit && offSet > 0 {
		// 计算结束游标
		offSet = 0
		stop = limit - int64(len(kvList)) - 1
		if (sum - int64(len(kvList))) < stop {
			stop = sum - int64(len(kvList)) - 1
		}
		kvCList, _ := its.redisClient.LRange(cacheKey, 0, stop).Result()
		kvList = append(kvList, kvCList...)
		newOffSet = stop
	} else {
		newOffSet = offSet + int64(len(kvList))
	}

	return

	// // 获取在线数据
	// onlineList, err := its.redisClient.LRange(cacheKey, offSet, offSet+limit-1).Result()
	// if err != nil {
	// 	return
	// }
	// kvList = append(kvList, onlineList...)
	// // 如果没有获取到数据或者获取到的数据不够
	// // 如果offSet本来就是从0开始取的。则不再从头开始取
	// if sum >= limit && (len(kvList) == 0 || int64(len(kvList)) < limit) {
	// 	// 从离线缓存桶获取
	// 	offSet = 0
	// 	// 离线里面获取剩余的数据
	// 	limit = limit - int64(len(kvList))
	//
	// 	// 可以忽略err，失败也会返回前面查询到的数据
	// 	kvCList, _ := its.redisClient.LRange(cacheKey, offSet, offSet+limit-1).Result()
	// 	kvList = append(kvList, kvCList...)
	// }
	//
	// newOffSet = offSet + int64(len(kvList))
	//
	// return
}

// 新注册用户加入全局缓存
func (its *CacheMod) AddGlobalCache(user *dbmodels.SystemUser) {
	// 获取配置信息
	config, err := its.loadConfig()
	if err != nil {
		utils.LogErrorF("获取配置信息失败:%s", err.Error())
		return
	}

	// 计算注册时间与当前时间的差时, 根据时间差计算能被撩的次数
	subT := time.Now().Unix() - user.BaseModel.Created
	num := 1
	for k := range config {
		if subT < config[k].RegTimes {
			num = int(config[k].Num)
			break
		}
	}

	// 保存用户id与对应的次数
	err = its.redisClient.HSet(globalCacheKey, strconv.FormatInt(user.UserID, 10), strconv.Itoa(num)).Err()
	if err != nil {
		utils.LogErrorF("新注册用户加入全局缓存失败:%s", err.Error())
		return
	}

	// 查询用户状态
	uRMod := &redismodels.UserInfo{}
	uInfo, err := uRMod.GetUserInfo(user.UserID)
	if err != nil {
		return
	}

	// 过滤错误数据
	if uInfo.UserID == 0 ||
		uInfo.UserIsOnline != dbmodels.USER_IS_ONLINE_ONLINE ||
		uInfo.UserNickname == "" ||
		uInfo.UserIconurl == "" {
		return
	}

	// 获取当前kye值
	currentKey, _ := its.redisClient.Get(cacheNodeKey).Result()
	// 序列化数据
	bStr, _ := uInfo.MarshalBinary()
	// 插入到新注册用户队列
	_, _ = its.redisClient.LPush(currentKey+cacheNodeReg, bStr).Result()
}

// 获取在线数据
