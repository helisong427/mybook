/**
  created by yy on 23/04/2021
*/

package services

import (
	"fmt"
	"testing"
)

func TestSpeedMatchingMapNil(t *testing.T) {
	m := make(map[int64]int64)

	fmt.Println(m[15])
}
