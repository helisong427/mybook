package services

import (
	"encoding/json"
	"gamers/controller/response"
	"gamers/controller/services/recommend"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/go-redis/redis"
	"gorm.io/gorm"
)

type IndexParamsSkill struct {
	SkillId            int64         `json:"skill_id"`
	SkillType          int           `json:"skill_type"`           // 游戏类型(0游戏,1娱乐)
	SkillName          string        `json:"skill_name"`           // 游戏名称
	SkillIconurl       string        `json:"skill_iconurl"`        // 游戏icon
	SkillRequiredField string        `json:"skill_required_field"` // 必填字段id
	SkillLevelTips     string        `json:"skill_level_tips"`     // 等级提示
	SkillLevelUrl      string        `json:"skill_level_url"`      // 等级示例图片
	SkillSoundTips     string        `json:"skill_sound_tips"`     // 技能申请提示
	SkillAvatarTips    string        `json:"skill_avatar_tips"`    // 头像提示
	SkillFields        []string      `json:"skill_fields"`         // 游戏可选字段用,分割
	SkillParams        []SkillParams `json:"skill_params"`         // 参数详情
}

type SkillParams struct {
	SkillValueKey   string            `json:"skill_key"`
	SkillValueName  string            `json:"skill_name"`
	SkillValueValue []SkillValueValue `json:"skill_value_value"`
}

type SkillValueValue struct {
	ValueId int64  `json:"value_id"`
	Value   string `json:"value"`
}

type IndexParamsParty struct {
	AttrId   int    `json:"attr_id"`
	AttrName string `json:"attr_name"`
}

const (
	// 首页推荐类型
	INDEX_COMMENT_TYPE_PART int = iota // 派对
	INDEX_COMMENT_TYPE_LIVE
	INDEX_COMMENT_TYPE_SPARRING
	INDEX_COMMENT_TYPE_VIDEO
	INDEX_COMMENT_TYPE_IMAGE
)

// 首页参数
func IndexParams(userId int64) (r [4]response.IndexParamsRep, err error) {
	// 返回之前查询用户的常用游戏
	defer func() {
		info, err := new(redismodels.UserInfo).GetUserInfo(userId)
		if err != nil {
			return
		}
		if info.UserGameOrder != "" {
			gameOrder := strings.Split(info.UserGameOrder, "_")
			tmpGameOrder := make([]int, len(gameOrder))
			for k, v := range gameOrder {
				tmpInt, _ := strconv.Atoi(v)
				tmpGameOrder[k] = tmpInt
			}
			r[1].UserGameOrder = tmpGameOrder
		} else {
			r[1].UserGameOrder = []int{}
		}
	}()
	key := utils.REDIS_INDEX_PARAMS
	// 获取缓存
	cache, err := utils.RedisClient.Get(key).Result()
	if err != nil && err != redis.Nil {
		return
	}

	// 无缓存,设置缓存
	if err != nil && err == redis.Nil {
		r[0] = IndexRecommendParams()
		r[1], err = IndexGameParams()
		if err != nil {
			return
		}
		r[2], err = IndexPartyParams()
		if err != nil {
			return
		}
		r[3], err = IndexLiveParams()
		cacheByte, _ := json.Marshal(r)
		_, err := utils.RedisClient.Set(key, string(cacheByte), time.Hour).Result()
		if err != nil {
			return [4]response.IndexParamsRep{}, err
		}
	} else {
		// 有缓存,反序列化返回
		err := json.Unmarshal([]byte(cache), &r)
		if err != nil {
			return [4]response.IndexParamsRep{}, err
		}
	}
	return
}

// 首页推荐
func IndexRecommendParams() (r response.IndexParamsRep) {
	r.TagId = 0
	r.TagName = "推荐"
	return
}

// 首页游戏参数
func IndexGameParams() (r response.IndexParamsRep, err error) {
	r.TagId = 1
	r.TagName = "游戏"
	params := []IndexParamsSkill{}
	all, err := new(dbmodels.AppSkill).QueryAll()
	if err != nil {
		return
	}

	// //第一列默认推荐
	// defaultData := IndexParamsSkill{
	//	SkillId:   0,
	//	SkillName: "推荐",
	// }
	// params = append(params, defaultData)

	for _, v := range all {
		ps := IndexParamsSkill{
			SkillId:            v.SkillId,
			SkillType:          v.SkillType,
			SkillName:          v.SkillName,
			SkillIconurl:       v.SkillIconurl,
			SkillRequiredField: v.SkillRequiredField,
			SkillLevelTips:     v.SkillLevelTips,
			SkillLevelUrl:      v.SkillLevelUrl,
			SkillSoundTips:     v.SkillSoundTips,
			SkillAvatarTips:    v.SkillAvatarTips,
		}
		ps.SkillFields = strings.Split(v.SkillFields, ",")
		// 声明一个map用于去重
		skillParamsMap := make(map[string]SkillParams)
		for _, val := range v.AppSkillFieldValue {
			if m, ok := skillParamsMap[val.ValueField]; !ok {
				p := SkillParams{}
				p.SkillValueKey = val.ValueField
				p.SkillValueName = val.ValueFieldName
				p.SkillValueValue = append(p.SkillValueValue, SkillValueValue{
					ValueId: val.ValueId,
					Value:   val.ValueValue,
				})
				skillParamsMap[val.ValueField] = p
			} else {
				m.SkillValueValue = append(m.SkillValueValue, SkillValueValue{
					ValueId: val.ValueId,
					Value:   val.ValueValue,
				})
				skillParamsMap[val.ValueField] = m
			}
		}
		for _, v := range skillParamsMap {
			ps.SkillParams = append(ps.SkillParams, v)
		}

		params = append(params, ps)
	}
	r.TagParams = params
	return
}

// 派对参数
func IndexPartyParams() (r response.IndexParamsRep, err error) {
	r.TagId = 2
	r.TagName = "派对"
	attrData, err := new(dbmodels.AppLiveAttr).QueryByAttrType(dbmodels.LIVE_ATTR_TYPE_PARTY)
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	params := []IndexParamsParty{}
	startData := IndexParamsParty{
		AttrId:   -1,
		AttrName: "收藏",
	}
	defaultData := IndexParamsParty{
		AttrId:   0,
		AttrName: "推荐",
	}
	params = append(params, startData)
	params = append(params, defaultData)

	for _, v := range attrData {
		res := IndexParamsParty{
			AttrId:   int(v.AttrID),
			AttrName: v.AttrName,
		}
		params = append(params, res)
	}
	r.TagParams = params
	return
}

// 直播参数
func IndexLiveParams() (r response.IndexParamsRep, err error) {
	r.TagId = 3
	r.TagName = "FM"
	attrData, err := new(dbmodels.AppLiveAttr).QueryByAttrType(dbmodels.LIVE_ATTR_TYPE_LIVE)
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	params := []IndexParamsParty{}
	startData := IndexParamsParty{
		AttrId:   -1,
		AttrName: "收藏",
	}
	defaultData := IndexParamsParty{
		AttrId:   0,
		AttrName: "推荐",
	}
	params = append(params, startData)
	params = append(params, defaultData)

	for _, v := range attrData {
		res := IndexParamsParty{
			AttrId:   int(v.AttrID),
			AttrName: v.AttrName,
		}
		params = append(params, res)
	}
	r.TagParams = params
	return
}

// 首页
func Index(userId int64) (r response.IndexRep, err error) {
	var (
		timeExpire int64
		nowTime    int64
	)

	nowTime = time.Now().Unix()
	key := utils.REDIS_INDEX_INDEX
	redisClient := utils.RedisClient
	indexCache, err := redisClient.Get(key).Result()
	if err != nil && err != redis.Nil {
		return r, err
	}
	if indexCache == "" {
		// 查询banner
		adData, err := new(dbmodels.AppAd).QueryByPositionID(dbmodels.AD_POSITION_INDEX)
		if err != nil {
			return r, err
		}
		for _, v := range adData {
			r.AdList = append(r.AdList, response.AdList{
				AdId:       v.AdId,
				AdName:     v.AdName,
				AdContent:  v.AdContent,
				AdUrl:      v.AdUrl,
				AdJumpType: v.AdJumpType,
				AdURLParam: v.AdURLParam, // AdURL 广告链接参数
			})
		}

		// 查询游戏
		skillData, err := new(dbmodels.AppSkill).QuerySkillAll()
		if err != nil {
			return r, err
		}
		for _, v := range skillData {
			r.SkillList = append(r.SkillList, response.SkillList{
				SkillId:      v.SkillId,
				SkillName:    v.SkillName,
				SkillIconurl: v.SkillIconurl,
			})
		}

		// 缓存
		marshal, err := json.Marshal(r)
		if err != nil {
			return r, err
		}

		// 排序
		sortData := sortAd{data: adData}

		sort.Sort(&sortData)

		for _, v := range adData {
			if v.AdEndTime == 0 {
				continue
			}

			timeExpire = v.AdEndTime - nowTime
			break
		}

		if int64(time.Hour) < timeExpire || timeExpire == 0 {
			utils.LogInfoF("timeExpireTime is zero: %v", timeExpire)
			timeExpire = int64(time.Hour)
		}

		utils.LogInfoF("timeExpireTime: %v", timeExpire)

		err = redisClient.Set(key, marshal, time.Second*time.Duration(timeExpire)).Err()
		if err != nil {
			return r, err
		}
	} else {
		err = json.Unmarshal([]byte(indexCache), &r)
		if err != nil {
			return r, err
		}
	}
	sparringList, err := recommend.NewRecommendPosition().GetIndexSparring()
	if err != nil {
		return
	}
	r.SparringList = sparringList
	return
}

type sortAd struct {
	data []dbmodels.AppAdResutl
}

func (sort *sortAd) Len() int {
	return len(sort.data)
}

func (sort *sortAd) Less(i, j int) bool {
	return sort.data[i].AdEndTime < sort.data[j].AdEndTime
}

func (sort *sortAd) Swap(i, j int) {
	handleAdSwap(&sort.data[i], &sort.data[j])
}

func handleAdSwap(a *dbmodels.AppAdResutl, b *dbmodels.AppAdResutl) {
	*a, *b = *b, *a
}
