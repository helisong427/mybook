/**
 * @Author: panke
 * @Description: 房间pk service
 * @File: live_pk
 * @Date: 2021/4/16 11:11
 */

package services

import (
	"encoding/json"
	"errors"
	"fmt"
	"gamers/controller/request"
	"gamers/enum"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"gamers/utils/delay"
	"strconv"
	"time"

	"gorm.io/gorm"

	jsoniter "github.com/json-iterator/go"

	"github.com/go-redis/redis"
)

const (
	RoomPkRedPart  = 1
	RoomPkBluePart = 2
)

// 房间开启pk
func RoomPkStart(userId int64, room dbmodels.AppLiveRoom) (err error) {

	// 新增pk结果记录，记录开始时间 创建缓存  并且回填房间表pk场次id 打开爱意值
	// 推送消息给房间所有人

	tx := utils.GEngine.Begin()
	record := dbmodels.AppRoomPkRecord{
		RoomID:             room.RoomId,
		RoomPkRecordStart:  time.Now().Unix(),
		RoomPkRecordTime:   room.RoomPkRecordTime,
		RoomPkRecordPunish: room.RoomPkRecordPunish,
		RoomPkRecordStatus: enum.RoomPkRecordDoing,
	}
	record.RoomPkRecordExpectedEnd = record.RoomPkRecordStart + record.RoomPkRecordTime
	err = new(dbmodels.AppRoomPkRecord).Create(tx, &record)
	if err != nil {
		tx.Rollback()
		return errors.New("创建房间pk记录失败")
	}

	taskInfo := new(request.RoomPKTaskInfo)
	taskInfo.RoomPkRecordID = record.RoomPkRecordID
	taskInfo.Forbidden = false
	marshal, _ := json.Marshal(taskInfo)
	// 请求task
	req := delay.AddTaskReq{
		ExecuteTime: time.Now().Unix() + room.RoomPkRecordTime,
		TaskInfo:    string(marshal),
		TaskType:    delay.TASK_TYPE_DELAY,
		TaskTimeOut: 0,
		Topic:       "RoomPK",
	}
	resp, err := new(delay.SystemTaskLog).Add(req)
	if err != nil {
		utils.LogErrorF("请求房间pk延迟任务失败: %s", err.Error())
		tx.Rollback()
		return
	}

	err = new(dbmodels.AppLiveRoom).UpdateByTranslation(tx, room.RoomId, map[string]interface{}{
		"room_pk_record_id": record.RoomPkRecordID,
		"room_pk_state":     dbmodels.RoomPkStartStage,
	})
	if err != nil {
		tx.Rollback()
		return errors.New("更新房间pk场次失败")
	}

	err = new(dbmodels.AppRoomPkRecord).Updates(tx, record.RoomPkRecordID, map[string]interface{}{"room_pk_record_task_id": resp.LogId})
	if err != nil {
		tx.Rollback()
		return errors.New("更新pk记录失败")
	}

	// 操作redis
	pkDetail := redismodels.RoomPkDetail{RoomPKDetailExpectedEnd: time.Now().Unix() + room.RoomPkRecordTime}
	err = new(redismodels.RoomPkDetail).Update(room.RoomId, pkDetail)
	if err != nil {
		tx.Rollback()
		utils.LogErrorF("房间开启pk创建缓存失败:%s", err.Error())
		return
	}

	// 开启爱意值
	_, err = new(redismodels.Wheat).SwitchWheatLove(int(room.RoomId), userId, redismodels.WHEAT_LOVE_SWITCH_OPEN, true)
	if err != nil {
		tx.Rollback()
		utils.LogErrorF("pk房间开启爱意值失败: %s", err.Error())
		return
	}

	err = tx.Commit().Error
	if err != nil {
		utils.LogErrorF("pk房间开启失败: %s", err.Error())
		tx.Rollback()
		return errors.New("房间开启PK失败")
	}

	// 获取麦位消息
	data, err := new(redismodels.Wheat).QueryWheatDetail(int(room.RoomId))
	if err != nil {
		utils.LogErrorF(fmt.Sprintf("开始pk获取房间[%d]麦位信息失败", room.RoomId), err.Error())
	}
	// 获取直播间消息
	info := GetLiveInfo(room, dbmodels.RoomPkStartStage)
	info.RoomPKRemainingTime = record.RoomPkRecordTime
	// 推送-开启房间pk
	go new(LiveMsg).AnnouncePkStart(&data, &info)
	return
}

// 房间结算pk
func RoomSettlePk(userId int64, room dbmodels.AppLiveRoom) (err error) {

	var (
		redMaxId    int64 // 红方爱意值最大的用户id
		redMaxLove  int64 // 红方最大爱意值
		blueMaxId   int64 // 蓝方爱意值最大的用户id
		blueMaxLove int64 // 蓝方最大爱意值
		maxId       int64 // 魅力王id
		redMaxKey   int
		blueMaxKey  int
	)

	key := utils.REDIS_LIVE_WHEAT + strconv.Itoa(int(room.RoomId))
	allInfo, err := utils.RedisClient.HGetAll(key).Result()
	if err != nil && err != redis.Nil {
		return
	}

	data := redismodels.Wheat{}
	_ = json.Unmarshal([]byte(allInfo[redismodels.WHEAT_LIST]), &data.WheatObj)
	data.WheatLoveSwitch, _ = strconv.Atoi(allInfo[redismodels.WHEAT_LOVE_SWITCH])

	// 判断爱意值如果开启
	if data.WheatLoveSwitch == redismodels.WHEAT_LOVE_SWITCH_OPEN {
		data.GetLoveValue(room.RoomId)
	}

	data.WheatLen, _ = strconv.Atoi(allInfo[redismodels.WHEAT_LEN])
	data.WheatSwitch, _ = strconv.Atoi(allInfo[redismodels.WHEAT_SWITCH])

	// 获取pk 详情
	all, _ := utils.RedisClient.HGetAll(fmt.Sprintf("%s%d", utils.RedisRoomPkDetail, room.RoomId)).Result()
	red, _ := strconv.Atoi(all[redismodels.ROOM_PK_DETAIL_RED])
	blue, _ := strconv.Atoi(all[redismodels.ROOM_PK_DETAIL_BLUE])

	// 获取pk记录
	roomRecord, err := new(dbmodels.AppRoomPkRecord).Query(room.RoomPkRecordId)
	if err != nil {
		utils.LogErrorF(fmt.Sprintf("查询房间pk记录失败:%s", err.Error()))
		return err
	}
	// 根据红蓝两队pk值 判断结果
	var result int
	if red > blue {
		result = enum.RedWin
	} else if red < blue {
		result = enum.BlueWin
	} else if red == blue {
		result = enum.DrawResult
	}

	// 计算svp和mvp
	pkWheatInfo := make([]redismodels.WheatPkObj, 0)
	for _, j := range data.WheatObj {
		info := redismodels.WheatPkObj{
			Role:              j.Role,
			UserId:            j.UserId,
			UserNickName:      j.UserNickName,
			UserIconurl:       j.UserIconurl,
			UserGender:        j.UserGender,
			UserAvatarDressUp: j.UserAvatarDressUp,
			Status:            j.Status,
			LoveValue:         j.LoveValue,
			Position:          j.Position,
			UpdateTime:        j.UpdateTime,
			IsMvp:             0,
			IsSvp:             0,
			IsCharm:           0,
		}
		pkWheatInfo = append(pkWheatInfo, info)
	}
	for k, v := range pkWheatInfo {
		if v.Position > 0 && v.Position < 5 {
			if int64(v.LoveValue) > redMaxLove {
				redMaxId = int64(v.UserId)
				redMaxLove = int64(v.LoveValue)
				redMaxKey = k
				// 如果是红方胜利
			}
		}
		if v.Position > 4 && v.Position < 9 {
			if int64(v.LoveValue) > blueMaxLove {
				blueMaxId = int64(v.UserId)
				blueMaxLove = int64(v.LoveValue)
				// 如果是红方胜利
				blueMaxKey = k
			}
		}
	}
	// 判断svp,mvp
	if result == enum.RedWin {
		pkWheatInfo[redMaxKey].IsMvp = 1
		pkWheatInfo[blueMaxKey].IsSvp = 1

	} else if result == enum.BlueWin {
		pkWheatInfo[blueMaxKey].IsMvp = 1
		pkWheatInfo[redMaxKey].IsSvp = 1
	}
	// 判断魅力王
	if redMaxLove >= blueMaxLove {
		pkWheatInfo[redMaxKey].IsCharm = 1
		maxId = redMaxId
	} else {
		pkWheatInfo[redMaxKey].IsCharm = 1
		maxId = blueMaxId
	}

	roomIdStr := strconv.Itoa(int(room.RoomId))
	var starInfo redismodels.MsgUserObj
	maxScore := utils.RedisClient.ZPopMax(utils.RedisRoomPkGloryStar+roomIdStr, 1).Val()
	if len(maxScore) > 0 && maxScore[0].Score >= redismodels.MIN_GLORY_SCORE_VALUE {
		starIdStr := maxScore[0].Member.(string)
		starId, err := strconv.ParseInt(starIdStr, 10, 64)
		if err != nil {
			utils.LogErrorF("获取闪耀之星[%s]失败,err:%s", starIdStr, err.Error())
			return err
		}
		starInfo, err = new(redismodels.MsgUserObj).GetMsgUserInfo(starId, map[string]bool{})
		if err != nil {
			utils.LogErrorF("获取闪耀之星[%s]失败,err:%s", starIdStr, err.Error())
			return err
		}
	}

	detail := redismodels.WheatPk{
		WheatSwitch:        data.WheatSwitch,
		WheatLoveSwitch:    data.WheatLoveSwitch,
		WheatLen:           data.WheatLen,
		WheatObj:           pkWheatInfo,
		RoomPkRecordResult: result,
		RoomPkRecordRed:    int64(red),
		RoomPKRecordBlue:   int64(blue),
		RoomPKRecordPunish: room.RoomPkRecordPunish,
		RoomGloryStar:      starInfo,
	}
	detailMarshal, _ := json.Marshal(detail)

	// 开启事务更新
	tx := utils.GEngine.Begin()
	nowTime := time.Now().Unix()
	updates := make(map[string]interface{})
	updates["edited"] = nowTime
	updates["room_pk_record_end"] = nowTime
	updates["room_pk_record_settle"] = enum.ManualSettlement
	updates["room_pk_record_status"] = enum.RoomPkRecordEnd
	updates["room_pk_record_result"] = result
	updates["room_pk_record_red"] = red
	updates["room_pk_record_blue"] = blue
	updates["room_pk_record_charm_user_id"] = maxId
	updates["room_pk_record_detail"] = detailMarshal
	if result == enum.RedWin {
		updates["room_pk_record_mvp_user_id"] = redMaxId
		updates["room_pk_record_svp_user_id"] = blueMaxId
	}
	if result == enum.BlueWin {
		updates["room_pk_record_svp_user_id"] = redMaxId
		updates["room_pk_record_mvp_user_id"] = blueMaxId
	}

	err = new(dbmodels.AppRoomPkRecord).Updates(tx, roomRecord.RoomPkRecordID, updates)
	if err != nil {
		tx.Rollback()
		return
	}

	// 更新房间状态
	err = new(dbmodels.AppLiveRoom).UpdateAffairs(tx, room.RoomId, map[string]interface{}{"room_pk_state": fmt.Sprintf("%d", dbmodels.RoomPkReadyStage)})
	if err != nil {
		tx.Rollback()
		return
	}
	if err = tx.Commit().Error; err != nil {
		utils.LogErrorF("房间pk结束失败: %s", err.Error())
		tx.Rollback()
		return
	}

	// 关闭爱意值
	_, err = new(redismodels.Wheat).SwitchWheatLove(int(room.RoomId), userId, redismodels.WHEAT_LOVE_SWITCH_OFF, true)
	if err != nil {
		utils.LogErrorF("pk房间关闭爱意值失败: %s", err.Error())
	}
	// 删除房间荣耀之星
	err = utils.RedisClient.Del(fmt.Sprintf("%s%d", utils.RedisRoomPkGloryStar, room.RoomId)).Err()
	if err != nil {
		utils.LogErrorF("pk房间删除房间荣耀之星失败:%s", err.Error())
	}

	// 删除房间pk详情
	err = utils.RedisClient.Del(fmt.Sprintf("%s%d", utils.RedisRoomPkDetail, room.RoomId)).Err()
	if err != nil {
		utils.LogErrorF("pk房间删除房间详情失败: %s", err.Error())
	}

	// 获取直播间消息
	info := GetLiveInfo(room, dbmodels.RoomPkReadyStage)
	// 发送pk结束
	data.WheatLoveSwitch = redismodels.WHEAT_LOVE_SWITCH_OFF
	go new(LiveMsg).AnnouncePkFinished(&data, &info, false)
	return
}

// 添加pk时长
func AddPkTime(room dbmodels.AppLiveRoom, timeKey int) (err error) {

	record, err := new(dbmodels.AppRoomPkRecord).Query(room.RoomPkRecordId)
	if err != nil {
		utils.LogErrorF("查询pk房间记录错误:[%s]", err.Error())
		return
	}

	req := delay.AddTaskTimeReq{
		TaskId:   record.RoomPkRecordTaskID,
		Duration: int64(timeKey),
	}

	resp, err := new(delay.SystemTaskLog).AddTime(req)
	if err != nil {
		utils.LogErrorF("请求房间pk延迟任务失败:[%s]", err.Error())
		return
	}

	tx := utils.GEngine.Begin()
	err = new(dbmodels.AppRoomPkRecord).Updates(tx, room.RoomId, map[string]interface{}{"room_pk_record_expected_end": resp.LogTaskExecuteTime})
	if err != nil {
		utils.LogErrorF("更新pk房间记录预计结束时间错误:[%s]", err.Error())
		tx.Rollback()
		return
	}

	err = utils.RedisClient.HSet(fmt.Sprintf("%s%d", utils.RedisRoomPkDetail, room.RoomId), redismodels.ROOM_PK_DETAIL_EXPECTEDEND, resp.LogTaskExecuteTime).Err()
	if err != nil {
		utils.LogErrorF("缓存房间pk详情到[%d]失败, %s", room.RoomId, err.Error())
		tx.Rollback()
		return
	}
	if err = tx.Commit().Error; err != nil {
		utils.LogErrorF("添加房间pk时长失败:[%s]", err.Error())
		tx.Callback()
		return
	}
	// 发送延时消息
	new(LiveMsg).AnnounceExtendPkTime(room.RoomId, int64(timeKey))
	return
}

// 结束惩罚阶段
func EndPunishStage(room dbmodels.AppLiveRoom) (err error) {
	update := make(map[string]interface{})
	update["room_pk_state"] = dbmodels.RoomPkReadyStage
	update["room_pk_record_id"] = 0
	err = room.Update(int(room.RoomId), update)
	if err != nil {
		utils.LogErrorF("结束惩罚阶段失败:[%s]", err.Error())
		return
	}
	// 删除房间荣耀之星
	err = utils.RedisClient.Del(fmt.Sprintf("%s%d", utils.RedisRoomPkGloryStar, room.RoomId)).Err()
	if err != nil {
		utils.LogErrorF("pk房间删除房间荣耀之星失败:[%s]", err.Error())
		return
	}

	// 删除房间pk详情
	err = utils.RedisClient.Del(fmt.Sprintf("%s%d", utils.RedisRoomPkDetail, room.RoomId)).Err()
	if err != nil {
		utils.LogErrorF("pk房间删除房间详情失败:[%s]", err.Error())
		return
	}
	// 冻结爱意值
	_, err = new(redismodels.Wheat).SwitchWheatLove(int(room.RoomId), 1, redismodels.WHEAT_LOVE_SWITCH_OFF, false)
	if err != nil {
		utils.LogErrorF("pk房间冻结爱意值失败:[%s]", err.Error())
	}
	detail, err := new(redismodels.Wheat).QueryWheatDetail(int(room.RoomId))
	if err != nil {
		utils.LogErrorF("获取麦位信息失败:[%s]", err.Error())
	}
	info := GetLiveInfo(room, dbmodels.RoomPkReadyStage)
	go new(LiveMsg).AnnouncePkPunishFinished(&detail, &info)
	return
}

func GetLiveInfo(room dbmodels.AppLiveRoom, pkStage int) (info redismodels.LiveInfo) {
	var roomIsPassword int
	if room.RoomPassword != "" {
		roomIsPassword = 1
	}
	return redismodels.LiveInfo{
		RoomId:             room.RoomId,
		RoomPrettyId:       room.RoomPrettyId,
		RoomType:           room.RoomType,
		RoomName:           room.RoomName,
		RoomCover:          room.RoomCover,
		RoomBackground:     room.RoomBackground,
		RoomTitle:          room.RoomTitle,
		RoomContent:        room.RoomContent,
		RoomUnionId:        room.RoomUnionId,
		RoomUserId:         room.RoomUserId,
		RoomAttrId:         room.RoomAttrId,
		RoomAttrName:       room.RoomLiveAttr.AttrName,
		RoomSpeakType:      room.RoomSpeakType,
		RoomOpenIm:         room.RoomOpenIm,
		RoomLiveStatus:     room.RoomLiveStatus,
		RoomLastOnline:     room.RoomLastOnline,
		RoomPassword:       room.RoomPassword,
		RoomIsPassword:     roomIsPassword,
		RoomEggbreakMsg:    room.RoomEggbreakMsg,
		RoomPkRecordTime:   room.RoomPkRecordTime,
		RoomPkRecordPunish: room.RoomPkRecordPunish,
		RoomPkState:        int64(pkStage),
		RoomPkSwitch:       room.RoomPkSwitch,
	}
}

func GetPkInfo(req request.RoomPkDetail, userId int64) (data redismodels.WheatPk, err error) {
	record, err := new(dbmodels.AppRoomPkRecord).Query(req.RoomPkRecordID)
	if err != nil {
		if err != gorm.ErrRecordNotFound {
			utils.LogErrorF("获取pk记录[%d]失败,err:[%s]", req.RoomPkRecordID, err.Error())
			err = errors.New("查询pk记录失败")
			return
		}
		err = errors.New("记录不存在")
		return
	}
	// 序列化成结构体返回
	err = jsoniter.UnmarshalFromString(record.RoomPkRecordDetail, &data)
	if err != nil {
		utils.LogErrorF("序列化pk记录[%d]失败,err:%s", req.RoomPkRecordID, err.Error())
		err = errors.New("获取pk信息失败")
		return
	}
	var validate bool
	for _, v := range data.WheatObj {
		if int64(v.UserId) == userId {
			validate = true
			break
		}
	}
	if !validate {
		err = errors.New("无权访问")
		return
	}
	return
}
