package services

import (
	"encoding/json"
	"fmt"
	"gamers/controller/response"
	"gamers/models/dbmodels"
	"gamers/utils"
	"sync"
	"time"

	"github.com/go-redis/redis"
	"gorm.io/gorm"
)

//首页用户推荐记录
type IndexCommentUserRecord struct {
	Part       []int `json:"part"`        //派对记录
	Live       []int `json:"live"`        //直播记录
	Sparring   []int `json:"sparring"`    //大神记录
	TweetImage []int `json:"tweet_image"` //朋友圈图片记录
	TweetVideo []int `json:"tweet_video"` //朋友圈视频记录
}

//首页推荐
func IndexComment(userId int64) (r []interface{}, err error) {
	record := IndexCommentUserRecord{}
	//获取用户推荐记录
	key := fmt.Sprintf("%s%d", utils.REDIS_INDEX_RECOMMEND_USER_RECORD, userId)
	redisClient := utils.RedisClient
	result, err := redisClient.Get(key).Result()
	if err != nil && err != redis.Nil {
		return
	}
	if result != "" {
		err = json.Unmarshal([]byte(result), &record)
		if err != nil {
			return
		}
	}
	lock := sync.Mutex{}
	wg := sync.WaitGroup{}
	done := make(chan int)
	errChan := make(chan error)

	wg.Add(4)
	//派对房
	go func() {
		defer wg.Done()
		part, err := record.IndexCommentPart()
		if err != nil && err != gorm.ErrRecordNotFound {
			errChan <- err
			return
		}
		lock.Lock()
		defer lock.Unlock()
		if part.Type != 0 {
			r = append(r, part)
		}
	}()

	//直播房
	go func() {
		defer wg.Done()
		live, err := record.IndexCommentLive()
		if err != nil && err != gorm.ErrRecordNotFound {
			errChan <- err
			return
		}
		lock.Lock()
		defer lock.Unlock()
		if live.Type != 0 {
			r = append(r, live)
		}
	}()

	//大神
	go func() {
		defer wg.Done()
		sparring, err := record.IndexCommentSparring()
		if err != nil && err != gorm.ErrRecordNotFound {
			errChan <- err
			return
		}
		lock.Lock()
		defer lock.Unlock()
		if sparring.Type != 0 {
			r = append(r, sparring)
		}
	}()

	//视频图片动态
	go func() {
		defer wg.Done()
		tweet, err := record.IndexCommentTweet(userId)
		if err != nil && err != gorm.ErrRecordNotFound {
			errChan <- err
			return
		}
		lock.Lock()
		defer lock.Unlock()
		//图片动态
		for _, v := range tweet {
			if v.Type != 0 {
				r = append(r, v)
			}

		}
	}()

	go func() {
		wg.Wait()
		close(done)
	}()

	select {
	case err = <-errChan: //读取到错误直接返回
		return
	case <-done:
	case <-time.After(time.Second * 2): //最多等待2秒
	}

	//打乱顺序
	utils.FuncShuffle(r)

	//保存用户记录访问记录
	marshal, err := json.Marshal(&record)
	if err != nil {
		return
	}
	err = redisClient.Set(key, marshal, time.Minute*10).Err()
	if err != nil {
		return
	}
	return
}

//首页派对房
func (record *IndexCommentUserRecord) IndexCommentPart() (model response.IndexRecommendModel, err error) {
	r := response.IndexRecommendPart{}
	where := fmt.Sprintf("WHERE room_type = %d  AND room_password = '' AND room_union_id > 0", dbmodels.ROOM_TYPE_PARTY)
	and := fmt.Sprintf("AND room_type = %d  AND room_password = '' AND room_union_id > 0", dbmodels.ROOM_TYPE_PARTY)
	randData := dbmodels.AppLiveRoom{}
	err = dbmodels.QueryRandIndex("room_id", randData.TableName(), 1, record.Part, where, and, "", &randData)
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	//没有随机到不附加NOT IN条件再次查询
	if randData.RoomId == int64(0) {
		//未查询到清空纪录
		record.Part = record.Part[:0]
		err = dbmodels.QueryRandIndex("room_id", randData.TableName(), 1, nil, where, and, "", &randData)
		if err != nil && err != gorm.ErrRecordNotFound {
			return
		}
	}

	data, err := new(dbmodels.AppLiveRoom).QueryByRoomId(int(randData.RoomId))
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	if err == nil {
		r.RoomId = data.RoomId
		r.RoomType = data.RoomType
		r.RoomName = data.RoomName
		r.RoomCover = data.RoomCover
		r.RoomAttrId = data.RoomAttrId
		r.RoomAttrName = data.RoomLiveAttr.AttrName
		r.RoomSpeakType = data.RoomSpeakType
		r.RoomLiveStatus = data.RoomLiveStatus
		r.UserIconurl = data.SystemUser.UserIconurl
		r.UserNickname = data.SystemUser.UserNickname
		r.RoomPkState = data.RoomPkState
		r.Hot = int(data.RoomHeat)
		//处理热度为负数
		if r.Hot < 0 {
			r.Hot = 0
		}
		////查询麦位
		//wheatData, _ := new(redismodels.Wheat).QueryWheatDetail(int(data.RoomId))
		//for _, v := range wheatData.WheatObj {
		//	if v.UserIconurl != "" {
		//		r.WheatList = append(r.WheatList, v.UserIconurl)
		//	}
		//}

		model.Type = INDEX_COMMENT_TYPE_PART
		model.PartModel = r

		//储存本次记录
		record.Part = append(record.Part, int(randData.RoomId))
	}
	return
}

//首页直播房
func (record *IndexCommentUserRecord) IndexCommentLive() (model response.IndexRecommendModel, err error) {
	r := response.IndexRecommendLive{}
	where := fmt.Sprintf("WHERE room_type = %d  AND room_status = %d AND room_live_status = %d AND room_password = ''", dbmodels.ROOM_TYPE_LIVE, dbmodels.ROOM_STATUS_OK, dbmodels.ROOM_LIVE_STATUS_ON)
	randData := dbmodels.AppLiveRoom{}
	and := fmt.Sprintf("AND room_type = %d  AND room_status = %d AND room_live_status = %d AND room_password = ''", dbmodels.ROOM_TYPE_LIVE, dbmodels.ROOM_STATUS_OK, dbmodels.ROOM_LIVE_STATUS_ON)
	err = dbmodels.QueryRandIndex("room_id", randData.TableName(), 1, record.Live, where, and, "", &randData)
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	//没有随机到不附加NOT IN条件再次查询
	if randData.RoomId == int64(0) {
		record.Live = record.Live[:0]
		err = dbmodels.QueryRandIndex("room_id", randData.TableName(), 1, nil, where, and, "", &randData)
		if err != nil && err != gorm.ErrRecordNotFound {
			return
		}
	}

	data, err := new(dbmodels.AppLiveRoom).QueryByRoomId(int(randData.RoomId))
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	if err == nil {
		r.RoomId = data.RoomId
		r.RoomType = data.RoomType
		r.RoomName = data.RoomName
		r.RoomCover = data.RoomCover
		r.RoomAttrId = data.RoomAttrId
		r.RoomAttrName = data.RoomLiveAttr.AttrName
		r.RoomSpeakType = data.RoomSpeakType
		r.RoomLiveStatus = data.RoomLiveStatus
		r.UserIconurl = data.SystemUser.UserIconurl
		r.UserNickname = data.SystemUser.UserNickname
		r.Hot = int(data.RoomHeat)
		//处理热度为负数
		if r.Hot < 0 {
			r.Hot = 0
		}
		model.Type = INDEX_COMMENT_TYPE_LIVE
		model.LiveModel = r

		//储存本次记录
		record.Live = append(record.Live, int(randData.RoomId))
	}
	return
}

//大神
func (record *IndexCommentUserRecord) IndexCommentSparring() (model response.IndexRecommendModel, err error) {
	r := response.IndexRecommendSparring{}
	where := fmt.Sprintf("WHERE skill_status = %d", dbmodels.SPARRING_SKILL_STATUS_OK)
	randData := dbmodels.AppSparringSkill{}
	err = dbmodels.QueryRandIndex("skill_id", randData.TableName(), 1, record.Sparring, where, "", "", &randData)
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	//没有随机到不附加NOT IN条件再次查询
	if randData.SkillID == int64(0) {
		record.Sparring = record.Sparring[:0]
		err = dbmodels.QueryRandIndex("skill_id", randData.TableName(), 1, nil, where, "", "", &randData)
		if err != nil && err != gorm.ErrRecordNotFound {
			return
		}
	}

	data, err := new(dbmodels.AppSparringSkill).QueryBySkillId(randData.SkillID)
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}

	r.SparringId = data.SkillID
	r.SkillName = data.AppSkill.SkillName
	r.SkillType = data.AppSkill.SkillType
	r.SkillIconurl = data.AppSkill.SkillIconurl
	r.UserId = data.SystemUser.UserID
	r.UserNickname = data.SystemUser.UserNickname
	r.UserIconurl = data.SystemUser.UserIconurl
	r.SkillInfo = data.SkillInfo
	r.PriceWay, r.PricePrice = skillMinPrice(data)

	model.Type = INDEX_COMMENT_TYPE_SPARRING
	model.SparringModel = r

	//储存本次记录
	record.Sparring = append(record.Sparring, int(randData.SkillID))
	return
}

//朋友圈
func (record *IndexCommentUserRecord) IndexCommentTweet(userId int64) (model []response.IndexRecommendModel, err error) {
	r := []response.IndexRecommendTweet{}
	imageWhere := fmt.Sprintf("WHERE tweet_status = %d AND tweet_visible = %d AND tweet_type = %d AND tweet_user_id NOT IN ( SELECT `blacklist_black_user_id` FROM `app_blacklist` WHERE blacklist_user_id = %d ) ", dbmodels.TWEET_STATUS_OK, dbmodels.TWEET_VISIBLE_UNLIMITED, dbmodels.TWEET_TYPE_IMAGE, userId)
	imageAnd := fmt.Sprintf("AND tweet_type = %d AND tweet_visible = %d AND `t1`.`tweet_user_id` NOT IN ( SELECT `blacklist_black_user_id` FROM `app_blacklist` WHERE blacklist_user_id = %d ) ", dbmodels.TWEET_TYPE_IMAGE, dbmodels.TWEET_VISIBLE_UNLIMITED, userId)
	randImageData := []dbmodels.AppTweet{}
	err = dbmodels.QueryRandIndex("tweet_id", new(dbmodels.AppTweet).TableName(), 3, record.TweetImage, imageWhere, imageAnd, "", &randImageData)
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	//没有随机到不附加NOT IN条件再次查询
	if len(randImageData) == 0 {
		record.TweetImage = record.TweetImage[:0]
		err = dbmodels.QueryRandIndex("tweet_id", new(dbmodels.AppTweet).TableName(), 3, nil, imageWhere, imageAnd, "", &randImageData)
		if err != nil && err != gorm.ErrRecordNotFound {
			return
		}
	}

	videoWhere := fmt.Sprintf("WHERE tweet_status = %d AND tweet_visible = %d AND tweet_type = %d AND tweet_user_id NOT IN ( SELECT `blacklist_black_user_id` FROM `app_blacklist` WHERE blacklist_user_id = %d ) ", dbmodels.TWEET_STATUS_OK, dbmodels.TWEET_VISIBLE_UNLIMITED, dbmodels.TWEET_TYPE_VIDEO, userId)
	videoAnd := fmt.Sprintf("AND tweet_type = %d AND tweet_visible = %d AND `t1`.`tweet_user_id` NOT IN ( SELECT `blacklist_black_user_id` FROM `app_blacklist` WHERE blacklist_user_id = %d ) ", dbmodels.TWEET_TYPE_VIDEO, dbmodels.TWEET_VISIBLE_UNLIMITED, userId)
	randVideoData := []dbmodels.AppTweet{}
	err = dbmodels.QueryRandIndex("tweet_id", new(dbmodels.AppTweet).TableName(), 2, record.TweetVideo, videoWhere, videoAnd, "", &randVideoData)
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	//没有随机到不附加NOT IN条件再次查询
	if len(randVideoData) == 0 {
		record.TweetVideo = record.TweetVideo[:0]
		err = dbmodels.QueryRandIndex("tweet_id", new(dbmodels.AppTweet).TableName(), 2, nil, videoWhere, videoAnd, "", &randVideoData)
		if err != nil && err != gorm.ErrRecordNotFound {
			return
		}
	}

	ids := []int{}
	for _, v := range randImageData {
		ids = append(ids, int(v.TweetID))
		record.TweetImage = append(record.TweetImage, int(v.TweetID))
	}
	for _, v := range randVideoData {
		ids = append(ids, int(v.TweetID))
		record.TweetVideo = append(record.TweetVideo, int(v.TweetID))
	}

	data, err := new(dbmodels.AppTweet).QueryIn(ids, userId)
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	for _, v := range data {
		res := response.IndexRecommendTweet{
			TweetId:        v.TweetID,
			TweetType:      v.TweetType,
			TweetContent:   v.TweetContent,
			TweetLikeCount: v.TweetLikeCount,
			UserInfo: response.TweetUserInfo{
				UserId:       v.UserID,
				UserNickname: v.UserNickname,
				UserIconurl:  v.UserIconurl,
			},
		}
		if res.IsLike > 0 {
			res.IsLike = 1
		}
		attachments := []response.TweetAttachments{}
		err = json.Unmarshal([]byte(v.TweetAttachment), &attachments)
		if err != nil {
			return
		}
		res.TweetAttachment = attachments
		r = append(r, res)
	}

	for _, v := range r {
		_type := INDEX_COMMENT_TYPE_IMAGE
		if v.TweetType == dbmodels.TWEET_TYPE_IMAGE {
			_type = INDEX_COMMENT_TYPE_IMAGE
		}
		if v.TweetType == dbmodels.TWEET_TYPE_VIDEO {
			_type = INDEX_COMMENT_TYPE_VIDEO
		}
		model = append(model, response.IndexRecommendModel{
			Type:       _type,
			TweetModel: v,
		})
	}
	return
}
