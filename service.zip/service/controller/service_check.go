package controller

import (
	"github.com/gin-gonic/gin"

	"gamers/controller/response"
)

func ServiceCheck(c *gin.Context) {
	response.ResponseOk(c, "ok", "ok")
	return
}
