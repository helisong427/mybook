/**
 * @Author: panke
 * @Description:
 * @File: turntable
 * @Date: 2021/4/22 14:05
 */

package controller

import (
	"fmt"
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"gamers/utils/prop"
	"sort"
	"time"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// 返回大转盘 key
func TurnTableReturnKey(c *gin.Context) {
	userId := utils.FuncUserId(c)
	now := time.Now().Unix()
	key := fmt.Sprintf("%s%d%d", utils.Config.App.AppKey, userId, now)

	keyMd5 := utils.FuncMD5(utils.FuncMD5(key))

	mapParam := map[string]interface{}{
		"time":    now,
		"userkey": keyMd5,
		"userid":  userId,
	}
	// 任务触发
	_ = new(redismodels.Task).Init().ReportConditionTag(userId, "logInDaily", 1)
	response.ResponseOk(c, "获取key成功", mapParam)
}

// 获取转盘配置
func TurnTableConfig(c *gin.Context) {
	var resp response.TurnTableConfigResp

	// 初始化
	resp.AppTurnTableLog = make([]*response.TurnTableLogResp, 0)
	resp.TurnTableConfigListResp = make([]*response.TurnTableConfigListResp, 0)

	configList := make([]*response.TurnTableConfigListResp, 0)
	logList := make([]*response.TurnTableLogResp, 0)

	// 转盘配置
	data, err := new(dbmodels.AppTurnTable).QueryAll()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	for _, v := range data {
		if v.TurnTableStatus != dbmodels.DB_TURNTABLE_STATUS_OPEN {
			continue
		}

		var item = &response.TurnTableConfigListResp{
			TurnTableID:            v.TurnTableID,
			TurnTableTitle:         v.TurnTableTitle,
			TurnTableDesc:          v.TurnTableDesc,
			TurnTableCostPropType:  v.TurnTableCostPropType,
			TurnTableCostPropID:    v.TurnTableCostPropID,
			TurnTableCostPropCount: v.TurnTableCostPropCount,
			TurnTableStatus:        v.TurnTableStatus,
			TurnTableBg:            v.TurnTableBg,
			TurnTableType:          v.TurnTableType,
		}

		for _, r := range v.AppTurnTableRewardRate {
			item.TurnTableRewardRate = append(item.TurnTableRewardRate, &response.TurnTableRewardRate{
				PropType:     r.AppProp.PropType,
				PropId:       r.AppProp.PropId,
				PropName:     r.AppProp.PropName,
				PropPrice:    r.AppProp.PropPrice,
				PropOrgPrice: r.AppProp.PropPrice,
				PropIcon:     r.AppProp.PropIcon,
				RatePosition: r.RatePosition,
				Rate:         fmt.Sprintf("%.2f%%", float64(r.RateRate)/100),
				RateValue:    r.RateRate,
			})
		}
		sort.Slice(item.TurnTableRewardRate, func(i, j int) bool {
			return item.TurnTableRewardRate[i].RatePosition < item.TurnTableRewardRate[j].RatePosition
		})
		configList = append(configList, item)

		data, err := new(dbmodels.AppTurnTableLog).Query50Limit(v.TurnTableID, 50, 0)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询转盘记录错误", "", err.Error())
			return
		}
		for _, v := range data {
			logResp := &response.TurnTableLogResp{
				LogID:             v.LogID,
				LogRecordID:       v.LogRecordID,
				LogUserID:         v.LogUserID,
				LogUserName:       v.SystemUser.UserNickname,
				LogTurnTableID:    v.LogTurnTableID,
				LogTurnTableCount: v.LogTurnTableCount,
				LogPropType:       v.LogPropType,
				LogPropID:         v.LogPropID,
				LogPropName:       v.AppProp.PropName,
				LogPropCount:      v.LogPropCount,
			}
			logList = append(logList, logResp)
		}
	}
	resp.TurnTableConfigListResp = configList
	resp.AppTurnTableLog = logList
	response.ResponseOk(c, "获取成功", resp)
}

// 转盘抽奖
func Turn(c *gin.Context) {
	userId := utils.FuncUserId(c)

	var req = request.TurnTableReq{}
	if err := c.ShouldBindJSON(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	_, cfg, err := new(dbmodels.AppTurnTable).QueryFirst(req.TurnTableId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "获取配置数据失败", "", err.Error())
		return
	}

	// 判断活动已结束
	now := time.Now().Unix()
	if now < int64(cfg.TurnTableStartTime) || now > int64(cfg.TurnTableEndTime) {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "活动已结束", "", "")
		return
	}

	if cfg.TurnTableID != req.TurnTableId || cfg.TurnTableStatus != dbmodels.DB_TURNTABLE_STATUS_OPEN {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "未开启活动", "", "")
		return
	}

	resp, msg, err := services.Turn(userId, &req)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, msg, err.Error())
		return
	}
	response.ResponseOk(c, "转盘抽奖成功", resp)
}

// 转盘抽奖记录
func TurnTableRecords(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var req = request.TurnTableRecordsReq{}
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	if _, err := new(dbmodels.SystemUser).QueryById(userId); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "不存在此用户", "", err.Error())
		return
	}

	_, cfg, err := new(dbmodels.AppTurnTable).QueryFirst(req.TurnTableId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "获取配置数据失败", "", err.Error())
		return
	}

	if cfg.TurnTableID != req.TurnTableId || cfg.TurnTableStatus != dbmodels.DB_TURNTABLE_STATUS_OPEN {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "未开启活动", "", "")
		return
	}

	page, size, skip, err := utils.GetPageAndSize(c)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "分页参数错误", "", err.Error())
		return
	}

	total, result, err := new(dbmodels.AppTurnTableLog).QueryByUserId(userId, req.TurnTableId, size, skip)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	AppTurnTableLog := make([]*response.TurnTableLogResp, 0)
	for _, v := range result {
		logResp := &response.TurnTableLogResp{
			LogID:             v.LogID,
			LogRecordID:       v.LogRecordID,
			LogUserID:         v.LogUserID,
			LogUserName:       v.SystemUser.UserNickname,
			LogTurnTableID:    v.LogTurnTableID,
			LogTurnTableCount: v.LogTurnTableCount,
			LogPropType:       v.LogPropType,
			LogPropID:         v.LogPropID,
			LogPropName:       v.AppProp.PropName,
			LogPropCount:      v.LogPropCount,
			Created:           v.Created,
		}
		AppTurnTableLog = append(AppTurnTableLog, logResp)
	}
	data := response.BasePageList{
		Page:       page,
		Size:       size,
		Total:      int64(skip) + total,
		TotalPages: utils.FuncTotalPages(int64(skip)+total, size),
		List:       AppTurnTableLog,
	}
	if result == nil {
		data.List = []string{}
	}
	response.ResponseOk(c, "ok", data)
}

// 保存地址
func SaveAddress(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var req = request.TurnTableAddress{}
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	if _, err := new(dbmodels.SystemUser).QueryById(userId); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "不存在此用户", "", err.Error())
		return
	}

	err := new(dbmodels.AppTurnTableAddress).SaveOrUpdate(userId, req)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "保存地址失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "保存地址成功", "")
}

// 获取地址
func GetAddress(c *gin.Context) {
	userId := utils.FuncUserId(c)

	if _, err := new(dbmodels.SystemUser).QueryById(userId); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "不存在此用户", "", err.Error())
		return
	}

	data, err := new(dbmodels.AppTurnTableAddress).Get(userId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询地址失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "查询地址成功", data)
}

// 获取大转盘任务中心
func TaskGetListTurnTable(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var data, err = services.TaskGetListTurnTable(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取任务数据失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取任务数据成功", &data)
}

// 大转盘-领取奖励
func TurnTableTaskGetReward(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var req request.TurnTableTaskGetReward
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	var data, msg, err = services.TaskGetReward(userId, req.SetID, req.TaskID)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}
	response.ResponseOk(c, "领取成功", data)
}

// 大转盘-获取背包
// 获取背包列表
func TurnTableGetBackpackList(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var req = request.TurnTableBackpackListReq{}
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	if _, err := new(dbmodels.SystemUser).QueryById(userId); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "不存在此用户", "", err.Error())
		return
	}

	var data, err = (&dbmodels.AppBackpack{}).Query(userId, prop.Type(req.BackpackPropType))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取失败", "", err.Error())
		return
	}

	// 保证金银顺序
	sort.Slice(data, func(i, j int) bool {
		return data[i].BackpackPropId < data[j].BackpackPropId
	})
	response.ResponseOk(c, "获取成功", &data)
}
