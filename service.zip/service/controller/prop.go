package controller

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/models/dbmodels"
	"gamers/utils"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// 获取物品配置
func GetPropList(c *gin.Context) {
	var req = request.GetPropListByTypeAndAttrIdReq{}
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	var lists, err = new(dbmodels.AppProp).QueryByTypeAndAttrId(req.PropType, req.AttrId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取道具列表失败", "", err.Error())
		return
	}

	response.ResponseOk(c, "ok", lists)
}

// 获取礼物tab
func GetPropAttrs(c *gin.Context) {
	var form request.GetPropAttrByTypeReq
	err := c.ShouldBind(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	attrs, err := new(dbmodels.AppPropAttr).QueryByAttrType(*form.AttrType)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取道具attr列表失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "ok", attrs)
	return
}

//获取礼物列表
func GetGiftLists(c *gin.Context) {
	var form request.GetGiftByTypeReq
	err := c.ShouldBind(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	gifts, err := new(dbmodels.AppProp).GetAllGifts(form.AttrId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取礼物列表失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "ok", gifts)
	return
}

// 获取用户余额
func GetUserOver(c *gin.Context) {
	userId := utils.FuncUserId(c)
	data, err := new(dbmodels.AppUserWallet).GetUserOver(userId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if err == gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "未找到该用户", "", "")
		return
	}
	response.ResponseOk(c, "ok", data)
	return
}
