package controller

import (
	"gamers/controller/response"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"github.com/gin-gonic/gin"
)

func VipIndex(c *gin.Context) {
	data, err := new(dbmodels.AppUserVipPrivilege).QueryVipPrivilege()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "获取特权列表失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "请求成功", data)
	return
}

func GetVipUserInfo(c *gin.Context) {
	userId := utils.FuncUserId(c)
	data, err := new(dbmodels.AppUserVipExperience).GetUserVipLevelByUserId(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "获取用户特权信息失败", "", err.Error())
		return
	}
	userInfo, err := new(redismodels.UserInfo).GetUserInfo(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "获取用户信息失败", "", err.Error())
		return
	}
	rep := response.GetUserVipInfo{
		UserId:              userId,
		Icon:                userInfo.UserIconurl,
		Nickname:            userInfo.UserNickname,
		ExperienceNextValue: data.ExperienceNextValue,
		ExperienceValue:     data.ExperienceValue,
		VipLevel:            data.ExperienceLevel,
	}
	response.ResponseOk(c, "请求成功", rep)
	return
}
