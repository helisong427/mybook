package controller

import (
	"github.com/gin-gonic/gin"

	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/utils"
)

// 用户送礼排行（财富榜）
func GetRankUserSendWealth(c *gin.Context) {
	userId := utils.FuncUserId(c)

	var req = request.RankUserSendWealth{}
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	resp, msg, err := services.GetRankUserSendWealth(userId, &req)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}
	if len(resp.List) >= response.MAX_RANK_LIST_LENGTH {
		resp.List = resp.List[0:10]
	}
	response.ResponseOk(c, "获取成功", resp)
}

// 用户收礼排行（魅力榜）
func GetRankUserRecvCharm(c *gin.Context) {
	userId := utils.FuncUserId(c)

	var req = request.RankUserRecvCharm{}
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	resp, msg, err := services.GetRankUserRecvCharm(userId, &req)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}
	if len(resp.List) >= response.MAX_RANK_LIST_LENGTH {
		resp.List = resp.List[0:10]
	}
	response.ResponseOk(c, "获取成功", resp)
}

// 房间送礼排行（魅力榜）
func GetRankRoomSendCharm(c *gin.Context) {
	userId := utils.FuncUserId(c)

	var req = request.RankRoomSendCharm{}
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	if req.RoomId <= 0 {
		req.RoomId = 0
		// 尝试获得user的房间Id
		if userId > 0 {
			//if roomInfo, err := new(dbmodels.AppLiveRoom).GetRoomInfoByUserId(userId); err == nil {
			//	req.RoomId = roomInfo.RoomId
			//}
		}
	}

	resp, msg, err := services.GetRankRoomSendCharm(&req)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}
	if len(resp.List) >= response.MAX_RANK_LIST_LENGTH {
		resp.List = resp.List[0:10]
	}
	response.ResponseOk(c, "获取成功", resp)
}

// 房间送礼排行变更轮询（魅力榜）
func GetRankRoomSendCharmRollPolling(c *gin.Context) {
	var req = request.RankRoomSendCharmRollPolling{}
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	resp, msg, err := services.GetRankRoomSendCharmRollPolling(&req)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}
	response.ResponseOk(c, "获取成功", resp)
}

// 房间内用户送礼排行（财富榜）
func GetRankRoomUserSendWealth(c *gin.Context) {
	userId := utils.FuncUserId(c)

	var req = request.RankRoomUserSendWealth{}
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	resp, msg, err := services.GetRankRoomUserSendWealth(userId, &req)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}
	if len(resp.List) >= response.MAX_RANK_LIST_LENGTH {
		resp.List = resp.List[0:10]
	}
	response.ResponseOk(c, "获取成功", resp)
}

// 房间内用户收礼排行（魅力榜）
func GetRankRoomUserRecvCharm(c *gin.Context) {
	userId := utils.FuncUserId(c)

	var req = request.RankRoomUserRecvCharm{}
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	resp, msg, err := services.GetRankRoomUserRecvCharm(userId, &req)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}
	if len(resp.List) >= response.MAX_RANK_LIST_LENGTH {
		resp.List = resp.List[0:10]
	}
	response.ResponseOk(c, "获取成功", resp)
}
