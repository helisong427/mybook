package controller

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/models/dbmodels"
	"github.com/gin-gonic/gin"
)

// 周星榜 排行获取
func WeekStarRankList(c *gin.Context) {
	var (
		err  error
		msg  string
		req  request.WeekStarRankListSearch
		data *response.BasePageList
	)

	if err = c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	if data, msg, err = services.GetRankList(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}

	response.ResponseOk(c, msg, data)
}

// 获取周星榜 数据
func GetWeekStarInfo(c *gin.Context) {
	var (
		err  error
		msg  string
		data *dbmodels.AppWeekStarResultItem
	)

	if data, msg, err = services.GetWeekStarInfo(); err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}

	response.ResponseOk(c, msg, data)
}

// 获取 周星榜 历史纪录
func GetWeekStarHistory(c *gin.Context) {
	var (
		err  error
		msg  string
		data *response.BasePageList
	)

	if data, msg, err = services.GetWeekStarHistory(); err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}

	response.ResponseOk(c, msg, data)
}
