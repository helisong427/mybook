package controller

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"strconv"

	"github.com/gin-gonic/gin"
	"github.com/go-redis/redis"
)

// 退出房间
func QuitLive(c *gin.Context) {
	var form request.QuitLive
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	userId := utils.FuncUserId(c)
	userInfo, err := new(redismodels.MsgUserObj).GetMsgUserInfo(userId, map[string]bool{"comeIn": false})
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户信息失败", "", err.Error())
		return
	}
	liveRoom, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(form.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取房间信息失败", "", err.Error())
		return
	}
	err = services.QuitLiveRoom(&liveRoom, &userInfo)
	if err != nil && err != redis.Nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "处理退出房间逻辑失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "ok", "ok")
	return
}

// 进入房间
func JoinLive(c *gin.Context) {
	var form request.QuitLive
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	userId := utils.FuncUserId(c)
	userInfo, err := new(redismodels.MsgUserObj).GetMsgUserInfo(userId, map[string]bool{"comeIn": true})
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户信息失败", "", err.Error())
		return
	}
	liveRoom, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(form.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取房间信息失败", "", err.Error())
		return
	}
	role, err := new(dbmodels.AppRoomAdmin).GetUserRole(userId, form.RoomId)
	if err != nil {
		utils.LogInfoF("获取用户角色失败")
	}
	userInfo.Role = role
	err = services.JoinLiveRoom(&liveRoom, &userInfo)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "处理加入房间逻辑失败", "", err.Error())
		return
	}

	response.ResponseOk(c, "ok", "ok")
	return
}

// 获取上次房间
func GetLastRoom(c *gin.Context) {
	userId := utils.FuncUserId(c)
	userIdStr := strconv.Itoa(int(userId))
	oldRoomId, err := utils.RedisClient.Get(utils.REDIS_LIVE_JOIN_USER + userIdStr).Int64()
	if err != nil && err != redis.Nil {
		utils.LogErrorF("查询用户加入的房间信息失败:userId[%s],err:%s", userIdStr, err.Error())
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查找用户房间失败", "", err.Error())
		return
	}
	data := response.LastLiveRoomResp{
		RoomId: oldRoomId,
	}
	response.ResponseOk(c, "ok", data)
	return
}
