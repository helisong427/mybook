package controller

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/models/dbmodels"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
	"strconv"
)

//AddTopic 发布话题
func AddTopic(gctx *gin.Context) {
	userId, _ := gctx.Get("userID")
	userIdInt64, _ := strconv.ParseInt(userId.(string), 10, 64)
	paramsJSON := request.AddTopicReq{}
	err := gctx.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	model := dbmodels.AppTopic{
		TopicTitle:    paramsJSON.TopicTitle,
		TopicContent:  "暂无内容",
		TopicIsSystem: int(dbmodels.TOPIC_IS_SYSYTEM_NO),
		TopicUserID:   int64(userIdInt64),
	}
	//查询话题是否存在
	affected, _, err := model.QueryByTitle(paramsJSON.TopicTitle)

	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	if affected == 1 {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "该话题已存在", "", "")
		return
	}

	err = model.Create()
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	r := response.AddTopicRep{
		TopicID:    model.TopicID,
		TopicTitle: model.TopicTitle,
	}
	response.ResponseOk(gctx, "发布话题成功", r)

}

//GetHotTopic 获取热门话题
func GetHotTopic(gctx *gin.Context) {
	model := dbmodels.AppTopic{}
	topics, err := model.QueryHot()
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	r := response.GetHotTopic{}
	for _, v := range topics {
		topic := response.AddTopicRep{
			TopicID:    v.TopicID,
			TopicTitle: v.TopicTitle,
		}
		r.List = append(r.List, topic)
	}

	response.ResponseOk(gctx, "获取热门话题成功", r)
}

//SearchTopic 搜索话题
func SearchTopic(gctx *gin.Context) {
	paramsJSON := request.SearchTopicReq{}
	err := gctx.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	model := dbmodels.AppTopic{}
	topic, err := model.QueryByLikeTitle(paramsJSON.TopicTitle)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	r := response.SearchTopic{
		IsSearch: 0,
	}
	if len(topic) == 0 {
		r.IsSearch = 0
	} else {
		for _, v := range topic {
			data := response.AddTopicRep{
				TopicID:    v.TopicID,
				TopicTitle: v.TopicTitle,
			}
			r.List = append(r.List, data)
			if v.TopicTitle == paramsJSON.TopicTitle {
				r.IsSearch = 1
			}
		}
	}

	response.ResponseOk(gctx, "搜索成功", r)
}
