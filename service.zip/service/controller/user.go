package controller

import (
	"encoding/json"
	"fmt"
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/enum"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/mq/rabbitmqProducer"
	"gamers/utils"
	"gamers/utils/chuanglan/shanyan"
	"gamers/utils/chuanglan/sms"
	"gamers/utils/tencent/facecore"
	"gamers/utils/tencent/tencentIm"

	"github.com/go-redis/redis"

	"strconv"
	"strings"
	"time"

	"gorm.io/gorm"

	"github.com/gin-gonic/gin"
)

// UserInfo 用户信息
func UserInfo(gctx *gin.Context) {
	userId, _ := gctx.Get("userID")
	userIdInt64, _ := strconv.ParseInt(userId.(string), 10, 64)
	model := dbmodels.SystemUser{}
	user, err := model.UserIdByUser(userIdInt64)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	attentionModel := dbmodels.AppAttention{}
	followsCount, err := attentionModel.GetUserFollowCount(userIdInt64)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	fansCount, err := attentionModel.GetUserFollowedCount(userIdInt64)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	var image []string
	if user.UserBackImage != "" {
		err = json.Unmarshal([]byte(user.UserBackImage), &image)
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
	}
	if image == nil || len(image) == 0 {
		image = []string{}
	} else {
		if image[0] == "" {
			image = []string{}
		}
	}

	r := response.UserInfoRep{
		UserId:         int(userIdInt64),
		UserPrettyId:   user.UserPrettyId,
		Nickname:       user.UserNickname,
		Gender:         user.UserGender,
		Iconurl:        user.UserIconurl,
		Mobile:         user.UserMobile,
		Birthday:       int(user.UserBirthday),
		Constellation:  user.UserConstellation,
		FansCount:      int(fansCount),
		FollowCount:    int(followsCount),
		ProvinceId:     int(user.UserProvinceID),
		CityId:         int(user.UserCityID),
		RegionId:       int(user.UserRegionID),
		Sound:          user.UserSound,
		SoundTime:      user.UserSoundTime,
		Slogan:         user.UserSlogan,
		Images:         image,
		VisitsCount:    0,
		IsSetPassword:  1,
		IsBindMobile:   1,
		IsAnchor:       user.UserIsAnchor,
		Age:            utils.FuncGetAge(int(user.UserBirthday)),
		LiveUnionId:    user.UserUnionId,
		UserIsRecharge: user.UserIsRecharge,
		CreateT:        user.BaseModel.Created,
	}
	if user.UserPassword == "" || user.UserSalt == "" {
		r.IsSetPassword = 0
	}
	if user.UserMobile == "" {
		r.IsBindMobile = 0
	}
	// 查询用户余额
	userWallet, err := new(dbmodels.AppUserWallet).Query(userIdInt64)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	r.WalletTotalOver = userWallet.WalletTotalOver
	// 获取地区信息
	if user.UserCityID != 0 {
		id := []int{
			int(user.UserCityID),
		}
		regionModel := dbmodels.SystemRegion{}
		regionData, err := regionModel.QueryById(id)
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		r.CityName = regionData[0].RegionFullname
	}

	// 获取直播兴趣信息
	if user.UserLiveSavor != "" {
		savorList := []response.UserLiveSavorRep{}
		savorsArr := strings.Split(user.UserLiveSavor, "_")
		savorData, err := new(dbmodels.AppSavor).QueryIdIn(savorsArr)
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		for _, v := range savorData {
			savor := response.UserLiveSavorRep{
				SavorId:   v.SavorID,
				SavorName: v.SavorName,
			}
			savorList = append(savorList, savor)
		}
		r.LiveSavor = savorList
	}

	// 获取游戏兴趣
	if user.UserGameSavor != "" {
		savorList := []response.UserGameSavorRep{}
		savorsArr := strings.Split(user.UserGameSavor, "_")
		savorData, err := new(dbmodels.AppSkill).QueryInGameName(savorsArr)
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		for _, v := range savorData {
			savor := response.UserGameSavorRep{
				GameId:   v.SkillId,
				GameName: v.SkillName,
			}
			savorList = append(savorList, savor)
		}
		r.GameSavor = savorList
	}

	r.IsBigGod = user.UserIsSparring
	// 判断是否大神
	sparringModel := dbmodels.Certification{}
	data, err := sparringModel.VerificationByUserId(userIdInt64)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if err == nil {
		// 是否身份认证
		if data.CertificationStatus == dbmodels.CERTIFICATION_STATUS_OK {
			r.IsIdCard = 1
		}
	}

	// // 判断是否是公会管理员
	// var liveunion dbmodels.AppRoomAdmin
	// liveUnionId := liveunion.GetAnchorUnionIDByUserId(userIdInt64)
	// r.LiveUnionId = liveUnionId

	// 判断是否拥有房间
	if r.IsIdCard == response.USER_IS_ID_CARD_TRUE {
		var room dbmodels.AppLiveRoom
		room, err = room.GetRoomInfoByUserId(userIdInt64)
		if err != nil && err != gorm.ErrRecordNotFound {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "获取用户房间信息错误", "", err.Error())
			return
		}
		if err == nil {
			r.UserRoomInfo.RoomType = room.RoomType
			r.UserRoomInfo.RoomId = room.RoomId
			r.UserRoomInfo.RoomLiveStatus = room.RoomLiveStatus
			r.UserRoomInfo.RoomCover = room.RoomCover
			r.UserRoomInfo.RoomStatus = room.RoomStatus
		}
	}

	// 访问
	cont, err := new(dbmodels.AppUserVisitorLog).QueryCont(userIdInt64)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "获取访问次数失败", "", err.Error())
		return
	}
	r.VisitsCount = cont

	// 最新访问次数
	visitsKey := fmt.Sprintf("%s%d", utils.REDIS_USER_NEW_VISITOR_COUNT, userIdInt64)
	result := utils.RedisClient.Get(visitsKey).Val()
	if result == "" {
		result = "0"
	}
	resultInt, err := strconv.Atoi(result)
	if err != nil {
		resultInt = 0
	}
	r.VisitCountNew = resultInt

	// 获取用户头像装扮
	avatarDressUp, err := new(redismodels.IconStyle).Get(userIdInt64)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "获取用户头像框失败", "", err.Error())
		return
	}
	r.AvatarDressUp = avatarDressUp

	// 获取用户气泡装扮
	chatDressUp, err := new(redismodels.ChatStyle).Get(userIdInt64)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "获取用户气泡装扮失败", "", err.Error())
		return
	}
	vipLevel, err := new(redismodels.UserInfo).GetUserVipLevel(userIdInt64)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "获取用户Vip等级失败", "", err.Error())
		return
	}
	r.VipLevel = vipLevel
	r.ChatDressUp = chatDressUp
	response.ResponseOk(gctx, "用户信息获取成功", r)
	return
}

// GetImSign 获取im签名
func GetImSign(gctx *gin.Context) {
	userId, _ := gctx.Get("userID")
	sign, err := tencentIm.GenUserSig(userId.(string), 60*60*24*180)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(gctx, "获取成功", gin.H{"sign": sign})
}

// 查询手机号
func QueryMobile(c *gin.Context) {
	clientType, err := strconv.Atoi(c.Request.Header.Get("Client-Type"))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "获取客户端类型失败", "", err.Error())
		return
	}

	params := request.QueryMobileReq{}
	err = c.ShouldBindJSON(&params)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	mobile, err := shanyan.SdkWarp{}.QueryPhone(shanyan.ClientType(clientType), params.Token)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "手机号获取失败", "", err.Error())
		return
	}

	r := response.QueryMobileRep{
		Mobile: mobile,
	}
	response.ResponseOk(c, "手机号获取成功", r)
}

// 用户初始化设置信息
func InitSetUserInfo(c *gin.Context) {
	// 获取用户userId
	userId := utils.FuncUserId(c)
	// 解析参数
	paramsJSON := request.InitSetUserInfoReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	// 根据userId查询用户三方信息
	_, data, err := new(dbmodels.SystemUserOpeninfo).QueryByUserId(userId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "用户不存在", "", err.Error())
		return
	}

	/*
		changer: 陈建君
		change: 2021-04-08 登录流程优化功能优化重构修改
		需求: https://shimo.im/docs/5smkTWu6qacbenag
	*/
	updateMap := make(map[string]interface{})
	// 用户性别
	updateMap["user_gender"] = paramsJSON.Gender
	// 默认生日18岁
	updateMap["user_birthday"] = time.Now().AddDate(-enum.USER_DEFAULT_AGE, 0, 0).Unix()
	// 判断是否有第三方用户信息
	if data.OpeninfoNickname == "" || data.OpeninfoIconurl == "" {
		// 获取默认昵称
		pramKeyDefaultNickname, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_DEFAULTNICKNAME)
		if err != nil {
			pramKeyDefaultNickname["value"] = ""
		}
		updateMap["user_nickname"] = fmt.Sprintf("%s%s", pramKeyDefaultNickname["value"], strconv.Itoa(int(userId))[2:10])
		// 获取默认头像,如果性别为0，默认取男性头像
		key := dbmodels.PRAM_KEY_DEFAULTMANICONURL
		if paramsJSON.Gender == 2 {
			key = dbmodels.PRAM_KEY_DEFAULTWOMANICONURL
		}
		defaultIconUrl, err := new(dbmodels.SystemParam).QueryKey(key)
		if err == nil {
			updateMap["user_iconurl"] = defaultIconUrl["value"]
		}
	} else {
		// 使用第三方昵称
		updateMap["user_nickname"] = data.OpeninfoNickname
		updateMap["user_iconurl"] = data.OpeninfoIconurl
	}

	r := response.InitSetUserInfoRep{}
	// 如果上传的性别有值，说明是登录优化之前的版本，需要做兼容处理
	if paramsJSON.Gender > 0 {
		// 更新用户表
		err = new(dbmodels.SystemUser).Update(userId, updateMap)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "用户信息设置失败", "", err.Error())
			return
		}
		userModel, err := new(dbmodels.SystemUser).UserIdByUser(userId)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户信息失败", "", err.Error())
			return
		}
		// 更新用户信息到redis
		go new(redismodels.UserInfoUpdate).UpdateUserInfo(userModel)
		// 设置腾讯im资料
		go tencentIm.PortraitSet(userId, userModel.UserNickname, userModel.UserIconurl)

		r.Nickname = userModel.UserNickname
		r.Iconurl = userModel.UserIconurl
		r.Birthday = userModel.UserBirthday
	} else {
		// 新版本，不需要更新，客户端在下一步会提交用户资料
		r.Nickname = updateMap["user_nickname"].(string)
		r.Iconurl = updateMap["user_iconurl"].(string)
		r.Birthday = updateMap["user_birthday"].(int64)
	}

	// 发送撩一撩消息。一分钟之后定时任务
	go rabbitmqProducer.ProducerInviteMessageUserID(userId)

	response.ResponseOk(c, "用户信息设置成功", r)
	return

	// // 查询第三方用户信息
	// row, data, err := new(dbmodels.SystemUserOpeninfo).QueryByUserId(userId)
	// if err != nil && err != gorm.ErrRecordNotFound {
	// 	response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "用户不存在", "", err.Error())
	// 	return
	// }
	// err = nil
	//
	// updateMap := make(map[string]interface{})
	// // 用户性别
	// updateMap["user_gender"] = paramsJSON.Gender
	// // 默认生日18岁
	// updateMap["user_birthday"] = time.Now().AddDate(-enum.USER_DEFAULT_AGE, 0, 0).Unix()
	//
	// if row == 0 {
	// 	pramKeyDefaultNickname, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_DEFAULTNICKNAME)
	// 	if err != nil {
	// 		pramKeyDefaultNickname["value"] = ""
	// 	}
	// 	// 默认昵称
	// 	idString := strconv.Itoa(int(userId))
	// 	updateMap["user_nickname"] = fmt.Sprintf("%s%s", pramKeyDefaultNickname["value"], idString[2:10])
	// 	if paramsJSON.Gender == 1 {
	// 		pramKeyDefaultManIconUrl, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_DEFAULTMANICONURL)
	// 		if err == nil {
	// 			updateMap["user_iconurl"] = pramKeyDefaultManIconUrl["value"]
	// 		}
	// 	} else {
	// 		pramKeyDefaultWomanIconUrl, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_DEFAULTWOMANICONURL)
	// 		if err == nil {
	// 			updateMap["user_iconurl"] = pramKeyDefaultWomanIconUrl["value"]
	// 		}
	// 	}
	// } else {
	// 	// 第三方用户信息为空,生成默认信息
	// 	if data.OpeninfoNickname == "" || data.OpeninfoIconurl == "" {
	// 		pramKeyDefaultNickname, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_DEFAULTNICKNAME)
	// 		if err != nil {
	// 			pramKeyDefaultNickname["value"] = ""
	// 		}
	// 		// 默认昵称
	// 		idString := strconv.Itoa(int(userId))
	// 		updateMap["user_nickname"] = fmt.Sprintf("%s%s", pramKeyDefaultNickname["value"], idString[2:10])
	// 		if paramsJSON.Gender == 1 {
	// 			pramKeyDefaultManIconUrl, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_DEFAULTMANICONURL)
	// 			if err == nil {
	// 				updateMap["user_iconurl"] = pramKeyDefaultManIconUrl["value"]
	// 			}
	// 		} else {
	// 			pramKeyDefaultWomanIconUrl, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_DEFAULTWOMANICONURL)
	// 			if err == nil {
	// 				updateMap["user_iconurl"] = pramKeyDefaultWomanIconUrl["value"]
	// 			}
	// 		}
	// 	} else {
	// 		// 使用第三方昵称
	// 		updateMap["user_nickname"] = data.OpeninfoNickname
	// 		updateMap["user_iconurl"] = data.OpeninfoIconurl
	// 	}
	// }
	//
	// err = new(dbmodels.SystemUser).Update(userId, updateMap)
	// if err != nil {
	// 	response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "用户信息设置失败", "", err.Error())
	// 	return
	// }
	// userModel, err := new(dbmodels.SystemUser).UserIdByUser(userId)
	// if err != nil {
	// 	response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户信息失败", "", err.Error())
	// 	return
	// }
	//
	// go new(redismodels.UserInfoUpdate).UpdateUserInfo(userModel)
	//
	// go tencentIm.PortraitSet(userId, userModel.UserNickname, userModel.UserIconurl)
	// r := response.InitSetUserInfoRep{
	// 	Nickname: userModel.UserNickname,
	// 	Iconurl:  userModel.UserIconurl,
	// 	Birthday: userModel.UserBirthday,
	// }
	// response.ResponseOk(c, "用户信息设置成功", r)
	// return
}

// SetUserInfo 设置用户信息
func SetUserInfo(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.SetUserInfoReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	// 获取用户信息
	userInfo, err := new(dbmodels.SystemUser).UserIdByUser(userId)
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "用户不存在", "", err.Error())
			return
		}
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if userInfo.UserIsSparring == dbmodels.USER_IS_SPARRING_YES {
		if *paramsJSON.Iconurl != "" {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "您目前是大神,无法通过此渠道修改头像,请前往技能认证信息页修改", "", "")
			return
		}
		paramsJSON.Iconurl = &userInfo.UserIconurl
	}
	msg, err := services.SetUserInfo(userId, paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}
	response.ResponseOk(c, "用户信息设置成功", nil)
}

// 更新密码校验
func UpdatePasswordVerify(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramJSON := request.UpdatePasswordVerifyReq{}
	err := c.ShouldBindJSON(&paramJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	user, err := new(dbmodels.SystemUser).UserIdByUser(userId)
	if paramJSON.OldPassword == "" || len([]rune(paramJSON.OldPassword)) != 16 {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "旧密码非法", "", "")
		return
	}

	if user.UserPassword != utils.FuncMD5(paramJSON.OldPassword+user.UserSalt) {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "旧密码错误", "", "")
		return
	}
	key := fmt.Sprintf("%s%d", utils.REDIS_FORGET_UPDATE_PASSWORD_VERIFY, userId)
	err = utils.RedisClient.Set(key, 1, time.Minute*10).Err()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "旧密码错误校验失败", "", err.Error())
		return
	}

	response.ResponseOk(c, "旧密码校验成功", nil)
	return
}

// SetPassword 设置密码
func SetPassword(gctx *gin.Context) {
	userId, _ := gctx.Get("userID")
	userIdInt64, _ := strconv.ParseInt(userId.(string), 10, 64)
	paramJSON := request.SetPasswordReq{}
	err := gctx.ShouldBindJSON(&paramJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	if paramJSON.NewPassword != paramJSON.NewPassword2 {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "两次密码不一致", "", "")
		return
	}

	model := dbmodels.SystemUser{}
	user, err := model.UserIdByUser(userIdInt64)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	if paramJSON.Type == 1 {
		// 如果是设置密码，检查密码是否已经设置
		if user.UserPassword != "" || user.UserSalt != "" {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "密码已设置", "", "")
			return
		}
	} else if paramJSON.Type == 2 {
		// 如果是更新密码，检查原密码是否通过校验
		key := fmt.Sprintf("%s%d", utils.REDIS_FORGET_UPDATE_PASSWORD_VERIFY, userIdInt64)
		_, err := utils.RedisClient.Get(key).Result()
		if err != nil && err == redis.Nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "旧密码未校验", "", "")
			return
		}
		utils.RedisClient.Del(key)
	} else if paramJSON.Type == 3 {
		// 如果是重置密码，检查验证码
		key := utils.REDIS_FORGET_PASSWORD_CHECK + userId.(string)
		if utils.RedisClient.Get(key).Val() == "" {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "手机号未验证", "", "")
			return
		}
		utils.RedisClient.Del(key)
	} else {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "参数错误", "", "type不在范围内")
		return
	}

	salt := utils.FuncRandString(16)
	password := paramJSON.NewPassword
	model.UserPassword = utils.FuncMD5(password + salt)
	model.UserSalt = salt

	err = model.UpdateUserInfo(user.UserID)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "密码设置失败", "", err.Error())
		return
	}
	response.ResponseOk(gctx, "密码设置成功", nil)

}

// ForGetPassword 忘记密码
func ForGetPassword(gctx *gin.Context) {
	userId, _ := gctx.Get("userID")
	userIdInt64, _ := strconv.ParseInt(userId.(string), 10, 64)
	paramsJSON := request.ForGetPasswordReq{}
	err := gctx.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	err = utils.FuncSmsTimestamp(paramsJSON.Timestamp)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "请检查当前系统时间", "", err.Error())
		return
	}

	ClientKey := utils.Config.App.ClientKey
	sign := utils.FuncMD5(fmt.Sprintf("%s%d%s", ClientKey, paramsJSON.Timestamp, paramsJSON.Uuid))
	fmt.Println(sign)
	if sign != paramsJSON.Sign {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "非法请求", "", "")
		return
	}

	model := dbmodels.SystemUser{}
	user, err := model.UserIdByUser(int64(userIdInt64))
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if user.UserMobile == "" {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "未绑定手机号", "", "")
		return
	}

	// 给用户绑定的手机号发送验证码
	smsCodeKey := utils.REDIS_FORGET_SMS_CODE + user.UserMobile
	smsIpKey := utils.REDIS_FORGET_SMS_IP + gctx.ClientIP()
	smsClientKey := utils.REDIS_FORGET_SMS_CLIENT_CODE + gctx.Request.Header.Get("Udid")
	// 设备信息+ip限流
	smsIp := utils.RedisClient.Get(smsIpKey).Val()
	smsClient := utils.RedisClient.Get(smsClientKey).Val()
	if smsIp != "" || smsClient != "" {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "操作过于频繁，请3分钟后再尝试", "", "")
		return
	}

	// 生成验证码
	code := utils.FuncRandRangeInt(1000, 9999)
	fmt.Println(code)
	msgParams := fmt.Sprintf("%s,%d,%d", user.UserMobile, code, 5)
	go sms.SendSms(2, sms.SMS_CODE, msgParams)
	pipe := utils.RedisClient.TxPipeline()
	pipe.Set(smsCodeKey, code, 60*5*time.Second)
	pipe.Set(smsIpKey, 1, 60*time.Second)
	pipe.Set(smsClientKey, 1, 60*time.Second) // 限制每分钟3次验证码
	_, err = pipe.Exec()
	if err != nil {
		utils.LogErrorF("存储登录信息错误，err:%s", err.Error())
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "发送验证码失败，稍后再试", "", "")
		return
	}
	if !utils.FuncEnv() {
		response.ResponseOk(gctx, "发送成功", gin.H{"code": code})
		return
	} else {
		response.ResponseOk(gctx, "发送成功", nil)
		return
	}
}

// ForGetPasswordCheck 忘记密码验证
func ForGetPasswordCheck(gctx *gin.Context) {
	userId, _ := gctx.Get("userID")
	userIdInt64, _ := strconv.ParseInt(userId.(string), 10, 64)
	paramJSON := request.ForGetPasswordCheckReq{}
	err := gctx.ShouldBindJSON(&paramJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	model := dbmodels.SystemUser{}
	user, err := model.UserIdByUser(int64(userIdInt64))
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	if user.UserMobile == "" {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "未绑定手机号", "", "")
		return
	}

	smsCodeKey := utils.REDIS_FORGET_SMS_CODE + user.UserMobile
	code, err := utils.RedisClient.Get(smsCodeKey).Int()
	if err != nil && err != redis.Nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "验证码错误", "", err.Error())
		return
	}

	if err != nil && err == redis.Nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "验证码已过期", "", err.Error())
		return
	}

	if paramJSON.Code != code {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "验证码错误", "", "")
		return
	}

	// 设置一个参数代表该用户验证密码成功
	key := utils.REDIS_FORGET_PASSWORD_CHECK + userId.(string)
	smsIpKey := utils.REDIS_FORGET_SMS_IP + gctx.ClientIP()
	smsClientKey := utils.REDIS_FORGET_SMS_CLIENT_CODE + gctx.Request.Header.Get("Udid")
	err = utils.RedisClient.Set(key, 1, 60*60*time.Second).Err()
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	utils.RedisClient.Del(smsCodeKey)
	utils.RedisClient.Del(smsIpKey)
	utils.RedisClient.Del(smsClientKey)
	response.ResponseOk(gctx, "验证成功", nil)
}

// OldMobileSms 旧手机发送验证码
func OldMobileSms(gctx *gin.Context) {
	userId, _ := gctx.Get("userID")
	userIdInt64, _ := strconv.ParseInt(userId.(string), 10, 64)

	paramsJSON := request.OldMobileSmsReq{}
	err := gctx.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	err = utils.FuncSmsTimestamp(paramsJSON.Timestamp)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "请检查当前系统时间", "", err.Error())
		return
	}

	ClientKey := utils.Config.App.ClientKey
	sign := utils.FuncMD5(fmt.Sprintf("%s%d%s", ClientKey, paramsJSON.Timestamp, paramsJSON.Uuid))
	fmt.Println("sign = ", sign)
	if sign != paramsJSON.Sign {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "非法请求", "", "")
		return
	}

	model := dbmodels.SystemUser{}
	user, err := model.UserIdByUser(int64(userIdInt64))
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	if user.UserMobile == "" {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "未绑定手机号", "", "")
		return
	}

	// 给用户绑定的手机号发送验证码
	smsCodeKey := utils.REDIS_OLD_SMS_CODE + user.UserMobile
	smsIpKey := utils.REDIS_OLD_SMS_IP + gctx.ClientIP()
	smsClientKey := utils.REDIS_OLD_SMS_CLIENT_CODE + gctx.Request.Header.Get("Udid")
	// 设备信息+ip限流
	smsIp := utils.RedisClient.Get(smsIpKey).Val()
	smsClient := utils.RedisClient.Get(smsClientKey).Val()
	if smsIp != "" || smsClient != "" {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "操作过于频繁，请3分钟后再尝试", "", "")
		return
	}

	// 生成验证码
	code := utils.FuncRandRangeInt(1000, 9999)
	fmt.Println(code)
	msgParams := fmt.Sprintf("%s,%d,%d", user.UserMobile, code, 5)
	go sms.SendSms(2, sms.SMS_CODE, msgParams)
	pipe := utils.RedisClient.TxPipeline()
	pipe.Set(smsCodeKey, code, 60*5*time.Second)
	pipe.Set(smsIpKey, 1, 60*time.Second)
	pipe.Set(smsClientKey, 1, 60*time.Second) // 限制每分钟3次验证码
	_, err = pipe.Exec()
	if err != nil {
		utils.LogErrorF("存储登录信息错误，err:%s", err.Error())
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "发送验证码失败，稍后再试", "", "")
		return
	}
	if !utils.FuncEnv() {
		response.ResponseOk(gctx, "发送成功", gin.H{"code": code})
		return
	} else {
		response.ResponseOk(gctx, "发送成功", nil)
		return
	}
}

// OldMobileCheck 旧手机验证
func OldMobileCheck(gctx *gin.Context) {
	userId, _ := gctx.Get("userID")
	userIdInt64, _ := strconv.ParseInt(userId.(string), 10, 64)
	paramsJSON := request.OldMobileCheckReq{}
	err := gctx.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	model := dbmodels.SystemUser{}
	user, err := model.UserIdByUser(int64(userIdInt64))
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	if user.UserMobile == "" {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "未绑定手机号", "", "")
		return
	}

	smsCodeKey := utils.REDIS_OLD_SMS_CODE + user.UserMobile
	code, err := utils.RedisClient.Get(smsCodeKey).Int()
	if err != nil && err != redis.Nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "验证码错误", "", err.Error())
		return
	}
	if err != nil && err == redis.Nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "验证码超时,请重新获取", "", err.Error())
		return
	}

	if paramsJSON.Code != code {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "验证码错误", "", "")
		return
	}

	// 设置一个参数代表该用户验证成功
	key := utils.REDIS_OLD_MOBILE_CHECK + userId.(string)
	smsIpKey := utils.REDIS_OLD_SMS_IP + gctx.ClientIP()
	smsClientKey := utils.REDIS_OLD_SMS_CLIENT_CODE + gctx.Request.Header.Get("Udid")
	err = utils.RedisClient.Set(key, 1, 60*60*time.Second).Err()
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	utils.RedisClient.Del(smsCodeKey)
	utils.RedisClient.Del(smsIpKey)
	utils.RedisClient.Del(smsClientKey)
	response.ResponseOk(gctx, "验证成功", nil)
}

// NewMobileBind 新手机号绑定
func NewMobileBind(gctx *gin.Context) {
	userId, _ := gctx.Get("userID")
	userIdInt64, _ := strconv.ParseInt(userId.(string), 10, 64)
	paramsJSON := request.NewMobileBindReq{}
	err := gctx.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	if !utils.FuncVerifyMobile(paramsJSON.Mobile) {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "手机号格式错误", "", "")
		return
	}

	// 短信验证码验证,这里的验证码使用`login/sms-code`接口的验证码
	key := utils.REDIS_SMS_CODE + paramsJSON.Mobile
	code, err := utils.RedisClient.Get(key).Int()
	if err != nil && err != redis.Nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "验证码错误", "", err.Error())
		return
	}

	if err != nil && err == redis.Nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "验证码超时,请重新获取", "", err.Error())
		return
	}

	if paramsJSON.Code != code {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "验证码错误", "", "")
		return
	}

	// 旧手机号是否验证成功
	oldCheck := utils.REDIS_OLD_MOBILE_CHECK + userId.(string)
	if utils.RedisClient.Get(oldCheck).Val() == "" {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "旧手机号未验证", "", "")
		return
	}

	model := dbmodels.SystemUser{}

	// 查询手机号是否绑定用户
	row, _, err := model.MobileByUser(paramsJSON.Mobile)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if row != 0 {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "该手机号已绑定", "", "")
		return
	}

	// 查询当前用户信息
	user, err := model.UserIdByUser(userIdInt64)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if user.UserMobile == paramsJSON.Mobile {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "旧手机号不能和旧手机号一致", "", "")
		return
	}

	model.UserMobile = paramsJSON.Mobile
	err = model.UpdateUserInfo(userIdInt64)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	// 删除redis key
	utils.RedisClient.Del(oldCheck)
	utils.RedisClient.Del(key)

	response.ResponseOk(gctx, "绑定成功", nil)
}

// FollowUser 关注用户
func FollowUser(gctx *gin.Context) {
	userId, _ := gctx.Get("userID")
	userIdInt, _ := strconv.Atoi(userId.(string))
	paramsJSON := request.FollowUserReq{}
	err := gctx.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	if userIdInt == paramsJSON.FollowUserId {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "不能关注自己", "", "")
		return
	}

	// 查询被关注用户是否存在
	userModel := dbmodels.SystemUser{}
	_, err = userModel.UserIdByUser(int64(paramsJSON.FollowUserId))
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	if err != nil && err == gorm.ErrRecordNotFound {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "关注用户不存在", "", err.Error())
		return
	}

	// 查询是否已经关注
	model := dbmodels.AppAttention{}
	fansModel := dbmodels.AppFan{}
	_, err = model.QueryExist(userIdInt, paramsJSON.FollowUserId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	attention := services.InitAttention()
	if err != gorm.ErrRecordNotFound {
		// 取消关注
		err = model.Delete(userIdInt, paramsJSON.FollowUserId)
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}

		err = fansModel.Delete(paramsJSON.FollowUserId, userIdInt)
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		go attention.LikeTag(userIdInt, paramsJSON.FollowUserId, false)
		response.ResponseOk(gctx, "取消关注成功", gin.H{"is_follow": 0})
		return
	} else {
		_, err = new(dbmodels.AppBlacklist).Exists(int64(paramsJSON.FollowUserId), int64(userIdInt))
		if err != nil && err != gorm.ErrRecordNotFound {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "获取用户黑名单信息错误", "", err.Error())
			return
		}
		if err == nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "你已被对方拉黑,无法关注", "", "")
			return
		}
		model.AttentionUserID = int64(userIdInt)
		model.AttentionFollowUserID = int64(paramsJSON.FollowUserId)
		err = model.Create()
		if err != nil && err != gorm.ErrRecordNotFound {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}

		fansModel.FanUserID = int64(paramsJSON.FollowUserId)
		fansModel.FanFollowUserID = int64(userIdInt)
		err = fansModel.Create()
		if err != nil && err == gorm.ErrRecordNotFound {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		go attention.Like(userIdInt, paramsJSON.FollowUserId)
		go attention.LikeTag(userIdInt, paramsJSON.FollowUserId, true)
		go func() {
			_ = new(redismodels.Task).Init().ReportConditionTag(int64(userIdInt), "followUserWithInterest", 1)
		}()
		response.ResponseOk(gctx, "关注成功", gin.H{"is_follow": 1})
		return
	}
}

// UserSavorList 兴趣列表
func UserSavorList(gctx *gin.Context) {
	// 查询直播兴趣
	liveData, err := new(dbmodels.AppSavor).Query()
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	// 查询技能兴趣
	skillData, err := new(dbmodels.AppSkill).QuerySkillName()
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	r := response.UserSavorRep{}
	for _, v := range liveData {
		res := response.UserLiveSavorRep{
			SavorId:   v.SavorID,
			SavorName: v.SavorName,
		}
		r.UserLiveSavorRep = append(r.UserLiveSavorRep, res)
	}
	for _, v := range skillData {
		res := response.UserGameSavorRep{
			GameId:   int64(v.SkillId),
			GameName: v.SkillName,
		}
		r.UserGameSavorRep = append(r.UserGameSavorRep, res)
	}

	response.ResponseOk(gctx, "获取成功", r)
}

// GetUserFollow 获取用户关注/粉丝
func GetUserFollowList(gctx *gin.Context) {
	var (
		total int64
		data  []dbmodels.AppAttention
		err   error
	)
	userId, _ := gctx.Get("userID")
	userIdInt, _ := strconv.ParseInt(userId.(string), 10, 64)
	paramsJSON := request.GetUserFollowListReq{}
	err = gctx.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	model := dbmodels.AppAttention{}
	if paramsJSON.Type == 1 {
		// 获取关注
		total, data, err = model.QueryPageFollow(userIdInt, paramsJSON.Page, paramsJSON.Size, paramsJSON.IsOnline)
	} else {
		// 获取粉丝
		total, data, err = model.QueryPageFollowed(userIdInt, paramsJSON.Page, paramsJSON.Size, paramsJSON.IsOnline)
	}

	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	list := []response.GetUserFollowListRep{}

	// 查询互相关注列表
	closelyList := []dbmodels.AppAttention{}
	userIds := []int64{}
	if paramsJSON.Type == 1 {
		for _, v := range data {
			userIds = append(userIds, v.AttentionFollowUserID)
		}
		closelyList, err = model.QueryFollowIn(userIds, userIdInt)
	} else {
		for _, v := range data {
			userIds = append(userIds, v.AttentionUserID)
		}
		closelyList, err = model.QueryFollowedIn(userIds, userIdInt)
	}

	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	for _, v := range data {
		res := response.GetUserFollowListRep{}
		if paramsJSON.Type == 1 {
			res.UserID = v.FollowSystemUser.UserID
			res.Nickname = v.FollowSystemUser.UserNickname
			res.Gender = v.FollowSystemUser.UserGender
			res.Iconurl = v.FollowSystemUser.UserIconurl
			res.Slogan = v.FollowSystemUser.UserSlogan
			res.Age = utils.FuncGetAge(int(v.FollowSystemUser.UserBirthday))
			res.IsOnline = v.FollowSystemUser.UserIsOnline
			for _, val := range closelyList {
				if v.AttentionFollowUserID == val.AttentionUserID {
					res.IsClosely = 1
				}
			}
		} else {
			res.UserID = v.FollowedSystemUser.UserID
			res.Nickname = v.FollowedSystemUser.UserNickname
			res.Gender = v.FollowedSystemUser.UserGender
			res.Iconurl = v.FollowedSystemUser.UserIconurl
			res.Slogan = v.FollowedSystemUser.UserSlogan
			res.Age = utils.FuncGetAge(int(v.FollowedSystemUser.UserBirthday))
			res.IsOnline = v.FollowedSystemUser.UserIsOnline
			for _, val := range closelyList {
				if v.AttentionUserID == val.AttentionFollowUserID {
					res.IsClosely = 1
				}
			}
		}
		list = append(list, res)
	}

	r := response.BasePageList{
		Page:       paramsJSON.Page,
		Size:       paramsJSON.Size,
		Total:      total,
		TotalPages: utils.FuncTotalPages(total, paramsJSON.Size),
		List:       list,
	}
	response.ResponseOk(gctx, "获取成功", r)
}

// SparringIdCardVerification 身份证认证
func SparringIdCardVerification(gctx *gin.Context) {
	userId, _ := gctx.Get("userID")
	userIdInt64, _ := strconv.ParseInt(userId.(string), 10, 64)
	paramsJSON := request.CardVerificationReq{}
	err := gctx.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	if !utils.FuncVerifyIdCard(paramsJSON.IdCard) {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "身份证号码不合法", "", "")
		return
	}

	model := dbmodels.Certification{}
	data, err := model.QueryByUserId(userIdInt64)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	now := time.Now()

	if err == nil {
		if data.CertificationStatus == dbmodels.CERTIFICATION_STATUS_OK {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "已通过审核", "", "")
			return
		}
		applyTime := time.Unix(data.CertificationApplyTime, 0)
		if data.CertificationApplyCount >= dbmodels.CERTIFICATION_MAX_APPLY_COUNT && applyTime.Day() == now.Day() {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "已超过每日最大申请次数", "", "")
			return
		}

		verification, err := facecore.IdCardVerification(&paramsJSON.IdCard, &paramsJSON.Name)
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", "")
			return
		}

		// 更新
		model.CertificationRealName = paramsJSON.Name
		model.CertificationIdCode = paramsJSON.IdCard
		model.CertificationApplyTime = now.Unix()
		model.CertificationApplyCount = data.CertificationApplyCount + 1
		if *verification.Response.Result == "0" {
			model.CertificationStatus = dbmodels.CERTIFICATION_STATUS_OK // 审核通过
		} else {
			model.CertificationStatus = dbmodels.CERTIFICATION_STATUS_PASS // 审核未通过
		}
		_, err = model.Update(userIdInt64)
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		// 审核未通过
		if *verification.Response.Result != "0" {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, *verification.Response.Description, "", "")
			return
		}

		go func() {
			_ = new(redismodels.Task).Init().ReportConditionTag(userIdInt64, "realNameAuthentication", 1)
		}()

		response.ResponseOk(gctx, "审核通过", nil)
		return
	} else {
		// 调用接口验证身份信息
		verification, err := facecore.IdCardVerification(&paramsJSON.IdCard, &paramsJSON.Name)
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", "")
			return
		}

		model.CertificationId = int64(userIdInt64)
		model.CertificationRealName = paramsJSON.Name
		model.CertificationIdCode = paramsJSON.IdCard
		model.CertificationApplyTime = now.Unix()
		model.CertificationApplyCount = 1

		if *verification.Response.Result == "0" {
			model.CertificationStatus = dbmodels.CERTIFICATION_STATUS_OK // 审核通过
		} else {
			model.CertificationStatus = dbmodels.CERTIFICATION_STATUS_PASS // 未通过
		}

		_, err = model.Create()
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		// 审核未通过
		if *verification.Response.Result != "0" {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, *verification.Response.Description, "", "")
			return
		}

		go func() {
			_ = new(redismodels.Task).Init().ReportConditionTag(userIdInt64, "realNameAuthentication", 1)
		}()

		response.ResponseOk(gctx, "审核通过", nil)
		return
	}
}

// 其他用户信息
func OtherUserInfo(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.OtherUserInfoReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	// 数据库查询用户信息
	user, err := new(dbmodels.SystemUser).UserIdByUser(int64(paramsJSON.UserId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "用户不存在", "", err.Error())
		return
	}
	// 判断用户状态
	if user.UserStatus > dbmodels.USER_STATUS_LOCK {
		response.ResponseError(c, response.RESPONSE_USER_STATUS_ERROR, "该用户账号异常", "", "")
		return
	}

	// 判断 用户是否在线
	// 获取用户缓存
	userInfo, err := new(redismodels.UserInfo).GetUserInfo(user.UserID)
	if err != nil {
		return
	}

	if userInfo.UserIsOnline != user.UserIsOnline {
		new(redismodels.UserInfo).UpdateIsOnline(fmt.Sprintf("%v", user.UserID), user.UserIsOnline)
	}

	fansCount, err := new(dbmodels.AppAttention).GetUserFollowedCount(int64(paramsJSON.UserId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	if user.UserBackImage == "" {
		user.UserBackImage = ""
	}
	image := []string{}
	json.Unmarshal([]byte(user.UserBackImage), &image)
	if len(image) > 0 && image[0] == "" {
		image = []string{}
	}
	r := response.OtherUserInfoRep{
		UserId:           int(user.UserID),
		UserPrettyId:     user.UserPrettyId,
		Nickname:         user.UserNickname,
		Gender:           user.UserGender,
		Iconurl:          user.UserIconurl,
		Constellation:    user.UserConstellation,
		Sound:            user.UserSound,
		SoundTime:        user.UserSoundTime,
		Slogan:           user.UserSlogan,
		Images:           image,
		FansCount:        int(fansCount),
		Age:              utils.FuncGetAge(int(user.UserBirthday)),
		IsBigGod:         user.UserIsSparring,
		UserOnlineStatus: user.UserIsOnline,
	}

	// 获取直播兴趣信息
	if user.UserLiveSavor != "" {
		savorList := []response.UserLiveSavorRep{}
		savorsArr := strings.Split(user.UserLiveSavor, "_")
		savorData, err := new(dbmodels.AppSavor).QueryIdIn(savorsArr)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		for _, v := range savorData {
			savor := response.UserLiveSavorRep{
				SavorId:   v.SavorID,
				SavorName: v.SavorName,
			}
			savorList = append(savorList, savor)
		}
		r.LiveSavor = savorList
	}

	// 获取游戏兴趣
	if user.UserGameSavor != "" {
		savorList := []response.UserGameSavorRep{}
		savorsArr := strings.Split(user.UserGameSavor, "_")
		savorData, err := new(dbmodels.AppSkill).QueryInGameName(savorsArr)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		for _, v := range savorData {
			savor := response.UserGameSavorRep{
				GameId:   v.SkillId,
				GameName: v.SkillName,
			}
			savorList = append(savorList, savor)
		}
		r.GameSavor = savorList
	}

	// 是否关注
	followed, err := new(dbmodels.AppAttention).QueryFollowed(userId, int64(paramsJSON.UserId))
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if followed > 0 {
		r.IsFollow = 1
	}

	// 查询用户所在用户房间信息
	// 只有在线的时候查询
	if r.UserOnlineStatus == 1 {
		key := fmt.Sprintf("%s%d", utils.REDIS_LIVE_JOIN_USER, paramsJSON.UserId)
		roomId := utils.RedisClient.Get(key).Val()
		if roomId != "" {
			roomIdInt, _ := strconv.Atoi(roomId)
			// 查询直播间信息
			room, err := new(dbmodels.AppLiveRoom).QueryRoomId(roomIdInt)
			if err != nil {
				response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
				return
			}
			// 判断房间状态是否正常
			if (room.RoomType == dbmodels.ROOM_TYPE_LIVE && room.RoomStatus == dbmodels.ROOM_STATUS_OK && room.RoomLiveStatus == dbmodels.ROOM_LIVE_STATUS_ON) || (room.RoomType == dbmodels.ROOM_TYPE_PARTY && room.RoomStatus == dbmodels.ROOM_STATUS_OK) {
				r.UserRoomInfo.RoomId = room.RoomId
				r.UserRoomInfo.RoomCover = room.RoomCover
				r.UserRoomInfo.RoomType = room.RoomType
				r.UserRoomInfo.RoomLiveStatus = room.RoomLiveStatus
			}
		}
	}

	// 是否实名认证
	certificationData, err := new(dbmodels.Certification).VerificationByUserId(int64(paramsJSON.UserId))
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if certificationData.CertificationStatus == dbmodels.CERTIFICATION_STATUS_OK {
		r.IsRealName = 1
	}
	// 大神技能信息
	if r.IsBigGod == 1 {
		data, err := new(dbmodels.AppSparringSkill).QuerySkillByOtherUserId(int64(paramsJSON.UserId))
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}

		for _, v := range data {
			skill := response.OtherUserSparringSkill{
				SparringId:   int(v.SkillID),
				SkillType:    v.AppSkill.SkillType,
				SkillName:    v.AppSkill.SkillName,
				SkillIconurl: v.AppSkill.SkillIconurl,
				ServiceCount: int(v.SkillOrderCount),
			}

			for _, val := range v.AppSparringSkillInfo {
				// 如果技能表的必填字段等于技能配置表的技能字段名称
				if v.AppSkill.SkillRequiredField == val.AppSkillFieldValue.ValueField {
					// 游戏段位
					skill.CertifiedValue = val.AppSkillFieldValue.ValueValue
				}
			}

			// 价格
			min, err := new(dbmodels.AppSparringSkillPrice).GetSparringByMin(v.SkillID)
			if err != nil && err == gorm.ErrRecordNotFound {
				continue
			} else {
				skill.PriceWay = min.AppSkillPrice.PriceWay
				skill.PricePrice = int(min.PricePrice)
			}
			r.SparringSkill = append(r.SparringSkill, skill)
		}
	}

	// 获取用户头像装扮
	avatarDressUp, err := new(redismodels.IconStyle).Get(int64(paramsJSON.UserId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户头像框失败", "", err.Error())
		return
	}
	r.AvatarDressUp = avatarDressUp
	info, err := new(redismodels.UserInfo).GetUserInfo(int64(paramsJSON.UserId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户vip失败", "", err.Error())
		return
	}
	r.VipLevel = info.VipLevel

	// 查询拉黑
	blackExits, err := new(dbmodels.AppBlacklist).Exists(userId, int64(paramsJSON.UserId))
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户拉黑列表失败", "", err.Error())
		return
	}
	if blackExits.BlacklistId != 0 {
		r.IsBlack = 1
	}

	// 记录访问记录
	go func() {
		if err = services.SaveUserVisitorLog(int64(paramsJSON.UserId), userId, 0); err != nil {
			utils.LogErrorF("save user visitor log error: %v", err.Error())
		}
	}()
	response.ResponseOk(c, "", r)
	return
}

// 设置大神是否接受用户浏览推送消息
func SparringMessageSet(c *gin.Context) {
	var (
		err    error
		userId int64
		req    request.SparringMessageSetEdit
	)

	userId = utils.FuncUserId(c)

	if err = c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	if err = services.SparringMessageSet(&req, userId); err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	response.ResponseOk(c, "", req.UserIsForwardsNews)
}

// 用户名片
func UserCard(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.UserCardReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	data, err := services.GetUserCard(paramsJSON.UserId, paramsJSON.RoomId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询用户信息失败", "", err.Error())
		return
	}
	// 是否关注
	followed, err := new(dbmodels.AppAttention).QueryFollowed(userId, paramsJSON.UserId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if followed > 0 {
		data.IsFollow = 1
	}

	response.ResponseOk(c, "", data)
	return
}

// 更新青少年模式
func UpdateUserYouth(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.UpdateUserYouthReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	if len([]rune(paramsJSON.Password)) != 32 {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "密码格式错误", "", "")
		return
	}

	// 查询用户信息
	user, err := new(dbmodels.SystemUser).UserIdByUser(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	if paramsJSON.Action == 1 {
		// 设置青少年模式
		if user.UserYouthStatus == dbmodels.USER_YOUTH_STATUS_OPEN {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "请勿重复开启青少年模式", "", "")
			return
		}
		err := new(dbmodels.SystemUser).SetYouth(userId, paramsJSON.Password)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
	} else {
		// 取消青少年模式
		if user.UserYouthStatus == dbmodels.USER_YOUTH_STATUS_OFF {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "请勿重复取消青少年模式", "", "")
			return
		}
		if user.UserYouthPassword != paramsJSON.Password {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "密码错误", "", "")
			return
		}

		err := new(dbmodels.SystemUser).CancelYouth(userId)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
	}
	user.UserYouthStatus = paramsJSON.Action
	user.UserYouthPassword = paramsJSON.Password

	go new(redismodels.UserInfoUpdate).UpdateUserInfo(user)
	response.ResponseOk(c, "操作成功", nil)
	return
}

// 检查青少年模式
func CheckUserYouth(c *gin.Context) {
	userId := utils.FuncUserId(c)
	info, err := new(redismodels.UserInfo).GetUserInfo(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取青少年模式成功", gin.H{"youth": info.UserYouthStatus})
}

// 举报
func Report(c *gin.Context) {
	const (
		reportUser int = iota // 用户
		reportRoom
		reportTweet
		reportTweetComment
		reportSkill
	)
	userId := utils.FuncUserId(c)
	paramsJSON := request.ReportReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	if len(paramsJSON.ReportImage) > 3 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "最多三张图片", "", "")
		return
	}

	if len([]rune(paramsJSON.ReportContent)) < 10 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "举报内容最少10个字符", "", "")
		return
	}

	var reportImage string
	if len(paramsJSON.ReportImage) > 0 {
		marshal, err := json.Marshal(paramsJSON.ReportImage)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		reportImage = string(marshal)
	}
	if paramsJSON.ReportToType == reportUser {
		user, err := new(dbmodels.SystemUser).UserIdByUser(int64(paramsJSON.ReportToId))
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		if user.UserID == userId {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "不能举报自己", "", "")
			return
		}
	} else if paramsJSON.ReportToType == reportRoom {
		room, err := new(dbmodels.AppLiveRoom).QueryRoomId(paramsJSON.ReportToId)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		if room.RoomUserId == userId {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "不能举报自己", "", "")
			return
		}

	} else if paramsJSON.ReportToType == reportTweet {
		_, data, err := new(dbmodels.AppTweet).QueryById(paramsJSON.ReportToId)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		if int64(data.TweetUserID) == userId {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "不能举报自己", "", "")
			return
		}
	} else if paramsJSON.ReportToType == reportTweetComment {
		_, data, err := new(dbmodels.AppTweetComment).QueryFirst(paramsJSON.ReportToId)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		if data.CommentUserID == userId {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "不能举报自己", "", "")
			return
		}

	} else if paramsJSON.ReportToType == reportSkill {
		data, err := new(dbmodels.AppSparringSkill).QueryFirst(int64(paramsJSON.ReportToId))
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		if data.SkillUserID == userId {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "不能举报自己", "", "")
			return
		}
	}
	model := dbmodels.AppReport{
		ReportType:    int64(paramsJSON.ReportType),
		ReportContent: paramsJSON.ReportContent,
		ReportUserId:  userId,
		ReportImage:   reportImage,
		ReportToId:    int64(paramsJSON.ReportToId),
		ReportToType:  int64(paramsJSON.ReportToType),
		ReportRoomId:  int64(paramsJSON.ReportRoomId),
	}

	err = model.Create()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	response.ResponseOk(c, "举报成功", nil)
	return
}

// 用户认证详情
func UserCertificationDetail(c *gin.Context) {
	userId := utils.FuncUserId(c)
	data, err := new(dbmodels.Certification).QueryByUserId(int64(userId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "认证信息不存在", "", err.Error())
		return
	}
	r := response.UserCertificationDetailRep{
		IdCode:   data.CertificationIdCode,
		RealName: data.CertificationRealName,
	}
	realName := []rune(r.RealName)
	for i := 0; i < len(realName)-1; i++ {
		realName[i] = '*'
	}

	idCard := []byte(r.IdCode)
	// for i := 3; i < len(idCard)-2; i++ {
	//	idCard[i] = '*'
	// }
	r.IdCode = fmt.Sprintf("%s******%s", r.IdCode[:3], r.IdCode[len(idCard)-2:])
	r.RealName = string(realName)
	response.ResponseOk(c, "获取用户认证详情成功", r)
}

// 存储 用户浏览记录
func VisitorSaveLog(c *gin.Context) {
	var (
		err error
	)

	userId := utils.FuncUserId(c)
	paramsJSON := request.OtherUserInfoReq{}
	if err = c.ShouldBind(&paramsJSON); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	if err = services.SaveUserVisitorLog(int64(paramsJSON.UserId), userId, 1); err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	response.ResponseOk(c, "获取访客记录成功", "ok")
	return
}

// 访客记录
func UserVisitorList(c *gin.Context) {
	// c.Set("userID", "1006744305")
	userId := utils.FuncUserId(c)
	paramsJSON := request.BasePageReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	go func() {
		// 重置访问次数
		key := fmt.Sprintf("%s%d", utils.REDIS_USER_NEW_VISITOR_COUNT, userId)
		err = utils.RedisClient.Del(key).Err()
		if err != nil {
			utils.LogErrorF("重置访问次数失败:%s", err.Error())
		}
	}()

	total, data, err := new(dbmodels.AppUserVisitor).QueryPage(userId, paramsJSON.Page, paramsJSON.Size)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	var list []response.UserVisitorListRep
	for _, v := range data {
		list = append(list, response.UserVisitorListRep{
			UserId:     v.SystemUser.UserID,
			Nickname:   v.SystemUser.UserNickname,
			Gender:     v.SystemUser.UserGender,
			Iconurl:    v.SystemUser.UserIconurl,
			Age:        utils.FuncGetAge(int(v.SystemUser.UserBirthday)),
			Time:       v.VisitLastTime,
			VisitTimes: v.VisitTimes,
			VisitType:  v.VisitType,
		})
	}
	r := response.BasePageList{
		Page:       paramsJSON.Page,
		Size:       paramsJSON.Size,
		Total:      total,
		TotalPages: utils.FuncTotalPages(total, paramsJSON.Size),
		List:       list,
	}
	response.ResponseOk(c, "获取访客记录成功", r)
	return
}

// 设置常用游戏顺序
func UserSetGameOrder(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.UserSetGameOrderReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	var temp = make([]string, len(paramsJSON.SkillId))
	for k, v := range paramsJSON.SkillId {
		temp[k] = fmt.Sprintf("%d", v)
	}

	gameOrder := strings.Join(temp, "_")
	err = new(dbmodels.SystemUser).UpdateGameOrder(userId, gameOrder)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "设置失败", "", err.Error())
		return
	}

	user, err := new(dbmodels.SystemUser).UserIdByUser(userId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	go new(redismodels.UserInfoUpdate).UpdateUserInfo(user)

	response.ResponseOk(c, "设置成功", nil)
	return
}

// 查找用户
func UserFind(c *gin.Context) {
	var (
		wallet dbmodels.AppUserWallet
	)

	paramsJSON := request.UserFindReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	_, user, err := new(dbmodels.SystemUser).QueryUserByAccount(paramsJSON.Account)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "未查询到用户", "", "")
		return
	}
	if user.UserStatus >= dbmodels.USER_STATUS_LOCK {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "用户状态异常", "", "")
		return
	}

	// 获取钱包
	if wallet, err = new(dbmodels.AppUserWallet).Query(user.UserID); err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "用户信息异常", "", "")
		return
	}

	r := response.UserFindRep{
		UserId:       user.UserID,
		UserNickname: user.UserNickname,
		UserIconurl:  user.UserIconurl,

		Sex:           user.UserGender,
		UserRegTime:   user.BaseModel.Created,
		Vip:           user.AppUserVipExperience.ExperienceLevel,
		GroupId:       user.UserUnionId,
		Host:          user.UserIsAnchor,
		Partner:       user.UserIsSparring,
		Longitude:     user.UserLongitude,
		Latitude:      user.UserLatitude,
		First:         user.UserIsRecharge,
		FinalQuantity: wallet.WalletTotalOver,
		Balance:       wallet.WalletTotalExtractable,
	}
	response.ResponseOk(c, "查询成功", r)
	return
}

// 获取活体认证地址
func UserLiveAuthenticationUrl(c *gin.Context) {
	userId := utils.FuncUserId(c)
	msg, data, err := services.UserLiveAuthenticationUrl(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}
	response.ResponseOk(c, "获取地址成功", data)
	return
}

// 更新用户坐标
func UserUpdateCoordinate(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var paramsJSON request.UserUpdateCoordinateReq
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	err = services.UserUpdateCoordinate(userId, paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "更新用户坐标失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "更新用户坐标成功", nil)
	return
}
