package rabbitmqProducer

import (
	"fmt"
	"gamers/enum"
	"gamers/models/dbmodels"
	"gamers/utils"
)

// 投递麦位延迟消息
func ProducerCloseRoom(roomId int) {
	room, err := new(dbmodels.AppLiveRoom).QueryRoomId(roomId)
	if err != nil {
		utils.LogErrorF("投递麦位延迟消息失败roomId[%d],err[%s]", roomId, err.Error())
		return
	}

	// 派对房投递延迟队列
	if room.RoomType == dbmodels.ROOM_TYPE_PARTY {
		err = utils.RabbitMQProducerDelayed(utils.RABBITMQ_CLOSE_ROOM, fmt.Sprintf("%d", roomId), enum.ROOM_SYSTEM_CLOSE_PARTY_TIME)
		if err != nil {
			utils.LogErrorF("投递麦位延迟消息失败roomId[%d],err[%s]", roomId, err.Error())

		}
	}
}
