package rabbitmqProducer

import (
	"gamers/utils"
	"strconv"
)

const (
	DEFALUT_INVITE_MESSAGE_CHANGE_TIMEOUT = 60 // 默认一分钟之后发送消息
)

// ProducerInviteMessageUserID 获取撩一撩邀请消息用户id
func ProducerInviteMessageUserID(userID int64) (err error) {
	ids := strconv.Itoa(int(userID)) // id

	err = utils.RabbitMQProducerDelayed(utils.RABBITMOQ_INVITE_MESSAGE, string(ids), DEFALUT_INVITE_MESSAGE_CHANGE_TIMEOUT)
	if err != nil {
		utils.LogErrorF("给用户推送大神撩一撩邀请消息失败userId[%s],err[%s]", ids, err.Error())
		return
	}

	utils.LogInfoF("用户注册后推送撩一撩邀请消息成功")
	return
}
