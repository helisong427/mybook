package rabbitmqProducer

import (
	"encoding/json"
	"gamers/utils"
)

const DEFALUT_IM_STATE_CHANGE_TIMEOUT = 30

type ImStateChange struct {
	Action    string `json:"Action"`      //用户上线或者下线的动作，Login 表示上线（TCP 建立），Logout 表示下线（TCP 断开），Disconnect 表示网络断开（TCP 断开）
	UserIdStr string `json:"user_id_str"` //用户 UserID
	Reason    string `json:"Reason"`      //用户上下线触发的原因：
}

func ProducerImStateChange(userIdStr, action, reason string) {
	data := ImStateChange{
		Action:    action,
		UserIdStr: userIdStr,
		Reason:    reason,
	}
	marshal, err := json.Marshal(data)
	if err != nil {
		utils.LogErrorF("im状态变更消息失败userId[%s],err[%s]", userIdStr, err.Error())
	}
	err = utils.RabbitMQProducerDelayed(utils.RABBITMQ_IM_STATE_CHANGE, string(marshal), DEFALUT_IM_STATE_CHANGE_TIMEOUT)
	if err != nil {
		utils.LogErrorF("im状态变更消息失败userId[%s],err[%s]", userIdStr, err.Error())
	}

}
