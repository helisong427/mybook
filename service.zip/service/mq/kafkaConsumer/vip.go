package kafkaConsumer

import (
	"encoding/json"
	"fmt"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"strconv"
	"strings"

	"github.com/Shopify/sarama"
	"github.com/go-redis/redis"
	jsoniter "github.com/json-iterator/go"
	"gorm.io/gorm"
)

func VipConsumer(message *sarama.ConsumerMessage) {
	fmt.Println(fmt.Sprintf("Received:topic[%s]|partition[%d]|offset[%d]|key[%s]", message.Topic, message.Partition, message.Offset, message.Key))
	var err error
	var form dbmodels.PushUserExperience
	err = jsoniter.Unmarshal(message.Value, &form)
	if err != nil {
		utils.LogErrorF("反序列化收到的原始消息[%s][%s]失败, %s", message.Topic, message.Key, err.Error())
		return
	}
	key := utils.REDIS_USER_VIP_LOCK + strconv.Itoa(int(form.UserId))
	lock, islock := utils.AcquireLock(key, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
	if !islock {
		utils.LogErrorF("vip加锁失败")
		return
	}
	// 释放锁
	defer utils.ReleaseLock(key, lock)
	// 获取用户vip信息
	userInfo, err := new(dbmodels.AppUserVipExperience).GetUserVipLevelByUserId(form.UserId)
	if err != nil {
		utils.LogErrorF("获取用户[%d]vip信息失败, %s", form.UserId, form.Experience, err.Error())
		return
	}
	var setting VipSetting
	param, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_VIP_SETTING)
	if err != nil {
		utils.LogErrorF("获取vip配置失败,err:%s", err.Error())
		return
	}
	err = json.Unmarshal([]byte(param["value"]), &setting)
	if err != nil {
		utils.LogErrorF("获取vip配置失败,err:%s", err.Error())
		return
	}
	maxLevel, err := new(dbmodels.AppUserVipLevel).GetMaxVipLevelByExperience()
	if err != nil {
		utils.LogErrorF("获取最大经验值失败, %s", form.UserId, form.Experience, err.Error())
		return
	}
	newExperience := userInfo.ExperienceValue + form.Experience
	if newExperience >= userInfo.ExperienceNextValue && userInfo.ExperienceLevel < maxLevel.LevelLevel {
		var levelInfo dbmodels.AppUserVipLevel
		levelInfo, err = new(dbmodels.AppUserVipLevel).GetVipLevelByExperience(newExperience)
		if err != nil && err != gorm.ErrRecordNotFound {
			utils.LogErrorF("获取下一等级信息失败,err:%s", err.Error())
		}
		var vipInfo dbmodels.AppUserVipExperience
		if err == nil {
			userInfo.ExperienceLevel = levelInfo.LevelLevel - 1
			userInfo.ExperienceNextValue = levelInfo.LevelMinExperience
			vipInfo, err = new(dbmodels.AppUserVipExperience).UpdateUserExperienceByUserId(form.UserId, form.Experience, userInfo.ExperienceNextValue, userInfo.ExperienceLevel)
			if err != nil {
				utils.LogErrorF("更新用户[%d]vip经验值[%d]失败, %s", form.UserId, form.Experience, err.Error())
				return
			}
		} else {
			vipInfo, err = new(dbmodels.AppUserVipExperience).UpdateUserExperienceByUserId(form.UserId, form.Experience, maxLevel.LevelMinExperience, maxLevel.LevelLevel)
			if err != nil {
				utils.LogErrorF("更新用户[%d]vip经验值[%d]失败, %s", form.UserId, form.Experience, err.Error())
				return
			}
		}
		err = new(redismodels.UserInfo).UpdateUserVipLevel(vipInfo.ExperienceUserId, vipInfo.ExperienceLevel)
		if err != nil {
			utils.LogErrorF("更新用户[%d]vip信息[%d]失败, %s", form.UserId, vipInfo.ExperienceLevel, err.Error())
		}
		if vipInfo.ExperienceLevel >= setting.PushMsgLevel {
			SendVipInfoByAssistant(userInfo.ExperienceUserId, vipInfo.ExperienceLevel, &setting)
		}
	} else if newExperience >= maxLevel.LevelMinExperience {
		_, err = new(dbmodels.AppUserVipExperience).UpdateUserExperienceByUserId(form.UserId, form.Experience, maxLevel.LevelMinExperience, userInfo.ExperienceLevel)
		if err != nil {
			utils.LogErrorF("更新用户[%d]vip经验值[%d]失败, %s", form.UserId, form.Experience, err.Error())
			return
		}
	} else {
		_, err = new(dbmodels.AppUserVipExperience).UpdateUserExperienceByUserId(form.UserId, form.Experience, userInfo.ExperienceNextValue, userInfo.ExperienceLevel)
		if err != nil {
			utils.LogErrorF("更新用户[%d]vip经验值[%d]失败, %s", form.UserId, form.Experience, err.Error())
			return
		}
	}

	return
}

const VIP_LEVEL_UP_KEY = "assistant_vip_level_up"

type VipSetting struct {
	QQ           string `json:"qq"`
	PushMsgLevel int    `json:"push_msg_level"`
	MaxVipLevel  int    `json:"max_vip_level"`
}

func SendVipInfoByAssistant(userId int64, level int, setting *VipSetting) {
	levelStr := strconv.Itoa(level)
	userIdStr := strconv.Itoa(int(userId))
	_, err := utils.RedisClient.HGet(utils.REDIS_VIP_PUSH_INFO, userIdStr).Result()
	if err != nil && err != redis.Nil {
		utils.LogErrorF("获取vip升级缓存【%s】信息失败,err:%s", utils.REDIS_VIP_PUSH_INFO, err.Error())
		return
	}
	if err == nil {
		return
	}
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(VIP_LEVEL_UP_KEY)
	if err != nil {
		utils.LogErrorF("获取VIP升级消息model失败,err:%s", err.Error())
		return
	}

	tip := strings.NewReplacer("${vip_level}", levelStr, "${qq}", setting.QQ).Replace(msgModel.MsgContent)
	skillMsg := &redismodels.AssistantMsg{
		Type: redismodels.MSG_ASSISTANT_TYPE_TEXT,
		Text: tip,
	}
	msg := &redismodels.AppMsg{AssistantMsg: skillMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userIdStr)
	if err != nil {
		utils.LogErrorF("发送vip升级推送失败,err:%s", err.Error())
	}

	err = utils.RedisClient.HSet(utils.REDIS_VIP_PUSH_INFO, userIdStr, levelStr).Err()
	if err != nil {
		utils.LogErrorF("存储vip升级缓存【%s】信息失败,err:%s", utils.REDIS_VIP_PUSH_INFO, err.Error())
		return
	}
	return
}
