package kafkaConsumer

import (
	"github.com/Shopify/sarama"
)

//Log 消费日志
func SendMsg(message *sarama.ConsumerMessage) {

}
