package kafkaConsumer

import (
	"fmt"
	"gamers/models/esmodels"
	"gamers/utils"

	"github.com/Shopify/sarama"
)

//Log 消费日志
func Logger(message *sarama.ConsumerMessage) {
	model := esmodels.ESLogIndex{}
	// fmt.Println(fmt.Sprintf("Received:topic[%s]|partition[%d]|offset[%d]|key[%s]", message.Topic, message.Partition, message.Offset, message.Key))
	//fmt.Println("插入日志文档, message = ", string(message.Value))
	err := model.Create(string(message.Key), string(message.Value))
	if err != nil {
		fmt.Println("插入日志文档失败, err = ", err)
	}
	defer func() {
		if r := recover(); r != nil {
			utils.LogErrorF(r.(string))
		}
	}()
}
