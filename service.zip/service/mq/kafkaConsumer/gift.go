package kafkaConsumer

import (
	"fmt"
	"gamers/controller/services"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"strconv"
	"sync"
	"time"

	"github.com/Shopify/sarama"
	"github.com/go-redis/redis"
	jsoniter "github.com/json-iterator/go"
)

const (
	CONSUMER_GIFT_ACQUIRE_TIMEOUT = 30
	CONSUMER_GIFT_LOCK_TIMEOUT    = 5
)

func GiftConsumer(message *sarama.ConsumerMessage) {
	fmt.Println("开始处理礼物消费者")
	utils.LogInfoF("Received:topic[%s]|partition[%d]|offset[%d]|key[%s]", message.Topic, message.Partition, message.Offset, message.Key)
	var err error
	var form services.SendPropInfoToMq
	err = jsoniter.Unmarshal(message.Value, &form)
	if err != nil {
		utils.LogErrorF("反序列化收到的原始消息[%s][%s]失败, %s", message.Topic, message.Key, err.Error())
		return
	}
	UpdateAnchorIncome(&form)
	// 爱意值
	roomIdStr := strconv.Itoa(int(form.SendPropReq.RoomId))
	// 判断爱意值开关
	loveSwitch, err := utils.RedisClient.HGet(utils.REDIS_LIVE_WHEAT+roomIdStr, "wheat_love_switch").Int()
	if err != nil {
		utils.LogErrorF("获取房间[%s]爱意值开关失败失败,err: %s", roomIdStr, err.Error())
	}
	charm := form.Prop.PropCharm * form.SendPropReq.PropCount
	// wealth := form.Prop.PropWealth * form.SendPropReq.PropCount
	go func() {
		// 更新排行榜（房间内送礼排行[魅力榜]）
		_, err := new(redismodels.RankRoomSendCharm).Init("hourly", time.Unix(form.SendTime, 0), redismodels.RankRoomItemLengthHourly).Update(form.LiveRoom.RoomId, charm)
		if err != nil {
			utils.LogErrorF("更新排行榜（房间内送礼排行[魅力榜]）失败, roomId[%d], err: %s", form.LiveRoom.RoomId, err.Error())
		}
	}()

	// 爱意值开关打开的
	wg := sync.WaitGroup{}
	for _, v := range form.SendPropReq.ReceiverIDS {
		// wg.Add(1)
		if loveSwitch == redismodels.WHEAT_LOVE_SWITCH_OPEN {
			wg.Add(1)
			go AddLoveValue(v, charm, &wg, form.LiveRoom)
		}
		// go UpdateCharmAndWealth(wealth, charm, form.SenderId, v, &wg)
	}
	if form.LiveRoom.RoomPkState == dbmodels.RoomPkStartStage {
		wg.Add(1)
		go CalculatePkValueAndGloryStar(form, &wg)
	}
	wg.Wait()
	return
}

// 更新用户魅力值
func UpdateCharmAndWealth(wealth int64, charm int64, wealthUser, charmUser int64, wg *sync.WaitGroup) {
	defer wg.Done()
	wStr := strconv.Itoa(int(wealthUser))
	cStr := strconv.Itoa(int(charmUser))

	err := utils.RedisClient.HIncrBy(utils.REDIS_USER_INFO+wStr, "UserWealth", wealth).Err()
	if err != nil && err != redis.Nil {
		utils.LogErrorF("连接redis更新用户[%s]的财富值失败，err:%s", wealthUser, err.Error())
		return
	}
	if err == redis.Nil {
		L, err := new(dbmodels.AppAnchorRoomProp).GetGiftsWealthBySendUser(wealthUser)
		if err != nil {
			utils.LogErrorF("查询用户财富值失败，err:%s", err.Error())
			return
		}
		err = utils.RedisClient.HSet(utils.REDIS_USER_INFO+wStr, "UserWealth", L.Wealth).Err()
		if err != nil {
			utils.LogErrorF("连接redis设置用户[%s]的财富值失败，err:%s", wealthUser, err.Error())
			return
		}
	}
	err = utils.RedisClient.HIncrBy(utils.REDIS_USER_INFO+cStr, "UserCharm", charm).Err()
	if err != nil && err != redis.Nil {
		utils.LogErrorF("连接redis更新用户[%s]的魅力值失败，err:%s", wealthUser, err.Error())
		return
	}
	if err == redis.Nil {
		L, err := new(dbmodels.AppAnchorRoomProp).GetGiftsCharmBySendUser(wealthUser)
		if err != nil {
			utils.LogErrorF("查询用户财富值失败，err:%s", err.Error())
			return
		}
		err = utils.RedisClient.HSet(utils.REDIS_USER_INFO+cStr, "UserCharm", L.Charm).Err()
		if err != nil {
			utils.LogErrorF("连接redis设置用户[%s]的魅力值失败，err:%s", wealthUser, err.Error())
			return
		}
	}
	return
}

func AddLoveValue(userId, loveValue int64, wg *sync.WaitGroup, room *dbmodels.AppLiveRoom) {
	defer wg.Done()
	// 如果实在pk模式中，只有在开始阶段才会加爱意值
	if room.RoomPkState == dbmodels.RoomPkReadyStage || room.RoomPkState == dbmodels.RoomPkPunishmentStage {
		return
	}
	roomIdStr := strconv.Itoa(int(room.RoomId))
	userIdStr := strconv.Itoa(int(userId))
	err := utils.RedisClient.HIncrBy(utils.REDIS_LIVE_WHEAT_LOVE+roomIdStr, userIdStr, loveValue).Err()
	if err != nil && err != redis.Nil {
		utils.LogErrorF("连接redis增加用户[%s]的爱意值失败，err:%s", userIdStr, err.Error())
		return
	}
	if err == redis.Nil {
		err = utils.RedisClient.HSet(utils.REDIS_LIVE_WHEAT_LOVE+roomIdStr, userIdStr, loveValue).Err()
		if err != nil {
			utils.LogErrorF("设置房间【%】的用户【%s】爱意值失败,err:%s", roomIdStr, userIdStr, err.Error())
		}
	}
	return
}

// 更新用户收入
func UpdateAnchorIncome(form *services.SendPropInfoToMq) {
	// 背包礼物，增加收益
	// 查询收益分成
	for _, uid := range form.Receivers {
		// 主播收入
		income := uid.UserIncome
		// 增加主播收入
		tx := utils.GEngine.Begin()
		err := new(dbmodels.AppUserWallet).UpdateUserGiftIncome(tx, true, uid.UserInfo.UserId, income)
		if err != nil {
			utils.LogErrorF("增加主播收益失败，err:%s", err.Error())
			tx.Rollback()
			return
		}

		// 公会收人
		now := time.Now().Unix()
		getInputDate, _ := time.ParseInLocation("2006-01-02 15:04:05", "2021-04-05 00:00:00", time.Local)
		// 当前时间大于2021-04-05日 增加公会收入
		if now >= getInputDate.Unix() && uid.UserInfo.UserUnionId != 0 && uid.UnionIncome != 0 {
			err = new(dbmodels.AppUnionWithdrawalBalance).AddAmount(tx, uid.UserInfo.UserUnionId, uid.UnionIncome)
			if err != nil {
				utils.LogErrorF("增加公会收益失败，err:%s", err.Error())
				tx.Rollback()
				return
			}
		}

		err = tx.Commit().Error
		if err != nil {
			utils.LogErrorF("增加主播收益失败，err:%s", err.Error())
			tx.Rollback()
		}
	}
}

func CalculatePkValueAndGloryStar(form services.SendPropInfoToMq, wg *sync.WaitGroup) {
	defer wg.Done()
	// 计算pk值和荣耀之星
	var partStr string
	roomIdStr := strconv.Itoa(int(form.SendPropReq.RoomId))
	pipeline := utils.RedisClient.Pipeline()
	totalWealth := form.SendPropReq.PropCount * form.Prop.PropWealth * int64(len(form.Receivers))
	senderStr := strconv.Itoa(int(form.SenderId))
	err := pipeline.ZIncrBy(utils.RedisRoomPkGloryStar+roomIdStr, float64(totalWealth), senderStr).Err()
	if err != nil {
		utils.LogErrorF("计算pk值和荣耀之星失败, roomId[%d],userId[%d], err: %s", roomIdStr, form.SenderId, err.Error())
		return
	}
	for _, v := range form.Receivers {
		switch v.Position {
		case 1, 2, 3, 4:
			partStr = redismodels.ROOM_PK_DETAIL_RED
		case 5, 6, 7, 8:
			partStr = redismodels.ROOM_PK_DETAIL_BLUE
		}
		// 给主持人送礼不添加pk值
		if v.Position != 0 {
			pipeline.HIncrBy(utils.RedisRoomPkDetail+roomIdStr, partStr, v.AddLoveValue)
		}
	}
	_, err = pipeline.Exec()
	if err != nil {
		utils.LogErrorF("计算pk值和荣耀之星失败, roomId[%d], err: %s", roomIdStr, err.Error())
		return
	}
	return
}
