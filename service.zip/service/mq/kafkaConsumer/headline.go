package kafkaConsumer

import (
	"fmt"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"github.com/Shopify/sarama"
	jsoniter "github.com/json-iterator/go"
	"strconv"
)

func HeadlineConsumer(message *sarama.ConsumerMessage) {
	var err error
	fmt.Println(fmt.Sprintf("Received:topic[%s]|partition[%d]|offset[%d]|key[%s]", message.Topic, message.Partition, message.Offset, message.Key))
	var form redismodels.HeadlineJob
	err = jsoniter.Unmarshal(message.Value, &form)
	if err != nil {
		utils.LogErrorF("反序列化收到的原始消息[%s][%s]失败, %s", message.Topic, message.Key, err.Error())
		return
	}
	switch form.Type {
	case redismodels.HEADLINE_JOB_TYPE_ROOM:
		go PushHeadlineByRoomId(&form.Job, form.LiveRoomId)
	case redismodels.HEADLINE_JOB_TYPE_TAG:
		go PushHeadlineByTagId(&form.Job, form.TagId)
	case redismodels.HEADLINE_JOB_TYPE_ALL:
		go PushHeadlineAll(&form.Job)
	default:
		utils.LogErrorF("解析跑马灯推送任务失败，未知的推送类型:%d", form.Type)
	}
}

// 推送本房间
func PushHeadlineByRoomId(form *redismodels.HeadlineMsg, roomId int64) {
	roomIdStr := strconv.Itoa(int(roomId))
	err := form.SendGroupHeadMsg(roomIdStr)
	if err != nil {
		utils.LogErrorF("发送房间[%s]的跑马灯消息[%v]失败, %s", roomIdStr, form, err.Error())
	}
}

// 推送同标签
func PushHeadlineByTagId(form *redismodels.HeadlineMsg, tagId int64) {
	// 获取同标签id
	ids, err := new(dbmodels.AppLiveRoom).GetRoomIdsByAttrId(tagId)
	if err != nil {
		utils.LogErrorF("获取同标签房间[%d]失败, %s", tagId, err.Error())
	}
	for _, v := range ids {
		go PushHeadlineByRoomId(form, v)
	}
}

// 全部推送
func PushHeadlineAll(form *redismodels.HeadlineMsg) {
	err := form.SendAllHeadMsg()
	if err != nil {
		utils.LogErrorF("推送全局跑马灯消息[%v]失败, %s", form, err.Error())
	}
}
