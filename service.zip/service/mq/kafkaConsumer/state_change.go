package kafkaConsumer

import (
	"encoding/json"
	"fmt"
	"strconv"
	"time"

	"gamers/controller/services"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/mq/rabbitmqProducer"
	"gamers/utils"
	"gamers/utils/ymd"
	"gamers/v2/app/models"

	"github.com/Shopify/sarama"
	"github.com/go-redis/redis"
)

const (
	IM_STATE_CHANGE_ACTION_LOGIN      = "Login"      // 上线
	IM_STATE_CHANGE_ACTION_LOGOUT     = "Logout"     // 下线
	IM_STATE_CHANGE_ACTION_DISCONNECT = "Disconnect" // 网络断开
)

const RegisterTime7days = 60 * 60 * 24 * 7 // 7日注册新用户

type imStateChangeReq struct {
	CallbackCommand string `json:"CallbackCommand"` // 回调命令
	Info            struct {
		Action     string `json:"Action"`     // 用户上线或者下线的动作，Login 表示上线（TCP 建立），Logout 表示下线（TCP 断开），Disconnect 表示网络断开（TCP 断开）
		To_Account string `json:"To_Account"` // 用户 UserID
		Reason     string `json:"Reason"`     // 用户上下线触发的原因：
		// Login 的原因有 Register：App TCP 连接建立
		// Logout 的原因有 Unregister：App 用户注销帐号导致 TCP 断开
		// Disconnect 的原因有 LinkClose：即时通信 IM 检测到 App TCP 连接断开（例如 kill App，客户端发出 TCP 的 FIN 包或 RST 包）；TimeOut：即时通信 IM 检测到 App 心跳包超时，认为 TCP 已断开（例如客户端网络异常断开，未发出 TCP 的 FIN 包或 RST 包，也无法发送心跳包）。心跳超时时间为400秒
		// 各种具体场景触发的回调 Reason 请参考 可能触发该回调的场景
		// 如果用户的上线请求和下线请求同时到来，此时只会触发 Logout + Unregister 回调，不会触发 Login + Register 回调
	} `json:"Info"` // 用户上下线的信息
}

// IM状态变更回调
func IMStateChange(message *sarama.ConsumerMessage) {

	utils.LogInfoF("接收到消息：[%s][%s][%s]", message.Topic, message.Key, string(message.Value))

	callback := imStateChangeReq{}
	err := json.Unmarshal(message.Value, &callback)

	if err != nil {
		utils.LogErrorF("反序列化收到的原始消息[%s][%s]失败, %s", message.Topic, message.Key, err.Error())
		return
	}
	userIdStr := callback.Info.To_Account
	userId, _ := strconv.ParseInt(userIdStr, 10, 64)
	if callback.Info.Action == IM_STATE_CHANGE_ACTION_LOGIN {
		// 上线
		// 更新用户在线状态
		err = new(dbmodels.SystemUser).UpdateOnline(userIdStr, dbmodels.USER_IS_ONLINE_ONLINE)
		if err != nil {
			utils.LogErrorF("更新用户[%s]上线状态失败:%s", userIdStr, err.Error())
			return
		}
		// 更新用户缓存
		_, err = utils.RedisClient.HSet(utils.REDIS_USER_INFO+userIdStr, "UserIsOnline", dbmodels.USER_IS_ONLINE_ONLINE).Result()
		if err != nil {
			utils.LogErrorF("缓存用户[%s]上线状态失败:%s", userIdStr, err.Error())
			return
		}
		// 兼容v2版本用户在线状态
		_, err = models.NewUserModel().UpdateIsLine(userId, dbmodels.USER_IS_ONLINE_ONLINE)
		if err != nil {
			utils.LogErrorF("[v2]缓存用户[%s]上线状态失败:%s", userIdStr, err.Error())
			return
		}

		// 获取用户详情
		userId, _ := strconv.ParseInt(userIdStr, 10, 64)
		userInfo, err := new(dbmodels.SystemUser).QueryById(userId)
		if err != nil {
			utils.LogErrorF("查询用户[%s]详情失败:%s", userIdStr, err.Error())
			return
		}

		// 获取主动推荐系统配置
		activePushConfig, err := getActivePush()
		if err != nil {
			utils.LogErrorF("查询主动推荐系统配置失败:%s", err.Error())
			return
		}

		// 判断用户为大神或者主播
		if userInfo.UserIsSparring == dbmodels.USER_IS_SPARRING_YES || userInfo.UserIsAnchor == dbmodels.USER_IS_ANCHOR_YES {

			setting, err := new(dbmodels.SystemUserPrivacySetting).GetPrivacySetting(userId)
			if err != nil {
				utils.LogErrorF("查询用户隐私[%s]详情失败:%s", userIdStr, err.Error())
				return
			}
			if setting.UserOnlineMessagePush == 0 {
				_ = utils.RedisClient.SAdd(utils.Redis_Active_Push_Sparring_Set, userInfo.UserID)

				result, _ := utils.RedisClient.Exists(fmt.Sprintf("%s%d", utils.Redis_Active_Push_Sparring, userId)).Result()
				// 不存在
				if result == 0 {
					utils.RedisClient.HMSet(fmt.Sprintf("%s%d", utils.Redis_Active_Push_Sparring, userId), map[string]interface{}{
						redismodels.SparringReceiveCount: 0,
					})
					conf := utils.Config.App.Env
					if conf != "prod" {
						utils.RedisClient.Do("EXPIRE", fmt.Sprintf("%s%d", utils.Redis_Active_Push_Sparring, userId), 60*60*5)
					} else {
						utils.RedisClient.Do("EXPIRE", fmt.Sprintf("%s%d", utils.Redis_Active_Push_Sparring, userId), ymd.GetNow2Today24TimeStamp())
					}
				}
			}
		} else { // 普通用户

			if userInfo.BaseModel.Created+RegisterTime7days < time.Now().Unix() {
				return
			}

			result, _ := utils.RedisClient.Exists(fmt.Sprintf("%s%d", utils.Redis_Active_Push_User, userId)).Result()
			// 不存在
			if result == 0 {
				utils.RedisClient.HMSet(fmt.Sprintf("%s%d", utils.Redis_Active_Push_User, userId), map[string]interface{}{
					redismodels.UserLoginLimit: 0,
					redismodels.CDTime:         0,
				})
				conf := utils.Config.App.Env
				if conf != "prod" {
					utils.RedisClient.Do("EXPIRE", fmt.Sprintf("%s%d", utils.Redis_Active_Push_User, userId), 60*60*5)
				} else {
					utils.RedisClient.Do("EXPIRE", fmt.Sprintf("%s%d", utils.Redis_Active_Push_User, userId), ymd.GetNow2Today24TimeStamp())
				}
			}

			userResult, err := utils.RedisClient.HGetAll(fmt.Sprintf("%s%d", utils.Redis_Active_Push_User, userId)).Result()
			if err != nil && err != redis.Nil {
				return
			}

			cdTime, _ := strconv.Atoi(userResult[redismodels.CDTime])
			loginLimit, _ := strconv.Atoi(userResult[redismodels.UserLoginLimit])
			// 推送时间未冷却 或者 登录次数超过配置
			if (time.Now().Unix()-int64(activePushConfig.CDTime)*60 < int64(cdTime)) || loginLimit >= activePushConfig.UserLoginLimit {
				return
			} else {
				// 获取推荐大神userId
				sparringUserId := getActivePushSparringUserId(userId, activePushConfig.SparringCount, activePushConfig.SparringReceiveCount)
				if len(sparringUserId) == 0 {
					return
				}
				err := new(services.LiaoyiLiaoActivePush).MsgSend(userInfo, redismodels.MSG_ADMIN_USER_SUPERMASTER, sparringUserId)
				if err != nil {
					utils.LogErrorF("发送主动推荐消息失败:%s", err.Error())
					return
				}
				_ = dealWithUserAndSparring(sparringUserId, userId)
			}
		}
	} else {
		rabbitmqProducer.ProducerImStateChange(userIdStr, callback.Info.Action, callback.Info.Reason)
	}

	// 更新用户第一次登录
	err = new(dbmodels.SystemUser).UpdateFirstLogin(userIdStr, dbmodels.USER_NOT_FIRST_LOGIN)
	if err != nil {
		utils.LogErrorF("更新用户[%s]上线状态失败:%s", userIdStr, err.Error())
		return
	}
	return
}

// 获取主动推荐系统配置
func getActivePush() (activePushConfig redismodels.LiaoYiLiaoActivePush, err error) {
	param, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PARAM_KEY_LIAOYILIAO_CONFIG)
	if err != nil {
		utils.LogErrorF("查询撩一撩主动推送配置详情失败:%s", err.Error())
		return
	}
	activePushConfig = redismodels.LiaoYiLiaoActivePush{}
	_ = json.Unmarshal([]byte(param["value"]), &activePushConfig)
	return
}

// 发送完成后 处理用户大神key
func dealWithUserAndSparring(sparringUserId []string, userId int64) (err error) {
	pipeline := utils.RedisClient.Pipeline()
	for _, v := range sparringUserId {
		_ = pipeline.HIncrBy(fmt.Sprintf("%s%s", utils.Redis_Active_Push_Sparring, v), redismodels.SparringReceiveCount, 1)
	}
	pipeline.HIncrBy(fmt.Sprintf("%s%d", utils.Redis_Active_Push_User, userId), redismodels.UserLoginLimit, 1)
	pipeline.HSet(fmt.Sprintf("%s%d", utils.Redis_Active_Push_User, userId), redismodels.CDTime, time.Now().Unix())
	if _, err := pipeline.Exec(); err != nil {
		utils.LogErrorF("主动推送修改用户大神推送次数缓存错误:%s", err.Error())
		return err
	}
	return
}

// 获取推荐大神userId集合
func getActivePushSparringUserId(userId int64, SparringCount, receiveCount int) (data []string) {
	sparringResult, err := utils.RedisClient.SMembersMap(utils.Redis_Active_Push_Sparring_Set).Result()
	if err != nil {
		utils.LogErrorF("获取符合条件大神集合失败:%s", err.Error())
		return
	}
	var count int
	for k, _ := range sparringResult {
		if count == SparringCount {
			break
		}
		// 不能给自己推荐
		if k == strconv.Itoa(int(userId)) {
			continue
		}
		receiveNum, err := utils.RedisClient.HGet(fmt.Sprintf("%s%s", utils.Redis_Active_Push_Sparring, k), redismodels.SparringReceiveCount).Int()
		if err != nil {
			utils.LogErrorF("获取主动推荐大神详情失败:%s", err.Error())
			continue
		}
		if receiveNum < receiveCount {
			data = append(data, k)
			count += 1
		}
	}
	return
}
