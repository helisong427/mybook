package rabbitmqConsumer

import (
	"gamers/controller/services"
	"gamers/enum"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"strconv"
	"time"

	"github.com/go-redis/redis"
	"github.com/streadway/amqp"
)

// 关闭房间
// 此延迟队列用于,直播房间主麦位无用户时,延迟一段时间关闭麦位
func CloseRoom(d amqp.Delivery) {
	defer d.Ack(true)
	body := string(d.Body)
	utils.LogInfoF("[延迟关闭房间]接收到消息：[%s]", body)
	roomId, err := strconv.Atoi(body)
	if err != nil {
		utils.LogErrorF("[延迟关闭房间]转换数据类型失败[%d]失败,%s", roomId, err.Error())
		return
	}

	// 查询房间
	room, err := new(dbmodels.AppLiveRoom).QueryRoomId(roomId)
	if err != nil {
		utils.LogErrorF("[延迟关闭房间]获取房间详情失败[%d],%s", roomId, err.Error())
		return
	}

	// 查询麦位
	detail, err := new(redismodels.Wheat).QueryWheatDetail(roomId)
	if err != nil {
		utils.LogErrorF("[延迟关闭房间]获取麦位详情失败[%d],%s", roomId, err.Error())
		return
	}
	wheat := detail.WheatObj[redismodels.WHEAT_HOME_KEY]
	t := time.Now().Unix() - enum.ROOM_SYSTEM_CLOSE_PARTY_TIME

	// 10分钟之前下麦，关闭房间
	if wheat.UserId == 0 && wheat.UpdateTime <= t && room.RoomStatus == dbmodels.ROOM_STATUS_OK && room.RoomType == dbmodels.ROOM_TYPE_PARTY {
		tx := utils.GEngine.Begin()
		update := make(map[string]interface{})
		update["room_live_status"] = dbmodels.ROOM_LIVE_STATUS_OFF
		update["room_status"] = dbmodels.ROOM_STATUS_TIME_OUT_OFF
		update["room_pk_state"] = dbmodels.RoomPkCloseStage
		update["room_pk_record_id"] = 0
		err = new(dbmodels.AppLiveRoom).UpdateByTranslation(tx, int64(roomId), update)
		if err != nil {
			utils.LogErrorF("[延迟关闭房间]状态更新失败[%d],%s", roomId, err.Error())
			return
		}
		logModel := dbmodels.AppRoomCloseLog{
			LogRoomId:    int64(roomId),
			LogType:      dbmodels.CLOSE_LOG_TYPE_TIMEOUT_CLOSE,
			LogRemark:    "超时关闭派对房间",
			LogStartTime: time.Now().Unix(),
		}
		err = logModel.Create(tx)
		if err != nil {
			utils.LogErrorF("[延迟关闭房间]日志创建失败[%d],%s", roomId, err.Error())
			return
		}
		err = tx.Commit().Error
		if err != nil {
			utils.LogErrorF("关闭房间失败[%d],%s", room.RoomId, err.Error())
			return
		}
		_, err = new(redismodels.Wheat).SwitchWheatLove(int(room.RoomId), room.RoomUserId, redismodels.WHEAT_SWITCH_OFF, false)
		if err != nil && err != redismodels.ErrWheatCantOpenLove {
			utils.LogErrorF("关闭房间时，关闭爱意值失败,err:%s", err.Error())
		}
		// 清除房间内的人员
		err = utils.RedisClient.Del(utils.REDIS_LIVE_ONLINE_MEMBER + body).Err()
		if err != nil {
			utils.LogErrorF("移除房间[%s]在线人员失败, %s", body, err.Error())
		}
		// 在线人员更新为0
		err = utils.RedisClient.Del(utils.REDIS_LIVE_ONLINE_MEMBER_NUM + body).Err()
		if err != nil && err != redis.Nil {
			utils.LogErrorF("更新用户在线人员失败, %s,  %v", body, err.Error())
		}
		// 删除热度
		go redismodels.NewRoomHeat().Delete(int(room.RoomId))
		// 禁止排行
		go func() {
			_, _ = new(redismodels.RankRoomSendCharm).Init("hourly", time.Now(), redismodels.RankRoomItemLengthHourly).Ban(room.RoomId)
		}()
		liveMsg := services.InitLiveMsg()
		// 发送消息
		go liveMsg.AnnounceStudioCloseAndOpen(&room, true)
	}
}
