package rabbitmqConsumer

import (
	"encoding/json"
	"fmt"
	"gamers/controller/services"
	"gamers/enum"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/mq/rabbitmqProducer"
	"gamers/utils"
	"gamers/utils/tencent/tencentIm"
	"gamers/v2/app/models"
	"strconv"
	"time"

	"github.com/streadway/amqp"
)

const (
	IM_STATE_CHANGE_ACTION_LOGIN      = "Login"      // 上线
	IM_STATE_CHANGE_ACTION_LOGOUT     = "Logout"     // 下线
	IM_STATE_CHANGE_ACTION_DISCONNECT = "Disconnect" // 网络断开
)

type JoinInfo struct {
	*redismodels.MsgUserObj
	JoinT int64 `json:"join_t"`
}

func IMStateChange(d amqp.Delivery) {
	defer d.Ack(true)
	var form rabbitmqProducer.ImStateChange
	err := json.Unmarshal(d.Body, &form)
	if err != nil {
		utils.LogErrorF("im解析[%s]失败,%s", string(d.Body), err.Error())
		return
	}
	// userId
	userId, err := strconv.Atoi(form.UserIdStr)
	if err != nil {
		utils.LogErrorF("im解析用户id[%s]失败,%s", form.UserIdStr, err.Error())
		return
	}
	status, err := tencentIm.QueryOneState(int64(userId))
	if err != nil {
		utils.LogErrorF("im查询用户[%s]状态失败,%s", form.UserIdStr, err.Error())
		return
	}

	// 查询用户加入的房间
	key := fmt.Sprintf("%s%s", utils.REDIS_LIVE_JOIN_USER, form.UserIdStr)
	roomIdStr := utils.RedisClient.Get(key).Val()
	// 当前用户状态如果是离线状态,则直接下线
	if status != enum.USER_IM_STATUS_ONLINE {
		err = new(dbmodels.SystemUser).UpdateOnline(form.UserIdStr, dbmodels.USER_IS_ONLINE_OFFLINE)
		if err != nil {
			utils.LogErrorF("更新用户[%s]离线状态失败:%s", form.UserIdStr, err.Error())
		}
		// 更新用户缓存
		_, err = utils.RedisClient.HSet(utils.REDIS_USER_INFO+form.UserIdStr, "UserIsOnline", dbmodels.USER_IS_ONLINE_OFFLINE).Result()
		if err != nil {
			utils.LogErrorF("缓存用户[%s]下线状态失败:%s", form.UserIdStr, err.Error())
		}
		if roomIdStr != "" {
			// 离开之后麦位处理
			services.AfterExitWheat(form.UserIdStr, roomIdStr)
		}

		// 不用每次查询db 这也可以直接删缓存 如果用户不在set 报错忽略
		_ = utils.RedisClient.SRem(utils.Redis_Active_Push_Sparring_Set, userId)

		// 兼容v2版本用户下线状态
		_, err = models.NewUserModel().UpdateIsLine(int64(userId), dbmodels.USER_IS_ONLINE_OFFLINE)
		if err != nil {
			utils.LogErrorF("[v2]缓存用户[%s]下线状态失败:%s", userId, err.Error())
			return
		}
		return
	}
	if roomIdStr == "" {
		// 离开之后麦位处理
		return
	}
	var joinInfo JoinInfo
	err = utils.RedisClient.HGet(utils.REDIS_LIVE_ONLINE_MEMBER+roomIdStr, form.UserIdStr).Scan(&joinInfo)
	if err != nil {
		return
	}
	// 判断加入时间是否大于5分钟
	if joinInfo.JoinT+rabbitmqProducer.DEFALUT_IM_STATE_CHANGE_TIMEOUT >= time.Now().Unix() {
		services.AfterExitWheat(form.UserIdStr, roomIdStr)
	}
	return

}
