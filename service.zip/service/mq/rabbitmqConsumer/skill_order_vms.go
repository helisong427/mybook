package rabbitmqConsumer

import (
	"gamers/models/dbmodels"
	"gamers/utils"
	"gamers/utils/tencent/vms"
	"strconv"

	"fmt"

	"github.com/streadway/amqp"
)

const SKILL_ORDER_MAX_TIMES = 10

// 处理语音提示消费者
func SkillOrderVmsHandler(d amqp.Delivery) {
	defer d.Ack(true)
	orderId, _ := strconv.Atoi(string(d.Body))
	// 查询订单详情
	_, order, err := new(dbmodels.AppSkillOrder).QueryByOrderId(int64(orderId))
	if err != nil {
		utils.LogErrorF("[处理订单语音提示]查询订单失败:[orderId = %d],[err = %s]", orderId, err.Error())
		return
	}
	if order.OrderStatus != dbmodels.SKILL_ORDER_STATUS_CONFIRM {
		utils.LogInfoF("[处理订单语音提示]当前订单状态已过期:[orderId = %d],[status = %d],[order_confirm_status = %d]", orderId, order.OrderStatus, order.OrderConfirmStatus)
		return
	}
	if order.OrderConfirmStatus != dbmodels.SKILL_ORDER_CONFIRM_STATUS_NO {
		utils.LogInfoF("[处理订单语音提示]当前订单状态已过期:[orderId = %d],[status = %d],[order_confirm_status = %d]", orderId, order.OrderStatus, order.OrderConfirmStatus)
		return
	}

	key := fmt.Sprintf("%s%d", utils.REDIS_SKILL_ORDER_VMS, order.OrderSellUserId)
	sendCount, _ := utils.RedisClient.Get(key).Int()
	if sendCount > SKILL_ORDER_MAX_TIMES {
		utils.LogInfoF("[处理订单语音提示]当前用户已超过单日最大发送上限:[sellerId = %d]", order.OrderSellUserId)
		return
	}
	// 查询卖家信息
	userInfo, err := new(dbmodels.SystemUser).UserIdByUser(order.OrderSellUserId)
	if err != nil {
		utils.LogErrorF("[处理订单语音提示]查询卖家信息失败:[sellerId = %d],[err = %s]", order.OrderSellUserId, err.Error())
		return
	}
	var modelId string
	modelParam, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PARAM_KEY_VMS_SKILL_ORDER_MODEL_ID)
	if err != nil {
		utils.LogErrorF("[处理订单语音提示]查询语音模板信息失败:[err = %s]", err.Error())
		return
	}
	if modelParam["value"] != "" {
		modelId = modelParam["value"]
	}
	_, err = vms.SendModelMsg(modelId, userInfo.UserMobile, []string{})
	if err != nil {
		utils.LogErrorF("[处理订单语音提示]发送语音信息失败:[err = %s]", err.Error())
		return
	}
	err = utils.RedisClient.Incr(key).Err()
	if err != nil {
		utils.LogErrorF("[处理订单语音提示]记录用户发送次数失败:[err = %s]", err.Error())
		return
	}
	err = utils.RedisClient.Expire(key, utils.GetExpiredByDay()).Err()
	if err != nil {
		utils.LogErrorF("[处理订单语音提示]记录用户发送次数失败:[err = %s]", err.Error())
		return
	}
	return
}
