package rabbitmqConsumer

import (
	"encoding/json"
	"errors"
	"fmt"
	"gamers/controller/services"
	"gamers/models/dbmodels"
	"gamers/mq/rabbitmqProducer"
	"gamers/utils"
	"strconv"
	"time"

	"github.com/streadway/amqp"
	"gorm.io/gorm"
)

// 处理订单
func SkillOrderHandle(d amqp.Delivery) {
	defer d.Ack(true)
	a := rabbitmqProducer.AmqpSkillOrderConsumer{}
	err := json.Unmarshal(d.Body, &a)
	if err != nil {
		utils.LogErrorF("订单解析[%s]失败,%s", string(d.Body), err.Error())
		return
	}
	utils.LogInfoF("接收到订单[%d],订单状态[%d]", a.OrderId, a.OrderStatus)
	lock := fmt.Sprintf("%s%d", utils.REDIS_USER_WALLET_LOCK, a.OrderId)
	lockVal, lockBool := utils.AcquireLock(lock, 2, 1)
	if !lockBool {
		utils.LogErrorF("订单加锁[%d]失败", a.OrderId)
		return
	}
	defer utils.ReleaseLock(lock, lockVal)

	err = systemSkillOrderHandle(a.OrderId, a.OrderStatus)
	if err != nil {
		utils.LogErrorF("系统自动处理订单失败:%s", err.Error())
	}
	return
}

// 处理申述订单
func SkillOrderAppealHandler(d amqp.Delivery) {
	defer d.Ack(true)
	orderId, _ := strconv.Atoi(string(d.Body))
	lock := fmt.Sprintf("%s%d", utils.REDIS_USER_WALLET_LOCK, orderId)
	lockVal, lockBool := utils.AcquireLock(lock, 2, 1)
	if !lockBool {
		utils.LogErrorF("[处理申述订单]订单加锁失败:%d", orderId)
		return
	}
	defer utils.ReleaseLock(lock, lockVal)

	// 查询订单详情
	_, data, err := new(dbmodels.AppSkillOrder).QueryByOrderId(int64(orderId))
	if err != nil {
		utils.LogErrorF("[处理申述订单]查询订单失败:[orderId = %d],[err = %s]", orderId, err.Error())
		return
	}
	// 如果大神未举证
	if data.OrderAppealStatus == dbmodels.SKILL_ORDER_APPEAL_STATUS_ING {
		order := services.NewSkillOrder()
		err = order.Appeal.TimeOutSystem(&data)
		if err != nil {
			utils.LogErrorF("[处理申述订单]更新订单失败:[orderId = %d],[err = %s]", orderId, err.Error())
			return
		}
	} else {
		utils.LogErrorF("[处理申述订单]查询订单失败:[orderId = %d],[OrderAppealStatus = %d]", orderId, data.OrderAppealStatus)
		return
	}
}

// 系统处理订单
func systemSkillOrderHandle(orderId int64, orderStatus int) (err error) {
	now := time.Now().Unix()
	row, order, err := new(dbmodels.AppSkillOrder).QueryByOrderId(orderId)
	if err != nil && err != gorm.ErrRecordNotFound {
		err = errors.New(fmt.Sprintf("订单不存在,order_id = %d", orderId))
		return
	}
	if row == 1 {
		orderServices := services.NewSkillOrder()
		// 未接单
		if order.OrderStatus == dbmodels.SKILL_ORDER_STATUS_CONFIRM && orderStatus == dbmodels.SKILL_ORDER_STATUS_CONFIRM && order.OrderConfirmStatus == dbmodels.SKILL_ORDER_CONFIRM_STATUS_NO {
			err = orderServices.Confirm.System(order)
			if err != nil {
				err = errors.New(fmt.Sprintf("取消未接单的订单[%d]失败,%s", orderId, err.Error()))
				return
			}
		}

		// 完成订单
		if (now >= (order.OrderConfirmTime+order.OrderTime+dbmodels.SKILL_ORDER_CONFIRM_TIME) && order.OrderStatus == dbmodels.SKILL_ORDER_STATUS_CONFIRM && orderStatus == dbmodels.SKILL_ORDER_STATUS_CONFIRM && order.OrderConfirmStatus == dbmodels.SKILL_ORDER_CONFIRM_STATUS_ACCEPT) ||
			(order.OrderStatus == dbmodels.SKILL_ORDER_STATUS_REFUND && orderStatus == dbmodels.SKILL_ORDER_STATUS_REFUND && order.OrderRefundCount == dbmodels.SKILL_ORDER_REFUND_STATUS_SPARRING_REFUSE) ||
			(now >= (order.OrderConfirmTime+order.OrderTime+dbmodels.SKILL_ORDER_CONFIRM_TIME) && order.OrderStatus == dbmodels.SKILL_ORDER_STATUS_CONFIRM && orderStatus == dbmodels.SKILL_ORDER_STATUS_CONFIRM && order.OrderConfirmStatus == dbmodels.SKILL_ORDER_CONFIRM_STATUS_FINISH) {
			err = orderServices.Finish.System(orderId)
			if err != nil {
				err = errors.New(fmt.Sprintf("完成订单失败[%d]失败,%s", orderId, err.Error()))
				return
			}
		}

		// 自动退款
		if (order.OrderStatus == dbmodels.SKILL_ORDER_STATUS_CANCEL && orderStatus == dbmodels.SKILL_ORDER_STATUS_CANCEL) || (order.OrderStatus == dbmodels.SKILL_ORDER_STATUS_REFUND && orderStatus == dbmodels.SKILL_ORDER_STATUS_REFUND && order.OrderRefundStatus == dbmodels.SKILL_ORDER_REFUND_STATUS_REFUNDING) {
			err = orderServices.Refund.System(order)
			if err != nil {
				err = errors.New(fmt.Sprintf("退款订单失败[%d]失败,%s", orderId, err.Error()))
				return
			}
		}
		// 拒绝退款自动恢复
		if order.OrderStatus == dbmodels.SKILL_ORDER_STATUS_REFUND && orderStatus == dbmodels.SKILL_ORDER_STATUS_REFUND && order.OrderRefundStatus == dbmodels.SKILL_ORDER_REFUND_STATUS_SPARRING_REFUSE {
			err = orderServices.Refund.SystemRecover(order)
			if err != nil {
				err = errors.New(fmt.Sprintf("恢复退款订单失败[%d]失败,%s", orderId, err.Error()))
				return
			}
		}
		// 结算
		if order.OrderStatus == dbmodels.SKILL_ORDER_STATUS_FINISH && orderStatus == dbmodels.SKILL_ORDER_STATUS_FINISH {
			err = orderServices.Settle.System(order)
			if err != nil {
				err = errors.New(fmt.Sprintf("结算订单失败[%d]失败,%s", orderId, err.Error()))
				return
			}
		}
	}
	return
}
