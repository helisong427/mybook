/**
 * @Author: 陈建君
 * @Date: 2021/4/8 10:45 上午
 * @Description: TODO:描述
 */

package shanyan

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/hmac"
	"crypto/md5"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io/ioutil"
	"net/http"
	"net/url"
	"sort"

	"gamers/utils"
)

type ClientType uint8

const (
	CTAndroid  ClientType = 1
	CTIos      ClientType = 2
	respOkCode string     = "200000"
)

type (
	SdkWarp struct{}
)

// 通过token获取手机号
func (m SdkWarp) QueryPhone(clientType ClientType, token string) (phone string, err error) {
	// 应用AppId, 应用AppKey
	appId, appKey, queryUrl, _, err := m.getSdkParam(clientType)
	if err != nil {
		return
	}

	formData := url.Values{}
	formData.Set("appId", appId)
	formData.Set("token", token)
	formData.Set("sign", m.signParam(map[string]string{
		"appId": appId,
		"token": token,
	}, appKey))

	mapResult, err := m.httpRequest(queryUrl, formData)
	if err != nil {
		return
	}
	if mapResult["code"] == respOkCode {
		data := (mapResult["data"]).(map[string]interface{})
		phone = m.decryptPhone(data["mobileName"].(string), appKey)
	} else {
		err = errors.New(mapResult["message"].(string))
	}

	return
}

// 通过token和手机号来验证合法性
func (m SdkWarp) ValidatePhone(clientType ClientType, mobile, token string) (isOk bool, err error) {
	// 应用AppId, 应用AppKey
	appId, appKey, _, queryUrl, err := m.getSdkParam(clientType)
	if err != nil {
		return
	}

	formData := url.Values{}
	formData.Set("appId", appId)
	formData.Set("token", token)
	formData.Set("mobile", mobile)
	formData.Set("sign", m.signParam(map[string]string{
		"appId":  appId,
		"token":  token,
		"mobile": mobile,
	}, appKey))

	mapResult, err := m.httpRequest(queryUrl, formData)
	if err != nil {
		return
	}
	if mapResult["code"] == "200000" {
		data := (mapResult["data"]).(map[string]interface{})
		// tradeNo := data["tradeNo"].(string)  // 流水号
		isVerify := data["isVerify"].(string)
		if "1" == isVerify {
			isOk = true
		} else {
			isOk = false
		}
	} else {
		err = errors.New(mapResult["message"].(string))
	}

	return
}

func (m SdkWarp) httpRequest(queryUrl string, formData url.Values) (mapResult map[string]interface{}, err error) {
	resp, err := http.PostForm(queryUrl, formData)
	if err != nil {
		return
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return
	}
	respBody := string(body)
	if err = json.Unmarshal([]byte(respBody), &mapResult); err != nil {
		return
	}

	return
}

func (m SdkWarp) pKCS5UnPadding(encrypt []byte) []byte {
	padding := encrypt[len(encrypt)-1]
	return encrypt[:len(encrypt)-int(padding)]
}

// 根据客户端类型获取sdk参数
func (m SdkWarp) getSdkParam(clientType ClientType) (appId, appKey, queryUrl, validateUrl string, err error) {
	switch clientType {
	case CTAndroid:
		appId = utils.Config.Android.ShanyanAppID
		appKey = utils.Config.Android.ShanyanAppKey
		queryUrl = utils.Config.Android.ShanyanQuery
		validateUrl = utils.Config.Android.ShanyanValidate
	case CTIos:
		appId = utils.Config.Ios.ShanyanAppID
		appKey = utils.Config.Ios.ShanyanAppKey
		queryUrl = utils.Config.Ios.ShanyanQuery
		validateUrl = utils.Config.Ios.ShanyanValidate
	default:
		err = errors.New("未知的客户端类型")
	}
	return
}

// 参数签名
func (m SdkWarp) signParam(params map[string]string, secret string) string {
	ps := make([]string, 0, len(params))
	for key := range params {
		ps = append(ps, key)
	}
	sort.Strings(ps)

	// 组装排序以后的参数字符串
	paramStr := bytes.Buffer{}
	for i := range ps {
		paramStr.WriteString(ps[i])
		paramStr.WriteString(params[ps[i]])
	}

	mac := hmac.New(sha256.New, []byte(secret))
	_, _ = mac.Write(paramStr.Bytes())
	return hex.EncodeToString(mac.Sum(nil))
}

// 解码手机号
func (m SdkWarp) decryptPhone(data string, key string) string {
	hash := md5.Sum([]byte(key))
	hashString := hex.EncodeToString(hash[:])
	block, _ := aes.NewCipher([]byte(hashString[:16]))
	ecb := cipher.NewCBCDecrypter(block, []byte(hashString[16:]))
	source, _ := hex.DecodeString(data)
	decrypted := make([]byte, len(source))
	ecb.CryptBlocks(decrypted, source)
	return string(m.pKCS5UnPadding(decrypted))
}
