package sms

import (
	"encoding/json"

	"github.com/guonaihong/gout"

	"gamers/utils"
)

const (
	SMS_CODE = "亲爱的用户，您的短信验证码为{$var}，{$var}分钟内有效，若非本人操作请忽略。"

	SMS_Warning = "GOGO语音充值异常提示：用户ID：{$var}，充值订单编号：{$var}，充值金额：{$var}，发起充值时间：{$var}" // 充值预警
)

type SmsCodeRequest struct {
	Account  string `json:"account"`  // 创蓝API账号
	Password string `json:"password"` // 创蓝API密码
	Msg      string `json:"msg"`      // 短信内容
	Params   string `json:"params"`   // 手机号码
	Report   string `json:"report"`   // 是否需要状态报告
}

type SmsModelMsgRequest struct {
	Account  string `json:"account"`  // 创蓝API账号
	Password string `json:"password"` // 创蓝API密码
	Msg      string `json:"msg"`      // 短信内容
	Phone    string `json:"phone"`    // 手机号码
	Report   string `json:"report"`   // 是否需要状态报告
}

type SmsCodeResponse struct {
	Time       string `json:"time"`       // 响应时间
	SuccessNum string `json:"successNum"` // 成功条数
	Msgid      string `json:"msgid"`      // 消息id
	ErrorMsg   string `json:"errorMsg"`   // 状态码说明（成功返回值）
	Code       string `json:"code"`       // 状态码（返回0为成功，失败的返回值请查看“验证码通知和营销短信提交响应状态码”
}

// SendSms 发送短信 smsType:1通知类,2验证码,3营销类  msgParams="手机号1,参数1,参数2;手机号2,参数1,参数2"
func SendSms(smsType int, msgContent string, msgParams string) {
	var apiUrl string
	request := SmsCodeRequest{
		Params:   msgParams,
		Account:  utils.Config.Sms.ChuangLanTongZhiAccount,
		Password: utils.Config.Sms.ChuangLanTongZhiPassword,
		Msg:      msgContent,
		Report:   "true",
	}
	apiUrl = utils.Config.Sms.ChuangLanTongZhiUrl
	if smsType == 2 {
		request.Account = utils.Config.Sms.ChuangLanyanZhengMaAccount
		request.Password = utils.Config.Sms.ChuangLanyanZhengMaPassword
		apiUrl = utils.Config.Sms.ChuangLanyanZhengMaUrl
	} else if smsType == 3 {
		request.Account = utils.Config.Sms.ChuangLanYingXiaoAccount
		request.Password = utils.Config.Sms.ChuangLanYingXiaoPassword
		apiUrl = utils.Config.Sms.ChuangLanYingXiaoUrl
	}
	response := SmsCodeResponse{}
	err := gout.POST(apiUrl).SetJSON(&request).BindJSON(&response).Do()
	if err != nil {
		utils.LogErrorF("发送短信失败:%s", err.Error())
		return
	}
	if response.Code != "0" {
		marshal, _ := json.Marshal(response)
		utils.LogErrorF("发送短信失败:%s", marshal)
		return
	}
}

func SendModelSms(smsType int, msgContent string, phone string) {
	var apiUrl string
	request := SmsModelMsgRequest{
		Phone:    phone,
		Account:  utils.Config.Sms.ChuangLanTongZhiAccount,
		Password: utils.Config.Sms.ChuangLanTongZhiPassword,
		Msg:      msgContent,
		Report:   "true",
	}
	apiUrl = utils.Config.Sms.ChuangLanTongZhiModelUrl
	if smsType == 2 {
		request.Account = utils.Config.Sms.ChuangLanyanZhengMaAccount
		request.Password = utils.Config.Sms.ChuangLanyanZhengMaPassword
		apiUrl = utils.Config.Sms.ChuangLanyanZhengMaModelUrl
	} else if smsType == 3 {
		request.Account = utils.Config.Sms.ChuangLanYingXiaoAccount
		request.Password = utils.Config.Sms.ChuangLanYingXiaoPassword
		apiUrl = utils.Config.Sms.ChuangLanYingXiaoModelUrl
	}
	response := SmsCodeResponse{}
	err := gout.POST(apiUrl).SetJSON(&request).BindJSON(&response).Do()
	if err != nil {
		utils.LogErrorF("发送短信失败:%s", err.Error())
		return
	}
	if response.Code != "0" {
		marshal, _ := json.Marshal(response)
		utils.LogErrorF("发送短信失败:%s", marshal)
		return
	}
}

// //SendSms 发送短信 smsType:1通知类,2验证码,3营销类  msgParams="手机号1,参数1,参数2;手机号2,参数1,参数2"
// func SendSms(smsType int, msgContent string, msgParams string) bool {
//	var apiUrl string
//	params := make(map[string]interface{})
//	params["params"] = msgParams                                   //手机号码,参数
//	params["account"] = utils.Config.Sms.ChuangLanTongZhiAccount   //创蓝API账号
//	params["password"] = utils.Config.Sms.ChuangLanTongZhiPassword //创蓝API密码
//	apiUrl = utils.Config.Sms.ChuangLanTongZhiUrl                  //短信发送URL
//	if smsType == 2 {
//		params["account"] = utils.Config.Sms.ChuangLanyanZhengMaAccount
//		params["password"] = utils.Config.Sms.ChuangLanyanZhengMaPassword
//		apiUrl = utils.Config.Sms.ChuangLanyanZhengMaUrl
//	} else if smsType == 3 {
//		params["account"] = utils.Config.Sms.ChuangLanYingXiaoAccount
//		params["password"] = utils.Config.Sms.ChuangLanYingXiaoPassword
//		apiUrl = utils.Config.Sms.ChuangLanYingXiaoUrl
//	}
//
//	//设置您要发送的内容：其中“【】”中括号为运营商签名符号，多签名内容前置添加提交
//	params["msg"] = msgContent
//	params["report"] = "true"
//	bytesData, err := json.Marshal(params)
//	if err != nil {
//		// fmt.Println("e1:", err.Error())
//		return false
//	}
//	reader := bytes.NewReader(bytesData)
//
//	request, err := http.NewRequest("POST", apiUrl, reader)
//
//	if err != nil {
//		// fmt.Println("e2:", err.Error())
//		return false
//	}
//	request.Header.Set("Content-Type", "application/json;charset=UTF-8")
//	client := http.Client{}
//	resp, err := client.Do(request)
//	defer resp.Body.Close()
//	body, err := ioutil.ReadAll(resp.Body)
//	if err != nil {
//		// fmt.Println("e4:", err.Error())
//		return false
//	}
//	respBody := string(body)
//	// fmt.Printf("本机号校验响应: %s \n ", respBody)
//	var mapResult map[string]interface{}
//	if err := json.Unmarshal([]byte(respBody), &mapResult); err != nil {
//		return false
//	}
//	// fmt.Println(mapResult)
//	if mapResult["code"] == "0" {
//		// "code"："0", //状态码
//		// "msgId":"17041010383624511", //消息Id
//		// "errorMsg":"", //失败状态码说明（成功返回空）
//		// "failNum":"0", //失败条数
//		// "successNum":"1" //成功条数
//		return true
//	}
//	return false
//
// }

// SendPayWarningSms 支付预警发送短信
// smsType:1通知类,2验证码,3营销类
// msgParams="手机号1,参数1,参数2;手机号2,参数1,参数2"
func SendPayWarningSms(smsType int, msgContent string, msgParams string) (resp SmsCodeResponse, err error) {
	apiUrl := utils.Config.Sms.ChuangLanTongZhiUrl // 默认为通知类短信
	request := SmsCodeRequest{
		Params:   msgParams,
		Account:  utils.Config.Sms.ChuangLanTongZhiAccount,
		Password: utils.Config.Sms.ChuangLanTongZhiPassword,
		Msg:      msgContent,
		Report:   "true",
	}

	if smsType == 2 {
		request.Account = utils.Config.Sms.ChuangLanyanZhengMaAccount
		request.Password = utils.Config.Sms.ChuangLanyanZhengMaPassword
		apiUrl = utils.Config.Sms.ChuangLanyanZhengMaUrl
	} else if smsType == 3 {
		request.Account = utils.Config.Sms.ChuangLanYingXiaoAccount
		request.Password = utils.Config.Sms.ChuangLanYingXiaoPassword
		apiUrl = utils.Config.Sms.ChuangLanYingXiaoUrl
	}

	err = gout.POST(apiUrl).SetJSON(&request).BindJSON(&resp).Do()
	if err != nil {
		utils.LogErrorF("发送短信失败:%s", err.Error())
		return
	}
	return
}
