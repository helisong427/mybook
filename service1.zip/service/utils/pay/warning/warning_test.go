package warning

import (
	"sync"
	"testing"
)

// TestMessagePush 测试消息推送
func TestMessagePush(t *testing.T) {
	var wg sync.WaitGroup
	for i := 0; i < 10; i++ {
		wg.Add(1)
		go func(i int) {
			if i%2 == 0 {
				q.PushMessage(Message{
					UserID: 1,
					Type:   4,
				})
			} else {
				q.PushMessage(Message{
					UserID: 1,
					Type:   1,
				})
			}
			wg.Done()
		}(i)
	}

	wg.Wait()
}

// TestQueueStop 测试关闭队列
func TestQueueStop(t *testing.T) {
	q.PushMessage(Message{
		UserID: 1,
		Type:   1,
	})
	q.PushMessage(Message{
		UserID: 1,
		Type:   1,
	})

	q.Stop()

	q.PushMessage(Message{
		UserID: 1,
		Type:   4,
	})
}
