package pay

import (
	"fmt"
	"github.com/iGoogle-ink/gopay"
	"github.com/iGoogle-ink/gopay/alipay"
)

//支付宝支付
type AliPay struct {
	client     *alipay.Client
	ReturnUrl  string //返回地址
	Price      int64  //金额/分
	OutTradeNo int64  //商户订单号
	Desc       string //描述
}

//初始化支付宝支付
func NewAlipay(appId, privateKey, publicKey, notifyUrl, returnUrl string) *AliPay {
	p := AliPay{}
	//获取环境
	debug, _ := GetPayEnv()
	p.ReturnUrl = returnUrl
	p.client = alipay.NewClient(appId, privateKey, true)
	p.client.DebugSwitch = debug
	p.client.NotifyUrl = notifyUrl
	//设置支付宝公钥
	p.client.SetAliPayPublicCertSN(publicKey)
	return &p
}

//App下单
func (p *AliPay) AppPlaceOrder() (orderParameters string, err error) {
	bm := make(gopay.BodyMap)
	bm.Set("subject", p.Desc).
		Set("out_trade_no", p.OutTradeNo).
		Set("total_amount", fmt.Sprintf("%.2f", float64(p.Price)/float64(100))) //支付宝支付单位为元
	appPay, err := p.client.TradeAppPay(bm)
	if err != nil {
		return
	}
	orderParameters = appPay
	return
}

//手机网站支付下单
func (p *AliPay) WapPlaceOrder() (orderParameters string, err error) {
	returnUrl := fmt.Sprintf("%s?out_trade_no=%d", p.ReturnUrl, p.OutTradeNo)
	bm := make(gopay.BodyMap)
	bm.Set("subject", p.Desc).
		Set("return_url", returnUrl).
		Set("quit_url", p.ReturnUrl).
		Set("out_trade_no", p.OutTradeNo).
		Set("total_amount", fmt.Sprintf("%.2f", float64(p.Price)/float64(100))) //支付宝支付单位为元
	appPay, err := p.client.TradeWapPay(bm)
	if err != nil {
		return
	}
	orderParameters = appPay
	return
}
