package wechat

import (
	"fmt"
	"github.com/guonaihong/gout"
	"net/url"
)

type Wechat struct {
	AppId       string
	Secret      string
	RedirectUri string
}

type AccessTokenResponse struct {
	ErrCode      int    `json:"errcode"`
	ErrMsg       string `json:"errmsg"`
	AccessToken  string `json:"access_token"`
	ExpiresIn    int    `json:"expires_in"`
	RefreshToken string `json:"refresh_token"`
	Openid       string `json:"openid"`
	Scope        string `json:"scope"`
}

const (
	codeUrl        = "https://open.weixin.qq.com/connect/oauth2/authorize?%s#wechat_redirect" //获取用户code地址
	accessTokenUrl = "https://api.weixin.qq.com/sns/oauth2/access_token?%s"                   //获取access_token地址
)

func NewWechat(appId, secret, redirectUri string) *Wechat {
	return &Wechat{
		AppId:       appId,
		Secret:      secret,
		RedirectUri: redirectUri,
	}
}

//获取用户同意授权,获取code
func (w *Wechat) GetCode() (url string) {
	params := make(map[string]string)
	params["appid"] = w.AppId
	params["redirect_uri"] = w.RedirectUri
	params["response_type"] = "code" //code
	params["scope"] = "snsapi_base"
	param := formatURLParam(params)
	url = fmt.Sprintf(codeUrl, param)
	return
}

//通过code换取网页授权access_token
func (w *Wechat) GetAccessToken(code string) (r AccessTokenResponse, err error) {
	params := make(map[string]string)
	params["appid"] = w.AppId
	params["secret"] = w.Secret
	params["code"] = code
	params["grant_type"] = "authorization_code"
	param := formatURLParam(params)
	requestUrl := fmt.Sprintf(accessTokenUrl, param)
	//发起请求
	err = gout.GET(requestUrl).Debug(true).BindJSON(&r).Do()
	if err != nil {
		return
	}
	if r.ErrCode != 0 {
		err = fmt.Errorf("code:%d,err:%s", r.ErrCode, r.ErrMsg)
	}
	return
}

// 格式化请求URL参数
func formatURLParam(body map[string]string) (urlParam string) {
	v := url.Values{}
	for key, value := range body {
		v.Add(key, value)
	}
	return v.Encode()
}
