package utils

import (
	"bytes"
	"fmt"
	"io/ioutil"
	"os"
	"time"

	"github.com/gin-gonic/gin"
	jsoniter "github.com/json-iterator/go"

	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"

	"github.com/Shopify/sarama"
	rotatelogs "github.com/lestrrat-go/file-rotatelogs"
)

// Logger 全局
var Logger *zap.Logger

func LogInfoF(format string, ps ...interface{}) {
	content := fmt.Sprintf(format, ps...)
	Logger.Info(content)
}
func LogErrorF(format string, ps ...interface{}) {
	content := fmt.Sprintf(format, ps...)
	Logger.Error(content)
}

type logKafka struct {
	Producer sarama.SyncProducer
}

func (lk *logKafka) Write(p []byte) (n int, err error) {
	msg := &sarama.ProducerMessage{}
	msg.Topic = Config.App.LogName
	msg.Value = sarama.ByteEncoder(p)
	msg.Key = sarama.StringEncoder(FuncGenerateDataId())
	_, _, err = lk.Producer.SendMessage(msg)
	if err != nil {
		return
	}
	return
}

// LoggerInit 初始化日志 按时间/等级分割
func LoggerInit() {
	// 设置一些基本日志格式 具体含义还比较好理解，直接看zap源码也不难懂
	config := zapcore.EncoderConfig{
		TimeKey:       "time",
		LevelKey:      "level",
		NameKey:       "logger",
		CallerKey:     "linenum",
		MessageKey:    "content",
		StacktraceKey: "stacktrace",
		LineEnding:    zapcore.DefaultLineEnding,   // 每行的分隔符。默认zapcore.DefaultLineEnding 即"\n"
		EncodeLevel:   zapcore.CapitalLevelEncoder, // 将日志级别字符串转化为LowercaseLevelEncoder小写,CapitalLevelEncoder
		EncodeTime: func(t time.Time, enc zapcore.PrimitiveArrayEncoder) {
			enc.AppendString(t.Format("2006-01-02 15:04:05"))
		},
		EncodeCaller: zapcore.FullCallerEncoder, // 以包/文件:行号 格式化调用堆栈 ShortCallerEncoder
		EncodeDuration: func(d time.Duration, enc zapcore.PrimitiveArrayEncoder) {
			enc.AppendInt64(int64(d) / 1000000)
		},
	}
	encoder := zapcore.NewJSONEncoder(config) //json格式
	//encoder := zapcore.NewConsoleEncoder(config)

	// 设置级别
	logLevel := zap.DebugLevel
	switch Config.App.LogLevel {
	case "debug":
		logLevel = zap.DebugLevel
	case "info":
		logLevel = zap.InfoLevel
	case "warn":
		logLevel = zap.WarnLevel
	case "error":
		logLevel = zap.ErrorLevel
	case "panic":
		logLevel = zap.PanicLevel
	case "fatal":
		logLevel = zap.FatalLevel
	default:
		logLevel = zap.InfoLevel
	}

	// 最后创建具体的Logger
	var allCore []zapcore.Core
	// >=logLevel 控制台输出
	allCore = append(allCore, zapcore.NewCore(encoder,
		zapcore.AddSync(os.Stdout),
		zap.LevelEnablerFunc(func(lvl zapcore.Level) bool {
			return lvl >= logLevel
		})))
	// >=logLevel 保存到文件或者kafka
	if Config.App.LogType == "file" {
		// 生成rotatelogs的Logger 实际生成的文件名 demo.log.YYmmddHH
		fileErrorHook, err := rotatelogs.New(
			Config.App.LogPath+"log_%Y%m%d%H.log",
			rotatelogs.WithMaxAge(time.Hour*24*30),    // 保存30天
			rotatelogs.WithRotationTime(time.Hour*24), // 切割频率 24小时
		)
		if err != nil {
			fmt.Printf("log to file failed: %+v\n", err)
			os.Exit(-1)
		}
		allCore = append(allCore, zapcore.NewCore(encoder,
			zapcore.AddSync(fileErrorHook),
			zap.LevelEnablerFunc(func(lvl zapcore.Level) bool {
				return lvl >= logLevel
			})))
	} else if Config.App.LogType == "kafka" {
		var (
			kl  logKafka
			err error
		)
		// 设置日志输入到Kafka的配置
		config := sarama.NewConfig()
		// 等待服务器所有副本都保存成功后的响应
		config.Producer.RequiredAcks = sarama.WaitForAll
		// 随机的分区类型
		config.Producer.Partitioner = sarama.NewRandomPartitioner
		// 是否等待成功和失败后的响应,只有上面的RequiredAcks设置不是NoReponse这里才有用.
		config.Producer.Return.Successes = true
		config.Producer.Return.Errors = true

		kl.Producer, err = sarama.NewSyncProducer([]string{Config.App.LogPath}, config)
		if err != nil {
			fmt.Printf("connect kafka failed: %+v\n", err)
			os.Exit(-1)
		}
		// 打印在kafka
		kafkaCore := zapcore.NewCore(encoder, zapcore.AddSync(&kl), zap.LevelEnablerFunc(func(lvl zapcore.Level) bool {
			return lvl >= logLevel
		}))
		allCore = append(allCore, kafkaCore)
	}
	core := zapcore.NewTee(allCore...)
	Logger = zap.New(core, zap.AddCaller(), zap.AddStacktrace(zapcore.ErrorLevel)) // zap.AddCaller() 才会显示打日志点的文件名和行数
}

// LoggerAddString 添加自定义字符串字段
func LoggerAddString(key, value string) zapcore.Field {
	return zap.String(key, value)
}

// LoggerAddInt 添加自定义数字字段
func LoggerAddInt(key string, value int) zapcore.Field {
	return zap.Int(key, value)
}

// 请求日志白名单接口
var requestLogWhite = map[string]int{
	"/user/id-card-verification": 0,
	"/common/region-list":        0,
	"/":                          0,
	"/livez":                     0, // 监控
}

func RequestLog() gin.HandlerFunc {
	return func(gct *gin.Context) {
		start := time.Now().UTC()
		method := gct.Request.Method
		path := gct.Request.RequestURI
		ip := gct.ClientIP()
		queryId := FuncGenerateDataId()
		gct.Set("SYSTEMQUERYID", queryId)
		if method != "OPTIONS" {
			// 日志白名单不写日志
			if _, ok := requestLogWhite[path]; !ok {
				fmt.Println("访问目录:" + path)
				bodyString := ""
				if gct.Request.Body != nil {
					body, _ := ioutil.ReadAll(gct.Request.Body)
					gct.Request.Body = ioutil.NopCloser(bytes.NewBuffer(body))
					bodyString = string(body)
				}
				// 继续
				gct.Next()
				// 计算请求完成时间
				end := time.Now().UTC()
				latency := end.Sub(start)
				contentMap := make(map[string]interface{})
				contentMap["Url"] = path
				contentMap["Header"] = gct.Request.Header
				contentMap["IP"] = ip
				contentMap["Body"] = bodyString
				contentMap["Latency"] = latency.String()
				content, err := jsoniter.MarshalToString(contentMap)
				if err != nil {
					content = ""
				}
				Logger.Info(content,
					LoggerAddString("Method", method),
					LoggerAddString("Url", path),
					LoggerAddString("Type", "request"),
					LoggerAddString("Queryid", queryId),
				)
			}
		}
	}
}
