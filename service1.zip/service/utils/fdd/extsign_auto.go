package fdd

import (
	"errors"
)

// 自动签
// 企业和用户签署合同
type ExtSignAutoRequest struct {
	baseRequest
	TransactionId string `json:"transaction_id"` // 交易号码
	ContractId    string `json:"contract_id"`    // 合同编号
	CustomerId    string `json:"customer_id"`    // 客户编号
	ClientRole    string `json:"client_role"`    // 客户角色:1-接入平台
	DocTitle      string `json:"doc_title"`      // 文档标题
	PositionType  string `json:"position_type"`  // 定位类型:0-关键字,1-坐标
	SignKeyword   string `json:"sign_keyword"`   // 关键字
	// NotifyUrl     string `json:"notify_url"`     //异步通知地址
}

type ExtSignAutoResponse struct {
	Code        string `json:"code"`         // 状态码，1000成功
	Result      string `json:"result"`       // success:成功,error:失败
	Msg         string `json:"msg"`          // 描述
	DownloadUrl string `json:"download_url"` // 下载地址
	ViewpdfUrl  string `json:"viewpdf_url"`  // 查看地址
}

// 自动签
func (c *Client) ExtSignAuto(transactionId string, contractId string) (r ExtSignAutoResponse, err error) {
	c.Address = extSignAuto
	req := ExtSignAutoRequest{
		baseRequest:   c.baseRequest,
		ContractId:    contractId, // 合同编号
		CustomerId:    c.CustomerId,
		TransactionId: transactionId,
		ClientRole:    "1",
		DocTitle:      c.DocTitle,
		PositionType:  "0",
		SignKeyword:   c.SignKeyword,
	}
	sign := c.extsionAuto(transactionId, c.CustomerId)
	req.MsgDigest = sign
	err = c.send(req, &r)
	if err != nil {
		return
	}
	if r.Code != "1000" || r.Result != "success" {
		err = errors.New(r.Msg)
		return
	}

	return
}
