package fdd

import "errors"

// 合同归档
type ContractFilingRequest struct {
	baseRequest
	ContractId string `json:"contract_id"` // 合同编号
}

type ContractFilingResponse struct {
	Result string `json:"result"`
	Code   string `json:"code"`
	Msg    string `json:"msg"`
}

func (c *Client) ContractFiling(contractId string) (err error) {
	c.Address = contractFiling
	req := ContractFilingRequest{
		baseRequest: c.baseRequest,
		ContractId:  contractId,
	}
	sign := c.sontractFilingSign(contractId)
	req.MsgDigest = sign
	r := ContractFilingResponse{}
	err = c.send(req, &r)
	if err != nil {
		return
	}
	if r.Result != "success" || r.Code != "1000" {
		err = errors.New(r.Msg)
		return
	}
	return
}
