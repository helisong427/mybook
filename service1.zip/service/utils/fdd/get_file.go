package fdd

import (
	"encoding/json"
	"errors"

	"github.com/fatih/structs"
	"github.com/guonaihong/gout"
)

type GetFileRequest struct {
	baseRequest
	Uuid string `json:"uuid"` // 图片uuid,查询认证结果时返回
}

type GetFileResponse struct {
	baseResponse
	Data string `json:"data"`
}

type GetFileHeader struct {
	ContentDisposition string `header:"Content-Disposition"`
}

// 通过uuid下载文件
func (c *Client) GetFile(uuid string) (file *string, err error) {
	c.Address = getFile
	req := GetFileRequest{
		baseRequest: c.baseRequest,
		Uuid:        uuid,
	}
	m := structs.Map(&req)
	sign := c.sign(m)
	req.MsgDigest = sign

	url := c.Host + c.Address
	marshal, err := json.Marshal(req)
	if err != nil {
		return
	}
	form := make(map[string]string)
	err = json.Unmarshal(marshal, &form)
	if err != nil {
		return
	}
	r := GetFileResponse{}
	header := GetFileHeader{}
	body := ""
	err = gout.POST(url).SetWWWForm(form).BindHeader(&header).BindBody(&body).Do()
	if err != nil {
		return
	}
	// 如果header不为空,有文件
	if header.ContentDisposition != "" {
		file = &body
	} else {
		err = json.Unmarshal([]byte(body), &r)
		if err != nil {
			return
		}
		err = c.send(req, &r)
		if err != nil {
			return
		}
		if r.Code != 1 {
			err = errors.New(r.Msg)
			return
		}
	}
	return
}
