package fdd

import (
	"errors"
	"fmt"
	"time"
)

// 合同上传
type UploaddocsRequest struct {
	baseRequest
	ContractId string `json:"contract_id"` // 合同编号
	DocTitle   string `json:"doc_title"`   // 合同标题
	DocUrl     string `json:"doc_url"`     // 文档地址
	// File       string `json:"file"`        //PDF文档
	DocType string `json:"doc_type"` // 文档类型
}

type UploaddocsResponse struct {
	Result string `json:"result"` // 处理结果
	Code   string `json:"code"`   // 状态码
	Msg    string `json:"msg"`    // 描述
}

func (c *Client) Uploaddocs(userId int64) (contractId string, err error) {
	c.Address = uploaddocs
	// 合合同编号
	contractId = fmt.Sprintf("%d%d", userId, time.Now().Unix())
	req := UploaddocsRequest{
		baseRequest: c.baseRequest,
		ContractId:  contractId,
		DocTitle:    c.DocTitle,
		DocUrl:      c.DocUrl,
		DocType:     ".pdf",
	}
	// m := structs.Map(&req)
	sign := c.uploaddocsSign(req.ContractId)
	req.MsgDigest = sign
	r := UploaddocsResponse{}
	err = c.send(req, &r)
	if err != nil {
		return
	}
	if r.Result != "success" || r.Code != "1000" {
		err = errors.New(r.Msg)
		return
	}
	return
}
