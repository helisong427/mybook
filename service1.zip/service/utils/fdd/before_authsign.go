package fdd

import "fmt"

// 授权自动签
type BeforeAuthsignRequest struct {
	baseRequest
	TransactionId string `json:"transaction_id"` // 交易号码
	ContractId    string `json:"contract_id"`    // 合同编号
	CustomerId    string `json:"customer_id"`    // 客户编号
	AuthType      int    `json:"auth_type"`      // 授权类型,1:授权自动签（目前只能填1）
	ReturnUrl     string `json:"return_url"`     // 页面跳转URL（签署结果同步通知)
	NotifyUrl     string `json:"notify_url"`     // 签署结果异步通知URL
}

// 授权自动签
func (c *Client) BeforeAuthsign(customerId string, transactionId string) (url string, err error) {
	c.Address = beforeAuthsign
	req := BeforeAuthsignRequest{
		baseRequest:   c.baseRequest,
		TransactionId: transactionId,
		// ContractId:    c.ContractId,
		CustomerId: customerId,
		AuthType:   1,
		ReturnUrl:  c.ReturnUrl,
		NotifyUrl:  c.NotifyUrl,
	}
	sign := c.extsionAuto(transactionId, customerId)
	req.MsgDigest = sign

	url = fmt.Sprintf("%s%s?app_id=%s&timestamp=%s&v=%s&msg_digest=%s&transaction_id=%s&contract_id=%s&customer_id=%s&auth_type=%d&return_url=%s&notify_url=%s",
		c.Host,
		c.Address,
		c.AppId,
		c.Timestamp,
		c.V,
		req.MsgDigest,
		req.TransactionId,
		req.ContractId,
		req.CustomerId,
		req.AuthType,
		req.ReturnUrl,
		req.NotifyUrl,
	)

	return
}
