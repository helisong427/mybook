package utils

import (
	"fmt"
	"reflect"
	"strconv"
	"time"

	"github.com/go-redis/redis"
	"github.com/leyle/ginbase/util"
)

// redis锁时间
const (
	DEFAULT_LOCK_ACQUIRE_TIMEOUT = 5 // 秒
	DEFAULT_LOCK_KEY_TIMEOUT     = 5
)

// 定义redis key,注意，如果需要对用户信息相关的数据进行操作加锁，请直接使用用户id，避免多业务并发问题
const (
	REDIS_USER_INFO                  = "userInfo:"               // 存放用户info
	REDIS_USER_TEM_OLD_REFRESH_TOKEN = "userTemOldRefreshToken:" // 存放用户临时RefreshToken
	REDIS_USER_COMMISSION_INFO       = "userInfoCommission:"     // 存放用户info分成比例
	REDIS_USER_ICON_INFO             = "userIconInfo:"           // 存放用户当前装扮头像框
	REDIS_USER_CHAT_INFO             = "userChatInfo:"           // 存放用户当前装扮气泡
	REDIS_USER_COME_IN_INFO          = "userComeInInfo:"         // 存放用户当前装扮坐骑信息
	REDIS_EXCHANGE_MONEY_LOCK        = "exchangeMoneyLock:"      // 用户兑换go币锁
	REDIS_USER_VISITOR               = "userVisitor:"            // 用户访问记录
	REDIS_USER_NEW_VISITOR_COUNT     = "userNewVisitorCount:"    // 用户最新访问次数
	REDIS_USER_TODAY_VISITOR_COUNT   = "userTodayVisitorCount:"  // 用户 访问记录
	REDIS_USER_PLACE_ORDER_LOCK      = "userPlaceOrderLock:"     // 用户下单锁
	REDIS_SMS_CODE                   = "smsCode:"                // 短语验证码
	REDIS_SMS_IP                     = "smsIp:"                  // 短信ip
	REDIS_SMS_CLIENT_CODE            = "smsClientCode:"          // 短信设备

	REDIS_FORGET_SMS_CODE               = "forgetSmsCode:"        // 忘记密码短语验证码
	REDIS_FORGET_SMS_IP                 = "forgetSmsIp:"          // 忘记密码短信ip
	REDIS_FORGET_SMS_CLIENT_CODE        = "forgetSmsClientCode:"  // 忘记密码短信设备
	REDIS_FORGET_PASSWORD_CHECK         = "forgetPasswordCheck:"  // 忘记密码验证
	REDIS_FORGET_UPDATE_PASSWORD_VERIFY = "updatePasswordVerify:" // 更新密码验证

	REDIS_OLD_SMS_CODE        = "oldSmsCode:"        // 旧手机验证码
	REDIS_OLD_SMS_IP          = "oldSmsIp:"          // 旧手机短信ip
	REDIS_OLD_SMS_CLIENT_CODE = "oldSmsClientCode:"  // 旧手机短信设备
	REDIS_OLD_MOBILE_CHECK    = "oldMobileCheck:"    // 旧手机验证
	REDIS_SKILL_INFO          = "skillInfo"          // 游戏查询缓存
	REDIS_MSG_MODEL           = "msgModel"           // 消息查询缓存
	REDIS_GIFT_INFO           = "giftInfo"           // 礼物查询缓存
	REDIS_SYTEM_PARAM         = "systemParam"        // 系统参数缓存
	REDIS_TRANSACTION_CHANNEL = "transactionChannel" // 交易渠道缓存

	REDIS_ATTENTION_TIMEOUT = "attention:" // 关注超时推送
	// id 生成器 key
	REDIS_IDBUILDER_USER_ID             = "userIdBuilder:"            // 用户id生成器
	REDIS_IDBUILDER_EGGBREAK_RECORD_ID  = "eggBreakRecordIdBuilder:"  // 砸蛋记录标识(聚合)
	REDIS_IDBUILDER_TURNTABLE_RECORD_ID = "turnTableRecordIdBuilder:" // 转盘记录表示(聚合)
	REDIS_IDBUILDER_ORDER_ID            = "orderIdBuilder:"           // 订单id
	REDIS_IDBUILDER_TRANSACTION_ID      = "transactionIdBuilder:"     // 交易流水id

	// 直播间
	REDIS_LIVE_ROOM_INFO         = "liveRoomInfo:"        // 直播间信息
	REDIS_LIVE_WHEAT             = "liveWheat:"           // 麦位
	REDIS_LIVE_WHEAT_LOVE        = "liveWheatLove:"       // 麦位爱意值
	REDIS_LIVE_WHEAT_QUEUE       = "liveWheatQueue:"      // 麦序
	REDIS_LIVE_GIFT_BACKPACK     = "liveGiftBackpack:"    // 背包礼物
	REDIS_LIVE_GIFT_LOCK         = "liveGiftLock:"        // 收费礼物锁
	REDIS_LIVE_ONLINE_MEMBER_NUM = "liveOnLineMemberNum:" // 在线人员数
	REDIS_LIVE_ONLINE_MEMBER     = "liveOnLineMember:"    // 在线人员
	REDIS_LIVE_USER_FREE_GIFT    = "liveUserFreeGift:"    // 麦位
	// 直播间
	REDIS_LIVE_MUTE          = "liveMute:"
	REDIS_LIVE_FORBIDEN      = "liveForBiden:"
	REDIS_LIVE_JOIN_USER     = "liveJoinUser:" // 直播间加入的用户信息:key=>liveJoinUser:1,value=>3
	LOCK_PREFIX              = "lock:"
	REDIS_USER_WALLET_LOCK   = "userWallet:"   // 消费礼物的时候加锁
	REDIS_USER_SPARRING_LOCK = "userSparring:" // 申请大神加锁
	REDIS_USER_VIP_LOCK      = "userVip:"      // 用户vip加锁
	REDIS_DELAY_LOCK         = "delayLock"     // 爱意值加锁
	REDIS_ROOM_HEAT_PART     = "roomHeatPart"  // 派对房热度
	REDIS_ROOM_HEAT_Live     = "roomHeatLive"  // 直播房热度

	// 首页缓存
	REDIS_INDEX_INDEX                 = "indexIndex"                // 首页缓存
	REDIS_INDEX_PARAMS                = "indexParams"               // 首页参数缓存
	REDIS_INDEX_RECOMMEND_SPARRING    = "indexSparringRecommend:"   // 大神推荐记录
	REDIS_INDEX_ROOM_COMMENT          = "indexRoomComment:"         // 房间推荐记录
	REDIS_INDEX_ROOM_CHARM            = "indexRoomCharm"            // 房间魅力值
	REDIS_INDEX_RECOMMEND_USER_RECORD = "indexRecommendUserRecord:" // 首页用户推荐记录
	REDIS_INDEX_RECOMMEND_POSITION    = "indexRecommendPosition:"   // 首页推荐位

	// 排行
	REDIS_RANK_USER_SEND_WEALTH      = "rankUser:sendWealth:"     // 用户送礼排行（财富榜）
	REDIS_RANK_USER_RECV_CHARM       = "rankUser:recvCharm:"      // 用户收礼排行（魅力榜）
	REDIS_RANK_ROOM_SEND_CHARM       = "rankRoom:sendCharm:"      // 房间送礼排行（魅力榜）
	REDIS_RANK_ROOM_USER_SEND_WEALTH = "rankRoomUser:sendWealth:" // 房间内用户送礼排行（财富榜）
	REDIS_RANK_ROOM_USER_RECV_CHARM  = "rankRoomUser:recvCharm:"  // 房间内用户收礼排行（魅力榜）

	// 物品
	REDIS_PROP_INFO = "propInfo" // 物品查询缓存

	// 背包
	REDIS_BACKPACK_LOCK = "backpackLock:" // 背包锁

	// 砸蛋
	REDIS_EGGBREAK_RANK      = "eggBreakRank:"      // 砸蛋排行缓存(lock)
	REDIS_EGGBREAK_USER      = "eggBreakUser:"      // 砸蛋用户信息(用户配置etc)
	REDIS_EGGBREAK_RECORDER  = "eggBreak:Recorder:" // 砸蛋记录（日志/记录lock）
	REDIS_EGGBREAK_POOL_INIT = "eggBreak:PoolInit:" // 砸蛋池初始化(lock)
	// 砸蛋管理
	REDIS_EGGBREAK_POOL              = "eggbreak:Pool:"            // 砸蛋池
	REDIS_EGGBREAK_POOL_NEXT         = "eggbreak:PoolNext:"        // 砸蛋池下次更新
	REDIS_EGGBREAK_POOL_STATUS       = "eggbreak:PoolStatus:"      // 砸蛋池状态    key:小蛋池id:奖励id:礼物id:礼物价格 value:奖励数量
	REDIS_EGGBREAK_POOL_LOTTERY_LIST = "eggbreak:PoolLotteryList:" // 砸蛋池奖励列表

	// 转盘
	REDIS_TURNTABLE_POOL_INIT = "turntable:PoolInit:" // 转盘池初始化(lock)

	// 转盘管理
	REDIS_TURNTABLE_POOL              = "turntable:Pool:"            // 转盘池
	REDIS_TURNTABLE_POOL_NEXT         = "turntable:PoolNext:"        // 转盘池下次更新
	REDIS_TURNTABLE_POOL_STATUS       = "turntable:PoolStatus:"      // 转盘池状态    key:小转盘id:奖励id:礼物id:礼物价格 value:奖励数量
	REDIS_TURNTABLE_POOL_LOTTERY_LIST = "turntable:PoolLotteryList:" // 转盘池奖励列表

	// 任务系统
	REDIS_TASK_CFG_CHANGE       = "taskCfgChange"       // 任务系统变动(lock)
	REDIS_TASK_CFG_BY_SET       = "taskCfgBySet"        // 任务数据(以任务集合为基准)
	REDIS_TASK_CFG_BY_TASK_ID   = "taskCfgByTaskID"     // 任务数据(以任务集合为基准)
	REDIS_TASK_CFG_BY_CONDITION = "taskCfgByCondition:" // 任务数据(以完成条件为基准)

	// 管理平台
	REDIS_MANAGE_INFO                  = "manageInfo:"               // 管理员信息
	REDIS_MANAGE_TEM_OLD_REFRESH_TOKEN = "manageTemOldRefreshToken:" // 管理员临时RefreshToken

	// 版本信息
	REDIS_VERSION_INFO     = "versionInfo:"
	REDIS_APP_VERSION      = "appVersion:"
	REDIS_APP_LAST_VERSION = "appLastVersion:"

	// vip信息
	REDIS_VIP_PUSH_INFO = "vipLevelPushInfo"
	REDIS_USER_VIP_INFO = "userVipInfo"
	REDIS_MIN_VIP_LEVEL = "minVipExperience"
	REDIS_MAX_VIP_LEVEL = "maxVipExperience"

	// 首充信息
	REDIS_FIRST_CHARGE = "firstCharge"

	// 大神缓存
	REDIS_SPARRING_INFO = "sparringInfo"

	// 广告缓存
	REDIS_AD_LIST_INFO = "adListInfo:"

	// 大神id查询缓存
	REDIS_SPARRING_ID_LIST = "sparringIdList:"

	// 热门朋友圈
	REDIS_TWEET_POPULAR_COUNT   = "tweetPopularCount"   // 热门朋友圈统计
	REDIS_TWEET_POPULAR_ID_LIST = "tweetPopularIdList:" // 热门朋友圈id查询缓存

	// 渠道
	REDIS_CHANNEL_CALLBACK = "channelCallback:"
	REDIS_CHANNEL_INFO     = "channelInfo"

	// 评价标签
	REDIS_COMMENT_LABEL = "commentLabel:"

	// 大神技能标签
	REDIS_SPARRING_SKILL_LABEL = "sparringSkillLabel:"
	// 撩一撩
	REDIS_LIAOYILIAO_CONFIG    = "liaoyiliaoConfig"    // 配置
	REDIS_LIAOYILIAO_DAILY_MSG = "liaoyiliaoDailyMsg:" // 每日消息

	// 撩一撩邀请消息是否修改
	REDIS_INVITE_MESSAGE = "inviteMessage:"

	// 支付预警
	REDIS_PAY_WARNING = "payWarning:" // 同一用户若支付宝，苹果，微信都触发时，只发送一次。
	// REDIS_ALI_PAY_WARNING   = "aliPayWarning:"   // 支付宝
	// REDIS_APPLE_PAY_WARNING = "applePayWarning:" // 苹果

	// 推荐
	REDIS_RECOMMEND_SPARRING_GLOBAL         = "recommend:sparring:global"          // 大神全局缓存,大神分数(list),用于储存大神分数和其他信息
	REDIS_RECOMMEND_SPARRING_ONLINE         = "recommend:sparring:online"          // 大神推荐,在线列表(zset)
	REDIS_RECOMMEND_SPARRING_OFFLINE        = "recommend:sparring:offline"         // 大神推荐,离线列表(zset)
	REDIS_RECOMMEND_SPARRING_SKILL_ONLINE   = "recommend:sparring:skillOnline:"    // 大神游戏推荐,在线列表(zset)
	REDIS_RECOMMEND_SPARRING_SKILL_OFFLINE  = "recommend:sparring:skillOffline:"   // 大神游戏推荐,离线列表(zset)
	REDIS_RECOMMEND_SPARRING_POSITION       = "recommend:position:sparring"        // 首页大神推荐位
	REDIS_RECOMMEND_SPARRING_EXCLUSIVE      = "recommend:position:exclusive"       // 首页专属推荐位
	REDIS_RECOMMEND_SPARRING_EXCLUSIVE_USER = "recommend:sparring:exclusive:user:" // 首页专属推荐用户缓存

	REDIS_RECHARGE = "recharge_key" // 充值key

	// 邀请上麦
	RedisInviteUpWheat     = "inviteUpWheat:"     // 邀请上麦记录
	RedisInviteUpWheatList = "inviteUpWheatList:" // 所有邀请记录

	// 房间pk
	RedisRoomPkDetail    = "roomPKDetail:"    // 房间pk详情
	RedisRoomPkGloryStar = "roomPkGloryStar:" // 荣耀之星

	// 极速匹配
	REDIS_MATCHING_SPARRING_MATERIAL = "matching:sparringMaterial" // 大神素材
	REDIS_MATCHING_GRABBING_LOCK     = "matching:speedLock:"       // 极速匹配锁
)

var RedisClient *redis.Client

func RedisInit() {
	addr := fmt.Sprintf("%s%s", Config.Redis.Host, Config.Redis.Port)
	rOpt := &redis.Options{
		Addr:     addr,
		Password: Config.Redis.Password,
		DB:       Config.Redis.DbNum,
		PoolSize: Config.Redis.MaxOpenConns,
	}
	RedisClient = redis.NewClient(rOpt)

	_, err := RedisClient.Ping().Result()
	if err != nil {
		LogErrorF("ping redis[%s]失败, %s", addr, err.Error())
		return
	}
	LogInfoF("连接redis成功")
	return
}

func AcquireLock(resource string, acquireTimeout, lockTimeout int) (string, bool) {
	r := RedisClient
	if acquireTimeout <= 0 {
		acquireTimeout = DEFAULT_LOCK_ACQUIRE_TIMEOUT
	}
	if lockTimeout <= 0 {
		lockTimeout = DEFAULT_LOCK_KEY_TIMEOUT
	}

	lockResource := LOCK_PREFIX + resource
	val := util.GenerateDataId()
	lockTimeoutD := time.Duration(lockTimeout) * time.Second
	endTime := time.Now().Add(time.Duration(acquireTimeout) * time.Second)
	for time.Now().Unix() < endTime.Unix() {
		ok, err := r.SetNX(lockResource, val, lockTimeoutD).Result()
		if err != nil {
			LogErrorF("", "设置[%s]的锁失败, %s", resource, err.Error())
			return "", false
		}

		if ok {
			return val, true
		} else {
			time.Sleep(10 * time.Millisecond)
			continue
		}
	}
	return "", false
}

func ReleaseLock(resource, val string) bool {
	r := RedisClient
	lockResource := LOCK_PREFIX + resource
	v, err := r.Get(lockResource).Result()
	if err != nil && err != redis.Nil {
		LogErrorF("", "释放[%s]的锁失败, %s", resource, err.Error())
		return false
	}

	if err == redis.Nil {
		return true
	}
	redis.NewStringStructMapCmd()
	if v == val {
		r.Del(lockResource)
		return true
	} else {
		// 数据已被其他人加锁，那么此处可以认为是 ok 的
		return true
	}
}

func HashToStruct(data map[string]string, target interface{}) (err error) {
	_value := reflect.ValueOf(target).Elem()
	_type := reflect.TypeOf(target).Elem()

	for i := 0; i < _value.NumField(); i++ {
		// 获取tag
		tag := _type.Field(i).Tag.Get("redis")
		// 获取结构体类型
		structType := _value.Field(i).Type().Kind().String()
		// 参数不存在跳过
		if dataVal, ok := data[tag]; ok {
			switch structType {
			case "string":
				_value.Field(i).Set(reflect.ValueOf(dataVal))
			case "uint8":
				tmpVal, err := strconv.Atoi(dataVal)
				if err != nil {
					return err
				}
				_value.Field(i).Set(reflect.ValueOf(int8(tmpVal)))

			case "int32":
				tmpVal, err := strconv.Atoi(dataVal)
				if err != nil {
					return err
				}
				_value.Field(i).Set(reflect.ValueOf(int32(tmpVal)))

			case "uint32":
				tmpVal, err := strconv.Atoi(dataVal)
				if err != nil {
					return err
				}
				_value.Field(i).Set(reflect.ValueOf(int64(tmpVal)))
			case "int":
				tmpVal, err := strconv.Atoi(dataVal)
				if err != nil {
					return err
				}
				_value.Field(i).Set(reflect.ValueOf(int(tmpVal)))
			case "int64":
				tmpVal, err := strconv.Atoi(dataVal)
				if err != nil {
					return err
				}
				_value.Field(i).Set(reflect.ValueOf(int64(tmpVal)))
			case "uint64":
				tmpVal, err := strconv.Atoi(dataVal)
				if err != nil {
					return err
				}
				_value.Field(i).Set(reflect.ValueOf(int64(tmpVal)))
			default:

			}
		}
	}
	return
}

func SliceHelper(reply interface{}, err error, name string, makeSlice func(int), assign func(int, interface{}) error) error {
	if err != nil {
		return err
	}
	switch reply := reply.(type) {
	case []string:
		makeSlice(len(reply))
		for i := range reply {
			if reply[i] == "" {
				continue
			}
			if err := assign(i, reply[i]); err != nil {
				return err
			}
		}
		return nil
	}
	return fmt.Errorf("redigo: unexpected type for %s, got type %T", name, reply)
}
