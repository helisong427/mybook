package prop

import (
	"crypto/rand"
	"errors"
	"math/big"
	"time"
)

// 物品类型
type Type int

const (
	TypeGift      Type = 1 // 礼物
	TypeHammer    Type = 2 // 锤子
	TypeAvatar    Type = 3 // 头像框
	TypeChat      Type = 4 // 聊天框
	TypeCar       Type = 5 // 座驾
	TypeEvent     Type = 6 // 活动道具
	TypeRealThing Type = 7 // 实物道具
	TypeGOGO      Type = 8 // go币
)

const (
	ExceptedTypeAll Type = 0  // 用于标识所有类型
	UnexpectedType  Type = -1 // 用于标识非期望物品Type
	UnexpectedId    int  = -1 // 用于标识非期望物品Id
)

var (
	ErrorUnexpectedType = errors.New("unexpected prop type")
	ErrorUnexpectedId   = errors.New("unexpected prop id")
)

const (
	unexpectedCacheTimeOut             = time.Minute * 30
	unexpectedCacheTimeOutRandInterval = time.Minute * 5
)

func GetUnexpectedCacheTimeOut() time.Duration {
	var timeOut = unexpectedCacheTimeOut
	var randRT time.Duration

	var maxProb = new(big.Int).SetInt64(int64(unexpectedCacheTimeOutRandInterval))
	if prob, err := rand.Int(rand.Reader, maxProb); err == nil {
		randRT = time.Duration(prob.Int64())
	}

	return timeOut + randRT
}
