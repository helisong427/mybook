package token

import (
	"crypto/md5"
	"encoding/hex"
	"strconv"
)

// appId ,appCertificate /Code 证书,expiredTime // 授权过期时间戳,account //用户 ID
func SignalingToken(account, appID, appCertificate string, expiredTsInSeconds int) string {
	version := "1"
	expired := strconv.Itoa(expiredTsInSeconds)
	content := account + appID + appCertificate + expired
	hasher := md5.New()
	hasher.Write([]byte(content))
	md5sum := hex.EncodeToString(hasher.Sum(nil))
	result := version + ":" + appID + ":" + expired + ":" + md5sum
	return result
}
