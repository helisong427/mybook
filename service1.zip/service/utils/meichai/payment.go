package meichai

import (
	"encoding/json"
	"errors"
)

// 付款请求
type PaymentRequest struct {
	Outtradeno string `json:"outtradeno"` // 商户流水号（由商户填写，方便商户跟踪交易）
	Username   string `json:"username"`   // 姓名
	Useridcard string `json:"useridcard"` // 身份证号码
	Usermobile string `json:"usermobile"` // 手机号
	Userbankno string `json:"userbankno"` // 银行卡号
	Salary     string `json:"salary"`     // 薪资,单位元,支持小数点后两位
	Salarymemo string `json:"salarymemo"` // 薪资备注
}

type PaymentResponse struct {
	BaseResponse
	Data struct {
		TradeNo string `json:"trade_no"`
	} `json:"data"`
}

func (c *Client) PaymentRequest(request PaymentRequest) (tradeNo string, err error) {
	c.Params["method"] = paymentMethod
	bizContent, err := json.Marshal(request)
	if err != nil {
		return
	}
	c.Params["biz_content"] = string(bizContent)
	err = c.getSign()
	if err != nil {
		return
	}
	r := PaymentResponse{}
	err = c.Send(&r)
	if err != nil {
		return
	}
	if r.Code != "00" || r.SubCode != "00000" {
		marshal, _ := json.Marshal(r)
		err = errors.New(string(marshal))
	}
	tradeNo = r.Data.TradeNo
	return
}
