package meichai

import (
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha1"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"github.com/guonaihong/gout"
	"sort"
	"strings"
	"time"
)

const (
	bankCardVerifyMethod   = "individual.realname.002"     //姓名+身份证号+银行卡号 三要素校验接口
	alipayCardVerifyMethod = "individual.realname.003"     //姓名+身份证+支付宝 三要素校验接口
	paymentMethod          = "add.to.salarybill"           //银行卡付款
	alipayPaymentMethod    = "add.to.alipaysalarybillauto" //支付宝付款
	serviceSignMethod      = "add.servicesign"             //服务签约
	serviceAutoSignMethod  = "person.auto.servicesign"     //个人签约
)

type Client struct {
	Host       string
	PrivateKey string //私钥
	Params     map[string]string
}

//基础参数
type Base struct {
	MerchantId   string `json:"merchant_id"`   //商户号
	MerchantName string `json:"merchant_name"` //商户名
	Method       string `json:"method"`        //接口编号
	Version      string `json:"version"`       //版本
	Timestamp    string `json:"timestamp"`     //时间戳,发送请求的时间，格式"YYYY-MM-DD HH:mm:ss"
	SignType     string `json:"sign_type"`     //签名方法,目前支持:RSA
	Sign         string `json:"sign"`          //签名
	BizContent   string `json:"biz_content"`   //业务数据,将业务数据内容组合成json格式
}

//基础返回参数
type BaseResponse struct {
	Code    string `json:"code"`     //响应状态码
	Msg     string `json:"msg"`      //响应状态码描述
	SubCode string `json:"sub_code"` //业务返回码
	SubMsg  string `json:"sub_msg"`  //业务返回码描述
}

//初始化基本参数
func New(url, privateKey, merchantId, merchantName string) *Client {
	c := Client{
		Host:       url,
		PrivateKey: privateKey,
		Params:     make(map[string]string),
	}
	c.Params["merchant_id"] = merchantId
	c.Params["merchant_name"] = merchantName
	c.Params["version"] = "1.0"
	c.Params["timestamp"] = time.Now().Format("2006-01-02 15:04:05")
	c.Params["sign_type"] = "RSA"
	return &c
}

func (c *Client) Send(response interface{}) (err error) {
	marshal, err := json.Marshal(c.Params)
	if err != nil {
		return
	}
	fmt.Println(string(marshal))
	err = gout.POST(c.Host).Debug(true).SetWWWForm(c.Params).BindJSON(&response).Do()
	return
}

//获取签名
func (c *Client) getSign() (err error) {
	params := make(map[string]string)
	params = c.Params

	//排序
	var (
		buf     strings.Builder
		keyList []string
	)
	for k, _ := range params {
		keyList = append(keyList, k)
	}

	sort.Strings(keyList)
	for _, k := range keyList {
		if v, ok := params[k]; ok {
			buf.WriteString(k)
			buf.WriteByte('=')
			buf.WriteString(v)
			buf.WriteByte('&')
		}
	}
	param := buf.String()
	param = strings.TrimRight(param, "&")

	//格式化私钥
	privateKey := c.formatPrivateKey()
	block, _ := pem.Decode([]byte(privateKey))
	if block == nil {
		err = errors.New("pem.Decode：privateKey decode error")
		return
	}
	key, err := x509.ParsePKCS8PrivateKey(block.Bytes)
	if err != nil {
		return
	}
	pk8, ok := key.(*rsa.PrivateKey)
	if !ok {
		err = errors.New("parse PKCS8 key error")
		return
	}

	hash := sha1.New()
	_, err = hash.Write([]byte(param))
	if err != nil {
		return
	}
	v15, err := rsa.SignPKCS1v15(rand.Reader, pk8, crypto.SHA1, hash.Sum(nil))
	if err != nil {
		return
	}
	sign := base64.StdEncoding.EncodeToString(v15)
	c.Params["sign"] = sign
	return
}

//格式化私钥
func (c *Client) formatPrivateKey() (pKey string) {
	var buffer strings.Builder
	buffer.WriteString("-----BEGIN RSA PRIVATE KEY-----\n")
	rawLen := 64
	keyLen := len(c.PrivateKey)
	raws := keyLen / rawLen
	temp := keyLen % rawLen
	if temp > 0 {
		raws++
	}
	start := 0
	end := start + rawLen
	for i := 0; i < raws; i++ {
		if i == raws-1 {
			buffer.WriteString(c.PrivateKey[start:])
		} else {
			buffer.WriteString(c.PrivateKey[start:end])
		}
		buffer.WriteByte('\n')
		start += rawLen
		end = start + rawLen
	}
	buffer.WriteString("-----END RSA PRIVATE KEY-----\n")
	pKey = buffer.String()
	return
}
