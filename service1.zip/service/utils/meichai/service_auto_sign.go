package meichai

import (
	"encoding/json"
	"errors"
	"time"
)

// 发起个人服务签约请求
type ServiceAutoSignRequest struct {
	OutTradeNo       string      `json:"out_trade_no"`      // 交易编号
	ContractTemplate string      `json:"contract_template"` // 合同模板
	UserName         string      `json:"user_name"`         // 姓名
	UserIdcard       string      `json:"user_idcard"`       // 身份证
	FrontUrl         string      `json:"front_url"`         // 身份证正面照片地址
	BackUrl          string      `json:"back_url"`          // 身份证反面照片地址
	UserMobile       string      `json:"user_mobile"`       // 手机号
	Param            interface{} `json:"param"`             // 模板参数
	NotifyUrl        string      `json:"notify_url"`        // 异步通知地址
}

type ServiceAutoSignResponse struct {
	BaseResponse
	Data struct {
		MerchantId       string `json:"merchant_id"`       // 商户号
		OutTradeNo       string `json:"out_trade_no"`      // 交易号
		ContractCode     string `json:"contract_code"`     // 合同编号
		ContractTitle    string `json:"contract_title"`    // 合同标题
		ContractTemplate string `json:"contract_template"` // 合同模板
		SignCompany      string `json:"sign_company"`      // 签约企业
		UserName         string `json:"user_name"`         // 姓名
		UserIdcard       string `json:"user_idcard"`       // 身份证号
		UserMobile       string `json:"user_mobile"`       // 手机号
		ContractStatus   int    `json:"contract_status"`   // 合同状态：1-待企业签署，2-待个人签署，3-已签署，4-已拒签，5-已取消
		DownloadUrl      string `json:"download_url"`      // 合同下载地址
		ViewUrl          string `json:"view_url"`          // 合同查看地址
		CreateDate       string `json:"create_date"`       // 合同创建时间
		CompanySignDate  string `json:"company_sign_date"` // 企业签署时间
		UserSignDate     string `json:"user_sign_date"`    // 个人签署时间
		CancelDate       string `json:"cancel_date"`       // 取消时间
	} `json:"data"`
}

// 个人签约
func (c *Client) ServiceAutoSign(request ServiceAutoSignRequest) (err error) {
	c.Params["method"] = serviceAutoSignMethod
	param := make(map[string]interface{})
	param["签署日期"] = time.Now().Unix()
	param["姓名"] = request.UserName
	param["手机号"] = request.UserMobile
	param["身份证号"] = request.UserIdcard
	param["合同开始日期"] = time.Now().Unix()
	param["合同结束日期"] = time.Now().AddDate(10, 0, 0).Unix()
	request.Param = param
	bizContent, err := json.Marshal(request)
	if err != nil {
		return
	}
	c.Params["biz_content"] = string(bizContent)
	err = c.getSign()
	if err != nil {
		return
	}
	r := ServiceAutoSignResponse{}
	err = c.Send(&r)
	if err != nil {
		return
	}
	if r.Code != "00" || r.SubCode != "00000" {
		marshal, _ := json.Marshal(r)
		err = errors.New(string(marshal))
	}
	return
}
