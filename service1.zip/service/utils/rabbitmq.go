package utils

import (
	"fmt"
	"os"
	"time"

	"github.com/streadway/amqp"
)

var AMQP *amqp.Connection

const (
	RABBITMQ_SKILL_ORDER         = "skill_order"         // 大神订单
	RABBITMQ_SKILL_ORDER_APPEAL  = "skill_order_appeal"  // 大神订单申述
	RABBITMQ_CLOSE_ROOM          = "close_room"          // 关闭房间
	RABBITMQ_CANCEL_ROOM_RECTIFY = "cancel_room_rectify" // 取消房间整改
	RABBITMQ_IM_STATE_CHANGE     = "im_state_change"     // im状态变更
	RABBITMOQ_INVITE_MESSAGE     = "invite_message"      // 撩一撩邀请消息
	RABBITMQ_MATCHING_CANCEL     = "matching_cancel"     // 极速匹配取消
)

// RabbitMQInit 创建结构体实例
func RabbitMQInit() {
	rabitmqConf := Config.RabbitMQ
	url := fmt.Sprintf("amqp://%s:%s@%s%s/%s", rabitmqConf.User, rabitmqConf.Password, rabitmqConf.Host, rabitmqConf.Port, rabitmqConf.Vhost)
	connection, err := amqp.Dial(url)
	if err != nil {
		LogErrorF("连接rabbitmq失败,%s", err.Error())
		os.Exit(1)
	}
	AMQP = connection
}

// ProducerDelayed 生产延迟消息
func RabbitMQProducerDelayed(name string, body string, xDelay int) (err error) {
	var channel *amqp.Channel
	for i := 0; i < 5; i++ {
		channel, err = AMQP.Channel()
		if err == nil {
			break
		}
		LogErrorF("第[%d次]生产延迟消息失败,获取channel错误:[queue:%s],[body:%s],[err:%s]", i+1, name, body, err.Error())
		sT := 10 * (i + 1)
		time.Sleep(time.Duration(sT) * time.Second)
		RabbitMQInit()
	}
	if err == nil {
		defer channel.Close()
	} else {
		LogErrorF("生产延迟消息失败,获取channel错误:[queue:%s],[body:%s],[err:%s]", name, body, err.Error())
		return
	}

	err = channel.ExchangeDeclare(
		name,
		"x-delayed-message",
		true,  // 持久化
		false, // 是否自动删除
		false,
		false,
		amqp.Table{
			"x-delayed-type": "direct", // 设计交换机基本类型
		},
	)
	if err != nil {
		return
	}

	_, err = channel.QueueDeclare(
		name,
		true,
		false,
		false,
		false,
		nil,
	)
	if err != nil {
		return
	}

	err = channel.QueueBind(
		name,
		name,
		name,
		false,
		nil,
	)
	if err != nil {
		return
	}

	// 发送消息
	for i := 0; i < 3; i++ {
		err = channel.Publish(
			name,
			name,
			false,
			false,
			amqp.Publishing{
				ContentType:  "text/plain",
				Body:         []byte(body),
				DeliveryMode: amqp.Persistent, // 持久化消息
				Headers: amqp.Table{
					"x-delay": fmt.Sprintf("%d", 1000*xDelay), // 延迟(毫秒),xDelay(秒)
				},
			},
		)
		if err == nil {
			break
		}
		sT := 3 * (i + 1)
		time.Sleep(time.Duration(sT) * time.Second)
	}

	return
}

// ConsumerDelayed 消费延迟消息
func RabbitMQConsumerDelayed(QueueName string, funcF func(d amqp.Delivery)) {
	channel, err := AMQP.Channel()
	if err != nil {
		LogErrorF("消费延迟消息失败,获取channel错误:[queue:%s],[err:%s]", QueueName, err.Error())
		return
	}
	defer channel.Close()
	m := make(chan bool)
	msgs, err := channel.Consume(
		QueueName,
		"",
		false,
		false,
		false,
		true,
		nil,
	)
	if err != nil {
		LogErrorF("连接消费者失败:%s", err.Error())
	}
	go func() {
		for d := range msgs {
			fmt.Println(string(d.Body))
			funcF(d)
			// d.Ack(true) //确认消息
		}
	}()
	<-m
}
