package tencentIm

import "strconv"

const (
	FORBID_SEND_MSG = "v4/group_open_http_svc/create_group" // 禁言
)

type forbidSendMsgRequest struct {
	GroupId         string   `json:"GroupId"`         // 群Id
	Members_Account []string `json:"Members_Account"` // 禁言id列表
	ShutUpTime      int      `json:"ShutUpTime"`      // 禁言时间
}

type forbidSendMsgResponse struct {
	baseResponse
}

// 批量禁言和取消禁言
func ForbidSendMsg(userId int64, groupId int, time int) (err error) {
	data := forbidSendMsgRequest{
		GroupId:         strconv.Itoa(groupId),
		Members_Account: []string{strconv.Itoa(int(userId))},
		ShutUpTime:      time,
	}

	res := forbidSendMsgResponse{}
	err = post(FORBID_SEND_MSG, data, &res)
	return
}
