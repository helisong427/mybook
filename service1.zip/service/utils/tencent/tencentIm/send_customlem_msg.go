package tencentIm

import (
	"math/rand"
	"time"
)

// fa
func SendCusMsg(fromAccount string, tarGetId string, msg TIMCustomElem) (err error) {
	rand.Seed(time.Now().UnixNano())
	data := SendC2CMsgRequest{
		FromAccount:      fromAccount,
		SyncOtherMachine: 2,
		ToAccount:        tarGetId,
		MsgLifeTime:      DEFAULT_MSGLIFETIE,
		MsgRandom:        rand.Intn(MAX_RAND_NUM),
		MsgTimeStamp:     time.Now().Unix(),
		OfflinePushInfo:  OfflinePushInfo{Desc: msg.Desc, Ext: msg.Ext, Title: msg.Desc},
		MsgBody:          []CustomMsg{{MsgType: "TIMCustomElem", MsgContent: msg}},
	}
	res := SendGroupMsgResponse{}
	err = post(SEND_C2C_MSG, data, &res)
	return
}
