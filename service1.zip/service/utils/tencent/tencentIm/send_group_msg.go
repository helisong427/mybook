package tencentIm

import (
	"encoding/json"
	"math/rand"
	"time"
)

const (
	SEND_GROUP_MSG = "v4/group_open_http_svc/send_group_msg"
)

// 消息优先级
const (
	MSG_PRIORITY_HIGH   = "High"   // 高
	MSG_PRIORITY_NORMAL = "Normal" // 正常
	MSG_PRIORITY_LOW    = "Low"    // 低
	MSG_PRIORITY_LOWEST = "Lowest" // 最低
)

type SendGroupMsgRequest struct {
	GroupId     string `json:"GroupId"`      // 发送群id
	FromAccount string `json:"From_Account"` // 指定消息发送者（选填）
	MsgPriority string `json:"MsgPriority"`  // 消息优先级（选填）
	Random      int    `json:"Random"`       // 随机数字，五分钟数字相同认为是重复消息
	MsgBody     [1]struct {
		MsgType    string `json:"MsgType"` // 消息类型
		MsgContent struct {
			Text string `json:"Text"` // 消息内容
		} `json:"MsgContent"` // 消息body
	} `json:"MsgBody"` // 消息体
}

type SendGroupMsgResponse struct {
	baseResponse
	MsgTime int `json:"MsgTime"` // 消息发送的时间戳，对应后台 server 时间
	MsgSeq  int `json:"MsgSeq"`  // 消息序列号，唯一标示一条消息
}

// 在群组中发送普通消息
func SendGroupMsg(groupId string, fromAccount string, msg interface{}) (err error) {
	rand.Seed(time.Now().UnixNano())
	data := SendGroupMsgRequest{
		GroupId:     groupId,
		MsgPriority: MSG_PRIORITY_NORMAL,
		Random:      rand.Intn(MAX_RAND_NUM),
		FromAccount: fromAccount,
	}
	msgContent, _ := json.Marshal(msg)
	data.MsgBody[0].MsgType = "TIMTextElem" // 文本
	data.MsgBody[0].MsgContent.Text = string(msgContent)
	res := SendGroupMsgResponse{}
	err = post(SEND_GROUP_MSG, data, &res)
	return
}
