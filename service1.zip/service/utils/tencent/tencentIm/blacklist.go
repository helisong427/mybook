package tencentIm

const (
	BLACKLIST_ADD_URL = "v4/sns/black_list_add"
	BLACKLIST_DEL_URL = "v4/sns/black_list_delete"
)

// 拉黑请求
type blacklistAddReq struct {
	FromAccount string   `json:"From_Account"`
	ToAccount   []string `json:"To_Account"`
}

// 拉黑响应item
type blacklistAddRespItem struct {
	ToAccount  string `json:"To_Account"`
	ResultCode int64  `json:"ResultCode"`
	ResultInfo string `json:"ResultInfo"`
}

// 拉黑响应
type blacklistAddResp struct {
	ResultItem   []blacklistAddRespItem `json:"ResultItem"`
	FailAccount  []string               `json:"Fail_Account"`
	ErrorDisplay string                 `json:"ErrorDisplay"`
	baseResponse
}

// 拉黑操作im
func BlacklistAdd(userId, bannerId string) (err error) {
	data := blacklistAddReq{
		FromAccount: userId,
		ToAccount:   []string{bannerId},
	}
	res := blacklistAddResp{}
	err = post(BLACKLIST_ADD_URL, data, &res)
	return
}

// 取消拉黑
func BlacklistDel(userId, bannerId string) (err error) {
	data := blacklistAddReq{
		FromAccount: userId,
		ToAccount:   []string{bannerId},
	}
	res := blacklistAddResp{}
	err = post(BLACKLIST_DEL_URL, data, &res)
	return
}
