package tencentIm

import (
	"encoding/json"
)

const (
	SEND_GROUP_SYSTEM_NOTIFICATION = "v4/group_open_http_svc/send_group_system_notification"
)

type SendGroupSystemNotificationRequest struct {
	GroupId string `json:"GroupId"` // 群id
	Content string `json:"Content"` // 系统通知内容
}

type SendGroupSystemNotificationResponse struct {
	baseResponse
}

// 在群组中发送系统通知
func SendGroupSystemNotification(groupId string, msg interface{}) (err error) {
	msgContent, _ := json.Marshal(msg)
	data := SendGroupSystemNotificationRequest{
		GroupId: groupId,
		Content: string(msgContent),
	}

	res := SendGroupSystemNotificationResponse{}
	err = post(SEND_GROUP_SYSTEM_NOTIFICATION, data, &res)
	return
}
