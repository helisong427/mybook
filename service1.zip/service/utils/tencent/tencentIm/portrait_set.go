package tencentIm

import (
	"fmt"

	"gamers/utils"
)

const (
	PORTRAIT_SET = "v4/profile/portrait_set"
)
const (
	// 指定要设置的资料字段的名称
	TAG_PROFILE_IM_NICK  = "Tag_Profile_IM_Nick"  // 昵称
	TAG_PROFILE_IM_IMAGE = "Tag_Profile_IM_Image" // 头像URL
)

type PortraitSetRequest struct {
	From_Account string        `json:"From_Account"` // 需要设置该 UserID 的资料
	ProfileItem  []ProfileItem `json:"ProfileItem"`  // 待设置的用户的资料对象数组，数组中每一个对象都包含了 Tag 和 Value
}

type ProfileItem struct {
	Tag   string `json:"Tag"`   // 指定要设置的资料字段的名称
	Value string `json:"Value"` // 待设置的资料字段的值
}

type PortraitSetResponse struct {
	baseResponse
	ErrorDisplay string `json:"ErrorDisplay"`
}

// 设置资料
func PortraitSet(userId int64, userNickName string, UserIconurl string) (res PortraitSetResponse, err error) {
	data := PortraitSetRequest{
		From_Account: fmt.Sprintf("%d", userId),
	}
	data.ProfileItem = append(data.ProfileItem, ProfileItem{TAG_PROFILE_IM_NICK, userNickName})
	data.ProfileItem = append(data.ProfileItem, ProfileItem{TAG_PROFILE_IM_IMAGE, UserIconurl})
	err = post(PORTRAIT_SET, data, &res)
	if err != nil {
		utils.LogErrorF("修改用户信息失败,userId[%d],err[%s]", userId, err.Error())
	}
	return
}

// 设置管理员账号资料
func PortraitManagerSet(userId string, userNickName string, UserIconurl string) (res PortraitSetResponse, err error) {
	data := PortraitSetRequest{
		From_Account: userId,
	}
	data.ProfileItem = append(data.ProfileItem, ProfileItem{TAG_PROFILE_IM_NICK, userNickName})
	data.ProfileItem = append(data.ProfileItem, ProfileItem{TAG_PROFILE_IM_IMAGE, UserIconurl})
	err = post(PORTRAIT_SET, data, &res)
	if err != nil {
		utils.LogErrorF("修改用户信息失败,userId[%d],err[%s]", userId, err.Error())
	}
	return
}
