package tencentIm

import "fmt"

const (
	DESTROY_GROUP = "v4/group_open_http_svc/destroy_group"
)

type destroyGroupRequest struct {
	GroupId string `json:"GroupId"` // 群id
}

type DestroyGroupResponse struct {
	baseResponse
}

// 解散群
func DestroyGroup(groupId int) (res DestroyGroupResponse, err error) {
	data := destroyGroupRequest{GroupId: fmt.Sprintf("%d", groupId)}
	err = post(DESTROY_GROUP, data, &res)
	return
}
