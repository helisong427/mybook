package tencentIm

import "strconv"

const (
	GET_GROUP_MEMBER_INFO = "v4/group_open_http_svc/get_group_member_info" // 获取群成员详细资料
)

type getGroupMemberInfoRequest struct {
	GroupId string `json:"GroupId"` // 群组 ID（必填）
	Limit   int    `json:"Limit"`   // 最多获取多少个成员的资料
	Offset  int    `json:"Offset"`  // 从第多少个成员开始获取资料
}

type GetGroupMemberInfoResponse struct {
	baseResponse
	MemberNum  int `json:"MemberNum"` // 本群组的群成员总数
	MemberList []struct {
		Member_Account string `json:"Member_Account"` // 群员id

	} `json:"MemberList"` // 群成员列表
}

// 获取群成员详细资料
func GetGroupMemberInfo(groupId int, offset, limit int) (res GetGroupMemberInfoResponse, err error) {
	data := getGroupMemberInfoRequest{
		GroupId: strconv.Itoa(groupId),
		Offset:  offset,
		Limit:   limit,
	}
	err = post(GET_GROUP_MEMBER_INFO, data, &res)
	return
}
