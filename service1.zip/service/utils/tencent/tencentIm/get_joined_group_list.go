package tencentIm

import "strconv"

const (
	GET_JOINED_GROUP_LIST = "v4/group_open_http_svc/get_joined_group_list" // 获取用户所加入的群组
)

type getJoinedGroupListRequest struct {
	Member_Account string `json:"Member_Account"` // 用户id
	GroupType      string `json:"GroupType"`      // 群组类型
	WithHugeGroups int    `json:"WithHugeGroups"` // 是否获取用户加入的 AVChatRoom(直播群)，0表示不获取，1表示获取。默认为0
}

type GetJoinedGroupListResponse struct {
	baseResponse
	TotalCount  int `json:"TotalCount"` // 群组总数
	GroupIdList []struct {
		GroupId string `json:"GroupId"` // 群id
	} `json:"GroupIdList"` // 群id列表
}

// 获取用户所加入的群组
func GetJoinedGroupList(userId int64) (res GetJoinedGroupListResponse, err error) {
	data := getJoinedGroupListRequest{
		Member_Account: strconv.Itoa(int(userId)),
		GroupType:      GROUP_TYPE_AVCHATROOM,
		WithHugeGroups: 1,
	}

	err = post(GET_JOINED_GROUP_LIST, data, &res)
	return
}
