package tencentIm

const (
	GET_ONLINE_MEMBER_NUM = "v4/group_open_http_svc/get_online_member_num" // 获取在线人数
)

type GetOnlineMemberNumRequest struct {
	GroupId string `json:"GroupId"` // 群id
}

type GetOnlineMemberNumResponse struct {
	baseResponse
	GroupId         string `json:"GroupId"`         // 群id
	OnlineMemberNum int    `json:"OnlineMemberNum"` // 在线人数
}

// 获取在线人数
func GetOnlineMemberNum(groupId string) (onlineMemberNum int, err error) {
	data := GetOnlineMemberNumRequest{
		GroupId: groupId,
	}
	res := GetOnlineMemberNumResponse{}
	err = post(GET_ONLINE_MEMBER_NUM, data, &res)
	if err != nil {
		return
	}
	onlineMemberNum = res.OnlineMemberNum
	return
}
