package tencentIm

const MUTE_GROUP_URL = "v4/group_open_http_svc/forbid_send_msg"

type MuteGroupRequest struct {
	GroupId        string   `json:"GroupId"`         // 群id
	MembersAccount []string `json:"Members_Account"` // 禁言对象
	ShutUpTime     int64    `json:"ShutUpTime"`
}
type MuteGroupResponse struct {
	baseResponse
}

// 在群组中发送系统通知
func MuteGroup(groupId string, Users []string, expire int64) (err error) {
	if expire < 0 {
		expire = 0
	}
	data := MuteGroupRequest{
		GroupId:        groupId,
		MembersAccount: Users,
		ShutUpTime:     expire,
	}
	res := SendSystemNotificationResponse{}
	err = post(MUTE_GROUP_URL, data, &res)
	return
}
