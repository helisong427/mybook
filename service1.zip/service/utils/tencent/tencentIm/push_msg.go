package tencentIm

import (
	"math/rand"
	"time"
)

const SEND_SYSTEM_NOTIFICATION = "v4/all_member_push/im_push"

type MsgContent struct {
	Text string `json:"Text"`
}
type MsgItem struct {
	MsgType    string     `json:"MsgType"`
	MsgContent MsgContent `json:"MsgContent"`
}
type ConditionOrItem struct {
	TagsAnd  []string          `json:"TagsAnd"`
	TagsOr   []string          `json:"TagsOr"`
	AttrsAnd map[string]string `json:"AttrsAnd"`
	AttrsOr  map[string]string `json:"AttrsOr"`
}

type SendSystemNotificationRequest struct {
	FromAccount     string           `json:"From_Account"` // 群id
	MsgLifeTime     int64            `json:"MsgLifeTime"`
	MsgRandom       int              `json:"MsgRandom"`
	Condition       *ConditionOrItem `json:"Condition"`
	MsgBody         []CustomMsg      `json:"MsgBody"`
	OfflinePushInfo OfflinePushInfo  `json:"OfflinePushInfo"`
}
type SendSystemNotificationResponse struct {
	baseResponse
	TaskId string `json:"TaskId"`
}

const RETRY_MAX_TIMEOUT = 5000

// 在群组中发送系统通知
func SendSystemNotification(fromAccount string, msg TIMCustomElem) (err error) {
	rand.Seed(time.Now().UnixNano())
	data := SendSystemNotificationRequest{
		FromAccount: fromAccount,
		MsgLifeTime: 60 * 1,
		MsgRandom:   rand.Intn(MAX_RAND_NUM),
		MsgBody:     []CustomMsg{{MsgType: "TIMCustomElem", MsgContent: msg}},
	}
	// 重复三次
	for i := 0; i < 3; i++ {
		res := SendSystemNotificationResponse{}
		err = post(SEND_SYSTEM_NOTIFICATION, data, &res)
		if res.TaskId != "" {
			return
		}
		time.Sleep(time.Duration(rand.Intn(RETRY_MAX_TIMEOUT)) * time.Millisecond)
	}
	return
}

// 按标签推送
func SendNotificationByTag(fromAccount, tag string, msg TIMCustomElem) (err error) {
	rand.Seed(time.Now().UnixNano())
	tagInfo := ConditionOrItem{TagsAnd: []string{tag}}
	data := SendSystemNotificationRequest{
		FromAccount: fromAccount,
		MsgRandom:   rand.Intn(MAX_RAND_NUM),
		Condition:   &tagInfo,
		MsgLifeTime: 60 * 5,
		MsgBody:     []CustomMsg{{MsgType: "TIMCustomElem", MsgContent: msg}},
	}
	for i := 0; i < 3; i++ {
		res := SendSystemNotificationResponse{}
		err = post(SEND_SYSTEM_NOTIFICATION, data, &res)
		if res.TaskId != "" {
			return
		}
		time.Sleep(time.Duration(rand.Intn(RETRY_MAX_TIMEOUT)) * time.Millisecond)
	}
	return
}

// 全局推送
func SendNotificationByAll(fromAccount string, msg TIMCustomElem) (taskId string, err error) {
	rand.Seed(time.Now().UnixNano())
	data := SendSystemNotificationRequest{
		FromAccount:     fromAccount,
		MsgRandom:       rand.Intn(MAX_RAND_NUM),
		MsgLifeTime:     60 * 60,
		MsgBody:         []CustomMsg{{MsgType: "TIMCustomElem", MsgContent: msg}},
		OfflinePushInfo: OfflinePushInfo{Ext: msg.Ext, Desc: msg.Desc},
	}
	for i := 0; i < 3; i++ {
		res := SendSystemNotificationResponse{}
		err = post(SEND_SYSTEM_NOTIFICATION, data, &res)
		taskId = res.TaskId
		if res.TaskId != "" {
			return
		}
		time.Sleep(time.Duration(rand.Intn(RETRY_MAX_TIMEOUT)) * time.Millisecond)
	}
	return
}

// 按属性推送
func SendNotificationByAttr(fromAccount string, condition *ConditionOrItem, msg TIMCustomElem) (taskId string, err error) {
	rand.Seed(time.Now().UnixNano())
	data := SendSystemNotificationRequest{
		FromAccount:     fromAccount,
		MsgRandom:       rand.Intn(MAX_RAND_NUM),
		Condition:       condition,
		MsgLifeTime:     60 * 60,
		MsgBody:         []CustomMsg{{MsgType: "TIMCustomElem", MsgContent: msg}},
		OfflinePushInfo: OfflinePushInfo{Ext: msg.Ext, Desc: msg.Desc},
	}
	for i := 0; i < 3; i++ {
		res := SendSystemNotificationResponse{}
		err = post(SEND_SYSTEM_NOTIFICATION, data, &res)
		taskId = res.TaskId
		if res.TaskId != "" {
			return
		}
		time.Sleep(time.Duration(rand.Intn(RETRY_MAX_TIMEOUT)) * time.Millisecond)
	}
	return
}
