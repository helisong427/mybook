package tencentIm

import (
	"strconv"
)

const (
	CREATE_GROUP = "v4/group_open_http_svc/create_group" // 创建群
)

const (
	GROUP_TYPE_PRIVATE    = "Private"    // Private（即 Work，好友工作群）
	GROUP_TYPE_PUBLIC     = "Public"     // Public（陌生人社交群）
	GROUP_TYPE_CHATROOM   = "ChatRoom"   // ChatRoom（即 Meeting，会议群）
	GROUP_TYPE_AVCHATROOM = "AVChatRoom" // AVChatRoom（直播群）
	GROUP_TYPE_BCHATROOM  = "BChatRoom"
)

type createdGroupRequest struct {
	Type    string `json:"Type"`    // 群组类型：Private/Public/ChatRoom/AVChatRoom/BChatRoom（必填）
	GroupId string `json:"GroupId"` // 用户自定义群组 ID（选填）
	Name    string `json:"Name"`    // 群名称（必填）
}

type createdGroupResponse struct {
	baseResponse
	GroupId string
}

// 创建群
// userId 创建群的用户id
// GroupId 群id/房间id
// GroupName 群名称/房间名称
func CreatedGroup(groupId int64, groupName string) (err error) {
	data := createdGroupRequest{
		Type:    GROUP_TYPE_AVCHATROOM,
		GroupId: strconv.Itoa(int(groupId)),
		Name:    groupName,
	}
	res := createdGroupResponse{}
	err = post(CREATE_GROUP, data, &res)
	return
}
