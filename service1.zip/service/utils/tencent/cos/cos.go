package cos

import (
	"context"
	"crypto/hmac"
	"crypto/sha1"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math/rand"
	"net/http"
	"net/url"
	"os"
	"sort"
	"strconv"
	"strings"
	"time"

	"gamers/utils"

	"github.com/tencentyun/cos-go-sdk-v5"
)

type CredentialPolicyStatement struct {
	Action    []string                          `json:"action,omitempty"`
	Effect    string                            `json:"effect,omitempty"`
	Resource  []string                          `json:"resource,omitempty"`
	Condition map[string]map[string]interface{} `json:"condition,omitempty"`
}

type CredentialPolicy struct {
	Version   string                      `json:"version,omitempty"`
	Statement []CredentialPolicyStatement `json:"statement,omitempty"`
}

type CredentialOptions struct {
	Policy          *CredentialPolicy
	Region          string
	DurationSeconds int64
}

type Credentials struct {
	TmpSecretID  string `json:"TmpSecretId,omitempty"`
	TmpSecretKey string `json:"TmpSecretKey,omitempty"`
	SessionToken string `json:"Token,omitempty"`
}

type CredentialError struct {
	Code      string `json:"Code,omitempty"`
	Message   string `json:"Message,omitempty"`
	RequestId string `json:"RequestId,omitempty"`
}

type CredentialResult struct {
	Credentials *Credentials     `json:"Credentials,omitempty"`
	ExpiredTime int              `json:"ExpiredTime,omitempty"`
	Expiration  string           `json:"Expiration,omitempty"`
	StartTime   int              `json:"-,omitempty"`
	RequestId   string           `json:"RequestId,omitempty"`
	Error       *CredentialError `json:"Error,omitempty"`
}
type CredentialCompleteResult struct {
	Response *CredentialResult `json:"Response"`
}

func (e *CredentialError) Error() string {
	return fmt.Sprintf("Code: %v, Message: %v, RequestId: %v", e.Code, e.Message, e.RequestId)
}

type Client struct {
	client    *http.Client
	SecretId  string
	SecretKey string
}

func NewClient(secretId, secretKey string, hc *http.Client) *Client {
	if hc == nil {
		hc = &http.Client{}
	}
	c := &Client{
		client:    hc,
		SecretId:  secretId,
		SecretKey: secretKey,
	}
	return c
}

func makeFlat(params map[string]interface{}) string {
	keys := make([]string, 0, len(params))
	for k := range params {
		keys = append(keys, k)
	}
	sort.Strings(keys)

	var plainParms string
	for _, k := range keys {
		plainParms += fmt.Sprintf("&%v=%v", k, params[k])
	}
	return plainParms[1:]
}

func (c *Client) signed(method string, params map[string]interface{}) string {
	source := method + utils.Config.Tencent.CosHost + "/?" + makeFlat(params)

	hmacObj := hmac.New(sha1.New, []byte(c.SecretKey))
	hmacObj.Write([]byte(source))

	sign := base64.StdEncoding.EncodeToString(hmacObj.Sum(nil))

	return sign
}

func (c *Client) GetCredential(opt *CredentialOptions) (*CredentialResult, error) {
	if opt == nil || opt.Policy == nil {
		return nil, errors.New("CredentialOptions is illegal")
	}
	if opt.Policy.Version == "" {
		opt.Policy.Version = "2.0"
	}
	if opt.Region == "" {
		opt.Region = utils.Config.Tencent.CosRegion
	}
	if opt.DurationSeconds == 0 {
		opt.DurationSeconds = 1800
	}
	policy, err := json.Marshal(opt.Policy)
	if err != nil {
		return nil, err
	}
	rand.Seed(time.Now().UnixNano())
	params := map[string]interface{}{
		"SecretId":        c.SecretId,
		"Policy":          url.QueryEscape(string(policy)),
		"DurationSeconds": opt.DurationSeconds,
		"Region":          opt.Region,
		"Timestamp":       time.Now().Unix(),
		"Nonce":           rand.Int(),
		"Name":            "cos-sts-go",
		"Action":          "GetFederationToken",
		"Version":         "2018-08-13",
	}
	paramValues := url.Values{}
	for k, v := range params {
		paramValues.Add(fmt.Sprintf("%v", k), fmt.Sprintf("%v", v))
	}
	sign := c.signed("POST", params)
	paramValues.Add("Signature", sign)

	urlStr := "https://" + utils.Config.Tencent.CosHost
	resp, err := c.client.PostForm(urlStr, paramValues)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	result := &CredentialCompleteResult{}
	err = json.NewDecoder(resp.Body).Decode(result)
	if err == io.EOF {
		err = nil // ignore EOF errors caused by empty response body
	}
	if err != nil {
		return nil, err
	}
	if result.Response != nil && result.Response.Error != nil {
		result.Response.Error.RequestId = result.Response.RequestId
		return nil, result.Response.Error
	}
	if result.Response != nil && result.Response.Credentials != nil {
		result.Response.StartTime = result.Response.ExpiredTime - int(opt.DurationSeconds)
		return result.Response, nil
	}
	return nil, errors.New(fmt.Sprintf("GetCredential failed, result: %v", result.Response))
}

func GetTmpSecretKey(path string) (map[string]string, error) {
	appid := utils.Config.Tencent.CosAppid
	basePath := "/gogo/"
	if os.Getenv("GIN_CONFIG") == "staging" {
		basePath = "/gogo-staging/"
	}
	if path != "" {
		path = basePath + path + "/*"
	} else {
		path = basePath + "upload/*"
	}
	c := NewClient(
		utils.Config.Tencent.CosSecretId,
		utils.Config.Tencent.CosSecretKey,
		nil,
	)
	opt := &CredentialOptions{
		DurationSeconds: int64(time.Hour.Seconds()),
		Region:          utils.Config.Tencent.CosRegion,
		Policy: &CredentialPolicy{
			Statement: []CredentialPolicyStatement{
				{
					Action: []string{
						"name/cos:PostObject",
						"name/cos:PutObject",
						"name/cos:InitiateMultipartUpload",
						"name/cos:ListMultipartUploads",
						"name/cos:ListParts",
						"name/cos:UploadPart",
						"name/cos:CompleteMultipartUpload",
						"name/cos:AbortMultipartUpload",
					},
					Effect: "allow",
					Resource: []string{
						// 这里改成允许的路径前缀，可以根据自己网站的用户登录态判断允许上传的具体路径，例子： a.jpg 或者 a/* 或者 * (使用通配符*存在重大安全风险, 请谨慎评估使用)
						"qcs::cos:" + utils.Config.Tencent.CosRegion + ":uid/" + appid + ":" + utils.Config.Tencent.CosBucket + path,
					},
				},
			},
		},
	}
	mapResult := make(map[string]string)
	res, err := c.GetCredential(opt)
	if err != nil {
		return mapResult, err
	}
	if res.Error == nil {
		mapResult["bucket_name"] = utils.Config.Tencent.CosBucket   // 桶名称
		mapResult["bucket_region"] = utils.Config.Tencent.CosRegion // 地区
		mapResult["start_time"] = strconv.Itoa(res.StartTime)
		mapResult["expired_time"] = strconv.Itoa(res.ExpiredTime)
		mapResult["expiration"] = res.Expiration
		mapResult["request_id"] = res.RequestId
		mapResult["tmp_secret_id"] = res.Credentials.TmpSecretID
		mapResult["session_token"] = res.Credentials.SessionToken
		mapResult["tmp_secret_key"] = res.Credentials.TmpSecretKey
		mapResult["host"] = utils.Config.Tencent.CosBucketHost
		mapResult["path"] = strings.Replace(path, "*", "", 1)
	} else {
		return mapResult, res.Error
	}
	return mapResult, nil
}

func GetPresignedURL(filePath string) (fileURL string) {
	cosurl := "https://" + utils.Config.Tencent.CosBucket + ".cos." + utils.Config.Tencent.CosRegion + ".myqcloud.com"
	secretID := utils.Config.Tencent.CosSecretId
	secretKey := utils.Config.Tencent.CosSecretKey
	bucketURL, _ := url.Parse(cosurl)
	ctx := context.Background()
	client := cos.NewClient(&cos.BaseURL{BucketURL: bucketURL}, &http.Client{
		Transport: &cos.AuthorizationTransport{
			SecretID:  secretID,
			SecretKey: secretKey,
		},
	})
	// 获取预签名URL
	presignedURL, err := client.Object.GetPresignedURL(ctx, http.MethodGet, filePath, secretID, secretKey, time.Hour, nil)
	if err != nil {
		panic(err)
	}
	fileURL = strings.Replace(presignedURL.String(), cosurl, utils.Config.Tencent.CosBucketHost, 1)
	fileURL = strings.Replace(fileURL, "%2F", "/", -1)
	return
}
