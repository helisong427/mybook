package utils

import (
	"bytes"
	"net/http"
	"net/url"
	"time"
)

var HTTP_POST_TIMEOUT time.Duration = 10 // 10 seconds
var HTTP_GET_TIMEOUT time.Duration = 10  // 10 seconds

func httpRequest(method, reqUrl string, data []byte, headers map[string]string) (*http.Response, error) {
	req, err := http.NewRequest(method, reqUrl, bytes.NewBuffer(data))
	if err != nil {
		LogErrorF("[%s %s] 创建失败, %s", method, reqUrl, err.Error())
		return nil, err
	}

	for k, v := range headers {
		req.Header.Add(k, v)
	}

	client := &http.Client{
		Timeout: HTTP_POST_TIMEOUT * time.Second,
	}

	resp, err := client.Do(req)
	if err != nil {
		LogErrorF("对 [%s %s] 发起 client.Do() 操作失败, %s", method, reqUrl, err.Error())
		return nil, err
	}

	return resp, nil
}

func HttpGet(reqUrl string, values map[string][]string, headers map[string]string) (*http.Response, error) {
	// url query paramaters
	// https://golang.org/pkg/net/url/#Values
	urlV := url.Values{}
	for k, vs := range values {
		if len(vs) == 1 {
			urlV.Set(k, vs[0])
		} else if len(vs) > 1 {
			for _, v := range vs {
				urlV.Add(k, v)
			}
		}
	}

	req, err := http.NewRequest(http.MethodGet, reqUrl, nil)
	if err != nil {
		LogErrorF("生成 http get newrequest 失败, %s", err.Error())
		return nil, err
	}
	req.URL.RawQuery = urlV.Encode()

	for k, v := range headers {
		req.Header.Add(k, v)
	}

	client := &http.Client{
		Timeout: HTTP_GET_TIMEOUT * time.Second,
	}

	resp, err := client.Do(req)
	if err != nil {
		LogErrorF("", "发起get请求do[%s]失败, %s", reqUrl, err.Error())
		return nil, err
	}
	return resp, nil
}

func HttpPost(reqUrl string, data []byte, headers map[string]string) (*http.Response, error) {
	return httpRequest(http.MethodPost, reqUrl, data, headers)
}

func HttpPut(reqUrl string, data []byte, headers map[string]string) (*http.Response, error) {
	return httpRequest(http.MethodPut, reqUrl, data, headers)
}

func HttpDelete(reqUrl string, data []byte, headers map[string]string) (*http.Response, error) {
	return httpRequest(http.MethodDelete, reqUrl, data, headers)
}
