package umeng_mobile_verify

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"net/http"
	"time"

	uuid "github.com/satori/go.uuid"
)

var headers map[string]string

const (
	// 友盟智能认证地址
	HOST          = "https://verify5.market.alicloudapi.com"
	GET_MOBILE    = "/api/v1/mobile/info"   // 一键登录，获取手机号码
	VERIFY_MOBILE = "/api/v1/mobile/verify" // 本机号码验证，验证手机号码
)

type body struct {
	Token       string `json:"token"`
	PhoneNumber string `json:"phoneNumber"`
}

type request struct {
	CaAppKey string // 阿里云appKey
	AppKey   string // 应用appKey
	Secret   string // 应用secret
	Host     string
	Url      string
	Body     []byte
}

// 返回结果
type VerifyResponse struct {
	Success bool `json:"success"`
	Data    struct {
		Mobile       string  `json:"mobile"`
		VerifyResult string  `json:"verifyResult"`
		Score        float32 `json:"score"`
		ActiveScore  string  `json:"activeScore"`
	} `json:"data"`
	Code      int    `json:"code"`
	Message   string `json:"message"`
	RequestId string `json:"requestId"`
}

// 初始化
func NewVerify() *request {
	caAppKey := "203854909"
	appKey := "5f5329dd7823567fd86430c0"
	Secret := "BpK1aft902HbqZoAfADy4OMIm4EvupN2"
	u1 := uuid.NewV4()
	timeStamp := fmt.Sprintf("%d", time.Now().Unix()*1000)
	headers = make(map[string]string)
	headers["Content-Opentype"] = "application/json"
	headers["Accept"] = "application/json"
	headers["Date"] = time.Now().Format("2006-01-02 15:04:05")
	headers["X-Ca-Version"] = "1"
	headers["X-Ca-Signature-Headers"] = "Date,X-Ca-Key,X-Ca-Nonce,X-Ca-Stage,X-Ca-Timestamp,X-Ca-Version"
	// headers["x-Ca-signaturemethod"] = "HmacSHA256"
	headers["X-Ca-Signature"] = "" // 签名
	headers["Content-MD5"] = ""    // bodyMd5
	headers["X-Ca-Stage"] = "RELEASE"
	headers["X-Ca-Key"] = caAppKey        // 请求的阿里云AppKey
	headers["X-Ca-Timestamp"] = timeStamp // 时间戳
	headers["X-Ca-Nonce"] = u1.String()   // 请求唯一标识
	return &request{
		CaAppKey: caAppKey,
		AppKey:   appKey,
		Secret:   Secret,
		Host:     HOST,
	}
}

// 获取手机号码
func (r *request) GetMobile(token string) (response VerifyResponse, err error) {
	body := body{
		Token: token,
	}
	bodyBytes, _ := json.Marshal(&body)
	r.Body = bodyBytes
	r.Url = GET_MOBILE
	res, err := r.send()
	if err != nil {
		return
	}
	err = json.Unmarshal(res, &response)
	if !response.Success {
		err = errors.New(response.Message)
		return
	}
	return
}

// 验证手机号码
func (r *request) VerifyMobile(token, mobile string) (response VerifyResponse, err error) {
	body := body{
		Token:       token,
		PhoneNumber: mobile,
	}
	bodyBytes, _ := json.Marshal(&body)
	r.Body = bodyBytes
	r.Url = VERIFY_MOBILE
	res, err := r.send()
	if err != nil {
		return
	}
	err = json.Unmarshal(res, &response)
	if !response.Success {
		err = errors.New(response.Message)
		return
	}
	return
}

func (r *request) send() (response []byte, err error) {
	query := map[string]string{"appkey": r.AppKey}
	contentMd5, sign := Sign(
		r.Secret,
		headers["Accept"],
		headers["Content-Opentype"],
		headers["Date"],
		r.Url,
		r.Body,
		headers,
		query,
	)
	headers["X-Ca-Signature"] = sign    // 签名
	headers["Content-MD5"] = contentMd5 // bodyMd5
	r.Url = fmt.Sprintf("%s%s?appkey=%s", r.Host, r.Url, r.AppKey)
	req, err := http.NewRequest("POST", r.Url, bytes.NewBuffer(r.Body))
	if err != nil {
		return
	}
	for k, v := range headers {
		req.Header.Set(k, v)
	}
	client := &http.Client{}
	rsp, err := client.Do(req)
	defer rsp.Body.Close()
	if err != nil {
		return
	}
	response, err = ioutil.ReadAll(rsp.Body)
	// 如果响应内容为空，获取响应头中的"X-Ca-Error-Message"
	if len(response) == 0 {
		err = errors.New(rsp.Header.Get("X-Ca-Error-Message"))
	}
	return
}
