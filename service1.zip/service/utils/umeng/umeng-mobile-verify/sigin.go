package umeng_mobile_verify

import (
	"crypto/md5"
	"encoding/base64"
	"fmt"
	"sort"
	"strings"

	"gamers/utils"
)

// 获取签名
func Sign(secret string, accept string, contentType string, date string, url string, body []byte, headers map[string]string, query map[string]string) (contentMD5, sign string) {
	contentMD5 = contentSign(body)
	url = urlSign(url, query)
	header := headerSign(headers)
	sign = "POST" + "\n" + accept + "\n" + contentMD5 + "\n" + contentType + "\n" + date + "\n" + header + url
	// sign = "POST" + "\n" + "" + "\n" + contentMD5 + "\n" + "" + "\n" + ""+"\n" + url

	fmt.Println(sign)
	sign = utils.FuncHmacSha256(sign, secret)
	sign = base64.StdEncoding.EncodeToString([]byte(sign))
	return
}

// body参数签名
// md5的byte数组转base64
func contentSign(body []byte) string {
	h := md5.New()
	h.Write(body)
	return base64.StdEncoding.EncodeToString(h.Sum(nil))
}

func urlSign(url string, query map[string]string) string {
	str := url
	if len(query) > 0 {
		str += "?"
		for k, v := range query {
			if v != "" {
				str += k + "=" + v + "&"
			} else {
				str += k
			}
		}
		str = strings.TrimRight(str, "&")
	}
	return str
}

func headerSign(headers map[string]string) string {
	// 不参加签名的header
	noSignHeader := []string{
		"X-Ca-Signature",
		"X-Ca-Signature-Headers",
		"Accept",
		"Content-MD5",
		"Content-Opentype",
		// "Date",
		// "x-Ca-signaturemethod",
	}
	// 过滤不参加签名的参数
	for k := range headers {
		for _, val := range noSignHeader {
			if k == val {
				delete(headers, k)
			}
		}
	}

	// 按照字典排序
	keys := []string{}
	// 得到各个key
	for k := range headers {
		keys = append(keys, k)
	}
	// 排序
	sort.Strings(keys)

	var str string
	for _, v := range keys {
		for key, val := range headers {
			if v == key {
				str += v + ":" + val + "\n" // 拼接header
			}
		}
	}

	return str
}
