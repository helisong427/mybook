package umeng_push

import (
	"fmt"

	"gamers/utils"
)

// 签名生成规则:
// 提取请求方法method（POST,全大写）;
// 提取请求url信息,包括Host字段的域名(或ip:端口)和URI的path部分,注意不包括path的querystring,比如http://msg.umeng.com/api/send 或者 http://msg.umeng.com/api/status;
// 提取请求的post-body;
// 拼接请求方法、url、post-body及应用的app_secret;
// 将形成字符串计算MD5值,即为本次请求sign（签名）的值;sign=MD5($http_method$url$post-body$app_master_secret);
func Sign(url, body, secret string) string {
	s := "POST" + url + body + secret
	return utils.FuncMD5(s)
}

func UrlSign(url, body, secret string) string {
	sign := Sign(url, body, secret)
	return fmt.Sprintf("%s?sign=%s", url, sign)
}
