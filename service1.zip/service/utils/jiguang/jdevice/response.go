package jdevice

type JERROR struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

// 查询设备别名和tag响应
type QueryDeviceAliasAndTagResponse struct {
	Error  JERROR         `json:"error"`
	Tags   map[int]string `json:"tags"`
	Alias  string         `json:"alias"`
	Mobile string         `json:"mobile"`
}
