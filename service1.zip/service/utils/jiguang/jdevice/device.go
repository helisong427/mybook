package jdevice

import (
	"encoding/base64"
	"encoding/json"
	"net/http"
	"strings"

	"gamers/utils"
)

const (
	HOST                       = "https://device.jpush.cn"
	QUERT_DEVICE_ALIAS_AND_TAG = "/v3/devices/{registration_id}"
	SET_DEVICE_ALIAS_AND_TAG   = "/v3/devices/{registration_id}"
	BASE64_TABLE               = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
)

var base64Coder = base64.NewEncoding(BASE64_TABLE)

type DeviceClient struct {
	AppKey   string
	Secret   string
	AuthCode string
	BaseUrl  string
}

// NewDeviceClient 初始化
func NewDeviceClient() *DeviceClient {
	appKey := utils.Config.JiGuang.JPushAppKey
	secret := utils.Config.JiGuang.JPushSecret
	auth := "Basic " + base64Coder.EncodeToString([]byte(appKey+":"+secret))
	client := &DeviceClient{appKey, secret, auth, HOST}
	return client
}

// QueryDeviceAliasAndTag 查询设备别名和tag
func (d *DeviceClient) QueryDeviceAliasAndTag(registrationId string) (r *QueryDeviceAliasAndTagResponse, err error) {
	d.BaseUrl = d.BaseUrl + strings.ReplaceAll(QUERT_DEVICE_ALIAS_AND_TAG, "{registration_id}", registrationId)
	response, err := SendRequest(http.MethodGet, d.BaseUrl, d.AuthCode, nil)
	if err != nil {
		return
	}
	err = json.Unmarshal(response, &r)
	return
}

// SetDeviceAliasAndTag 设置设备别名和tag
func (d *DeviceClient) SetDeviceAliasAndTag(registrationId string, data SetDeviceAliasAndTagRequest) (err error) {
	d.BaseUrl = d.BaseUrl + strings.ReplaceAll(SET_DEVICE_ALIAS_AND_TAG, "{registration_id}", registrationId)
	dateBytes, _ := json.Marshal(data)
	_, err = SendRequest(http.MethodPost, d.BaseUrl, d.AuthCode, dateBytes)
	if err != nil {
		return
	}
	return
}
