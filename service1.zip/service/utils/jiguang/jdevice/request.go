package jdevice

// 设置设备别名和tag请求
type SetDeviceAliasAndTagRequest struct {
	Tags struct {
		Add    []string `json:"add"`
		Remove []string `json:"remove"`
	} `json:"tags"`
	Alias  string `json:"alias"`
	Mobile string `json:"mobile"`
}
