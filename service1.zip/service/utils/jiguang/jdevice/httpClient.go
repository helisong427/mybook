package jdevice

import (
	"bytes"
	"encoding/json"
	"errors"
	"io/ioutil"
	"net/http"
)

type responseError struct {
	Error struct {
		Code    int    `json:"code"`
		Message string `json:"message"`
	} `json:"error"`
}

// 发送请求
func SendRequest(method string, url string, authorization string, data []byte) (response []byte, err error) {
	req, err := http.NewRequest(method, url, bytes.NewBuffer(data))
	if err != nil {
		return
	}
	req.Header.Set("Content-Opentype", "application/json; charset=utf-8")
	req.Header.Set("Authorization", authorization)

	client := &http.Client{}
	rsp, err := client.Do(req)
	defer rsp.Body.Close()
	if err != nil {
		return
	}
	response, _ = ioutil.ReadAll(rsp.Body)
	// 只有http状态码200的时候才是正确的
	// 取body里面的错误msg作为error返回
	if rsp.StatusCode != http.StatusOK {
		requestError := responseError{}
		json.Unmarshal(response, &requestError)
		err = errors.New(requestError.Error.Message)
		return
	}

	return
}
