package utils

import (
	"crypto/hmac"
	"crypto/md5"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"math"
	"math/rand"
	"net"
	"os"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"gopkg.in/mgo.v2/bson"

	"github.com/gofrs/uuid"
)

// FuncRandInt 随机数字()
func FuncRandInt(max int) int64 {
	rand.Seed(time.Now().UnixNano())
	return int64(rand.Intn(max))
}

// FuncRandRangeInt 获取指定范围的随机数字
func FuncRandRangeInt(min int, max int) int64 {
	rand.Seed(time.Now().UnixNano())
	return int64(rand.Intn(max-min) + min)
}

// FuncRandString 随机字符串()
func FuncRandString(n int) string {
	var letterBytes = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
	const (
		letterIdxBits = 6
		letterIdxMask = 1<<letterIdxBits - 1
		letterIdxMax  = 63 / letterIdxBits
	)
	var src = rand.NewSource(time.Now().UnixNano())
	b := make([]byte, n)
	for i, cache, remain := n-1, src.Int63(), letterIdxMax; i >= 0; {
		if remain == 0 {
			cache, remain = src.Int63(), letterIdxMax
		}
		if idx := int(cache & letterIdxMask); idx < len(letterBytes) {
			b[i] = letterBytes[idx]
			i--
		}
		cache >>= letterIdxBits
		remain--
	}
	return string(b)
}

// FuncMD5 md5加密字符串
func FuncMD5(str string) string {
	hasher := md5.New()
	hasher.Write([]byte(str))
	return hex.EncodeToString(hasher.Sum(nil))
}

// Func16MD5 16位md5
func Func16MD5(str string) string {
	return FuncMD5(str)[8:24]
}

// FuncIPv42Int 把ip字符串转为数值
func FuncIPv42Int(ip string) (uint, error) {
	b := net.ParseIP(ip).To4()
	if b == nil {
		return 0, errors.New("invalid ipv4 format")
	}
	return uint(b[3]) | uint(b[2])<<8 | uint(b[1])<<16 | uint(b[0])<<24, nil
}

// FuncInt2IPv4 把数值转为ip字符串
func FuncInt2IPv4(i uint) (string, error) {
	if i > math.MaxInt64 {
		return "", errors.New("beyond the scope of ipv4")
	}
	ip := make(net.IP, net.IPv4len)
	ip[0] = byte(i >> 24)
	ip[1] = byte(i >> 16)
	ip[2] = byte(i >> 8)
	ip[3] = byte(i)
	return ip.String(), nil
}

// FuncFormatHTTP 格式网址
func FuncFormatHTTP(instr string) string {
	return strings.NewReplacer("http://", "//", "https://", "//", "HTTP://", "//", "HTTPS://", "//").Replace(instr)
}

// FuncRemoveHTML 去掉html标签
func FuncRemoveHTML(content []string) []string {
	reg := regexp.MustCompile(`<[^>]*>`)
	for key, value := range content {
		content[key] = reg.ReplaceAllString(value, "")
	}
	return content
}

// FuncGetContentImg 提取内容中的图片
func FuncGetContentImg(content string) []string {
	// reg := regexp.MustCompile(`(?i)<img[^>]*src\s*=\s*[\"|\'||\s]?(([^(\"|\'||\s|>)])*)[^>]*>`)
	imageReg := regexp.MustCompile(`(?i)<img [^>]*src=['"]([^'"]+)[^>]*>`)
	imagesArray := imageReg.FindAllString(content, -1)
	srcReg := regexp.MustCompile(`((?i)<img [^>]*src=['"])([^'"]+)([^>]*>)`)
	for key, value := range imagesArray {
		imagesArray[key] = srcReg.ReplaceAllString(value, "$2")
	}
	return imagesArray
}

// FuncHmacSha256 hmac sha256加密
func FuncHmacSha256(data string, secret string) string {
	h := hmac.New(sha256.New, []byte(secret))
	h.Write([]byte(data))
	return hex.EncodeToString(h.Sum(nil))
}

// FuncVerifyMobile 手机号验证
func FuncVerifyMobile(mobile string) bool {
	regular := "^(1[3-9])\\d{9}$"
	reg := regexp.MustCompile(regular)
	return reg.MatchString(mobile)
}

// FuncVerifyMobile 身份证号码验证
func FuncVerifyIdCard(idCard string) bool {
	idCardLen := strings.Count(idCard, "")
	if idCardLen-1 == 18 {
		regular18 := "^[1-9]\\d{5}(18|19|([23]\\d))\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$"
		reg := regexp.MustCompile(regular18)
		return reg.MatchString(idCard)
	} else {
		regular15 := "^[1-9]\\d{5}\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{2}[0-9Xx]$"
		reg := regexp.MustCompile(regular15)
		return reg.MatchString(idCard)
	}
}

// FuncUUID 获取uuid
func FuncUUID() string {
	u := uuid.Must(uuid.NewV4())
	return u.String()
}

// FuncPageParams 分页总页数
func FuncTotalPages(total int64, size int) (totalPages int) {
	totalPages = int(math.Ceil(float64(total) / float64(size)))
	return
}

// 获取offset
func FuncGetOffset(page, pageSize int) int {
	offset := (page - 1) * pageSize
	if offset <= 0 {
		offset = 0
	}
	return offset
}

// 威尔逊公式
// @param ups 好评
// @param downs 差评
func FuncWilson(ups, downs int64) float64 {

	// n 评论总数
	n := ups + downs
	if n == 0 {
		return 0
	}

	n1 := float64(n)
	// z represents the statistical confidence
	// z = 1.0 => ~69%, 1.96 => ~95% (default)
	z := 2.0
	p := float64(ups / n)

	zzfn := z * z / (4 * n1)

	return (p + 2.0*zzfn - z*math.Sqrt((zzfn/n1+p*(1.0-p))/n1)) / (1 + 4*zzfn)
}

// FuncSmsTimestamp 短信时间戳验证
func FuncSmsTimestamp(timestamp int) (err error) {
	now := time.Now()
	t := int64(timestamp)
	if t < now.Add(-60*time.Second).Unix() {
		err = errors.New("时间戳非法")
	}
	return
}

// FuncGetConstellation 获取星座
func FuncGetConstellation(month, day int) (star string) {
	switch {
	case month <= 0, month >= 13, day <= 0, day >= 32:
		star = "-1"
	case month == 1 && day >= 20, month == 2 && day <= 18:
		star = "水瓶座"
	case month == 2 && day >= 19, month == 3 && day <= 20:
		star = "双鱼座"
	case month == 3 && day >= 21, month == 4 && day <= 19:
		star = "白羊座"
	case month == 4 && day >= 20, month == 5 && day <= 20:
		star = "金牛座"
	case month == 5 && day >= 21, month == 6 && day <= 21:
		star = "双子座"
	case month == 6 && day >= 22, month == 7 && day <= 22:
		star = "巨蟹座"
	case month == 7 && day >= 23, month == 8 && day <= 22:
		star = "狮子座"
	case month == 8 && day >= 23, month == 9 && day <= 22:
		star = "处女座"
	case month == 9 && day >= 23, month == 10 && day <= 22:
		star = "天秤座"
	case month == 10 && day >= 23, month == 11 && day <= 21:
		star = "天蝎座"
	case month == 11 && day >= 22, month == 12 && day <= 21:
		star = "射手座"
	case month == 12 && day >= 22, month == 1 && day <= 19:
		star = "魔蝎座"
	}
	return
}

// FuncGetAge 获取年龄
func FuncGetAge(birthday int) (age int) {
	if birthday > 0 {
		t := time.Unix(int64(birthday), 0)
		birYear := t.Year()
		birMonth := int(t.Month())
		age = time.Now().Year() - birYear
		if int(time.Now().Month()) < birMonth {
			age--
		}
	}
	return
}

func FuncGenerateDataId() string {
	id := bson.NewObjectId().Hex()
	return id
}

// FuncUserIdToUint 用户id转int64
// 适用于解析http请求中的用户id
func FuncUserId(c *gin.Context) int64 {
	userId, _ := c.Get("userID")
	userIdInt, _ := strconv.ParseInt(userId.(string), 10, 64)
	return userIdInt
}

// 获取常用时间
func GenerateTime() int64 {
	now := int64(time.Now().Unix())
	return now
}

var MAX_ONE_PAGE_SIZE = 20

type PageSearchReq struct {
	Page int `form:"page" binding:"required"`
	Size int `form:"size" binding:"required"`
}

type TimeSearchReq struct {
	StartT int64 `form:"start_t"`
	EndT   int64 `form:"end_t"`
}

// 获取分页查询参数
func GetPageAndSize(c *gin.Context) (page, size, skip int, err error) {
	paramsJSON := PageSearchReq{}
	err = c.ShouldBind(&paramsJSON)
	if err != nil {
		return
	}
	page = paramsJSON.Page
	size = paramsJSON.Size

	if page < 1 {
		page = 1
	}

	if size > MAX_ONE_PAGE_SIZE {
		size = MAX_ONE_PAGE_SIZE
	}

	skip = (page - 1) * size

	return
}

// 时间查询
func GetSTAndETTime(c *gin.Context) (startT int64, endT int64, err error) {
	paramsJSON := TimeSearchReq{}
	err = c.ShouldBind(&paramsJSON)
	if err != nil {
		return
	}
	et := time.Now().Unix()
	st := et - 60*60*24*30

	if paramsJSON.StartT <= 0 {
		startT = st
	} else {
		startT = paramsJSON.StartT
	}
	if paramsJSON.EndT <= startT {
		endT = et
	} else {
		endT = paramsJSON.EndT
	}
	return
}

func GenerateTips(seconds int) interface{} {
	day := seconds / (60 * 60 * 24)
	checkTime := time.Now().AddDate(0, 0, day).Format("2006-01-02")
	tip := struct {
		Tips string `json:"tips"`
	}{Tips: "提交成功，您的信息将在" + checkTime + "之前审核完成"}
	return tip
}

func GetExpiredByDay() (expire time.Duration) {
	t0 := time.Now()
	tm1 := time.Date(t0.Year(), t0.Month(), t0.Day(), 0, 0, 0, 0, t0.Location())
	tm2 := tm1.AddDate(0, 0, 0)
	expired := int(60*60*24 - (t0.Unix() - tm2.Unix()))
	expire = time.Duration(expired) * time.Second
	return expire
}

// 随机返回指定数量的切片
func FuncRandSlice(original []int, amount int) (randData []int) {
	originalLen := len(original)
	if originalLen == 0 {
		return
	}
	// 切片长度小于要获取的数量
	// 以切片长度为准
	if originalLen < amount {
		amount = originalLen
	}
	if originalLen == amount {
		randData = original
		return
	}
	for {
		if amount == 0 {
			return
		}
		randKey := FuncRandRangeInt(0, originalLen-1)
		if FuncKeyIsSlice(original, int(randKey)) {
			if !FuncValueIsSlice(randData, original[randKey]) {
				randData = append(randData, original[randKey])
				amount--
			}
		}
	}
}

// key是否存在切片中
func FuncKeyIsSlice(slice []int, key int) (isIn bool) {
	for k := range slice {
		if k == key {
			isIn = true
			return
		}
	}
	return
}

// value是否存在切片中
func FuncValueIsSlice(slice []int, value int) (isIn bool) {
	for _, v := range slice {
		if v == value {
			isIn = true
			return
		}
	}
	return
}

// 获取当月第一天时间戳
func GetMonthFirstDayTimeStamp() (t int64) {
	t0 := time.Now()
	tm1 := time.Date(t0.Year(), t0.Month(), t0.Day(), 0, 0, 0, 0, t0.Location())
	tm2 := tm1.AddDate(0, 0, 0)
	// expired := int(60*60*24 - (t0.Unix() - tm2.Unix()))
	t = tm2.AddDate(0, 0, -tm2.Day()+1).Unix()
	return t
}

// 消息提示时间格式化
func MsgTimeFormatDay(tmNum int64) string {
	tm := time.Unix(tmNum, 0)
	tmStr := fmt.Sprintf("%d-%d-%d", tm.Year(), tm.Month(), tm.Day())
	return tmStr
}

// 消息提示时间格式化
func MsgTimeFormatHour(tmNum int64) string {
	tm := time.Unix(tmNum, 0)
	tmStr := fmt.Sprintf("%d-%d-%d %d:00", tm.Year(), tm.Month(), tm.Day(), tm.Hour()+1)
	return tmStr
}

// 消息提示时间格式化
func MsgTimeFormatSecond(tmNum int64) string {
	tm := time.Unix(tmNum, 0)
	tmStr := fmt.Sprintf("%d-%d-%d %d:%d:%d", tm.Year(), tm.Month(), tm.Day(), tm.Hour(), tm.Minute(), tm.Second())
	return tmStr
}

// 打乱切片
func FuncShuffle(slice []interface{}) {
	r := rand.New(rand.NewSource(time.Now().Unix()))
	for len(slice) > 0 {
		n := len(slice)
		randIndex := r.Intn(n)
		slice[n-1], slice[randIndex] = slice[randIndex], slice[n-1]
		slice = slice[:n-1]
	}
}

// FuncEnv 获取当前运行环境,返回是否正式和预发布环境bool
func FuncEnv() (isProd bool) {
	conf := os.Getenv("GIN_CONFIG")
	if conf == "" || conf == "debug" || conf == "test" || conf == "staging" {
		isProd = false
	} else {
		isProd = true
	}
	return
}

// FuncGetIp 获取ipv4
func FuncGetIpv4(c *gin.Context) uint {
	ip := c.ClientIP()
	ipv4, _ := FuncIPv42Int(ip)
	return ipv4
}

// FuncRound 四舍五入
// 返回将 val 根据指定精度 precision（十进制小数点后数字的数目）进行四舍五入的结果。precision 也可以是负数或零。
func FuncRound(val float64, precision int) float64 {
	p := math.Pow10(precision)
	return math.Floor(val*p+0.5) / p
}

// 获取分页 跳过数
func GetOffset(page, pageSize int) int {
	offset := (page - 1) * pageSize
	if offset <= 0 {
		offset = 0
	}

	return offset
}

func FuncManageIdToUint(c *gin.Context) uint64 {
	manageIdInt, _ := c.Get("manageId")
	manageID, _ := manageIdInt.(uint64)
	return manageID
}
