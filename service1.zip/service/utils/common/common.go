package common

import (
	"bytes"
	"crypto/md5"
	"crypto/tls"
	"encoding/hex"
	"encoding/json"
	"io/ioutil"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"

	"gamers/models/dbmodels"
)

// 前端查询分页参数
type WebPagination struct {
	Page int `form:"page"  binding:"gt=0"` // 第几页
	Size int `form:"size"  binding:"gt=0"` // 每页数量
}

// @comment MD5加密
func Md5(str []byte) string {
	h := md5.New()
	h.Write(str)
	cipherStr := h.Sum(nil)
	return hex.EncodeToString(cipherStr)
}

type eck struct {
	Key   int64  `json:"key"`
	Title string `json:"title"`
}

// 根据游戏id查询游戏的价格单位和key
func GetGamePriceByGameId(gameId int64) (result []eck, err error) {
	game := dbmodels.AppGame{}
	data, err := game.QueryByGameId(gameId)
	if err != nil {
		return
	}
	type kv struct {
		Key   int64  `json:"key"`
		Title string `json:"title"`
	}
	type tkv struct {
		Title string `json:"title"`
		Value []kv   `json:"value"`
	}
	m := make(map[string]*tkv)
	err = json.Unmarshal([]byte(data.GameParam), &m)
	if err != nil {
		return
	}
	on := eck{}
	for k, v := range m {
		if k == "SkillPrice" {
			for _, val := range v.Value {
				on.Key = val.Key
				on.Title = val.Title
				result = append(result, on)
			}
		}
	}
	return
}

func FormPost(url string, data url.Values) ([]byte, error) {
	u := strings.NewReader(data.Encode())
	tr := &http.Transport{
		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
	}
	client := &http.Client{Transport: tr}
	defer client.CloseIdleConnections()
	r, err := client.Post(url, "application/x-www-form-urlencoded", u)
	if err != nil {
		return []byte(""), err
	}
	defer r.Body.Close()
	b, err := ioutil.ReadAll(r.Body)
	if err != nil {
		return []byte(""), err
	}
	return b, err
}

type TagRequest struct {
	Url  string
	Body string
}

// 发送post请求
func Post(url string, data []byte) (response []byte, err error) {
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(data))
	if err != nil {
		return
	}
	req.Header.Set("Content-Opentype", "application/json")

	client := &http.Client{}
	rsp, err := client.Do(req)
	defer rsp.Body.Close()
	if err != nil {
		return
	}

	response, _ = ioutil.ReadAll(rsp.Body)

	return
}

// 从go币名称获取数量
// eg: 50GO币 --> 50
func RegexpGogoProp(GogoPropName string) int64 {
	re := regexp.MustCompile("[0-9]+")
	if len(re.FindAllString(GogoPropName, -1)) < 1 {
		return 0
	}
	c, _ := strconv.Atoi(re.FindAllString(GogoPropName, -1)[0])
	return int64(c)
}

// 返回较大数
func Max(x, y int) int {
	if x > y {
		return x
	}
	return y
}
