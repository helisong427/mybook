package test

import (
	"errors"
	"fmt"
	"github.com/guonaihong/gout"
	"net/http"
	"sync"
	"testing"
	"time"
)

var AccessToken = "eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJJRCI6Mzc4NDc4OTAsIkFUSSI6ImFjNzQ4ODhmOGY3YjYxYWU1Y2U3ZDgxODE3N2ZjOTNhIiwiU3ViamVjdCI6IjEiLCJleHAiOjE1OTk3ODk5MDUsImlhdCI6MTU5OTc4OTkwMiwibmJmIjoxNTk5Nzg5OTAxfQ.D49jhTzhsvbkrUOx47ZDZenrfqj12EEZbQ9UAyeyHfPrvYF5hV5977wGwtXmTRHIEv0kYXxcKfM-1OY6r4xhPQ"
var RefreshToken = "eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJJRCI6ODYzNjA5MzcsIkFUSSI6IjlmMTZiZjFkOGExZmM2ZmE5YjBlOWI0ZjI4MWU0MmI5IiwiU3ViamVjdCI6IjEiLCJleHAiOjE2MDEwODU5MDIsImlhdCI6MTU5OTc4OTkwMiwibmJmIjoxNTk5Nzg5OTAxfQ.eARpHqH9ag--ENeB-VktTFCRa2EcIUGiSLSe6iJeLT_EKLjT6hdo0f5M1r2ifmuTJVoJ2MUlioOdSdoDCgvf6g"

func detail() error {
	var err error
	req, _ := http.NewRequest(http.MethodGet, "http://127.0.0.1:3000/tweet/detail?id=3", nil)
	req.Header.Set("Access-Token", AccessToken)
	req.Header.Set("Refresh-Token", RefreshToken)
	client := &http.Client{}
	response, err := client.Do(req)
	defer response.Body.Close()
	if err != nil {
		panic(err)
	}
	if response.StatusCode == http.StatusInternalServerError {
		fmt.Println("Access-Token = ", AccessToken)
		fmt.Println("Refresh-Token =", RefreshToken)
		err = errors.New("500错误")
	} else {
		Accesstoken := response.Header.Get("Access_token")
		RefreshToken := response.Header.Get("Refresh-Token")
		if Accesstoken != "" && RefreshToken != "" {
			fmt.Println("Access_token = ", AccessToken)
			fmt.Println("Refresh-Token =", RefreshToken)
		}
	}
	return err
}

func TestDetails(t *testing.T) {
	for i := 0; i <= 100; i++ {
		err := detail()
		if err != nil {
			t.Errorf("第%d次循环,错误：%s\n", i, err.Error())
		}
		time.Sleep(time.Second * 1)
	}
}

//上下麦位
func TestUpAndDownWheat(t *testing.T) {
	type Body struct {
		RoomId         int `json:"room_id"`
		WheatKey       int `json:"wheat_key"`
		UpAndDownWheat int `json:"up_and_down_wheat"`
	}
	header := make(map[string]string)
	header["Access-Token"] = "eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJJRCI6NzEwODQzMDAsIkFUSSI6ImRiMThkNDAwNjc3ZTQ4ZmE2ZWUyOTMyY2E4ODczNDVmIiwiU3ViamVjdCI6IjIiLCJUeXBlIjoiIiwiZXhwIjoxNjE1NDQ2NTY4LCJpYXQiOjE2MTU0NDQ3NjgsIm5iZiI6MTYxNTQ0NDc2N30.7S17oed8iPZ9sQD-y8U7V_OeKFSo7XpGbDqvpMLJPpcXi1qW8qrbrOrCje_M7IKdx_Bx4466YP-8hzuxU5h1lA"

	wa := sync.WaitGroup{}
	for i := 1; i <= 8; i++ {
		wa.Add(1)
		go func(i int) {
			defer wa.Done()
			body := Body{
				RoomId:         125,
				WheatKey:       i,
				UpAndDownWheat: 1,
			}
			err := gout.POST("http://127.0.0.1:30000/live/up-and-down-wheat").Debug(true).SetHeader(header).SetJSON(body).Do()
			if err != nil {
				fmt.Println(err)
			}
		}(i)
	}
	wa.Wait()

}
