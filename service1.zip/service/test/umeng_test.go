package test

import (
	umeng_mobile_verify "gamers/utils/umeng/umeng-mobile-verify"
	"gamers/utils/umeng/umeng-push"
	"testing"
)

//发送安卓单播
func TestPushAndroidUnicast(t *testing.T) {
	res, err := umeng_push.NewPush().SendAndroidUnicast("标题", "内容", "打开app", map[string]string{"123": "321"}, "123456")
	if err != nil {
		t.Error(err)
		return
	}
	t.Log("发送成功")
	t.Log(res)
}

func TestPushIOSUnicast(t *testing.T) {
	res, err := umeng_push.NewPush().SendIOSUnicast("标题", "内容", map[string]string{"key1": "val1", "key2": "val2", "key3": "val3"}, "123456")
	if err != nil {
		t.Error(err)
		return
	}
	t.Log("发送成功")
	t.Log(res)
}

func TestTagList(t *testing.T) {
	res, err := umeng_push.NewPushTag().TagList("123456")
	if err != nil {
		t.Error(err)
		return
	}
	t.Log("发送成功")
	t.Log(res)
}

func TestVerify(t *testing.T) {
	res, err := umeng_mobile_verify.NewVerify().GetMobile("123456")
	if err != nil {
		t.Error(err)
		return
	}
	t.Log("发送成功")
	t.Log(res)
}
