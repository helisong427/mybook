package test

import (
	"fmt"
	"gamers/controller/request"
	"gamers/controller/services"
	"gamers/utils"
	"testing"
)

func InitConfig(conf string) {
	utils.ConfigInitLocal(conf)
	// 初始化日志
	utils.LoggerInit()
	utils.GDBInit()
	utils.RedisInit()
}

func TestSparringList(t *testing.T) {
	InitConfig("test")

	data, _ := services.SparringList(request.SparringListReq{
		BasePageReq: request.BasePageReq{
			Page: 1,
			Size: 10,
		},
		SkillId:        1,
		Sex:            0,
		SelectOnline:   0,
		OtherCondition: "",
	}, 1)

	fmt.Println(data)
}
