package test

import (
	"fmt"
	"gamers/controller"
	"testing"
)

const (
	tweetPopularCountF float64 = -1 //发布时间与当前时间差 + e
)

//func TestTest(T *testing.T) {
//	fmt.Println((float64(time.Now().Unix())-float64(1618452072))/86400+tweetPopularCountF)
//}

func TestTest(T *testing.T) {
	controller.CheckRechargeParams("1", "recharge_wap")
	fmt.Println("aa")
}
