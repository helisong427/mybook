package test

import (
	"encoding/json"
	"gamers/controller/services"
	"gamers/models/dbmodels"
	"gamers/mq/kafkaConsumer"
	"testing"
)

// 公会提现
func TestUnionWithdrawal(t *testing.T) {
	order := dbmodels.AppSkillOrder{
		OrderId:              1014012328,
		OrderBuyUserId:       1006081128,
		OrderBuyUserUnionId:  21,
		OrderSellUserId:      1006081710,
		OrderSellUserUnionId: 17,
		OrderSkillId:         1,
		OrderSparringSkillId: 67,
		OrderPrice:           10000,
		OrderAmount:          10000,
		OrderUnionFee:        99,
		OrderFee:             66,
	}
	err := services.NewSkillOrder().Settle.System(order)
	if err != nil {
		t.Errorf("失败:%s", err.Error())
		return
	}
	t.Log("ok")
}

// 送礼
func TestGift(t *testing.T) {
	form := services.SendPropInfoToMq{}
	str := "{\"send_prop_req\":{\"room_id\":100000,\"prop_id\":137,\"backpack_id\":0,\"prop_count\":1,\"prop_source\":1,\"receiver_ids\":[1006742301]},\"live_room\":{\"room_id\":100000,\"room_pretty_id\":666,\"room_type\":0,\"room_name\":\"贺山峰的房间\",\"room_cover\":\"https://testcdn1.chatgogo.cn/gogo/upload/avatar/0635ffdb4d1be31c3fd75bf9edb37935_1006742103_1616987611949.jpeg\",\"room_background\":\"https://testcdn1.chatgogo.cn/gogo/upload/sys/BG_A_01.jpg\",\"room_title\":\"\",\"room_content\":\"我用用哦\",\"room_union_id\":0,\"room_user_id\":1006742103,\"room_password\":\"\",\"room_old_attr_id\":3,\"room_attr_id\":1,\"room_speak_type\":1,\"room_open_im\":1,\"room_live_status\":1,\"room_last_online\":1617071363,\"room_last_offline\":1617070942,\"room_log_id\":4073,\"room_status\":0,\"system_user\":{\"UserID\":1006742103,\"UserPrettyId\":666666,\"UserWechat\":\"\",\"UserQQ\":\"\",\"UserParentID\":0,\"UserMobile\":\"18302842579\",\"UserPassword\":\"0235d4f67d20cc300d51cd794170d7cf\",\"UserSalt\":\"LUOHDVCRQiV5EF9j\",\"UserNickname\":\"贺山峰\",\"UserRealname\":\"\",\"UserGender\":1,\"UserConstellation\":\"白羊座\",\"UserBirthday\":1048647482,\"UserIconurl\":\"https://testcdn1.chatgogo.cn/gogo/upload/avatar/c1cf09ca35189b3d744ac72ade2a4ddc_1006742103_1616729896311.jpg\",\"UserIconurlVerification\":1,\"UserCountryID\":0,\"UserProvinceID\":0,\"UserCityID\":0,\"UserRegionID\":0,\"UserRegIP\":3232235692,\"UserRegPlatform\":0,\"UserRegChannel\":1,\"UserRegPoint\":0,\"UserSound\":\"\",\"UserSoundTime\":0,\"UserSlogan\":\"\",\"UserGameSavor\":\"\",\"UserLiveSavor\":\"\",\"UserBackImage\":\"\",\"UserLongitude\":104.06176,\"UserLatitude\":30.540333,\"UserStatus\":0,\"UserSkillOrderCount\":1,\"UserIsSparring\":1,\"UserIsAnchor\":1,\"UserIsSuper\":0,\"UserYouthStatus\":0,\"UserYouthPassword\":\"\",\"UserIsOnline\":1,\"UserGameOrder\":\"\",\"UserEggbreakMsg\":0,\"UserLastLoginTime\":1617014361,\"UserUnionId\":0,\"UserIsRecharge\":0,\"BaseModel\":{\"created\":1616727478,\"edited\":1617071361}},\"AppUnion\":{\"UnionId\":0,\"UnionName\":\"\",\"UnionUserId\":0,\"UnionCode\":0,\"UnionInviteKey\":\"\",\"union_gift_scale\":0,\"union_skill_scale\":0,\"UnionTaxFee\":0,\"UnionRoomCount\":0,\"UnionMobile\":\"\",\"UnionIdcode\":\"\",\"UnionExtractType\":0,\"UnionExtractAccount\":\"\",\"UnionExtractBank\":\"\",\"UnionExtractCompany\":\"\",\"created\":0,\"edited\":0},\"room_live_attr\":{\"attr_id\":1,\"attr_name\":\"唱歌\",\"attr_type\":0,\"attr_sort\":1,\"attr_directions\":\"\",\"attr_demand\":\"\",\"attr_is_show\":1,\"attr_background\":\"[\\r\\n\\\"https://testcdn1.chatgogo.cn/gogo/upload/sys/BG_A_01.jpg\\\",\\r\\n\\\"https://testcdn1.chatgogo.cn/gogo/upload/sys/BG_A_02.jpg\\\",\\r\\n\\\"https://testcdn1.chatgogo.cn/gogo/upload/sys/BG_A_03.jpg\\\",\\r\\n\\\"https://testcdn1.chatgogo.cn/gogo/upload/sys/BG_A_04.jpg\\\",\\r\\n\\\"https://testcdn1.chatgogo.cn/gogo/upload/sys/BG_A_05.jpg\\\",\\r\\n\\\"https://testcdn1.chatgogo.cn/gogo/upload/sys/BG_A_06.jpg\\\",\\r\\n\\\"https://testcdn1.chatgogo.cn/gogo/upload/sys/BG_A_07.jpg\\\",\\r\\n\\\"https://testcdn1.chatgogo.cn/gogo/upload/sys/BG_A_08.jpg\\\"\\r\\n]\",\"attr_default\":0,\"base_model\":{\"created\":0,\"edited\":0}},\"room_eggbreak_msg\":0,\"RoomAttachHeat\":0,\"RoomHeat\":0},\"prop\":{\"prop_id\":137,\"prop_name\":\"告白气球\",\"prop_type\":1,\"prop_class\":0,\"prop_attr_id\":10,\"prop_level\":0,\"prop_price\":18800,\"prop_org_price\":18800,\"PropVipLevel\":0,\"prop_wealth\":188,\"prop_charm\":188,\"prop_interval\":0,\"prop_get_max\":0,\"prop_radio_count_1\":0,\"prop_radio_count_2\":0,\"prop_radio_count_3\":52,\"prop_icon\":\"https://testcdn1.chatgogo.cn/gogo/upload/prop/1612344321000.png\",\"prop_url\":\"https://testcdn1.chatgogo.cn/gogo/upload/prop/1612344330000.svga\",\"prop_url1\":\"\",\"prop_quick_count\":\"[52,99,520,999]\",\"prop_start_time\":0,\"prop_end_time\":0,\"prop_special_level\":3,\"prop_get_radio_1\":0,\"prop_expired_type\":0,\"prop_expired_time\":0,\"prop_add_icon\":\"\",\"prop_remark\":\"\",\"prop_sort\":130,\"prop_status\":0},\"receivers\":[{\"user_info\":{\"user_id\":1006742301,\"user_pretty_id\":123456,\"icon\":\"https://testcdn1.chatgogo.cn/gogo/upload/avatar/(null)_1616728405000.jpg\",\"icon_style\":{\"icon_id\":0,\"bg_url\":\"\",\"end_t\":0},\"come_in_style\":{\"come_in_id\":0,\"bg_url\":\"\",\"pet_url\":\"\",\"end_t\":0},\"chat_style\":{\"chat_id\":0,\"bg_url\":\"\",\"end_t\":0},\"nick_name\":\"饺子🥟\",\"gender\":1,\"role\":0,\"is_super\":0,\"vip_level\":25,\"jue_level\":0,\"fans_level\":0,\"user_union_id\":126,\"age\":18},\"prop_info\":{\"prop_id\":137,\"prop_type\":1,\"prop_icon\":\"https://testcdn1.chatgogo.cn/gogo/upload/prop/1612344321000.png\",\"prop_name\":\"告白气球\",\"prop_class\":0,\"prop_attr_id\":10,\"prop_level\":0,\"prop_special_level\":3,\"prop_add_icon\":\"\",\"prop_url\":\"https://testcdn1.chatgogo.cn/gogo/upload/prop/1612344330000.svga\",\"prop_count\":1},\"love_value\":0,\"position\":1,\"user_income\":7520,\"union_income\":0}],\"send_id\":1006742103,\"send_time\":1617071474,\"love_num\":0}\n"
	err := json.Unmarshal([]byte(str), &form)
	if err != nil {
		t.Error(err)
		return
	}
	//form.Receivers = append(form.Receivers, &redismodels.MsgPropObj{
	//	redismodels.MsgUserObj{
	//		UserId:      1,
	//		Icon:        "",
	//		IconStyle:   redismodels.IconStyle{},
	//		ComeInStyle: redismodels.ComeInStyle{},
	//		ChatStyle:   redismodels.ChatStyle{},
	//		NickName:    "",
	//		Gender:      0,
	//		Role:        0,
	//		IsSuper:     0,
	//		VipLevel:    0,
	//		JueLevel:    0,
	//		FansLevel:   0,
	//		UserOver:    0,
	//		UserUnionId: 22,
	//		UserSlogan:  "",
	//		Age:         0,
	//	},
	//	redismodels.PropInfo{},
	//	0,
	//	0,
	//	100,
	//	99,
	//})

	kafkaConsumer.UpdateAnchorIncome(&form)
}

func TestLiaoyiliaoDailyMsg(t *testing.T) {
	services.LiaoyiliaoDailyMsg(100)
	services.LiaoyiliaoDailyMsg(1000)
}
