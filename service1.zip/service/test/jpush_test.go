package test

import (
	"gamers/utils/jiguang/jdevice"
	jpushclient "github.com/ylywyn/jpush-api-go-client"
	"testing"
)

func TestPush(t *testing.T) {

	pf := jpushclient.Platform{}
	pf.AddAndrid()
	pf.AddIOS()

	var ad jpushclient.Audience
	tags := []string{"tag1", "tag2"}
	ad.SetTag(tags)

	msg := jpushclient.Message{
		Content: "内容",
		Title:   "标题",
	}

	client := jpushclient.NewPushClient("xxx", "xxx")
	payload := jpushclient.NewPushPayLoad()
	payload.SetMessage(&msg)
	payload.SetPlatform(&pf)
	payload.SetAudience(&ad)

	bytes, _ := payload.ToBytes()
	t.Log(string(bytes))
	str, err := client.Send(bytes)
	if err != nil {
		t.Error(err)
		return
	}
	t.Log(str)

}

func TestQueryTag(t *testing.T) {
	client := jdevice.NewDeviceClient()
	r, err := client.QueryDeviceAliasAndTag("xxx")
	if err != nil {
		t.Error(err)
		return
	}
	t.Log(r)
}
