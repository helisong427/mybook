package test

import (
	"gamers/utils"
)

func init() {
	// utils.Config = &config.FileConfig{}
	// reportConfig := mysql.New(mysql.Config{
	// 	DSN:               "root:vspnmysql123dev@tcp(192.168.0.12:3306)/gamers?charset=utf8&parseTime=True&loc=Local",
	// 	DefaultStringSize: 1024, // string 类型字段的默认长度
	// })
	// var err error
	// utils.GEngine, err = gorm.Open(reportConfig, &gorm.Config{
	// 	QueryFields: true,
	// })
	// utils.GEngine.Debug()
	//
	// if err != nil {
	// 	fmt.Println("初始化主数据库失败" + err.Error())
	// 	return
	// }
	// conf := os.Getenv("GIN_CONFIG")
	// if conf == "" {
	// 	conf = "test"
	// }
	//
	// utils.ConfigInitLocal(conf)
	// // 初始化日志
	// utils.LoggerInit()
	// utils.GDBInit()
	// utils.RedisInit()
}

func Init(conf string) {
	utils.ConfigInitLocal(conf)
	// 初始化日志
	utils.LoggerInit()
	utils.GDBInit()
	utils.RedisInit()
}
