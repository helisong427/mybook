package test

import (
	"github.com/iGoogle-ink/gopay"
	"github.com/iGoogle-ink/gopay/alipay"
	"github.com/iGoogle-ink/gopay/wechat"
	"github.com/iGoogle-ink/gotil"
	"testing"
)

func TestWheatPlaceOrder(T *testing.T) {
	client := wechat.NewClient("wx4098cf3902167ebe", "1604493650", "902167ebe098cx40eb8cx48cx40eb0e1", true)
	client.DebugSwitch = gopay.DebugOn
	bm := make(gopay.BodyMap)
	bm.Set("nonce_str", gotil.GetRandomString(32)).
		Set("body", "H5支付").
		Set("out_trade_no", 123456).
		Set("total_fee", 1).
		Set("spbill_create_ip", "127.0.0.1").
		Set("notify_url", "http://www.gopay.ink").
		Set("trade_type", wechat.TradeType_App).
		Set("device_info", "WEB").
		Set("sign_type", wechat.SignType_MD5).
		SetBodyMap("scene_info", func(bm gopay.BodyMap) {
			bm.SetBodyMap("h5_info", func(bm gopay.BodyMap) {
				bm.Set("type", "Wap")
				bm.Set("wap_url", "http://www.gopay.ink")
				bm.Set("wap_name", "H5测试支付")
			})
		})
	order, err := client.UnifiedOrder(bm)
	if err != nil {
		T.Error(err)
		return
	}
	T.Log(order)
}

func TestAliPayPlaceOrder(T *testing.T) {
	client := alipay.NewClient("2021002114650349", "MIIEogIBAAKCAQEAiM1p+rpNXJBKzX+7PkI7hlR6j9Hf5vpnDB4JdUuhFRVWjrdM/GhSWZT1627T8abWrs1Rnd+Brs4SifkaXBWLIJq/6V2GdxYkzt6rpVIKwjlulqD0zSndYb3sFvx/Se1Rji42sahrA3i36vp2dGB9AMUIUcvspSpKC9oNuGiu9x1y7Cx4KNMZ8oCIXslP2aq73sg0XSrN/ysTyaw/XPxZAl9XSJgzCiaXgR5YibgZDx94Dzk/drpIIFpRV7glelLU//mfIDe0lAlhO0IKOTn4Nt4NOu5qtaGza+ye2u/PbzLfzUY0kZD6qcbn44XONgPfGLclvgFkvMuGUUzL72ZB1wIDAQABAoIBAAtGKnrAScncFl4TLcI2wSMT6TnbCQHHFyD3hL4G6pKLPKPsVUrj6g156j5p1suufTjQsO460jwuvXZjchmuqNWaC0DXNVKxH31w+mJYfYx+ITAGucYCsjzw4vkN/AuCpFr8UgOYJqGVnEqgM4zpusOKeWIMVUdTUeDiKolND0ZMJwE9lLrDLN1czq1kQV72fPLfAKaDswXiCwfpfbXW/x3vpfOxr19U9Zm0ox8PA3M1I7rL3MVTHVJvSSFnZrgiUgCqeEX2a7XQpnsCZcz2nR3KjhjgdQkhYAuDDX6MnqluQ7KtgoLSLe7oJyiNG9l/mCwOmXPm1/UQlTTU+TUGnMECgYEAzuNY2YJe7Lye9k7WzOyS6McQZaTluRb/7tvcPGpw30pocIJfR2Ig5h69ctAlV9XAy3V2EuAMGe2spOF9PGFXny64XL4b80D1PW3v9z5iuB/W+gs4X+s4/Ef/70DEbyBqASBsIE9SWhnSSzv0SoS0w8sGA7jNG3tRmkImwuf4rPcCgYEAqUbwP/qXRO6DrAb9/j8916xcxwRH2ktrCqwX4r+CqU9d52vx9i2TawNhYSpUBbRjgwj6motnqwUZepDXy05NiQCttdNn2HGiOhh0BUO4Y9tSKN/dk6Zp/KHPiRYEQye7TsaUWMgQzesxnGJaj3dRxs7pUtExo3WvFywZwdYYOiECgYAop0f4RcP9ZPsfj1JqJjqf/y3bq1Fw03IrL4zRWmEfn3FyWkv6rO+mCHhVrU0JO3mNAWHYR6pZFfkM1TpUuRQMtZOItdqsLCGElqvGu72OTMNjkvza7E/gUw2Zp/Jxm774xbQ5jRyzk8tc+UUBt54Fs0lVReUX912LoGAZgJe+9QKBgGqdiGHzdeTviLUHrl+8+zlkkQa0FoFR8PhGzcB9uFDk8RL59OqFaA0Fkwa8vzDcnbSBKj2+QawASTzeD1w4VDNO3xnfLc+wOmn2ztQmA/O4xjWCUi9Vp/l6/Jit6j9Vve5uui50y8i2Mof5lmo3z6S021XS9j2quH2SxCJGsvmhAoGAI4OjoKGzogeslLlk3AX9HTE0HEPgo8InXGhGXWIwQ7kVKPxtnPYsXFfD7jRe7+nMEiGFC0VLEcWq8fldzP4UblQuCgAgN+CVOaykU2i2r81ZkpWXteBTR4czHsdcaBsSgCq5USwWGxlYVxXqCTNgN+pg/Pw/jLQQhw5V1V2HyE4=", false)
	client.DebugSwitch = gopay.DebugOn
	//client.
	//	SetPrivateKeyType(alipay.PKCS1). // 设置 支付宝 私钥类型，alipay.PKCS1 或 alipay.PKCS8，默认 PKCS1
	//	SetAliPayRootCertSN("xxx"). // 设置支付宝根证书SN，通过 alipay.GetRootCertSN() 获取
	//	SetAppCertSN("xxx"). // 设置应用公钥证书SN，通过 alipay.GetCertSN() 获取
	//	SetAliPayPublicCertSN("xxx"). // 设置支付宝公钥证书SN，通过 alipay.GetCertSN() 获取
	//	SetCharset("utf-8"). // 设置字符编码，不设置默认 utf-8
	//	SetSignType(alipay.RSA2). // 设置签名类型，不设置默认 RSA2
	//	SetReturnUrl("https://www.gopay.ink"). // 设置返回URL
	//	SetNotifyUrl("https://www.gopay.ink"). // 设置异步通知URL
	//	SetAppAuthToken("xxx"). // 设置第三方应用授权
	//	SetAuthToken("xxx") // 设置个人信息授权
	//err := client.SetCertSnByPath("", "", "")
	//if err != nil {
	//	T.Error(err)
	//	return
	//}
	bm := make(gopay.BodyMap)
	bm.Set("subject", "手机网站测试支付").
		Set("out_trade_no", "GZ201909081743431443").
		Set("quit_url", "https://www.gopay.ink").
		Set("total_amount", "100.00").
		Set("product_code", "QUICK_WAP_WAY")
	pay, err := client.TradeAppPay(bm)
	if err != nil {
		T.Error(err)
		return
	}
	T.Log(pay)
}
