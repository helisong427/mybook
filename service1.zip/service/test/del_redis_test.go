package test

import (
	"fmt"
	"gamers/utils"
	"github.com/go-redis/redis"
	"testing"
)

func TestDelRedis(t *testing.T) {
	var (
		err error
	)

	Init("test")
	// 首先获取所有 对应键值数据
	key := fmt.Sprintf("%s*", utils.REDIS_USER_TODAY_VISITOR_COUNT)

	pipeline := utils.RedisClient.TxPipeline()

	delRedisKey(key, pipeline)

	if _, err = pipeline.Exec(); err != nil {
		utils.LogErrorF("del keys error: %v", err.Error())
	}
}

func delRedisKey(keys string, pipeline redis.Pipeliner) {
	var (
		err    error
		result []string
	)

	// 获取 要删除的键值对数组
	// 这里 pipeline会先 打包命令再发送,所以 keys 列表 需要单独获取一次
	if result, err = utils.RedisClient.Keys(keys).Result(); err != nil {
		return
	}

	// 遍历删除
	for _, v := range result {
		if err = pipeline.Del(v).Err(); err != nil {
			utils.LogErrorF("error: %v", err.Error())
		}
	}

	if _, err = pipeline.Exec(); err != nil {
		utils.Logger.Error(err.Error())
	}
}
