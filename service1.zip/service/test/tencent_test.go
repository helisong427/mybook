package test

import (
	"gamers/utils/tencent/facecore"
	"testing"
)

func TestFaceIdCard(t *testing.T) {
	imageBase64 := "xxxxx"
	idCard := "xxx"
	name := "xxx"
	response, err := facecore.FaceIdCardImage(&imageBase64, &idCard, &name)
	if err != nil {
		t.Error(err)
		return
	}
	t.Log(response)
}
