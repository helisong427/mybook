package test

import (
	"gamers/utils"
	"math"
	"strings"
	"testing"
)

func TestTotalPages(t *testing.T) {
	page := utils.FuncTotalPages(20, 10)
	t.Log("总页数 = ", page)
}

func TestMd5(t *testing.T) {
	str := utils.FuncMD5("419CC4E56AAEFFEE212523617D0A1B7F1Sh3ftAO2L68UVPqWeYmnzHuayQiNlTG16000699304ce9833d-00eb-4f42-b33c-29b9ce8f76f5")
	t.Log(str)
}

func TestAge(t *testing.T) {
	age := utils.FuncGetAge(1600506762)
	t.Log(age)
	id := "1000082905"
	t.Log(id[2:10])
}

func TestFuncRandSlice(t *testing.T) {
	original := []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
	//amount := 6
	//slice := utils.FuncRandSlice(original, amount)
	//original = append(original[:0], append([]int{666}, original[0:]...)...)
	//t.Log(slice)
	t.Log(original)
}

func TestPage(t *testing.T) {
	start, stop, pages := page(13, 2, 10)
	t.Log(start)
	t.Log(stop)
	t.Log(pages)
}

func page(count int64, page int64, size int64) (start int64, stop int64, totalPages int64) {
	//计算总页数
	totalPages = int64(math.Ceil(float64(count) / float64(size)))
	if page == 0 {
		return 0, size - 1, totalPages
	}
	return (page - 1) * size, page*size - 1, totalPages
}

func TestStrings(t *testing.T) {
	str := "{\"code\":\"00\",\"msg\":\"成功\",\"sub_code\":\"99999\",\"sub_msg\":\"禁止重复签约\",\"data\":{\"merchant_id\":\"\",\"out_trade_no\":\"\",\"contract_code\":\"\",\"contract_title\":\"\",\"contract_template\":\"\",\"sign_company\":\"\",\"user_name\":\"\",\"user_idcard\":\"\",\"user_mobile\":\"\",\"contract_status\":0,\"download_url\":\"\",\"view_url\":\"\",\"create_date\":\"\",\"company_sign_date\":\"\",\"user_sign_date\":\"\",\"cancel_date\":\"\"}"
	t.Log(strings.Index(str, "禁止重复签约"))
}

func TestRound(t *testing.T) {
	t.Log(utils.FuncRound(1.4, 0))
}
