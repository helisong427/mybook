package test

import (
	"gamers/controller/services"
	"gamers/models/dbmodels"
	"testing"
)

func TestSendMessage(t *testing.T) {
	var (
		err error
	)

	Init("test")

	if err = services.InitSparringVisitSendMsg().SendInteractiveMsg(&dbmodels.AppMsgModel{
		MsgTitle:             "test message",
		MsgContent:           "测试消息",
		MsgNotificationClose: 1,
	}, 1006766216, 1006744305, &dbmodels.SystemUser{
		UserID:       1006744305,
		UserNickname: "guaidashu",
	}); err != nil {
		return
	}
}
