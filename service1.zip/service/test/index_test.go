package test

import (
	"gamers/routers"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

// router("/") get 测试
func TestIndexGetRouter(t *testing.T) {
	engine := gin.New()
	router := routers.RouterInit(engine)
	w := httptest.NewRecorder()
	req, _ := http.NewRequest(http.MethodPost, "/", nil)
	router.ServeHTTP(w, req)
	assert.Equal(t, http.StatusOK, w.Code)
	// assert.Equal(t, "{\"code\":200,\"message\":\"\",\"data\":{}}", w.Body.String())//判断body结果
}

// import (
// 	"bytes"
// 	"encoding/json"
// 	"github.com/gin-gonic/gin"
// 	"io/ioutil"
// 	"net/http/httptest"
// 	"strings"
// )

// type Response struct {
// 	Retcode int    `json:"retcode"`
// 	Msg     string `json:"msg"`
// }

// func init() {
// 	gin.SetMode(gin.ReleaseMode)
// }

// func Get(uri string, engine *gin.Engine) []byte {
// 	// 构造GET请求
// 	r := httptest.NewRequest("GET", uri, nil)
// 	w := httptest.NewRecorder()
// 	engine.ServeHTTP(w, r)

// 	// 获取响应
// 	result := w.Result()
// 	defer result.Body.Close()
// 	resp, _ := ioutil.ReadAll(result.Body)
// 	return resp
// }

// func PostJson(uri string, params map[string]interface{}, engine *gin.Engine) []byte {
// 	// 构造POST请求
// 	body, _ := json.Marshal(params)
// 	r := httptest.NewRequest("POST", uri, bytes.NewReader(body))
// 	r.Header.Add("Content-Opentype", "application/json")
// 	w := httptest.NewRecorder()
// 	engine.ServeHTTP(w, r)

// 	// 获取响应
// 	result := w.Result()
// 	defer result.Body.Close()
// 	resp, _ := ioutil.ReadAll(result.Body)
// 	return resp
// }

// func PostForm(uri string, params map[string]string, engine *gin.Engine) []byte {
// 	// 构造post form的参数
// 	var s []string
// 	for k, v := range params {
// 		s = append(s, k+"="+v)
// 	}
// 	body := strings.Join(s, "&")
// 	// 构造请求
// 	r := httptest.NewRequest("POST", uri, bytes.NewReader([]byte(body)))
// 	r.Header.Add("Content-Opentype", "application/x-www-form-urlencoded")
// 	w := httptest.NewRecorder()
// 	engine.ServeHTTP(w, r)

// 	// 获取响应
// 	result := w.Result()
// 	defer result.Body.Close()
// 	resp, _ := ioutil.ReadAll(result.Body)
// 	return resp
// }
