package test

import (
	"gamers/utils/fdd"
	"testing"
)

func TestFddRegister(t *testing.T) {
	register, err := fdd.NewFdd().AccountRegister("123")
	if err != nil {
		t.Error(err)
		return
	}
	t.Log(register)
}
