package esmodels

import (
	"gamers/utils"
	"sync"
)

var logOnce sync.Once

//日志索引Mappings
type ESLogIndex struct {
	Content struct {
		Type string `json:"type"`
	} `json:"content"`
	Level struct {
		Type string `json:"type"`
	} `json:"level"`
	Linenum struct {
		Type string `json:"type"`
	} `json:"linenum"`
	Queryid struct {
		Type string `json:"type"`
	} `json:"queryid"`
	Stacktrace struct {
		Type string `json:"type"`
	} `json:"stacktrace"`
	Time struct {
		Type   string `json:"type"`
		Format string `json:"format"`
	} `json:"time"`
	Method struct {
		Type string `json:"type"`
	} `json:"method"`
	Type struct {
		Type string `json:"type"`
	} `json:"type"`
	URL struct {
		Type string `json:"type"`
	} `json:"url"`
}

//创建es索引
func (esli *ESLogIndex) indexCreate() (err error) {
	esli.Content.Type = "text"
	esli.Level.Type = "keyword"
	esli.Linenum.Type = "text"
	esli.Queryid.Type = "keyword"
	esli.Stacktrace.Type = "text"
	esli.Time.Type = "date"
	esli.Time.Format = "yyyy-MM-dd HH:mm:ss||yyyy-MM-dd||epoch_millis"
	esli.Type.Type = "keyword"
	esli.Method.Type = "keyword"
	esli.URL.Type = "text"
	base := Base{}
	base.Mappings.Properties = esli
	err = base.IndexCreate(utils.Config.App.LogName)
	return
}

//插入文档到es
func (esli *ESLogIndex) Create(id string, doc string) (err error) {
	logOnce.Do(func() {
		err = esli.indexCreate()
	})
	if err != nil {
		return
	}
	id, err = utils.ESCreate(utils.Config.App.LogName, id, doc)
	return
}
