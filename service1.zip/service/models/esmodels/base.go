package esmodels

import (
	"encoding/json"
	"errors"
	"fmt"
	"gamers/utils"
)

type Base struct {
	Mappings struct {
		Properties interface{} `json:"properties"`
	} `json:"mappings"`
}

func (m *Base) IndexCreate(index string) (err error) {
	//索引不存在，创建索引
	ok := utils.ESIndexExists(index)
	if !ok {
		mapping, _ := json.Marshal(m)
		fmt.Println(string(mapping))
		ok := utils.ESCreateIndex(index, string(mapping))
		if !ok {
			e := fmt.Sprintf("索引[%s]创建失败!", index)
			err = errors.New(e)
			return
		}
	}
	return
}
