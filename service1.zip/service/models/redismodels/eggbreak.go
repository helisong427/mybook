package redismodels

import (
	"encoding/json"
	"fmt"
	db "gamers/models/dbmodels"
	"gamers/utils"
	"github.com/go-redis/redis"
	wr "github.com/mroth/weightedrand"
)

type Eggbreak struct {
	Client       *redis.Client  //redis连接
	EggbreakId   int64          //蛋池id
	EggbreakPool []EggbreakPool //小蛋池
}

//小蛋池
type EggbreakPool struct {
	PoolId          int64        `json:"pool_id"`           //小奖池id
	PoolWeight      int64        `json:"pool_weight"`       //小奖池权重
	PoolRewardTotal int64        `json:"pool_reward_total"` //小奖池奖励总数
	RewardList      []RewardList `json:"reward_list"`       //奖励列表
}

//奖励列表
type RewardList struct {
	RewardId    int64  `json:"reward_id"`    //奖励id
	GiftId      int64  `json:"gift_id"`      //道具id
	GiftPrice   int64  `json:"gift_price"`   //道具单价
	RewardName  string `json:"reward_name"`  //奖励名称
	RewardTotal int64  `json:"reward_total"` //奖励数量
}

//抽奖列表
type LotteryList struct {
	RewardId   int64  `json:"reward_id"`   //奖励id
	GiftId     int64  `json:"gift_id"`     //道具id
	GiftPrice  int64  `json:"gift_price"`  //道具单价
	RewardName string `json:"reward_name"` //奖励名称
}

func NewEggbreak() *Eggbreak {
	egg := Eggbreak{
		Client: utils.RedisClient,
	}
	return &egg
}

// 初始化数据结构到redis
func (e *Eggbreak) Init(EggbreakId int64) (err error) {
	e.EggbreakId = EggbreakId
	eggData, err := new(db.AppEggbreak).QueryByEggbreakId(EggbreakId)
	if err != nil {
		return
	}

	// 尽量使用缓存奖池配置
	{
		// 先找是否有下轮更新
		var data []EggbreakPool
		var key = fmt.Sprintf("%s%d", utils.REDIS_EGGBREAK_POOL_NEXT, EggbreakId)
		var val, err = e.Client.Get(key).Result()
		switch err {
		case nil:
			// 有则创建砸蛋池
			if mErr := json.Unmarshal([]byte(val), &data); mErr != nil {
				return mErr
			}
			e.EggbreakPool = data
			goto createPool
		case redis.Nil:
			// 没有下轮则从查找蛋池
			key := fmt.Sprintf("%s%d", utils.REDIS_EGGBREAK_POOL, EggbreakId)
			result, err := e.Client.Get(key).Result()
			switch err {
			case nil:
				// 有则更新
				if mErr := json.Unmarshal([]byte(result), &data); mErr != nil {
					return mErr
				}
				e.EggbreakPool = data
				goto createPool
			case redis.Nil:
				// 没有则从数据库生成
				goto useDBConfig
			default:
				return err
			}
		default:
			return err
		}
	}

useDBConfig:
	for _, v := range eggData.AppEggbreakPool {
		pool := EggbreakPool{
			PoolId:          v.PoolId,
			PoolWeight:      v.PoolWeight,
			PoolRewardTotal: 0,
		}
		if len(v.AppEggbreakReward) != 0 {
			for _, val := range v.AppEggbreakReward {
				rewardList := RewardList{
					RewardId:    val.RewardId,
					GiftId:      val.RewardPropId,
					GiftPrice:   val.AppProp.PropPrice,
					RewardName:  val.AppProp.PropName,
					RewardTotal: val.RewardPropCount,
				}
				pool.PoolRewardTotal = pool.PoolRewardTotal + val.RewardPropCount
				pool.RewardList = append(pool.RewardList, rewardList)
			}
			e.EggbreakPool = append(e.EggbreakPool, pool)
		}
	}

createPool:
	//打乱顺序
	e.upset()
	//储存到list
	err = e.saveLotteryList()
	if err != nil {
		return
	}

	//储存到hash
	err = e.savePoolStatus()
	if err != nil {
		return
	}

	//储存到redis
	key := fmt.Sprintf("%s%d", utils.REDIS_EGGBREAK_POOL, EggbreakId)
	marshal, err := json.Marshal(e.EggbreakPool)
	if err != nil {
		return
	}
	err = e.Client.Set(key, marshal, 0).Err()
	if err != nil {
		return
	}

	//删除下次更新数据
	key = fmt.Sprintf("%s%d", utils.REDIS_EGGBREAK_POOL_NEXT, EggbreakId)
	err = e.Client.Del(key).Err()
	return
}

//获取当前的蛋池
func (e *Eggbreak) GetPool(EggbreakId int64) (data []EggbreakPool, err error) {
	key := fmt.Sprintf("%s%d", utils.REDIS_EGGBREAK_POOL, EggbreakId)
	result, err := e.Client.Get(key).Result()
	if err != nil && err != redis.Nil {
		return
	}
	if result != "" {
		err = json.Unmarshal([]byte(result), &data)
		return
	}
	err = nil
	return
}

//获取当前蛋池状态
func (e *Eggbreak) GetPoolStatus(EggbreakId int64) (result map[string]string, err error) {
	key := fmt.Sprintf("%s%d", utils.REDIS_EGGBREAK_POOL_STATUS, EggbreakId)
	result, err = e.Client.HGetAll(key).Result()
	return
}

//下次更新
func (e *Eggbreak) NextUpdate(EggbreakId int64) (err error) {
	e.EggbreakId = EggbreakId
	eggData, err := new(db.AppEggbreak).QueryByEggbreakId(EggbreakId)
	if err != nil {
		return
	}
	for _, v := range eggData.AppEggbreakPool {
		pool := EggbreakPool{
			PoolId:          v.PoolId,
			PoolWeight:      v.PoolWeight,
			PoolRewardTotal: 0,
		}
		if len(v.AppEggbreakReward) != 0 {
			for _, val := range v.AppEggbreakReward {
				rewardList := RewardList{
					RewardId:    val.RewardId,
					GiftId:      val.RewardPropId,
					RewardName:  val.AppProp.PropName,
					RewardTotal: val.RewardPropCount,
				}
				pool.PoolRewardTotal = pool.PoolRewardTotal + val.RewardPropCount
				pool.RewardList = append(pool.RewardList, rewardList)
			}
			e.EggbreakPool = append(e.EggbreakPool, pool)
		}
	}
	//打乱顺序
	e.upset()

	//储存到下次更新数据到redis
	key := fmt.Sprintf("%s%d", utils.REDIS_EGGBREAK_POOL_NEXT, EggbreakId)
	marshal, err := json.Marshal(e.EggbreakPool)
	if err != nil {
		return
	}
	err = e.Client.Set(key, marshal, 0).Err()
	return
}

//是否初始化
func (e *Eggbreak) IsInit(EggbreakId int64) (init int64, err error) {
	oldKey := fmt.Sprintf("%s%d", utils.REDIS_EGGBREAK_POOL, EggbreakId)
	init, err = e.Client.Exists(oldKey).Result()
	return
}

//按照权重打乱顺序
func (e *Eggbreak) upset() {
	tmp := []EggbreakPool{}
	//准备随机数
	choice := []wr.Choice{}
	for _, v := range e.EggbreakPool {
		choice = append(choice, wr.NewChoice(v.PoolId, uint(v.PoolWeight)))
	}

	//随机结果
	choiceResult := []int64{}
	for i := 0; i < len(e.EggbreakPool); i++ {
		chooser, _ := wr.NewChooser(choice...)
		fruit := chooser.Pick().(int64)
		//减少参与随机的数量
		for k, v := range choice {
			if fruit == v.Item.(int64) {
				choice = append(choice[:k], choice[k+1:]...)
			}
		}
		choiceResult = append(choiceResult, fruit)
	}
	//匹配顺序
	for _, v := range choiceResult {
		for _, val := range e.EggbreakPool {
			if v == val.PoolId {
				tmp = append(tmp, val)
			}
		}
	}
	e.EggbreakPool = e.EggbreakPool[:0]
	e.EggbreakPool = tmp
}

//储存抽奖列表
func (e *Eggbreak) saveLotteryList() (err error) {
	listKey := fmt.Sprintf("%s%d", utils.REDIS_EGGBREAK_POOL_LOTTERY_LIST, e.EggbreakId)
	//删除之前的
	err = e.Client.Del(listKey).Err()
	for _, v := range e.EggbreakPool {
		//奖励列表
		lotteryList := []interface{}{}
		for _, val := range v.RewardList {
			for i := 0; i < int(val.RewardTotal); i++ {
				lotteryList = append(lotteryList, LotteryList{
					RewardId:   val.RewardId,
					GiftId:     val.GiftId,
					GiftPrice:  val.GiftPrice,
					RewardName: val.RewardName,
				})
			}
		}
		//打乱顺序
		utils.FuncShuffle(lotteryList)

		//待插入数据
		lpush := []string{}
		for _, list := range lotteryList {
			l := list.(LotteryList)
			//拼接格式  小蛋池id:奖励id:礼物id:礼物价格
			value := fmt.Sprintf("%d:%d:%d:%d", v.PoolId, l.RewardId, l.GiftId, l.GiftPrice)
			lpush = append(lpush, value)
		}
		if len(lpush) != 0 {
			err = e.Client.LPush(listKey, lpush).Err()
			if err != nil {
				return err
			}
		}

	}

	return
}

//储存奖池状态
func (e *Eggbreak) savePoolStatus() (err error) {
	key := fmt.Sprintf("%s%d", utils.REDIS_EGGBREAK_POOL_STATUS, e.EggbreakId)
	e.Client.Del(key)
	for _, v := range e.EggbreakPool {
		for _, val := range v.RewardList {
			//拼接格式  小蛋池id:奖励id:礼物id:礼物价格
			hashKey := fmt.Sprintf("%d:%d:%d:%d", v.PoolId, val.RewardId, val.GiftId, val.GiftPrice)
			err = e.Client.HSet(key, hashKey, val.RewardTotal).Err()
			if err != nil {
				return err
			}
		}
	}
	return
}
