package redismodels

import (
	"fmt"
	"gamers/controller/response"
	"gamers/models/dbmodels"
	"gamers/utils"
	"strconv"
	"time"

	"github.com/go-redis/redis"
	"gorm.io/gorm"
)

// 房间热度
type RoomHeat struct {
	thisHourlyKey   string          // 当前房间小时榜key
	first23Hours    []string        // 前23小时榜key
	partyKey        string          // 派对房key
	partyKeyTmp     string          // 派对房临时key
	liveKey         string          // 直播房key
	liveKeyTmp      string          // 直播房临时key
	redisClient     *redis.Client   // redis
	hourHeat        []heat          // 小时榜热度
	first23HourHeat map[int64]int64 // 前23小时榜热度 roomId:roomHeat
	roomHeatRate    int64           // 房间热度倍率
}

// 房间热度
type heat struct {
	RoomId   int64 // 房间id
	RoomHeat int64 // 房间热度
}

const (
	// 房间热度范围
	roomHeatMin int = 1
	roomHeatMax int = 10
)

func NewRoomHeat() *RoomHeat {
	key, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_ROOM_HEAT_RATE)
	if err != nil {
		utils.LogErrorF("获取房间热度倍率失败:%s", err.Error())
	}
	roomHeatRate, _ := strconv.Atoi(key["value"])

	first23Hours := []string{}
	now := time.Now().Unix()
	// 前23小时榜key
	for i := 1; i <= 23; i++ {
		first23Hours = append(first23Hours, fmt.Sprintf("%shourly:%s", utils.REDIS_RANK_ROOM_SEND_CHARM, time.Unix(now-int64(60*60*i), 0).Format("2006010215")))
	}

	return &RoomHeat{
		thisHourlyKey: fmt.Sprintf("%shourly:%s", utils.REDIS_RANK_ROOM_SEND_CHARM, time.Now().Format("2006010215")),
		first23Hours:  first23Hours,
		// thisHourlyKey:   fmt.Sprintf("%shourly:%s", utils.REDIS_RANK_ROOM_SEND_CHARM, "2021012120"),
		partyKey:        utils.REDIS_ROOM_HEAT_PART,
		partyKeyTmp:     utils.REDIS_ROOM_HEAT_PART + "Tmp",
		liveKey:         utils.REDIS_ROOM_HEAT_Live,
		liveKeyTmp:      utils.REDIS_ROOM_HEAT_Live + "Tmp",
		redisClient:     utils.RedisClient,
		roomHeatRate:    int64(roomHeatRate),
		first23HourHeat: make(map[int64]int64),
	}
}

// 更新所有房间的热度
func (r *RoomHeat) UpdateAllHeat() (err error) {

	// 查询前23小时榜
	for _, v := range r.first23Hours {
		// 获取小时榜数量总数
		hourlyCount23 := r.redisClient.ZCard(v).Val()
		// 当前时间段没数据,跳过该时间段
		if hourlyCount23 == 0 {
			break
		}
		// 从高到低查询23小时榜
		hourZSet, err := r.redisClient.ZRevRangeWithScores(v, 0, hourlyCount23).Result() // Course房间热度(float64),Member房间id(string)
		if err != nil {
			return err
		}
		for _, v := range hourZSet {
			roomId, _ := strconv.Atoi(v.Member.(string))
			// 如果房间id已经存在map中，累加热度
			if _, ok := r.first23HourHeat[int64(roomId)]; ok {
				r.first23HourHeat[int64(roomId)] += int64(v.Score)
			} else {
				r.first23HourHeat[int64(roomId)] = int64(v.Score)
			}
		}
	}

	// 前23小时房间热度平均值
	for k, v := range r.first23HourHeat {
		if v != 0 {
			r.first23HourHeat[k] = v / 46
		}
	}

	// 获取小时榜数量总数
	hourlyCount := r.redisClient.ZCard(r.thisHourlyKey).Val()
	if hourlyCount != 0 {
		// 从高到低查询小时榜
		hourZSet, err := r.redisClient.ZRevRangeWithScores(r.thisHourlyKey, 0, hourlyCount).Result() // Course房间热度(float64),Member房间id(string)
		if err != nil {
			return err
		}
		for _, v := range hourZSet {
			roomId, _ := strconv.Atoi(v.Member.(string))
			r.hourHeat = append(r.hourHeat, heat{
				RoomId:   int64(roomId),
				RoomHeat: int64(v.Score),
			})
		}
	}

	err = r.buildPartyHeat()
	if err != nil {
		return
	}
	err = r.buildLiveHeat()
	return
}

// 切换房间热度
// 直播房间<->派对房间 互相切换时交换热度
func (r *RoomHeat) ChangeHeat(roomId int, roomType int) {
	var (
		err      error
		roomHeat float64 // 房间热度
		oldKey   string  // 旧房间
		newKey   string  // 新房间
	)

	// 根据类型查询相反房间的热度
	if roomType == dbmodels.ROOM_TYPE_LIVE {
		oldKey = r.partyKey
		newKey = r.liveKey
	} else {
		oldKey = r.liveKey
		newKey = r.partyKey
	}
	// 查询小时榜的热度
	roomHeat, err = r.redisClient.ZScore(r.thisHourlyKey, fmt.Sprint(roomId)).Result()
	if err != nil {
		utils.LogErrorF("[切换房间热度]未查询到小时榜热度:%d", roomId)
	}

	// 删除旧房间热度
	err = r.redisClient.ZRem(oldKey, roomId).Err()
	if err != nil {
		utils.LogErrorF("[切换房间热度]删除旧房间热度失败:%d", roomId)
	}

	// 储存新房间热度
	err = utils.RedisClient.ZAdd(newKey, redis.Z{
		Score:  roomHeat,
		Member: roomId,
	}).Err()
	if err != nil {
		utils.LogErrorF("[切换房间热度]更新新房间热度失败:%d", roomId)
	}
}

// 删除指定热度
func (r *RoomHeat) Delete(roomId int) {
	err := r.redisClient.ZRem(r.partyKey, roomId).Err()
	if err != nil {
		fmt.Println(err)
	}
	err = r.redisClient.ZRem(r.liveKey, roomId).Err()
	if err != nil {
		fmt.Println(err)
	}
}

// 获取房间列表
func (r *RoomHeat) List(page int64, size int64, roomType int) (total int64, data []dbmodels.AppLiveRoom, err error) {
	key := r.partyKey
	if roomType == dbmodels.ROOM_TYPE_LIVE {
		key = r.liveKey
	}
	// 获取总数
	hourlyCount := r.redisClient.ZCard(key).Val()
	if hourlyCount == 0 {
		return 0, data, err
	}
	total = hourlyCount
	start, stop := r.page(page, size)

	// 分页查询
	// 从高到低查询小时榜
	hourZSet, err := r.redisClient.ZRevRangeWithScores(key, start, stop).Result() // Course房间热度(float64),Member房间id(string)
	if err != nil {
		return 0, data, err
	}
	if len(hourZSet) == 0 {
		return 0, data, err
	}
	hourHeat := []heat{}
	// 排序
	for _, v := range hourZSet {
		roomId, _ := strconv.Atoi(v.Member.(string))
		hourHeat = append(hourHeat, heat{
			RoomId:   int64(roomId),
			RoomHeat: int64(v.Score),
		})
	}
	// 排序
	for i := 0; i < len(hourHeat); i++ {
		for j := 1; j < len(hourHeat)-1; j++ {
			if hourHeat[j].RoomHeat < hourHeat[j+1].RoomHeat {
				hourHeat[j], hourHeat[j+1] = hourHeat[j+1], hourHeat[j]
			}
		}
	}
	heatIds := []int64{}
	for _, v := range hourHeat {
		heatIds = append(heatIds, v.RoomId)
	}
	heatRow, data, err := new(dbmodels.AppLiveRoom).QueryHeat(heatIds, roomType)
	if err != nil && err != gorm.ErrRecordNotFound {
		return 0, data, err
	}

	if heatRow == 0 {
		return 0, data, err
	}

	// 处理热度
	for k, v := range data {
		for _, val := range hourHeat {
			if v.RoomId == val.RoomId {
				data[k].RoomAttachHeat = val.RoomHeat
			}
		}
	}
	return
}

// 构建派对房热度数据
func (r *RoomHeat) buildPartyHeat() (err error) {
	partIdMap := make(map[int64]int)
	partyHeatMap := make(map[int64]heat)
	partyRow, partyData, err := new(dbmodels.AppLiveRoom).QueryHeatParty()
	if err != nil {
		return
	}
	if partyRow == 0 {
		return
	}

	// 保存roomId
	for _, v := range partyData {
		partIdMap[v.RoomId] = 0
	}

	// 当前时间段热度遍历
	for _, v := range r.hourHeat {
		if _, ok := partyHeatMap[v.RoomId]; !ok {
			for _, val := range partyData {
				if v.RoomId == val.RoomId {
					partyHeatMap[v.RoomId] = heat{
						RoomId:   v.RoomId,
						RoomHeat: val.RoomAttachHeat + v.RoomHeat*r.roomHeatRate, // 数据库房间热度 + 小时榜热度*倍率
					}
					break
				}
			}
		}
	}

	// 23小时热度
	for roomId, heat23 := range r.first23HourHeat {
		for _, v := range partyData {
			if roomId == v.RoomId {
				if this, ok := partyHeatMap[roomId]; ok {
					// 如果存在,追加热度
					partyHeatMap[roomId] = heat{
						RoomId:   roomId,
						RoomHeat: this.RoomHeat + heat23,
					}
				} else {
					// 否则设置热度
					partyHeatMap[v.RoomId] = heat{
						RoomId:   v.RoomId,
						RoomHeat: heat23,
					}
				}
				break
			}
		}
	}

	// 给没有热度的房间赋值随机热度
	for k, _ := range partIdMap {
		if _, ok := partyHeatMap[k]; !ok {
			// 如果房间不在热度列表中,赋值随机热度
			rangeInt := utils.FuncRandRangeInt(roomHeatMin, roomHeatMax)
			partyHeatMap[k] = heat{
				RoomId:   k,
				RoomHeat: rangeInt,
			}
		}
	}

	if len(partyHeatMap) > 0 {
		// 查询房间状态,状态正常的房间进入有续集合
		ids := make([]int64, 0)
		for _, v := range partyHeatMap {
			ids = append(ids, v.RoomId)
		}
		roomIds, err := new(dbmodels.AppLiveRoom).QueryInRoomIds(ids)
		if err != nil {
			return err
		}
		for _, v := range roomIds {
			if value, ok := partyHeatMap[v.RoomId]; ok {
				err = r.redisClient.ZAdd(r.partyKeyTmp, redis.Z{
					Score:  float64(value.RoomHeat),
					Member: value.RoomId,
				}).Err()
				if err != nil {
					return err
				}
			}
		}

		// 更换缓存名称
		err = r.redisClient.Rename(r.partyKeyTmp, r.partyKey).Err()
		if err != nil {
			return err
		}

		for _, v := range partyHeatMap {
			update := make(map[string]interface{})
			update["room_heat"] = v.RoomHeat
			err = new(dbmodels.AppLiveRoom).Update(int(v.RoomId), update)
			if err != nil {
				return err
			}
		}
	}
	return
}

// 构建直播房热度数据
func (r *RoomHeat) buildLiveHeat() (err error) {
	liveIdMap := make(map[int64]int)
	liveHeatMap := make(map[int64]heat)
	liveRow, liveData, err := new(dbmodels.AppLiveRoom).QueryHeatLive()
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	if liveRow == 0 {
		return
	}

	// 保存roomId
	for _, v := range liveData {
		liveIdMap[v.RoomId] = 0
	}

	// 当前时间段热度遍历
	for _, v := range r.hourHeat {
		if _, ok := liveHeatMap[v.RoomId]; !ok {
			for _, val := range liveData {
				// 是否对应房间类型
				if v.RoomId == val.RoomId {
					liveHeatMap[v.RoomId] = heat{
						RoomId:   v.RoomId,
						RoomHeat: val.RoomAttachHeat + v.RoomHeat*r.roomHeatRate, // 数据库房间热度 + 小时榜热度*倍率
					}
					break
				}
			}
		}
	}

	for roomId, heat23 := range r.first23HourHeat {
		for _, v := range liveData {
			if roomId == v.RoomId {
				if this, ok := liveHeatMap[roomId]; ok {
					// 如果存在,追加热度
					liveHeatMap[roomId] = heat{
						RoomId:   roomId,
						RoomHeat: this.RoomHeat + heat23,
					}
				} else {
					// 否则设置热度
					liveHeatMap[v.RoomId] = heat{
						RoomId:   v.RoomId,
						RoomHeat: heat23,
					}
				}
				break
			}
		}
	}

	// 给没有热度的房间赋值随机热度
	for k, _ := range liveIdMap {
		if _, ok := liveHeatMap[k]; !ok {
			// 如果房间不在热度列表中,赋值随机热度
			rangeInt := utils.FuncRandRangeInt(roomHeatMin, roomHeatMax)
			liveHeatMap[k] = heat{
				RoomId:   k,
				RoomHeat: rangeInt,
			}
		}
	}

	if len(liveHeatMap) > 0 {
		// 查询房间状态,状态正常的房间进入有续集合
		ids := make([]int64, 0)
		for _, v := range liveHeatMap {
			ids = append(ids, v.RoomId)
		}
		roomIds, err := new(dbmodels.AppLiveRoom).QueryInRoomIds(ids)
		if err != nil {
			return err
		}
		for _, v := range roomIds {
			if value, ok := liveHeatMap[v.RoomId]; ok {
				err = r.redisClient.ZAdd(r.partyKeyTmp, redis.Z{
					Score:  float64(value.RoomHeat),
					Member: value.RoomId,
				}).Err()
				if err != nil {
					return err
				}
			}
		}

		// 更换缓存名称
		err = r.redisClient.Rename(r.liveKeyTmp, r.liveKey).Err()
		if err != nil {
			return err
		}

		for _, v := range liveHeatMap {
			update := make(map[string]interface{})
			update["room_heat"] = v.RoomHeat
			err = new(dbmodels.AppLiveRoom).Update(int(v.RoomId), update)
			if err != nil {
				return err
			}
		}
	}
	return
}

// 分页
func (r *RoomHeat) page(page int64, size int64) (start int64, stop int64) {
	if page == 0 {
		return 0, size - 1
	}
	return (page - 1) * size, page*size - 1
}

// 获取房间历史热度
func (r *RoomHeat) RoomHistoryHeat() (resp response.RoomHistoryHeatResp, err error) {
	// 查询前23小时榜
	for _, v := range r.first23Hours {
		// 获取小时榜数量总数
		hourlyCount23 := r.redisClient.ZCard(v).Val()
		// 当前时间段没数据,跳过该时间段
		if hourlyCount23 == 0 {
			break
		}
		// 从高到低查询23小时榜
		hourZSet, err := r.redisClient.ZRevRangeWithScores(v, 0, hourlyCount23).Result() // Course房间热度(float64),Member房间id(string)
		if err != nil {
			return resp, err
		}
		for _, v := range hourZSet {
			roomId, _ := strconv.Atoi(v.Member.(string))
			// 如果房间id已经存在map中，累加热度
			if _, ok := r.first23HourHeat[int64(roomId)]; ok {
				r.first23HourHeat[int64(roomId)] += int64(v.Score)
			} else {
				r.first23HourHeat[int64(roomId)] = int64(v.Score)
			}
		}
	}

	// 前23小时房间热度平均值
	for k, v := range r.first23HourHeat {
		resp.HistoryHeat = append(resp.HistoryHeat, response.RoomHeat{
			RoomId:   k,
			RoomHeat: v,
		})
		if v != 0 {
			r.first23HourHeat[k] = v / 46
			resp.HistoryHeatAverage = append(resp.HistoryHeatAverage, response.RoomHeat{
				RoomId:   k,
				RoomHeat: v / 46,
			})
		}
	}

	// 获取小时榜数量总数
	hourlyCount := r.redisClient.ZCard(r.thisHourlyKey).Val()
	if hourlyCount != 0 {
		// 从高到低查询小时榜
		hourZSet, err := r.redisClient.ZRevRangeWithScores(r.thisHourlyKey, 0, hourlyCount).Result() // Course房间热度(float64),Member房间id(string)
		if err != nil {
			return resp, err
		}
		for _, v := range hourZSet {
			roomId, _ := strconv.Atoi(v.Member.(string))
			resp.Heat = append(resp.Heat, response.RoomHeat{
				RoomId:   int64(roomId),
				RoomHeat: int64(v.Score),
			})
		}
	}

	// 查询派对房热度
	hourZSetParty, err := r.redisClient.ZRevRangeWithScores(r.partyKey, 0, -1).Result() // Course房间热度(float64),Member房间id(string)
	if err != nil {
		return resp, err
	}

	// 排序
	for _, v := range hourZSetParty {
		roomId, _ := strconv.Atoi(v.Member.(string))
		resp.PartyLive = append(resp.PartyLive, response.RoomHeat{
			RoomId:   int64(roomId),
			RoomHeat: int64(v.Score),
		})
	}
	// 查询直播房热度
	hourZSetLive, err := r.redisClient.ZRevRangeWithScores(r.liveKey, 0, -1).Result() // Course房间热度(float64),Member房间id(string)
	if err != nil {
		return resp, err
	}

	// 排序
	for _, v := range hourZSetLive {
		roomId, _ := strconv.Atoi(v.Member.(string))
		resp.LiveHeat = append(resp.LiveHeat, response.RoomHeat{
			RoomId:   int64(roomId),
			RoomHeat: int64(v.Score),
		})
	}
	return
}
