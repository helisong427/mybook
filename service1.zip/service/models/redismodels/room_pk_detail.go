/**
 * @Author: panke
 * @Description: pk房间详情
 * @File: room_pk_detail
 * @Date: 2021/4/16 15:19
 */

package redismodels

import (
	"errors"
	"gamers/utils"
	"strconv"
)

// 房间pk详情
type RoomPkDetail struct {
	RoomPKDetailRed            int64      `json:"room_pk_detail_red" redis:"room_pk_detail_red"`                   // 红队pk值
	RoomPKDetailBlue           int64      `json:"room_pk_detail_blue" redis:"room_pk_detail_blue"`                 // 蓝队pk值
	RoomPkDetailGloryStar      MsgUserObj `json:"-"`                                                               // 荣耀之星
	RoomPkDetailGloryStarValue int64      `json:"-"`                                                               // 荣耀之星
	RoomPKMvpId                int64      `json:"room_pk_mvp_id" redis:"room_pk_mvp_id"`                           // mvp
	RoomPKSvpId                int64      `json:"room_pk_svp_id" redis:"room_pk_svp_id"`                           // svp
	RoomPKCharmKingId          int64      `json:"room_pk_charm_king_id" redis:"room_pk_charm_king_id"`             // 魅力王
	RoomPKDetailExpectedEnd    int64      `json:"room_pk_record_expected_end" redis:"room_pk_record_expected_end"` // 预计结束时间
}

var (
	ErrPKDetailLater = errors.New("稍后再试")
)

const (
	ROOM_PK_DETAIL_RED         = "room_pk_detail_red"          // 直播间-红队pk值
	ROOM_PK_DETAIL_BLUE        = "room_pk_detail_blue"         // 直播间-蓝队pk值
	ROOM_PK_DETAIL_GLORY       = "room_pk_detail_glory"        // 直播间-荣耀之星
	ROOM_PK_DETAIL_EXPECTEDEND = "room_pk_record_expected_end" // 直播间-预计结束时间
	ROOM_PK_MVP_ID             = "room_pk_mvp_id"
	ROOM_PK_SVP_ID             = "room_pk_svp_id"
	ROOM_PK_CHARM_KING_ID      = "room_pk_charm_king_id"
)
const MIN_GLORY_SCORE_VALUE = 500

// 更新房间pk详情
func (m *RoomPkDetail) Update(roomId int64, detail RoomPkDetail) (err error) {
	key := utils.RedisRoomPkDetail + strconv.Itoa(int(roomId))
	_lockVal, isLock := utils.AcquireLock(key, utils.DEFAULT_LOCK_KEY_TIMEOUT, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT)
	if !isLock {
		return ErrPKDetailLater
	}
	defer utils.ReleaseLock(key, _lockVal)

	detailMap := make(map[string]interface{})
	detailMap[ROOM_PK_DETAIL_RED] = detail.RoomPKDetailRed
	detailMap[ROOM_PK_DETAIL_BLUE] = detail.RoomPKDetailBlue
	detailMap[ROOM_PK_DETAIL_EXPECTEDEND] = detail.RoomPKDetailExpectedEnd
	detailMap[ROOM_PK_MVP_ID] = 0
	detailMap[ROOM_PK_SVP_ID] = 0
	detailMap[ROOM_PK_CHARM_KING_ID] = 0
	return utils.RedisClient.HMSet(key, detailMap).Err()
}

// 获取当前房间pk值
func (m *RoomPkDetail) GetRoomPkInfo(roomId int64) (pkInfo RoomPkDetail, err error) {
	roomIdStr := strconv.Itoa(int(roomId))
	key := utils.RedisRoomPkDetail + roomIdStr
	val := utils.RedisClient.HGetAll(key).Val()
	err = utils.HashToStruct(val, &pkInfo)
	if err != nil {
		return
	}
	// 获取闪耀之星
	maxScore := utils.RedisClient.ZRangeWithScores(utils.RedisRoomPkGloryStar+roomIdStr, -1, -1).Val()
	if len(maxScore) == 0 || maxScore[0].Score < MIN_GLORY_SCORE_VALUE {
		return
	}
	userIdStr := maxScore[0].Member.(string)
	userId, err := strconv.ParseInt(userIdStr, 10, 64)
	if err != nil {
		utils.LogErrorF("获取闪耀之星[%s]失败,err:%s", userIdStr, err.Error())
		return
	}
	userInfo, err := new(MsgUserObj).GetMsgUserInfo(userId, map[string]bool{})
	if err != nil {
		utils.LogErrorF("获取闪耀之星[%s]失败,err:%s", userIdStr, err.Error())
		return
	}
	pkInfo.RoomPkDetailGloryStar = userInfo
	pkInfo.RoomPkDetailGloryStarValue = int64(maxScore[0].Score)

	// 获取魅力王

	return
}
