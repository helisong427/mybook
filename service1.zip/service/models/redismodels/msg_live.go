package redismodels

import (
	"encoding/json"
	"fmt"
	"gamers/utils"
	"sort"
	"strconv"
	"sync"
	"time"

	"github.com/go-redis/redis"
)

const (
	LIVE_KEY_COME_IN   = "live_come_in"   // 进入直播间
	LIVE_KEY_BREAK_EGG = "live_break_egg" // 砸蛋
)

// 直播间消息
type LiveMsg struct {
	FromAccount   *MsgUserObj                        `json:"from_account"`   // 发送者信息
	Type          int                                `json:"type"`           // 消息类型，区分禁言消息/拉黑/用户消息/礼物消息/公告消息等
	ContentType   int                                `json:"content_type"`   // 消息内容的类型，用以区分文本消息/音频/视频/图片消息/指令消息等
	Content       string                             `json:"content"`        // 消息具体内容，根据type，此值可能是一些指令，如：禁言，踢人等
	CMD           string                             `json:"cmd"`            // 指令
	Wheat         *Wheat                             `json:"wheat"`          // 礼物(麦位)信息
	GiftInfo      []*MsgPropObj                      `json:"gift_info"`      // 礼物信息
	WheatQueue    interface{}                        `json:"wheat_queue"`    // 麦序信息
	LiveInfo      *LiveInfo                          `json:"live_info"`      // 直播间信息
	Anchor        *LiveAnchorInfo                    `json:"anchor"`         // 主播信息
	CmdStartTime  int64                              `json:"cmd_start_time"` // 指令开始时间，如禁言，踢人的时长，单位秒
	CmdEntTime    int64                              `json:"cmd_ent_time"`   // 指令终止时间，如禁言，踢人的时长，单位秒
	CmdDuration   int64                              `json:"cmd_duration"`   // 指令时长
	CmdObjs       []*MsgUserObj                      `json:"cmd_objs"`       // 指令对象id
	MsgSource     int                                `json:"msg_source"`     // 消息源，用以区分是哪个端发的消息，如：ios/安卓/服务器
	MsgStyle      *MsgStyle                          `json:"msg_style"`      // 消息样式，此值用于区分消息的颜色/样式等
	LiveRecommend []LiveRecommend                    `json:"live_recommend"` // 直播推荐信息
	PropInfo      []*PropInfo                        `json:"prop_info"`      // 砸蛋信息
	RankInfo      *RankRoomSendCharmUpdateNotifyItem `json:"rank_info"`      // 排行榜信息
	InviteUpWheat *InviteUpWheat                     `json:"invite_up_wheat"`
}

type LiveAnchorInfo struct {
	UserID       int64  `json:"user_id"`       // 用户id
	UserNickname string `json:"user_nickname"` // 昵称
	UserIconurl  string `json:"user_iconurl"`  // 头像
	TotalCharm   int    `json:"total_charm"`
	IsAttention  int    `json:"is_attention"`
}

// 直播间信息
type LiveInfo struct {
	RoomId              int64      `json:"room_id" `         // 房间id
	RoomPrettyId        int64      `json:"room_pretty_id"`   // 靓号
	RoomType            int        `json:"room_type"`        // 类型(0音频直播,1音频派对)
	RoomName            string     `json:"room_name"`        // 房间名称
	RoomCover           string     `json:"room_cover"`       // 房间封面
	RoomBackground      string     `json:"room_background"`  // 房间背景
	RoomTitle           string     `json:"room_title"`       // 房间标题(排队公告标题)
	RoomContent         string     `json:"room_content"`     // 房间简介(派对公告内容)
	RoomUnionId         int64      `json:"room_union_id"`    // 所属公会id
	RoomUserId          int64      `json:"room_user_id"`     // 所属用户id
	RoomAttrId          int64      `json:"room_attr_id"`     // 房间属性(唱歌,脱口秀)
	RoomAttrName        string     `json:"attr_name"`        // 标签名
	RoomSpeakType       int        `json:"room_speak_type"`  // 麦位模式(0音频直播无麦位,1音频直播有麦位,2音频派对自由模式,3音频派对麦序模式)
	RoomOpenIm          int        `json:"room_open_im"`     // 是否开通公屏(图文聊天0关闭,1开通)
	RoomLiveStatus      int        `json:"room_live_status"` // 直播状态,直播类型才有效(0下播,1上播)
	RoomLastOnline      int64      `json:"room_last_online"` // 最后开播时间(直播)
	RoomIsPassword      int        `json:"room_is_password"`
	RoomPassword        string     `json:"room_password"`
	RoomEggbreakMsg     int        `json:"room_eggbreak_msg" `                          // 是否显示砸蛋消息:0--否,1--是
	RoomPkSwitch        int        `gorm:"column:room_pk_switch" json:"room_pk_switch"` // 房间开启pk功能(0未开启 1开启)
	RoomPkRecordTime    int64      `json:"room_pk_record_time"`                         // 房间pk时长
	RoomPkRecordPunish  string     `json:"room_pk_record_punish"`                       // 房间pk惩罚
	RoomPkState         int64      `json:"room_pk_state"`                               // 房间pk状态(0关闭 1准备 2开始 3惩罚)
	RoomPKDetailRed     int64      `json:"room_pk_detail_red"`                          // 红队pk值
	RoomPKDetailBlue    int64      `json:"room_pk_detail_blue"`                         // 蓝队pk值
	RoomPKRemainingTime int64      `json:"room_pk_remaining_time"`                      // 结束倒计时
	RoomPKMvpId         int64      `json:"room_pk_mvp_id"`                              // mvp
	RoomPKSvpId         int64      `json:"room_pk_svp_id"`                              // svp
	RoomPKCharmKingId   int64      `json:"room_pk_charm_king_id"`                       // 魅力王
	RoomGloryStar       MsgUserObj `json:"room_glory_star"`                             // 闪耀之星
}

// 直播推荐
type LiveRecommend struct {
	RoomId    int64  `json:"room_id"`    // 房间id
	RoomType  int    `json:"room_type"`  // 房间类型
	RoomName  string `json:"room_name"`  // 房间名称
	RoomCover string `json:"room_cover"` // 房间图片
}

// 麦位
type Wheat struct {
	WheatSwitch     int        `json:"wheat_switch"`      // 麦位开关
	WheatLoveSwitch int        `json:"wheat_love_switch"` // 爱意值开关
	WheatLen        int        `json:"wheat_len"`         // 麦位长度
	WheatObj        []WheatObj `json:"wheat_list"`
}

// 麦位pk详情
type WheatPkObj struct {
	Role              int    `json:"role"`                 // 身份:0--房主,1--管理员,2--普通用户
	UserId            int    `json:"user_id"`              // 用户id
	UserNickName      string `json:"user_nick_name"`       // 用户昵称
	UserIconurl       string `json:"user_iconurl"`         // 用户头像
	UserGender        int    `json:"user_gender"`          // 用户性别
	UserAvatarDressUp string `json:"user_avatar_dress_up"` // 用户头像装扮
	Status            int    `json:"status"`               // 状态：0--未上锁，1--已上锁，2--禁麦
	LoveValue         int    `json:"love_value"`           // 爱意值
	Position          int    `json:"position"`             // 麦序值
	UpdateTime        int64  `json:"update_time"`          // 更新时间

	// pk模式
	IsMvp   int `json:"is_mvp"`   // 是否为MVP 0为否，1为是
	IsSvp   int `json:"is_svp"`   // 是否为SVP 0为否，1为是
	IsCharm int `json:"is_charm"` // 是否为魅力王 0为否，1为是
}

// 麦位-详情
type WheatPk struct {
	WheatSwitch     int          `json:"wheat_switch"`      // 麦位开关
	WheatLoveSwitch int          `json:"wheat_love_switch"` // 爱意值开关
	WheatLen        int          `json:"wheat_len"`         // 麦位长度
	WheatObj        []WheatPkObj `json:"wheat_list"`

	RoomPkRecordResult int        `json:"room_pk_record_result"` // pk结果(1红方 2蓝方 3平局)
	RoomPkRecordRed    int64      `json:"room_pk_record_red"`    // 红队pk值
	RoomPKRecordBlue   int64      `json:"room_pk_record_blue"`   // 蓝队pk值
	RoomPKRecordPunish string     `json:"room_pk_record_punish"` // pk惩罚
	RoomGloryStar      MsgUserObj `json:"room_glory_star"`       // 房间闪耀之星
}

// 麦位信息
type WheatObj struct {
	Role              int    `json:"role"`                 // 身份:0--房主,1--管理员,2--普通用户
	UserId            int    `json:"user_id"`              // 用户id
	UserNickName      string `json:"user_nick_name"`       // 用户昵称
	UserIconurl       string `json:"user_iconurl"`         // 用户头像
	UserGender        int    `json:"user_gender"`          // 用户性别
	UserAvatarDressUp string `json:"user_avatar_dress_up"` // 用户头像装扮
	Status            int    `json:"status"`               // 状态：0--未上锁，1--已上锁，2--禁麦
	LoveValue         int    `json:"love_value"`           // 爱意值
	Position          int    `json:"position"`             // 麦序值
	UpdateTime        int64  `json:"update_time"`          // 更新时间
}

// 邀请上麦
type InviteUpWheat struct {
	RoomId        int64 `json:"room_id"`         // 房间id
	AdminId       int64 `json:"admin_id"`        // 管理员id
	WheatKey      int   `json:"wheat_key"`       // 麦位
	InvitedUserId int64 `json:"invited_user_id"` // 被邀请的用户id
	CreateT       int64 `json:"create_t"`        // 邀请时间
}

// 礼物消息
type MsgPropObj struct {
	UserInfo          MsgUserObj `json:"user_info"`           // 用户信息
	PropInfo          PropInfo   `json:"prop_info"`           // 道具信息
	FromAccountWealth int64      `json:"from_account_wealth"` // 赠送者新增的财富值
	AddLoveValue      int64      `json:"add_love_value"`      // 当次送礼新增爱意值
	LoveValue         int64      `json:"love_value"`          // 当前爱意值
	Position          int        `json:"position"`            // 麦序值
	UserIncome        int64      `json:"user_income"`         // 用户收入值
	UnionIncome       int64      `json:"union_income"`        // 公会收人
}

// 道具信息
type PropInfo struct {
	PropId           int64  `json:"prop_id"`                                             // 道具id
	PropType         int    `json:"prop_type"`                                           // 道具类型
	PropIcon         string `json:"prop_icon"`                                           // 道具icon
	PropName         string `json:"prop_name"`                                           // 道具名字
	PropClass        int    `gorm:"column:prop_class" json:"prop_class"`                 // 礼物类型(0正常礼物,1免费倒计时礼物,2限时购买礼物) 用于送礼物区分
	PropAttrId       int64  `gorm:"column:prop_attr_id" json:"prop_attr_id"`             // 道具属性(礼物页签,对应app_prop_attr中的attr_id)
	PropLevel        int    `gorm:"column:prop_level" json:"prop_level"`                 // 礼物抽成类型(0普通礼物,1冠名礼物 )
	PropSpecialLevel int64  `gorm:"column:prop_special_level" json:"prop_special_level"` // 礼物特效等级(1最初级 数字越大越高级)
	PropAddIcon      string `gorm:"column:prop_add_icon" json:"prop_add_icon"`           // 附属icon
	PropUrl          string `gorm:"column:prop_url" json:"prop_url"`                     // 礼物url 特效地址
	PropCount        int64  `json:"prop_count"`                                          // 道具数量
	PropGetRadio1    int64  `json:"-"`
}

// 用户信息
type MsgUserObj struct {
	UserId       int64       `json:"user_id"`
	UserPrettyId int64       `json:"user_pretty_id"`
	Icon         string      `json:"icon"` // icon
	IconStyle    IconStyle   `json:"icon_style"`
	ComeInStyle  ComeInStyle `json:"come_in_style"`
	ChatStyle    ChatStyle   `json:"chat_style"`
	NickName     string      `json:"nick_name" gorm:"column:user_nickname"` // 昵称
	Gender       int         `json:"gender" gorm:"column:user_gender"`      // 用户性别0未知,1男,2女
	Role         int         `json:"role" gorm:"-"`                         // 角色 (1房间副管理员,2房间管理员,3房主)
	IsSuper      int         `json:"is_super"`                              // 超级管理员0不是，1是
	VipLevel     int         `json:"vip_level" gorm:"-"`                    // vip等级
	JueLevel     int         `json:"jue_level" gorm:"-"`                    // 贵族等级
	FansLevel    int         `json:"fans_level" gorm:"-"`                   // 粉丝等级
	UserOver     int64       `json:"-"`
	UserUnionId  int64       `json:"user_union_id"` // 公会id
	UserSlogan   string      `json:"-"`
	Age          int         `json:"age"`
}

// 样式
type MsgStyle struct {
	PrimaryColor string `json:"primary_color"`
	SecondColor  string `json:"second_color"`
}

type MsgMuteItem struct {
	User   MsgUserObj `json:"user"`
	Admin  MsgUserObj `json:"admin"`
	StartT int64      `json:"start_t"`
	EndT   int64      `json:"end_t"`
}

func (s *MsgMuteItem) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s MsgMuteItem) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

const (
	MSG_STYLE_PRIMARYCOLOR_WHITE  = "#FFFFFF" // 白色
	MSG_STYLE_PRIMARYCOLOR_PURPLE = "#C7B2FF" // 紫色
)

const (
	MSG_STYLE_SECOND_YELLOW = "#FCD75E" // 黄色
)

// 消息类型
const (
	MSG_TYPE_NORMAL    = iota // 普通消息
	MSG_TYPE_FORBID           // 拉黑
	MSG_TYPE_KICK             // 踢人
	MSG_TYPE_MUTE             // 禁言
	MSG_TYPE_ANNOUNCE         // 公告消息
	MSG_TYPE_GIFT             // 礼物消息
	MSG_TYPE_MIC              // 麦消息
	MSG_TYPE_LIVE             // 开播消息
	MSG_TYPE_MANAGER          // 设置管理员消息
	MSG_TYPE_SETTING          // 设置房间信息
	MSG_TYPE_COME_IN          // 进场消息
	MSG_TYPE_BREAK_EGG        // 砸蛋消息
	MSG_TYPE_RANK             // 排行信息消息
	MSG_TYPE_STUDIO           // 房间消息
	MSG_TYPE_PK               // PK消息
)

// contentType 内容类型
const (
	CONTENT_TYPE_TEXT  = iota // 文本消息
	CONTENT_TYPE_IMG          // 图片消息
	CONTENT_TYPE_VOICE        // 音频消息
	CONTENT_TYPE_VDEIO        // 视频消息
	CONTENT_TYPE_CMD          // 指令消息
	CONTENT_TYPE_FACE         // 表情消息

)

// 指令
const (
	CMD_TYPE_FORBID                   = "FORBID"                   // 拉黑指令
	CMD_TYPE_UNFORBID                 = "UNFORBID"                 // 取消拉黑指令
	CMD_TYPE_KICK                     = "KICK"                     // 踢人消息
	CMD_TYPE_UNKICK                   = "UNKICK"                   // 解除踢人消息
	CMD_TYPE_MUTE                     = "MUTE"                     // 禁言消息
	CMD_TYPE_UNMUTE                   = "UNMUTE"                   // 取消禁言消息
	CMD_TYPE_WHEAT_ON                 = "MIC_WHEAT_ON"             // 开启麦位
	CMD_TYPE_WHEAT_OFF                = "MIC_WHEAT_OFF"            // 关闭麦位
	CMD_TYPE_MIC_ON                   = "MIC_ON"                   // 上麦
	CMD_TYPE_MIC_OFF                  = "MIC_OFF"                  // 下麦
	CMD_TYPE_MIC_LOCK                 = "MIC_LOCK"                 // 锁麦
	CMD_TYPE_MIC_UNLOCK               = "MIC_UNLOCK"               // 解锁麦
	CMD_TYPE_MIC_BAN_WHEAT            = "MIC_BAN_WHEAT"            // 禁麦
	MIC_CANCEL_BAN_WHEAT              = "MIC_CANCEL_BAN_WHEAT"     // 取消禁麦
	CMD_TYPE_MIC_APPLY                = "MIC_APPLY"                // 申请麦
	CMD_TYPE_MIC_QUIT                 = "MIC_QUIT"                 // 取消排麦
	CMD_TYPE_MIC_WAIT_CLEAR           = "MIC_WAIT_CLEAR"           // 清除排麦
	CMD_TYPE_MIC_ING_CLEAR            = "MIC_ING_CLEAR"            // 清除麦上
	CMD_TYPE_MIC_CLEAR                = "MIC_CLEAR"                // 清除所有麦
	CMD_TYPE_GIFT_SEND                = "GIFT_SEND"                // 送礼
	CMD_TYPE_LIVE_LOVE_ON             = "LIVE_LOVE_ON"             // 开启爱意值
	CMD_TYPE_LIVE_LOVE_OFF            = "LIVE_LOVE_OFF"            // 关闭爱意值
	CMD_TYPE_LIVE_UP                  = "LIVE_UP"                  // 上播
	CMD_TYPE_LIVE_DOWN                = "LIVE_DOWN"                // 下播
	CMD_TYPE_LIVE_CALLBACK_DOWN       = "LIVE_CALLBACK_DOWN"       // 回调下播
	CMD_TYPE_STUDIO_ON                = "STUDIO_ON"                // 开启房间
	CMD_TYPE_STUDIO_OFF               = "STUDIO_OFF"               // 关闭房间
	CMD_TYPE_LIVE_CALLBACK_OFF        = "LIVE_CALLBACK_OFF"        // 回调关闭直播
	CMD_TYPE_LIVE_UPDATE              = "LIVE_UPDATE"              // 更新直播信息
	CMD_TYPE_ICON_SEND                = "ICON_SEND"                // 发送头像表情
	CMD_TYPE_SET_ADMIN                = "SET_ADMIN"                // 设置管理员
	CMD_TYPE_CANCEL_ADMIN             = "CANCEL_ADMIN"             // 取消管理员
	CMD_TYPE_COME_IN                  = "COME_IN"                  // 进入直播间
	CMD_TYPE_BREAK_EGG                = "BREAK_EGG"                // 砸蛋获得道具
	CMD_TYPE_RANK_ROOM_SEND_CLARM     = "RANK_ROOM_SEND_CHARM"     // 更新rank信息
	CMD_TYPE_LIVE_BAN                 = "TYPE_LIVE_BAN"            // 禁封房间
	CMD_TYPE_LIVE_BAN_CANCEL          = "TYPE_LIVE_BAN_CANCEL"     // 取消禁封房间
	CMD_TYPE_LIVE_RECTIFY             = "TYPE_LIVE_RECTIFY"        // 整改房间
	CMD_TYPE_LIVE_RECTIFY_CANCEL      = "TYPE_LIVE_RECTIFY_CANCEL" // 取消整改房间
	CMD_TYPE_LIVE_RECTIFY_FACE_LIGHT  = "TYPE_FACE_LIGHT"          // 爆灯
	CMD_TYPE_LIVE_RECTIFY_FACE_DICE   = "TYPE_FACE_DICE"           // 骰子表情
	CMD_TYPE_LIVE_INVITED_USER_MIC    = "INVITED_USER_MIC"         // 邀请用户上麦
	CMD_TYPE_LIVE_PK_SWITCH_OFF       = "PK_OFF"                   // PK关闭
	CMD_TYPE_LIVE_PK_SWITCH_ON        = "PK_ON"                    // pk开启
	CMD_TYPE_LIVE_PK_EXTEND_TIME      = "EXTEND_TIME"              // pk延长时间
	CMD_TYPE_LIVE_PK_START            = "PK_START"                 // Pk开始
	CMD_TYPE_LIVE_PK_ADVANCE_FINISHED = "ADVANCE_FINISHED"         // 提前结束pk
	CMD_TYPE_LIVE_PK_SYS_FINISHED     = "SYS_FINISHED"             // 系统结束pk
	CMD_TYPE_LIVE_PK_PUNISH_FINISHED  = "PUNISH_FINISHED"          // 结束pk惩罚
	CMD_TYPE_LIVE_PK_DETAIL_PUSH      = "DETAIL_PUSH"              // 结束pk推送
)
const DEFAULT_ONLINE_NUMBER = 50 // 在线人数阈值
const (
	MSG_STYLE_DEFAULT = iota
)

const (
	MSG_SOURCE_SERVICE = iota // 服务器发送
	MSG_SOURCE_ANDROID        // 安卓
	MSG_SOURCE_IOS            // ios
)

// 头像特效
type IconStyle struct {
	IconId int64  `json:"icon_id"` // 装扮id
	BgUrl  string `json:"bg_url"`  // url
	EndT   int64  `json:"end_t"`   // 过期时间
}

func (s *IconStyle) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s IconStyle) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

// 入场特效
type ComeInStyle struct {
	ComeInId int64  `json:"come_in_id"` // 装扮id
	BgUrl    string `json:"bg_url"`     // 背景url
	PetUrl   string `json:"pet_url"`    // 坐骑
	EndT     int64  `json:"end_t"`      // 过期时间
}

func (s *ComeInStyle) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s ComeInStyle) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

// 聊天气泡
type ChatStyle struct {
	ChatId int64  `json:"chat_id"` // 装扮id
	BgUrl  string `json:"bg_url"`  // url
	EndT   int64  `json:"end_t"`   // 过期时间
}

func (s *ChatStyle) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s ChatStyle) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

func (m MsgUserObj) GetMsgUserInfo(userId int64, more map[string]bool) (userInfo MsgUserObj, err error) {
	var userStr = strconv.Itoa(int(userId))
	var u UserInfo

	val := utils.RedisClient.HGetAll(utils.REDIS_USER_INFO + userStr).Val()
	err = utils.HashToStruct(val, &u)
	if err != nil {
		utils.LogErrorF("获取用户信息出错,err:%s", err.Error())
		return
	}
	userInfo.UserId = u.UserID
	userInfo.Gender = u.UserGender
	userInfo.Icon = u.UserIconurl
	userInfo.NickName = u.UserNickname
	userInfo.UserOver = u.WalletTotalOver
	userInfo.UserUnionId = u.UserUnionId
	userInfo.UserSlogan = u.UserSlogan
	userInfo.VipLevel = u.VipLevel
	userInfo.UserPrettyId = u.UserPrettyId
	userInfo.Age = u.UserAge
	if more["icon"] {
		err = utils.RedisClient.Get(utils.REDIS_USER_ICON_INFO + userStr).Scan(&userInfo.IconStyle)
		if err != nil && err != redis.Nil {
			utils.LogErrorF("获取用户头像框信息出错,err:%s", err.Error())
			return
		}
	}
	if more["comeIn"] {
		err = utils.RedisClient.Get(utils.REDIS_USER_COME_IN_INFO + userStr).Scan(&userInfo.ComeInStyle)
		if err != nil && err != redis.Nil {
			utils.LogErrorF("获取用户进场特效信息出错,err:%s", err.Error())
			return
		}
	}
	if more["chat"] {
		err = utils.RedisClient.Get(utils.REDIS_USER_CHAT_INFO + userStr).Scan(&userInfo.ChatStyle)
		if err != nil && err != redis.Nil {
			utils.LogErrorF("获取用户聊天气泡信息出错,err:%s", err.Error())
			return
		}
	}
	err = nil
	return
}

// 设置头像框
func (m *IconStyle) Set(userId int64, propId int64, propUrl string, expTime int64) (err error) {
	key := fmt.Sprintf("%s%d", utils.REDIS_USER_ICON_INFO, userId)
	m.IconId = propId
	m.BgUrl = propUrl
	m.EndT = time.Now().Unix() + expTime
	err = utils.RedisClient.Set(key, m, new(MsgUserObj).handlerDressExpTime(expTime)).Err()
	return
}

// 获取用户头像框
func (m *IconStyle) Get(userId int64) (url string, err error) {
	key := fmt.Sprintf("%s%d", utils.REDIS_USER_ICON_INFO, userId)
	err = utils.RedisClient.Get(key).Scan(m)
	if err != nil && err != redis.Nil {
		return
	}
	return m.BgUrl, nil
}

// 删除头像框
func (m *IconStyle) Del(userId int64) (err error) {
	key := fmt.Sprintf("%s%d", utils.REDIS_USER_ICON_INFO, userId)
	err = utils.RedisClient.Del(key).Err()
	return
}

// 设置入场特效
func (m *ComeInStyle) Set(userId int64, propId int64, propBgUrl string, propPetUrl string, expTime int64) (err error) {
	key := fmt.Sprintf("%s%d", utils.REDIS_USER_COME_IN_INFO, userId)
	m.ComeInId = propId
	m.BgUrl = propBgUrl
	m.PetUrl = propPetUrl
	m.EndT = time.Now().Unix() + expTime
	err = utils.RedisClient.Set(key, m, new(MsgUserObj).handlerDressExpTime(expTime)).Err()
	return
}

// 删除入场特效
func (m *ComeInStyle) Del(userId int64) (err error) {
	key := fmt.Sprintf("%s%d", utils.REDIS_USER_COME_IN_INFO, userId)
	err = utils.RedisClient.Del(key).Err()
	return
}

// 设置头聊天气泡
func (m *ChatStyle) Set(userId int64, propId int64, propUrl string, expTime int64) (err error) {
	key := fmt.Sprintf("%s%d", utils.REDIS_USER_CHAT_INFO, userId)
	m.ChatId = propId
	m.BgUrl = propUrl
	m.EndT = time.Now().Unix() + expTime
	err = utils.RedisClient.Set(key, m, new(MsgUserObj).handlerDressExpTime(expTime)).Err()
	return
}

// 获取用户聊天气泡
func (m *ChatStyle) Get(userId int64) (url string, err error) {
	key := fmt.Sprintf("%s%d", utils.REDIS_USER_CHAT_INFO, userId)
	err = utils.RedisClient.Get(key).Scan(m)
	if err != nil && err != redis.Nil {
		return
	}
	err = nil
	url = m.BgUrl
	return
}

// 删除聊天气泡
func (m *ChatStyle) Del(userId int64) (err error) {
	key := fmt.Sprintf("%s%d", utils.REDIS_USER_CHAT_INFO, userId)
	err = utils.RedisClient.Del(key).Err()
	return
}

// 处理装扮过期时间
func (*MsgUserObj) handlerDressExpTime(expTime int64) (t time.Duration) {
	if expTime == 0 {
		return 0
	}
	exp := expTime - time.Now().Unix()   // 计算时间差/秒
	t = time.Second * time.Duration(exp) // redis所需时间类型转换
	return
}

type SortList []MsgUserObj

func (t SortList) Len() int {
	return len(t)
}
func (s SortList) Swap(i, j int) {
	s[i], s[j] = s[j], s[i]
}
func (t SortList) Less(i, j int) bool {
	return t[i].VipLevel > t[j].VipLevel
}

type MuteList []MsgMuteItem

func (t MuteList) Len() int {
	return len(t)
}
func (s MuteList) Swap(i, j int) {
	s[i], s[j] = s[j], s[i]
}
func (t MuteList) Less(i, j int) bool {
	return t[i].StartT > t[j].StartT
}

func GetMuteUserInfo(wg *sync.WaitGroup, muteInfo chan MsgMuteItem, key string) {
	defer wg.Done()
	var item MsgMuteItem
	err := utils.RedisClient.Get(key).Scan(&item)
	if err != nil {
		utils.LogErrorF("查询信息[%s]失败，err:%s", key, err.Error())
		return
	}
	muteInfo <- item
	return
}

func SliceInterface(reply interface{}, err error, target MsgUserObj) (SortList, error) {
	var result SortList
	err = utils.SliceHelper(reply, err, "interface", func(n int) { result = make(SortList, n) }, func(i int, v interface{}) error {
		switch v := v.(type) {
		case string:
			err = json.Unmarshal([]byte(v), &target)
			if err != nil {
				return err
			}
			result[i] = target
			return nil
		default:
			return fmt.Errorf(" unexpected element type for Strings, got type %T", v)
		}
	})

	return result, err
}

// 获取在线列表
func GetLiveRoomOnline(length int, roomId string) (results SortList, err error) {
	reply := utils.RedisClient.HVals(utils.REDIS_LIVE_ONLINE_MEMBER + roomId).Val()
	var info MsgUserObj
	list, err := SliceInterface(reply, err, info)
	if err != nil {
		return
	}
	sort.Sort(list)
	if length >= len(list) {
		length = len(list)
	}
	results = list[0:length]
	return
}
