package redismodels

import (
	"encoding/json"
	"gamers/models/dbmodels"
	"gamers/utils"
	"strconv"
	"time"

	"github.com/go-redis/redis"
	"gorm.io/gorm"
)

const (
	// 麦序队列动作
	WHEAT_QUEUE_ACTION_DEL   int = iota // 删除
	WHEAT_QUEUE_ACTION_ADD              // 增加
	WHEAT_QUEUE_ACTION_EMPTY            // 清空
)

// 麦序队列
type WheatQueue struct {
	UserId       int    `json:"user_id"`        // 用户id
	UserNickName string `json:"user_nick_name"` // 用户昵称
	UserIconurl  string `json:"user_iconurl"`   // 用户头像
	UserGender   int    `json:"user_gender"`    // 用户性别:0--未知,1--男,2--女
	UserAge      int    `json:"user_age"`       // 用户年龄
	UserLevel    int    `json:"user_level"`     // 用户等级
	IsAdmin      int    `json:"is_admin"`       // 是否房管：0--否,1--是
	Date         int64  `json:"date"`           // 时间
}

// 查询直播间缓存是否存在
func (m *WheatQueue) queryExist(key string) (err error) {
	err = utils.RedisClient.Get(key).Err()
	return
}

// 查询用户是否在麦序中
func (m *WheatQueue) QueryWheatQueueByUserId(key string, userId int64) (val string, err error) {
	val, err = utils.RedisClient.HGet(key, strconv.Itoa(int(userId))).Result()
	return
}

// 删除麦序
func (m *WheatQueue) Delete(key string) (err error) {
	err = utils.RedisClient.Del(key).Err()
	return
}

// 增加用户麦序
func (m *WheatQueue) addWheatQueue(roomId int, userId int64) (data WheatQueue, err error) {
	key := utils.REDIS_LIVE_WHEAT_QUEUE + strconv.Itoa(roomId)
	// 取用户信息
	userNickName := utils.RedisClient.HGet(utils.REDIS_USER_INFO+strconv.Itoa(int(userId)), "UserNickname").Val()
	userIconurl := utils.RedisClient.HGet(utils.REDIS_USER_INFO+strconv.Itoa(int(userId)), "UserIconurl").Val()

	// 查询用户信息
	model := dbmodels.SystemUser{}
	user, err := model.UserIdByUser(userId)
	if err != nil {
		return
	}

	// 是否房管
	adminRoomModel := dbmodels.AppRoomAdmin{}
	exits, err := adminRoomModel.QueryExits(userId, int64(roomId))
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}

	level, _ := new(UserInfo).GetUserVipLevel(userId)
	data = WheatQueue{
		UserId:       int(userId),
		UserNickName: userNickName,
		UserIconurl:  userIconurl,
		UserGender:   user.UserGender,
		UserAge:      utils.FuncGetAge(int(user.UserBirthday)),
		UserLevel:    level,
		Date:         time.Now().Unix(),
	}
	if exits > 0 {
		data.IsAdmin = 1
	} else {
		data.IsAdmin = 0
	}

	v, _ := json.Marshal(data)
	err = utils.RedisClient.HSet(key, strconv.Itoa(int(userId)), string(v)).Err()
	return
}

// 删除指定的队列
func (m *WheatQueue) delWheatQueue(key string, userId int64) (err error) {
	err = utils.RedisClient.HDel(key, strconv.Itoa(int(userId))).Err()
	return
}

// 更新麦序队列
func (m *WheatQueue) Update(roomId int, userId int64, action int) (data interface{}, err error) {
	key := utils.REDIS_LIVE_WHEAT_QUEUE + strconv.Itoa(roomId)
	_lockVal, islock := utils.AcquireLock(key, utils.DEFAULT_LOCK_KEY_TIMEOUT, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT)
	if !islock {
		err = ErrWheatLater
		return
	}
	defer utils.ReleaseLock(key, _lockVal)

	wheatModel := Wheat{}
	// 获取麦位详情
	wheatDetail, err := wheatModel.QueryWheatDetail(roomId)
	if err != nil {
		return
	}

	if wheatDetail.WheatSwitch == WHEAT_SWITCH_OFF {
		err = ErrWheatUnopened
		return
	}
	// 查询指定用户的麦序
	_, err = m.QueryWheatQueueByUserId(key, userId)
	switch action {
	case WHEAT_QUEUE_ACTION_DEL: // 删除
		err = m.delWheatQueue(key, userId)
		if err != nil {
			return
		}
		data = struct {
			UserId int `json:"user_id"`
		}{UserId: int(userId)}
	case WHEAT_QUEUE_ACTION_ADD: // 增加
		if err == redis.Nil {
			// 查询下用户身份
			var role int
			role, err = new(Wheat).QueryUserRole(roomId, userId)
			if err != nil {
				return nil, err
			}
			if role != WHEAT_ROLE_USER {
				err = ErrWheatNotANormalUser
				return nil, err
			}

			// 不存在数据，创建麦序
			data, err = m.addWheatQueue(roomId, userId)
			if err != nil {
				return nil, err
			}
		} else {
			err = ErrWheatAlreadyQueue
		}
	default: // 清空
		// 查询上麦用户用户身份
		role, err := new(Wheat).QueryUserRole(roomId, userId)
		if err != nil {
			return nil, err
		}
		if role != WHEAT_ROLE_USER {
			err = m.Delete(key)
			return data, err
		} else {
			err = ErrWheatNoAuth
			return data, err
		}
	}

	return
}

// 查询麦序列表
func (m *WheatQueue) QueryList(roomId int) (data []WheatQueue, err error) {
	key := utils.REDIS_LIVE_WHEAT_QUEUE + strconv.Itoa(roomId)
	values, err := utils.RedisClient.HGetAll(key).Result()
	if err != nil {
		return
	}
	tmp := []WheatQueue{}
	for _, v := range values {
		userInfo := WheatQueue{}
		json.Unmarshal([]byte(v), &userInfo)
		tmp = append(tmp, userInfo)
	}
	// 麦序小于1条不排序
	if len(tmp) <= 1 {
		data = tmp
		return
	}
	// 根据时间排序
	date := []int64{}
	for _, v := range tmp {
		date = append(date, v.Date)
	}
	// 冒泡排序
	for i := 0; i < len(date); i++ {
		for j := i + 1; j < len(date); j++ {
			if date[j] < date[j-1] {
				date[j], date[j-1] = date[j-1], date[j]
			}
		}
	}
	// 按照时间顺序排序
	for _, v := range date {
		for _, val := range tmp {
			if v == val.Date {
				data = append(data, val)
				break
			}
		}
	}
	return
}

// 系统下麦序
// 指定用户踢下麦序
func (m *WheatQueue) SystemDown(roomId int, userId int) (isChanged bool, data interface{}, err error) {
	key := utils.REDIS_LIVE_WHEAT_QUEUE + strconv.Itoa(roomId)
	// 查询指定用户的麦序
	_, err = m.QueryWheatQueueByUserId(key, int64(userId))
	if err != nil {
		return
	}
	// 用户在麦序上,删除
	err = m.delWheatQueue(key, int64(userId))
	if err != nil {
		return
	}
	data = struct {
		UserId int `json:"user_id"`
	}{UserId: userId}
	isChanged = true
	return
}

// 确认下播
func (m *WheatQueue) ConfirmDowncast(roomId int) (err error) {
	key := utils.REDIS_LIVE_WHEAT_QUEUE + strconv.Itoa(roomId)
	err = m.Delete(key)
	return
}
