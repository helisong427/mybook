package redismodels

import (
	"gamers/utils"
	"strconv"
	"time"
)

//抱上下麦位策略模式
type wheatHugStrategy interface {

	//detail 麦位详情
	//roomId 房间id
	//wheatUserId 用户id(麦上/麦下)
	//wheatKey 麦位Key
	//wheatUserRole被操作用户身份
	//apiUserRole请求接口用户身份
	hugUP(detail Wheat, roomId int, wheatUserId int64, wheatKey int, wheatUserRole int, apiUserRole int) (data Wheat, err error)
	hugDown(detail Wheat, roomId int, wheatUserId int64, wheatKey int, wheatUserRole int, apiUserRole int) (data Wheat, err error)
}

//普通用户
type wheatUserHug struct{}

//管理员
type wheatAdminHug struct{}

//副管理员
type wheatDeputyAdminHug struct{}

//主播
type wheatAnchorHug struct{}

type WheatHugContext struct {
	Strategy wheatHugStrategy
}

//用户身份
func newWheatHugContext(apiUserRole int) WheatHugContext {
	c := new(WheatHugContext)
	switch apiUserRole {
	case WHEAT_ROLE_USER:
		c.Strategy = newWheatUserHug()
	case WHEAT_ROLE_DEPUTY_ADMIN:
		c.Strategy = newWheatAdminHug()
	case WHEAT_ROLE_ADMIN:
		c.Strategy = newWheatDeputyAdminHug()
	default:
		c.Strategy = newWheatAnchorHug()
	}
	return *c
}

func (w WheatHugContext) hugUP(detail Wheat, roomId int, wheatUserId int64, wheatKey int, wheatUserRole int, apiUserRole int) (data Wheat, err error) {
	if err = wheatComm(detail, wheatKey); err != nil {
		return
	}

	//不能越级操作
	if wheatUserRole >= apiUserRole {
		err = ErrWheatNoAuth
		return
	}

	for i := 1; i < detail.WheatLen; i++ {
		//如果用户已在麦上
		if detail.WheatObj[i].UserId == int(wheatUserId) {
			err = ErrWheatAlready
			return
		}
	}

	for i := 1; i < detail.WheatLen; i++ {
		//查找空闲麦位
		if detail.WheatObj[i].UserId == 0 && detail.WheatObj[i].Status == WHEAT_STATUS_UNLOCK {
			wheatKey = i
			break
		}
	}
	if wheatKey == 0 {
		err = ErrWheatNoFree
		return
	}

	return w.Strategy.hugUP(detail, roomId, wheatUserId, wheatKey, wheatUserRole, apiUserRole)
}

func (w WheatHugContext) hugDown(detail Wheat, roomId int, wheatUserId int64, wheatKey int, wheatUserRole int, apiUserRole int) (data Wheat, err error) {
	if err = wheatComm(detail, wheatKey); err != nil {
		return
	}

	//普通用户无权操作
	if apiUserRole == WHEAT_ROLE_USER {
		err = ErrWheatNoAuth
		return
	}

	//不能越级操作
	if wheatUserRole >= apiUserRole {
		err = ErrWheatNoAuth
		return
	}

	if wheatKey == WHEAT_HOME_KEY {
		err = ErrWheatNoAnchorWheat
		return
	}

	//下麦
	detail.WheatObj[wheatKey].UserId = 0
	detail.WheatObj[wheatKey].UserNickName = ""
	detail.WheatObj[wheatKey].UserIconurl = ""
	detail.WheatObj[wheatKey].UserGender = 0
	detail.WheatObj[wheatKey].UserAvatarDressUp = ""
	detail.WheatObj[wheatKey].Role = WHEAT_ROLE_USER
	detail.WheatObj[wheatKey].LoveValue = 0
	detail.WheatObj[wheatKey].Status = WHEAT_STATUS_UNLOCK
	detail.WheatObj[wheatKey].UpdateTime = time.Now().Unix()
	return wheatUpdateWheatHug(detail, roomId, wheatKey)
}

//实例化普通用户
func newWheatUserHug() wheatUserHug {
	w := new(wheatUserHug)
	return *w
}

func (w wheatUserHug) hugUP(detail Wheat, roomId int, wheatUserId int64, wheatKey int, wheatUserRole int, apiUserRole int) (data Wheat, err error) {
	//普通用户无权操作
	if apiUserRole == WHEAT_ROLE_USER {
		err = ErrWheatNoAuth
		return
	}
	return
}

func (w wheatUserHug) hugDown(detail Wheat, roomId int, wheatUserId int64, wheatKey int, wheatUserRole int, apiUserRole int) (data Wheat, err error) {
	return
}

//实例化管理员
func newWheatAdminHug() wheatAdminHug {
	w := new(wheatAdminHug)
	return *w
}

func (w wheatAdminHug) hugUP(detail Wheat, roomId int, wheatUserId int64, wheatKey int, wheatUserRole int, apiUserRole int) (data Wheat, err error) {
	userInfo, avatarDressUp, love, err := detail.GetUpWheatUserInfo(wheatUserId, roomId)
	if err != nil {
		return
	}

	detail.WheatObj[wheatKey].UserId = int(wheatUserId)
	detail.WheatObj[wheatKey].UserNickName = userInfo.UserNickname
	detail.WheatObj[wheatKey].UserIconurl = userInfo.UserIconurl
	detail.WheatObj[wheatKey].UserGender = userInfo.UserGender
	detail.WheatObj[wheatKey].UserAvatarDressUp = avatarDressUp
	detail.WheatObj[wheatKey].Role = wheatUserRole
	detail.WheatObj[wheatKey].LoveValue = love
	detail.WheatObj[wheatKey].Status = WHEAT_STATUS_BAN_WHEAT
	detail.WheatObj[wheatKey].UpdateTime = time.Now().Unix()
	return wheatUpdateWheatHug(detail, roomId, wheatKey)
}

func (w wheatAdminHug) hugDown(detail Wheat, roomId int, wheatUserId int64, wheatKey int, wheatUserRole int, apiUserRole int) (data Wheat, err error) {
	return
}

//实例化副管理员
func newWheatDeputyAdminHug() wheatDeputyAdminHug {
	w := new(wheatDeputyAdminHug)
	return *w
}

func (w wheatDeputyAdminHug) hugUP(detail Wheat, roomId int, wheatUserId int64, wheatKey int, wheatUserRole int, apiUserRole int) (data Wheat, err error) {
	userInfo, avatarDressUp, love, err := detail.GetUpWheatUserInfo(wheatUserId, roomId)
	if err != nil {
		return
	}
	detail.WheatObj[wheatKey].UserId = int(wheatUserId)
	detail.WheatObj[wheatKey].UserNickName = userInfo.UserNickname
	detail.WheatObj[wheatKey].UserIconurl = userInfo.UserIconurl
	detail.WheatObj[wheatKey].UserGender = userInfo.UserGender
	detail.WheatObj[wheatKey].UserAvatarDressUp = avatarDressUp
	detail.WheatObj[wheatKey].Role = wheatUserRole
	detail.WheatObj[wheatKey].LoveValue = love
	detail.WheatObj[wheatKey].Status = WHEAT_STATUS_BAN_WHEAT
	detail.WheatObj[wheatKey].UpdateTime = time.Now().Unix()
	return wheatUpdateWheatHug(detail, roomId, wheatKey)
}

func (w wheatDeputyAdminHug) hugDown(detail Wheat, roomId int, wheatUserId int64, wheatKey int, wheatUserRole int, apiUserRole int) (data Wheat, err error) {
	return
}

//实例化主播
func newWheatAnchorHug() wheatAnchorHug {
	w := new(wheatAnchorHug)
	return *w
}

func (w wheatAnchorHug) hugUP(detail Wheat, roomId int, wheatUserId int64, wheatKey int, wheatUserRole int, apiUserRole int) (data Wheat, err error) {
	userInfo, avatarDressUp, love, err := detail.GetUpWheatUserInfo(wheatUserId, roomId)
	if err != nil {
		return
	}

	detail.WheatObj[wheatKey].UserId = int(wheatUserId)
	detail.WheatObj[wheatKey].UserNickName = userInfo.UserNickname
	detail.WheatObj[wheatKey].UserIconurl = userInfo.UserIconurl
	detail.WheatObj[wheatKey].UserGender = userInfo.UserGender
	detail.WheatObj[wheatKey].UserAvatarDressUp = avatarDressUp
	detail.WheatObj[wheatKey].Role = wheatUserRole
	detail.WheatObj[wheatKey].LoveValue = love
	detail.WheatObj[wheatKey].Status = WHEAT_STATUS_BAN_WHEAT
	detail.WheatObj[wheatKey].UpdateTime = time.Now().Unix()
	return wheatUpdateWheatHug(detail, roomId, wheatKey)
}

func (w wheatAnchorHug) hugDown(detail Wheat, roomId int, wheatUserId int64, wheatKey int, wheatUserRole int, apiUserRole int) (data Wheat, err error) {
	return
}

//更新麦位
//roomId 房间
//detail 麦位信息
//occupyKey 占用的麦位
//key 使用的麦位
func wheatUpdateWheatHug(detail Wheat, roomId int, wheatKey int) (data Wheat, err error) {
	cacheKey := utils.REDIS_LIVE_WHEAT + strconv.Itoa(roomId)

	//更新麦位
	err = new(Wheat).updateWheatObj(cacheKey, detail.WheatObj)
	if err != nil {
		return
	}
	data, err = new(Wheat).QueryWheatDetail(roomId)
	if err != nil {
		return
	}
	data.WheatObj = data.WheatObj[:0]                                //清空
	data.WheatObj = append(data.WheatObj, detail.WheatObj[wheatKey]) //重新赋值
	return
}
