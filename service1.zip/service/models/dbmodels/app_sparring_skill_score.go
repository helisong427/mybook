package dbmodels

import (
	"gamers/utils"
	"gorm.io/gorm"
)

// 技能得分
type AppSparringSkillScore struct {
	ScoreId                  int64   `gorm:"column:score_id"`
	ScoreUserId              int64   `gorm:"column:score_user_id"`               // 大神用户id
	ScoreSkillId             int64   `gorm:"column:score_skill_id"`              // 技能id
	ScoreSparringSkillId     int64   `gorm:"column:score_sparring_skill_id"`     // 大神技能id，对应app_sparring_skill表的主键
	ScoreOrderTotalCount     int64   `gorm:"column:score_order_total_count"`     // 总订单数量
	ScoreOrderCount          int64   `gorm:"column:score_order_count"`           // 大神接单数量
	ScorePraiseCount         int64   `gorm:"column:score_praise_count"`          // 好评数
	ScoreCommentTotal        int64   `gorm:"column:score_comment_total"`         // 评论总数
	ScoreRefundCount         int64   `gorm:"column:score_refund_count"`          // 退款数量
	ScoreSparringCancelCount int64   `gorm:"column:score_sparring_cancel_count"` // 大神取消数量
	ScoreConsumerCancelCount int64   `gorm:"column:score_consumer_cancel_count"` // 消费者取消数量
	ScoreRealScore           int64   `gorm:"column:score_real_score"`            // 真实积分(计算得来)
	ScoreInterventionScore   int64   `gorm:"column:score_intervention_score"`    // 后台干预分数
	ScoreOrderSpeed          float64 `gorm:"column:score_order_speed"`           // 接单速度
	BaseModel
}

func (m *AppSparringSkillScore) TableName() string {
	return "app_sparring_skill_score"
}

func (m *AppSparringSkillScore) UpdateBySparringId(sparringId int64, update map[string]interface{}) error {
	return utils.GEngine.Model(m).Where("deleted = 0").Where("score_sparring_skill_id = ?", sparringId).Updates(update).Error
}

// 更新 已经删除的数据(也就是恢复)
func (m *AppSparringSkillScore) UpdateHasDeletedBySparringId(sparringId int64, update map[string]interface{}) error {
	return utils.GEngine.Model(m).Where("score_sparring_skill_id = ?", sparringId).Updates(update).Error
}

// 通过大神Id获取记录
func (m *AppSparringSkillScore) QueryBySparringSkillId(sparringId int64) (result *AppSparringSkillScore, err error) {
	var (
		data AppSparringSkillScore
	)

	if err = utils.GEngine.Model(m).Where("score_sparring_skill_id = ?", sparringId).First(&data).Error; err != nil {
		if err == gorm.ErrRecordNotFound {
			err = nil
		}
	}

	result = &data

	return
}
