/**
 * @Author: panke
 * @Description:
 * @File: app_turn_table
 * @Date: 2021/4/22 14:51
 */

package dbmodels

import "gamers/utils"

type AppTurnTable struct {
	TurnTableID             int                       `json:"turn_table_id" gorm:"column:turn_table_id"`
	TurnTableTitle          string                    `json:"turn_table_title" gorm:"column:turn_table_title"`                       // 转盘名称
	TurnTableCostPropType   int                       `json:"turn_table_cost_prop_type" gorm:"column:turn_table_cost_prop_type"`     // 消耗物品类型(0go币,1礼物,2锤子,3头像框,4聊天框,5座驾,6活动道具,7实物道具,8Go币道具)
	TurnTableCostPropID     int64                     `json:"turn_table_cost_prop_id" gorm:"column:turn_table_cost_prop_id"`         // 消耗物品id
	TurnTableCostPropCount  int64                     `json:"turn_table_cost_prop_count" gorm:"column:turn_table_cost_prop_count"`   // 消耗物品数量
	TurnTableStatus         int                       `json:"turn_table_status" gorm:"column:turn_table_status"`                     // 转盘状态(0计划中,1开始,2结束)
	TurnTableStartTime      int                       `json:"turn_table_start_time" gorm:"column:turn_table_start_time"`             // 转盘开始时间
	TurnTableEndTime        int                       `json:"turn_table_end_time" gorm:"column:turn_table_end_time"`                 // 转盘结束时间
	TurnTableDesc           string                    `json:"turn_table_desc" gorm:"column:turn_table_desc"`                         // 转盘描述
	TurnTableManageID       int                       `json:"turn_table_manage_id" gorm:"column:turn_table_manage_id"`               // 创建转盘管理员id
	TurnTableBg             string                    `json:"turn_table_bg" gorm:"column:turn_table_bg"`                             // 转盘活动背景图
	TurnTableUpdateManageID int                       `json:"turn_table_update_manage_id" gorm:"column:turn_table_update_manage_id"` // 更新转盘管理员id
	AppTurnTablePool        []*AppTurnTablePool       `gorm:"foreignKey:PoolTurnTableID;references:TurnTableID"`                     // 关联奖池
	AppTurnTableRewardRate  []*AppTurnTableRewardRate `gorm:"foreignKey:RateTurnTableID;references:TurnTableID"`                     // 关联奖池概率表
	AppProp                 AppProp                   `gorm:"foreignKey:PropId;references:TurnTableCostPropID"`                      // 关联道具
	BaseModel
}

func (m *AppTurnTable) TableName() string {
	return "app_turn_table"
}

const (
	// 奖池状态
	DB_TURNTABLE_STATUS_CLOSE int = iota // 计划中
	DB_TURNTABLE_STATUS_OPEN             // 开始
	DB_TURNTABLE_STATUS_END              // 结束
)

// 查询全部
func (m *AppTurnTable) QueryAll() (data []AppTurnTable, err error) {
	err = utils.GEngine.Model(m).
		Preload("AppTurnTablePool").
		Preload("AppTurnTablePool.AppTurnTableReward").
		Preload("AppTurnTablePool.AppTurnTableReward.AppProp").
		Preload("AppTurnTableRewardRate").
		Preload("AppTurnTableRewardRate.AppProp").
		Preload("AppProp").
		Find(&data).Error
	return
}

// 查询一条记录
func (m *AppTurnTable) QueryFirst(turnTableId int) (row int64, data AppTurnTable, err error) {
	model := utils.GEngine.Where("turn_table_id = ?", turnTableId).First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

// 根据turn_table_id查询
func (m *AppTurnTable) QueryByTurnTableId(turnTableId int64) (data AppTurnTable, err error) {
	err = utils.GEngine.Model(m).Preload("AppTurnTablePool").
		Preload("AppTurnTablePool.AppTurnTableReward").
		Preload("AppTurnTablePool.AppTurnTableReward.AppProp").
		Preload("AppProp").
		Where("turn_table_id=?", turnTableId).First(&data).Error
	return
}
