package dbmodels

import (
	"gamers/utils"
)

type AppLiveAttr struct {
	AttrID         int64     `json:"attr_id" gorm:"column:attr_id;primaryKey;autoIncrement"`
	AttrName       string    `json:"attr_name"`       // AttrName 属性名称
	AttrType       int       `json:"attr_type"`       // 属性分类，0直播，1派对
	AttrSort       int64     `json:"attr_sort"`       // AttrSort 排序
	AttrDirections string    `json:"attr_directions"` // 直播属性说明
	AttrDemand     string    `json:"attr_demand"`     // 直播属性要求
	AttrIsShow     int       `json:"attr_is_show"`    // AttrIsShow 是否显示(0不显示,1显示)
	AttrBackground string    `json:"attr_background"` // 房间系统默认背景图,json格式["https://img.tupianzj.com/uploads/Bizhi/mn1_1366.jpg","http://pic1.win4000.com/pic/1/91/66ee942425.jpg"]'
	AttrDefault    int       `json:"attr_default"`    // 默认属性,创建派对房时的默认属性
	BaseModel      BaseModel `gorm:"embedded" json:"base_model"`
}

func (AppLiveAttr) TableName() string {
	return "app_live_attr"
}

const (
	LIVE_ATTR_TYPE_LIVE = iota
	LIVE_ATTR_TYPE_PARTY
)

// 是否默认标签
const (
	LIVE_ATTR_DEFAULT_NO = iota
	LIVE_ATTR_DEFAULT_OK
)

// 根据id查询attr
func (m *AppLiveAttr) GetAppLiveAttrById(id int64) (attr AppLiveAttr, err error) {
	err = utils.GEngine.Model(m).Where("attr_id = ? and deleted = 0", id).First(&attr).Error
	return
}

// 根据id和type查询attr
func (m *AppLiveAttr) GetAppLiveAttrByIdAndType(id int64, attrType int) (attr AppLiveAttr, err error) {
	err = utils.GEngine.Model(m).Where("attr_id = ? and deleted = 0 and attr_type = ?", id, attrType).First(&attr).Error
	return
}

// 查询attr
func (m *AppLiveAttr) QueryAttrByAnchor() (data []AppLiveAttr, err error) {
	err = utils.GEngine.Model(m).Where("attr_is_show = 1 and deleted = 0 and attr_type = ?", LIVE_ATTR_TYPE_LIVE).Order("attr_sort desc").Find(&data).Error
	return
}

// 查询attr，用户开房间用的
func (m *AppLiveAttr) QueryAttrByLiveRoom(userId int64) (data []AppLiveAttr, err error) {
	var attrIds []int64
	err = utils.GEngine.Table("app_anchor_skill").Select("skill_attr_id").Where("skill_user_id = ? and skill_status = ? and deleted = 0", userId, ANCHOR_SKILL_STATUS_OK).Find(&attrIds).Error
	if err != nil {
		return
	}
	err = utils.GEngine.Model(m).Where("attr_type = ? and deleted = 0", LIVE_ATTR_TYPE_PARTY).
		Or("attr_is_show = 1 and deleted = 0 and attr_id IN ?", attrIds).Group("attr_type").Find(&data).Error
	return
}

//根据类型查询
func (m *AppLiveAttr) QueryByAttrType(attrType int) (data []AppLiveAttr, err error) {
	err = utils.GEngine.Where("attr_type = ? and attr_is_show = ? and deleted = 0", attrType, 1).Order("attr_sort desc").Find(&data).Error
	return
}

// 获取默认派对标签
func (m *AppLiveAttr) GetPartyDefaultAttr() (data AppLiveAttr, err error) {
	err = utils.GEngine.Where("attr_type = 1 and attr_default = ? and deleted = 0", LIVE_ATTR_DEFAULT_OK).First(&data).Error
	return
}
