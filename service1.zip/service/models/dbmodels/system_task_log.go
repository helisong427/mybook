package dbmodels

import (
	"gamers/utils"
	"time"

	"gorm.io/gorm"
)

// 系统定时任务表
type SystemTaskLog struct {
	LogId                 int64     `gorm:"column:log_id;primaryKey;autoIncrement" json:"log_id"`
	LogTaskId             string    `gorm:"column:log_task_id" json:"log_task_id"`
	LogTaskType           int       `gorm:"column:log_task_type" json:"log_task_type"`
	LogTaskTopic          string    `gorm:"column:log_task_topic" json:"log_task_topic"`
	LogTaskFinishedStatus int64     `gorm:"column:log_task_finished_status" json:"log_task_finished_status"` // 0初始化，1成功，2部分成功，3fail
	LogTaskInfo           string    `gorm:"column:log_task_info" json:"log_task_info"`
	LogTaskExecuteTime    int64     `gorm:"column:log_task_execute_time" json:"log_task_execute_time"`
	LogTaskTimeoutTime    int64     `gorm:"column:log_task_timeout_time" json:"log_task_timeout_time"`
	BaseModel             BaseModel `gorm:"embedded" json:"base_model"`
}

const (
	TASK_FINISHED_STATUS_INIT    = iota // 初始化
	TASK_FINISHED_STATUS_OK             // 成功
	TASK_FINISHED_STATUS_PART_OK        // 部分成功
	TASK_FINISHED_STATUS_FAIL           // 失败
)

func (SystemTaskLog) TableName() string {
	return "system_task_log"
}

func (m *SystemTaskLog) Create() (err error) {
	err = utils.GEngine.Create(m).Error
	return
}

func (m *SystemTaskLog) Del(id int64) (err error) {
	now := time.Now().Unix()
	err = utils.GEngine.Model(m).Where("log_id = ?", id).Update("deleted", now).Error
	return
}

func (m SystemTaskLog) GetTasksWithoutFinished() (data []SystemTaskLog, err error) {
	now := time.Now().Unix()
	err = utils.GEngine.Model(m).Where("log_task_finished_status = ? and deleted = 0 and log_task_execute_time > ?", TASK_FINISHED_STATUS_INIT, now).Find(&data).Error
	return
}

// 更新任务执行状态
func (m *SystemTaskLog) UpdateTaskStatus(id int64, status int) (err error) {
	err = utils.GEngine.Model(m).Where("log_id = ?", id).Update("log_task_finished_status", status).Error
	return
}

// AddTime 添加时间
func (m *SystemTaskLog) AddTime(id, time int64) (err error) {
	err = utils.GEngine.Model(m).Where("log_id = ?", id).
		Updates(map[string]interface{}{"log_task_execute_time": gorm.Expr("log_task_execute_time + ?", time)}).Error
	return
}
