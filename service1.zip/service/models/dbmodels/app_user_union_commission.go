package dbmodels

import (
	"encoding/json"
	"gamers/utils"
	"strconv"

	"github.com/go-redis/redis"
	"gorm.io/gorm"
)

// 抽成比例
type AppUserUnionCommission struct {
	CommissionId       int64     `gorm:"column:commission_id;primaryKey;autoIncrement" json:"commission_id"` // 用户公会提成id
	CommissionType     int       `gorm:"column:commission_type" json:"commission_type"`                      // 抽成事件类型 1礼物,2陪玩订单
	CommissionLevel    int       `gorm:"column:commission_level" json:"commission_level"`                    // 抽成等级
	CommissionUnionId  int64     `gorm:"column:commission_union_id" json:"commission_union_id"`              // 公会id  为0且 commission_user_id 为0表示 普通人的分成比例
	CommissionUserId   int64     `gorm:"column:commission_user_id" json:"commission_user_id"`                // 用户id 为0表示公会默认比例
	CommissionPlatform int64     `gorm:"column:commission_platform" json:"commission_platform"`              // 平台分成比例 即 50=50%
	CommissionUnion    int64     `gorm:"column:commission_union" json:"commission_union"`                    // 公会分成比例
	CommissionUser     int64     `gorm:"column:commission_user" json:"commission_user"`                      // 用户分成比例
	BaseModel          BaseModel `gorm:"embedded" json:"base_model"`
}

func (AppUserUnionCommission) TableName() string {
	return "app_user_union_commission"
}
func (s *AppUserUnionCommission) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s AppUserUnionCommission) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

const (
	COMMISSION_TYPE_GIFT        = iota + 1 // 抽成类型礼物
	COMMISSION_TYPE_SKILL_ORDER            // 抽成类型 订单
)

const DEFAULT_SKILL_ORDER_COMMISSION_LEVEL = 1

// 获取抽成比例
func (m *AppUserUnionCommission) GetCommissionByUserIdAndType(userId, unionId int64, commissionType, commissionLevel int) (data AppUserUnionCommission, err error) {
	mainKey := utils.REDIS_USER_COMMISSION_INFO + strconv.Itoa(int(userId))
	secondKey := strconv.Itoa(int(unionId)) + ":" + strconv.Itoa(commissionType) + ":" + strconv.Itoa(commissionLevel)
	// 无数据，无公会
	if unionId == 0 {
		mainKey = utils.REDIS_USER_COMMISSION_INFO + "0"
		err = utils.RedisClient.HGet(mainKey, secondKey).Scan(&data)
		if err != nil && err != redis.Nil {
			return
		}
		if err == nil {
			return
		}
		err = utils.GEngine.Model(m).Where("commission_user_id = 0 and commission_union_id = 0 AND commission_type = ? and commission_level = ? and deleted = 0", commissionType, commissionLevel).First(&data).Error
		if err != nil {
			utils.LogErrorF("查询用户抽成比例出错,err:%s", err.Error())
			return
		}
		err = utils.RedisClient.HSet(mainKey, secondKey, data).Err()
		return
	}
	// 缓存查询
	err = utils.RedisClient.HGet(mainKey, secondKey).Scan(&data)
	if err != nil && err != redis.Nil {
		return
	}
	if err == nil {
		return
	}
	// 有公会，有单独抽成比例
	err = utils.GEngine.Model(m).Where("commission_user_id = ? and commission_union_id = ? and commission_type = ? and commission_level = ? and deleted = 0", userId, unionId, commissionType, commissionLevel).First(&data).Error
	if err != nil && err != gorm.ErrRecordNotFound {
		utils.LogErrorF("查询用户抽成比例出错,err:%s", err.Error())
		return
	}
	// 查询到有数据
	if err == nil {
		err = utils.RedisClient.HSet(mainKey, secondKey, data).Err()
		return
	}
	// 无数据，有公会，公用抽成比例
	err = utils.GEngine.Model(m).Where("commission_user_id = 0 and commission_union_id = ? and commission_type = ? and commission_level = ? and deleted = 0", unionId, commissionType, commissionLevel).First(&data).Error
	if err != nil && err != gorm.ErrRecordNotFound {
		utils.LogErrorF("查询用户抽成比例出错,err:%s", err.Error())
		return
	}
	if err == nil {
		err = utils.RedisClient.HSet(mainKey, secondKey, data).Err()
		return
	}
	// 有公会,无公共抽成比例
	data = AppUserUnionCommission{
		CommissionType:     commissionType,
		CommissionLevel:    commissionLevel,
		CommissionId:       userId,
		CommissionUnionId:  unionId,
		CommissionPlatform: 100,
		CommissionUnion:    0,
		CommissionUser:     0,
	}
	err = utils.RedisClient.HSet(mainKey, secondKey, data).Err()
	return
}
