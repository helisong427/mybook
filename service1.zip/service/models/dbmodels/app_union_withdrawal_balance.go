package dbmodels

import (
	"gorm.io/gorm"
)

// 公会余额表
type AppUnionWithdrawalBalance struct {
	BalanceId           int64  `gorm:"column:balance_id;primaryKey;autoIncrement"` // 余额表主键ID
	BalanceUnionId      int64  `gorm:"column:balance_union_id"`                    // 公会ID
	BalanceTotalAmount  int64  `gorm:"column:balance_total_amount"`                // 累计总金额
	BalanceTotalBalance uint64 `gorm:"column:balance_total_balance"`               // 可使用总余额
	BalanceTotalUse     int64  `gorm:"column:balance_total_use"`                   // 总已使用金额
	BalanceWeekReward   int64  `gorm:"column:balance_week_reward"`                 // 累计周奖励
	BalanceMonthReward  int64  `gorm:"column:balance_month_reward"`                // 累计月奖励
	BaseModel
}

func (m *AppUnionWithdrawalBalance) TableName() string {
	return "app_union_withdrawal_balance"
}

func (m *AppUnionWithdrawalBalance) Create(tx *gorm.DB) error {
	return tx.Create(m).Error
}

func (m *AppUnionWithdrawalBalance) QueryUnionFirst(tx *gorm.DB, unionId int64) (data AppUnionWithdrawalBalance, err error) {
	err = tx.Model(m).Where("balance_union_id = ? AND deleted = 0", unionId).First(&data).Error
	return
}

// 增加公会余额
func (m *AppUnionWithdrawalBalance) AddAmount(tx *gorm.DB, unionId int64, amount int64) (err error) {
	var balanceId int64
	data, err := m.QueryUnionFirst(tx, unionId)
	if err != nil {
		if err != gorm.ErrRecordNotFound {
			return
		} else {
			m.BalanceUnionId = unionId
			err = m.Create(tx)
			if err != nil {
				return
			}
			balanceId = m.BalanceId
		}
	} else {
		balanceId = data.BalanceId
	}

	err = tx.Model(m).Where("balance_id = ?", balanceId).
		Updates(map[string]interface{}{
			"balance_total_balance": gorm.Expr("balance_total_balance + ?", amount),
			"balance_total_amount":  gorm.Expr("balance_total_amount + ?", amount),
		}).Error
	return
}
