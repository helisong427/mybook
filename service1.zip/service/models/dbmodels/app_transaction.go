package dbmodels

import (
	"gamers/controller/response"
	"gamers/utils"
	"gorm.io/gorm"
	"time"
)

//交易流水表
type AppTransaction struct {
	TransactionId              int64  `gorm:"column:transaction_id;primaryKey;autoIncrement"` //交易id
	TransactionType            int    `gorm:"column:transaction_type"`                        //交易类型(0余额转go币,1充值go币,2余额提现,3系统赠送到余额,4系统赠送到收入,5系统冻结,6购买锤子,7购买头像框,8购买聊天框,9购买座驾,10活动赠送)
	TransactionAmount          int64  `gorm:"column:transaction_amount"`                      //涉及代币数*100
	TransactionGetAmount       int64  `gorm:"column:transaction_get_amount"`                  //转移得到的go币(只用0余额转go币)
	TransactionCash            int64  `gorm:"column:transaction_cash"`                        //涉及金额人民币,单位分
	TransactionFee             int64  `gorm:"column:transaction_fee"`                         //涉及手续费
	TransactionFinalCash       int64  `gorm:"column:transaction_final_cash"`                  //最终涉及金额即用户到手金额
	TransactionPayableCash     int64  `gorm:"column:transaction_payable_cash"`                //涉及金额
	TransactionStatus          int    `gorm:"column:transaction_status"`                      //交易状态(1交易中即发起,2交易完成,3交易失败)
	TransactionTime            int64  `gorm:"column:transaction_time"`                        //完成时间
	TransactionRemark          string `gorm:"column:transaction_remark"`                      //交易备注
	TransactionToUserId        int64  `gorm:"column:transaction_to_user_id"`                  //到达账户id
	TransactionToAccountType   int    `gorm:"column:transaction_to_account_type"`             //到达账户类型(0平台,1支付宝,2微信,银行卡)
	TransactionToAccountInfo   string `gorm:"column:transaction_to_account_info"`             //到达账户信息
	TransactionFromUserId      int64  `gorm:"column:transaction_from_user_id"`                //来源账号id
	TransactionFromAccountType int64  `gorm:"column:transaction_from_account_type"`           //来源账号类型(0平台,1支付宝,2微信,银行卡)
	TransactionFromAccountInfo string `gorm:"column:transaction_from_account_info"`           //来源账号信息
	TransactionFromSystem      int    `gorm:"column:transaction_from_system"`                 //来源系统
	TransactionFromWay         int    `gorm:"column:transaction_from_way"`                    //充值来源方式(0原生app,1公众号)
	TransactionReviewStatus    int64  `gorm:"column:transaction_review_status"`               //审核状态(0待审核,1运营审核通过,2.运营审核失败,3财务审核通过,4财务审核失败,5出纳审核失败,6出纳审核审核成功(待打款),7打款中,8第三方打款成功,9第三方打款失败)
	TransactionOperationTips   string `gorm:"column:transaction_operation_tips"`              //运营提示
	TransactionFinanceTips     string `gorm:"column:transaction_finance_tips"`                //财务审核提示
	TransactionCashierTips     string `gorm:"column:transaction_cashier_tips"`                //出纳提示
	TransactionThirdTips       string `gorm:"column:transaction_third_tips"`                  //第三方打款提示
	TransactionThirdOrderid    string `gorm:"column:transaction_third_orderid"`               //第三方id
	TransactionThirdProductid  string `gorm:"column:transaction_third_productid"`             //第三方产品id(主要用在apple)
	TransactionChannelId       int    `gorm:"column:transaction_channel_id"`                  //交易渠道(0平台,对应app_transaction_channel的id)
	TransactionNeedCustomer    int    `gorm:"column:transaction_need_customer"`               //是否需要客服介入(0不需要,1需要)
	BaseModel
}

//映射枚举
var TransactionTypeMap = map[int]int{
	//用户背包:交易流水
	DB_PROP_TYPE_TYPE_HAMMER: DB_TRANSACTION_TYPE_HAMMER,
	DB_PROP_TYPE_TYPE_AVATAR: DB_TRANSACTION_TYPE_AVATAR,
	DB_PROP_TYPE_TYPE_CHAT:   DB_TRANSACTION_TYPE_CHAT,
	DB_PROP_TYPE_TYPE_CAR:    DB_TRANSACTION_TYPE_CAR,
}

//枚举映射中文含义
var TransactionTypeMapString = map[int]string{
	DB_TRANSACTION_TYPE_BALANCE_TO_GO:       "兑换go币",
	DB_TRANSACTION_TYPE_GO:                  "充值go币",
	DB_TRANSACTION_TYPE_WITHDRAW:            "余额提现",
	DB_TRANSACTION_TYPE_SYSTEM_GIFT:         "系统赠送到余额",
	DB_TRANSACTION_TYPE_SYSTEM_COMPENSATION: "系统赠送到收入",
	DB_TRANSACTION_TYPE_SYSTEM_FREEZES:      "系统冻结",
	DB_TRANSACTION_TYPE_HAMMER:              "买锤子",
	DB_TRANSACTION_TYPE_AVATAR:              "买头像框",
	DB_TRANSACTION_TYPE_CHAT:                "买聊天框",
	DB_TRANSACTION_TYPE_CAR:                 "买座驾",
	DB_TRANSACTION_TYPE_ACTIVITY_GIVE:       "活动赠送",
}

const (
	//交易类型
	DB_TRANSACTION_TYPE_BALANCE_TO_GO       int = iota // 兑换go币
	DB_TRANSACTION_TYPE_GO                             // 充值go币
	DB_TRANSACTION_TYPE_WITHDRAW                       // 余额提现
	DB_TRANSACTION_TYPE_SYSTEM_GIFT                    // 系统赠送到余额
	DB_TRANSACTION_TYPE_SYSTEM_COMPENSATION            // 系统赠送到收入
	DB_TRANSACTION_TYPE_SYSTEM_FREEZES                 // 系统冻结
	DB_TRANSACTION_TYPE_HAMMER                         // 买锤子
	DB_TRANSACTION_TYPE_AVATAR                         // 买头像框
	DB_TRANSACTION_TYPE_CHAT                           // 买聊天框
	DB_TRANSACTION_TYPE_CAR                            // 买座驾
	DB_TRANSACTION_TYPE_ACTIVITY_GIVE                  // 活动赠送
)

const (
	//交易状态
	DB_TRANSACTION_STATUS   int = iota
	DB_TRANSACTION_ING          //交易中即发起
	DB_TRANSACTION_COMPLETE     //交易完成
	DB_TRANSACTION_FAIL         //交易失败
)

const (
	//账户类型 (0平台,1支付宝,2微信,银行卡)
	DB_ACCOUNT_TYPE_PLATFORM  int = iota //平台
	DB_ACCOUNT_TYPE_ALIPAY               //支付宝
	DB_ACCOUNT_TYPE_WEHCHAT              //微信
	DB_ACCOUNT_TYPE_BANK_CARD            //银行卡
	DB_ACCOUNT_TYPE_APPLEPAY             //苹果支付
)

func (AppTransaction) TableName() string {
	return "app_transaction"
}

func (m *AppTransaction) Create(tx *gorm.DB) (err error) {
	err = tx.Create(m).Error
	return
}

//查询未完成订单
func (m *AppTransaction) QueryUnfinishedFirst(transactionId interface{}, transactionFromAccountType int) (row int64, data AppTransaction, err error) {
	model := utils.GEngine.Where("transaction_id = ? AND transaction_from_account_type = ? AND transaction_status = ?", transactionId, transactionFromAccountType, DB_TRANSACTION_ING).First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

//更新流水状态
func (m *AppTransaction) UpdateStatus(tx *gorm.DB, transactionId int64, status int, thirdNo string) (err error) {
	update := make(map[string]interface{})
	update["transaction_status"] = status
	update["transaction_third_orderid"] = thirdNo
	//交易完成更新完成时间
	if status == DB_TRANSACTION_COMPLETE {
		update["transaction_time"] = time.Now().Unix()
	}
	err = tx.Model(m).Where("transaction_id = ? AND transaction_third_orderid = ''", transactionId).Updates(update).Error
	return
}

//根据单号查询
func (m *AppTransaction) QueryFirst(transactionId int64) (row int64, data AppTransaction, err error) {
	model := utils.GEngine.Where("transaction_id = ?", transactionId).First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

func (m *AppTransaction) QueryFirstByRecharge(transactionId int64) (row int64, data AppTransaction, err error) {
	model := utils.GEngine.Where("transaction_type=? AND transaction_id = ?", DB_TRANSACTION_TYPE_GO, transactionId).First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

// 查询第三方id是否存在
func (m *AppTransaction) QueryByThirdNo(thirdNo string) (count int64, err error) {
	err = utils.GEngine.Model(m).Where("transaction_third_orderid = ?", thirdNo).Count(&count).Error
	return
}

//查询go币购买记录
func (m *AppTransaction) QueryGoList(page int, size int, userId int64) (total int64, data []AppTransaction, err error) {
	err = utils.GEngine.Model(m).
		Where("transaction_from_user_id = ? AND transaction_type = ? AND transaction_status = ?", userId, DB_TRANSACTION_TYPE_GO, DB_TRANSACTION_COMPLETE).
		Count(&total).
		Order("created desc").
		Offset((page * size) - size).
		Limit(size).
		Find(&data).Error
	return
}

//查询其他记录
func (m *AppTransaction) QueryOtherList(page int, size int, userId int64) (total int64, data []AppTransaction, err error) {
	err = utils.GEngine.Model(m).
		Where("(transaction_from_user_id = ? OR transaction_to_user_id = ?)AND ( transaction_type >= ? OR transaction_type = ? OR  transaction_type = ? OR transaction_type = ?)",
			userId, userId, DB_TRANSACTION_TYPE_HAMMER, DB_TRANSACTION_TYPE_BALANCE_TO_GO, DB_TRANSACTION_TYPE_SYSTEM_GIFT, DB_TRANSACTION_TYPE_ACTIVITY_GIVE).
		Count(&total).
		Order("created desc").
		Offset((page * size) - size).
		Limit(size).
		Find(&data).Error
	return
}

//查询进行中的提现
func (m *AppTransaction) QueryOngoingWithDraw(userId int64) (row int64, data AppTransaction, err error) {
	model := utils.GEngine.Where("transaction_to_user_id = ? AND transaction_type = ? AND transaction_status = ?", userId, DB_TRANSACTION_TYPE_WITHDRAW, DB_TRANSACTION_ING).First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

//查询本月已提现金额
func (m *AppTransaction) QueryMonthAmount(userId int64) (data AppTransaction, err error) {
	err = utils.GEngine.
		Model(m).
		Select("sum(transaction_cash) AS transaction_cash").
		Where("transaction_to_user_id = ? AND transaction_type = ? AND transaction_status = ?", userId, DB_TRANSACTION_TYPE_WITHDRAW, DB_TRANSACTION_COMPLETE).
		Where("created >= ? AND created <= ?", utils.GetMonthFirstDayTimeStamp(), time.Now().Unix()).
		First(&data).Error
	return
}

// 查询兑换的go币和提现go币
func (m *AppTransaction) GetOtherUserIncome(userId int64, size, skip int) (total int64, data []response.UserOtherIncomeResp, err error) {
	err = utils.GEngine.Model(m).Where("(transaction_from_user_id = ? AND (transaction_type = ? OR transaction_type = ?)) OR (transaction_to_user_id = ? and transaction_type = ? and deleted = 0)",
		userId, DB_TRANSACTION_TYPE_WITHDRAW, DB_TRANSACTION_TYPE_BALANCE_TO_GO, userId, DB_TRANSACTION_TYPE_SYSTEM_COMPENSATION).Count(&total).Offset(skip).Limit(size).Order("transaction_id desc").Find(&data).Error
	return
}

// QueryPayTimes 查询充值 go 币次数。
func (m *AppTransaction) QueryPayTimes(types int, crash int64, userID int64) (total int64, err error) {
	err = utils.GEngine.Model(m).
		Where("transaction_from_user_id = ?", userID).
		Where("transaction_type = ?", DB_TRANSACTION_TYPE_GO).
		Where("transaction_from_account_type = ? ", types).
		Where("transaction_cash >= ?", crash).
		Count(&total).Error
	return
}

// QueryAliAndWechatPayTimes 查询支付宝和微信充值 go 币次数。
func (m *AppTransaction) QueryAliAndWechatPayTimes(crash int64, userID int64) (total int64, err error) {
	err = utils.GEngine.Model(m).
		Where("transaction_from_user_id = ?", userID).
		Where("transaction_type = ?", DB_TRANSACTION_TYPE_GO).
		Where("transaction_from_account_type IN (?,?) ", DB_ACCOUNT_TYPE_ALIPAY, DB_ACCOUNT_TYPE_WEHCHAT).
		Where("transaction_cash >= ?", crash).
		Count(&total).Error
	return
}
