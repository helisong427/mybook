package dbmodels

import "gamers/utils"

//奖池权重表
type AppEggbreakPool struct {
	PoolId            int64                `gorm:"column:pool_id;primaryKey;autoIncrement"`
	PoolEggbreakId    int64                `gorm:"column:pool_eggbreak_id"`                       //砸蛋id
	PoolWeight        int64                `gorm:"column:pool_weight"`                            //奖池权重
	AppEggbreakReward []*AppEggbreakReward `gorm:"foreignKey:RewardEggbreakId;references:PoolId"` //关联奖励
	BaseModel
}

func (AppEggbreakPool) TableName() string {
	return "app_eggbreak_pool"
}

//创建
func (m *AppEggbreakPool) Create() (err error) {
	err = utils.GEngine.Create(m).Error
	return
}

//删除
func (m *AppEggbreakPool) Delete(poolId int64) (err error) {
	err = utils.GEngine.Where("pool_id = ?", poolId).Delete(m).Error
	return
}

//更新权重
func (m *AppEggbreakPool) UpdatePoolWeight(poolId int64, poolWeight int64) (err error) {
	err = utils.GEngine.Model(m).Where("pool_id = ?", poolId).Update("pool_weight", poolWeight).Error
	return
}
