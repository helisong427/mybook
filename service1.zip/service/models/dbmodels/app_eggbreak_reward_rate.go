package dbmodels

// 砸蛋概率（显示用）

type AppEggbreakRewardRate struct {
	RateId         int     `gorm:"column:rate_id" json:"rate_id"`
	RateEggbreakId int64   `gorm:"column:rate_eggbreak_id" json:"rate_eggbreak_id"` // 砸蛋id
	RatePropType   int     `gorm:"column:rate_prop_type" json:"rate_prop_type"`     // 物品类型(0go币,1礼物,2锤子,3头像框,4聊天框,5座驾,6活动道具,7实物道具,8Go币道具)
	RatePropId     int64   `gorm:"column:rate_prop_id" json:"rate_prop_id"`         // 物品ID
	RateRate       int64   `gorm:"column:rate_rate" json:"rate_rate"`               // 物品被抽到的概率
	AppProp        AppProp `gorm:"foreignKey:PropId;references:RatePropId"`         // 关联物品
	BaseModel
}

func (AppEggbreakRewardRate) TableName() string {
	return "app_eggbreak_reward_rate"
}
