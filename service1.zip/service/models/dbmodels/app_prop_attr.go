package dbmodels

import (
	"encoding/json"
	"gamers/utils"
)

// 道具属性
type AppPropAttr struct {
	AttrId     int64     `gorm:"column:attr_id;primaryKey;autoIncrement" json:"attr_id"`
	AttrType   int       `gorm:"column:attr_type" json:"attr_type"`
	AttrName   string    `gorm:"column:attr_name" json:"attr_name"`
	AttrSort   int64     `gorm:"column:attr_sort" json:"attr_sort"`
	AttrIsShow int64     `gorm:"column:attr_is_show" json:"attr_is_show"`
	BaseModel  BaseModel `gorm:"embedded" json:"-"`
}

const (
	DB_ATTR_IS_SHOW_HIDDEN  int = iota //不显示
	DB_ATTR_IS_SHOW_DISPLAY            //显示
)

const (
	PROP_TYPE_GIFT = iota + 1
	PROP_TYPE_HAMMER
	PROP_TYPE_ICON_STYLE //头像
	PROP_TYPE_CHAT_STYLE //聊天框
	PROP_TYPE_PET_STYLE  //座驾
)

func (AppPropAttr) TableName() string {
	return "app_prop_attr"
}

func (s *AppPropAttr) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s AppPropAttr) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

//根据类型查询
func (m *AppPropAttr) QueryByAttrType(attrType int) (data []AppPropAttr, err error) {
	err = utils.GEngine.Where("attr_type = ? and attr_is_show = ?", attrType, DB_ATTR_IS_SHOW_DISPLAY).Order("attr_sort desc").Find(&data).Error
	return
}

//获取全部装扮的属性
func (m *AppPropAttr) QueryDressAll() (data []AppPropAttr, err error) {
	err = utils.GEngine.
		Where("attr_type IN ? and attr_is_show = ?", []int{PROP_TYPE_ICON_STYLE, PROP_TYPE_PET_STYLE, PROP_TYPE_CHAT_STYLE}, DB_ATTR_IS_SHOW_DISPLAY).
		Order("attr_sort asc").
		Find(&data).Error
	return
}
