package dbmodels

import (
	"gamers/utils"
	"time"
)

// 周星榜 历史榜单表
type AppWeekStarList struct {
	WeekStarListId     int64 `gorm:"column:week_star_list_id" json:"week_star_list_id"`
	WeekStarListUserId int64 `gorm:"column:week_star_list_user_id" json:"week_star_list_user_id"` // 周星榜上榜用户ID
	WeekStarListType   int64 `gorm:"column:week_star_list_type" json:"week_star_list_type"`       // 周星榜类型 1 财富榜 2 魅力榜
	WeekStarListWeight int64 `gorm:"column:week_star_list_weight" json:"week_star_list_weight"`   // 权重(排名)
	WeekStarId         int64 `gorm:"column:week_star_id" json:"week_star_id"`                     // 周星榜活动 id 匹配app_week_star表的主键ID
	WeekStarPropCount  int64 `gorm:"column:week_star_prop_count" json:"week_star_prop_count"`     // 收到/送出礼物个数
	WeekStarPropId     int64 `gorm:"week_star_prop_id" json:"week_star_prop_id"`                  // 本次礼物ID
	Created            int64 `gorm:"column:created" json:"created"`                               // 创建时间
	Edited             int64 `gorm:"column:edited" json:"edited"`                                 // 修改时间
	Deleted            int64 `gorm:"column:deleted" json:"deleted"`                               // 删除时间
}

func (m *AppWeekStarList) TableName() string {
	return "app_week_star_list"
}

func (m *AppWeekStarList) Create() error {
	m.Created = time.Now().Unix()
	return utils.GEngine.Model(m).Create(m).Error
}

func (m *AppWeekStarList) GetHistoryRankList() (list []WeekStarPropItem, err error) {
	db := utils.GEngine.Model(m).Select(`week_star_list_user_id as prop_user_id, user_iconurl as prop_user_iconurl,
		week_star_list_weight as prop_rank, user_nickname as prop_user_nickname, week_star_prop_count as prop_count
		`).Where("app_week_star_list.deleted = 0").
		Where("week_star_list_weight = 1").
		Joins(`left join (select user_id, user_nickname, user_iconurl from system_user) su on su.user_id = app_week_star_list.week_star_list_user_id`)

	err = db.Order("app_week_star_list.created desc").Offset(0).Limit(2).Find(&list).Error

	return
}
