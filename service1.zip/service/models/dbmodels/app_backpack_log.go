package dbmodels

import "gorm.io/gorm"

//背包日志
type AppBackpackLog struct {
	LogId       int64 `gorm:"column:log_id;primaryKey;autoIncrement"`
	LogType     int   `gorm:"column:log_type"`      //交易类型(0购买,1使用,2赠送)
	LogTypeId   int64 `gorm:"column:log_type_id"`   //交易关联表的id  (0购买对应app_transaction的id,1砸蛋使用对应app_eggbreak_log表的id)',
	LogUserId   int64 `gorm:"column:log_user_id"`   //用户id
	LogPropId   int64 `gorm:"column:log_prop_id"`   //物品id
	LogPropType int   `gorm:"column:log_prop_type"` //物品类型(1礼物,2锤子,3头像框,4聊天框,5座驾,6活动道具,7实物道具,8Go币道具)
	LogCount    int64 `gorm:"column:log_count"`     //交易数量
	BaseModel
}

//交易类型
const (
	DB_APP_BACK_PACK_LOG_LOG_TYPE_BUY  int = iota //购买
	DB_APP_BACK_PACK_LOG_LOG_TYPE_USE             //使用
	DB_APP_BACK_PACK_LOG_LOG_TYPE_GIFT            //赠送
)

func (m *AppBackpackLog) TableName() string {
	return "app_backpack_log"
}

func (m *AppBackpackLog) Create(tx *gorm.DB) (err error) {
	err = tx.Create(m).Error
	return
}
