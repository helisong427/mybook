package dbmodels

import "gamers/utils"

//举报
type AppReport struct {
	ReportId      int64     `gorm:"column:report_id;primaryKey;autoIncrement;"`
	ReportType    int64     `gorm:"column:report_type"`    //举报类型(0低俗色情,1涉政治,2广告,3侮辱诋毁,4诈骗,5侵权举报,6其他)
	ReportContent string    `gorm:"column:report_content"` //举报内容
	ReportUserId  int64     `gorm:"column:report_user_id"` //举报人id
	ReportImage   string    `gorm:"column:report_image"`   //举报图片,json格式["https://img.tupianzj.com/uploads/Bizhi/mn1_1366.jpg","http://pic1.win4000.com/pic/1/91/66ee942425.jpg"]
	ReportStatus  int64     `gorm:"column:report_status"`  //举报状态(0待处理,1已处理)
	ReportRemark  string    `gorm:"column:report_remark"`  //处理备注
	ReportToId    int64     `gorm:"column:report_to_id"`   //被举报id(人id,房间id,朋友圈动态id,朋友圈评论id,技能id)
	ReportToType  int64     `gorm:"column:report_to_type"` //被举报的类型(0人,1房间,2朋友圈动态,3朋友圈评论,4技能)
	ReportRoomId  int64     `gorm:"column:report_room_id"` //发生的聊天室
	BaseModel     BaseModel `gorm:"embedded"  json:"base_model"`
}

func (AppReport) TableName() string {
	return "app_report"
}

func (m *AppReport) Create() (err error) {
	err = utils.GEngine.Create(m).Error
	return
}
