package dbmodels

import "gamers/utils"

type AppUserBanLog struct {
	LogId        int64  `gorm:"column:log_id"`
	LogUserId    int64  `gorm:"column:log_user_id"`    //用户id
	LogType      int64  `gorm:"column:log_type"`       //日志类型1封禁,2注销
	LogClass     int64  `gorm:"column:log_class"`      //处理类型,1涉黄,2涉赌,3涉政,4侮辱谩骂,5虚假宣传,6引导私下交易,7未成年相关,8导流,9诱骗礼物
	LogRemark    string `gorm:"column:log_remark"`     //处理备注
	LogStartTime int64  `gorm:"column:log_start_time"` //开始时间
	LogEndTime   int64  `gorm:"column:log_end_time"`   //结束时间0表示永久
	BaseModel
}

func (AppUserBanLog) TableName() string {
	return "app_user_ban_log"
}

//查询用户封禁日志
func (m *AppUserBanLog) QueryBanFirst(userId int64) (row int64, data AppUserBanLog, err error) {
	model := utils.GEngine.Where("user_id = ? AND log_type = 1 AND log_end_time > 0", userId).Order("created desc").First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}
