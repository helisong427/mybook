package dbmodels

import "gorm.io/gorm"

// AppInviteMessageReviewLogs 撩一撩邀请消息操作日志表
type AppInviteMessageReviewLogs struct {
	LogsID           int64  `gorm:"column:logs_id"`
	LogsUserID       int64  `gorm:"column:logs_user_id"`       // 用户 id
	LogsReviewID     int64  `gorm:"column:logs_review_id"`     // 邀请消息审核表 id
	LogsName         string `gorm:"column:logs_name"`          // 用户或审核人真实姓名
	LogsBehavior     string `gorm:"column:logs_behavior"`      // 操作行为
	LogsRejectReason string `gorm:"column:logs_reject_reason"` // 拒绝原因
	BaseModel
}

// TableName 表名
func (*AppInviteMessageReviewLogs) TableName() string {
	return "app_invite_message_review_logs"
}

// Create 插入记录
func (l *AppInviteMessageReviewLogs) Create(tx *gorm.DB) error {
	return tx.Create(l).Error
}
