/**
 * @Author: panke
 * @Description:
 * @File: app_turn_table_log
 * @Date: 2021/4/22 16:31
 */

package dbmodels

import (
	"gamers/controller/response"
	"gamers/utils"
	"gamers/utils/prop"
	"sort"
)

type AppTurnTableLog struct {
	LogID             uint       `json:"log_id" gorm:"column:log_id"`
	LogRecordID       int64      `json:"log_record_id" gorm:"column:log_record_id"`               // 转盘记录id
	LogUserID         int64      `json:"log_user_id" gorm:"column:log_user_id"`                   // 用户id
	LogTurnTableID    int        `json:"log_turn_table_id" gorm:"column:log_turn_table_id"`       // 转盘表的id
	LogTurnTableCount int        `json:"log_turn_table_count" gorm:"column:log_turn_table_count"` // 转盘次数(如：1次/10次/50次/100次)
	LogCostPropType   prop.Type  `json:"log_cost_prop_type" gorm:"column:log_cost_prop_type"`     // 消耗物品类型(0go币,1礼物,2锤子,3头像框,4聊天框,5座驾,6活动道具,7实物道具,8Go币道具)
	LogCostPropID     int64      `json:"log_cost_prop_id" gorm:"column:log_cost_prop_id"`         // 消耗物品ID
	LogCostPropCount  int64      `json:"log_cost_prop_count" gorm:"column:log_cost_prop_count"`   // 消耗物品数量
	LogPropType       prop.Type  `json:"log_prop_type" gorm:"column:log_prop_type"`               // 物品类型(0go币,1礼物,2锤子,3头像框,4聊天框,5座驾,6活动道具,7实物道具,8Go币道具)
	LogPropID         int        `json:"log_prop_id" gorm:"column:log_prop_id"`                   // 物品ID
	LogPropCount      int        `json:"log_prop_count" gorm:"column:log_prop_count"`             // 物品被抽到次数
	AppProp           AppProp    `gorm:"foreignKey:PropId;references:LogPropID"`                  // 关联道具
	SystemUser        SystemUser `gorm:"foreignKey:UserID;references:LogUserID"`                  // 管理用户
	BaseModel
}

func (m *AppTurnTableLog) TableName() string {
	return "app_turn_table_log"
}

func (m *AppTurnTableLog) Query50Limit(turnTableId int, size, skip int) (data []*AppTurnTableLog, err error) {
	err = utils.GEngine.Model(m).Preload("AppProp").Preload("SystemUser").
		Offset(skip).Limit(size).Where("log_turn_table_id=?", turnTableId).Order("created desc").Find(&data).Error
	return
}

func (m *AppTurnTableLog) QueryByUserId(userId int64, turnTableId int, size, skip int) (count int64, data []*AppTurnTableLog, err error) {
	model := utils.GEngine.Model(m)
	err = model.Preload("AppProp").Preload("SystemUser").
		Offset(skip).Limit(size).Where("log_turn_table_id=?", turnTableId).Where("log_user_id=?", userId).
		Order("created desc").Find(&data).Error
	err = model.Count(&count).Error
	return
}

func (m *AppTurnTableLog) Query(turnTableId int, size, skip int) (int64, []*response.TurnTableRecord, error) {
	var rows, err = utils.GEngine.Raw(`
	select log_record_id, log_turn_table_count, log_prop_type, log_prop_id, log_user_id, log_prop_count, created, log_item_count from 
		(select * from app_turn_table_log where log_turn_table_id = ?) as A
	right join
		(
		select log_record_id as b_log_record_id, count(*) as log_item_count from app_turn_table_log
		where log_turn_table_id = ? 
		group by log_record_id 
		order by created desc, log_record_id desc limit ?, ?
    	) as B
	on A.log_record_id = B.b_log_record_id;
	`, turnTableId, turnTableId,
		skip, skip+size).Rows()

	if err != nil {
		return 0, nil, err
	}
	defer rows.Close()

	var propIdMaps = map[int64]int64{}                     // select prop config
	var recordMaps = map[int64]*response.TurnTableRecord{} // map[log_record_id]record
	for rows.Next() {
		receiver := &response.TurnTableRecord{}
		if err := rows.Scan(&receiver.LogRecordId, &receiver.LogTurnTableCount,
			&receiver.LogPropType, &receiver.LogPropId, &receiver.LogUserId, &receiver.LogPropCount,
			&receiver.Created, &receiver.LogItemCount); err != nil {
			return 0, nil, err
		}
		if _, prs := recordMaps[receiver.LogRecordId]; !prs {
			recordMaps[receiver.LogRecordId] = receiver
		}
		var item = recordMaps[receiver.LogRecordId]
		item.LogDetails = append(item.LogDetails, &response.TurnTableRecordReward{
			PropType:  receiver.LogPropType,
			PropId:    receiver.LogPropId,
			PropCount: receiver.LogPropCount,
		})
		propIdMaps[int64(receiver.LogPropId)] = int64(receiver.LogPropId)

		userInfo, err := new(SystemUser).QueryById(receiver.LogUserId)
		if err != nil {
			utils.LogErrorF("查询用户昵称错误:", err.Error())
			continue
		}
		receiver.LogUserName = userInfo.UserNickname
	}

	var respData = &response.TurnTableRecordsRep{
		TurnTableId: turnTableId,
	}
	for _, v := range recordMaps {
		respData.Records = append(respData.Records, v)
	}
	sort.Slice(respData.Records, func(i, j int) bool {
		if respData.Records[i].Created != respData.Records[j].Created {
			return respData.Records[i].Created > respData.Records[j].Created
		}
		return respData.Records[i].LogRecordId > respData.Records[j].LogRecordId
	})

	if cfgMaps, err := new(AppProp).QueryByPropIdMaps(propIdMaps); err == nil {
		for _, v := range respData.Records {
			for _, d := range v.LogDetails {
				if cfg, ok := cfgMaps[int64(d.PropId)]; ok {
					d.PropName = cfg.PropName
					d.PropIcon = cfg.PropIcon
					d.PropPrice = cfg.PropOrgPrice
				}
			}
		}
	}

	for _, v := range respData.Records {
		sort.Slice(v.LogDetails, func(i, j int) bool {
			return v.LogDetails[i].PropPrice > v.LogDetails[j].PropPrice
		})
	}

	return int64(len(respData.Records)), respData.Records, nil
}

func (m *AppTurnTableLog) QueryByUser(userId int64, turnTableId int, size, skip int) (int64, []*response.TurnTableRecord, error) {
	var rows, err = utils.GEngine.Raw(`
	select log_record_id, log_turn_table_count, log_prop_type, log_prop_id, log_prop_count, created, log_item_count from 
		(select * from app_turn_table_log where log_user_id = ? and log_turn_table_id = ?) as A
	right join
		(
		select log_record_id as b_log_record_id, count(*) as log_item_count from app_turn_table_log
		where log_user_id = ? and log_turn_table_id = ? 
		group by log_record_id 
		order by created desc, log_record_id desc limit ?, ?
    	) as B
	on A.log_record_id = B.b_log_record_id;
	`, userId, turnTableId,
		userId, turnTableId,
		skip, skip+size).Rows()

	if err != nil {
		return 0, nil, err
	}
	defer rows.Close()

	var propIdMaps = map[int64]int64{}                     // select prop config
	var recordMaps = map[int64]*response.TurnTableRecord{} // map[log_record_id]record
	for rows.Next() {
		receiver := &response.TurnTableRecord{}
		if err := rows.Scan(&receiver.LogRecordId, &receiver.LogTurnTableCount,
			&receiver.LogPropType, &receiver.LogPropId, &receiver.LogPropCount,
			&receiver.Created, &receiver.LogItemCount); err != nil {
			return 0, nil, err
		}
		if _, prs := recordMaps[receiver.LogRecordId]; !prs {
			recordMaps[receiver.LogRecordId] = receiver
		}
		var item = recordMaps[receiver.LogRecordId]
		item.LogDetails = append(item.LogDetails, &response.TurnTableRecordReward{
			PropType:  receiver.LogPropType,
			PropId:    receiver.LogPropId,
			PropCount: receiver.LogPropCount,
		})
		propIdMaps[int64(receiver.LogPropId)] = int64(receiver.LogPropId)
	}

	var respData = &response.TurnTableRecordsRep{
		TurnTableId: turnTableId,
	}
	for _, v := range recordMaps {
		respData.Records = append(respData.Records, v)
	}
	sort.Slice(respData.Records, func(i, j int) bool {
		if respData.Records[i].Created != respData.Records[j].Created {
			return respData.Records[i].Created > respData.Records[j].Created
		}
		return respData.Records[i].LogRecordId > respData.Records[j].LogRecordId
	})

	if cfgMaps, err := new(AppProp).QueryByPropIdMaps(propIdMaps); err == nil {
		for _, v := range respData.Records {
			for _, d := range v.LogDetails {
				if cfg, ok := cfgMaps[int64(d.PropId)]; ok {
					d.PropName = cfg.PropName
					d.PropIcon = cfg.PropIcon
					d.PropPrice = cfg.PropOrgPrice
				}
			}
		}
	}

	for _, v := range respData.Records {
		sort.Slice(v.LogDetails, func(i, j int) bool {
			return v.LogDetails[i].PropPrice > v.LogDetails[j].PropPrice
		})
	}

	return int64(len(respData.Records)), respData.Records, nil
}

func (m *AppTurnTableLog) Log(logs []*AppTurnTableLog) (err error) {
	return utils.GEngine.Model(m).Create(logs).Error
}
