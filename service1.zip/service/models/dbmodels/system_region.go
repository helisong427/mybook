package dbmodels

import "gamers/utils"

//系统地区表
type SystemRegion struct {
	RegionID       int64     `json:"region_id" gorm:"column:region_id;primaryKey;autoIncrement"`
	RegionName     string    `json:"region_name"`      //简称
	RegionParentID int64     `json:"region_parent_id"` //上级id
	RegionFullname string    `json:"region_fullname"`  //全名
	RegionLevel    string    `json:"region_level"`     //地区级别(0国家,1省,2市,3区)
	BaseModel      BaseModel `gorm:"embedded" json:"base_model"`
}

func (SystemRegion) TableName() string {
	return "system_region"
}

const (
	REGION_LEVEL_COUNTRY  = iota //国家
	REGION_LEVEL_PROVINCE        //省
	REGION_LEVEL_CITY            //市
	REGION_LEVEL_AREA            //区
)

//Query 查询所有地区信息
func (m *SystemRegion) QueryAll() (data []*SystemRegion, err error) {
	err = utils.GEngine.Find(&data).Error
	return
}

//QueryByParentId 根据上级id查询
func (m *SystemRegion) QueryById(id []int) (data []SystemRegion, err error) {
	err = utils.GEngine.Where("region_id IN ?", id).Find(&data).Error
	return
}
