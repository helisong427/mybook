package dbmodels

import (
	"gamers/utils"
	"gorm.io/gorm"
)

// 任务

type AppTask struct {
	TaskID             uint32 `gorm:"column:task_id;primaryKey;" json:"task_id"`                // 任务id
	TaskSetID          uint32 `gorm:"column:task_set_id;" json:"task_set_id"`                   // 任务集合
	TaskName           string `gorm:"column:task_name;" json:"task_name"`                       // 任务名字
	TaskConditionTag   string `gorm:"column:task_condition_tag;" json:"task_condition_tag"`     // 任务条件tag
	TaskConditionCount uint32 `gorm:"column:task_condition_count;" json:"task_condition_count"` // 任务条件的完成数量/次数
	TaskRewardQuota    uint32 `gorm:"column:task_reward_quota;" json:"task_reward_quota"`       // 任务奖励配额（0:不限额;其他:具体限额数量）
	TaskIcon           string `gorm:"column:task_icon;" json:"task_icon"`                       // 任务icon
	TaskSort           uint32 `gorm:"column:task_sort;" json:"task_sort"`                       // 任务排序(task_set内，从小到大)
	TaskStatus         uint8  `gorm:"column:task_status;" json:"task_status"`                   // 任务状态(0:关闭;1:开启)
	BaseModel
	TaskRewards []*AppTaskReward `gorm:"foreignKey:RewardTaskID;references:TaskID" json:"task_rewards"`
}

func (AppTask) TableName() string {
	return "app_task"
}

func (t *AppTask) AddTask(task *AppTask) error {
	return utils.GEngine.Transaction(func(tx *gorm.DB) error {
		if err := tx.Create(task).Error; err != nil {
			return err
		}

		//if len(task.TaskRewards) == 0 {
		//	return nil
		//}

		// 将生成的 task_id 带入 TaskRewards
		//var taskID = task.TaskID
		//for _, v := range task.TaskRewards {
		//	v.RewardTaskID = taskID
		//}
		//
		//if err := tx.Create(task.TaskRewards).Error; err != nil {
		//	return err
		//}
		return nil
	})
}

func (t *AppTask) Update(db *gorm.DB, taskID uint32, updates map[string]interface{}) error {
	return db.Model(t).Where("task_id = ?", taskID).Updates(updates).Error
}

func (t *AppTask) EditTask(task *AppTask, orgTask *AppTask) error {
	var updates = map[string]interface{}{
		"task_name":            task.TaskName,
		"task_condition_tag":   task.TaskConditionTag,
		"task_condition_count": task.TaskConditionCount,
		"task_reward_quota":    task.TaskRewardQuota,
		"task_icon":            task.TaskIcon,
		"task_sort":            task.TaskSort,
		"task_status":          task.TaskStatus,
	}

	var (
		orgRewardsByRewardID = map[uint32]*AppTaskReward{}
		addRewards           []*AppTaskReward
		delRewards           []*AppTaskReward
		updateRewards        []*AppTaskReward
	)

	for _, v := range orgTask.TaskRewards {
		orgRewardsByRewardID[v.RewardID] = v
	}
	for _, v := range task.TaskRewards {
		if data, prs := orgRewardsByRewardID[v.RewardID]; prs {
			if v.RewardPropType != data.RewardPropType ||
				v.RewardPropID != data.RewardPropID ||
				v.RewardPropCount != data.RewardPropCount {

				v.RewardTaskID = task.TaskID
				updateRewards = append(updateRewards, v)
			}
			delete(orgRewardsByRewardID, v.RewardID)
		} else {
			v.RewardID = 0
			v.RewardTaskID = task.TaskID
			addRewards = append(addRewards, v)
		}
	}
	for _, v := range orgRewardsByRewardID {
		delRewards = append(delRewards, v)
	}

	return utils.GEngine.Transaction(func(tx *gorm.DB) error {
		if err := t.Update(tx, task.TaskID, updates); err != nil {
			return err
		}

		var rTaskReward = new(AppTaskReward)
		for _, v := range delRewards {
			if err := rTaskReward.DeleteByRewardID(tx, v.RewardID); err != nil {
				return err
			}
		}

		for _, v := range updateRewards {
			var rUpdates = map[string]interface{}{
				"reward_task_id":    v.RewardTaskID,
				"reward_prop_type":  v.RewardPropType,
				"reward_prop_id":    v.RewardPropID,
				"reward_prop_count": v.RewardPropCount,
			}
			if err := rTaskReward.Update(tx, v.RewardID, rUpdates); err != nil {
				return err
			}
		}

		if len(addRewards) != 0 {
			if err := tx.Create(addRewards).Error; err != nil {
				return err
			}
		}

		return nil
	})
}

func (t *AppTask) DeleteBySetID(db *gorm.DB, setID uint32) error {
	return db.Model(t).Where("task_set_id = ?", setID).Delete(t).Error
}

func (t *AppTask) DeleteByTaskData(task *AppTask) error {
	if task == nil {
		return nil
	}

	return utils.GEngine.Transaction(func(tx *gorm.DB) error {
		if err := tx.Model(t).Where("task_id = ?", task.TaskID).Delete(t).Error; err != nil {
			return err
		}

		if err := new(AppTaskReward).DeleteByTaskID(tx, task.TaskID); err != nil {
			return err
		}

		return nil
	})
}
