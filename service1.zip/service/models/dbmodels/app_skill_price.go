package dbmodels

import "gamers/utils"

// 技能价格表
type AppSkillPrice struct {
	PriceId             int64     `gorm:"column:price_id" json:"price_id"`
	PriceSkillId        int64     `gorm:"column:price_skill_id" json:"price_skill_id"`               // 技能id
	PriceWay            string    `gorm:"column:price_way" json:"price_way"`                         // 陪玩方式 局/次/天/半小时/小时
	PriceTime           int64     `gorm:"column:price_time" json:"price_time"`                       // 陪玩方式   时长  单位秒
	PriceProtectionTime int64     `gorm:"column:price_protection_time" json:"price_protection_time"` // 订单保护时间长,过了这个时间才能确认订单：0分钟/5分钟/7分钟/10分钟/15分钟/20分钟/30分钟（当陪玩方式选择局/次，保护时间才可选）半小时/小时/天，陪玩时长固定为30分钟/60分钟/720分钟 保护时间固定为15分钟/30分钟/360分钟
	PricePrice          int64     `gorm:"column:price_price" json:"price_price"`                     // 技能价格
	PricePriceRand      int64     `gorm:"column:price_price_rand"`                                   // 随机单价格
	PriceRequired       int       `json:"price_required" gorm:"column:price_required"`
	BaseModel           BaseModel `gorm:"embedded" json:"-"`
}

func (AppSkillPrice) TableName() string {
	return "app_skill_price"
}

const (
	PRICE_REQUIRED_FALSE = iota
	PRICE_REQUIRED_TRUE
)

// 获取游戏价格方式
func (m AppSkillPrice) GetSkillPriceBySkillId(skillId int64) (data []AppSkillPrice, err error) {
	err = utils.GEngine.Model(m).Where("price_skill_id = ? and deleted = 0", skillId).Find(&data).Error
	return
}

// 查询价格，根据技能和priceid
func (m AppSkillPrice) GetSkillPriceBySkillIdAndPrice(skillId int64, priceId int64) (data AppSkillPrice, err error) {
	err = utils.GEngine.Model(m).Where("price_skill_id = ? and price_id = ? and deleted = 0", skillId, priceId).Find(&data).Error
	return
}
