package dbmodels

import (
	"encoding/json"
	"fmt"
	"gamers/utils"
	"strconv"
	"strings"
	"time"

	"github.com/go-redis/redis"
	"gorm.io/gorm"
)

// 直播房间
type AppLiveRoom struct {
	RoomId             int64          `json:"room_id" gorm:"column:room_id;primaryKey;autoIncrement"`             // 房间id
	RoomPrettyId       int64          `json:"room_pretty_id"`                                                     // 靓号
	RoomType           int            `json:"room_type"`                                                          // 类型(0音频直播,1音频派对)
	RoomName           string         `json:"room_name"`                                                          // 房间名称
	RoomCover          string         `json:"room_cover"`                                                         // 房间封面
	RoomBackground     string         `json:"room_background"`                                                    // 房间背景
	RoomTitle          string         `json:"room_title"`                                                         // 房间标题(排队公告标题)
	RoomContent        string         `json:"room_content"`                                                       // 房间简介(派对公告内容)
	RoomUnionId        int64          `json:"room_union_id"`                                                      // 所属公会id
	RoomUserId         int64          `json:"room_user_id"`                                                       // 所属用户id
	RoomPassword       string         `json:"room_password"`                                                      // 房间密码
	RoomOldAttrId      int64          `gorm:"column:room_old_attr_id" json:"room_old_attr_id"`                    // 原直播/派对房属性
	RoomAttrId         int64          `gorm:"column:room_attr_id" json:"room_attr_id"`                            // 属性
	RoomSpeakType      int            `json:"room_speak_type"`                                                    // 麦位模式(0音频直播无麦位,1音频直播有麦位,2音频派对自由模式,3音频派对麦序模式)
	RoomOpenIm         int            `json:"room_open_im"`                                                       // 是否开通公屏(图文聊天0关闭,1开通)
	RoomLiveStatus     int            `json:"room_live_status"`                                                   // 直播状态,直播类型才有效(0下播,1上播)
	RoomLastOnline     int64          `json:"room_last_online"`                                                   // 最后开播时间(直播)
	RoomLastOffline    int64          `json:"room_last_offline"`                                                  // 最后下播时间(直播)
	RoomLogId          int64          `gorm:"column:room_log_id" json:"room_log_id"`                              // 房间记录id
	RoomStatus         int            `json:"room_status"`                                                        // 房间状态 0正常,1管理员(房主)关闭,2超时关闭,3平台整改,4平台封禁
	AppRoomAdmins      []AppRoomAdmin `gorm:"foreignKey:AdminRoomID;references:RoomId" json:"-"`                  // 管理员列表
	SystemUser         SystemUser     `gorm:"foreignKey:RoomUserId;joinForeignKey:UserID;" json:"system_user"`    // 用户信息
	AppUnion           AppUnion       `gorm:"foreignKey:UnionId;references:RoomUnionId"`                          // 关联用户
	RoomLiveAttr       AppLiveAttr    `gorm:"foreignKey:RoomAttrId;joinForeignKey:AttrID;" json:"room_live_attr"` // 直播属性
	RoomEggbreakMsg    int            `gorm:"column:room_eggbreak_msg" json:"room_eggbreak_msg"`                  // 博彩类游戏,信息是否在公屏显示 0显示,1不显示
	RoomAttachHeat     int64          `gorm:"column:room_attach_heat" json:"room_attach_heat"`                    // 加成热度
	RoomHeat           int64          `gorm:"column:room_heat" json:"room_heat"`                                  // 热度
	RoomPkSwitch       int            `gorm:"column:room_pk_switch" json:"room_pk_switch"`                        // 房间开启pk功能(0未开启 1开启)
	RoomPkState        int64          `gorm:"column:room_pk_state" json:"room_pk_state"`                          // 房间pk状态(0关闭 1准备 2开始 3惩罚)
	RoomPkRecordId     int64          `gorm:"column:room_pk_record_id" json:"room_pk_record_id"`                  // 当前房间pk场次id
	RoomPkRecordTime   int64          `gorm:"column:room_pk_record_time" json:"room_pk_record_time"`              // 房间pk时长
	RoomPkRecordPunish string         `gorm:"column:room_pk_record_punish" json:"room_pk_record_punish"`          // 房间pk惩罚
	RoomIsReview       int64          `gorm:"room_is_review" json:"room_is_review"`                               // 是否审核
	BaseModel          BaseModel      `gorm:"embedded" json:"-"`                                                  // base
}

const (
	MAX_LIVE_ROOM_PRETTY_ID = 100000
)

func (AppLiveRoom) TableName() string {
	return "app_live_room"
}
func (s *AppLiveRoom) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s AppLiveRoom) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

const (
	ROOM_TYPE_LIVE  = iota // 音频直播
	ROOM_TYPE_PARTY        // 派对房
)

const (
	SPEAK_TYPE_LIVE_WITHOUT_MIC = iota // 音频直播无麦位
	SPEAK_TYPE_LIVE_WITH_MIC           // 音频直播有麦位
	SPEAK_TYPE_PARTY_FREE_MIC          // 音频派对自由模式
	SPEAK_TYPE_PARTY_WITH_MIC          // 音频派对麦序模式
)

const (
	ROOM_IM_STATUS_CLOSE = iota // 聊天公平关闭
	ROOM_IM_STATUS_OPEN         // 聊天公平打开
)

const (
	// 房间状态
	ROOM_STATUS_OK                     int = iota // 正常
	ROOM_STATUS_ADMIN_OFF                         // 管理员关闭
	ROOM_STATUS_TIME_OUT_OFF                      // 超时关闭
	ROOM_STATUS_PLATFORM_RECTIFICATION            // 平台整改
	ROOM_STATUS_PLATFORM_BAN                      // 平台禁封
)

const (
	ROOM_LIVE_STATUS_OFF     = iota // 下播
	ROOM_LIVE_STATUS_ON             // 上播
	ROOM_LIVE_STATUS_TIMEOUT        // 超时系统自动下播
)

const (
	RoomPkFunctionOpen  = 1 // 房间pk功能开启
	RoomPkFunctionClose = 0 // 房间pk功能关闭
)

const (
	RoomPkCloseStage      = iota // 关闭阶段
	RoomPkReadyStage             // 准备阶段
	RoomPkStartStage             // 开始阶段
	RoomPkPunishmentStage        // 惩罚阶段
)

// 根据用户id获取房间
func (m *AppLiveRoom) GetRoomInfoByUserId(userId int64) (data AppLiveRoom, err error) {
	err = utils.GEngine.Where("room_user_id = ? and deleted = 0", userId).Preload("SystemUser").
		Preload("RoomLiveAttr").
		First(&data).Error
	return
}

// 根据房间id获取房间
func (m *AppLiveRoom) QueryByRoomId(roomId interface{}) (data AppLiveRoom, err error) {
	err = utils.GEngine.
		Preload("SystemUser").
		Preload("RoomLiveAttr").
		Preload("AppRoomAdmins").
		Where("room_id = ?", roomId).
		Where("room_status != ?", ROOM_STATUS_PLATFORM_BAN).
		First(&data).Error
	return
}

// 模糊查询
func (m *AppLiveRoom) QueryLikeRoomId(page, size int, roomId string) (total int64, data []AppLiveRoom, err error) {
	err = utils.GEngine.Model(m).
		Preload("RoomLiveAttr").
		// Preload("AppRoomAdmins").
		Where("room_id != ? and room_id like ? and room_status != ?", roomId, "%"+roomId+"%", ROOM_STATUS_PLATFORM_BAN).
		Or("room_pretty_id != ? and room_pretty_id like ? and room_status != ?", roomId, "%"+roomId+"%", ROOM_STATUS_PLATFORM_BAN).
		Order("room_pretty_id desc").
		Count(&total).
		Offset((page * size) - size).
		Limit(size).
		Find(&data).Error
	return
}

// 根据房间id In查询
func (m *AppLiveRoom) QueryInRoomId(roomIds []int) (data []AppLiveRoom, err error) {
	err = utils.GEngine.
		Preload("RoomLiveAttr").
		Preload("AppRoomAdmins").
		Preload("AppUnion").
		Where("room_id IN ?", roomIds).
		// 暂时不考虑房间状态
		// Where("room_status = ?", ROOM_STATUS_OK).
		Find(&data).Error
	return
}

// 根据房间id In查询没有密码的房间
func (m *AppLiveRoom) QueryNotPasswordRoomId(roomIds []int) (data []AppLiveRoom, err error) {
	err = utils.GEngine.
		Preload("RoomLiveAttr").
		Preload("AppRoomAdmins").
		Preload("AppUnion").
		Where("room_id IN ?", roomIds).
		// Where("room_status = ? AND room_password = ''", ROOM_STATUS_OK).
		Where("room_password = '' AND (( room_type = ? AND room_status = ? AND room_live_status = ? ) OR ( room_type = ?  AND room_status = ? AND room_union_id > 0 ))", ROOM_TYPE_LIVE, ROOM_STATUS_OK, ROOM_LIVE_STATUS_ON, ROOM_TYPE_PARTY, ROOM_STATUS_OK).
		Find(&data).Error
	return
}

// 查询房间
func (m *AppLiveRoom) QueryRoomId(roomId int) (data AppLiveRoom, err error) {
	roomIdStr := strconv.Itoa(roomId)
	err = utils.RedisClient.Get(utils.REDIS_LIVE_ROOM_INFO + roomIdStr).Scan(&data)
	if err != nil && err != redis.Nil {
		return
	}
	if err == nil {
		return
	}
	err = utils.GEngine.
		Preload("SystemUser").
		Preload("RoomLiveAttr").
		Preload("AppRoomAdmins").
		Where("room_id = ? and deleted = 0", roomId).
		First(&data).Error
	if err != nil {
		return
	}
	// 写入缓存
	err = utils.RedisClient.Set(utils.REDIS_LIVE_ROOM_INFO+roomIdStr, data, -1).Err()
	return
}

// 获取房间
func (m *AppLiveRoom) GetStudioList(userId int64, attrId int32, _type int, _page, _size int) (count int64, result []AppLiveRoom, err error) {
	model := utils.GEngine.Model(m).Preload("AppRoomAdmins").Preload("RoomLiveAttr").Preload("SystemUser")
	if attrId == -1 {
		// 查询收藏的房间id
		favoriteData, err := new(AppRoomFavorite).GetListByUserId(userId)
		if err != nil && err != gorm.ErrRecordNotFound {
			return 0, []AppLiveRoom{}, err
		}
		if len(favoriteData) > 0 {
			ids := []int{}
			for _, v := range favoriteData {
				ids = append(ids, int(v.FavoriteRoomId))
			}
			model = model.Where("room_id in ?", ids).Where("room_status != ?", ROOM_STATUS_PLATFORM_BAN)
		} else {
			model = model.Where("room_id = ?", 0)
		}
	} else if attrId == 0 {
		// 查询所有房间
		model = model.Where("room_status = ? AND room_password = ''", ROOM_STATUS_OK)
	} else {
		// 查询指定属性的房间
		model = model.Where("room_attr_id = ?", attrId).Where("room_status = ? AND room_password = ''", ROOM_STATUS_OK)
	}

	model = model.Where("room_type = ?", _type)

	if _type == ROOM_TYPE_LIVE && attrId != -1 {
		model = model.Where("room_live_status = ?", ROOM_LIVE_STATUS_ON)
	}

	// 非收藏列表的派对列表只展示公会房间
	if _type == ROOM_TYPE_PARTY && attrId > -1 {
		model = model.Where("room_union_id > 0")
	}

	err = model.Count(&count).
		Offset((_page * _size) - _size).
		Limit(_size).
		Order("created desc").
		Find(&result).Error
	return
}

// 创建直播间，事务处理
func (m *AppLiveRoom) CreateLiveRoom(create bool, tx *gorm.DB) (err error) {
	if create {
		err = tx.Create(m).Error
	} else {
		err = tx.Save(m).Error
		if err != nil {
			return
		}
		err = utils.RedisClient.Del(utils.REDIS_LIVE_ROOM_INFO + strconv.Itoa(int(m.RoomId))).Err()
	}
	return
}

// 更新
func (m *AppLiveRoom) Update(roomId int, update map[string]interface{}) (err error) {
	err = utils.GEngine.Model(m).Where("room_id= ?", roomId).Updates(update).Error
	if err != nil {
		return
	}
	err = utils.RedisClient.Del(utils.REDIS_LIVE_ROOM_INFO + strconv.Itoa(roomId)).Err()
	return
}

// 更新-事务方法
func (m *AppLiveRoom) UpdateAffairs(tx *gorm.DB, roomId int64, update map[string]interface{}) (err error) {
	err = tx.Model(m).Where("room_id=?", roomId).Updates(update).Error
	if err != nil {
		return
	}
	err = utils.RedisClient.Del(utils.REDIS_LIVE_ROOM_INFO + strconv.Itoa(int(roomId))).Err()
	return
}

// 更新直播状态
func (m *AppLiveRoom) UpdateLiveStatus(roomId int, status int) (err error) {
	now := time.Now().Unix()
	tx := utils.GEngine.Begin()
	if status == ROOM_LIVE_STATUS_OFF || status == ROOM_LIVE_STATUS_TIMEOUT {
		room, err := m.QueryRoomId(roomId)
		if err != nil {
			return err
		}
		// 更新直播记录表
		err = tx.Table("app_room_open_log").Where("log_id = ?", room.RoomLogId).
			Updates(map[string]interface{}{"log_end_time": now, "log_live_status": status}).Error
		if err != nil {
			tx.Rollback()
			return err
		}
		err = tx.Table("app_live_room").Where("room_id= ?", roomId).
			Updates(map[string]interface{}{"room_log_id": 0, "room_live_status": status, "room_last_offline": now}).Error
		if err != nil {
			tx.Rollback()
			return err
		}
		err = tx.Commit().Error
		if err != nil {
			return err
		}
		err = utils.RedisClient.Del(utils.REDIS_LIVE_ROOM_INFO + strconv.Itoa(roomId)).Err()
		return err
	}
	err = utils.GEngine.Model(m).Where("room_id= ?", roomId).
		Updates(map[string]interface{}{"room_live_status": status, "room_last_offline": now}).Error
	if err != nil {
		return
	}
	err = utils.RedisClient.Del(utils.REDIS_LIVE_ROOM_INFO + strconv.Itoa(roomId)).Err()
	return
}

type AppLiveRoomSearchByUnionID struct {
	UnionID  int64 `json:"union_id"`
	Page     int   `json:"page"`
	PageSize int   `json:"page_size"`
}

// 根据公会ID查询公会房间列表
func (m *AppLiveRoom) SearchByUnionID(search *AppLiveRoomSearchByUnionID) (total int64, data []*AppLiveRoom, err error) {
	var db = utils.GEngine.Model(m).
		Where("room_union_id = ?", search.UnionID).
		Preload("AppRoomAdmins").
		Preload("SystemUser").
		Preload("AppUnion").
		Preload("RoomLiveAttr").
		Order("created DESC, room_id DESC")

	offset := (search.Page - 1) * search.PageSize
	if offset <= 0 {
		offset = 0
	}

	err = db.Count(&total).Offset(offset).Limit(search.PageSize).Find(&data).Error
	return
}

// 随机获取已开播房间
func (m *AppLiveRoom) RandRoom() (data []AppLiveRoom, err error) {
	randLen := 3
	err = utils.GEngine.Model(m).
		Preload("AppRoomAdmins").
		Preload("RoomLiveAttr").
		Preload("SystemUser").
		Scopes(m.baseWhere(ROOM_TYPE_LIVE)).
		Order("rand()").
		Limit(randLen).
		Find(&data).Error
	return
}

// 更新
func (m *AppLiveRoom) UpdateByTranslation(tx *gorm.DB, roomId int64, update map[string]interface{}) (err error) {
	err = tx.Model(m).Where("room_id= ?", roomId).Updates(update).Error
	if err != nil {
		return
	}
	err = utils.RedisClient.Del(utils.REDIS_LIVE_ROOM_INFO + strconv.Itoa(int(roomId))).Err()
	return
}

// 根据tag获取房间tag
func (m *AppLiveRoom) GetRoomIdsByAttrId(tagId int64) (data []int64, err error) {
	err = utils.GEngine.Model(m).Select("room_id").Where("room_attr_id = ? and deleted =0 and room_status = ?", tagId, ROOM_STATUS_OK).Find(&data).Error
	return
}

// 获取派对房id和热度
func (m *AppLiveRoom) QueryHeatParty() (row int64, data []AppLiveRoom, err error) {
	model := utils.GEngine.Select("room_id,room_attach_heat").Where("room_type = ?", ROOM_TYPE_PARTY, ROOM_STATUS_OK).Find(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

// 获取直播房id和热度
func (m *AppLiveRoom) QueryHeatLive() (row int64, data []AppLiveRoom, err error) {
	model := utils.GEngine.Select("room_id,room_attach_heat").Where("room_type = ?", ROOM_TYPE_LIVE).Find(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

// 根据热度id查询
func (m *AppLiveRoom) QueryHeat(hotIds []int64, roomType int) (row int64, data []AppLiveRoom, err error) {
	model := utils.GEngine.Model(m).
		Preload("AppRoomAdmins").
		Preload("RoomLiveAttr").
		Preload("SystemUser").
		Where("room_id IN ? AND room_type = ?", hotIds, roomType).
		Scopes(m.baseWhere(roomType))
	var temp = make([]string, len(hotIds))
	for k, v := range hotIds {
		temp[k] = fmt.Sprintf("%d", v)
	}
	field := strings.Join(temp, ",")
	model = model.Order("field(room_id," + field + ")").Find(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

// 随机获取指定类型指定条数房间
func (m *AppLiveRoom) QueryRandFind(roomType int, number int, notIds []int64) (row int64, data []AppLiveRoom, err error) {
	model := utils.GEngine.Model(m).
		Preload("SystemUser").
		Preload("RoomLiveAttr").
		Preload("AppRoomAdmins").
		Scopes(m.baseWhere(roomType))
	if len(notIds) > 0 {
		model = model.Where("room_id NOT IN ?", notIds)
	}
	model = model.Order("rand()").
		Limit(number).
		Find(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

// 获取指定数量的房间id
func (m *AppLiveRoom) QuerySpecifiedNumberId(notInIds []int64, roomType int, number int64) (row int64, data []AppLiveRoom, err error) {
	model := utils.GEngine.Model(m).
		Select("room_id").
		Scopes(m.baseWhere(roomType)).
		Where("room_id NOT IN ?", notInIds).
		Limit(int(number)).
		Find(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

// 按照roomId的顺序in查询
func (m *AppLiveRoom) QueryOrderIn(roomId []int64, roomType int64) (data []AppLiveRoom, err error) {
	model := utils.GEngine.Model(m).
		Preload("SystemUser").
		Preload("RoomLiveAttr").
		Preload("AppRoomAdmins").Scopes(m.baseWhere(int(roomType)))
	model = model.Where("room_id IN ?", roomId)
	var temp = make([]string, len(roomId))
	for k, v := range roomId {
		temp[k] = fmt.Sprintf("%d", v)
	}
	field := strings.Join(temp, ",")
	err = model.Order("field(room_id," + field + ")").Find(&data).Error
	return
}

// 随机获取一条
func (m *AppLiveRoom) QueryNotInRand(notInIds []int64, roomType int) (data AppLiveRoom, err error) {
	err = utils.GEngine.Model(m).
		Preload("SystemUser").
		Preload("RoomLiveAttr").
		Preload("AppRoomAdmins").
		Scopes(m.baseWhere(roomType)).
		Where("room_id NOT IN ?", notInIds).
		Group("room_id").
		Order("rand()").
		Limit(1).
		First(&data).Error
	return
}

// 根据in条件筛选正常状态的房间
func (m *AppLiveRoom) QueryInFilter(ids []int64, roomType int) (row int64, data []AppLiveRoom, err error) {
	model := utils.GEngine.Model(m).Select("room_id").Where("room_id IN ?", ids).Scopes(m.baseWhere(roomType))
	model = model.Find(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

// 随机获取正常状态的房间(直播或者派对)
func (m *AppLiveRoom) QueryRandNormalStatus(size int) (data []AppLiveRoom, err error) {
	err = utils.GEngine.Model(m).
		Preload("AppRoomAdmins").
		Preload("RoomLiveAttr").
		Preload("SystemUser").
		Where("room_password = '' AND (( room_type = ? AND room_status = ? AND room_live_status = ? ) OR ( room_type = ?  AND room_status = ? AND room_union_id > 0 ))", ROOM_TYPE_LIVE, ROOM_STATUS_OK, ROOM_LIVE_STATUS_ON, ROOM_TYPE_PARTY, ROOM_STATUS_OK).
		Order("rand()").
		Limit(size).
		Find(&data).Error
	return
}

func (m *AppLiveRoom) baseWhere(roomType int) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if roomType == ROOM_TYPE_LIVE {
			db = db.Where("room_type = ? AND room_live_status = ? AND room_status = ? AND room_password = ''", ROOM_TYPE_LIVE, ROOM_LIVE_STATUS_ON, ROOM_STATUS_OK)
		} else {
			db = db.Where("room_type = ? AND  room_status = ? AND room_union_id > 0 AND room_password = ''", ROOM_TYPE_PARTY, ROOM_STATUS_OK)
		}
		return db
	}
}

type AppLiveRoomAdList struct {
	RoomId           int64 `json:"room_id"`
	RoomRandomWeight int64 `json:"room_random_weight"`
}

// 只查询 开播的 公会的房间
func (m *AppLiveRoom) QueryByLiveStatus() (result []*AppLiveRoomAdList, total int64, err error) {
	db := utils.GEngine.Model(m).Select("room_id, room_random_weight").Where("deleted = 0").
		Where("room_union_id > 0").Where("room_status = 0").Where("room_random_weight > 0")

	if err = db.Find(&result).Error; err != nil {
		return
	}

	err = db.Offset(-1).Count(&total).Error

	return
}

// 搜索房间信息
func (m *AppLiveRoom) GetSearchInfoByRoomId(roomId int64) (data AppLiveRoom, err error, isPretty bool) {
	if roomId >= MAX_LIVE_ROOM_PRETTY_ID {
		err = utils.GEngine.Model(m).
			Preload("SystemUser").
			Preload("RoomLiveAttr").
			// Preload("AppRoomAdmins").
			Where("room_id = ?", roomId).
			Where("room_status != ?", ROOM_STATUS_PLATFORM_BAN).
			First(&data).Error
	} else {
		err = utils.GEngine.Model(m).
			Preload("SystemUser").
			Preload("RoomLiveAttr").
			// Preload("AppRoomAdmins").
			Where("room_pretty_id = ?", roomId).
			Where("room_status != ?", ROOM_STATUS_PLATFORM_BAN).
			First(&data).Error
		isPretty = true
	}
	return
}

// 获取正常状态的房间(直播或者派对)
func (m *AppLiveRoom) QueryIn(roomIds []int64) (data []AppLiveRoom, err error) {
	var temp = make([]string, len(roomIds))
	for k, v := range roomIds {
		temp[k] = fmt.Sprintf("%d", v)
	}
	field := strings.Join(temp, ",")

	err = utils.GEngine.Model(m).
		Preload("AppRoomAdmins").
		Preload("RoomLiveAttr").
		Preload("SystemUser").
		Where("room_password = '' AND (( room_type = ? AND room_status = ? AND room_live_status = ? ) OR ( room_type = ?  AND room_status = ? AND room_union_id > 0 ))", ROOM_TYPE_LIVE, ROOM_STATUS_OK, ROOM_LIVE_STATUS_ON, ROOM_TYPE_PARTY, ROOM_STATUS_OK).
		Where("room_id IN (?)", roomIds).
		Order("field(room_id," + field + ")").
		Find(&data).Error
	return
}

// 获取正常状态的房间id(直播或者派对)
func (m *AppLiveRoom) QueryInRoomIds(roomIds []int64) (data []AppLiveRoom, err error) {
	err = utils.GEngine.Model(m).
		Select("*").
		Where("room_password = '' AND (( room_type = ? AND room_status = ? AND room_live_status = ? ) OR ( room_type = ?  AND room_status = ? AND room_union_id > 0 ))", ROOM_TYPE_LIVE, ROOM_STATUS_OK, ROOM_LIVE_STATUS_ON, ROOM_TYPE_PARTY, ROOM_STATUS_OK).
		Where("room_id IN (?)", roomIds).
		Find(&data).Error
	return
}
