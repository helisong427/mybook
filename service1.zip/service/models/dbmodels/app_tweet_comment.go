package dbmodels

import (
	"fmt"
	"gamers/utils"
	"gorm.io/gorm"
)

//朋友圈评论
type AppTweetComment struct {
	CommentID         int64     `gorm:"column:comment_id;primaryKey;autoIncrement"`
	CommentTweetID    int64     `gorm:"column:comment_tweet_id"`     //tweet_id
	CommentUserID     int64     `gorm:"column:comment_user_id"`      //评论用户id
	CommentToUserID   int64     `gorm:"column:comment_to_user_id"`   //回复用户id
	CommentParentID   int64     `gorm:"column:comment_parent_id"`    //顶级comment_id
	CommentToParentID int64     `gorm:"column:comment_to_parent_id"` //直接上级comment_id
	CommentContent    string    `gorm:"column:comment_content"`      //评论内容
	CommentLikeCount  int64     `gorm:"column:comment_like_count"`   //点赞数量
	BaseModel         BaseModel `gorm:"embedded" json:"base_model"`
}

func (AppTweetComment) TableName() string {
	return "app_tweet_comment"
}

//朋友圈关联
type AppTweetCommentJoin struct {
	CommentID         int64  `json:"comment_id"`
	CommentUserID     int64  `json:"comment_user_id"`
	CommentToUserID   int64  `json:"comment_to_user_id"`
	CommentParentID   int64  `json:"comment_parent_id"`
	CommentToParentID int64  `json:"comment_to_parent_id"`
	CommentContent    string `json:"comment_content"`
	CommentLikeCount  int64  `json:"comment_like_count"`
	Created           int64  `json:"created"`
	UserNickname      string `json:"user_nickname"`
	UserIconurl       string `json:"user_iconurl"`
	UserIsLike        int    `json:"user_is_like"`
	ToUserNickname    string `json:"to_user_nickname"`
}

//Creat 创建
func (m *AppTweetComment) Create() (err error) {
	err = utils.GEngine.Create(m).Error
	return
}

const (
	TWEET_COMMENT_FOLD_NUMBER = 5 //折叠评论条数
)

//QueryByTweetID 根据朋友圈id查询
func (m *AppTweetComment) QueryByTweetID(tweetId, page, size int, userId string) (total int64, data []AppTweetCommentJoin, err error) {
	err = utils.GEngine.Select("*,app_tweet_comment.created,u.user_nickname,u.user_iconurl,atcu.user_is_like as user_is_like,u2.user_nickname as to_user_nickname").
		Model(m).
		Joins("INNER JOIN system_user AS u ON app_tweet_comment.comment_user_id = u.user_id").
		Joins("LEFT JOIN system_user AS u2 ON app_tweet_comment.comment_to_user_id = u2.user_id").
		Joins("LEFT JOIN app_tweet_comment_user AS atcu ON ( app_tweet_comment.comment_id = atcu.user_comment_id and atcu.user_user_id = ? )", userId).
		Where("comment_parent_id = 0 AND comment_tweet_id =? AND app_tweet_comment.deleted = 0", tweetId).
		Order("app_tweet_comment.created desc").
		Offset((page * size) - size).Limit(size).
		Find(&data).Count(&total).Error
	return
}

//QueryByCommentParentIds 根据顶级id查询子级评论
func (m *AppTweetComment) QueryByCommentParentIds(commentParentIds []int64, userId string) (data []AppTweetCommentJoin, err error) {
	err = utils.GEngine.Select("*,app_tweet_comment.created,u.user_nickname,u.user_iconurl,atcu.user_is_like as user_is_like,u2.user_nickname as to_user_nickname").
		Model(m).
		Joins("INNER JOIN system_user AS u ON app_tweet_comment.comment_user_id = u.user_id").
		Joins("LEFT JOIN system_user AS u2 ON app_tweet_comment.comment_to_user_id = u2.user_id").
		Joins("LEFT JOIN app_tweet_comment_user AS atcu ON ( app_tweet_comment.comment_id = atcu.user_comment_id and atcu.user_user_id = ? )", userId).
		Where("comment_parent_id IN ? AND app_tweet_comment.deleted = 0", commentParentIds).
		Order("app_tweet_comment.created desc").
		Find(&data).Error
	return
}

//QueryByCommentParentIds 根据顶级id查询5条子级评论
func (m *AppTweetComment) QueryByCommentParentId(commentParentIds int64, userId string) (total int64, data []AppTweetCommentJoin, err error) {
	err = utils.GEngine.Select("*,app_tweet_comment.created,u.user_nickname,u.user_iconurl,atcu.user_is_like as user_is_like,u2.user_nickname as to_user_nickname").
		Model(m).
		Joins("INNER JOIN system_user AS u ON app_tweet_comment.comment_user_id = u.user_id").
		Joins("LEFT JOIN system_user AS u2 ON app_tweet_comment.comment_to_user_id = u2.user_id").
		Joins("LEFT JOIN app_tweet_comment_user AS atcu ON ( app_tweet_comment.comment_id = atcu.user_comment_id and atcu.user_user_id = ? )", userId).
		Where("comment_parent_id = ? AND app_tweet_comment.deleted = 0", commentParentIds).
		Order("app_tweet_comment.created desc").
		Limit(TWEET_COMMENT_FOLD_NUMBER).
		Find(&data).Count(&total).Error
	return
}

//QueryByCommentParentIds 根据顶级id分页查询子评论
func (m *AppTweetComment) QueryPageByCommentParentId(commentParentIds int64, userId int64, page int, size int) (total int64, data []AppTweetCommentJoin, err error) {
	err = utils.GEngine.Select("*,app_tweet_comment.created,u.user_nickname,u.user_iconurl,atcu.user_is_like as user_is_like,u2.user_nickname as to_user_nickname").
		Model(m).
		Joins("INNER JOIN system_user AS u ON app_tweet_comment.comment_user_id = u.user_id").
		Joins("LEFT JOIN system_user AS u2 ON app_tweet_comment.comment_to_user_id = u2.user_id").
		Joins("LEFT JOIN app_tweet_comment_user AS atcu ON ( app_tweet_comment.comment_id = atcu.user_comment_id and atcu.user_user_id = ? )", userId).
		Where("comment_parent_id = ? AND app_tweet_comment.deleted = 0", commentParentIds).
		Order("app_tweet_comment.created desc").
		Offset((page * size) - size).
		Limit(size).
		Find(&data).Count(&total).Error
	return
}

//QueryByOne 查询一条评论
func (m *AppTweetComment) QueryByOne(commentId int64, userId string) (has int64, data AppTweetCommentJoin, err error) {
	model := utils.GEngine.Select("*,app_tweet_comment.created,u.user_nickname,u.user_iconurl,atcu.user_is_like as user_is_like,u2.user_nickname as to_user_nickname").
		Model(m).
		Joins("INNER JOIN system_user AS u ON app_tweet_comment.comment_user_id = u.user_id").
		Joins("LEFT JOIN system_user AS u2 ON app_tweet_comment.comment_to_user_id = u2.user_id").
		Joins("LEFT JOIN app_tweet_comment_user AS atcu ON ( app_tweet_comment.comment_id = atcu.user_comment_id and atcu.user_user_id = ? )", userId).
		Where("comment_id = ? AND app_tweet_comment.deleted = 0", commentId).
		First(&data)
	has = model.RowsAffected
	err = model.Error
	return
}

//插入成功以后
func (m *AppTweetComment) AfterCreate(tx *gorm.DB) (error error) {
	//朋友圈评论数+1
	model := AppTweet{}
	model.AddCommentCount(tx, m.CommentTweetID)
	return nil
}

//DecreaseLikeCount  减少点赞
func (m *AppTweetComment) DecreaseLikeCount(tx *gorm.DB, id int64) {
	sql := "update `app_tweet_comment` set comment_like_count = comment_like_count-1 where comment_id = ? "
	err := tx.Exec(sql, id).Error
	if err != nil {
		fmt.Println(err)
	}
}

//AddLikeCount  增加点赞
func (m *AppTweetComment) AddLikeCount(tx *gorm.DB, id int64) {
	sql := "update `app_tweet_comment` set comment_like_count = comment_like_count+1 where comment_id = ? "
	err := tx.Exec(sql, id).Error
	if err != nil {
		fmt.Println(err)
	}
}

//QueryExist 查询是否存在
func (m *AppTweetComment) QueryExist(id int) (has int64, err error) {
	model := utils.GEngine.Where("comment_id = ? AND deleted = 0", id).First(m)
	has = model.RowsAffected
	err = model.Error
	return
}

//查询一条
func (m *AppTweetComment) QueryFirst(id int) (has int64, data AppTweetComment, err error) {
	model := utils.GEngine.Where("comment_id = ? AND deleted = 0", id).First(&data)
	has = model.RowsAffected
	err = model.Error
	return
}
