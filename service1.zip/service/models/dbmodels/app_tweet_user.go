package dbmodels

import (
	"gamers/utils"
	"gorm.io/gorm"
)

//朋友圈用户表
type AppTweetUser struct {
	UserID       int64     `json:"user_id pk autoincr" gorm:"column:user_id;primaryKey;autoIncrement"`
	UserTweetID  int64     `json:"user_tweet_id"`  //tweet的id
	UserUserID   int64     `json:"user_user_id"`   //操作的用户id
	UserIsLike   int       `json:"user_is_like"`   //是否点了喜欢(0:没有,1喜欢)
	UserIsHidden int       `json:"user_is_hidden"` //是否屏蔽(0不屏蔽,1屏蔽)
	BaseModel    BaseModel `gorm:"embedded" json:"base_model"`
}

func (AppTweetUser) TableName() string {
	return "app_tweet_user"
}

//是否屏蔽
const (
	USER_IS_HIDDEN_NO  int = iota //否
	USER_IS_HIDDEN_YES            //是
)

//Create 创建
func (m *AppTweetUser) Create() (err error) {
	err = utils.GEngine.Create(m).Error
	return
}

//QueryOne 查询一条数据
func (m *AppTweetUser) QueryOne(userTweetID int, userUserId int) (row int64, data AppTweetUser, err error) {
	model := utils.GEngine.Where("user_tweet_id = ? and user_user_id = ?", userTweetID, userUserId).First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

//PointLike 点赞
func (m *AppTweetUser) PointLike() (err error) {
	tx := utils.GEngine
	update := AppTweetUser{}
	err = tx.Model(update).Where("user_id = ?", m.UserID).Update("user_is_like", USER_IS_LIKE_YES).Error
	if err == nil {
		m.UserIsLike = USER_IS_LIKE_YES
		err = m.AfterCreate(tx)
	}
	return
}

//UpdateHidden 更新屏蔽
func (m *AppTweetUser) UpdateHidden() (err error) {
	err = utils.GEngine.Model(m).Where("user_id = ?", m.UserID).Update("user_is_hidden", USER_IS_HIDDEN_YES).Error
	return
}

//CancelLike 取消赞
func (m *AppTweetUser) CancelLike() (err error) {
	tx := utils.GEngine
	update := AppTweetUser{}
	err = tx.Model(update).Where("user_id = ?", m.UserID).Update("user_is_like", USER_IS_LIKE_NO).Error
	if err == nil {
		err = m.AfterDelete(tx)
	}
	return
}

//AfterCreate 插入数据成功以后
func (m *AppTweetUser) AfterCreate(tx *gorm.DB) error {
	appTweetModel := AppTweet{}
	//增加朋友圈表点赞数
	if m.UserIsLike == USER_IS_LIKE_YES {
		appTweetModel.AddLikeCount(m.UserTweetID)
	}
	return nil
}

//AfterDelete 删除/取消点赞 成功以后
func (m *AppTweetUser) AfterDelete(tx *gorm.DB) error {
	appTweetModel := AppTweet{}
	//减少朋友圈表点赞数
	appTweetModel.DecreaseLikeCount(tx, m.UserTweetID)
	return nil
}
