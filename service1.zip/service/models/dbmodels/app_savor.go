package dbmodels

import "gamers/utils"

//兴趣表
type AppSavor struct {
	SavorID     int64     `json:"savor_id" gorm:"column:savor_id;primaryKey;autoIncrement"`
	SavorName   string    `json:"savor_name"`   //兴趣名称
	SavorOrder  int64     `json:"savor_order"`  //兴趣排序,升序
	SavorStatus int       `json:"savor_status"` //兴趣状态(0不显示,1显示)
	BaseModel   BaseModel `gorm:"embedded" json:"base_model"`
}

func (AppSavor) TableName() string {
	return "app_savor"
}

//Query 获取兴趣
func (m *AppSavor) Query() (data []AppSavor, err error) {
	err = utils.GEngine.Where("savor_status = 1").Order("savor_order desc").Find(&data).Error
	return
}

//QueryIdIn
func (m *AppSavor) QueryIdIn(id []string) (data []AppSavor, err error) {
	err = utils.GEngine.Where("savor_status = 1").Where("savor_id IN ?", id).Find(&data).Error
	return
}
