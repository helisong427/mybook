package dbmodels

import (
	"gamers/utils"
)

// 身份认证model
type Certification struct {
	CertificationId                   int64  `gorm:"column:certification_id;primaryKey" json:"certification_id"`
	CertificationRealName             string `gorm:"column:certification_real_name"`             //真实姓名
	CertificationIdCode               string `gorm:"column:certification_id_code"`               //身份证id
	CertificationPhoto                string `gorm:"column:certification_photo"`                 //认证照片
	CertificationStatus               int    `gorm:"column:certification_status"`                //身份信息认证状态(0待审核,1未通过,2通过)
	CertificationCustomerId           string `gorm:"column:certification_customer_id"`           //法大大交客户号
	CertificationTransactionId        string `gorm:"column:certification_transaction_id"`        //法大大交易编号
	CertificationAuthenticationNumber string `gorm:"column:certification_authentication_number"` //法大大认证号码
	CertificationFadadaUrl            string `gorm:"column:certification_fadada_url"`            //实名认证地址
	CertificationPositiveUrl          string `gorm:"column:certification_positive_url"`          //身份证正面照片
	CertificationNegativeUrl          string `gorm:"column:certification_negative_url"`          //身份证反面照片
	CertificationFaceUrl              string `gorm:"column:certification_face_url"`              //人脸识别照片
	CertificationContractUrl          string `gorm:"column:certification_contract_url"`          //合同url
	CertificationLivingStatus         int    `gorm:"column:certification_living_status"`         //是否活体(0没有活体,1活体认证成功,2法大大认证失败)
	CertificationApplyCount           int    `gorm:"column:certification_apply_count"`           //当日申请次数
	CertificationApplyTime            int64  `gorm:"column:certification_apply_time"`            //申请时间
	CertificationMeicaiSignup         int    `gorm:"column:certification_meicai_signup"`         //美差(0为签约,1已经签约)
	CertificationContractId           string `gorm:"column:certification_contract_id"`           //法大大合同编号
	BaseModel
}

func (Certification) TableName() string {
	return "app_certification"
}

const (
	//身份信息认证状态
	CERTIFICATION_STATUS_PENDING  int = iota //待审核
	CERTIFICATION_STATUS_PASS                //未通过
	CERTIFICATION_STATUS_OK                  //通过
	CERTIFICATION_MAX_APPLY_COUNT int = 5    //当日最大申请次数
)

const (
	//活体认证
	CERTIFICATION_STATUS_LIVING_ON  int = iota //未通过
	CERTIFICATION_STATUS_LIVING_YES            //已通过
)

const (
	//美差签约
	CERTIFICATION_MEICHAI_SIGN_NO  int = iota //未通过
	CERTIFICATION_MEICHAI_SIGN_YES int = iota //已经签约
)

//Create
func (m *Certification) Create() (affected int64, err error) {
	model := utils.GEngine.Create(m)
	affected = model.RowsAffected
	err = model.Error
	return
}

func (m *Certification) Update(id int64) (affected int64, err error) {
	model := utils.GEngine.Model(m).Where("certification_id = ?", id).Updates(m)
	affected = model.RowsAffected
	err = model.Error
	return
}

//QueryByUserId 根据用户id查询
func (m *Certification) QueryByUserId(userId int64) (data Certification, err error) {
	err = utils.GEngine.Model(m).Where("certification_id = ?", userId).First(&data).Error
	return
}

// 判断用户是否通过认证
func (m *Certification) VerificationByUserId(userId int64) (data Certification, err error) {
	err = utils.GEngine.Model(m).Where("certification_id = ? and certification_status = ?", userId, CERTIFICATION_STATUS_OK).First(&data).Error
	return
}

//根据法大大回调信息查询
func (m *Certification) QueryFddCallback(transactionId string) (row int64, data Certification, err error) {
	model := utils.GEngine.Where("certification_transaction_id = ? OR certification_authentication_number = ?", transactionId, transactionId).First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}
