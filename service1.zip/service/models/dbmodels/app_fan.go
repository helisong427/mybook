package dbmodels

import "gamers/utils"

type AppFan struct {
	FanID           int64     `json:"fan_id"`
	FanUserID       int64     `json:"fan_user_id"`        //主用户id(被粉用户)
	FanFollowUserID int64     `json:"fan_follow_user_id"` //粉丝用户id
	BaseModel       BaseModel `gorm:"embedded" json:"base_model"`
}

func (AppFan) TableName() string {
	return "app_fan"
}

//Create 创建
func (m *AppFan) Create() (err error) {
	err = utils.GEngine.Create(m).Error
	return
}

//QueryByUserID 根据主用户id查询
func (m *AppFan) QueryByUserID(fanUserID int) (data []AppAttention, err error) {
	err = utils.GEngine.Where("fan_user_id = ?", fanUserID).Find(&data).Error
	return
}

//Delete 删除用户关注
func (m *AppFan) Delete(fanUserID, fanFollowUserID int) (err error) {
	err = utils.GEngine.Where("fan_user_id = ? and fan_follow_user_id = ?", fanUserID, fanFollowUserID).Delete(m).Error
	return
}
