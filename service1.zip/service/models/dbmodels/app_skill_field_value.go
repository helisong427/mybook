package dbmodels

import (
	"encoding/json"
	"gamers/utils"
)

// 技能字段配置表
type AppSkillFieldValue struct {
	ValueId        int64     `gorm:"column:value_id" json:"value_id"`
	ValueSkillId   int64     `gorm:"column:value_skill_id" json:"value_skill_id"`     // 技能id
	ValueField     string    `gorm:"column:value_field" json:"value_field"`           // 技能字段
	ValueFieldName string    `gorm:"column:value_field_name" json:"value_field_name"` // 技能字段名称
	ValueValue     string    `gorm:"column:value_value" json:"value_value"`           // 技能字段值
	ValueOrder     int64     `gorm:"column:value_order" json:"value_order"`           // 字段排序
	BaseModel      BaseModel `gorm:"embedded" json:"-"`
}

type GameSkillFiledValue struct {
	ValueKey     string               `json:"value_key"`                                   // 技能字段
	ValueKeyName string               `gorm:"column:value_key_name" json:"value_key_name"` // 技能字段名称
	Values       []AppSkillFieldValue `json:"values"`
}

func (AppSkillFieldValue) TableName() string {
	return "app_skill_field_value"
}

func (s *AppSkillFieldValue) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s AppSkillFieldValue) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

// 根据id获取参数
func (m *AppSkillFieldValue) GetAppSkillFieldByValueKeyAndSkillId(key string, skillId int64) (data []AppSkillFieldValue, err error) {
	err = utils.GEngine.Model(m).Where("value_skill_id = ? and value_field = ? and deleted = 0", skillId, key).Order("value_order").Find(&data).Error
	return
}

// 根据id获取
func (m *AppSkillFieldValue) GetAppSkillFieldByValueId(ValueId int64) (data AppSkillFieldValue, err error) {
	err = utils.GEngine.Model(m).Where("value_id = ? and deleted = 0", ValueId).First(&data).Error
	return
}

// 根据skillId获取
func (m *AppSkillFieldValue) GetAppSkillFieldBySkillId(skillId int64) (data []AppSkillFieldValue, err error) {
	err = utils.GEngine.Model(m).Where("value_skill_id = ? and deleted = 0", skillId).Find(&data).Error
	return
}

// 校验value合法性
func (m *AppSkillFieldValue) CheckedByValueIdAndSkillIdAndValueField(valueId int64, skillId int64, valueField string) (result bool) {
	var data AppSkillFieldValue
	err := utils.GEngine.Model(m).Where("value_skill_id = ? and value_id = ? and value_field = ? and deleted = 0", skillId, valueId, valueField).First(&data).Error
	if err != nil {
		return false
	}
	return true
}
