package dbmodels

import (
	"encoding/json"
	"fmt"
	"sort"
	"time"

	"github.com/go-redis/redis"

	"gamers/utils"
)

// 砸蛋排行查询/接收/缓存

const (
	EggBreakRankMaxLimit   = 20
	EggBreakRankMaxTimeOut = time.Minute * 10
)

type EggBreakRecvRank struct {
	RankEggBreakId int                     `json:"rank_eggbreak_id"`
	RankTag        string                  `json:"rank_tag"`
	RankPeriod     int                     `json:"rank_period"`
	RankItems      []*EggBreakRankRecvItem `json:"rank_items"`
	// FOR QUERY
	QueryRankName       string `json:"_"`
	QueryRankDetailName string `json:"-"`
}

type EggBreakRankRecvItem struct {
	RankUserId     int64                     `json:"rank_user_id"`
	UserNickname   string                    `json:"user_nickname"`
	UserIconurl    string                    `json:"user_iconurl"`
	RankTotalPrice int64                     `json:"rank_total_price"`
	RankDetails    []*EggBreakRankRecvDetail `json:"rank_details"`
	// FOR QUERY
	DetailPropType  int `json:"-"`
	DetailPropId    int `json:"-"`
	DetailPropCount int `json:"-"`
	Edited          int `json:"-"`
}

type EggBreakRankRecvDetail struct {
	PropType     int    `json:"prop_type"`
	PropId       int    `json:"prop_id"`
	PropCount    int    `json:"prop_count"`
	PropName     string `json:"prop_name"`
	PropIcon     string `json:"prop_icon"`
	PropPrice    int64  `json:"-"`
	PropOrgPrice int64  `json:"-"`
}

func (r *EggBreakRecvRank) Init(eggBreakId int, tag string, period int) *EggBreakRecvRank {
	r.RankEggBreakId = eggBreakId
	r.RankTag = tag
	r.RankPeriod = period
	return r
}

func (r *EggBreakRecvRank) Query(rankName, rankDetailName string) error {
	r.QueryRankName = rankName
	r.QueryRankDetailName = rankDetailName

	var sql = fmt.Sprintf(`
	select rank_user_id, rank_total_price, user_nickname, user_iconurl, detail_prop_type, detail_prop_id, detail_prop_count, ZAB.edited as edited
	from
		(select rank_user_id, rank_total_price, edited from %s where rank_eggbreak_id = ? and rank_period = ?
		order by rank_total_price desc, edited asc
		limit ?
		) as ZAB
	left join
	    %s as C
	on ZAB.rank_user_id= C.user_id
	left join
		(select detail_user_id, detail_prop_type, detail_prop_id, detail_prop_count from %s where detail_eggbreak_id = ? and detail_period = ?) as D
	ON ZAB.rank_user_id = D.detail_user_id;
	`, r.QueryRankName,
		(&SystemUser{}).TableName(),
		r.QueryRankDetailName)

	var rows, err = utils.GEngine.Raw(sql,
		r.RankEggBreakId, r.RankPeriod,
		EggBreakRankMaxLimit,
		r.RankEggBreakId, r.RankPeriod).Rows()

	if err != nil {
		return err
	}
	defer rows.Close()

	var propIdMaps = map[int64]int64{} // select prop config
	var recvRankMaps = map[int64]*EggBreakRankRecvItem{}
	for rows.Next() {
		receiver := &EggBreakRankRecvItem{}
		if err := rows.Scan(&receiver.RankUserId, &receiver.RankTotalPrice,
			&receiver.UserNickname, &receiver.UserIconurl,
			&receiver.DetailPropType, &receiver.DetailPropId, &receiver.DetailPropCount,
			&receiver.Edited); err != nil {
			return err
		}

		if _, prs := recvRankMaps[receiver.RankUserId]; !prs {
			recvRankMaps[receiver.RankUserId] = receiver
		}
		var item = recvRankMaps[receiver.RankUserId]
		item.RankDetails = append(item.RankDetails, &EggBreakRankRecvDetail{
			PropType:  receiver.DetailPropType,
			PropId:    receiver.DetailPropId,
			PropCount: receiver.DetailPropCount,
		})
		propIdMaps[int64(receiver.DetailPropId)] = int64(receiver.DetailPropId)
	}

	if cfgMaps, err := new(AppProp).QueryByPropIdMaps(propIdMaps); err == nil {
		for _, v := range recvRankMaps {
			for _, d := range v.RankDetails {
				if cfg, ok := cfgMaps[int64(d.PropId)]; ok {
					d.PropName = cfg.PropName
					d.PropIcon = cfg.PropIcon
					d.PropPrice = cfg.PropPrice
					d.PropOrgPrice = cfg.PropOrgPrice
				}
			}
		}
	}

	r.RankItems = []*EggBreakRankRecvItem{}
	for _, v := range recvRankMaps {
		sort.Slice(v.RankDetails, func(i, j int) bool {
			if v.RankDetails[i].PropPrice != v.RankDetails[j].PropPrice {
				return v.RankDetails[i].PropPrice > v.RankDetails[j].PropPrice
			}
			if v.RankDetails[i].PropOrgPrice != v.RankDetails[j].PropOrgPrice {
				return v.RankDetails[i].PropOrgPrice > v.RankDetails[j].PropOrgPrice
			}
			return v.RankDetails[i].PropCount > v.RankDetails[j].PropCount
		})

		v.DetailPropType = v.RankDetails[0].PropType
		v.DetailPropId = v.RankDetails[0].PropId
		v.DetailPropCount = v.RankDetails[0].PropCount
		r.RankItems = append(r.RankItems, v)
	}
	sort.Slice(r.RankItems, func(i, j int) bool {
		if r.RankItems[i].RankTotalPrice != r.RankItems[j].RankTotalPrice {
			return r.RankItems[i].RankTotalPrice > r.RankItems[j].RankTotalPrice
		}

		var li, lj = len(r.RankItems[i].RankDetails), len(r.RankItems[j].RankDetails)
		if li > 0 && lj > 0 {
			if r.RankItems[i].RankDetails[0].PropPrice != r.RankItems[j].RankDetails[0].PropPrice {
				return r.RankItems[i].RankDetails[0].PropPrice > r.RankItems[j].RankDetails[0].PropPrice
			}
			if r.RankItems[i].RankDetails[0].PropOrgPrice != r.RankItems[j].RankDetails[0].PropOrgPrice {
				return r.RankItems[i].RankDetails[0].PropOrgPrice > r.RankItems[j].RankDetails[0].PropOrgPrice
			}
		}

		if r.RankItems[i].Edited != r.RankItems[j].Edited {
			return r.RankItems[i].Edited < r.RankItems[j].Edited
		}

		return li > lj
	})

	return nil
}

func (r *EggBreakRecvRank) RedisKey() string {
	return fmt.Sprintf("%s%d:%s:%d", utils.REDIS_EGGBREAK_RANK, r.RankEggBreakId, r.RankTag, r.RankPeriod)
}

func (r *EggBreakRecvRank) Save() error {
	data, err := json.Marshal(r)
	if err != nil {
		return err
	}
	return utils.RedisClient.Set(r.RedisKey(), string(data), EggBreakRankMaxTimeOut).Err()
}

func (r *EggBreakRecvRank) Get() error {
	val, err := utils.RedisClient.Get(r.RedisKey()).Result()
	switch err {
	case redis.Nil:
		return err
	case nil:
	default:
		return err
	}

	err = json.Unmarshal([]byte(val), r)
	if err != nil {
		utils.RedisClient.Del(r.RedisKey()) // 尝试删除缓存
		return err
	}
	return nil
}
