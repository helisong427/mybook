/**
 * @Author: panke
 * @Description: 房间pk结果表
 * @File: app_room_pk_record
 * @Date: 2021/4/16 11:19
 */

package dbmodels

import (
	"gamers/utils"

	"gorm.io/gorm"
)

type AppRoomPkRecord struct {
	RoomPkRecordID          int64  `json:"room_pk_record_id" gorm:"column:room_pk_record_id;primaryKey;autoIncrement"`
	RoomID                  int64  `json:"room_id" gorm:"column:room_id"`                                         // 房间id
	RoomPkRecordStart       int64  `json:"room_pk_record_start" gorm:"column:room_pk_record_start"`               // 开始时间
	RoomPkRecordEnd         int64  `json:"room_pk_record_end" gorm:"column:room_pk_record_end"`                   // 结束时间
	RoomPkRecordExpectedEnd int64  `json:"room_pk_record_expected_end" gorm:"column:room_pk_record_expected_end"` // 预计结束时间
	RoomPkRecordResult      int    `json:"room_pk_record_result" gorm:"column:room_pk_record_result"`             // pk结果(1红方 2蓝方 3平局)
	RoomPkRecordTime        int64  `json:"room_pk_record_time" gorm:"column:room_pk_record_time"`                 // pk时长
	RoomPkRecordRed         int64  `json:"room_pk_record_red" gorm:"column:room_pk_record_red"`                   // 红方pk值
	RoomPkRecordBlue        int64  `json:"room_pk_record_blue" gorm:"column:room_pk_record_blue"`                 // 蓝方pk值
	RoomPkRecordPunish      string `json:"room_pk_record_punish" gorm:"column:room_pk_record_punish"`             // 惩罚
	RoomPkRecordSettle      int    `json:"room_pk_record_settle" gorm:"column:room_pk_record_settle"`             // 结算方式(1系统结算 2直播结算)
	RoomPkRecordDetail      string `json:"room_pk_record_detail" gorm:"column:room_pk_record_detail"`             // pk详情
	RoomPkRecordTaskID      int64  `json:"room_pk_record_task_id" gorm:"column:room_pk_record_task_id"`           // 结算任务id
	RoomPkRecordStatus      int64  `json:"room_pk_record_status" gorm:"column:room_pk_record_status"`             // pk状态
	RoomPkRecordMvpUserId   int64  `json:"room_pk_record_mvp_user_id" gorm:"room_pk_record_mvp_user_id"`          // mvp user id
	RoomPkRecordSvpUserId   int64  `json:"room_pk_record_svp_user_id" gorm:"room_pk_record_svp_user_id"`          // svp user id
	RoomPkRecordCharmUserId int64  `json:"room_pk_record_charm_user_id" gorm:"room_pk_record_charm_user_id"`      // 魅力王id
	BaseModel
}

func (m *AppRoomPkRecord) TableName() string {
	return "app_room_pk_record"
}

// 创建pk记录
func (m *AppRoomPkRecord) Create(tx *gorm.DB, record *AppRoomPkRecord) (err error) {
	return tx.Model(m).Create(&record).Error
}

// 更新pk记录
func (m *AppRoomPkRecord) Updates(tx *gorm.DB, recordId int64, updates map[string]interface{}) (err error) {
	return tx.Model(m).Where("room_pk_record_id=?", recordId).Updates(updates).Error
}

// 获取pk记录-事务方法
func (m *AppRoomPkRecord) QueryAffairs(tx *gorm.DB, recordId int64) (data AppRoomPkRecord, err error) {
	err = tx.Model(m).Where("room_pk_record_id=?", recordId).Take(&data).Error
	return
}

// 获取pk记录
func (m *AppRoomPkRecord) Query(recordId int64) (data AppRoomPkRecord, err error) {
	err = utils.GEngine.Model(m).Where("room_pk_record_id=?", recordId).Take(&data).Error
	return
}
