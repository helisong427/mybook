package dbmodels

import "gamers/utils"

// 登录上报接口
type Login struct {
	LoginId               int64  `gorm:"column:login_id;primaryKey;autoIncrement" json:"login_id"`
	LoginDevice           string `gorm:"column:login_device" json:"login_device"`
	LoginUdid             string `gorm:"column:login_udid" json:"login_udid"`
	LoginSystem           int    `gorm:"column:login_system" json:"login_system"`
	LoginChannel          string `gorm:"column:login_channel" json:"login_channel"`
	LoginPoint            string `gorm:"column:login_point" json:"login_point"`
	LoginUnionId          int64  `gorm:"column:login_union_id" json:"login_union_id"`
	LoginUserId           int64  `gorm:"column:login_user_id" json:"login_user_id"`
	LoginNickname         string `gorm:"column:login_nickname" json:"login_nickname"`
	LoginGender           int    `gorm:"column:login_gender" json:"login_gender"`
	LoginMobile           string `gorm:"column:login_mobile" json:"login_mobile"`
	LoginBirthday         int64  `gorm:"column:login_birthday" json:"login_birthday"`
	LoginRegTime          int64  `gorm:"column:login_reg_time" json:"login_reg_time"`
	LoginVipLevel         int    `gorm:"column:login_vip_level" json:"login_vip_level"`
	LoginIsSparring       int    `gorm:"column:login_is_sparring" json:"login_is_sparring"`
	LoginIsAnchor         int    `gorm:"column:login_is_anchor" json:"login_is_anchor"`
	LoginHometownId       string `gorm:"column:login_hometown_id" json:"login_hometown_id"`
	LoginCountryId        string `gorm:"column:login_country_id" json:"login_country_id"`
	LoginProvinceId       string `gorm:"column:login_province_id" json:"login_province_id"`
	LoginCityId           string `gorm:"column:login_city_id" json:"login_city_id"`
	LoginRegionId         string `gorm:"column:login_region_id" json:"login_region_id"`
	LoginLongitude        string `gorm:"column:login_longitude" json:"login_longitude"`
	LoginLatitude         string `gorm:"column:login_latitude" json:"login_latitude"`
	LoginSystemVersion    string `gorm:"column:login_system_version" json:"login_system_version"`
	LoginDeviceBrand      string `gorm:"column:login_device_brand" json:"login_device_brand"`
	LoginDevicePattern    string `gorm:"column:login_device_pattern" json:"login_device_pattern"`
	LoginScreenResolution string `gorm:"column:login_screen_resolution" json:"login_screen_resolution"`
	LoginAppVersion       string `gorm:"column:login_app_version" json:"login_app_version"`
	LoginInternet         string `gorm:"column:login_internet" json:"login_internet"`
	LoginIp               string `gorm:"column:login_ip" json:"login_ip"`
	LoginRoomStatus       int    `gorm:"column:login_room_status" json:"login_room_status"`
	LoginStatus           int    `gorm:"column:login_status" json:"login_status"`
	LoginOnlineTimes      int64  `gorm:"column:login_online_times" json:"login_online_times"`
	ReportBaseModel
}

func (Login) TableName() string {
	return "login"
}

func (m *Login) Create() (err error) {
	err = utils.REngine.Create(m).Error
	return
}
