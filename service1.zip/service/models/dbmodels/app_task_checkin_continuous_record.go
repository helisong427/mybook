package dbmodels

import (
	"errors"
	"time"

	"gorm.io/gorm"

	"gamers/enum"
	"gamers/utils"
	"gamers/utils/ymd"
)

// 连续签到任务系列 --> 单独记录一下

type AppTaskCheckinContinuousRecord struct {
	RecordID           uint32 `json:"record_id"`
	RecordUserID       int64  `json:"record_user_id"`       // user_id
	RecordSetID        uint32 `json:"record_set_id"`        // 任务集合ID
	RecordTaskID       uint32 `json:"record_task_id"`       // 任务ID
	RecordConditionTag string `json:"record_condition_tag"` // 任务条件标签
	RecordProgress     uint32 `json:"record_progress"`      // 任务进度
	RecordState        uint32 `json:"record_state"`         // 任务状态(0:未完成;1:已完成;2:已领取)
	RecordTime         int64  `json:"record_time"`          // 任务时间
	BaseModel
}

func (AppTaskCheckinContinuousRecord) TableName() string {
	return "app_task_checkin_continuous_record"
}

type TaskCheckinContinuous struct {
	UserID            int64
	SetID             uint32
	RecordTime        time.Time // 触发时间
	MaxConditionCount uint32
	Tasks             []*AppTask
	TaskMaps          map[uint32]*AppTask
	CurConditionCount uint32
	CurTask           *AppTask
}

// 签到（只修改状态）
func (r *AppTaskCheckinContinuousRecord) Checkin(tcc *TaskCheckinContinuous) (string, error) {
	var err = utils.GEngine.Transaction(func(tx *gorm.DB) error {
		var orgRecord AppTaskRecord

		var queryDB = tx.Model(r).Where("record_user_id = ? AND record_set_id = ?", tcc.UserID, tcc.SetID).
			Order("record_time DESC").Limit(1)
		var err = queryDB.First(&orgRecord).Error
		if err != nil && err != gorm.ErrRecordNotFound {
			return err
		}

		if err == gorm.ErrRecordNotFound {
			// 没记录，第一天的签到
			tcc.CurConditionCount = 1
			if task, prs := tcc.TaskMaps[tcc.CurConditionCount]; prs {
				tcc.CurTask = task
			}

			var newRecord = &AppTaskCheckinContinuousRecord{
				RecordID:           0,
				RecordUserID:       tcc.UserID,
				RecordSetID:        tcc.SetID,
				RecordTaskID:       0,                   // tcc.CurTask.TaskID,
				RecordConditionTag: "checkinContinuous", // tcc.CurTask.TaskConditionTag,
				RecordProgress:     1,                   // tcc.CurTask.TaskConditionCount,
				RecordState:        enum.TaskStateInProgress,
				RecordTime:         tcc.RecordTime.Unix(),
			}
			if tcc.CurTask != nil {
				newRecord.RecordTaskID = tcc.CurTask.TaskID
				newRecord.RecordConditionTag = tcc.CurTask.TaskConditionTag
				newRecord.RecordProgress = tcc.CurTask.TaskConditionCount
				newRecord.RecordState = enum.TaskStateGet
			}

			if err := tx.Create(newRecord).Error; err != nil {
				return err
			}
			return nil
		}

		var pCount uint32
		var pCurDay bool
		var pState uint32 = enum.TaskStateInProgress
		if ymd.IsSameDay(time.Unix(orgRecord.RecordTime, 0), tcc.RecordTime) { // 同一天
			pCurDay = true
			pCount = orgRecord.RecordProgress
			pState = orgRecord.RecordState
		} else if ymd.IsSameDay(time.Unix(orgRecord.RecordTime, 0), tcc.RecordTime.AddDate(0, 0, -1)) { // 上一天
			pCount = orgRecord.RecordProgress + 1
			pState = enum.TaskStateInProgress
		} else {
			pCount = 1
			pState = enum.TaskStateInProgress
		}
		if pCount > tcc.MaxConditionCount {
			pCount = 1
			pState = enum.TaskStateInProgress
		}

		tcc.CurConditionCount = pCount
		if task, prs := tcc.TaskMaps[tcc.CurConditionCount]; prs {
			tcc.CurTask = task
		}

		if pCurDay {
			if pState == enum.TaskStateGet {
				return errors.New("已签到")
			}
			if tcc.CurTask == nil { // 无奖励
				return errors.New("已签到")
			}
		}

		// 无奖励
		if tcc.CurTask == nil {
			err = tx.Model(r).Where("record_id = ?", orgRecord.RecordID).Updates(map[string]interface{}{
				"record_task_id":       0,
				"record_condition_tag": "checkinContinuous",
				"record_progress":      tcc.CurConditionCount,
				"record_state":         enum.TaskStateInProgress,
				"record_time":          tcc.RecordTime.Unix(),
			}).Error
			if err != nil {
				return err
			}
			return nil
		}

		err = tx.Model(r).Where("record_id = ?", orgRecord.RecordID).Updates(map[string]interface{}{
			"record_task_id":       tcc.CurTask.TaskID,
			"record_condition_tag": tcc.CurTask.TaskConditionTag,
			"record_progress":      tcc.CurTask.TaskConditionCount,
			"record_state":         enum.TaskStateGet,
			"record_time":          tcc.RecordTime.Unix(),
		}).Error
		if err != nil {
			return err
		}

		// 向 app_task_record 插入数据
		err = tx.Create(&AppTaskRecord{
			RecordID:           0,
			RecordUserID:       tcc.UserID,
			RecordSetID:        tcc.SetID,
			RecordTaskID:       tcc.CurTask.TaskID,
			RecordConditionTag: tcc.CurTask.TaskConditionTag,
			RecordProgress:     tcc.CurTask.TaskConditionCount,
			RecordState:        enum.TaskStateGet,
			RecordTime:         tcc.RecordTime.Unix(),
		}).Error
		if err != nil {
			return err
		}

		return nil
	})

	if err != nil {
		return "签到失败", err
	}
	return "签到成功", nil
}
