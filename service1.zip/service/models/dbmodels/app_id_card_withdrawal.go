package dbmodels

import (
	"gamers/utils"
	"time"
)

// 身份证号码提现
type AppIdCardWithdrawal struct {
	WithdrawalId     int64  `gorm:"column:withdrawal_id;primaryKey;autoIncrement"`
	IdCard           string `gorm:"column:id_card"`           // 身份证号码
	DateMonth        string `gorm:"column:date_month"`        // 提现月份(202103)
	WithdrawalAmount int64  `gorm:"column:withdrawal_amount"` //本月提现金额
	BaseModel
}

func (AppIdCardWithdrawal) TableName() string {
	return "app_id_card_withdrawal"
}

func (m *AppIdCardWithdrawal) Create() (err error) {
	err = utils.GEngine.Create(m).Error
	return
}

// 按照月份和身份证号码查询一条
func (m *AppIdCardWithdrawal) QueryMonthFirst(idCard string) (row int64, data AppIdCardWithdrawal, err error) {
	model := utils.GEngine.Where("id_card = ? AND date_month = ?", idCard, time.Now().Format("200601")).First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}
