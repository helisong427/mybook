package dbmodels

import (
	"encoding/json"
	"gamers/controller/response"
	"gamers/utils"

	"gorm.io/gorm"
)

// 用户钱包表
type AppUserWallet struct {
	WalletUserId           int64     `gorm:"column:wallet_user_id;primaryKey;"` // 对应用户app_user_id
	WalletTotalAmount      int64     `gorm:"column:wallet_total_amount"`        // 代币总数
	WalletBuyAmount        int64     `gorm:"column:wallet_buy_amount"`          // 总购买代币数
	WalletBuyCash          int64     `gorm:"column:wallet_buy_cash"`            // 总购买金额人民币,单位分
	WalletTotalOver        int64     `gorm:"column:wallet_total_over"`          // 总余额(可用代币数)
	WalletTotalExtractable int64     `gorm:"column:wallet_total_extractable"`   // 总收益
	WalletPropAmount       int64     `gorm:"column:wallet_prop_amount"`         // 道具总收益
	WalletSparringAmount   int64     `gorm:"column:wallet_sparring_amount"`     // 陪练收益
	BaseModel              BaseModel `gorm:"embedded" json:"base_model"`
}

type PushUserExperience struct {
	UserId     int64 `json:"user_id"` // 对应用户app_user_id
	Experience int64 `json:"experience"`
}

// 推送到mq处理vip
func (m PushUserExperience) PushMq() {
	key := "VIP"
	data, err := json.Marshal(m)
	if err != nil {
		utils.LogErrorF("推送消息到topic[%v]失败，err：%s", m, err.Error())
		return
	}
	err = utils.KafkaSendMsg(key, utils.FuncGenerateDataId(), data)
	if err != nil {
		utils.LogErrorF("推送消息到topic[%s]失败，err：%s", key, err.Error())
	}
	return
}

func (AppUserWallet) TableName() string {
	return "app_user_wallet"
}

func (m *AppUserWallet) Create() (err error) {
	err = utils.GEngine.Create(m).Error
	return
}

// 查询用户钱包
func (m *AppUserWallet) Query(userId int64) (data AppUserWallet, err error) {
	err = utils.GEngine.Where("wallet_user_id = ?", userId).First(&data).Error
	return
}

// 充值
func (m *AppUserWallet) UpdateWalletRecharge(tx *gorm.DB, userId int64, amount, cash int64) (data AppUserWallet, err error) {
	err = tx.Model(m).Where("wallet_user_id = ?", userId).Updates(map[string]interface{}{
		"wallet_total_over":   gorm.Expr("wallet_total_over + ?", amount),
		"wallet_buy_amount":   gorm.Expr("wallet_buy_amount + ?", amount),
		"wallet_total_amount": gorm.Expr("wallet_total_amount + ?", amount),
		"wallet_buy_cash":     gorm.Expr("wallet_buy_cash + ?", cash),
	}).Select("wallet_user_id,wallet_total_amount,wallet_buy_amount,wallet_total_over,wallet_prop_amount").Scan(&data).Error
	return
}

func (m *AppUserWallet) UpdateWalletTotalOver(tx *gorm.DB, userId int64, isAdd, refund bool, amount int64) (data AppUserWallet, err error) {
	// 如果是增加
	if isAdd {
		err = tx.Model(m).Where("wallet_user_id = ?", userId).Updates(map[string]interface{}{"wallet_total_over": gorm.Expr("wallet_total_over + ?", amount)}).
			Select("wallet_user_id,wallet_total_amount,wallet_buy_amount,wallet_total_over,wallet_prop_amount").Scan(&data).Error
	} else {
		err = tx.Model(m).Where("wallet_user_id = ?", userId).Updates(map[string]interface{}{"wallet_total_over": gorm.Expr("wallet_total_over - ?", amount)}).
			Select("wallet_user_id,wallet_total_amount,wallet_buy_amount,wallet_total_over,wallet_prop_amount").Scan(&data).Error
		if !refund {
			vip := PushUserExperience{UserId: userId, Experience: amount}
			go vip.PushMq()
		}
	}
	return
}

// 增加礼物收入
func (m *AppUserWallet) UpdateUserGiftIncome(tx *gorm.DB, isAdd bool, userId int64, UserGiftAmount int64) (err error) {
	// 如果是增加
	if isAdd {
		model := tx.Model(m).Where("wallet_user_id = ?", userId).Updates(map[string]interface{}{"wallet_prop_amount": gorm.Expr("wallet_prop_amount + ?", UserGiftAmount),
			"wallet_total_extractable": gorm.Expr("wallet_total_extractable + ?", UserGiftAmount),
		})
		err = model.Error
	} else {
		model := tx.Model(m).Where("wallet_user_id = ?", userId).Updates(map[string]interface{}{"wallet_prop_amount": gorm.Expr("wallet_prop_amount - ?", UserGiftAmount),
			"wallet_total_extractable": gorm.Expr("wallet_total_extractable - ?", UserGiftAmount)})
		err = model.Error
	}

	return
}

// 增加订单收入
func (m *AppUserWallet) UpdateUserSparringIncome(tx *gorm.DB, isAdd bool, userId int64, UserSparringAmount int64) (err error) {
	// 如果是增加
	if isAdd {
		model := tx.Model(m).Where("wallet_user_id = ?", userId).Updates(map[string]interface{}{"wallet_sparring_amount": gorm.Expr("wallet_sparring_amount + ?", UserSparringAmount),
			"wallet_total_extractable": gorm.Expr("wallet_total_extractable + ?", UserSparringAmount),
		})
		err = model.Error
	} else {
		model := tx.Model(m).Where("wallet_user_id = ?", userId).Updates(map[string]interface{}{"wallet_sparring_amount": gorm.Expr("wallet_sparring_amount - ?", UserSparringAmount),
			"wallet_total_extractable": gorm.Expr("wallet_total_extractable - ?", UserSparringAmount)})
		err = model.Error
	}
	return
}

// 提现
func (m *AppUserWallet) Withdraw(tx *gorm.DB, userId int64, amount int64) (err error) {
	model := tx.Model(m).Where("wallet_user_id = ?", userId).
		Updates(map[string]interface{}{"wallet_total_extractable": gorm.Expr("wallet_total_extractable - ?", amount)})
	err = model.Error
	return
}

// 查询用户钱包
func (m *AppUserWallet) GetUserWallet(userId int64) (wallet response.UserWalletRep, err error) {
	err = utils.GEngine.Model(m).Select("wallet_total_over,wallet_total_extractable,(wallet_prop_amount + wallet_sparring_amount) as total_amount").
		Where("wallet_user_id = ?", userId).Find(&wallet).Error
	return
}

// 兑换go币
func (m *AppUserWallet) UpdateExchange(tx *gorm.DB, userId int64, money int64) (err error) {
	err = tx.Model(m).Where("wallet_user_id = ?", userId).Updates(map[string]interface{}{
		"wallet_total_extractable": gorm.Expr("wallet_total_extractable - ?", money),
		"wallet_total_over":        gorm.Expr("wallet_total_over + ?", money),
	}).Error
	return
}

// 查询用户余额
func (m *AppUserWallet) GetUserOver(userId int64) (wallet response.UserOverRep, err error) {
	err = utils.GEngine.Model(m).Select("wallet_total_over").Where("wallet_user_id = ?", userId).Find(&wallet).Error
	return
}

// 添加用户钱包go币
func (m *AppUserWallet) AddUserGogo(tx *gorm.DB, userId int64, GogoCount int64) (err error) {
	err = tx.Model(m).Where("wallet_user_id=?", userId).Updates(map[string]interface{}{
		"wallet_total_amount": gorm.Expr("wallet_total_amount + ?", GogoCount),
		"wallet_total_over":   gorm.Expr("wallet_total_over + ?", GogoCount),
	}).Error
	return
}
