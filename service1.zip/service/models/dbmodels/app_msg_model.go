package dbmodels

import (
	"encoding/json"
	"gamers/utils"

	"github.com/go-redis/redis"
)

type AppMsgModel struct {
	MsgId                int64     `gorm:"column:msg_id" json:"msg_id"`
	MsgKey               string    `gorm:"column:msg_key" json:"msg_key"`
	MsgTitle             string    `gorm:"column:msg_title" json:"msg_title"`
	MsgContent           string    `gorm:"column:msg_content" json:"msg_content"`
	MsgActionStart       int       `gorm:"column:msg_action_start" json:"msg_action_start"`
	MsgActionEnd         int       `gorm:"column:msg_action_end" json:"msg_action_end"`
	MsgColor             string    `gorm:"column:msg_color" json:"msg_color"`
	MsgNotificationClose int       `gorm:"column:msg_notification_close" json:"msg_notification_close"` // 是否关闭通知栏
	MsgSmsSend           int       `gorm:"column:msg_sms_send" json:"msg_sms_send"`                     // 是否发送短信
	MsgSmsContent        string    `gorm:"column:msg_sms_content" json:"msg_sms_content"`               // 短信发送内容
	BaseModel            BaseModel `gorm:"embedded" json:"base_model"`
}

func (AppMsgModel) TableName() string {
	return "app_msg_model"
}

func (s *AppMsgModel) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s AppMsgModel) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

const (
	MSG_SEND_SMS_NO = iota // 是否发送短信
	MSG_SEND_SMS_YES
)

func (m *AppMsgModel) GetMsgByKey(msgKey string) (data AppMsgModel, err error) {
	//获取缓存
	err = utils.RedisClient.HGet(utils.REDIS_MSG_MODEL, msgKey).Scan(&data)
	if err != nil && err != redis.Nil {
		return
	}
	if err == nil {
		return
	}
	//未获取到缓存，从数据库取
	err = utils.GEngine.Model(m).Where("msg_key = ? and deleted = 0", msgKey).First(&data).Error
	if err != nil {
		return
	}
	//保存缓存
	err = utils.RedisClient.HSet(utils.REDIS_MSG_MODEL, msgKey, data).Err()
	return
}
