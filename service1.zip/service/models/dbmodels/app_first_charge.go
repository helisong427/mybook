package dbmodels

import "gamers/utils"

//首充道具
type AppFirstCharge struct {
	ChargeId        int64   `gorm:"column:charge_id"`                          //首充奖励id
	ChargePropId    int64   `gorm:"column:charge_prop_id"`                     //礼物id
	ChargePropCount int64   `gorm:"column:charge_prop_count"`                  //数量
	ChargeSort      int64   `gorm:"column:charge_sort"`                        //礼物排序,从小到大
	ChargeStatus    int     `gorm:"column:charge_status"`                      //道具状态(0关闭,1开启)
	AppProp         AppProp `gorm:"foreignKey:PropId;references:ChargePropId"` //关联礼物
	BaseModel
}

const (
	//道具状态
	FIRST_CHARGE_STATUS_OFF int = iota //关闭
	FIRST_CHARGE_STATUS_ON             //开启
)

func (AppFirstCharge) TableName() string {
	return "app_first_charge"
}

//查询所有可用奖励
func (m *AppFirstCharge) QueryAll() (data []AppFirstCharge, err error) {
	err = utils.GEngine.Model(m).Joins("AppProp").
		Where("charge_status = ?", FIRST_CHARGE_STATUS_ON).
		Order("charge_sort asc").
		Find(&data).Error
	return
}
