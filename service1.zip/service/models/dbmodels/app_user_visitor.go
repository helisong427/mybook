package dbmodels

import (
	"gamers/utils"
	"gorm.io/gorm"
	"time"
)

type AppUserVisitor struct {
	VisitId            int64      `gorm:"column:visit_id" json:"visit_id"`
	VisitUserId        int64      `gorm:"column:visit_user_id" json:"visit_user_id"`                 // 被访问用户ID
	VisitType          int64      `gorm:"column:visit_type" json:"visit_type"`                       // 访问类型(0个人中心, 1 技能页)
	VisitVisitorUserId int64      `gorm:"column:visit_visitor_user_id" json:"visit_visitor_user_id"` // 访问者用户id
	VisitLastTime      int64      `gorm:"column:visit_last_time" json:"visit_last_time"`             // 最后访问时间
	VisitTimes         int64      `gorm:"column:visit_times" json:"visit_times"`                     // 访问次数
	Created            int64      `gorm:"column:created" json:"created"`                             // 记录创建时间
	Edited             int64      `gorm:"column:edited" json:"edited"`                               // 修改时间
	Deleted            int64      `gorm:"column:deleted" json:"deleted"`                             // 删除时间
	SystemUser         SystemUser `gorm:"foreignKey:UserID;references:VisitVisitorUserId"`           // 关联访客用户信息
}

func (m *AppUserVisitor) TableName() string {
	return "app_user_visitor"
}

// 创建记录
func (m *AppUserVisitor) Create() error {
	m.Created = time.Now().Unix()
	return utils.GEngine.Model(m).Create(m).Error
}

// 更新记录
func (m *AppUserVisitor) Update(visitId int64, update map[string]interface{}) error {
	return utils.GEngine.Model(m).
		Where("deleted = 0").
		Where("visit_id = ?", visitId).
		Updates(update).Error
}

type AppUserVisitorResult struct {
	VisitId    int64 `json:"visit_id"`
	VisitTimes int64 `json:"visit_times"` // 访问次数
}

func (m *AppUserVisitor) QueryByUidAndType(visitUserId, visitVisitUserId int64) (data *AppUserVisitorResult, err error) {
	var (
		result AppUserVisitorResult
	)

	db := utils.GEngine.Model(m).Select(`visit_id, visit_times`).
		Where("deleted = 0").
		Where("visit_user_id = ?", visitUserId).
		Where("visit_visitor_user_id = ?", visitVisitUserId)

	// if visitType > -1 {
	// 	db = db.Where("visit_type = ?", visitType)
	// }

	err = db.First(&result).Error

	data = &result

	return
}

// 分页查询信息访客
func (m *AppUserVisitor) QueryPage(userId int64, page int, size int) (total int64, data []*AppUserVisitor, err error) {
	db := utils.GEngine.
		Model(m).
		Preload("SystemUser", func(db *gorm.DB) *gorm.DB {
			return db.Select("user_id,user_nickname,user_iconurl,user_gender,user_birthday")
		}).
		Where("visit_user_id = ?", userId)

	err = db.Offset((page * size) - size).
		Limit(size).
		Order("visit_last_time desc").
		Find(&data).Error

	db.Offset(-1).Limit(-1).Count(&total)

	return
}
