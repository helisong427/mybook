package dbmodels

import (
	"encoding/json"
	"gamers/utils"
	"github.com/go-redis/redis"
	"gorm.io/gorm"
	"strconv"
)

// 用户vip
type AppUserVipExperience struct {
	ExperienceUserId    int64     `gorm:"column:experience_user_id" json:"experience_user_id"`
	ExperienceValue     int64     `gorm:"column:experience_value" json:"experience_value"`
	ExperienceNextValue int64     `gorm:"column:experience_next_value" json:"experience_next_value"`
	ExperienceLevel     int       `gorm:"column:experience_level" json:"experience_level"`
	BaseModel           BaseModel `gorm:"embedded" json:"base_model"`
}

func (AppUserVipExperience) TableName() string {
	return "app_user_vip_experience"
}
func (s *AppUserVipExperience) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s AppUserVipExperience) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

// 新建用户vip信息
func (m *AppUserVipExperience) Create(create bool) (err error) {
	if create {
		err = utils.GEngine.Model(m).Create(m).Error
	} else {
		err = utils.GEngine.Model(m).Where("experience_user_id = ?", m.ExperienceUserId).Save(m).Error
	}

	return
}

// 增加用户经验
func (m *AppUserVipExperience) UpdateUserExperienceByUserId(userId, experience, next int64, level int) (data AppUserVipExperience, err error) {
	key := strconv.Itoa(int(userId))
	err = utils.GEngine.Model(m).Where("experience_user_id = ?", userId).
		Updates(map[string]interface{}{"experience_value": gorm.Expr("experience_value + ?", experience),
			"experience_next_value": next, "experience_level": level}).Scan(&data).Error
	if err != nil {
		return
	}
	err = utils.RedisClient.HDel(utils.REDIS_USER_VIP_INFO, key).Err()
	return
}

// 获取用户vip信息
func (m AppUserVipExperience) GetUserVipLevelByUserId(userId int64) (data AppUserVipExperience, err error) {
	key := strconv.Itoa(int(userId))
	err = utils.RedisClient.HGet(utils.REDIS_USER_VIP_INFO, key).Scan(&data)
	if err != redis.Nil {
		return
	}
	err = utils.GEngine.Where("experience_user_id = ?", userId).First(&data).Error
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	// 如果为空
	if err == gorm.ErrRecordNotFound {
		minVip, err := new(AppUserVipLevel).GetMinVipLevelByExperience()
		if err != nil {
			return data, err
		}
		data = AppUserVipExperience{
			ExperienceUserId:    userId,
			ExperienceNextValue: minVip.LevelMinExperience,
		}
		err = data.Create(true)
		if err != nil {
			return data, err
		}
	}
	err = utils.RedisClient.HSet(utils.REDIS_USER_VIP_INFO, key, data).Err()
	return
}
