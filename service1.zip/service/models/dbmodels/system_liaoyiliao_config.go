package dbmodels

import (
	"encoding/json"
	"gamers/utils"

	"github.com/go-redis/redis"
)

//撩一撩配置
type SystemLiaoyiliaoConfig struct {
	ID           int64  `gorm:"column:id"`
	RegisterTime int64  `gorm:"column:register_time"`
	Amount       uint32 `gorm:"column:amount"`
	BaseModel
}

func (SystemLiaoyiliaoConfig) TableName() string {
	return "system_liaoyiliao_config"
}

func (m *SystemLiaoyiliaoConfig) QueryAll() (data []SystemLiaoyiliaoConfig, err error) {
	result, err := utils.RedisClient.Get(utils.REDIS_LIAOYILIAO_CONFIG).Result()
	if err != nil {
		if err == redis.Nil {
			err = utils.GEngine.Where("deleted = 0").Order("register_time asc").Find(&data).Error
			if err != nil {
				return
			}
			marshal, _ := json.Marshal(data)
			utils.RedisClient.Set(utils.REDIS_LIAOYILIAO_CONFIG, string(marshal), 0)
		}
		return
	}
	err = json.Unmarshal([]byte(result), &data)
	return
}
