package dbmodels

import "gamers/utils"

type AppImManager struct {
	ManagerId      int64     `gorm:"column:manager_id;primaryKey" json:"manager_id"`
	ManagerName    string    `gorm:"column:manager_name" json:"manager_name"`
	ManagerIconurl string    `gorm:"column:manager_iconurl" json:"manager_iconurl"`
	ManagerType    int64     `gorm:"column:manager_type" json:"manager_type"`
	ManagerInit    int64     `gorm:"column:manager_init" json:"manager_init"`
	ManagerRemark  string    `gorm:"column:manager_remark" json:"manager_remark"`
	BaseModel      BaseModel `gorm:"embedded" json:"base_model"`
}

const (
	MANAGER_INIT_FALSE = iota
	MANAGER_INIT_TRUE
)

// 表名
func (AppImManager) TableName() string {
	return "app_im_manager"
}

// 获取所有管理员账号
func (m *AppImManager) GetAllImManager() (data []AppImManager, err error) {
	err = utils.GEngine.Model(m).Where("deleted = 0  and manager_init = 0").Find(&data).Error
	return
}

// 修改
func (m *AppImManager) Update() (err error) {
	err = utils.GEngine.Save(m).Error
	return
}
