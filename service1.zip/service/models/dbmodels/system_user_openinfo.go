package dbmodels

import (
	"gamers/utils"
	"gorm.io/gorm"
)

// 第三方用户信息表
type SystemUserOpeninfo struct {
	OpeninfoID       int64     `json:"openinfo_id pk autoincr" gorm:"column:openinfo_id;primaryKey;autoIncrement"`
	OpeninfoType     int       `json:"openinfo_type"`     // open的类型 0--未知 1--微信   2--QQ   3--微博
	OpeninfoOpenid   string    `json:"openinfo_openid"`   // 微信unionid/新浪id/QQopenid
	OpeninfoNickname string    `json:"openinfo_nickname"` // 用户昵称
	OpeninfoGender   int       `json:"openinfo_gender"`   // 用户性别0未知,1男,2女
	OpeninfoIconurl  string    `json:"openinfo_iconurl"`  // 用户头像
	OpeninfoUserID   int64     `json:"openinfo_user_id"`  // 所属会员id,0表示没有绑定会员
	OpeninfoRegIP    uint      `json:"openinfo_reg_ip"`   // 注册ip
	BaseModel        BaseModel `gorm:"embedded" json:"base_model"`
}

func (SystemUserOpeninfo) TableName() string {
	return "system_user_openinfo"
}

type OpeninfoType int //open的类型

const (
	OPENINFO_TYPE_WECHAT     OpeninfoType = iota // 微信
	OPENINFO_TYPE_QQ                             // QQ
	OPENINFO_TYPE_WEIBO                          // 微博
	OPENINFO_TYPE_WECHATMINI                     // 微信小程序
)

// 创建用户
func (m *SystemUserOpeninfo) CreateUser() (err error) {
	err = utils.GEngine.Create(m).Error
	return
}

// 根据用户openid查询用户
func (m *SystemUserOpeninfo) OpenidByUser() (user SystemUserOpeninfo, err error) {
	err = utils.GEngine.Where("openinfo_openid = ? and openinfo_type = ?", m.OpeninfoOpenid, m.OpeninfoType).First(&user).Error
	return
}

// 根据用户id查询用户
func (m *SystemUserOpeninfo) QueryByUserId(userId int64) (row int64, data SystemUserOpeninfo, err error) {
	model := utils.GEngine.Model(m).Where("openinfo_user_id = ?", userId).First(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

// 更新用户信息
func (m *SystemUserOpeninfo) UpdateUserInfo(id int64) (affected int64, err error) {
	model := utils.GEngine.Model(m).Where("openinfo_id", id).Updates(m)
	affected = model.RowsAffected
	err = model.Error
	return
}

// 绑定用户id
func (m *SystemUserOpeninfo) BindUserId(openId string, openType int, userId int64) (affected int64, err error) {
	model := utils.GEngine.Model(m).Where("openinfo_openid = ? and openinfo_type = ?", openId, openType).Update("openinfo_user_id", userId)
	affected = model.RowsAffected
	err = model.Error
	return
}

// 用户登录
func (m *SystemUserOpeninfo) UserLogin() (user SystemUserOpeninfo, err error) {
	user, err = m.OpenidByUser()
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	if err == nil && user.OpeninfoID != 0 {
		return
	}

	//用户不存在，创建用户信息
	if err != nil && err == gorm.ErrRecordNotFound {
		err = m.CreateUser()
		if err != nil && err != gorm.ErrRecordNotFound {
			return
		}
		//再次查询用户完整信息
		user, err = m.OpenidByUser()
		if err != nil && err != gorm.ErrRecordNotFound {
			return
		}
		return
	}
	return
}
