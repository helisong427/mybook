package dbmodels

import "gamers/utils"

//AppQuickReply 快捷回复表
type AppQuickReply struct {
	ReplyId      int64     `json:"reply_id" gorm:"column:reply_id;primaryKey;autoIncrement"`
	ReplyType    int       `gorm:"column:reply_type" json:"reply_type"`
	ReplyContent string    `json:"reply_content"` //回复内容
	ReplyOrder   int       `json:"reply_order"`   //快捷语排序
	BaseModel    BaseModel `gorm:"embedded" json:"-"`
}

func (AppQuickReply) TableName() string {
	return "app_quick_reply"
}

const (
	REPLY_TYPE_GROUP = iota // 直播间的快捷回复
	REPLY_TYPE_IM           // im的快捷回复
)

//安排序返回快捷键列表
func (m *AppQuickReply) GetQuickReplyByType(replyType int) (results []AppQuickReply, err error) {
	engine := utils.GEngine
	err = engine.Model(m).Where("reply_type = ?", replyType).Order("reply_order").Find(&results).Error
	return
}
