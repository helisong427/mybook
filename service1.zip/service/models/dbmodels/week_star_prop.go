package dbmodels

import (
	"fmt"
	"gamers/utils"
	"time"
)

type AppWeekStarProp struct {
	PropId            int64 `gorm:"column:prop_id" json:"prop_id"`
	PropUserId        int64 `gorm:"column:prop_user_id" json:"prop_user_id"`                 // 赠送用户id
	PropRoomId        int64 `gorm:"column:prop_room_id" json:"prop_room_id"`                 // 礼物赠送房间id
	PropRoomUnionId   int64 `gorm:"column:prop_room_union_id" json:"prop_room_union_id"`     // 礼物赠送房间id的公会id
	PropRoomType      int64 `gorm:"column:prop_room_type" json:"prop_room_type"`             // 类型(0音频直播,1音频派对)
	PropRoomAttrId    int64 `gorm:"column:prop_room_attr_id" json:"prop_room_attr_id"`       // 收到礼物时房间属性id
	PropAnchorId      int64 `gorm:"column:prop_anchor_id" json:"prop_anchor_id"`             // 收礼主播id
	PropAnchorUnionId int64 `gorm:"column:prop_anchor_union_id" json:"prop_anchor_union_id"` // 主播公会id
	PropPropId        int64 `gorm:"column:prop_prop_id" json:"prop_prop_id"`                 // 礼物id
	PropPropPrice     int64 `gorm:"column:prop_prop_price" json:"prop_prop_price"`           // 礼物代币单价格
	PropPropCount     int64 `gorm:"column:prop_prop_count" json:"prop_prop_count"`           // 单次礼物数量
	PropPropWealth    int64 `gorm:"column:prop_prop_wealth" json:"prop_prop_wealth"`         // 总财富值
	PropPropCharm     int64 `gorm:"column:prop_prop_charm" json:"prop_prop_charm"`           // 总魅力值
	PropGiveTime      int64 `gorm:"column:prop_give_time" json:"prop_give_time"`             // 赠送(获得)时间
	PropIncome        int64 `gorm:"column:prop_income" json:"prop_income"`                   // 礼物总价
	Created           int64 `gorm:"column:created" json:"created"`                           // 创建时间
	Edited            int64 `gorm:"column:edited" json:"edited"`                             // 修改时间
	Deleted           int64 `gorm:"column:deleted" json:"deleted"`                           // 删除时间
}

func (*AppWeekStarProp) TableName() string {
	return "app_week_star_prop"
}

func (m *AppWeekStarProp) Create() error {
	m.Created = time.Now().Unix()
	return utils.GEngine.Model(m).Create(m).Error
}

type WeekStarPropItem struct {
	PropCount        int64  `json:"prop_count"`         // 礼物数量
	PropUserId       int64  `json:"prop_user_id"`       // 送礼/收礼 用户ID
	PropIcon         string `json:"prop_icon"`          // 头像框
	PropUserNickname string `json:"prop_user_nickname"` // 送礼/收礼 用户 昵称
	PropUserIconurl  string `json:"prop_user_iconurl"`  // 送礼 用户 头像
	PropRank         int64  `json:"prop_rank"`          // 排名
}

// 通过 礼物ID获取对应的 礼物统计数据
func (m *AppWeekStarProp) GetListByPropPropId(propId int64, user string) (data []WeekStarPropItem, err error) {
	db := utils.GEngine.Model(m).Select(fmt.Sprintf(`sum(prop_prop_count) as prop_count, prop_%v_id as prop_user_id,
		su.user_nickname as prop_%v_nickname, su.user_iconurl as prop_%v_iconurl`, user, user, user)).
		Joins(fmt.Sprintf(`left join system_user su on su.user_id = app_week_star_prop.prop_%v_id`, user)).
		Where("deleted = 0").
		Where("prop_prop_id = ?", propId)

	err = db.Group(fmt.Sprintf("prop_%v_id", user)).Order("prop_count desc").Offset(0).Limit(10).Find(&data).Error

	return
}

// 通过id 数组 获取用户列表
func (m *AppWeekStarProp) GetUserInfoByIds(ids []interface{}) (data []WeekStarPropItem, err error) {
	db := utils.GEngine.Model(&SystemUser{}).Select("user_id as prop_user_id, user_nickname as prop_user_nickname, user_iconurl as prop_user_iconurl").Where("deleted = 0").
		Where("user_id in ?", ids)

	err = db.Find(&data).Error

	return
}

// 通过礼物ID 和 用户ID 获取 个人排名
func (m *AppWeekStarProp) GetListByPropIdAndUid(propId, userId int64, user string) (data []*WeekStarPropItem, err error) {
	//db := utils.GEngine.Model(m).Raw(fmt.Sprintf(``))

	return
}
