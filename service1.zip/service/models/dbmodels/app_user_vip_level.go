package dbmodels

import (
	"encoding/json"
	"gamers/utils"
	"github.com/go-redis/redis"
	"gorm.io/gorm"
)

// vip等级
type AppUserVipLevel struct {
	LevelId            int64     `gorm:"column:level_id;primaryKey;autoIncrement" json:"level_id"` // 等级id
	LevelName          string    `gorm:"column:level_name" json:"level_name"`                      // 特权名称，如白金/黑金
	LevelMinExperience int64     `gorm:"column:level_min_experience" json:"level_min_experience"`  // 最小经验值
	LevelLevel         int       `gorm:"column:level_level"`                                       // 特权等级，1暂时1到30
	LevelRemark        string    `gorm:"column:level_remark" json:"level_remark"`                  // 备注
	BaseModel          BaseModel `gorm:"embedded" json:"base_model"`
}

func (AppUserVipLevel) TableName() string {
	return "app_user_vip_level"
}

func (s *AppUserVipLevel) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s AppUserVipLevel) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

const MAX_VIP_LEVEL = 30

// 根据experience获取对应等级
func (m AppUserVipLevel) GetVipLevelByExperience(experience int64) (data AppUserVipLevel, err error) {
	err = utils.GEngine.Model(m).Select("level_min_experience,level_id,level_name,level_level,level_remark").
		Where("level_min_experience > ? and deleted = 0", experience).Order("level_min_experience asc").First(&data).Error
	return
}

// 获取最大等级
func (m AppUserVipLevel) GetMaxVipLevelByExperience() (data AppUserVipLevel, err error) {
	err = utils.RedisClient.Get(utils.REDIS_MAX_VIP_LEVEL).Scan(&data)
	if err != redis.Nil {
		return
	}
	err = utils.GEngine.Model(m).Select("level_min_experience,level_id,level_name,level_level,level_remark").
		Where("deleted = 0").Order("level_level desc").First(&data).Error
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	if err == gorm.ErrRecordNotFound {
		utils.LogErrorF("未查询到vip等级信息")
		return
	}
	err = utils.RedisClient.Set(utils.REDIS_MAX_VIP_LEVEL, data, -1).Err()
	return
}

// 获取最低等级对应的经验值
func (m AppUserVipLevel) GetMinVipLevelByExperience() (data AppUserVipLevel, err error) {
	err = utils.RedisClient.Get(utils.REDIS_MIN_VIP_LEVEL).Scan(&data)
	if err != redis.Nil {
		return
	}
	err = utils.GEngine.Model(m).Select("level_min_experience,level_id,level_name,level_level,level_remark").
		Where("deleted = 0").Order("level_level asc").First(&data).Error
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	if err == gorm.ErrRecordNotFound {
		utils.LogErrorF("未查询到vip等级信息")
		return
	}
	err = utils.RedisClient.Set(utils.REDIS_MIN_VIP_LEVEL, data, -1).Err()
	// 缓存
	return
}
