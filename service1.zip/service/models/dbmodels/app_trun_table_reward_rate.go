/**
 * @Author: panke
 * @Description:
 * @File: app_trun_table_reward_rate
 * @Date: 2021/4/22 14:53
 */

package dbmodels

type AppTurnTableRewardRate struct {
	RateID          uint    `json:"rate_id" gorm:"column:rate_id"`
	RateTurnTableID uint    `json:"rate_turn_table_id" gorm:"column:rate_turn_table_id"` // 转盘id
	RatePropType    uint    `json:"rate_prop_type" gorm:"column:rate_prop_type"`         // 物品类型(0go币,1礼物,2锤子,3头像框,4聊天框,5座驾,6活动道具,7实物道具,8Go币道具)
	RatePropID      uint    `json:"rate_prop_id" gorm:"column:rate_prop_id"`             // 物品ID
	RateRate        int64   `json:"rate_rate" gorm:"column:rate_rate"`                   // 物品被抽到的概率
	RatePosition    int64   `json:"rate_position" gorm:"rate_position"`                  // 在转盘的位置
	AppProp         AppProp `gorm:"foreignKey:PropId;references:RatePropID"`             // 关联礼物
	BaseModel
}

func (m *AppTurnTableRewardRate) TableName() string {
	return "app_turn_table_reward_rate"
}
