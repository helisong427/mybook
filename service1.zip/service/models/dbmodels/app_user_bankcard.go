package dbmodels

import "gamers/utils"

//用户银行卡表
type AppUserBankcard struct {
	BankcardId          int64  `gorm:"column:bankcard_id;primaryKey;autoIncrement"`
	BankcardUserId      int64  `gorm:"column:bankcard_user_id"`      //用户id
	BankcardAccountType int    `gorm:"column:bankcard_account_type"` //账户类型(1支付宝,2微信,3银行卡)
	BankcardAccountInfo string `gorm:"column:bankcard_account_info"` //账号详情{"realname":"真实姓名","card":"卡号","banck":"银行名称","createbanck":"开户行","alipay":"支付宝账号","wechat":"微信账号"}
	BankcardDefault     int64  `gorm:"column:bankcard_default"`      //是否是默认(0不是,1是)
	BaseModel
}

const (
	//账户类型
	BANKCARD_ACCOUNT_TYPE         int = iota
	BANKCARD_ACCOUNT_TYPE_ALIPAY      //支付宝
	BANKCARD_ACCOUNT_TYPE_WECHATA     //微信
	BANKCARD_ACCOUNT_TYPE_CARD        //银行卡
)

//用户银行卡账号详情
type BankcardAccountInfo struct {
	Realname    string `json:"realname"`    //真实姓名
	Mobile      string `json:"mobile"`      //手机号
	Card        string `json:"card"`        //卡号
	Banck       string `json:"banck"`       //银行名称
	Createbanck string `json:"createbanck"` //开户行
	Alipay      string `json:"alipay"`      //支付宝
	Wechat      string `json:"wechat"`      //微信
}

func (AppUserBankcard) TableName() string {
	return "app_user_bankcard"
}

//创建
func (m *AppUserBankcard) Create() (err error) {
	err = utils.GEngine.Create(m).Error
	return
}

//按照类型查询一条
func (m *AppUserBankcard) QueryFirstByType(userId int64, bankcardAccountType int) (row int64, data AppUserBankcard, err error) {
	model := utils.GEngine.Where("bankcard_user_id = ? AND bankcard_account_type = ?", userId, bankcardAccountType).Find(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

//按照id查询一条
func (m *AppUserBankcard) QueryFirstById(bankcardId int64) (row int64, data AppUserBankcard, err error) {
	model := utils.GEngine.Where("bankcard_id = ?", bankcardId).Find(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

//查询全部
func (m *AppUserBankcard) QueryAll(userId int64) (row int64, data []AppUserBankcard, err error) {
	model := utils.GEngine.Where("bankcard_user_id = ?", userId).Find(&data)
	row = model.RowsAffected
	err = model.Error
	return
}

//更新
func (m *AppUserBankcard) Update(bankcardId int64, update map[string]interface{}) (err error) {
	err = utils.GEngine.Model(m).Where("bankcard_id = ?", bankcardId).Updates(update).Error
	return
}
