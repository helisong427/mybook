package dbmodels

import (
	"gamers/utils"
	"sync"
)

//SystemIdBuilder 生成器表
type SystemIdBuilder struct {
	BuilderID    int64     `json:"builder_id" gorm:"column:builder_id;primaryKey;autoIncrement"`
	BuilderKey   string    `json:"builder_key"`          // BuilderKey id的key
	BuilderName  string    `json:"builder_name"`         // BuilderName id的名称
	BuilderMaxid int64     `gorm:"column:builder_maxid"` // BuilderMaxid 当前最大id
	BuilderMinid int64     `gorm:"column:builder_minid"` // BuilderMaxid 当前最大id
	BaseModel    BaseModel `gorm:"embedded" json:"base_model"`
}

//互斥锁
var SystemIdBuilderLock sync.RWMutex

func (SystemIdBuilder) TableName() string {
	return "system_id_builder"
}

//CreatIDBuilder 创建id生成器
func (m *SystemIdBuilder) CreatIDBuilder() (affected int64, err error) {
	model := utils.GEngine.Create(m)
	affected = model.RowsAffected
	err = model.Error
	return
}

// Update id生成器
func (m *SystemIdBuilder) UpdateIDBuilder() (err error) {
	err = utils.GEngine.Updates(m).Error
	return
}

//IDBuilderByKey 根据key获取生成器
func (m *SystemIdBuilder) IDBuilderByKey(key string) (has int64, idBuilder SystemIdBuilder, err error) {
	model := utils.GEngine.Model(m).Where("builder_key = ?", key).First(&idBuilder)
	has = model.RowsAffected
	err = model.Error
	return
}

//UpdateIDBuilderByKey
func (m *SystemIdBuilder) UpdateIDBuilderByKey(key string) (result int64, err error) {
	model := utils.GEngine.Model(m).Where("builder_key = ? ", key).Updates(m)
	result = model.RowsAffected
	err = model.Error
	return
}

func IDBuilderGetId(key string) (id int64) {
	lock, isLock := utils.AcquireLock(key, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
	if !isLock {
		return
	}
	defer utils.ReleaseLock(key, lock)
	userIDStep := int64(10000)
	userMaxId := int64(0)
	userID := int64(0)
	systemIDBuilder := SystemIdBuilder{}
	has, idBuilderInfo, err := systemIDBuilder.IDBuilderByKey(key)
	if err != nil || has <= 0 || idBuilderInfo.BuilderMaxid <= 0 {
		return 0
	}
	if utils.RedisClient.Get(key+"Max").Val() == "" { // redis中没有最大值

		userMaxId = idBuilderInfo.BuilderMaxid + userIDStep
		// 当数据库中min和max不相等时，认为redis非正常挂掉
		if idBuilderInfo.BuilderMaxid != idBuilderInfo.BuilderMinid {
			idBuilderInfo.BuilderMinid = idBuilderInfo.BuilderMaxid
		}
		idBuilderInfo.BuilderMaxid = userMaxId
		pipe := utils.RedisClient.TxPipeline()
		pipe.Set(key+"Max", userMaxId, 0)
		pipe.Set(key, userMaxId-userIDStep, 0)
		_, err = pipe.Exec()
		if err != nil {
			return
		}
		// 更新数据库
		err = idBuilderInfo.UpdateIDBuilder()
		if err != nil {
			return
		}

	} else {
		userMaxId, err = utils.RedisClient.Get(key + "Max").Int64()
		if err != nil {
			return
		}
	}
	if userMaxId <= 0 {
		return 0
	}
	if utils.RedisClient.Get(key).Val() != "" { // redis 中有key
		addId, err := utils.RedisClient.Incr(key).Result()
		if err != nil {
			return 0
		}
		if addId >= userMaxId { // 更新数据库和redis最大值
			tempMaxId := addId + userIDStep
			// 更新数据库
			idBuilderInfo.BuilderMinid = idBuilderInfo.BuilderMaxid
			idBuilderInfo.BuilderMaxid = tempMaxId
			// 更新数据库
			err = idBuilderInfo.UpdateIDBuilder()
			if err != nil {
				return
			}
			//更新redis
			err = utils.RedisClient.Set(key+"Max", tempMaxId, 0).Err()
			if err != nil {
				return
			}
		}
		userID = addId
	} else { // redis中没有key
		userID = userMaxId - userIDStep + 1
		err = utils.RedisClient.Set(key, userID, -1).Err()
		if err != nil {
			return
		}
	}
	return userID
}
