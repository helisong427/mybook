package dbmodels

import "gorm.io/gorm"

// 任务奖励

type AppTaskReward struct {
	RewardID        uint32  `gorm:"column:reward_id;primaryKey;" json:"reward_id"`
	RewardSetID     uint32  `gorm:"column:reward_set_id;" json:"reward_set_id"`         // 任务集合ID
	RewardTaskID    uint32  `gorm:"column:reward_task_id;" json:"reward_task_id"`       // 任务ID
	RewardPropType  uint32  `gorm:"column:reward_prop_type;" json:"reward_prop_type"`   // 任务奖励物品类型
	RewardPropID    uint32  `gorm:"column:reward_prop_id;" json:"reward_prop_id"`       // 任务奖励物品ID
	RewardPropCount uint32  `gorm:"column:reward_prop_count;" json:"reward_prop_count"` // 任务奖励物品数量
	AppProp         AppProp `gorm:"foreignKey:PropId;references:RewardPropID" json:"app_prop"`
	BaseModel
}

func (AppTaskReward) TableName() string {
	return "app_task_reward"
}

func (r *AppTaskReward) Update(db *gorm.DB, rewardID uint32, updates map[string]interface{}) error {
	return db.Model(r).Where("reward_id = ?", rewardID).Updates(updates).Error
}

func (r *AppTaskReward) DeleteByTaskID(db *gorm.DB, taskID uint32) error {
	return db.Model(r).Where("reward_task_id = ?", taskID).Delete(r).Error
}

func (r *AppTaskReward) DeleteByRewardID(db *gorm.DB, rewardID uint32) error {
	return db.Model(r).Where("reward_id = ?", rewardID).Delete(r).Error
}
