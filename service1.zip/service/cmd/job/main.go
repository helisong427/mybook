package main

import (
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"sync"
	"syscall"
	"time"

	"github.com/gin-gonic/gin"

	"gamers/cron"
	"gamers/routers"
	"gamers/utils"
	v2Job "gamers/v2/job"
)

func init() {
	conf := os.Getenv("GIN_CONFIG")
	if conf == "" {
		conf = "debug"
	}

	// 配置文件初始化
	utils.ConfigInit(conf)
	// 初始化日志
	utils.LoggerInit()
	// 建立连接池
	CreatePool()
	// 开启定时任务

}

func webServer(cronSignal chan struct{}) {
	engine := gin.Default()
	router := routers.LivezRouterInit(engine, utils.Config.Job.Name)
	server := &http.Server{
		Addr:         utils.Config.Job.Port,
		Handler:      router,
		ReadTimeout:  time.Duration(utils.Config.App.ReadTimeout) * time.Second,
		WriteTimeout: time.Duration(utils.Config.App.WriteTimeout) * time.Second,
	}
	// 服务连接
	if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		cronSignal <- struct{}{}
		utils.Logger.Panic(fmt.Sprintf(utils.Config.Job.Name+" server listen: %s\n", err))
	}
}

func main() {
	var wg sync.WaitGroup
	cronSignal := make(chan struct{}, 1)
	// 捕获 ctrl + c 和 kill -9，方便注册 ws 的服务进行清理服务
	signalChan := make(chan os.Signal, 1)
	signal.Notify(signalChan, syscall.SIGINT, syscall.SIGTERM)

	wg.Add(1)

	// 关闭 cron 定时任务协程
	go func() {
		v2Job.Main(signalChan, cronSignal)
		cron.NewCron(signalChan, cronSignal)
		utils.LogInfoF("定时任务协程关闭")
		wg.Done()
	}()

	go webServer(cronSignal)

	wg.Wait()
}

// CreatePool 创建连接池
func CreatePool() {
	utils.GDBInit()
	utils.ESInit()
	utils.RedisInit()
	utils.KafkaInitProducer()
	utils.RabbitMQInit()
}
