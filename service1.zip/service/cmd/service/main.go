package main

import (
	"context"
	"errors"
	"fmt"
	"gamers/middleware"
	"gamers/models/dbmodels"
	"gamers/routers"
	"gamers/utils"
	"gamers/utils/pay/warning"
	"gamers/utils/tencent/tencentIm"
	v2 "gamers/v2"

	"log"
	"net/http"
	"os"
	"os/signal"
	"time"

	jsoniter "github.com/json-iterator/go"

	"github.com/gin-contrib/pprof"
	"github.com/gin-gonic/gin"
)

func init() {
	conf := os.Getenv("GIN_CONFIG")
	if conf == "" {
		conf = "debug"
	}
	// 配置文件初始化
	utils.ConfigInit(conf)
	// 初始化日志
	utils.LoggerInit()

	// 建立连接池
	CreatePool()

	// 初始化推送
	InitIm(conf)

	utils.InitSingLefLight()
}

func main() {

	// 初始化
	engine := gin.New()
	// 跨域
	engine.Use(middleware.Cors())
	// 捕获异常
	engine.Use(middleware.Recovery())
	// 注册request日志
	engine.Use(utils.RequestLog())
	// 设置路由
	routers.RouterInit(engine)

	// 性能分析 - 正式环境不要使用！！！
	if gin.Mode() != gin.ReleaseMode {
		pprof.Register(engine)
	}

	// ///////////
	// 重构模块启动
	v2.Main(engine)
	// ///////////

	// 开启支付预警队列协程
	q := warning.Queue()
	go q.Run()

	processed := make(chan struct{}, 1)
	if err := startServer(engine, utils.Config.App.Port, processed); err != nil {
		utils.Logger.Info(fmt.Sprintf("HTTP server listen: %s\n", err))
	}
	<-processed
}

func startServer(engine *gin.Engine, address string, processed chan struct{}) (err error) {
	server := &http.Server{
		Addr:         address,
		Handler:      engine,
		ReadTimeout:  time.Duration(utils.Config.App.ReadTimeout) * time.Second,
		WriteTimeout: time.Duration(utils.Config.App.WriteTimeout) * time.Second,
	}

	go func() {
		// 启动信号量
		c := make(chan os.Signal, 1)
		// 收到ctrl C阻断信号才释放继续执行
		signal.Notify(c, os.Interrupt)
		<-c

		// ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		ctx, cancel := context.WithTimeout(&ShutdownContext{Chan: nil}, 3*time.Second)
		defer cancel()

		if err := server.Shutdown(ctx); err != nil {
			log.Fatalf("server shutdown failed, err: %v\n", err)
		}

		utils.Logger.Info("server gracefully exit")

		close(processed)

	}()

	fmt.Println("|-----------------------------------|")
	fmt.Println("|            frontend-service       |")
	fmt.Println("|-----------------------------------|")
	fmt.Println("|  Go Http Server Start Successful  |")
	fmt.Println("|       Port:" + utils.Config.App.Port + "    Pid:" + fmt.Sprintf("%d", os.Getpid()) + "    |")
	fmt.Println("|-----------------------------------|")

	err = server.ListenAndServe()

	// 这里可以做释放操作，比如关闭数据库, 也可以在之前的代码中加入defer 操作，效果相同
	// close db

	if http.ErrServerClosed != err {
		err = errors.New(fmt.Sprintf("server not gracefully shutdown, err :%v", err))
	}

	return
}

// CreatePool 创建连接池
func CreatePool() {
	utils.GDBInit()
	utils.ESInit()
	utils.KafkaInitProducer()
	utils.RedisInit()
	utils.RabbitMQInit()
}

type InitImInfo struct {
	InteractiveId   string `json:"interactive_id"`
	InteractiveName string `json:"interactive_name"`
	InteractiveIcon string `json:"interactive_icon"`
	AssistantId     string `json:"assistant_id"`
	AssistantName   string `json:"assistant_name"`
	AssistantIcon   string `json:"assistant_icon"`
	OrderId         string `json:"order_id"`
	OrderName       string `json:"order_name"`
	OrderIcon       string `json:"order_icon"`
	Init            int    `json:"init"`
}

// im初始化
func InitIm(conf string) {
	param, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_IM_INIT)
	if err != nil {
		utils.LogErrorF("查询im初始化参数失败，err:%s", err.Error())
		panic(err)
		return
	}
	var form InitImInfo
	err = jsoniter.UnmarshalFromString(param["value"], &form)
	if err != nil {
		utils.LogErrorF("反序列化im初始化参数失败，err:%s", err.Error())
		panic(err)
		return
	}
	if form.Init == 1 {
		return
	}
	update := true
	_, err = tencentIm.PortraitManagerSet(form.OrderId, form.OrderName, form.OrderIcon)
	if err != nil {
		update = false
		utils.LogErrorF("初始化订单消息属性失败，err:%s", err.Error())
	}
	_, err = tencentIm.PortraitManagerSet(form.AssistantId, form.AssistantName, form.AssistantIcon)
	if err != nil {
		update = false
		utils.LogErrorF("初始化助手消息属性失败，err:%s", err.Error())
	}
	_, err = tencentIm.PortraitManagerSet(form.InteractiveId, form.InteractiveName, form.InteractiveIcon)
	if err != nil {
		update = false
		utils.LogErrorF("初始化互动消息属性失败，err:%s", err.Error())
	}
	err = tencentIm.InitAppAttr()
	if err != nil {
		update = false
		utils.LogErrorF("初始化应用属性失败，err:%s", err.Error())
		// 测试环境和正式环境这里需要panic
		if conf == "test" || conf == "release" {
			panic(err)
			return
		}
	}
	if update {
		form.Init = 1
		data, _ := jsoniter.MarshalToString(&form)
		err = new(dbmodels.SystemParam).UpdateValue(dbmodels.PRAM_KEY_IM_INIT, data)
		if err != nil {
			utils.LogErrorF("编辑应用参数失败，err:%s", err.Error())
			panic(err)
		}
	}
	return
}

// 实现 context.Context 接口
// Deadline() (deadline time.Time, ok bool)
// Done() <-chan struct{}
// Err() error
// Value(key interface{}) interface{}
// 让 http 优雅退出(graceful)
type ShutdownContext struct {
	Chan         chan struct{}
	DeadLineTime time.Time
}

func (s *ShutdownContext) Deadline() (deadline time.Time, ok bool) {
	deadline = s.DeadLineTime
	ok = true
	return
}

func (s *ShutdownContext) Done() <-chan struct{} {
	return s.Chan
}

func (s *ShutdownContext) Err() error {
	return nil
}

func (s *ShutdownContext) Value(key interface{}) interface{} {
	return nil
}
