package main

import (
	"fmt"
	"gamers/delay"
	"gamers/utils"
	"net/http"
	"os"
	"time"

	"github.com/gin-gonic/gin"
)

func init() {
	conf := os.Getenv("GIN_CONFIG")
	if conf == "" {
		conf = "debug"
	}

	//配置文件初始化
	utils.ConfigInit(conf)
	//初始化日志
	utils.LoggerInit()
	// 建立连接池
	CreatePool()

	go delay.InitTasks()
	go delay.InitTimers()

}

func main() {
	//初始化
	engine := gin.New()
	//注册request日志
	engine.Use(utils.RequestLog())
	//设置路由
	delay.RouterInit(engine)
	server := &http.Server{
		Addr:         utils.Config.Delay.Port,
		Handler:      engine,
		ReadTimeout:  time.Duration(utils.Config.App.ReadTimeout) * time.Second,
		WriteTimeout: time.Duration(utils.Config.App.WriteTimeout) * time.Second,
	}
	fmt.Println("|-----------------------------------|")
	fmt.Println("|             frontend-delay        |")
	fmt.Println("|-----------------------------------|")
	fmt.Println("|  Go Http Server Start Successful  |")
	fmt.Println("|       Port:" + utils.Config.Delay.Port + "      Pid:" + fmt.Sprintf("%d", os.Getpid()) + "  |")
	fmt.Println("|-----------------------------------|")

	// 服务连接
	if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		utils.Logger.Panic(fmt.Sprintf("HTTP server listen: %s\n", err))
	}

}

// CreatePool 创建连接池
func CreatePool() {
	utils.GDBInit()
	utils.ESInit()
	utils.RedisInit()
	utils.RabbitMQInit()
	utils.KafkaInitProducer()
}
