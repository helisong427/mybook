package routers

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

//探针路由初始化
func LivezRouterInit(engine *gin.Engine, serverName string) *gin.Engine {
	engine.GET("/livez", func(c *gin.Context) {
		c.String(http.StatusOK, serverName+" success!")
	})
	return engine
}
