package enum

const (
	REDIS_WEEK_STAR_NOW_GIFT_LIST      = "week_star_now_gift_list"
	REDIS_WEEK_STAR_LOCK               = "week_star_gift_lock"
	REDIS_WEEK_STAR_WEALTH_LIST        = "week_star_wealth_list:" // 财富榜
	REDIS_WEEK_STAR_WEALTH_PERSON_LIST = "wealth_person:"         // 财富榜
	REDIS_WEEK_STAR_CHARM_LIST         = "week_star_charm_list:"  // 魅力榜
	REDIS_WEEK_STAR_CHARM_PERSON_LIST  = "charm_person:"          // 魅力榜
	REDIS_WEEK_STAR_EXPIRE_TIME        = 5                        // 列表排行过期时间
	REDIS_WEEK_STAR_PERSON_EXPIRE_TIME = 6                        // 个人排行过期时间(暂时未用到)
	REDIS_WEEK_STAR_ZSET_WEALTH_NAME   = "week_star_wealth_zset:" // 有序集 名
	REDIS_WEEK_STAR_ZSET_CHARM_NAME    = "week_star_charm_zset:"  // 有序集 名
	REDIS_WEEK_STAR_RANK_NUM           = 10                       // 排行人数 0开始计数 (考虑到后期会增加)
	GIFT_TYPE                          = 1
	GO_MONEY                           = 2
	GO_MONEY_NAME                      = "GO币"
	REDIS_WEEK_STAR_LOCK_WEALTH_NAME   = "week_star_wealth:"      // 锁的名字
	REDIS_WEEK_STAR_LOCK_CHARM_NAME    = "week_star_charm:"       // 锁的名字
	REDIS_WEEK_STAR_LOCK_TIMEOUT       = 10                       // 自动解锁时间
	REDIS_WEEK_STAR_LOCK_FORCE_TIMEOUT = 10                       // 自动强制解锁时间
	REDIS_WEEK_STAR_HISTORY_LIST       = "week_star_history_list" // 历史榜单
	WEEK_STAR_HANDLE_WEALTH_TYPE       = 1                        // 财富榜 类型
	WEEK_STAR_HANDLE_CHARM_TYPE        = 2                        // 魅力榜 类型
)
