/**
  created by yy on 23/04/2021
*/

package enum

const (
	SPEED_ORDER_TOP_TIME = 60 * 15
)
