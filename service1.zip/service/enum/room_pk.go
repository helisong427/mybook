/**
 * @Author: panke
 * @Description:
 * @File: room_pk
 * @Date: 2021/4/19 11:38
 */

package enum

const (
	RedWin     = 1
	BlueWin    = 2
	DrawResult = 3 // 平局
)

const (
	SystemSettlement = 1 // 系统结算
	ManualSettlement = 2 // 手动结算
)

const (
	RoomPkRecordDoing = 1 // 记录表-pk进行中
	RoomPkRecordEnd   = 2 // 记录表-pk结束
)
