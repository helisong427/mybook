package enum

//用户相关枚举
const (
	//用户设备类型
	USER_CLIENT_TYPE         int = iota
	USER_CLIENT_TYPE_ANDROID     //安卓
	USER_CLIENT_TYPE_IOS         //iOS
	USER_CLIENT_TYPE_H5          //h5
)

const (
	USER_DEFAULT_AGE = 18 //用户默认年龄
)

// 用户im在线状态
const (
	USER_IM_STATUS_ONLINE    = 1
	USER_IM_STATUS_OFFONLINE = 2
)

const (
	IM_USER_ATTR_CLIENT   = "client"   // 客户端类型,1安卓,2ios
	IM_USER_ATTR_ANCHOR   = "anchor"   // 是否是主播 0不是,1是
	IM_USER_ATTR_SPARRING = "sparring" // 是否是大神 0不是,1是
)

const (
	MaterialIsNotReview = iota // 素材未审核
	MaterialReviewed           // 素材已审核
)
