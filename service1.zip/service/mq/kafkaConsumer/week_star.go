package kafkaConsumer

import (
	"encoding/json"
	"fmt"
	"gamers/controller/services"
	"gamers/enum"
	"gamers/models/dbmodels"
	"gamers/utils"
	"github.com/Shopify/sarama"
	"github.com/go-redis/redis"
	"log"
	"os"
	"sort"
	"strconv"
	"strings"
	"time"
)

const (
	WEEK_STAR_SEND_TO_FIRST      = 1
	WEEK_STAR_SEND_TO_OTHERS     = 2
	WEEK_STAR_SEND_TO_FIRST_KEY  = "week_star_given_gift_first"
	WEEK_STAR_SEND_TO_OTHERS_KEY = "week_star_given_gift_others"
)

type GiftDataStruct struct {
	Type      int64  `json:"type"`       // 类型
	Name      string `json:"name"`       // 礼物名 或 其他名
	PropImage string `json:"prop_image"` // 图片url
	Count     int64  `json:"count"`      // 数量
	Id        int64  `json:"id"`         // 礼物ID
}

type WeekStarResultItemImage struct {
	Level     int64            `json:"level"`      // 排名
	Type      int64            `json:"type"`       // 类型
	Name      string           `json:"name"`       // 礼物名 或 其他名
	PropImage string           `json:"prop_image"` // 图片url
	Count     int64            `json:"count"`      // 数量
	GiftData  []GiftDataStruct `json:"gift_data"`  // 礼物列表
}

type AppWeekStarResultItem struct {
	WeekStarId             int64                      `json:"week_star_id"`
	WeekStarStatus         int64                      `json:"week_star_status"`           // 周星榜状态(0关闭, 1开启)
	WeekStarBackground     string                     `json:"week_star_background"`       // 活动背景图
	WeekStarWealthGift     string                     `json:"week_star_wealth_gift"`      // 财富榜奖励(json形式)
	WeekStarCharmGift      string                     `json:"week_star_charm_gift"`       // 魅力榜奖励(json形式)
	WeekStarGift           string                     `json:"week_star_gift"`             // 周星榜礼物列表
	WeekStarStartTime      int64                      `json:"week_star_start_time"`       // 活动开始时间
	WeekStarEndTime        int64                      `json:"week_star_end_time"`         // 活动结束时间
	Created                int64                      `json:"created"`                    // create time
	Edited                 int64                      `json:"edited"`                     // edit time
	Deleted                int64                      `json:"deleted"`                    // delete time
	WeekStarTaskId         int64                      `json:"week_star_task_id"`          // 延时任务ID
	WeekStarWealthGiftList []*WeekStarResultItemImage `json:"week_star_wealth_gift_list"` // 财富榜奖励图片数组
	WeekStarCharmGiftList  []*WeekStarResultItemImage `json:"week_star_charm_gift_list"`  // 魅力榜奖励图片数组
	WeekStarGiftList       []*WeekStarResultItemImage `json:"week_star_gift_list"`        // 活动礼物图片
}

// 处理 周星榜 结算
func ConsumeWeekStarSettle(message *sarama.ConsumerMessage) {
	var (
		weekStar AppWeekStarResultItem
		taskLog  dbmodels.SystemTaskLog
		err      error
		giftList []int64
	)

	// 首先解析数据
	if err = json.Unmarshal(message.Value, &taskLog); err != nil {
		utils.LogErrorF("反序列化收到的原始消息[%s][%s]失败, %s", message.Topic, message.Key, err.Error())
		return
	}

	if taskLog.LogTaskInfo == "" {
		utils.Logger.Error("receive nil task info =================> week star error")
	}

	if err = json.Unmarshal([]byte(taskLog.LogTaskInfo), &weekStar); err != nil {
		utils.LogErrorF("反序列化收到的原始消息[%s][%s]失败, %s", message.Topic, message.Key, err.Error())
		return
	}

	if weekStar.WeekStarId > 0 {
		// 这里要判断 是否需要结算, 如果手动关闭了活动, 则 不结算
		weekStarModel, _ := new(dbmodels.AppWeekStar).QueryById(weekStar.WeekStarId)
		if weekStarModel.WeekStarId > 0 {
			if weekStarModel.WeekStarStatus == 0 {
				utils.Logger.Error("活动已被关闭, 不进行结算")
				return
			}
		}
	}

	// 格式化奖励列表
	// 财富榜
	weekStar.WeekStarWealthGiftList = handleImage(weekStar.WeekStarWealthGift)

	// 魅力榜
	weekStar.WeekStarCharmGiftList = handleImage(weekStar.WeekStarCharmGift)

	// 礼物列表
	giftList = handleGiftList(weekStar.WeekStarGift)

	// 发放操作
	for _, v := range giftList {
		giveGiftHandle(enum.WEEK_STAR_HANDLE_WEALTH_TYPE, enum.REDIS_WEEK_STAR_ZSET_WEALTH_NAME+fmt.Sprintf("%v", v), weekStar.WeekStarWealthGiftList, weekStar, v)
		giveGiftHandle(enum.WEEK_STAR_HANDLE_CHARM_TYPE, enum.REDIS_WEEK_STAR_ZSET_CHARM_NAME+fmt.Sprintf("%v", v), weekStar.WeekStarCharmGiftList, weekStar, v)
	}

	// 删除当前礼物列表
	if err = utils.RedisClient.Del(enum.REDIS_WEEK_STAR_NOW_GIFT_LIST).Err(); err != nil {
		utils.Logger.Error("delete_now_gift_list: " + err.Error())
		err = nil
	}

	// 修改周星榜 状态(改为关闭状态)
	if err = utils.GEngine.Model(&dbmodels.AppWeekStar{}).Where("week_star_id = ?", weekStar.WeekStarId).Update("week_star_status", 0).Error; err != nil {
		utils.Logger.Error(err.Error())
		err = nil
	}

	if err = utils.RedisClient.Del(enum.REDIS_WEEK_STAR_HISTORY_LIST).Err(); err != nil {
		utils.Logger.Error("delete history_week_star_rank_list_error: " + err.Error())
	}
}

func giveGiftHandle(handleType int64, zsetKey string, giftList []*WeekStarResultItemImage, weekStar AppWeekStarResultItem, propId int64) {
	var (
		err          error
		userRankList []redis.Z
		sendMsg      string
		key          string
		msgModel     dbmodels.AppMsgModel
	)

	nowTime := time.Now().Unix()

	// 获取当前用户
	if userRankList, err = utils.RedisClient.ZRevRangeByScoreWithScores(zsetKey, redis.ZRangeBy{
		Min:    "-inf",
		Max:    "+inf",
		Offset: 0,
		Count:  enum.REDIS_WEEK_STAR_RANK_NUM,
	}).Result(); err != nil {
		utils.Logger.Error(err.Error())
		return
	}

	for k, v := range userRankList {
		uid, uidErr := strconv.ParseInt(v.Member.(string), 10, 64)

		if uidErr != nil {
			utils.Logger.Error(uidErr.Error())
			continue
		}

		// 历史数据入库
		appWeekStarList := &dbmodels.AppWeekStarList{
			WeekStarListUserId: uid,
			WeekStarListType:   handleType,
			WeekStarListWeight: int64(k) + 1,
			WeekStarId:         weekStar.WeekStarId,
			WeekStarPropCount:  int64(v.Score),
			WeekStarPropId:     propId,
		}

		if err = appWeekStarList.Create(); err != nil {
			utils.Logger.Error("week_star_history_data_save_error: " + err.Error())
			continue
		}

		// 只给前三名送礼物
		if k > 2 {
			continue
		}

		if handleType == WEEK_STAR_SEND_TO_FIRST {
			key = WEEK_STAR_SEND_TO_FIRST_KEY
		} else {
			key = WEEK_STAR_SEND_TO_OTHERS_KEY
		}

		if msgModel, err = new(dbmodels.AppMsgModel).GetMsgByKey(key); err != nil {
			utils.LogErrorF("获取周星榜礼物赠送消息model失败,err:%s", err.Error())
			return
		}

		if handleType == 1 {
			sendMsg = strings.NewReplacer("${rankname}", "贡献榜").Replace(msgModel.MsgContent)
		} else {
			sendMsg = strings.NewReplacer("${rankname}", "魅力榜").Replace(msgModel.MsgContent)
		}

		sendMsg = strings.Replace(sendMsg, "${rank}", fmt.Sprintf("%v", k+1), -1)

		// 第一名
		if k == 0 {
			sendMsg = sendMsg + fmt.Sprintf("\n1、上期荣誉榜展示7天")
		}

		for k2, v2 := range giftList[k].GiftData {
			if v2.Type == enum.GIFT_TYPE {
				// 如果是礼物, 则 根据ID 赠送
				// 首先获取 道具的 类型以及属性ID
				_, prop, tmpErr := new(dbmodels.AppProp).QueryById(uint64(v2.Id))
				if tmpErr != nil {
					utils.Logger.Error(tmpErr.Error())
					continue
				}

				expireTime := prop.PropExpiredTime

				if expireTime > 0 {
					expireTime = expireTime*60*60*24 + nowTime
				}

				backPack := &dbmodels.AppBackpack{
					BackpackUserId:      uid,
					BackpackPropType:    prop.PropType,
					BackpackPropId:      prop.PropId,
					BackpackCount:       v2.Count,
					BackpackPropAttrId:  prop.PropAttrId,
					BackpackExpiredTime: expireTime,
				}

				if err = backPack.CreateWeekStar(); err != nil {
					utils.Logger.Error(err.Error())
					err = nil
				}

				// 计算 礼物过期 天数
				giftExpireDate := getExpireDateNum(prop.PropExpiredTime)

				// 发送消息给用户
				if k == 0 {
					// 第一名
					sendMsg = sendMsg + fmt.Sprintf("\n%v、%v（%v）", k2+2, v2.Name, giftExpireDate)
				} else {
					sendMsg = sendMsg + fmt.Sprintf("\n%v、%v（%v）", k2+1, v2.Name, giftExpireDate)
				}
			}
		}

		if err = services.InitWeekStarSendMsg().SendGivenGiftMsg(uid, handleType, sendMsg, msgModel); err != nil {
			utils.Logger.Error("send_gogo_msg_week_star_error: " + err.Error())
			err = nil
		}
		// TODO 之后可能要发GO币, 此处预留
	}

	// 删除redis 排行数据
	if err = utils.RedisClient.Del(zsetKey).Err(); err != nil {
		utils.Logger.Error("delete_week_star_gift_rank_list:" + err.Error())
	}
}

func getExpireDateNum(timeStamp int64) (dateNum string) {
	if timeStamp > 0 {
		dateNum = fmt.Sprintf("%v天", timeStamp)
	} else {
		dateNum = "永久"
	}

	return
}

func handleGiftList(weekStarListStr string) (list []int64) {
	var (
		err error
	)

	if err = json.Unmarshal([]byte(weekStarListStr), &list); err != nil {
		utils.Logger.Error(err.Error())
	}

	return
}

type giftDataStruct struct {
	Id    int64 `json:"id"`
	Count int64 `json:"count"`
	Type  int64 `json:"type"`
}

type giftStruct struct {
	GiftType int64 `json:"giftType"`
	Gift     []giftDataStruct
	Level    int64 `json:"level"`
}

type sortGift struct {
	data []giftStruct
}

func (sort *sortGift) Len() int {
	return len(sort.data)
}

func (sort *sortGift) Less(i, j int) bool {
	return sort.data[i].Level < sort.data[j].Level
}

func (sort *sortGift) Swap(i, j int) {
	handleSwap(&sort.data[i], &sort.data[j])
}

func handleSwap(a *giftStruct, b *giftStruct) {
	*a, *b = *b, *a
}

func handleImage(data string) (result []*WeekStarResultItemImage) {
	var (
		list []giftStruct
		err  error
	)

	if err = json.Unmarshal([]byte(data), &list); err != nil {
		return
	}

	// 根据等级排序
	sortData := &sortGift{data: list}

	sort.Sort(sortData)

	for _, v := range list {

		tmpData := &WeekStarResultItemImage{
			Level: v.Level,
		}

		var giftData []GiftDataStruct

		for _, v2 := range v.Gift {

			tmpGift := GiftDataStruct{}
			tmpGift.Type = v2.Type
			tmpGift.Count = v2.Count

			if v2.Type == enum.GIFT_TYPE {
				_, prop, _ := new(dbmodels.AppProp).QueryById(uint64(v2.Id))
				tmpGift.Name = prop.PropName
				tmpGift.PropImage = prop.PropIcon
				tmpGift.Id = v2.Id
			}

			if v2.Type == enum.GO_MONEY {
				tmpData.Name = enum.GO_MONEY_NAME
			}

			giftData = append(giftData, tmpGift)
		}

		tmpData.GiftData = giftData

		result = append(result, tmpData)
	}

	return
}

func WriteToFile(fileName, msg string) {
	f, err := os.OpenFile(fileName, os.O_WRONLY|os.O_CREATE|os.O_APPEND, 0666)

	defer func() {
		if err := f.Close(); err != nil {
			log.Fatalln(err)
		}
	}()

	if err != nil {
		log.Println(err.Error())
	}

	_, err = f.Write([]byte(msg))

	if err != nil {
		log.Println(err.Error())
	}
}
