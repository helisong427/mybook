package kafkaConsumer

import (
	"encoding/json"
	"fmt"
	"gamers/controller/services"
	"gamers/models/dbmodels"
	"gamers/utils"
	"gamers/utils/pay"
	"github.com/Shopify/sarama"
	"gorm.io/gorm"
	"strconv"
)

// 支付回调
func PayCallback(message *sarama.ConsumerMessage) {
	fmt.Println(fmt.Sprintf("Received:topic[%s]|partition[%d]|offset[%d]|key[%s]", message.Topic, message.Partition, message.Offset, message.Key))
	var totalAmount int64     // 订单金额
	var transactionStatus int // 交易状态
	payCallback := pay.PayCallback{}
	err := json.Unmarshal(message.Value, &payCallback)
	if err != nil {
		utils.LogErrorF("[支付回调]解析支付回调消息失败:%s", err.Error())
		return
	} else {
		data, _ := json.Marshal(payCallback)
		utils.LogInfoF("[支付回调]解析支付回调消息成功:%s", data)
	}
	// 查询订单
	first, data, err := new(dbmodels.AppTransaction).QueryUnfinishedFirst(payCallback.OutTradeNo, payCallback.PayType)
	if err != nil && err != gorm.ErrRecordNotFound {
		utils.LogErrorF("[支付回调]查询订单失败:[%s],[%s]", payCallback.OutTradeNo, err.Error())
		return
	}
	if first == 0 {
		utils.LogErrorF("[支付回调]未查询到未完成订单:[%s]", payCallback.OutTradeNo)
		return
	}
	// TODO 开发完成后加强校验
	//if data.TransactionChannelId !=payCallback.ChannelId {
	//	utils.LogErrorF("[支付回调]回调渠道和创建渠道一一致:[%s]", payCallback)
	//	return
	//}

	// 微信支付
	if payCallback.PayType == dbmodels.DB_ACCOUNT_TYPE_WEHCHAT {
		atoi, err := strconv.Atoi(payCallback.TotalAmount)
		if err != nil {
			utils.LogErrorF("[支付回调]转换订单金额失败:[%s],[%s]", payCallback.OutTradeNo, err.Error())
			return
		}
		totalAmount = int64(atoi)
		if payCallback.TradeStatus == pay.WECHAT_PAY_TRADE_STATUS_SUCCESS {
			transactionStatus = dbmodels.DB_TRANSACTION_COMPLETE
		} else if payCallback.TradeStatus == pay.WECHAT_PAY_TRADE_STATUS_FAIL {
			transactionStatus = dbmodels.DB_TRANSACTION_FAIL
		} else {
			// 不处理
			utils.LogErrorF("[支付回调]订单非预期状态，不处理:[%s],[%d],[%s],", payCallback.OutTradeNo, payCallback.PayType, payCallback.TradeStatus)
			return
		}
	} else { //支付宝
		float, err := strconv.ParseFloat(payCallback.TotalAmount, 64)
		if err != nil {
			utils.LogErrorF("[支付回调]转换订单金额失败:[%s],[%s]", payCallback.OutTradeNo, err.Error())
			return
		}
		// 支付宝单价为元,转换为分
		totalAmount = int64(float * 100)
		if payCallback.TradeStatus == pay.ALIPAY_PAY_TRADE_STATUS_SUCCESS || payCallback.TradeStatus == pay.ALIPAY_PAY_TRADE_STATUS_FINISHED {
			transactionStatus = dbmodels.DB_TRANSACTION_COMPLETE
		} else if payCallback.TradeStatus == pay.ALIPAY_PAY_TRADE_STATUS_CLOSE {
			transactionStatus = dbmodels.DB_TRANSACTION_FAIL
		} else {
			// 不处理
			utils.LogErrorF("[支付回调]订单非预期状态，不处理:[%s],[%d],[%s],", payCallback.OutTradeNo, payCallback.PayType, payCallback.TradeStatus)
			return
		}
	}

	// 校验金额
	if data.TransactionCash != totalAmount {
		utils.LogErrorF("[支付回调]订单金额不一致:[%s],[收到的金额:%d],[数据库金额:%d]", payCallback.OutTradeNo, totalAmount, data.TransactionCash)
		return
	}
	// 处理支付结果
	_, err = services.PayCallbackHandler(&data, transactionStatus, payCallback.ThirdNo)
	if err != nil {
		fmt.Println(err)
	}
	return
}
