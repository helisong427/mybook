package kafkaConsumer

import (
	"encoding/json"
	"fmt"
	"gamers/controller/services"
	"gamers/enum"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"strconv"
	"time"

	"github.com/Shopify/sarama"
	jsoniter "github.com/json-iterator/go"
)

type RoomPkSettleMq struct {
	RoomPkRecordId int64 `json:"room_pk_record_id"` // 记录id
	Forbidden      bool  `json:"forbidden"`         // 是否为后台封禁整改结算
}

func RoomPkConsumer(message *sarama.ConsumerMessage) {
	fmt.Println("开始处理房间pk系统结算消费者")
	utils.LogInfoF("Received:topic[%s]|partition[%d]|offset[%d]|key[%s]", message.Topic, message.Partition, message.Offset, message.Key)
	var task dbmodels.SystemTaskLog
	var form RoomPkSettleMq
	err := jsoniter.Unmarshal(message.Value, &task)
	if err == nil && task.LogId != 0 {
		err = jsoniter.UnmarshalFromString(task.LogTaskInfo, &form)
		if err != nil {
			utils.LogErrorF("反序列化收到的原始消息[%s][%s]失败, %s", message.Topic, message.Key, err.Error())
			return
		}
	} else {
		err = jsoniter.Unmarshal(message.Value, &form)
		if err != nil {
			utils.LogErrorF("反序列化收到的原始消息[%s][%s]失败, %s,%s", message.Topic, message.Key, err.Error(), string(message.Value))
			return
		}
	}
	// 对结算加锁，防止错误结算
	key := fmt.Sprintf("%s:%d", utils.RedisRoomPkDetail, form.RoomPkRecordId)
	lock, isLock := utils.AcquireLock(key, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
	if !isLock {
		utils.LogErrorF("结算pk记录[%d]加锁失败", form.RoomPkRecordId)
		return
	}
	// 释放锁
	defer utils.ReleaseLock(key, lock)
	if form.Forbidden {
		ForbiddenSettle(form.RoomPkRecordId)
		return
	}
	NormalSettle(form.RoomPkRecordId)
	if task.LogId != 0 {
		err = task.UpdateTaskStatus(task.LogId, dbmodels.TASK_FINISHED_STATUS_OK)
		if err != nil {
			utils.LogErrorF("修改task[%d]状态失败, %s", task.LogId, err.Error())
			return
		}
	}
	return
}

// 正常结算
func Settle(record *dbmodels.AppRoomPkRecord, room *redismodels.LiveInfo) (data redismodels.Wheat) {
	// 如果未结算，则结算
	var (
		redMaxId    int64     // 红方爱意值最大的用户id
		blueMaxId   int64     // 蓝方爱意值最大的用户id
		redMaxLove  int64 = 0 // 红方最大爱意值
		blueMaxLove int64 = 0 // 蓝方最大爱意值
		maxId       int64     // 魅力王id
		mvpId       int64     // mvp
		svpId       int64     // svp
		redMaxKey   int       // 红方最大值key
		blueMaxKey  int       // 蓝方最大值key
		err         error
	)

	data, err = new(redismodels.Wheat).QueryWheatDetail(int(record.RoomID))
	if err != nil {
		utils.LogErrorF("获取房间[%d]的麦位详情失败，err:%s", record.RoomID, err.Error())
		return
	}

	// 获取pk 详情
	all, _ := utils.RedisClient.HGetAll(fmt.Sprintf("%s%d", utils.RedisRoomPkDetail, record.RoomID)).Result()
	red, _ := strconv.Atoi(all[redismodels.ROOM_PK_DETAIL_RED])
	blue, _ := strconv.Atoi(all[redismodels.ROOM_PK_DETAIL_BLUE])

	// 根据红蓝两队pk值 判断结果
	var result int
	if red > blue {
		result = enum.RedWin
	} else if red < blue {
		result = enum.BlueWin
	} else if red == blue {
		result = enum.DrawResult
	}
	pkWheatInfo := make([]redismodels.WheatPkObj, 0)
	for _, j := range data.WheatObj {
		info := redismodels.WheatPkObj{
			Role:              j.Role,
			UserId:            j.UserId,
			UserNickName:      j.UserNickName,
			UserIconurl:       j.UserIconurl,
			UserGender:        j.UserGender,
			UserAvatarDressUp: j.UserAvatarDressUp,
			Status:            j.Status,
			LoveValue:         j.LoveValue,
			Position:          j.Position,
			UpdateTime:        j.UpdateTime,
			IsMvp:             0,
			IsSvp:             0,
			IsCharm:           0,
		}
		pkWheatInfo = append(pkWheatInfo, info)
	}
	// 计算svp和mvp
	for k, v := range pkWheatInfo {
		if v.Position > 0 && v.Position < 5 {
			if int64(v.LoveValue) > redMaxLove {
				redMaxId = int64(v.UserId)
				redMaxLove = int64(v.LoveValue)
				redMaxKey = k
			}
		}
		if v.Position > 4 && v.Position < 9 {
			if int64(v.LoveValue) > blueMaxLove {
				blueMaxId = int64(v.UserId)
				blueMaxLove = int64(v.LoveValue)
				blueMaxKey = k
			}
		}
	}
	// 判断svp,mvp
	if result == enum.RedWin {
		pkWheatInfo[redMaxKey].IsMvp = 1
		pkWheatInfo[blueMaxKey].IsSvp = 1
		mvpId = redMaxId
		svpId = blueMaxId
	} else if result == enum.BlueWin {
		pkWheatInfo[blueMaxKey].IsMvp = 1
		pkWheatInfo[redMaxKey].IsSvp = 1
		mvpId = blueMaxId
		svpId = redMaxId
	}
	// 判断魅力王
	if redMaxLove >= blueMaxLove {
		pkWheatInfo[redMaxKey].IsCharm = 1
		maxId = redMaxId
	} else {
		pkWheatInfo[redMaxKey].IsCharm = 1
		maxId = blueMaxId
	}

	// 更新mvp，svp，魅力王
	room.RoomPKCharmKingId = maxId
	roomIdStr := strconv.Itoa(int(room.RoomId))
	detailMap := make(map[string]interface{})
	detailMap[redismodels.ROOM_PK_MVP_ID] = mvpId
	detailMap[redismodels.ROOM_PK_SVP_ID] = svpId
	detailMap[redismodels.ROOM_PK_CHARM_KING_ID] = maxId
	err = utils.RedisClient.HMSet(utils.RedisRoomPkDetail+roomIdStr, detailMap).Err()
	if err != nil {
		utils.LogErrorF("更新mvp，svp,魅力王失败:[%s]", err.Error())
		return
	}
	var starInfo redismodels.MsgUserObj
	maxScore := utils.RedisClient.ZRangeWithScores(utils.RedisRoomPkGloryStar+roomIdStr, -1, -1).Val()
	if len(maxScore) > 0 && maxScore[0].Score >= redismodels.MIN_GLORY_SCORE_VALUE {
		starIdStr := maxScore[0].Member.(string)
		starId, err := strconv.ParseInt(starIdStr, 10, 64)
		if err != nil {
			utils.LogErrorF("获取闪耀之星[%s]失败,err:%s", starIdStr, err.Error())
			return
		}
		starInfo, err = new(redismodels.MsgUserObj).GetMsgUserInfo(starId, map[string]bool{})
		if err != nil {
			utils.LogErrorF("获取闪耀之星[%s]失败,err:%s", starIdStr, err.Error())
			return
		}
	}

	detail := redismodels.WheatPk{
		WheatSwitch:        data.WheatSwitch,
		WheatLoveSwitch:    data.WheatLoveSwitch,
		WheatLen:           data.WheatLen,
		WheatObj:           pkWheatInfo,
		RoomPkRecordResult: result,
		RoomPkRecordRed:    int64(red),
		RoomPKRecordBlue:   int64(blue),
		RoomPKRecordPunish: record.RoomPkRecordPunish,
		RoomGloryStar:      starInfo,
	}
	detailMarshal, _ := json.Marshal(detail)

	// 开启事务更新
	tx := utils.GEngine.Begin()

	nowTime := time.Now().Unix()
	updates := make(map[string]interface{})
	updates["room_pk_record_end"] = nowTime
	updates["room_pk_record_settle"] = enum.SystemSettlement
	updates["room_pk_record_status"] = enum.RoomPkRecordEnd
	updates["room_pk_record_result"] = result
	updates["room_pk_record_red"] = red
	updates["room_pk_record_blue"] = blue
	updates["room_pk_record_charm_user_id"] = maxId
	updates["room_pk_record_detail"] = detailMarshal
	if result == enum.RedWin {
		updates["room_pk_record_mvp_user_id"] = redMaxId
		updates["room_pk_record_svp_user_id"] = blueMaxId
	}
	if result == enum.BlueWin {
		updates["room_pk_record_svp_user_id"] = redMaxId
		updates["room_pk_record_mvp_user_id"] = blueMaxId
	}

	err = new(dbmodels.AppRoomPkRecord).Updates(tx, record.RoomPkRecordID, updates)
	if err != nil {
		tx.Rollback()
		return
	}
	if err = tx.Commit().Error; err != nil {
		utils.LogErrorF("房间pk结束失败:[%s]", err.Error())
		tx.Rollback()
		return
	}
	room.RoomPKDetailRed = int64(red)
	room.RoomPKDetailBlue = int64(blue)
	return
}

// 正常结算
func NormalSettle(RecordId int64) {
	record, err := new(dbmodels.AppRoomPkRecord).Query(RecordId)
	if err != nil {
		utils.LogErrorF("获取pk记录失败[%d], %s", RecordId, err.Error())
		return
	}
	room, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(record.RoomID))
	if err != nil {
		utils.LogErrorF("获取房间信息失败[%d], %s", record.RoomID, err.Error())
		return
	}
	if record.RoomPkRecordStatus == enum.RoomPkRecordEnd {
		utils.LogInfoF("pk记录[%d]，已结算,不再系统结算", record.RoomPkRecordID)
		return
	}
	info := services.GetLiveInfo(room, dbmodels.RoomPkPunishmentStage)
	// 正常结算
	data := Settle(&record, &info)
	// 进入惩罚阶段
	err = new(dbmodels.AppLiveRoom).Update(int(room.RoomId), map[string]interface{}{"room_pk_state": fmt.Sprintf("%d", dbmodels.RoomPkPunishmentStage)})
	if err != nil {
		utils.LogErrorF("更新房间状态失败:[%s]", err.Error())
	}
	// 冻结爱意值
	_, err = new(redismodels.Wheat).SwitchWheatLove(int(room.RoomId), 1, redismodels.WHEAT_LOVE_SWITCH_FREEZE, false)
	if err != nil {
		utils.LogErrorF("pk房间冻结爱意值失败:[%s]", err.Error())
	}
	data.WheatLoveSwitch = redismodels.WHEAT_LOVE_SWITCH_FREEZE
	go new(services.LiveMsg).AnnouncePkFinished(&data, &info, true)
	go new(services.PkMsg).SendPkResult(RecordId, &data)
}

// 封禁结算
func ForbiddenSettle(RecordId int64) {
	utils.LogInfoF("开始处理封禁pk：%d", RecordId)
	record, err := new(dbmodels.AppRoomPkRecord).Query(RecordId)
	if err != nil {
		utils.LogErrorF("获取pk记录失败[%d], %s", RecordId, err.Error())
		return
	}
	room, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(record.RoomID))
	if err != nil {
		utils.LogErrorF("获取房间信息失败[%d], %s", record.RoomID, err.Error())
		return
	}
	// 如果已经手动结算，则只需要更改房间pk状态
	if record.RoomPkRecordStatus == 2 && record.RoomPkRecordSettle == enum.ManualSettlement {
		if room.RoomPkState == 0 {
			return
		}
		err = new(dbmodels.AppLiveRoom).Update(int(room.RoomId), map[string]interface{}{"room_pk_state": fmt.Sprintf("%d", dbmodels.RoomPkCloseStage)})
		if err != nil {
			utils.LogErrorF("更新房间状态失败:[%s]", err.Error())
		}
		// 冻结爱意值
		_, err = new(redismodels.Wheat).SwitchWheatLove(int(room.RoomId), 1, redismodels.WHEAT_LOVE_SWITCH_OFF, false)
		if err != nil {
			utils.LogErrorF("pk房间冻结爱意值失败:[%s]", err.Error())
		}
		return
	}
	info := services.GetLiveInfo(room, dbmodels.RoomPkPunishmentStage)
	// 如果已经系统结算，需要移除闪耀之星等
	if record.RoomPkRecordStatus == 1 {
		Settle(&record, &info)
	}

	// 删除房间荣耀之星
	err = utils.RedisClient.Del(fmt.Sprintf("%s%d", utils.RedisRoomPkGloryStar, record.RoomID)).Err()
	if err != nil {
		utils.LogErrorF("pk房间删除房间荣耀之星失败:%s", err.Error())
	}
	// 删除房间pk详情
	err = utils.RedisClient.Del(fmt.Sprintf("%s%d", utils.RedisRoomPkDetail, record.RoomID)).Err()
	if err != nil {
		utils.LogErrorF("pk房间删除房间详情失败: %s", err.Error())
	}
	// 关闭房间pk
	err = new(dbmodels.AppLiveRoom).Update(int(room.RoomId), map[string]interface{}{"room_pk_state": fmt.Sprintf("%d", dbmodels.RoomPkCloseStage)})
	if err != nil {
		utils.LogErrorF("更新房间状态失败:[%s]", err.Error())
	}
	// 冻结爱意值
	_, err = new(redismodels.Wheat).SwitchWheatLove(int(room.RoomId), 1, redismodels.WHEAT_LOVE_SWITCH_OFF, false)
	if err != nil {
		utils.LogErrorF("pk房间冻结爱意值失败:[%s]", err.Error())
	}
	return
}
