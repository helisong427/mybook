package kafkaConsumer

import (
	"fmt"
	"gamers/enum"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"gamers/utils/tencent/tencentIm"
	"strings"
	"sync"
	"time"

	"github.com/Shopify/sarama"
	jsoniter "github.com/json-iterator/go"
)

const (
	MSG_PUSH_MEMBER_TYPE_ALL   = iota // 所有人
	MSG_PUSH_MEMBER_TYPE_USERS        // 按用户推送
	MSG_PUSH_MEMBER_TYPE_ATTR         // 按属性推送
)

//
func MsgPush(message *sarama.ConsumerMessage) {
	fmt.Println(fmt.Sprintf("Received:topic[%s]|partition[%d]|offset[%d]|key[%s]", message.Topic, message.Partition, message.Offset, message.Key))
	var err error
	var form dbmodels.SystemTaskLog
	err = jsoniter.Unmarshal(message.Value, &form)
	if err != nil {
		utils.LogErrorF("反序列化收到的原始消息[%s][%s]失败, %s", message.Topic, message.Key, err.Error())
		return
	}
	var task dbmodels.AppSystemMessage
	err = jsoniter.UnmarshalFromString(form.LogTaskInfo, &task)
	if err != nil {
		fmt.Println("反序列化推送消息失败", err.Error())
		return
	}
	switch task.MessageType {
	case dbmodels.MSG_PUSH_TYPE_KEFU:
		status, err := PushMsgKeFu(&task)
		if err != nil {
			utils.LogErrorF("更新推送任务id[%d]失败, %s", form.LogId, err.Error())
			return
		}
		err = form.UpdateTaskStatus(form.LogId, status)
	case dbmodels.MSG_PUSH_TYPE_SYS:
		status, err := PushMsgSys(&task)
		if err != nil {
			utils.LogErrorF("更新推送任务id[%d]失败, %s", form.LogId, err.Error())
			return
		}
		err = form.UpdateTaskStatus(form.LogId, status)
	default:
		utils.LogErrorF("解析到未知类型消息,id:%d", form.LogId)
	}
	return
}

// 系统推送
func PushMsgSys(form *dbmodels.AppSystemMessage) (status int, err error) {
	switch form.MessageToUserType {
	case MSG_PUSH_MEMBER_TYPE_ALL:
		status = dbmodels.MESSAGE_FINISHED_STATUS_OK
		taskId, err := PushMsgAllAction(form)
		if err != nil {
			utils.LogErrorF("推送全局消息失败,err:%s", err.Error())
			status = dbmodels.MESSAGE_FINISHED_STATUS_FAIL
		}
		err = form.UpdateStatusAndReturnIdById(form.MessageId, status, taskId)
		return status, err
	case MSG_PUSH_MEMBER_TYPE_ATTR:
		taskId, status, err := PushMsgByAttr(form)
		if err != nil {
			utils.LogErrorF("按属性推送消息失败,err:%s", err.Error())
		}
		err = form.UpdateStatusAndReturnIdById(form.MessageId, status, taskId)
		return status, err
	case MSG_PUSH_MEMBER_TYPE_USERS:
		status, err := PushMsgKeFu(form)
		if err != nil {
			utils.LogErrorF("更新推送任务失败, %s", err.Error())
			return status, err
		}
		err = form.UpdateStatusAndReturnIdById(form.MessageId, status, "")
		return status, err
	default:
		utils.LogErrorF("解析到未知类型消息,id:%d", form.MessageId)
	}
	return
}

// 按属性推送
func PushMsgByAttr(form *dbmodels.AppSystemMessage) (taskId string, status int, err error) {
	var more bool
	attrs := make(map[string]string)
	attr2 := make(map[string]string)
	condition := tencentIm.ConditionOrItem{}
	condition2 := tencentIm.ConditionOrItem{}
	switch form.MessageToUserPlatform {
	case enum.USER_CLIENT_TYPE_ANDROID:
		attrs[enum.IM_USER_ATTR_CLIENT] = "1"
		attr2[enum.IM_USER_ATTR_CLIENT] = "1"
	case enum.USER_CLIENT_TYPE_IOS:
		attrs[enum.IM_USER_ATTR_CLIENT] = "2"
		attr2[enum.IM_USER_ATTR_CLIENT] = "2"
	default:
	}
	switch form.MessageToUserIdentity {
	case dbmodels.MESSAGE_PUSH_USER_IDENTITY_ALL:
	case dbmodels.MESSAGE_PUSH_USER_IDENTITY_ANCHOR:
		attrs[enum.IM_USER_ATTR_ANCHOR] = "1"
		//attrs[enum.IM_USER_ATTR_SPARRING] = "0"
		more = false
	case dbmodels.MESSAGE_PUSH_USER_IDENTITY_SPARRING:
		//attrs[enum.IM_USER_ATTR_ANCHOR] = "0"
		attrs[enum.IM_USER_ATTR_SPARRING] = "1"
		more = false
	case dbmodels.MESSAGE_PUSH_USER_IDENTITY_NORMAL:
		attrs[enum.IM_USER_ATTR_ANCHOR] = "0"
		attrs[enum.IM_USER_ATTR_SPARRING] = "0"
		more = false
	case dbmodels.MESSAGE_PUSH_USER_IDENTITY_ANCHOR_AND_NORMAL:
		attrs[enum.IM_USER_ATTR_ANCHOR] = "1"
		attr2[enum.IM_USER_ATTR_ANCHOR] = "0"
		attr2[enum.IM_USER_ATTR_SPARRING] = "0"
		more = true
	case dbmodels.MESSAGE_PUSH_USER_IDENTITY_SPARRING_AND_NORMAL:
		attrs[enum.IM_USER_ATTR_SPARRING] = "1"
		attr2[enum.IM_USER_ATTR_ANCHOR] = "0"
		attr2[enum.IM_USER_ATTR_SPARRING] = "0"
		more = true
	case dbmodels.MESSAGE_PUSH_USER_IDENTITY_SPARRING_AND_ANCHOR:
		attrs[enum.IM_USER_ATTR_SPARRING] = "1"
		attr2[enum.IM_USER_ATTR_ANCHOR] = "1"
		more = true
	default:
	}
	condition.AttrsAnd = attrs
	condition2.AttrsAnd = attr2
	wg := sync.WaitGroup{}
	if !more {
		wg.Add(1)
		errChan := make(chan *AttrPushChan, 1)
		status = dbmodels.MESSAGE_FINISHED_STATUS_OK
		PushMsgAttrAction(form, &condition, errChan, &wg)
		wg.Wait()
		close(errChan)
		info := <-errChan
		taskId = info.TaskId
		err = info.Err
		if err != nil {
			status = dbmodels.MESSAGE_FINISHED_STATUS_FAIL
		}
		return
	}
	wg.Add(2)
	errChan := make(chan *AttrPushChan, 2)
	status = dbmodels.MESSAGE_FINISHED_STATUS_OK
	go PushMsgAttrAction(form, &condition, errChan, &wg)
	go PushMsgAttrAction(form, &condition2, errChan, &wg)
	wg.Wait()
	close(errChan)
	for m := range errChan {
		taskId += m.TaskId + ","
		err = m.Err
		if err != nil {
			status = dbmodels.MESSAGE_FINISHED_STATUS_FAIL
		}
	}
	return
}

type AttrPushChan struct {
	TaskId string `json:"task_id"`
	Err    error  `json:"err"`
}

// 推送,按标签
func PushMsgAttrAction(form *dbmodels.AppSystemMessage, condition *tencentIm.ConditionOrItem, msgChan chan *AttrPushChan, wg *sync.WaitGroup) {
	defer wg.Done()

	assistantMsg := &redismodels.AssistantMsg{
		Type:       form.MessageAssistantType,
		ActionType: form.MessageJumpType,
		Title:      form.MessageTitle,
		Text:       form.MessageContent,
		Action:     form.MessageJumpLink,
		Image:      form.MessageUrl,
	}
	var returnInfo AttrPushChan
	if assistantMsg.Type == redismodels.MSG_ASSISTANT_TYPE_ACTION ||
		assistantMsg.Type == redismodels.MSG_ASSISTANT_TYPE_IMG ||
		assistantMsg.Type == redismodels.MSG_ASSISTANT_TYPE_TIPS_ACTION {
		action := make(map[string]interface{})
		returnInfo.Err = jsoniter.UnmarshalFromString(form.MessageJumpLink, &action)
		if returnInfo.Err != nil {
			utils.LogErrorF("反序列化跳转参数失败")
			msgChan <- &returnInfo
			return
		}
		assistantMsg.ActionParams = action
	}
	msg := &redismodels.AppMsg{
		AssistantMsg: assistantMsg,
		CreateT:      time.Now().Unix(),
		Type:         redismodels.MSG_EXT_TYPE_ASSISTANT,
	}
	cusMsg := tencentIm.TIMCustomElem{Data: msg.MarshalToString(), Ext: form.MessageSubtitle, Desc: form.MessageSubtitle}
	returnInfo.TaskId, returnInfo.Err = tencentIm.SendNotificationByAttr(redismodels.MSG_ADMIN_USER_ASSISTANT, condition, cusMsg)
	msgChan <- &returnInfo
	return
}

// 推送,全局
func PushMsgAllAction(form *dbmodels.AppSystemMessage) (taskId string, err error) {
	assistantMsg := &redismodels.AssistantMsg{
		Type:       form.MessageAssistantType,
		ActionType: form.MessageJumpType,
		Title:      form.MessageTitle,
		Text:       form.MessageContent,
		Action:     form.MessageJumpLink,
		Image:      form.MessageUrl,
	}
	if assistantMsg.Type == redismodels.MSG_ASSISTANT_TYPE_ACTION ||
		assistantMsg.Type == redismodels.MSG_ASSISTANT_TYPE_IMG ||
		assistantMsg.Type == redismodels.MSG_ASSISTANT_TYPE_TIPS_ACTION {
		action := make(map[string]interface{})
		err = jsoniter.UnmarshalFromString(form.MessageJumpLink, &action)
		if err != nil {
			utils.LogErrorF("反序列化跳转参数失败")
			return
		}
		assistantMsg.ActionParams = action
	}
	msg := &redismodels.AppMsg{
		AssistantMsg: assistantMsg,
		CreateT:      time.Now().Unix(),
		Type:         redismodels.MSG_EXT_TYPE_ASSISTANT,
	}
	cusMsg := tencentIm.TIMCustomElem{Data: msg.MarshalToString(), Ext: form.MessageSubtitle, Desc: form.MessageSubtitle}
	taskId, err = tencentIm.SendNotificationByAll(redismodels.MSG_ADMIN_USER_ASSISTANT, cusMsg)
	return
}

// 推送客服消息
func PushMsgKeFu(form *dbmodels.AppSystemMessage) (status int, err error) {
	//if form.MessageToUserIds == ""{
	//	taskId, err := PushMsgAllAction(form)
	//	if err != nil {
	//		utils.LogErrorF("推送全局消息失败,err:%s", err.Error())
	//		status = dbmodels.MESSAGE_FINISHED_STATUS_FAIL
	//	}
	//	err = form.UpdateStatusAndReturnIdById(form.MessageId, status, taskId)
	//	return status, err
	//}
	userIds := strings.Split(form.MessageToUserIds, ",")
	if form.MessageCcUserIds != "" {
		userIds = append(userIds, strings.Split(form.MessageCcUserIds, ",")...)
	}
	wg := sync.WaitGroup{}
	errChan := make(chan error, len(userIds))
	for _, userId := range userIds {
		wg.Add(1)
		go PushMsgKeFuAction(userId, form, &wg, errChan)
	}
	wg.Wait()
	close(errChan)
	var Errs []error
	for m := range errChan {
		if m != nil {
			Errs = append(Errs, m)
		}
	}
	// 更新任务执行状态
	if len(Errs) == len(userIds) {
		status = dbmodels.MESSAGE_FINISHED_STATUS_FAIL
	} else if len(Errs) == 0 {
		status = dbmodels.MESSAGE_FINISHED_STATUS_OK
	} else {
		status = dbmodels.MESSAGE_FINISHED_STATUS_PART_OK
	}
	err = form.UpdateStatusAndReturnIdById(form.MessageId, status, "")
	return
}

// 处理客服消息
func PushMsgKeFuAction(userId string, form *dbmodels.AppSystemMessage, wg *sync.WaitGroup, errChan chan error) {
	defer wg.Done()
	assistantMsg := &redismodels.AssistantMsg{
		Type:       form.MessageAssistantType,
		ActionType: form.MessageJumpType,
		Title:      form.MessageTitle,
		Text:       form.MessageContent,
		Action:     form.MessageJumpLink,
		Image:      form.MessageUrl,
	}
	if assistantMsg.Type == redismodels.MSG_ASSISTANT_TYPE_ACTION ||
		assistantMsg.Type == redismodels.MSG_ASSISTANT_TYPE_IMG ||
		assistantMsg.Type == redismodels.MSG_ASSISTANT_TYPE_TIPS_ACTION {
		action := make(map[string]interface{})
		err := jsoniter.UnmarshalFromString(form.MessageJumpLink, &action)
		if err != nil {
			utils.LogErrorF("反序列化跳转参数失败")
			errChan <- err
			return
		}
		assistantMsg.ActionParams = action
	}

	msg := redismodels.AppMsg{
		CreateT:      time.Now().Unix(),
		AssistantMsg: assistantMsg,
		Type:         redismodels.MSG_EXT_TYPE_ASSISTANT,
	}
	cusMsg := tencentIm.TIMCustomElem{Data: msg.MarshalToString(), Ext: form.MessageTitle, Desc: form.MessageSubtitle}
	err := tencentIm.SendCusMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userId, cusMsg)
	if err != nil {
		utils.LogErrorF("发送客服推送失败,err:%s", err.Error())
	}
	errChan <- err
	return
}
