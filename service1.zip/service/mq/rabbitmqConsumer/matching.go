package rabbitmqConsumer

import (
	"gamers/controller/services/speedmatching"
	"gamers/models/dbmodels"
	"gamers/utils"
	"strconv"

	"github.com/streadway/amqp"
)

// 取消极速匹配
func MatchingCancel(d amqp.Delivery) {
	defer d.Ack(true)
	body := string(d.Body)
	utils.LogInfoF("[取消极速匹配]接收到消息：[%s]", body)
	matchingId, err := strconv.Atoi(body)
	if err != nil {
		utils.LogErrorF("[取消极速匹配]转换数据类型失败[%d]失败,%s", matchingId, err.Error())
		return
	}
	msg, _, _, err := speedmatching.New().Refund(int64(matchingId), dbmodels.SPEED_MATCHING_STATUS_EXPIRED, 0)
	if err != nil {
		utils.LogErrorF("[取消极速匹配]处理失败[%d]失败[%s],%s", matchingId, msg, err.Error())
		return
	}
}
