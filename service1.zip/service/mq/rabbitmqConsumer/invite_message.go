package rabbitmqConsumer

import (
	"gamers/controller/services"
	"gamers/utils"
	"strconv"

	"github.com/streadway/amqp"
)

// InviteMessageSend 给用户发送大神撩一撩邀请消息
func InviteMessageSend(d amqp.Delivery) {
	defer d.Ack(true)

	userID, err := strconv.Atoi(string(d.Body))
	if err != nil {
		utils.LogErrorF("获取撩一撩用户id失败.", err)
		return
	}
	utils.LogInfoF("---------->撩一撩收到消息,用户id %d<-------------", userID)

	err = new(services.InviteMessage).Send(int64(userID))
	if err != nil {
		utils.LogErrorF("给用户发送撩一撩邀请消息失败. %v", err)
		return
	}
	utils.LogInfoF("给用户发送撩一撩邀请消息成功")
}
