package rabbitmqProducer

import (
	"encoding/json"
	"fmt"
	"gamers/utils"
)

type AmqpSkillOrderConsumer struct {
	OrderId     int64 `json:"order_id"`
	OrderStatus int   `json:"order_status"`
}

//延迟申述订单时间
var appealOrderTime = 60 * 60 * 12 //12小时

//投递大神订单延迟消息
//orderId 订单id
//orderStatus 订单状态(当前订单状态)
//delay 延迟时间(单位/秒)
func ProducerOrder(orderId int64, orderStatus int, delay int) {
	data := AmqpSkillOrderConsumer{
		OrderId:     orderId,
		OrderStatus: orderStatus,
	}
	marshal, err := json.Marshal(data)
	if err != nil {
		utils.LogErrorF("投递订单延迟消息失败orderId[%d],err[%s]", orderId, err.Error())
	}
	// 避免单次投递失败,10秒内重复投递
	err = utils.RabbitMQProducerDelayed(utils.RABBITMQ_SKILL_ORDER, string(marshal), delay)
	if err != nil {
		utils.LogErrorF("投递订单延迟消息失败orderId[%d],err[%s]", orderId, err.Error())
	}
}

//投递大神订单申述延迟消息
//orderId 订单id
func ProducerAppealOrder(orderId int64) {
	err := utils.RabbitMQProducerDelayed(utils.RABBITMQ_SKILL_ORDER_APPEAL, fmt.Sprintf("%d", orderId), appealOrderTime)
	if err != nil {
		utils.LogErrorF("投递大神订单申述延迟消息:orderId[%d],err[%s]", orderId, err.Error())
	}
}
