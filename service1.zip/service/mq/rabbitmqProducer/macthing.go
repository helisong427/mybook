package rabbitmqProducer

import (
	"fmt"
	"gamers/utils"
)

// 投递极速匹配取消
func MatchingCancel(matchingId int64) {
	delay := 60 * 5
	err := utils.RabbitMQProducerDelayed(utils.RABBITMQ_MATCHING_CANCEL, fmt.Sprint(matchingId), delay)
	if err != nil {
		utils.LogErrorF("投递极速匹配取消失败[%d],err[%s]", matchingId, err.Error())
		return
	}
	fmt.Println("投递极速匹配取消成功")
}
