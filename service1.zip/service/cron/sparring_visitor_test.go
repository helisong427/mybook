package cron

import "testing"

func TestAutoMergeSparringVisitorHistoryData(t *testing.T) {
	Init("test")

	AutoMergeSparringVisitorHistoryData()
}
