package cron

import (
	"os"

	"github.com/robfig/cron"
)

func NewCron(sysSignal chan os.Signal, done chan struct{}) {
	// f1 f2 f3 f4 f5 f6  f1 是表示秒，f2表示分钟，f3 表示小时，f4 表示一个月份中的第几日，f5 表示月份，f6表示一个星期中的第几天
	// (1) */2 * * * * *     每个偶数分执行
	// (2) */2 */2 * * * *   每个偶数分 并且是偶数秒执行
	// (3) 2,4,6 * * * * *   每分钟的2,4,6这三个秒执行
	// (4) 2,4,6 5-6 * * * 1 每周一的5点2,4,6秒和6点2,4,6秒执行
	// (5) @daily            每天一次
	// (6) @midnight         同上
	// (7) @every 1m30s      定时1分30秒执行
	cron := cron.New()
	defer cron.Stop()
	roomCharmCount(cron)
	roomHot(cron)
	tweetPopularCount(cron)
	OrderComment(cron)
	liaoyiliaoInitGlobalCache(cron)
	liaoyiliaoUpdateCache(cron)
	UserState(cron)
	go AutoMergeSparringVisitorHistoryData()
	go RoomCron()
	cron.Start()

	select {
	case <-done:
	case <-sysSignal:
	}
}
