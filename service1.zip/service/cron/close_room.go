package cron

import (
	"gamers/models/dbmodels"
	"gamers/mq/rabbitmqProducer"
	"gamers/utils"
	"strconv"
	"time"

	"github.com/go-redis/redis"
)

func RoomCron() {
	// 首先 从 redis 获取对应键值, 如果有,则不执行
	key := "closeRoomDataClean"
	if cacheData := utils.RedisClient.Get(key).Val(); cacheData != "" {
		return
	}
	CleanRoom()
	PushNormalRoom()
	// 存储对应键值
	utils.RedisClient.Set(key, "1", 60*60*24*15*time.Second)
}

// 清洗关闭房间的在线人员信息
func CleanRoom() {
	// 获取所有关闭的房间
	rooms := make([]dbmodels.AppLiveRoom, 0)
	err := utils.GEngine.Table("app_live_room").
		Where("app_live_room.room_status = 1 OR app_live_room.room_status = 2 and app_live_room.room_type = 1").
		Find(&rooms).Error
	if err != nil {
		utils.LogErrorF("房间关闭查询关闭房间失败,err:%s", err.Error())
		return
	}
	for _, v := range rooms {
		idStr := strconv.Itoa(int(v.RoomId))
		// 清除房间内的人员
		err = utils.RedisClient.Del(utils.REDIS_LIVE_ONLINE_MEMBER + idStr).Err()
		if err != nil {
			utils.LogErrorF("移除房间[%s]在线人员失败, %s", idStr, err.Error())
		}
		// 在线人员更新为0
		err = utils.RedisClient.Del(utils.REDIS_LIVE_ONLINE_MEMBER_NUM + idStr).Err()
		if err != nil && err != redis.Nil {
			utils.LogErrorF("更新用户在线人员失败, %s,  %v", idStr, err.Error())
		}
		if err == nil {
			utils.LogInfoF("清理房间[" + idStr + "]成功")
		}
	}
}

// 推送未关闭房间
func PushNormalRoom() {
	rooms := make([]dbmodels.AppLiveRoom, 0)
	err := utils.GEngine.Table("app_live_room").Where("app_live_room.room_status = 0 and app_live_room.room_type = 1").Find(&rooms).Error
	if err != nil {
		utils.LogErrorF("房间关闭查询关闭房间失败,err:%s", err.Error())
		return
	}
	for _, v := range rooms {
		rabbitmqProducer.ProducerCloseRoom(int(v.RoomId))
		utils.LogInfoF("推送房间[%d]成功", v.RoomId)
	}
}
