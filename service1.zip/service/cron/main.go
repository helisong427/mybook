package cron

import "gamers/utils"

func Init(conf string) {
	utils.ConfigInitLocal(conf)
	// 初始化日志
	utils.LoggerInit()
	utils.GDBInit()
	utils.RedisInit()
}
