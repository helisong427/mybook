package cron

import (
	"encoding/json"
	"fmt"
	"gamers/models/dbmodels"
	"gamers/utils"
	"gamers/utils/tencent/tencentIm"

	"github.com/robfig/cron"
)

const (
	// 每次查询出来的最大用户数，与 im 一次查询用户状态的最大限制数相同。
	MaxminueUsers                   = 500
	DEFALUT_IM_STATE_CHANGE_TIMEOUT = 60 * 15
	// 用户状态改变回调命名
	UserStateChange = "State.StateChange"
	StateOptimized  = "主动补偿"
)

type imStateChangeReq struct {
	CallbackCommand string `json:"CallbackCommand"` // 回调命令
	Info            struct {
		Action     string `json:"Action"`     // 用户上线或者下线的动作，Login 表示上线（TCP 建立），Logout 表示下线（TCP 断开），Disconnect 表示网络断开（TCP 断开）
		To_Account string `json:"To_Account"` // 用户 UserID
		Reason     string `json:"Reason"`     // 用户上下线触发的原因：
		// Login 的原因有 Register：App TCP 连接建立
		// Logout 的原因有 Unregister：App 用户注销帐号导致 TCP 断开
		// Disconnect 的原因有 LinkClose：即时通信 IM 检测到 App TCP 连接断开（例如 kill App，客户端发出 TCP 的 FIN 包或 RST 包）；TimeOut：即时通信 IM 检测到 App 心跳包超时，认为 TCP 已断开（例如客户端网络异常断开，未发出 TCP 的 FIN 包或 RST 包，也无法发送心跳包）。心跳超时时间为400秒
		// 各种具体场景触发的回调 Reason 请参考 可能触发该回调的场景
		// 如果用户的上线请求和下线请求同时到来，此时只会触发 Logout + Unregister 回调，不会触发 Login + Register 回调
	} `json:"Info"` // 用户上下线的信息
}

// UserState 获取用户状态，每天凌晨4点执行。
func UserState(cron *cron.Cron) {
	// 启动时初始化
	spec := "0 0 4 * * *" // 每天凌晨4点执行

	err := cron.AddFunc(spec, task)
	if err != nil {
		utils.LogErrorF("增加更新用户状态定时任务失败：%v", err)
	}
}

// task 更改用户状态定时任务回调
func task() {
	// 获取在线用户总人数
	var total int64
	err := utils.GEngine.Model(&dbmodels.SystemUser{}).
		Count(&total).
		Where("user_is_online = ?", 1).Error
	if err != nil {
		utils.LogErrorF("获取在线用户总人数失败: %v", err)
		return
	}
	// 没有在线的人
	if total == 0 {
		utils.LogInfoF("没有在线用户，定时任务结束。")
		return
	}

	var times int
	quo := total / MaxminueUsers // 商
	res := total % MaxminueUsers // 余
	times = int(quo)
	if res > 0 {
		times += 1
	}

	// 要处理的次数
	for i := 0; i < times; i++ {
		ids, err := getOnlineUsers(i, MaxminueUsers)
		if err != nil {
			utils.LogInfoF("查询数据库中所有在线的用户失败：%v", err)
			return
		}

		// 每 500 个用户开启一个协程处理用户在线状态变更,不足的按实际人数请求。
		go dealIMQueryState(ids)
	}
}

// getOnlineUsers 查询数据库中所有在线的用户。 0 不在线 1 在线
func getOnlineUsers(page, size int) (ids []string, err error) {
	err = utils.GEngine.Model(&dbmodels.SystemUser{}).
		Select("user_id").
		Where("user_is_online = ?", 1).
		Offset(page * size).Limit(size).
		Find(&ids).Error
	if err != nil {
		utils.LogErrorF("查询用户在线状态失败：%v", err)
		return
	}
	return
}

// dealIMQueryState 处理 im 查询状态
func dealIMQueryState(ids []string) {
	fmt.Println(ids)
	resp, err := tencentIm.Querystate(ids)
	if err != nil || resp.ActionStatus == "FAIL" {
		utils.LogErrorF("请求IM查询用户状态失败。响应结构：%v 错误：%v", resp, err)
		return
	}

	for _, v := range resp.QueryResult {
		// 用户为在线状态直接返回
		if v.Status == tencentIm.USER_STATUS_ONLINE {
			continue
		}

		// json 编码内容
		data, err := json.Marshal(&imStateChangeReq{
			CallbackCommand: UserStateChange,
			Info: struct {
				Action     string "json:\"Action\""
				To_Account string "json:\"To_Account\""
				Reason     string "json:\"Reason\""
			}{
				Action:     convert(v.Status),
				To_Account: v.To_Account,
				Reason:     StateOptimized,
			},
		})
		if err != nil {
			utils.LogErrorF("编码消息内容失败：%v", err)
			continue
		}

		// // 生产一条更新用户状态的消息
		err = utils.KafkaSendMsg(UserStateChange, utils.FuncGenerateDataId(), data)
		if err != nil {
			utils.LogErrorF("kafka发送消息失败：%v", err)
		}
	}
}

// convert 转换到 im 请求结构体的所需状态
func convert(status string) string {
	// 都表示离线
	if status == tencentIm.USER_STATUS_OFFLINE || status == tencentIm.USER_STATUS_PUSHONLINE {
		return "Logout"
	}
	return ""
}
