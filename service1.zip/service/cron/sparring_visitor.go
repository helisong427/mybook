package cron

import "gamers/utils"

// 自动 统计合并之前的访客记录
func AutoMergeSparringVisitorHistoryData() {
	key := "autoMergeSparringVisitorHistoryData"
	utils.RedisClient.Del(key)
	// var (
	// 	key       string
	// 	err       error
	// 	cacheData string
	// 	visitList []*dbmodels.ConvertHistoryDataResult
	// )
	//
	// // 首先 从 redis 获取对应键值, 如果有,则不执行
	// key = "autoMergeSparringVisitorHistoryData"
	// if cacheData = utils.RedisClient.Get(key).Val(); cacheData != "" {
	// 	return
	// }
	//
	// // 获取 访问列表 userId visitUid (因为以前只有主页访问)
	// if visitList, err = new(dbmodels.AppUserVisitorLog).GetList(); err != nil {
	// 	utils.LogErrorF("get visit list error in merge history data: %v", err.Error())
	// 	return
	// }
	//
	// for _, v := range visitList {
	// 	// 拼接为 userId visitUid方式
	// 	// 查询 数据库
	// 	tmp, errTmp := new(dbmodels.AppUserVisitor).QueryByUidAndType(v.LogUserId, v.LogVisitorUserId)
	//
	// 	if errTmp == gorm.ErrRecordNotFound {
	// 		// 创建记录
	// 		visitorModel := &dbmodels.AppUserVisitor{
	// 			VisitUserId:        v.LogUserId,
	// 			VisitVisitorUserId: v.LogVisitorUserId,
	// 			VisitLastTime:      v.Created,
	// 			VisitTimes:         1,
	// 			VisitType:          v.LogType,
	// 		}
	//
	// 		if err = visitorModel.Create(); err != nil {
	// 			utils.LogErrorF("%v", err.Error())
	// 		}
	//
	// 		continue
	// 	}
	//
	// 	if errTmp != nil {
	// 		utils.LogErrorF("get history user visitor error: %v", errTmp.Error())
	// 		continue
	// 	}
	//
	// 	// 进行更新操作
	// 	if err = new(dbmodels.AppUserVisitor).Update(tmp.VisitId, map[string]interface{}{
	// 		"visit_times": gorm.Expr("visit_times + 1"),
	// 		"visit_type":  v.LogType,
	// 	}); err != nil {
	// 		utils.LogErrorF("update user visitor error: %v", err.Error())
	// 	}
	// }
	//
	// // 存储对应键值
	// utils.RedisClient.Set(key, "1", 0)
}
