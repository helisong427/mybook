package cron

import (
	"gamers/controller/services"
	"gamers/utils"
	"github.com/robfig/cron"
)

//朋友圈热度统计
func tweetPopularCount(cron *cron.Cron) {
	spec := "0 0 */2 * * *" //每2个小时执行
	err := cron.AddFunc(spec, func() {
		err := services.TweetPopularCount()
		if err != nil {
			utils.LogErrorF("[朋友圈热度统计]错误,%s", err.Error())
		}
	})
	if err != nil {
		utils.LogErrorF("启动[朋友圈热度统计]定时任务失败:%s", err.Error())
	}
}
