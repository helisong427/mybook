package cron

import (
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"time"

	"github.com/go-redis/redis"
	"github.com/robfig/cron"
)

// 房间魅力值统计
func roomCharmCount(cron *cron.Cron) {
	// 每10分钟执行
	spec := "0 */10 * * * *"
	// spec := "* * * * * *"
	err := cron.AddFunc(spec, func() {
		t := time.Now()
		utils.LogInfoF("开始统计房间魅力值")

		// 今天时间
		todayStartTime := time.Date(t.Year(), t.Month(), t.Day(), 0, 0, 0, 0, t.Location()).Unix()
		todayEndTime := time.Date(t.Year(), t.Month(), t.Day(), 23, 59, 59, 59, t.Location()).Unix()
		// 昨天时间
		yesterdayT := t.AddDate(0, 0, -1) // 获取昨天的时间
		yesterdayStartTime := time.Date(yesterdayT.Year(), yesterdayT.Month(), yesterdayT.Day(), 0, 0, 0, 0, t.Location()).Unix()
		yesterdayEndTime := time.Date(yesterdayT.Year(), yesterdayT.Month(), yesterdayT.Day(), 23, 59, 59, 59, t.Location()).Unix()

		// 查询今天魅力值
		todayCharm, err := new(dbmodels.AppAnchorRoomProp).QueryTimeCharm(todayStartTime, todayEndTime)
		if err != nil {
			utils.LogErrorF("统计今天房间魅力值失败:%s", err.Error())
			return
		}

		// 查询昨天魅力值
		yesterdayCharm, err := new(dbmodels.AppAnchorRoomProp).QueryTimeCharm(yesterdayStartTime, yesterdayEndTime)
		if err != nil {
			utils.LogErrorF("统计昨天房间魅力值失败:%s", err.Error())
			return
		}

		if len(todayCharm) == 0 && len(yesterdayCharm) == 0 {
			// 没有数据删除缓存
			err = utils.RedisClient.Del(utils.REDIS_INDEX_ROOM_CHARM).Err()
			if err != nil {
				utils.LogErrorF("删除房间魅力值到redis失败:%s", err.Error())
				return
			}
		}
		// 魅力值
		charm := map[int64]float64{}
		// 跨天第一个小时（0点-1点）需按照前一天日榜总魅力值/48+当日日榜魅力值统计排序，1点后正常按当日日榜排序
		if t.Hour() == 0 || t.Hour() == 1 {
			for _, v := range todayCharm {
				charm[v.PropRoomId] = v.CharmSum
			}
			for _, v := range yesterdayCharm {
				if value, ok := charm[v.PropRoomId]; ok {
					charm[v.PropRoomId] = value/48 + v.CharmSum
				} else {
					charm[v.PropRoomId] = v.CharmSum
				}
			}
		} else {
			for _, v := range todayCharm {
				charm[v.PropRoomId] = v.CharmSum
			}
		}

		for k, v := range charm {
			if k == 0 || v == 0 {
				continue
			}
			// 储存到redis
			err = utils.RedisClient.ZAdd(utils.REDIS_INDEX_ROOM_CHARM, redis.Z{
				Score:  v,
				Member: k,
			}).Err()
			if err != nil {
				utils.LogErrorF("统计房间魅力值到redis失败:%s", err.Error())
				return
			}
		}
	})

	if err != nil {
		utils.LogErrorF("启动[房间魅力值统计]定时任务失败:%s", err.Error())
	}
}

// 房间热度统计
func roomHot(cron *cron.Cron) {
	// 每10分钟执行
	spec := "0 */10 * * * *"
	err := cron.AddFunc(spec, func() {
		err := redismodels.NewRoomHeat().UpdateAllHeat()
		if err != nil {
			utils.LogErrorF("[房间热度统计]错误:%s", err.Error())
		}
	})

	if err != nil {
		utils.LogErrorF("启动[房间热度统计]定时任务失败:%s", err.Error())
	}
}
