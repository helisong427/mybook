package config

type FileConfig struct {
	App           app           `ini:"app"`
	Delay         delay         `ini:"delay"`
	Consumer      consumer      `ini:"consumer"`
	Job           job           `ini:"job"`
	MasterDB      masterDB      `ini:"masterDB"`
	Slave1DB      slave1DB      `ini:"slave1DB"`
	Redis         redis         `ini:"redis"`
	RabbitMQ      rabbitMQ      `ini:"rabbitMQ"`
	Elasticsearch elasticsearch `ini:"elasticsearch"`
	Android       android       `ini:"android"`
	Ios           ios           `ini:"ios"`
	Sms           sms           `ini:"sms"`
	Tencent       tencent       `ini:"tencent"`
	JiGuang       jiguang       `ini:"jiguang"`
	Kafka         kafka         `ini:"kafka"`
	DelayMq       delayMq       `ini:"delayMq"`
	Agora         agora         `ini:"agora"`
	Fdd           fdd           `ini:"fdd"`
}

type app struct {
	Name         string `ini:"name"`
	Port         string `ini:"port"`
	Appkey       string `ini:"appkey"`
	ReadTimeout  int    `ini:"readTimeout"`
	WriteTimeout int    `ini:"writeTimeout"`
	ClientKey    string `ini:"clientkey"`
	LogType      string `ini:"logType"`
	LogLevel     string `ini:"logLevel"`
	LogPath      string `ini:"logPath"`
	LogName      string `ini:"logName"`
	DelayHost    string `ini:"delayHost"`
	LocalKey     string `ini:"localKey"`
}

type delay struct {
	Name string `ini:"name"`
	Port string `ini:"port"`
}

type consumer struct {
	Name string `ini:"name"`
	Port string `ini:"port"`
}

type job struct {
	Name string `ini:"name"`
	Port string `ini:"port"`
}

type masterDB struct {
	Type         string `ini:"type"`
	Host         string `ini:"host"`
	Port         string `ini:"port"`
	Username     string `ini:"username"`
	Password     string `ini:"password"`
	Dbname       string `ini:"dbname"`
	ReportDbName string `ini:"reportDbName"`
	Charset      string `ini:"charset"`
	MaxIdleConns int    `ini:"maxIdleConns"`
	MaxOpenConns int    `ini:"maxOpenConns"`
	TimeZone     string `ini:"timeZone"`
}

type slave1DB struct {
	Type     string `ini:"type"`
	Host     string `ini:"host"`
	Port     string `ini:"port"`
	Username string `ini:"username"`
	Password string `ini:"password"`
	Dbname   string `ini:"dbname"`
	Charset  string `ini:"charset"`
	TimeZone string `ini:"timeZone"`
}

type redis struct {
	Host         string `ini:"host"`
	Port         string `ini:"port"`
	Password     string `ini:"password"`
	Type         string `ini:"type"`
	DbNum        int    `ini:"dbNum"`
	MaxIdleConns int    `ini:"maxIdleConns"`
	MaxOpenConns int    `ini:"maxOpenConns"`
}

type rabbitMQ struct {
	User     string `ini:"user"`
	Password string `ini:"password"`
	Host     string `ini:"host"`
	Port     string `ini:"port"`
	Vhost    string `ini:"vhost"`
}

type elasticsearch struct {
	User     string `ini:"user"`
	Password string `ini:"password"`
	Host     string `ini:"host"`
	Port     string `ini:"port"`
	Cloudid  string `ini:"cloudid"`
	Apikey   string `ini:"apikey"`
}

type android struct {
	ShanyanAppID    string `ini:"shanyanAppID"`
	ShanyanAppKey   string `ini:"shanyanAppKey"`
	ShanyanQuery    string `ini:"shanyanQuery"`
	ShanyanValidate string `ini:"shanyanValidate"`
}

type ios struct {
	ShanyanAppID    string `ini:"shanyanAppID"`
	ShanyanAppKey   string `ini:"shanyanAppKey"`
	ShanyanQuery    string `ini:"shanyanQuery"`
	ShanyanValidate string `ini:"shanyanValidate"`
}

type sms struct {
	ChuangLanTongZhiAccount  string `ini:"chuangLanTongZhiAccount"`
	ChuangLanTongZhiPassword string `ini:"chuangLanTongZhiPassword"`
	ChuangLanTongZhiUrl      string `ini:"chuangLanTongZhiUrl"`
	ChuangLanTongZhiModelUrl string `ini:"chuangLanTongZhiModelUrl"`

	ChuangLanyanZhengMaAccount  string `ini:"chuangLanyanZhengMaAccount"`
	ChuangLanyanZhengMaPassword string `ini:"chuangLanyanZhengMaPassword"`
	ChuangLanyanZhengMaUrl      string `ini:"chuangLanyanZhengMaUrl"`
	ChuangLanyanZhengMaModelUrl string `ini:"chuangLanyanZhengMaModelUrl"`

	ChuangLanYingXiaoAccount  string `ini:"chuangLanYingXiaoAccount"`
	ChuangLanYingXiaoPassword string `ini:"chuangLanYingXiaoPassword"`
	ChuangLanYingXiaoUrl      string `ini:"chuangLanYingXiaoUrl"`
	ChuangLanYingXiaoModelUrl string `ini:"chuangLanYingXiaoModelUrl"`
}
type tencent struct {
	CosHost             string `ini:"cosHost"`
	CosRegion           string `ini:"cosRegion"`
	CosAppid            string `ini:"cosAppid"`
	CosSecretId         string `ini:"cosSecretId"`
	CosSecretKey        string `ini:"cosSecretKey"`
	CosBucket           string `ini:"cosBucket"`
	CosBucketHost       string `ini:"cosBucketHost"`
	CosSecretBucket     string `ini:"cosSecretBucket"`
	CosSecretBucketHost string `ini:"cosSecretBucketHost"`
	IMAppId             int    `ini:"imAppId"`
	IMSecretKey         string `ini:"imSecretKey"`
	Identifier          string `ini:"identifier"`

	// 重构后端登录相关配置
	CaptchaHost         string `ini:"captchaHost"`
	CaptchaSecretId     string `ini:"captchaSecretId"`
	CaptchaSecretKey    string `ini:"captchaSecretKey"`
	CaptchaAppid        uint64 `ini:"captchaAppid"`
	CaptchaAppSecretKey string `ini:"captchaAppSecretKey"`
}

type jiguang struct {
	JPushAppKey string `ini:"jpushAppKey"`
	JPushSecret string `ini:"jpushSecret"`
}

type kafka struct {
	Host string `ini:"host"`
}

type delayMq struct {
	Host1 string `ini:"host1"`
	Host2 string `ini:"host2"`
}

type agora struct {
	AppId          string `ini:"appId"`
	AppSecret      string `ini:"appSecret"`
	CustomerId     string `ini:"customerId"`
	CustomerSecret string `ini:"customerSecret"`
}

type fdd struct {
	AppId       string `ini:"appId"`
	AppSecret   string `ini:"appSecret"`
	Host        string `ini:"host"`
	NotifyUrl   string `ini:"notifyUrl"`
	ReturnUrl   string `ini:"returnUrl"`
	TemplateId  string `ini:"templateId"`
	CustomerId  string `ini:"customerId"`
	DocTitle    string `ini:"docTitle"`
	SignKeyword string `ini:"signKeyword"`
	DocUrl      string `ini:"docUrl"`
}
