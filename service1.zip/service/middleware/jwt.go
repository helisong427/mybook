package middleware

import (
	"errors"
	"strconv"
	"time"

	"gamers/controller/response"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"

	"github.com/gin-gonic/gin"

	"github.com/dgrijalva/jwt-go"
)

// JWT struct
type JWT struct {
	SigningKey []byte // 自定义密钥
}

// CustomClaims struct
type CustomClaims struct {
	ID      int64
	ATI     string // md5(Access-Token) 用于 refreshToken
	Subject string // 签名主题 ,用户id
	Type    string // 类型="refresh" 表示刷新
	jwt.StandardClaims
}

// 定义错误信息
var (
	TokenExpired     = errors.New("Token 已经过期")
	TokenNotValidYet = errors.New("Token 未激活")
	TokenMalformed   = errors.New("Token 错误")
	TokenInvalid     = errors.New("Token 无效")
)

// CustomClaimsManager 管理端token校验使用
type CustomClaimsManager struct {
	ID      uint64
	ATI     string // md5(Access-Token) 用于 refreshToken
	Subject uint64 // 签名主题 ,用户id
	RoleID  uint64 // 角色id
	Type    string // token类型
	jwt.StandardClaims
}

// JWTInit JWT初始化
func JWTInit() *JWT {
	return &JWT{SigningKey: []byte(utils.Config.App.Appkey)}
}

// CreateToken 创建 token
func (j *JWT) CreateToken(claims jwt.Claims) (string, error) {
	token := jwt.NewWithClaims(jwt.SigningMethodHS512, claims)
	return token.SignedString(j.SigningKey)
}

// ParseToken 解析 token
func (j *JWT) ParseToken(tokenString string) (*CustomClaims, error) {
	token, err := jwt.ParseWithClaims(tokenString, &CustomClaims{}, func(token *jwt.Token) (interface{}, error) {
		return j.SigningKey, nil
	})
	if err != nil {
		// fmt.Println("err = ", err)
		if ve, ok := err.(*jwt.ValidationError); ok {
			if ve.Errors&jwt.ValidationErrorMalformed != 0 {
				return nil, TokenMalformed
			} else if ve.Errors&jwt.ValidationErrorExpired != 0 {
				return nil, TokenExpired
			} else if ve.Errors&jwt.ValidationErrorNotValidYet != 0 {
				return nil, TokenNotValidYet
			} else {
				return nil, TokenInvalid
			}
		}
	}
	if token == nil {
		return nil, TokenInvalid
	}
	// 解析到Claims 构造中
	if claims, ok := token.Claims.(*CustomClaims); ok && token.Valid {
		currentTime := time.Now().Unix()
		capital, ok := token.Header["alg"]
		if !ok || capital != "HS512" {
			return nil, TokenInvalid
		} else if currentTime > claims.ExpiresAt || currentTime < claims.IssuedAt || claims.NotBefore > currentTime {
			return nil, TokenExpired
		}
		return claims, nil
	}
	return nil, TokenInvalid
}

// UserToken 用户token生成
func UserToken(userID int64) (accessToken, refreshToken string, err error) {
	timeNow := time.Now()
	j := JWTInit()
	userIDString := strconv.FormatInt(userID, 10)
	ATI := utils.FuncMD5(utils.FuncRandString(6))
	IDInt := utils.FuncRandInt(100000000)
	accessClams := CustomClaims{
		ID:      IDInt,
		ATI:     ATI,
		Subject: userIDString,
		StandardClaims: jwt.StandardClaims{
			ExpiresAt: timeNow.Add(30 * time.Minute).Unix(), //过期时间30分钟
			IssuedAt:  timeNow.Unix(),                       //颁发时间
			NotBefore: timeNow.Add(-1 * time.Second).Unix(), //开始生效时间
		},
	}
	accessToken, err = j.CreateToken(accessClams)
	if err != nil {
		return "", "", err
	}
	user, err := new(dbmodels.SystemUser).UserIdByUser(userID)
	if err != nil {
		return "", "", err
	}
	refreshClams := CustomClaims{
		ID:      IDInt,
		ATI:     utils.FuncMD5(ATI + "refresh"),
		Subject: userIDString,
		Type:    "refresh",
		StandardClaims: jwt.StandardClaims{
			ExpiresAt: timeNow.Add(15 * 24 * time.Hour).Unix(), // 过期时间15天
			IssuedAt:  timeNow.Unix(),                          // 颁发时间
			NotBefore: timeNow.Add(-1 * time.Second).Unix(),    // 开始生效时间
		},
	}
	refreshToken, err = j.CreateToken(refreshClams)
	if err != nil {
		return "", "", err
	}
	new(redismodels.UserInfo).SaveUserInfo(user, ATI)
	return accessToken, refreshToken, nil
}

func UserMultiToken(userID int64, ati string) (accessToken, refreshToken string, err error) {
	timeNow := time.Now()
	j := JWTInit()
	userIDString := strconv.FormatInt(userID, 10)
	IDInt := utils.FuncRandInt(100000000)
	accessClams := CustomClaims{
		ID:      IDInt,
		ATI:     ati,
		Subject: userIDString,
		StandardClaims: jwt.StandardClaims{
			ExpiresAt: timeNow.Add(5 * time.Hour).Unix(),    //过期时间5小时
			IssuedAt:  timeNow.Unix(),                       //颁发时间
			NotBefore: timeNow.Add(-1 * time.Second).Unix(), //开始生效时间
		},
	}
	accessToken, err = j.CreateToken(accessClams)
	if err != nil {
		return "", "", err
	}
	if err != nil {
		return "", "", err
	}
	refreshClams := CustomClaims{
		ID:      IDInt,
		ATI:     utils.FuncMD5(ati + "refresh"),
		Subject: userIDString,
		Type:    "refresh",
		StandardClaims: jwt.StandardClaims{
			ExpiresAt: timeNow.Add(15 * 24 * time.Hour).Unix(), //过期时间15天
			IssuedAt:  timeNow.Unix(),                          //颁发时间
			NotBefore: timeNow.Add(-1 * time.Second).Unix(),    //开始生效时间
		},
	}
	refreshToken, err = j.CreateToken(refreshClams)
	if err != nil {
		return "", "", err
	}
	return accessToken, refreshToken, nil
}

// JWTAuth 检查访问token
func JWTAuth() gin.HandlerFunc {
	return func(gctx *gin.Context) {
		accessToken := gctx.Request.Header.Get("Access-Token")
		j := JWTInit()
		if accessToken == "" {
			response.ResponseError(gctx, response.RESPONSE_AUTH_ERROR, "未登录或非法访问1", "5", "")
			gctx.Abort()
			return
		}
		accessClaims, err := j.ParseToken(accessToken)
		if err != nil || accessClaims == nil {
			response.ResponseError(gctx, response.RESPONSE_AUTH_TIME_OUT, "未登录或非法访问2", "1", accessToken)
			gctx.Abort()
			return
		}
		if accessClaims.Type != "" {
			response.ResponseError(gctx, response.RESPONSE_AUTH_TIME_OUT, "未登录或非法访问3", "2", accessToken)
			gctx.Abort()
			return
		}
		if accessClaims.Subject == "" {
			response.ResponseError(gctx, response.RESPONSE_AUTH_TIME_OUT, "登录身份过期4", "3", accessToken)
			gctx.Abort()
			return
		}
		token, _ := utils.RedisClient.HGet(utils.REDIS_USER_INFO+accessClaims.Subject, "Token").Result()
		if token == "" {
			tips := "账号异常,请联系客服工作人员!5"
			param, err1 := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_SERVICE_QQ)
			if err1 == nil {
				tips = "账号异常,请联系客服QQ:" + param["value"] + "!6"
			}
			response.ResponseError(gctx, response.RESPONSE_AUTH_TOKEN_NULL, tips, "7", "")
			gctx.Abort()
			return
		}
		if token != accessClaims.ATI {
			response.ResponseError(gctx, response.RESPONSE_AUTH_TIME_OUT, "未登录或非法访问7", "4", accessToken)
			gctx.Abort()
			return
		}
		gctx.Set("userID", accessClaims.Subject)
		gctx.Next()
	}
}

// 每日登录任务-中间件
func TurnTableDailyLogin() gin.HandlerFunc {
	return func(gctx *gin.Context) {

		accessToken := gctx.Request.Header.Get("Access-Token")
		j := JWTInit()
		if accessToken == "" {
			response.ResponseError(gctx, response.RESPONSE_AUTH_ERROR, "未登录或非法访问1", "5", "")
			gctx.Abort()
			return
		}
		accessClaims, err := j.ParseToken(accessToken)
		if err != nil || accessClaims == nil {
			response.ResponseError(gctx, response.RESPONSE_AUTH_TIME_OUT, "未登录或非法访问2", "1", accessToken)
			gctx.Abort()
			return
		}
		// 任务触发
		go func() {
			userIdInt64, _ := strconv.ParseInt(accessClaims.Subject, 10, 64)
			_ = new(redismodels.Task).Init().ReportConditionTag(userIdInt64, "logInDaily", 1)
		}()
	}
}

func CheckRefreshToken() gin.HandlerFunc {
	return func(gctx *gin.Context) {
		refreshToken := gctx.Request.Header.Get("Refresh-Token")
		j := JWTInit()
		if refreshToken == "" {
			response.ResponseError(gctx, response.RESPONSE_AUTH_ERROR, "未登录或非法访问8", "7", "")
			gctx.Abort()
			return
		}
		refreshClaims, err := j.ParseToken(refreshToken)
		if err != nil || refreshClaims == nil {
			response.ResponseError(gctx, response.RESPONSE_AUTH_ERROR, "未登录或非法访问9", "1", "")
			gctx.Abort()
			return
		}
		if refreshClaims.Type != "refresh" {
			response.ResponseError(gctx, response.RESPONSE_AUTH_ERROR, "未登录或非法访问10", "2", "")
			gctx.Abort()
			return
		}
		if refreshClaims.Subject == "" {
			response.ResponseError(gctx, response.RESPONSE_AUTH_ERROR, "未登录或非法访问11", "3", "")
			gctx.Abort()
			return
		}

		token, _ := utils.RedisClient.HGet(utils.REDIS_USER_INFO+refreshClaims.Subject, "Token").Result()
		if token == "" {
			tips := "账号异常,请联系客服工作人员!12"
			param, err1 := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_SERVICE_QQ)
			if err1 == nil {
				tips = "账号异常,请联系客服QQ:" + param["value"] + "!13"
			}
			response.ResponseError(gctx, response.RESPONSE_AUTH_TOKEN_NULL, tips, "7", "")
			gctx.Abort()
			return
		}

		// 老token start
		userTemOldRefreshToken, _ := utils.RedisClient.Get(utils.REDIS_USER_TEM_OLD_REFRESH_TOKEN + refreshClaims.Subject).Result()
		if userTemOldRefreshToken != "" && userTemOldRefreshToken == refreshClaims.ATI {
			response.ResponseOk(gctx, "刷新Token成功", nil)
			gctx.Abort()
			return
		}
		// 老token end

		if utils.FuncMD5(token+"refresh") != refreshClaims.ATI {
			response.ResponseError(gctx, response.RESPONSE_AUTH_ERROR, "未登录或非法访问14", "4", "")
			gctx.Abort()
			return
		}

		// 10s刷新的token 不重新刷新start
		if time.Now().Unix()-refreshClaims.IssuedAt < 10 {
			response.ResponseOk(gctx, "刷新Token成功", nil)
			gctx.Abort()
			return
		}
		// 10s刷新的token end

		userId, _ := strconv.ParseInt(refreshClaims.Subject, 10, 64)
		accessToken, refreshToken, err := UserToken(userId)
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_AUTH_ERROR, "刷新Token失败15", "6", "")
			gctx.Abort()
			return
		}
		// 记录老refresh token 10s
		utils.RedisClient.Set(utils.REDIS_USER_TEM_OLD_REFRESH_TOKEN+refreshClaims.Subject, refreshClaims.ATI, 10*time.Second)

		// 返回token
		gctx.Header("Access-Token", accessToken)
		gctx.Header("Refresh-Token", refreshToken)
		response.ResponseOk(gctx, "刷新Token成功", nil)
		gctx.Abort()
		return
	}
}

// 使用手机号登录
func UserLoginByMobile(user dbmodels.SystemUser, ip uint) (accessToken string, refreshToken string, r response.UserLoginRep, err error) {
	// 生成token
	accessToken, refreshToken, err = UserToken(user.UserID)
	if err != nil {
		return
	}
	r = response.UserLoginRep{
		Nickname:     user.UserNickname,
		Gender:       user.UserGender,
		Iconurl:      user.UserIconurl,
		UserId:       user.UserID,
		IsBindMobile: 1,
		IsSetInfo:    0,
		IsSuper:      user.UserIsSuper,
	}
	if user.UserNickname != "" && user.UserGender > 0 {
		r.IsSetInfo = 1
	}
	return
}

// UserLoginByOpenid 使用第三方登录
func UserLoginByOpenid(userId int64, openinfoId int64, ip uint) (accessToken string, refreshToken string, r response.UserLoginRep, err error) {
	// 生成token
	accessToken, refreshToken, err = UserToken(userId)
	if err != nil {
		return
	}
	r = response.UserLoginRep{
		UserId:       userId,
		IsBindMobile: 1,
	}
	return
}

func CheckUserKey() gin.HandlerFunc {
	return func(gctx *gin.Context) {

		userKey := gctx.Query("user_key")
		timeQuery := gctx.Query("time")
		userID := gctx.Query("user_id")
		now := time.Now().Unix()
		parseInt, _ := strconv.ParseInt(timeQuery, 10, 64)

		if now-60*60 > parseInt {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "登录过期", "2", "")
			gctx.Abort()
			return
		}

		key := utils.Config.App.Appkey + userID + timeQuery

		md5 := utils.FuncMD5(utils.FuncMD5(key))
		if userKey == "" || timeQuery == "" || md5 != userKey {
			response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "未登录或非法访问", "2", "")
			gctx.Abort()
			return
		}
		gctx.Set("userID", userID)
		gctx.Next()
	}
}

// JWTAuthMannager 管理端
func JWTAuthMannager() gin.HandlerFunc {
	return func(gctx *gin.Context) {
		accessToken := gctx.Request.Header.Get("Access-Token")
		j := JWTInit()
		if accessToken == "" {
			response.ResponseError(gctx, response.RESPONSE_AUTH_ERROR, "未登录或非法访问1", "5", "")
			gctx.Abort()
			return
		}
		accessClaims, err := j.ParseTokenManager(accessToken)
		if err != nil || accessClaims == nil {
			response.ResponseError(gctx, response.RESPONSE_AUTH_TIME_OUT, "未登录或非法访问2", "1", accessToken)
			gctx.Abort()
			return
		}
		if accessClaims.Type != "" {
			response.ResponseError(gctx, response.RESPONSE_AUTH_TIME_OUT, "未登录或非法访问3", "2", accessToken)
			gctx.Abort()
			return
		}
		if accessClaims.Subject <= 0 {
			response.ResponseError(gctx, response.RESPONSE_AUTH_TIME_OUT, "登录身份过期4", "3", accessToken)
			gctx.Abort()
			return
		}
		token, _ := utils.RedisClient.HGet(utils.REDIS_MANAGE_INFO+strconv.FormatUint(accessClaims.Subject, 10), "token").Result()
		if token == "" || token != accessClaims.ATI {
			response.ResponseError(gctx, response.RESPONSE_AUTH_TIME_OUT, "未登录或非法访问5", "4", accessToken)
			gctx.Abort()
			return
		}
		// 管理员id
		gctx.Set("manageId", accessClaims.Subject)
		// 获取用户的角色
		roleID := accessClaims.RoleID
		gctx.Set("roleId", roleID)
		// 获取公会id
		unionID, _ := utils.RedisClient.HGet(utils.REDIS_MANAGE_INFO+strconv.FormatUint(accessClaims.Subject, 10), "unionid").Uint64()
		gctx.Set("unionId", unionID)
		gctx.Next()
	}
}

// ParseToken 解析 token
func (j *JWT) ParseTokenManager(tokenString string) (*CustomClaimsManager, error) {
	token, err := jwt.ParseWithClaims(tokenString, &CustomClaimsManager{}, func(token *jwt.Token) (interface{}, error) {
		return j.SigningKey, nil
	})
	if err != nil {
		if ve, ok := err.(*jwt.ValidationError); ok {
			if ve.Errors&jwt.ValidationErrorMalformed != 0 {
				return nil, TokenMalformed
			} else if ve.Errors&jwt.ValidationErrorExpired != 0 {
				return nil, TokenExpired
			} else if ve.Errors&jwt.ValidationErrorNotValidYet != 0 {
				return nil, TokenNotValidYet
			} else {
				return nil, TokenInvalid
			}
		}
	}
	if token == nil {
		return nil, TokenInvalid
	}
	// 解析到Claims 构造中
	if claims, ok := token.Claims.(*CustomClaimsManager); ok && token.Valid {
		currentTime := time.Now().Unix()
		capital, ok := token.Header["alg"]
		if !ok || capital != "HS512" {
			return nil, TokenInvalid
		} else if currentTime > claims.ExpiresAt || currentTime < claims.IssuedAt || claims.NotBefore > currentTime {
			return nil, TokenExpired
		}
		return claims, nil
	}
	return nil, TokenInvalid
}

func ManageToken(manageId uint64, roleID uint64) (string, string, string) {
	now := time.Now()
	j := JWTInit()
	randStr := utils.FuncMD5(utils.FuncRandString(6))
	randNum := utils.FuncRandInt(100000000)

	// access token
	accessClams := CustomClaimsManager{
		ID:      uint64(randNum),
		ATI:     randStr,
		Subject: manageId,
		RoleID:  roleID,
		StandardClaims: jwt.StandardClaims{
			ExpiresAt: now.Add(2 * time.Hour).Unix(),    // 过期时间2小时
			IssuedAt:  now.Unix(),                       // 颁发时间
			NotBefore: now.Add(-2 * time.Second).Unix(), // 开始生效时间
		},
	}
	accessToken, err := j.CreateToken(accessClams)
	if err != nil {
		return "", "", ""
	}

	// refresh token
	refreshClams := CustomClaimsManager{
		ID:      uint64(randNum),
		ATI:     utils.FuncMD5(randStr + "refresh"),
		Subject: manageId,
		RoleID:  roleID,
		Type:    "refresh",
		StandardClaims: jwt.StandardClaims{
			ExpiresAt: now.Add(15 * 24 * time.Hour).Unix(), // 过期时间15天
			IssuedAt:  now.Unix(),                          // 颁发时间
			NotBefore: now.Add(-2 * time.Second).Unix(),    // 开始生效时间
		},
	}
	refreshToken, err := j.CreateToken(refreshClams)
	if err != nil {
		return "", "", ""
	}

	return accessToken, refreshToken, randStr
}
