package middleware

import (
	"bytes"
	"gamers/controller/response"
	"gamers/utils"
	"io/ioutil"
	"strconv"

	"github.com/gin-gonic/gin"
	"github.com/go-redis/redis"
)

//直播白名单接口
var liveWhitelistApi = []string{
	"/live/room-members-online",
	"/live/room-before-to-check",
	"/live/quit",
}

type roomReq struct {
	RoomId int `json:"room_id"`
}

func LiveAuth() gin.HandlerFunc {
	return func(c *gin.Context) {
		path := c.Request.URL.Path
		for _, v := range liveWhitelistApi {
			if v == path {
				c.Next()
			}
		}

		userId := utils.FuncUserId(c)
		body, _ := ioutil.ReadAll(c.Request.Body)                //储存body
		c.Request.Body = ioutil.NopCloser(bytes.NewBuffer(body)) //还原body
		r := roomReq{}
		c.ShouldBindJSON(&r)
		if r.RoomId == 0 {
			roomId := c.Query("room_id")
			if roomId != "" {
				r.RoomId, _ = strconv.Atoi(roomId)
			}
		}

		key := utils.REDIS_LIVE_FORBIDEN + strconv.Itoa(r.RoomId) + ":" + strconv.Itoa(int(userId))
		get, err := utils.RedisClient.Get(key).Result()
		if err != nil && err != redis.Nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "", "", err.Error())
			c.Abort()
			return
		}
		if get != "" {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "无权进入", "", "")
			c.Abort()
			return
		}
		c.Request.Body = ioutil.NopCloser(bytes.NewBuffer(body)) //因为c.ShouldBindJSON(&r)读取了body，这里需要再次还原
		c.Next()
	}
}
