package middleware

import (
	"fmt"
	"gamers/controller/response"
	"gamers/utils"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
)

//内网鉴权
func LocalNetwork() gin.HandlerFunc {
	return func(c *gin.Context) {
		apiIp := c.ClientIP() //请求ip
		ipSlice := strings.Split(apiIp, ".")
		ipInt := []int{}
		for _, v := range ipSlice {
			ato, _ := strconv.Atoi(v)
			ipInt = append(ipInt, ato)
		}
		//验证签名
		time := c.Request.Header.Get("Clienttime")
		signature := c.Request.Header.Get("Signature")
		if time != "" && signature != "" && signature == utils.FuncMD5(time+utils.Config.App.LocalKey) {
			c.Next()
		} else {
			fmt.Println(utils.FuncMD5(time + utils.Config.App.LocalKey))
			response.ResponseError(c, response.RESPONSE_PERMIT_ERROR, "无权访问", "", "")
			c.Abort()
			return
		}
	}
}
