package middleware

import (
	"fmt"
	"gamers/controller/response"
	"gamers/utils"

	"github.com/gin-gonic/gin"
)

//Recovery 捕获异常
func Recovery() gin.HandlerFunc {
	return func(c *gin.Context) {
		defer func() {
			if err := recover(); err != nil {
				//发送日志
				utils.Logger.Error(fmt.Sprintf("%s", err))
				response.ResponseError(c, response.RESPONSE_UNKNOWN, "服务器错误", "", fmt.Sprintf("%s", err))
				c.Abort()
				return
			}
		}()
		c.Next()
	}
}
