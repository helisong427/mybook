package controller

import (
	"gamers/controller/response"
	"gamers/models/dbmodels"

	"github.com/gin-gonic/gin"
)

// 获取版本信息
func GetParamList(c *gin.Context) {
	param, err := new(dbmodels.SystemParam).SearchList()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "获取系统参数失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "请求成功", param)
	return
}
