package controller

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/controller/services/recommend"
	"gamers/models/dbmodels"
	"gamers/utils"
	"os"

	"github.com/gin-gonic/gin"
)

//首页
func Index(c *gin.Context) {
	userId := utils.FuncUserId(c)
	r, err := services.Index(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取首页成功", r)
	return
}

//首页推荐
func IndexComment(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.IndexCommentReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}
	// userId := utils.FuncUserId(c)
	// r, err := services.IndexExclusiveRecommend(userId, paramsJSON.Page)
	list, err := recommend.NewRecommendPosition().GetExclusiveRecommend(paramsJSON.Page, userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取首页推荐成功", list)
	return
}

//首页参数接口
func IndexParams(c *gin.Context) {
	userId := utils.FuncUserId(c)
	r, err := services.IndexParams(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取首页参数成功", r)
}

// GetApk
func IndexGetApk(gctx *gin.Context) {
	channel, channelBool := gctx.GetQuery("channel")
	point, pointBool := gctx.GetQuery("point")
	pathName := "/gogo/apk/"
	if os.Getenv("GIN_CONFIG") == "staging" {
		pathName = "/gogo-staging/apk/"
	}
	varsionstr := "0"
	version, err := new(dbmodels.AppVersionLog).GetVersionLastByClient(1)
	if err == nil {
		varsionstr = version.Version
	}
	filePath := pathName + "chatgogo-v" + varsionstr
	if channelBool && channel != "" && pointBool && point != "" && point != "0" {
		filePath = filePath + "-" + channel + "-" + point
	} else if channelBool && channel != "" {
		filePath = filePath + "-" + channel
	}
	response.ResponseOk(gctx, "获取下载包成功", utils.Config.Tencent.CosBucketHost+filePath+".apk")
}
func IndexDownloadApk(gctx *gin.Context) {
	channel := gctx.Param("cid")
	point := gctx.Param("pid")
	pathName := "/gogo/apk/"
	if os.Getenv("GIN_CONFIG") == "staging" {
		pathName = "/gogo-staging/apk/"
	}
	varsionstr := "0"
	version, err := new(dbmodels.AppVersionLog).GetVersionLastByClient(1)
	if err == nil {
		varsionstr = version.Version
	}
	filePath := pathName + "chatgogo-v" + varsionstr
	if channel != "" && point != "" && point != "0" {
		filePath = filePath + "-" + channel + "-" + point
	} else if channel != "" && channel != "0" {
		filePath = filePath + "-" + channel
	}
	gctx.Redirect(302, utils.Config.Tencent.CosBucketHost+filePath+".apk")
	return
}
