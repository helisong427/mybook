package response

import "time"

type TaskSet struct {
	SetID         uint32      `json:"set_id"`
	SetName       string      `json:"set_name"`
	SetDesc       string      `json:"set_desc"`
	SetFlag       uint32      `json:"set_flag"`
	SetVerifyMode uint8       `json:"set_verify_mode"`
	SetShow       uint32      `json:"-"`
	SetSort       uint32      `json:"-"`
	SetStatus     uint8       `json:"set_status"`
	SetStartTime  uint32      `json:"set_start_time"`
	SetEndTime    uint32      `json:"set_end_time"`
	SetTasks      []*TaskTask `json:"set_tasks,omitempty"`
}

type TaskTask struct {
	TaskID             uint32        `json:"task_id"`
	TaskSetID          uint32        `json:"task_set_id"`
	TaskName           string        `json:"task_name"`
	TaskConditionTag   string        `json:"task_condition_tag"`
	TaskConditionCount uint32        `json:"task_condition_count"`
	TaskRewardQuota    uint32        `json:"task_reward_quota"`
	TaskIcon           string        `json:"task_icon"`
	TaskSort           uint32        `json:"task_sort"`
	TaskStatus         uint8         `json:"task_status"`
	TaskRewards        []*TaskReward `json:"task_rewards"`
	RecordState        uint32        `json:"record_state"`    // 任务状态(0:未完成;1:已完成;2:已领取)
	RecordProgress     uint32        `json:"record_progress"` // 任务进度
	RecordCurrent      bool          `json:"record_current"`  // 特殊的:签到时标识当前签到任务
}

type TaskReward struct {
	RewardID        uint32 `json:"reward_id,omitempty"`
	RewardTaskID    uint32 `json:"reward_task_id,omitempty"`
	RewardPropType  uint32 `json:"reward_prop_type"`
	RewardPropID    uint32 `json:"reward_prop_id"`
	RewardPropCount uint32 `json:"reward_prop_count"`
	PropName        string `json:"prop_name"`
	PropIcon        string `json:"prop_icon"`
}

// 任务数据
type TaskListData struct {
	GeneratedTime time.Time  `json:"-"`
	GeneratedAt   int64      `json:"generated_at"` // 生成时间戳
	List          []*TaskSet `json:"list"`
}

type TaskRewardGet struct {
	RewardPropType  uint32 `json:"reward_prop_type"`
	RewardPropID    uint32 `json:"reward_prop_id"`
	RewardPropCount uint32 `json:"reward_prop_count"`
	PropName        string `json:"prop_name"`
	PropIcon        string `json:"prop_icon"`
	PropRemark      string `json:"prop_remark"`
}

// 领取奖励
type TaskGetReward struct {
	SetID   uint32           `json:"set_id"`
	TaskID  uint32           `json:"task_id"`
	Rewards []*TaskRewardGet `json:"rewards"`
}

// 领取奖励（连续）
type TaskGetRewardCheckinContinuous struct {
	TaskGetReward
	Progress uint32 `json:"progress"` // 连续签到进度（签到第几天）
}
