package response

// InviteMessageResp 撩一撩邀请消息响应结构体
type InviteMessageResp struct {
	ReviewID     int64  `json:"review_id"`
	Content      string `json:"review_content"`       // 邀请消息内容
	RejectReason string `json:"review_reject_reason"` // 审核拒绝原因
	Status       int    `json:"review_status"`        // 审核状态
}
