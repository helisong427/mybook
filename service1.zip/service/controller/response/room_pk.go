package response

// pk时长
const (
	OneMinute     = 1
	FiveMinute    = 5
	TenMinute     = 10
	FifteenMinute = 15
	TwentyMinute  = 20
	Base          = 60
)

var PkTime = map[int]int{
	FiveMinute:    5 * Base,
	TenMinute:     10 * Base,
	FifteenMinute: 15 * Base,
	TwentyMinute:  20 * Base,
}

var AddTime = map[int]int{
	OneMinute: Base,
}

// 房间结算
type RoomSettleResp struct {
	RoomPKRecordResult int    `json:"room_pk_record_result"` // pk结果(1红方 2蓝方 3平局)
	RoomPkRecordDetail string `json:"room_pk_record_detail"` // pk详情
	RoomPKRecordPunish string `json:"room_pk_record_punish"` // pk惩罚

}
