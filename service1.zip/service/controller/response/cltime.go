package response

import (
	"fmt"
	"strings"
	"time"
)

type clTimer struct {
	TimeStamp int64 // 时间戳
	Hour      int   // 小时
	Minuter   int   // 分钟
	Second    int   // 秒数
	Year      int64 // 年份
	Month     int   // 月份
	Days      int   // 天数
	Week      int   // 周几，0=周一
}

func getTargetTime(timestamp int64) *time.Time {
	timedate := time.Unix(int64(timestamp), 0)
	utc := timedate.UTC().Add(-8 * time.Hour)
	loc, err := time.LoadLocation("Asia/Taipei")
	if err != nil {
		return nil
	}

	utcTime := utc.In(loc)
	return &utcTime
}

// 透过时间戳新建一个时间对象
func NewTime(timestamp int64) (*clTimer, error) {

	nowtime := getTargetTime(timestamp)

	weeks := 0
	switch strings.ToLower(nowtime.Weekday().String()) {
	case "monday":
		weeks = 0
	case "tuesday":
		weeks = 1
	case "wednesday":
		weeks = 2
	case "thursday":
		weeks = 3
	case "friday":
		weeks = 4
	case "saturday":
		weeks = 5
	case "sunday":
		weeks = 6
	}

	var cltimer = clTimer{
		TimeStamp: int64(nowtime.Unix()),
		Year:      int64(nowtime.Year()),
		Month:     int(nowtime.Month()),
		Days:      int(nowtime.Day()),
		Hour:      int(nowtime.Hour()),
		Minuter:   int(nowtime.Minute()),
		Second:    int(nowtime.Second()),
		Week:      int(weeks),
	}
	return &cltimer, nil
}

// 获取本月开始时间
// @return int64 当前时间的本月1号0时0分0秒的时间戳
// @return string 当前时间的本月1号0时0分0秒的日期时间格式
func (this *clTimer) GetCurMonth() ( /*timestamp*/ int64 /*datestr*/, string) {
	dateformat := fmt.Sprintf("%04v-%02v-01 00:00:00", this.Year, this.Month)
	targetTime := getNowTime(dateformat)
	return int64(targetTime.Unix()), targetTime.Format("2006-01-02 15:04:05")
}

// 获取UTC时间
// @param date string 时间日期格式
// @return *time.Time 返回这个日期格式生成的时间指针
func getNowTime(date string) *time.Time {

	dateTimeArr := strings.Split(date, " ")
	if date == "" || len(dateTimeArr) != 2 {
		date = time.Now().UTC().Add(8 * time.Hour).Format("2006-01-02 15:04:05")
	} else {
		now := time.Now()
		dateArr := strings.Split(dateTimeArr[0], "-")
		timeArr := strings.Split(dateTimeArr[1], ":")

		Year := dateArr[0]
		if Year == "Y" {
			Year = now.Format("2006")
		}
		Month := dateArr[1]
		if Month == "m" {
			Month = now.Format("01")
		}
		Day := dateArr[2]
		if Day == "d" {
			Day = now.Format("02")
		}
		Hour := timeArr[0]
		if Hour == "H" {
			Hour = now.Format("15")
		}
		Minute := timeArr[1]
		if Minute == "i" {
			Minute = now.Format("04")
		}
		Second := timeArr[2]
		if Second == "s" {
			Second = now.Format("05")
		}

		date = fmt.Sprintf("%v-%v-%v %v:%v:%v", Year, Month, Day, Hour, Minute, Second)
	}

	timedate, _ := time.Parse("2006-01-02 15:04:05", date)
	//utc := timedate.UTC().Add(-8 * time.Hour)
	////utc := timedate.UTC()
	//loc, err := time.LoadLocation("Asia/Taipei")
	//if err != nil {
	//	fmt.Printf("LoadLocation error: %v\n", err)
	//	return nil
	//}

	utcTime := timedate.UTC().Add(8 * time.Hour)
	return &utcTime
}
