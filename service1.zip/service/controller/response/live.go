package response

type AdminListRep struct {
	UserId           int64  `json:"user_id"`            //用户id
	UserNickName     string `json:"user_nick_name"`     //用户昵称
	UserIconurl      string `json:"user_iconurl"`       //用户头像
	UserGender       int    `json:"user_gender"`        //用户性别:0--未知,1--男,2--女
	UserAge          int    `json:"user_age"`           //用户年龄
	UserLevel        int    `json:"user_level"`         //用户等级
	UserOnlineStatus int    `json:"user_online_status"` //用户在线状态：0--不在线,1--在线
	UserRole         int    `json:"user_role"`          //用户角色:1--房间副管理员,2--房间管理员,3--房主
}

type HodUpAndOnWheatRep struct {
	WheatData      interface{} `json:"wheat_data"`       //麦位信息
	WheatQueueData interface{} `json:"wheat_queue_data"` //麦序信息
}

// 进入房间之前的房间校验
type JoinStudioBeforeCheckResp struct {
	RoomStatus     int    `json:"room_status"`      // 房间状态，0正常,1管理员(房主)关闭,2超时关闭,3平台整改,4平台封禁
	RoomType       int    `json:"room_type"`        // 类型(0音频直播,1音频派对)
	RoomLiveStatus int    `json:"room_live_status"` // 直播状态,直播类型才有效(0下播,1上播)
	ControlEndTime int64  `json:"control_end_time"` // 封禁，关闭整改操作等的截至时间
	CanJoin        int    `json:"can_join"`         // 是否能够进入房间 0为不能，1为能
	NeedPassword   int    `json:"need_password"`    // 是否需要密码，0为不需要，1为需要
	Role           int    `json:"role"`
	Password       string `json:"password"`
}

const (
	JOIN_ROOM_TYPE_CANT = iota // 不能进入房间
	JOIN_ROOM_TYPE_CAN         // 能进入房间
)
const (
	NEED_PASSWORD_NEED_NO = iota // 不需要密码
	NEED_PASSWORD_NEED           // 需要密码
)

type GetAnchorLiveIncomeResp struct {
	LiveIncome int64 `json:"live_income" gorm:"column:live_income"`
}

// 获取用户当前房间
type LastLiveRoomResp struct {
	RoomId int64 `json:"room_id"`
}
