/**
 * @Author: panke
 * @Description:
 * @File: turn_table
 * @Date: 2021/4/22 15:25
 */

package response

import (
	"gamers/utils/prop"
)

// 转盘配置
type TurnTableConfigResp struct {
	TurnTableConfigListResp []*TurnTableConfigListResp `json:"turn_table_config_list"` // 转盘配置
	AppTurnTableLog         []*TurnTableLogResp        `json:"turn_table_records"`     // 记录
}

// 转盘列表
type TurnTableConfigListResp struct {
	TurnTableID            int                    `json:"turn_table_id"`              // 转盘id
	TurnTableTitle         string                 `json:"turn_table_title"`           // 转盘名称
	TurnTableDesc          string                 `json:"turn_table_desc"`            // 转盘描述
	TurnTableCostPropType  int                    `json:"turn_table_cost_prop_type"`  // 消耗物品类型
	TurnTableCostPropID    int64                  `json:"turn_table_cost_prop_id"`    // 转盘道具id
	TurnTableCostPropCount int64                  `json:"turn_table_cost_prop_count"` // 单次消耗数量
	TurnTableRewardRate    []*TurnTableRewardRate `json:"turn_table_reward_rate"`     // 转盘奖励概率
	TurnTableStatus        int                    `json:"turn_table_status"`          // 状态
	TurnTableBg            string                 `json:"turn_table_bg"`              // 转盘背景图
}

// 转盘奖励概率
type TurnTableRewardRate struct {
	PropType     int    `json:"prop_type"`      // 物品类型
	PropId       int64  `json:"prop_id"`        // 物品Id
	PropName     string `json:"prop_name"`      // 物品名字
	PropPrice    int64  `json:"prop_price"`     // 物品价格
	PropOrgPrice int64  `json:"prop_org_price"` // 物品原价
	PropIcon     string `json:"prop_icon"`      // 物品图标
	Rate         string `json:"rate"`           // 0.35%
	RateValue    int64  `json:"rate_value"`     // 万分比
	RatePosition int64  `json:"rate_position"`  // 在转盘的位置
}

// 转盘抽奖resp
type TurnTableResp struct {
	TurnTableID            int                      `json:"turn_table_id"`              // 转盘id
	TurnTableCount         int                      `json:"turn_table_count"`           // 转盘次数
	TurnTableCostPropType  prop.Type                `json:"turn_table_cost_prop_type"`  // 消耗物品类型
	TurnTableCostPropID    int64                    `json:"turn_table_cost_prop_id"`    // 转盘道具id
	TurnTableCostPropCount int64                    `json:"turn_table_cost_prop_count"` // 单次消耗数量
	TurnTableDetails       []*TurnTableRewardDetail `json:"turn_table_details"`         // 抽奖详情(奖励列表)
	TurnTableTotalPrice    int64                    `json:"turn_table_total_price"`     // 获得物品总价值
	TurnTableTicket        int64                    `json:"turn_table_ticket"`          // 抽奖后抽奖券数量
}

// 转盘抽奖详情
type TurnTableRewardDetail struct {
	PropType        prop.Type `json:"prop_type"`  // 物品类型
	PropId          int       `json:"prop_id"`    // 物品ID
	PropCount       int       `json:"prop_count"` // 物品被抽到次数
	PropExpiredType int64     `json:"-"`          // 过期类型(0具体时间,1若干天后)
	PropExpiredTime int64     `json:"-"`          // 过期时间,根据limit_type确定
	PropOrgPrice    int64     `json:"-"`          // 价值(单价)
	PropGetRadio1   int64     `json:"-"`          // 获得物品是否全服广播(0不广告,1广播)
	PropName        string    `json:"prop_name"`  // 物品名字
	PropAttrId      int64     `json:"-"`          // 道具属性(礼物页签,对应app_prop_attr中的attr_id)
	PropIcon        string    `json:"prop_icon"`  // 物品图标
	PropDesc        string    `json:"prop_desc"`  // 物品描述
}

// 转盘记录 (仅用来暂存数据)
type TurnTableRecordsRep struct {
	TurnTableId int                `json:"turn_table_id"` // 转盘记录ID
	Records     []*TurnTableRecord `json:"records"`       // 转盘记录
}

type TurnTableRecordReward struct {
	PropType  int    `json:"prop_type"`  // 物品类型
	PropId    int    `json:"prop_id"`    // 物品ID
	PropCount int    `json:"prop_count"` // 物品被抽到次数
	PropPrice int64  `json:"prop_price"` // 商品价格
	PropName  string `json:"prop_name"`  // 物品名字
	PropIcon  string `json:"prop_icon"`  // 物品图标
}

type TurnTableRecord struct {
	LogRecordId       int64                    `json:"log_record_id"`        // 转盘记录id
	LogTurnTableCount int                      `json:"log_turn_table_count"` // 转盘次数(如：1次/10次/50次/100次)
	LogItemCount      int                      `json:"-"`                    // 奖励条目数（即 len(log_details)）
	LogDetails        []*TurnTableRecordReward `json:"log_details"`          // 转盘详细（奖励列表）
	Created           int64                    `json:"created"`              // 创建时间
	LogUserId         int64                    `json:"log_user_id"`          // 用户id
	LogUserName       string                   `json:"log_user_name"`        // 用户昵称
	// FOR QUERY
	LogPropType  int `json:"-"` // 物品类型(0礼物,1锤子,2go币)
	LogPropId    int `json:"-"` // 物品ID
	LogPropCount int `json:"-"` // 物品被抽到次数
}

type TurnTableLogResp struct {
	LogID             uint      `json:"log_id" gorm:"column:log_id"`
	LogRecordID       int64     `json:"log_record_id" gorm:"column:log_record_id"`               // 转盘记录id
	LogUserID         int64     `json:"log_user_id" gorm:"column:log_user_id"`                   // 用户id
	LogUserName       string    `json:"log_user_name"`                                           // 用户昵称
	LogTurnTableID    int       `json:"log_turn_table_id" gorm:"column:log_turn_table_id"`       // 转盘表的id
	LogTurnTableCount int       `json:"log_turn_table_count" gorm:"column:log_turn_table_count"` // 转盘次数(如：1次/10次/50次/100次)
	LogPropType       prop.Type `json:"log_prop_type" gorm:"column:log_prop_type"`               // 物品类型(0go币,1礼物,2锤子,3头像框,4聊天框,5座驾,6活动道具,7实物道具,8Go币道具)
	LogPropID         int       `json:"log_prop_id" gorm:"column:log_prop_id"`                   // 物品ID
	LogPropName       string    `json:"log_prop_name"`                                           // 物品名称
	LogPropCount      int       `json:"log_prop_count" gorm:"column:log_prop_count"`             // 物品被抽到次数
	Created           int64     `json:"created"`                                                 // 创建时间
}
