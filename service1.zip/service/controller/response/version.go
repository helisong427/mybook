package response

import "encoding/json"

type GetVersionInfoResp struct {
	VersionInfo *VersionInfo `json:"version_info"`
}

type VersionInfo struct {
	LogId       int64  `gorm:"column:log_id;primaryKey;autoIncrement" json:"version_id"` // id
	Version     string `gorm:"column:log_version" json:"version"`                        // 版本号
	Tips        string `gorm:"column:log_tips" json:"tips"`                              // 更新tips
	CheckSwitch int    `gorm:"column:log_check_switch" json:"check_switch"`              // 检查开关
	MustUpdate  int    `gorm:"column:log_must_update" json:"must_update"`                // 是否强更
	Client      int    `gorm:"column:log_client" json:"client"`                          // 客户端，1安卓，2为ios
	Url         string `json:"url" gorm:"column:log_url"`
}

func (s *VersionInfo) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s VersionInfo) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}
