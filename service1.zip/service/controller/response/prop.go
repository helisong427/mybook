package response

import (
	"encoding/json"
	"gamers/enum"
	"gamers/utils"
	"gamers/utils/ymd"
	"gorm.io/gorm"
	"time"
)

type GetGiftResp struct {
	PropId           int64  `gorm:"column:prop_id;primaryKey;autoIncrement" json:"prop_id"` // 道具id
	PropName         string `gorm:"column:prop_name" json:"prop_name"`                      // 礼物名称
	PropType         int    `gorm:"column:prop_type" json:"prop_type"`                      // 道具类型(1礼物,2锤子,3头像框,4聊天框,5座驾,6活动道具,7实物道具,8Go币道具)
	PropClass        int    `gorm:"column:prop_class" json:"prop_class"`                    // 礼物类型(0正常礼物,1免费倒计时礼物,2限时购买礼物) 用于送礼物区分
	PropAttrId       int64  `gorm:"column:prop_attr_id" json:"prop_attr_id"`                // 道具属性(礼物页签,对应app_prop_attr中的attr_id)
	PropLevel        int64  `gorm:"column:prop_level" json:"prop_level"`                    // 礼物抽成类型(0普通礼物,1冠名礼物 )
	PropPrice        int64  `gorm:"column:prop_price" json:"prop_price"`                    // 代币价格
	PropOrgPrice     int64  `gorm:"column:prop_org_price" json:"prop_org_price"`            // 原价
	PropVipLevel     int64  `gorm:"column:prop_vip_level" json:"prop_vip_level"`            // 需要解锁的vip等级
	PropInterval     int64  `gorm:"column:prop_interval" json:"prop_interval"`              // 免费礼物时间间隔单位秒
	PropGetMax       int64  `gorm:"column:prop_get_max" json:"prop_get_max"`                // 每天免费获取上限
	PropRadioCount1  int64  `gorm:"column:prop_radio_count1" json:"prop_radio_count_1"`     // 本房间广播数量
	PropRadioCount2  int64  `gorm:"column:prop_radio_count2" json:"prop_radio_count_2"`     // 同标签广播数量
	PropRadioCount3  int64  `gorm:"column:prop_radio_count3" json:"prop_radio_count_3"`     // 全服广播数量
	PropIcon         string `gorm:"column:prop_icon" json:"prop_icon"`                      // 礼物图标
	PropUrl          string `gorm:"column:prop_url" json:"prop_url"`                        // 礼物url 特效地址
	PropUrl1         string `gorm:"column:prop_url1" json:"prop_url1"`                      // 礼物url1 特效地址
	PropQuickCount   string `gorm:"column:prop_quick_count" json:"-"`                       // 快捷送礼数量josn数组
	PropQuick        []int  `gorm:"-" json:"prop_quick_count"`                              // 快捷送礼数量josn数组
	PropStartTime    int64  `gorm:"column:prop_start_time" json:"prop_start_time"`          // 开启购买时间
	PropEndTime      int64  `gorm:"column:prop_end_time" json:"prop_end_time"`              // 结束购买时间
	PropSpecialLevel int64  `gorm:"column:prop_special_level" json:"prop_special_level"`    // 礼物特效等级(1最初级 数字越大越高级)
	PropExpiredType  int64  `gorm:"column:prop_expired_type" json:"prop_expired_type"`      // 过期类型(0具体时间,1若干天后)
	PropExpiredTime  int64  `gorm:"column:prop_expired_time" json:"prop_expired_time"`      // 过期时间,根据limit_type确定
	PropAddIcon      string `gorm:"column:prop_add_icon" json:"prop_add_icon"`              // 附属icon
	WeekStarIcon     int64  `gorm:"-" json:"week_star_icon"`                                // 周星榜 角标
	PropRemark       string `gorm:"column:prop_remark" json:"prop_remark"`                  // 物品描述
	PropSort         int64  `gorm:"column:prop_sort" json:"prop_sort"`                      // 物排序,从小到大
}

func (b *GetGiftResp) TableName() string {
	return "app_prop"
}

func (v *GetGiftResp) AfterFind(tx *gorm.DB) (err error) {
	var (
		list []int
	)
	if v.PropQuickCount != "" {
		err = json.Unmarshal([]byte(v.PropQuickCount), &list)
		if err != nil {
			return err
		}
		v.PropQuick = list
	} else {
		v.PropQuick = []int{}
	}

	handleGiftIcon(v)

	return
}

func handleGiftIcon(v *GetGiftResp) {
	var (
		nowGiftList string
		lockName    string
		ok          bool
		err         error
		result      *AppWeekStarResultItem
	)

	if lockName, ok = utils.AcquireLock(enum.REDIS_WEEK_STAR_LOCK, enum.REDIS_WEEK_STAR_LOCK_TIMEOUT, enum.REDIS_WEEK_STAR_LOCK_FORCE_TIMEOUT); ok {
		// 如果加锁成功, 则设置解锁
		defer func() {
			utils.ReleaseLock(enum.REDIS_WEEK_STAR_LOCK, lockName)
		}()
	}
	// 从 redis获取活动礼物ID
	if nowGiftList = utils.RedisClient.Get(enum.REDIS_WEEK_STAR_NOW_GIFT_LIST).Val(); nowGiftList != "" {

		if handleGiftList(nowGiftList, v.PropId) {
			v.WeekStarIcon = 1
		}

		return
	}

	nowTime := time.Now().Unix()

	// 如果没有, 则从数据库获取 当前活动列表, 并且存入 redis设置过期时间
	if result, err = GetByNowTime(nowTime); err != nil {
		utils.Logger.Error(err.Error())
		return
	}

	if result.WeekStarGift == "" {
		return
	}

	expireTime := ymd.GetToday24TimeStamp() - nowTime

	if err = utils.RedisClient.Set(enum.REDIS_WEEK_STAR_NOW_GIFT_LIST, result.WeekStarGift, time.Second*time.Duration(expireTime)).Err(); err != nil {
		utils.Logger.Error(err.Error())
		return
	}

	if handleGiftList(nowGiftList, v.PropId) {
		v.WeekStarIcon = 1
	}
}

func handleGiftList(nowGiftList string, propId int64) (ok bool) {
	var (
		propIds []int64
		err     error
	)

	ok = false

	if err = json.Unmarshal([]byte(nowGiftList), &propIds); err != nil {
		return
	}

	for _, v := range propIds {
		if v == propId {
			ok = true
			return
		}
	}

	return
}

type AppWeekStarResultItem struct {
	WeekStarGift string `json:"week_star_gift"` // 周星榜礼物列表
}

// 通过 当前时间 获取 记录
func GetByNowTime(timeStamp int64) (result *AppWeekStarResultItem, err error) {
	var (
		data AppWeekStarResultItem
	)

	if err = utils.GEngine.Table("app_week_star").Where("deleted = 0").
		Where("week_star_start_time <= ?", timeStamp).
		Where("week_star_end_time >= ?", timeStamp).
		Where("week_star_status = 1").
		First(&data).Error; err != nil {
		if err == gorm.ErrRecordNotFound {
			err = nil
		}
	}

	result = &data

	return
}

// 用户钱包信息
type UserOverRep struct {
	WalletTotalOver int64 `gorm:"column:wallet_total_over" json:"user_over"` // 总余额(可用代币数)
}

// 获取背包礼物信息
type BackGiftResp struct {
	BackpackId          int64       `gorm:"column:backpack_id;primaryKey;autoIncrement" json:"backpack_id"`
	BackpackUserId      int64       `gorm:"column:backpack_user_id" json:"backpack_user_id"`             // 用户id
	BackpackPropType    int         `gorm:"column:backpack_prop_type" json:"backpack_prop_type"`         // 道具类型(1礼物,2锤子,3头像框,4聊天框,5座驾,6活动道具,7实物道具,8Go币道具)
	BackpackPropId      int64       `gorm:"column:backpack_prop_id" json:"backpack_prop_id"`             // 道具id(更加type来区分不同)
	BackpackCount       int64       `gorm:"column:backpack_count" json:"backpack_count"`                 // 道具数量
	BackpackPropAttrId  int64       `gorm:"column:backpack_prop_attr_id" json:"backpack_prop_attr_id"`   // 道具属性id
	BackpackExpiredTime int64       `gorm:"column:backpack_expired_time" json:"backpack_expired_time"`   // 过期时间如果为0表示永不过期
	AppProp             GetGiftResp `gorm:"foreignKey:PropId;references:BackpackPropId" json:"app_prop"` // 关联道具表
}
