package response

//ArticleListRep
type ArticleListRep struct {
	ArticleID           int64  `json:"article_id"`
	ArticleCategoryID   int64  `json:"article_category_id"`
	ArticleTitle        string `json:"article_title"`
	ArticleTitleImage   string `json:"article_title_image"`
	ArticleContentImage string `json:"article_content_image"`
	ArticleContent      string `json:"article_content"`
	ArticleUrl          string `json:"article_url"`
	ArticleStatus       int    `json:"article_status"`
	ArticleOrder        int64  `json:"article_order"`
	ArticleIntroduction string `json:"article_introduction"`
	Created             int64  `json:"created"`
	Edited              int64  `json:"edited"`
	Deleted             int64  `json:"deleted"`
}
