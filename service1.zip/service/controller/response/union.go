package response

type UnionSearchItem struct {
	UnionID            int64  `json:"union_id"`
	UnionCode          uint64 `json:"union_code"`
	UnionName          string `json:"union_name"`
	UnionInviteKey     string `json:"union_invite_key"`
	ApplyForJoinStatus int64  `json:"apply_for_join_status"`
}

type UnionSearch struct {
	List []*UnionSearchItem `json:"list"`
}
