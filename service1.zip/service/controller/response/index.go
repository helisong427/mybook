package response

// 首页参数
type IndexParamsRep struct {
	TagId         int         `json:"tag_id"`          // tag_id
	TagName       string      `json:"tag_name"`        // 名称
	TagParams     interface{} `json:"tag_params"`      // 参数
	UserGameOrder []int       `json:"user_game_order"` // 用户常用游戏
}

// 首页
type IndexRep struct {
	SparringList []SearchRecommendSparring `json:"sparring_list"` // 大神推荐列表
	AdList       []AdList                  `json:"ad_list"`       // 公告图列表
	SkillList    []SkillList               `json:"skill_list"`    // 游戏列表
}

// banner列表
type AdList struct {
	AdId       int64       `json:"ad_id"`
	AdName     string      `json:"ad_name"`      // 广告名称
	AdContent  string      `json:"ad_content"`   // 广告内容
	AdUrl      string      `json:"ad_url"`       // 广告跳转链接
	AdJumpType int64       `json:"ad_jump_type"` // 跳转类型:0--网站跳转,1--app内跳转
	AdURLParam interface{} `json:"ad_url_param"` // AdURL 广告跳转参数
}

// 游戏列表
type SkillList struct {
	SkillId      int64  `json:"skill_id"`      // 游戏id
	SkillName    string `json:"skill_name"`    // 游戏名称
	SkillIconurl string `json:"skill_iconurl"` // 游戏icon
}

// 首页推荐model
type IndexRecommendModel struct {
	Type          int         `json:"type"`                     // 类型:0--派对，1--直播，2--大神，3--视频，4--图片
	PartModel     interface{} `json:"part_model,omitempty"`     // 派对
	LiveModel     interface{} `json:"live_model,omitempty"`     // 直播
	SparringModel interface{} `json:"sparring_model,omitempty"` // 大神
	TweetModel    interface{} `json:"tweet_model,omitempty"`    // 朋友圈
}

// 搜索推荐房间列表
type IndexRecommendPart struct {
	RoomId         int64  `json:"room_id"`          // 房间id
	RoomType       int    `json:"room_type"`        // 类型(0音频直播,1音频派对)
	RoomName       string `json:"room_name"`        // 房间名称
	RoomCover      string `json:"room_cover"`       // 房间封面
	RoomAttrId     int64  `json:"room_attr_id"`     // 房间属性(唱歌,脱口秀)
	RoomAttrName   string `json:"room_attr_name"`   // 房间属性名称(唱歌,脱口秀)
	RoomSpeakType  int    `json:"room_speak_type"`  // 麦位模式(0音频直播无麦位,1音频直播有麦位,2音频派对自由模式,3音频派对麦序模式)
	RoomLiveStatus int    `json:"room_live_status"` // 直播状态,直播类型才有效(0下播,1上播)
	UserIconurl    string `json:"user_iconurl"`     // 用户头像
	UserNickname   string `json:"user_nickname"`    // 用户昵称
	Hot            int    `json:"hot"`              // 热度
	RoomPkState    int64  `json:"room_pk_state"`    // 房间pk状态(0关闭 1准备 2开始 3惩罚)
	// WheatList      []string `json:"wheat_list"`       //麦位头像
}

// 搜索推荐房间列表
type IndexRecommendLive struct {
	RoomId         int64  `json:"room_id"`          // 房间id
	RoomType       int    `json:"room_type"`        // 类型(0音频直播,1音频派对)
	RoomName       string `json:"room_name"`        // 房间名称
	RoomCover      string `json:"room_cover"`       // 房间封面
	RoomAttrId     int64  `json:"room_attr_id"`     // 房间属性(唱歌,脱口秀)
	RoomAttrName   string `json:"room_attr_name"`   // 房间属性名称(唱歌,脱口秀)
	RoomSpeakType  int    `json:"room_speak_type"`  // 麦位模式(0音频直播无麦位,1音频直播有麦位,2音频派对自由模式,3音频派对麦序模式)
	RoomLiveStatus int    `json:"room_live_status"` // 直播状态,直播类型才有效(0下播,1上播)
	UserIconurl    string `json:"user_iconurl"`     // 用户头像
	UserNickname   string `json:"user_nickname"`    // 用户昵称
	Hot            int    `json:"hot"`              // 热度
}

// 首页推荐大神
type IndexRecommendSparring struct {
	SparringId   int64  `json:"sparring_id"`
	SkillName    string `json:"skill_name"`    // 游戏名称
	SkillType    int    `json:"skill_type"`    // 游戏类型(0游戏,1娱乐)
	SkillIconurl string `json:"skill_iconurl"` // 游戏icon
	SkillInfo    string `json:"skill_info"`    // 技能介绍
	UserId       int64  `json:"user_id"`       // 用户id
	UserNickname string `json:"user_nickname"` // 昵称
	UserIconurl  string `json:"user_iconurl"`  // 头像
	PriceWay     string `json:"price_way"`     // 陪玩方式
	PricePrice   int    `json:"price_price"`   // 技能价格
}

// 首页推荐朋友圈
type IndexRecommendTweet struct {
	TweetId         int64              `json:"tweet_id"`
	TweetType       int                `json:"tweet_type"` // 朋友圈类型(1图片,2视频)
	TweetContent    string             `json:"tweet_content"`
	TweetAttachment []TweetAttachments `json:"tweet_attachment"`
	TweetLikeCount  int64              `json:"tweet_like_count"`
	IsLike          int                `json:"is_like"` // 是否点赞
	UserInfo        TweetUserInfo      `json:"user_info"`
}
