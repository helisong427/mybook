package response

type GetPkTimeResp struct {
	PkTime  []int `json:"pk_time"`
	AddTime []int `json:"add_time"`
}

const (
	PK_TIME_CHOOSE_PKTIME = iota
	PK_TIME_CHOOSE_ADDTIME
)

// 校验时间参数
func (r *GetPkTimeResp) Validate(choose, chooseType int) (duration int, validate bool) {
	if chooseType == PK_TIME_CHOOSE_PKTIME {
		for _, v := range r.PkTime {
			if v == choose {
				validate = true
				duration = v * 60
				return
			}
		}
	}
	if chooseType == PK_TIME_CHOOSE_ADDTIME {
		for _, v := range r.AddTime {
			if v == choose {
				validate = true
				duration = v * 60
				return
			}
		}
	}
	return
}
