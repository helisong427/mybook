package response

import (
	"encoding/json"
	"gamers/utils"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
)

// 定义错误码
const (
	RESPONSE_SUCCESS                         int = 0     //成功
	RESPONSE_UNKNOWN                         int = 20000 //未知错误,服务不可用
	RESPONSE_AUTH_ERROR                      int = 20001 //授权权限错误
	RESPONSE_PARAM_ERROR                     int = 20002 //非法的参数
	RESPONSE_PERMIT_ERROR                    int = 20003 //权限不足
	RESPONSE_AUTH_TIME_OUT                   int = 20004 //登录过期
	RESPONSE_AUTH_TOKEN_NULL                 int = 20005 //redis中没有token
	RESPONSE_USER_STATUS_ERROR               int = 20006 //查询的用户信息异常
	RESPONSE_BUSINESS_ERROR                  int = 30000 //业务处理失败
	RESPONSE_LIVE_ERROR                      int = 40000 //直播处理失败
	RESPONSE_BALANCE_ERROR                   int = 50000 //余额不足
	RESPONSE_Invite_Message_Edit_StatusERROR int = 60000 // 撩一撩邀请消息，今日用户修改次数已达上限。
)

var responseMap = map[int]string{
	RESPONSE_SUCCESS:           "成功",
	RESPONSE_UNKNOWN:           "未知错误,服务不可用",
	RESPONSE_AUTH_ERROR:        "授权权限错误",
	RESPONSE_PARAM_ERROR:       "非法的参数",
	RESPONSE_USER_STATUS_ERROR: "查询的用户信息异常",
	RESPONSE_PERMIT_ERROR:      "权限不足",
	RESPONSE_AUTH_TIME_OUT:     "登录过期",
	RESPONSE_BUSINESS_ERROR:    "服务器错误",
	RESPONSE_LIVE_ERROR:        "直播处理失败",
	RESPONSE_BALANCE_ERROR:     "余额不足",
}

// Response 返回结果 结构体
type Response struct {
	Code       int         `json:"code"`
	Message    string      `json:"message"`
	SubCode    string      `json:"subcode"`
	SubMessage string      `json:"submessage"`
	Data       interface{} `json:"data"`
}

//ResponseOk 正确时返回
func ResponseOk(c *gin.Context, message string, data interface{}) {
	if message == "" {
		message = responseMap[RESPONSE_SUCCESS]
	}
	r := Response{
		Code:    RESPONSE_SUCCESS,
		Message: message,
		Data:    data,
		SubCode: time.Now().Format("2006-01-02 15:04:05"),
	}
	responseLog(r, c)
	c.JSON(http.StatusOK, r)
}

//ResponseError 错误时返回
func ResponseError(c *gin.Context, code int, message string, subCode string, subMessage string) {
	if message == "" {
		message = responseMap[code]
	}

	r := Response{
		Code:       code,
		Message:    message,
		SubCode:    subCode,
		SubMessage: subMessage,
		Data:       nil,
	}
	responseLog(r, c)
	c.JSON(http.StatusOK, r)
}

// 返回错误状态码
func ResponseErrorWithCode(c *gin.Context, httpCode, messageCode int, message string, subMessage string) {
	if message == "" {
		message = responseMap[RESPONSE_SUCCESS]
	}
	r := Response{
		Code:       messageCode,
		Message:    message,
		SubMessage: subMessage,
		Data:       nil,
		SubCode:    time.Now().Format("2006-01-02 15:04:05"),
	}
	responseLog(r, c)
	c.JSON(httpCode, r)
}

type BasePageList struct {
	Page       int         `json:"page"`        //当前页
	Size       int         `json:"size"`        //每页条数
	Total      int64       `json:"total"`       //总条数
	TotalPages int         `json:"total_pages"` //总页数
	List       interface{} `json:"list"`        //数据列表
}

func responseLog(res Response, gct *gin.Context) {
	GetQueryid, boolValue := gct.Get("SYSTEMQUERYID")
	queryid := ""
	if boolValue {
		queryid = GetQueryid.(string)
	}

	log, _ := json.Marshal(res)
	if gct.Request.URL.Path != "livez" && res.Message != "地址不存在" { //空路由不写入日志
		utils.Logger.Info(string(log),
			utils.LoggerAddString("Url", gct.Request.RequestURI),
			utils.LoggerAddString("Type", "response"),
			utils.LoggerAddString("Queryid", queryid),
		)
	}
}
