package response

import (
	"gorm.io/gorm"
	"time"
)

// 获取私聊界面上面的订单和技能信息
type MsgSparringAndOrderInfoResp struct {
	Orders      []MsgOrderInfo `json:"orders"` //  订单信息
	Skills      []MsgSKillInfo `json:"skills"` // 技能信息
	IsAttention int64          `json:"is_attention"`
}

type MsgOrderInfo struct {
	OrderId              int64          `json:"order_id"`                                                      // 订单id
	OrderSparringSkillId int64          `gorm:"column:order_sparring_skill_id" json:"order_sparring_skill_id"` // 大神基恩那个id
	OrderStatus          int            `json:"order_status"`                                                  // 订单状态(0待接单,1已接单,2已取消,3买家确认完成,4卖家确认完成
	OrderPayStatus       int            `gorm:"column:order_pay_status" json:"order_pay_status"`               // 支付状态(0待付款,1付款中,2已付款)
	OrderConfirmStatus   int            `gorm:"column:order_confirm_status" json:"order_confirm_status"`       // 接单状态(0待接单,1大神拒绝,2大神结单,3大神完成)
	OrderCancelStatus    int            `gorm:"column:order_cancel_status" json:"order_cancel_status"`
	OrderRefundStatus    int            `json:"order_refund_status"`                                     // 退款状态
	OrderAppealStatus    int            `json:"order_appeal_status"`                                     // 申诉状态(0未申诉,1申诉中,2待处理,3处理完成)
	OrderFinishStatus    int            `gorm:"column:order_finish_status" json:"order_finish_status"`   // 完成状态(0未完成,1系统自动完成,3玩家完成)
	OrderCommentStatus   int            `gorm:"column:order_comment_status" json:"order_comment_status"` // 评价状态(0待评价,1玩家已评价,2大神已评价)
	OrderSettleStatus    int            `gorm:"column:order_settle_status" json:"order_settle_status"`   // 订单结算(提取)状态(0未结算,1系统自动已结算,2客服结算)
	OrderBuyUserId       int64          `gorm:"column:order_buy_user_id" json:"order_buy_user_id"`       // 购买用户id
	OrderSellUserId      int64          `gorm:"column:order_sell_user_id" json:"order_sell_user_id"`     // 出售订单用户id
	OrderSkillId         int64          `gorm:"column:order_skill_id" json:"order_skill_id"`             // 购买的技能id
	OrderRefundCount     int            `gorm:"column:order_refund_count" json:"order_refund_count"`     // 退款申请次数
	SkillInfo            OrderSkillInfo `json:"skill_info" gorm:"foreignKey:SkillId;references:OrderSkillId"`
	OrderPrice           int64          `json:"order_price"`        // 单价
	OrderWay             string         `json:"order_way"`          // 订单单位
	OrderCount           int64          `json:"order_count"`        // 订单购买数量
	OrderAmount          int64          `json:"order_amount"`       // 收入
	Countdown            int64          `json:"countdown" gorm:"-"` // 倒计时
	Created              int64          `json:"created"`            // 订单生成时间
}

// 技能信息
type MsgSKillInfo struct {
	SparringId int64  `json:"sparring_id"` // 大神用户id
	SkillName  string `json:"skill_name"`  // 大神昵称
	SkillIcon  string `json:"skill_icon"`  // 游戏icon
	PriceWay   string `json:"price_way"`   // 陪玩方式
	PricePrice int64  `json:"price_price"` // 技能价格
}

func (u *MsgOrderInfo) AfterFind(tx *gorm.DB) (err error) {
	duration := (u.Created + DEFAULT_SKILL_ORDER_ORDER_TIME) - time.Now().Unix()
	if duration < 0 {
		duration = 0
	}
	u.Countdown = duration
	return
}

const (
	BLACKLIST_USER_STATUS_INIT = iota
	BLACKLIST_USER_STATUS_TRUE
)

// 用户信息
type MsgUserInfoResp struct {
	UserId       int64  `json:"user_id"`                              // 用户id
	UserPrettyID int64  `json:"user_pretty_id"`                       // 用户靓号
	Nickname     string `json:"nickname" gorm:"column:user_nickname"` // 昵称
	Gender       int    `json:"gender" gorm:"column:user_gender"`     // 性别
	Iconurl      string `json:"iconurl" gorm:"column:user_iconurl"`   // 头像
	UserBirthday int64  `gorm:"column:user_birthday" json:"-"`        // 出生年月日
	Age          int    `json:"age" gorm:"-"`                         // 年龄
	IsBlack      int    `json:"is_black" gorm:"-"`
	VipLevel     int    `json:"vip_level" gorm:"-"`
}

// 技能订单返回
type SkillOrderMsgResp struct {
	OrderId              int64          `json:"order_id"`                                                      // 订单id
	Remark               string         `json:"remark" gorm:"column:order_remark"`                             // 备注
	OrderSparringSkillId int64          `gorm:"column:order_sparring_skill_id" json:"order_sparring_skill_id"` // 大神基恩那个id
	OrderStatus          int            `json:"order_status"`                                                  // 订单状态(0待接单,1已接单,2已取消,3买家确认完成,4卖家确认完成
	OrderConfirmStatus   int            `gorm:"column:order_confirm_status" json:"order_confirm_status"`       // 接单状态(0待接单,1大神拒绝,2大神结单,3大神完成)
	OrderBuyUserId       int64          `gorm:"column:order_buy_user_id" json:"-"`                             // 购买用户id
	OrderSkillId         int64          `gorm:"column:order_skill_id" json:"-"`                                // 购买的技能id
	BuyerInfo            OrderUserInfo  `json:"buyer_info" gorm:"foreignKey:UserId;references:OrderBuyUserId"` // 买家信息
	SkillInfo            OrderSkillInfo `json:"skill_info" gorm:"foreignKey:SkillId;references:OrderSkillId"`  // 技能信息
	OrderPrice           int64          `json:"order_price"`                                                   // 单价
	OrderWay             string         `json:"order_way"`                                                     // 订单单位
	OrderCount           int64          `json:"order_count"`                                                   // 订单购买数量
	OrderAmount          int64          `json:"order_amount"`                                                  // 收入
	OrderTime            int64          `gorm:"column:order_time" json:"order_time"`                           // 陪玩方式   时长  单位秒
	Countdown            int64          `json:"countdown" gorm:"-"`                                            // 倒计时
	Created              int64          `json:"created"`                                                       //订单生成时间
	EntT                 int64          `json:"ent_t" gorm:"-"`
}

func (u *SkillOrderMsgResp) AfterFind(tx *gorm.DB) (err error) {
	duration := (u.Created + DEFAULT_SKILL_ORDER_ORDER_TIME) - time.Now().Unix()
	if duration < 0 {
		duration = 0
	}
	u.EntT = u.Created + DEFAULT_SKILL_ORDER_ORDER_TIME
	u.Countdown = duration
	return
}
