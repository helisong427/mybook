package response

//添加返回
type AddTopicRep struct {
	TopicID    int64  `json:"topic_id"`
	TopicTitle string `json:"topic_title"`
}

//获取热门话题返回
type GetHotTopic struct {
	List []AddTopicRep `json:"list"`
}

//搜索话题
type SearchTopic struct {
	IsSearch int           `json:"is_search"`
	List     []AddTopicRep `json:"list"`
}
