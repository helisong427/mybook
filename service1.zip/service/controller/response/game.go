package response

// 游戏列表
type GameInfoRep struct {
	GameId      int64       `json:"game_id" json:"game_id"`
	GameName    string      `json:"game_name" json:"game_name"`
	GameType    int         `json:"game_type" json:"game_type"`
	GameIconurl string      `json:"game_iconurl" json:"game_iconurl"`
	GameParam   interface{} `json:"game_param" json:"game_param,omitempty" gorm:"-"`
}

// 游戏列表分组
type QueryGameRep struct {
	GameType int           `json:"game_type" json:"game_type" gorm:"column:game_type"`
	Games    []GameInfoRep `json:"games" json:"games"`
}
