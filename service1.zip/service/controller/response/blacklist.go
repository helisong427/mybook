package response

import (
	"gamers/utils"
	"gorm.io/gorm"
)

type GetBlacklistResp struct {
	BlacklistId          int64             `gorm:"column:blacklist_id;primaryKey;autoIncrement" json:"blacklist_id"`     // 黑名单自增主键
	BlacklistUserId      int64             `gorm:"column:blacklist_user_id" json:"blacklist_user_id"`                    // 拉黑用户
	BlacklistBlackUserId int64             `gorm:"column:blacklist_black_user_id" json:"-"`                              // 被拉黑的用户id
	BlackUser            BlacklistUserInfo `gorm:"foreignKey:BlacklistBlackUserId;references:UserId;" json:"black_user"` //关注列表
	Created              int64             `json:"created" gorm:"column:edited"`
}

// 拉黑人员信息
type BlacklistUserInfo struct {
	UserId   int64  `json:"user_id" gorm:"column:user_id"`
	Icon     string `json:"icon" gorm:"column:user_iconurl"`      // 用户头像
	Nickname string `json:"nickname" gorm:"column:user_nickname"` // 昵称
	Gender   int    `json:"gender" gorm:"column:user_gender"`     // 用户性别0未知,1男,2女
	Birthday int64  `json:"-" gorm:"column:user_birthday"`        // 出生年月日
	Age      int    `json:"age" gorm:"-"`                         // 出生年月日
}

func (u *GetBlacklistResp) AfterFind(tx *gorm.DB) (err error) {
	u.BlackUser.Age = utils.FuncGetAge(int(u.BlackUser.Birthday))
	return
}
