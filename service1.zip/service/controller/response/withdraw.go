package response

//提现首页
type WithdrawHomeRep struct {
	IsRealName       int                `json:"is_real_name"`      //是否实名
	IsLiving         int                `json:"is_living"`         //是否活体认证
	WithdrawAmount   int64              `json:"withdraw_amount"`   //提现金额
	RealName         string             `json:"real_name"`         //真实姓名
	WithdrawBankcard []WithdrawBankcard `json:"withdraw_bankcard"` //提现银行卡
	IsWithdrawIng    int                `json:"is_withdraw_ing"`   //是否提现中
}

//提现银行卡
type WithdrawBankcard struct {
	BankcardId          int64       `json:"bankcard_id"`
	BankcardAccountType int         `json:"bankcard_account_type"`
	BankcardAccountInfo interface{} `json:"bankcard_account_info"`
	BankcardDefault     int64       `json:"bankcard_default"`
}
