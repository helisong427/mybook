package response

type GetVipPrivilegeResp struct {
	PrivilegeId      int64  `gorm:"column:privilege_id;primaryKey;autoIncrement" json:"privilege_id"`
	PrivilegeTitle   string `gorm:"column:privilege_title" json:"privilege_title"`     // 特权title
	PrivilegeIcon    string `gorm:"column:privilege_icon" json:"privilege_icon"`       // 特权icon
	PrivilegeContent string `gorm:"column:privilege_content" json:"privilege_content"` // 特权内容
	PrivilegeLevel   int    `gorm:"column:privilege_level" json:"privilege_level"`     // 解锁需要的vip等级
}

// 个人信息
type GetUserVipInfo struct {
	UserId              int64  `gorm:"column:experience_user_id" json:"user_id"`
	Icon                string `json:"icon"`
	Nickname            string `json:"nickname"`
	ExperienceValue     int64  `gorm:"column:experience_value" json:"experience_value"`
	ExperienceNextValue int64  `gorm:"column:experience_next_value" json:"experience_next_value"`
	VipLevel            int    `gorm:"column:experience_level" json:"vip_level"`
}
