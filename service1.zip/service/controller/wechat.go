package controller

import (
	"encoding/json"
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/models/dbmodels"
	"gamers/utils/wechat"
	"github.com/gin-gonic/gin"
)

//公众号获取code地址
func WechatCodeUrl(c *gin.Context) {

	channel, err := new(dbmodels.AppTransactionChannel).QueryKey(dbmodels.TRANSACTION_CHANNEL_KEY_WECHATJSAPIPAY)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
	}
	wechatJSAPIPayParam := dbmodels.ChannelWechatJSAPIPayParam{}
	err = json.Unmarshal([]byte(channel["param"]), &wechatJSAPIPayParam)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
	}

	url := wechat.NewWechat(wechatJSAPIPayParam.AppId, wechatJSAPIPayParam.Secret, wechatJSAPIPayParam.RedirectURL).GetCode()
	response.ResponseOk(c, "获取code地址成功", gin.H{"url": url})
}

//公众号获取AccessToke地址
func WechatAccessToken(c *gin.Context) {
	paramsJSON := request.WechatAccessTokeUrlReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}
	channel, err := new(dbmodels.AppTransactionChannel).QueryKey(dbmodels.TRANSACTION_CHANNEL_KEY_WECHATJSAPIPAY)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
	}
	wechatJSAPIPayParam := dbmodels.ChannelWechatJSAPIPayParam{}
	err = json.Unmarshal([]byte(channel["param"]), &wechatJSAPIPayParam)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
	}

	wechatInfo, err := wechat.NewWechat(wechatJSAPIPayParam.AppId, wechatJSAPIPayParam.Secret, wechatJSAPIPayParam.RedirectURL).GetAccessToken(paramsJSON.Code)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取失败", "", err.Error())
		return
	}
	r := response.WechatAccessTokeRep{
		AccessToken:  wechatInfo.AccessToken,
		ExpiresIn:    wechatInfo.ExpiresIn,
		RefreshToken: wechatInfo.RefreshToken,
		Openid:       wechatInfo.Openid,
		Scope:        wechatInfo.Scope,
	}
	response.ResponseOk(c, "获取成功", r)
}
