package controller

import (
	"bytes"
	"gamers/mq/rabbitmqProducer"
	"path"

	//"strings"

	"fmt"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson/primitive"

	"github.com/dchest/captcha"

	"gamers/controller/response"
	"gamers/utils"
	"gamers/utils/jiguang/jdevice"
	//"gamers/controllerutil/snowflake"
	//"gamers/controllerutil/moderation"
	//"gamers/controllerutil/agora/dynamickey5"
	//"gamers/controllerutil/agora/token"
)

type Book struct {
	Id       primitive.ObjectID `bson:"_id"`
	Name     string
	Category string
	Weight   int
	Author   string
}

// DemoInit 系统api初始化
func DemoInit(gctx *gin.Context) {
	var result response.Response = response.Response{}
	var paramsJSON = &struct {
		Clienttime    string `json:"clienttime"`
		Clientkey     string `json:"clientkey"`
		Remembertoken string `json:"remembertoken"`
	}{}
	ip := gctx.ClientIP()
	fmt.Println("ip0:", ip)

	aa, _ := utils.FuncIPv42Int(ip)
	fmt.Println(aa)
	aaa, _ := utils.FuncInt2IPv4(aa)
	fmt.Println(aaa)

	// token, err := controllerutil.CreateToken(&controllerutil.TokenParams{
	// 	Audience: "md5(用户id)", //受众
	// 	ID:       "sessionid", //编号
	// 	Issuer:   "md5(公司id)", // 签名颁发者
	// 	Subject:  "token",     //签名主题
	// })
	// fmt.Println("aa:", token)
	// test, err := controllerutil.ParseToken(token)
	// if err != nil {
	// 	fmt.Println("token 错误 !")
	// }
	// fmt.Println(test)

	// redisConnect := controllerutil.RedisPool.Get()
	// defer redisConnect.Close()
	// redisConnect.Do("SET", "test111", "你好!")

	//fmt.Println(utils.RedisSet(0, "test111", "hello 阿道夫", -1))

	str := utils.FuncFormatHTTP("http://www.baidu.com/#/阿斯蒂芬")
	fmt.Println(str)

	htmlArray := utils.FuncRemoveHTML([]string{"啊手动阀手动阀<a href='aa'>敖德萨是否</a>", "啊手动阀手动阀<a href='aa'>aaa</a>"})
	fmt.Println(htmlArray[0])
	fmt.Println(htmlArray[1])
	fmt.Println(utils.FuncGetContentImg(`<div class="article" id="article">
				<p>　　原标题：《环球时报》称中方正考虑起诉反华学者及智库，赵立坚：如果属实，我并不感到意外</p>
<p cms-style="font-L">　　[环球时报-环球网报道 记者 李司坤]近日，据消息人士称，中方有关部门正考虑起诉一贯炮制涉华谎言的郑国恩和澳大利亚战略政策研究所（ASPI）等学者和智库，追究其造谣诽谤的法律责任。</p>
<div class="img_wrapper"><img id="0" style="max-width: 640px;" src="http://n.sinaimg.cn/spider202079/200/w640h360/20200709/5d0d-iwasyei5981176.png" alt=""><span class="img_descr"></span></div>
<p cms-style="font-L">　　在7月9日举行的外交部例行记者会上，有来自路透社的记者提问称，《环球时报》引述消息报道说，中国准备起诉在新疆问题上批评中国的德国学者郑国恩和澳大利亚智库ASPI（澳大利亚战略政策研究所），请问发言人可否证实？如果属实的话，会在什么样的法院起诉？</p>
<p cms-style="font-L">　　对此，发言人赵立坚在回应中称，注<img id="0" style="max-width: 640px;" src="http://n.sinaimg.cn/spider202079/200/w640h360/20200709/5d0d-iwasyei5981176.png" alt=""><span src="aa.com" class="img_descr"></span></div>意到《环球时报》的报道，也注意到郑国恩接受所谓的自由亚洲电台的采访。“如果郑国恩没有撒谎造谣，他心虚什么？”赵立坚反问道，我想任何恶意诽谤行为都应受到谴责和追究，这是常识。</p>
<p cms-style="font-L">　　赵立坚指出，众所周知，郑国恩和澳大利亚战略政策研究所一贯炮制涉华谎言，诽谤中国，他们发表的有关涉华言论，早已在事实和真相面前被无情打脸，被证明是谎言和虚假信息。</p>
<p cms-style="font-L">　　“《环球时报》有关的报道，如果属实，我对此并不感到意外。”他说，郑国恩和澳大利亚战略政策研究所背后有谁在操盘，中外媒体已经多次披露，在此我就不重复了。“我奉劝有关方面，多行不义必自毙，尽快回头是岸。”</p><p class="show_author">责任编辑：范斯腾 </p>
			</div>`))

	paramsJSON.Clientkey = "Clientkey"
	gctx.ShouldBindJSON(paramsJSON)
	result.Data = paramsJSON
	gctx.JSON(http.StatusOK, result)
}

// DemoCaptcha 验证码图片
func DemoCaptcha(gctx *gin.Context) {
	width, height, captchaID := 107, 36, captcha.NewLen(6)
	ext := ".jpg"
	lang := "zh"
	download := false
	gctx.Writer.Header().Set("Cache-Control", "no-cache, no-store, must-revalidate")
	gctx.Writer.Header().Set("Pragma", "no-cache")
	gctx.Writer.Header().Set("Expires", "0")

	var content bytes.Buffer
	switch ext {
	case ".wav":
		gctx.Writer.Header().Set("Content-Opentype", "audio/x-wav")
		captcha.WriteAudio(&content, captchaID, lang)
	default:
		gctx.Writer.Header().Set("Content-Opentype", "image/png")
		captcha.WriteImage(&content, captchaID, width, height)
	}
	if download {
		gctx.Writer.Header().Set("Content-Opentype", "application/octet-stream")
	}
	http.ServeContent(gctx.Writer, gctx.Request, captchaID+ext, time.Time{}, bytes.NewReader(content.Bytes()))

}

type User struct {
	UserID   int64  `json:"user_id pk autoincr bigint(20)"`       //用户id
	Username string `json:"username notnull unique VARCHAR(255)"` //帐号
	Password string `json:"password notnull VARCHAR(255)"`        //密码
	Balance  int64  `json:"balance bigint(20)"`                   //余额
}

type Car struct {
	CarID      int64 `json:"car_id pk autoincr bigint(20)"` //购物车id
	GoodsID    int64 `json:"goods_id bigint(20)"`           //商品id
	Number     int64 `json:"car_number bigint(20)"`         //购买数量
	UserID     int64 `json:"user_id bigint(20)"`            //用户id
	TotalPrice int64 `json:"total_price bigint(20)"`        //总价
}
type Goods struct {
	GoodsID int64 `json:"goods_id pk autoincr bigint(20)"` //商品id
	Stock   int64 `json:"stock bigint(20)"`                //库存
}

func DemoDb(gctx *gin.Context) {
	//start := time.Now()
	//go func() {
	//	session := controllerutil.DBEngine.NewSession()
	//	//session.Engine().Sync2(new(User))
	//	defer session.Close()
	//	// session.Table("sys_user") //设置表真实名称
	//	for i := 1; i <= 20; i++ {
	//		account1 := new(User)
	//		account1.Username = "aa" + strconv.Itoa(i)
	//		account1.Password = "bb" + strconv.Itoa(i)
	//		install, err := session.Insert(account1)
	//		if err != nil {
	//			controllerutil.Logger.Panic(fmt.Sprintf("注册失败:", err))
	//		}
	//		fmt.Println("install:", install)
	//	}
	//}()
	//cost := time.Since(start)
	//fmt.Printf("cost=[%s]", cost)
	//account2 := new(User)
	//str, err := controllerutil.DBEngine.ID(2).Get(account2)
	//if err != nil {
	//	controllerutil.Logger.Panic(fmt.Sprintf("查询失败:", err))
	//}
	//fmt.Println("str:", str)
	//fmt.Println(account2.UserID, account2.Username, account2.Password)

	// account3 := new(User)
	// get, err := controllerutil.DBEngine.ID(2).Get(account3)
	// if err != nil {
	// 	controllerutil.Logger.Panic(fmt.Sprintf("查询失败:", err))
	// }
	// if get == false {
	// 	fmt.Println("用户名不存在！")
	// 	return
	// }
	// if account3.Password != "mima1" {
	// 	fmt.Println("旧密码不一样！")
	// 	return
	// }
	// account3.Password = "密码"
	// update, err := controllerutil.DBEngine.ID(1).Update(account3)
	// if err != nil {
	// 	fmt.Println("修改失败！")
	// }
	// fmt.Println("修改成功！", update)

	//更新值为0或者空
	// userNullUp := make(map[string]interface{})
	// userNullUp["password"] = ""
	// userNullUp["Balance"] = 10
	// controllerutil.DBEngine.Table(new(User)).ID(1).Update(userNullUp)

	// account4 := new(User)
	// delete, err := controllerutil.DBEngine.ID(1).Delete(account4)
	// if err != nil {
	// 	controllerutil.Logger.Panic(fmt.Sprintf("查询失败:", err))
	// }
	// fmt.Println("delete:", delete)

	// session1 := controllerutil.DBEngine.NewSession()
	// defer session1.Close()
	// var account5 []User
	// if session1.Find(&account5) != nil {
	// 	controllerutil.Logger.Panic(fmt.Sprintf("查询失败:", err))
	// }
	// fmt.Println("account5:", account5)
	// for _, user := range account5 {
	// 	fmt.Println("user:", user)
	// 	fmt.Println("user:", user.Username)
	// }

	// //事务的提交以及回滚
	// //创建session
	// session := controllerutil.DBEngine.NewSession()
	// defer session.Close()
	// //创建事务
	// err := session.Begin()
	// if err != nil {
	// 	gctx.JSON(200, gin.H{"err": err})
	// 	return
	// }
	// //操作事务,失败并回滚(模拟购物车结算情景)
	// carID := gctx.Query("car_id")
	// if carID == "" {
	// 	gctx.JSON(200, gin.H{"msg": "car_id1不得为空!", "car_id": carID})
	// 	return
	// }

	// //查找购物车中的商品id
	// ids, _ := strconv.ParseUint(carID, 10, 64)
	// car := &Car{CarID: ids}
	// session.Get(car)

	// //goods表库存减去销量
	// //查询商品
	// goods := &Goods{GoodsID: car.GoodsID}
	// session.Get(goods)
	// //更新库存

	// goodsUp := make(map[string]interface{})
	// stock := goods.Stock - car.Number
	// goodsUp["stock"] = stock
	// rel4, err4 := session.Table(new(Goods)).ID(car.GoodsID).Update(goodsUp)
	// if rel4 == 0 || err4 != nil {
	// 	session.Rollback()
	// 	gctx.JSON(200, gin.H{"err4": err4, "rel4": rel4, "carid": car.CarID, "goodsid": goods.GoodsID, "Stock": stock})
	// 	return
	// }

	// //用户扣费
	// //查询用户
	// user := &User{UserID: car.UserID}
	// session.Get(user)
	// //更新价格
	// userUp := make(map[string]interface{})
	// balance := user.Balance - car.TotalPrice
	// userUp["balance"] = balance
	// rel1, err1 := session.Table(new(User)).ID(car.UserID).Update(userUp)
	// if err1 != nil || rel1 == 0 {
	// 	session.Rollback()
	// 	gctx.JSON(200, gin.H{"err1": err1, "rel1": rel1})
	// 	return
	// }

	// //删除用户的购物车信息
	// rel2, err2 := session.Delete(car)
	// if rel2 == 0 || err2 != nil {
	// 	session.Rollback()
	// 	gctx.JSON(200, gin.H{"err2": err2, "rel2": rel2})
	// 	return
	// }

	// if balance < 0 {
	// 	session.Rollback()
	// 	gctx.JSON(200, gin.H{"msg": "余额不足"})
	// 	return
	// }
	// err3 := session.Commit()
	// if err3 != nil {
	// 	gctx.JSON(200, gin.H{"err3": err3})
	// 	return
	// }
	// gctx.JSON(200, gin.H{"msg": "用户扣费成功"})
}

type Employee struct {
	FirstName string   `json:"first_name"`
	LastName  string   `json:"last_name"`
	Age       int      `json:"age"`
	About     string   `json:"about"`
	Interests []string `json:"interests"`
}

func DemoJwt(gctx *gin.Context) {
	// accessToken, refreshToken, err := middleware.UserToken(110)
	// if err != nil {
	// 	response.ResponseError(gctx, 1, "ok", "", "")
	// 	return
	// }

	// data := gin.H{"AccessToken": accessToken, "RefreshToken": refreshToken}
	// response.ResponseOk(gctx, "ok", data)
	// has := sms.SendSms(2, "亲爱的用户，您的短信验证码为{$var}，{$var}分钟内有效，若非本人操作请忽略。【米豆兔】", "13689042927,484839,10") //
	// fmt.Println(has)

	// aa, err := cos.GetTmpSecretKey("test-cdsaibo-1301381879")
	// if err != nil {
	// 	response.ResponseOk(gctx, "ok", err)
	// } else {
	// 	// fmt.Println(aa["TmpSecretID"])
	// 	response.ResponseOk(gctx, "ok", aa)
	// }
	// return

	// str := moderation.TextModeration("啊xjp啊啊叼近啊习银啊习仅啊")
	// fmt.Println(str)
	// str1 := moderation.TextReplace("习啊仅E")
	// fmt.Println(str1)

	// 极光推送 start
	// //Platform
	// var pf jpush.Platform
	// pf.Add(jpush.ANDROID)
	// pf.Add(jpush.IOS)
	// pf.Add(jpush.WINPHONE)
	// //pf.All()

	// //Audience
	// var ad jpush.Audience
	// // s := []string{"1", "2", "3"}
	// // ad.SetTag(s)
	// // ad.SetAlias(s)
	// // ad.SetID(s)
	// ad.All()
	// //Notice
	// var notice jpush.Notice
	// notice.SetAlert("alert_test")
	// notice.SetAndroidNotice(&jpush.AndroidNotice{Alert: "AndroidNotice"})
	// notice.SetIOSNotice(&jpush.IOSNotice{Alert: "IOSNotice"})
	// notice.SetWinPhoneNotice(&jpush.WinPhoneNotice{Alert: "WinPhoneNotice"})
	// var msg jpush.Message
	// msg.Title = "Hello"
	// msg.Content = "你是ylywn"
	// payload := jpush.NewPushPayLoad()
	// payload.SetPlatform(&pf)
	// payload.SetAudience(&ad)
	// payload.SetMessage(&msg)
	// payload.SetNotice(&notice)
	// bytes, _ := payload.ToBytes()
	// fmt.Printf("%s\r\n", string(bytes))
	// //push
	// c := jpush.NewPushClient()
	// str, err := c.Send(bytes)
	// if err != nil {
	// 	fmt.Printf("err:%s", err.Error())
	// } else {
	// 	fmt.Printf("ok:%s", str)
	// }
	// 极光推送 end

	// node, err := snowflake.NewNode(1)
	// if err != nil {
	// 	fmt.Println(err)
	// 	return
	// }
	// // Generate a snowflake ID.
	// id := node.Generate()
	// fmt.Printf("Int64  ID: %d\n", id)
	// fmt.Printf("String ID: %s\n", id)

	// 1598803200
	// 9999999999
	// mobile := "13688804053"
	// aa, _ := strconv.ParseInt(mobile[len(mobile)-3:], 0, 64)
	// fmt.Println((aa % 32))
	// userBaseId := models.IDBuilderGetId(controllerutil.REDIS_IDBUILDER_USER_ID)
	// // userBaseId*100 + (aa % 32)
	// fmt.Println(userBaseId*100 + (aa % 32))

	response.ResponseOk(gctx, "ok", nil)
	return
}
func DemoAgora(gctx *gin.Context) {
	// appID := "4e80e0d1add74e70844ba8e9a8ba809d"                //Code ID
	// appCertificate := "d041ef84a2574c669c73e0ab0565f920"       //Code 证书
	// expiredTime := int64(time.Now().Unix()) + int64(3600*24) // 授权时间戳
	// account := "userA"                                         //客户端定义的用户 ID
	// signalingToken := token.SignalingToken(account, appID, appCertificate, expiredTime)
	// fmt.Printf("signalingToken: %s\n", signalingToken)

	// unixTs := int64(time.Now().Unix())
	// randomInt := int64(controllerutil.FuncRandInt(1000000))
	// ChannelKey, _ := dynamickey5.GenerateMediaChannelKey(appID, appCertificate, "testChannel01", unixTs, randomInt, int64(4000000009), expiredTime)
	// fmt.Printf("ChannelKey: %s\n", ChannelKey)

	// PublicSharingKey, _ := dynamickey5.GeneratePublicSharingKey(appID, appCertificate, "testChannel01", unixTs, randomInt, int64(4000000009), expiredTime)
	// fmt.Printf("PublicSharingKey: %s\n", PublicSharingKey)

	// channelName := "testChannel01"
	// uid := int64(4000000009)
	// t := token.CreateAccessToken(appID, appCertificate, channelName, uid)
	// t.Salt = int64(controllerutil.FuncRandInt(1000000))
	// t.Ts = int64(time.Now().Unix())
	// t.Message[token.KJoinChannel] = expiredTime
	// result, _ := t.Build()
	// fmt.Printf("Access Token: %s\n", result)

	// uidZero := int64(0)
	// result, err := token.RTCTokenWithUID(appID, appCertificate, channelName, uidZero, token.RoleSubscriber, expiredTime)
	// if err != nil {
	// 	fmt.Println(err)
	// }
	// at := token.AccessToken{}
	// at.FromString(result)
	// fmt.Printf("Rtc Token: %s\n", result)
	// // fmt.Println(at)
	// if at.Message[token.KJoinChannel] != expiredTime {
	// 	fmt.Println("no kJoinChannel ts")
	// }
	// if at.Message[token.KPublishVideoStream] != 0 {
	// 	fmt.Println("should not have publish video stream privilege")
	// }

	// rtmToken, err1 := token.RTMToken(appID, appCertificate, account, token.RoleRtmUser, expiredTime)
	// if err1 != nil {
	// 	fmt.Println(err1)
	// } else {
	// 	fmt.Println("Rtm Token:", rtmToken)
	// }
	// fmt.Println(restfulapi.RTMUserEvents(rtmToken, account))
	// fmt.Println(restfulapi.RTMChannelEvents(rtmToken, "userA"))

	// fmt.Println(restfulapi.RTMPeerMessages(rtmToken, account))
	// fmt.Println(restfulapi.RTMChannelMessages(rtmToken, account, "channelA"))

	// fmt.Println(restfulapi.RTMCreateHistory(rtmToken, account, "", "channelA", 0, 1601277852, 0, 20, ""))
	// fmt.Println(restfulapi.RTMQueryHistory(rtmToken, account, "MTA3NTg0OjE1NTk0MDI="))

	// fmt.Println(restfulapi.RTMHistoryCount(rtmToken, account, account, "", 0, 1601277852))

	// fmt.Println(restfulapi.CreateKickingRule(appID, 11111, "channelA", "", 60))
	// fmt.Println(restfulapi.QueryKickingRule(appID))
	// fmt.Println(restfulapi.UpdateKickingRule(appID, 355055151, 60))
	// fmt.Println(restfulapi.DeleteKickingRule(appID, 355055151))

	// fmt.Println(restfulapi.QueryUserProperty(appID, 11111, "channelA"))
	// fmt.Println(restfulapi.QueryUserList(appID, "channelA"))
	// fmt.Println(restfulapi.QueryChannelList(appID, 0, 0))
	response.ResponseOk(gctx, "ok", nil)
	return
}
func DemoES(gctx *gin.Context) {
	// var mapping = `{
	// 	"settings":{
	// 		"number_of_shards": 3,  //是数据分片数，默认为5，有时候设置为3
	// 		"number_of_replicas": 1  //是数据备份数，如果只有一台机器，设置为0
	// 	},
	// 	"mappings":{
	// 		"properties":{
	// 			"user":{
	// 				"type":"keyword"
	// 			}
	// 		}
	// 	}
	// }`
	// fmt.Println(controllerutil.ESCreateIndex("app_run_log1", mapping))
	// fmt.Println(controllerutil.ESDeleteIndex("app_run_log1"))
	// fmt.Println(controllerutil.ESIndexExists("app_run_log2"))

	// e2 := `{"first_name":"测试 999","last_name":"Smith","age":10,"about":"测试,中文,24口交换机,早上起床,看见","interests":["sports","music"]}`
	// controllerutil.ESCreate("app_run_log", "4", e2)
	// controllerutil.ESDelete("app_run_log", "2Pq02XQBo4imPlH18buO")
	// controllerutil.ESUpdate("app_run_log", "2", map[string]interface{}{"age": 88, "about": "测试中文24口交换机", "interests": []string{}})
	// controllerutil.ESUpdate("app_run_log", "2", map[string]interface{}{"age": 88, "doc": nil})

	// getResult := controllerutil.ESGet("app_run_log", "1")
	// if getResult != nil && getResult.Found {
	// 	fmt.Printf("Got document %s in version %d from index %s\n", getResult.Id, getResult.Version, getResult.Index)
	// 	var aa Employee
	// 	err := json.Unmarshal(getResult.Source, &aa)
	// 	if err != nil {
	// 		fmt.Println(err)
	// 	}
	// 	fmt.Println(aa)
	// }

	// searchResult := controllerutil.ESTermsSearch("app_run_log", "age", 88)
	// searchResult := controllerutil.ESBoolSearch("app_run_log")
	// var tweet Employee
	// if searchResult != nil {
	// 	for _, item := range searchResult.Each(reflect.TypeOf(tweet)) {
	// 		fmt.Println(item)
	// 	}
	// }
	// if searchResult != nil && searchResult.Hits.TotalHits.Value > 0 {
	// 	for _, hit := range searchResult.Hits.Hits {
	// 		err := json.Unmarshal(hit.Source, &tweet)
	// 		if err != nil {
	// 			fmt.Printf("source convert json failed, err: %v\n", err)
	// 		}
	// 		fmt.Printf("data: %v\n", tweet)
	// 	}
	// }

	utils.ESAggSearch("app_run_log")
	response.ResponseOk(gctx, "ok", nil)
	return
}

func DemoCheckJwt(gctx *gin.Context) {
	userID, _ := gctx.Get("userID")
	data := gin.H{"userId": userID}
	response.ResponseOk(gctx, "ok", data)
	return
}

func DemoJpush(gctx *gin.Context) {
	r, err := jdevice.NewDeviceClient().QueryDeviceAliasAndTag("123456")
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_UNKNOWN, err.Error(), "", "")
		return
	}
	response.ResponseOk(gctx, "ok", r)
}

//文件上传
func Upload(gctx *gin.Context) {
	file, err := gctx.FormFile("file")
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "文件上传失败", "", err.Error())
		return
	}
	//限制文件类型
	if file.Header.Get("Content-Opentype") != "image/jpeg" {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "文件类型错误", "", "")
		return
	}

	//限制文件大小
	if file.Size > fileSize {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "文件大小不能超过5M", "", "")
		return
	}

	suffix := path.Ext(file.Filename)
	dst := fmt.Sprintf("%s/%d%s", filePath, time.Now().UnixNano(), suffix)
	err = gctx.SaveUploadedFile(file, dst)

	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "文件上传失败", "", err.Error())
		return
	}
	r := gin.H{"FileUrl": dst}
	response.ResponseOk(gctx, "ok", r)
}

func DemoIM(c *gin.Context) {
	//userId, _ := c.Get("userID")
	//userIdInt64, _ := strconv.ParseUint(userId.(string), 10, 64)
	//user := models.SystemUser{}
	//byUser, err := user.UserIdByUser(userIdInt64)
	//if err != nil {
	//	fmt.Printf("err:%v\n", err)
	//}
	//result, err := common.IMAccountImport(byUser.UserID, byUser.UserNickname, byUser.UserIconurl)
	//if err != nil {
	//	fmt.Printf("IM err:%v\n", err)
	//}
	//fmt.Printf("result:%s\n", result)
	//hash, err := utils.RedisGetHash(utils.REDIS_DB_SEARCH_CACHE, strconv.Itoa(1000081424), "UserLoginIP")
	//if err != nil {
	//	fmt.Printf("err :%v\n", err)
	//}
	//fmt.Printf("hash:%d\n", hash)
}

func DemoHash(c *gin.Context) {
	//tmp := struct {
	//	WheatList       string `redis:"wheat_list"`
	//	WheatLoveSwitch int    `redis:"wheat_love_switch"`
	//	WheatSwitch     int    `redis:"wheat_switch"`
	//}{}
	//err := utils.RedisGetHashAll(utils.REDIS_DB_LIVE, "liveWheat:3", &tmp)
	//if err != nil {
	//	fmt.Println(err)
	//}
	//fmt.Printf("%+v\n", tmp)
}

//测试延迟投递队列处理订单
func DemoOrder(c *gin.Context) {
	rabbitmqProducer.ProducerOrder(1004002101, 2, 10)
}
