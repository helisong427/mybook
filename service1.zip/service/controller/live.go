package controller

import (
	"encoding/json"
	"fmt"
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"gamers/utils/tencent/tencentIm"
	"sort"
	"strconv"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/go-redis/redis"
	"gorm.io/gorm"
)

// 开关爱意值
func SwitchLove(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.SwitchLoveReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	// 查询房间是否存在
	model := dbmodels.AppLiveRoom{}
	room, err := model.QueryRoomId(paramsJSON.RoomId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间不存在", "", err.Error())
		return
	}

	// 如果房间开启pk功能 并且 pk状态处于准备开启惩罚阶段 不能修改爱意值开关
	if room.RoomPkSwitch == dbmodels.RoomPkFunctionOpen && room.RoomPkState != dbmodels.RoomPkCloseStage {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间当前模式不支持开关爱意值", "", "")
		return
	}

	// 操作redis
	redisModel := redismodels.Wheat{}
	data, err := redisModel.SwitchWheatLove(paramsJSON.RoomId, userId, paramsJSON.Switch, true)
	if err != nil {
		if err == redismodels.ErrWheatCantOpenLove {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, err.Error(), "", "")
			return
		} else {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "", "", err.Error())
			return
		}
	}

	// 发送IM消息通知开启爱意值
	go new(services.LiveMsg).AnnounceSwitchLove(&room, &data, paramsJSON.Switch)
	response.ResponseOk(c, "", data)
	return
}

// 上下麦
func UpAndDownWheat(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.UpAndDownWheatReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	// 查询房间是否存在
	model := dbmodels.AppLiveRoom{}
	room, err := model.QueryRoomId(paramsJSON.RoomId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间不存在", "", "")
		return
	}

	// 操作redis
	redisModel := redismodels.Wheat{}
	wheat, err := redisModel.UpAndDownWheat(paramsJSON.RoomId, userId, paramsJSON.WheatKey, paramsJSON.UpAndDownWheat)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, err.Error(), "", "")
		return
	}

	go new(services.LiveMsg).AnnounceUpDownWheat(&room, &wheat, paramsJSON.UpAndDownWheat, userId)
	response.ResponseOk(c, "", wheat)
	return
}

// 邀请上麦
func InviteUpWheat(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.InviteUpWheatReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	// 查询房间是否存在
	appLiveRoom, err := new(dbmodels.AppLiveRoom).QueryRoomId(paramsJSON.RoomId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间不存在", "", "")
		return
	}
	// 检验房间状态
	if appLiveRoom.RoomStatus != dbmodels.ROOM_STATUS_OK {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前直播间不允许邀请上麦", "", "")
		return
	}
	// 检查用户身份
	role, err := new(redismodels.Wheat).QueryUserRole(paramsJSON.RoomId, userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", "")
		return
	}
	if role <= redismodels.WHEAT_ROLE_USER {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "无权操作", "", "")
		return
	}
	// 检查用户是否在其他麦位上
	detail, err := new(redismodels.Wheat).QueryWheatDetail(int(appLiveRoom.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", "")
		return
	}
	isOnWheat := detail.CheckUserWheat(paramsJSON.UserId)
	if isOnWheat {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "该用户在其他麦位上", "", "")
		return
	}
	// 判断麦位上是否有人
	isUser := detail.CheckWheatIsUser(paramsJSON.WheatKey)
	if isUser {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "此麦位已被占用", "", "")
		return
	}
	_, err = new(redismodels.WheatQueue).QueryWheatQueueByUserId(utils.REDIS_LIVE_WHEAT_QUEUE+strconv.Itoa(paramsJSON.RoomId), int64(paramsJSON.UserId))
	if err == nil {
		// 在麦序中，直接抱上麦
		wheat, err := new(redismodels.Wheat).UpAndDownWheat(paramsJSON.RoomId, int64(paramsJSON.UserId), paramsJSON.WheatKey, redismodels.WHEAT_UP)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", "")
			return
		}
		go new(services.LiveMsg).AnnounceUpDownWheat(&appLiveRoom, &wheat, redismodels.WHEAT_UP, int64(paramsJSON.UserId))
		// 移除麦序
		wheatQueueData, err := new(redismodels.WheatQueue).Update(paramsJSON.RoomId, int64(paramsJSON.UserId), redismodels.WHEAT_QUEUE_ACTION_DEL)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, err.Error(), "", "操作麦序错误")
			return
		}
		// 发送麦序消息
		go new(services.LiveMsg).AnnounceUpdateWheatQueue(&appLiveRoom, wheatQueueData, redismodels.WHEAT_QUEUE_ACTION_DEL)
		response.ResponseOk(c, "抱人上麦成功", "")
		return
	}
	m := services.InviteUpWheat{
		RoomId:        paramsJSON.RoomId,
		UserId:        int(userId),
		WheatKey:      paramsJSON.WheatKey,
		InvitedUserId: paramsJSON.UserId,
		CreateT:       time.Now().Unix(),
	}
	err = m.InviteUpWheat()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "邀请失败", "", "")
		return
	}
	invite := redismodels.InviteUpWheat{
		RoomId:        int64(m.RoomId),
		AdminId:       int64(m.UserId),
		WheatKey:      m.WheatKey,
		InvitedUserId: int64(m.InvitedUserId),
		CreateT:       m.CreateT,
	}
	go new(services.LiveMsg).InvitedWheat(&invite)
	response.ResponseOk(c, "邀请成功", "")
	return
}

// 接受邀请上麦
func AcceptUpWheat(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.AcceptUpWheatReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	// 查询房间是否存在
	appLiveRoom, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(paramsJSON.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间不存在", "", "")
		return
	}
	// 房间状态校验
	if appLiveRoom.RoomStatus != dbmodels.ROOM_STATUS_OK {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前直播间不允许邀请上麦", "", "")
		return
	}
	m := services.InviteUpWheat{
		RoomId:        int(paramsJSON.RoomId),
		InvitedUserId: int(userId),
	}
	err, message, wheat := m.AcceptUpWheat()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, message, "", "")
		return
	}
	go new(services.LiveMsg).AnnounceUpDownWheat(&appLiveRoom, &wheat, redismodels.WHEAT_UP, userId)
	response.ResponseOk(c, "接受成功", wheat)
	return
}

// 拒绝上麦邀请
func RefuseUpWheat(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.AcceptUpWheatReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	// 查询房间是否存在
	model := dbmodels.AppLiveRoom{}
	_, err = model.QueryRoomId(int(paramsJSON.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间不存在", "", "")
		return
	}
	m := services.InviteUpWheat{
		RoomId:        int(paramsJSON.RoomId),
		InvitedUserId: int(userId),
	}
	err = m.RefuseUpWheat()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", "")
		return
	}
	response.ResponseOk(c, "拒绝成功", "")
	return
}

// 锁定/解锁 麦位
func LockAndUnlockWheat(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.LockAndUnlockWheatReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	// 查询房间是否存在
	model := dbmodels.AppLiveRoom{}
	room, err := model.QueryRoomId(paramsJSON.RoomId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间不存在", "", "")
		return
	}

	// 操作redis
	redisModel := redismodels.Wheat{}
	wheat, err := redisModel.LockAndUnlockWheat(paramsJSON.RoomId, userId, paramsJSON.WheatKey, paramsJSON.LockAndUnlockWheat)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, err.Error(), "", "")
		return
	}
	go new(services.LiveMsg).AnnounceLockUnlockWheat(&room, &wheat, paramsJSON.LockAndUnlockWheat)
	response.ResponseOk(c, "", wheat)
	return
}

// 获取麦位列表
func GetWheatList(c *gin.Context) {
	paramsJSON := request.GetWheatReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	redisModel := redismodels.Wheat{}
	list, err := redisModel.QueryWheatDetail(paramsJSON.RoomId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, err.Error(), "", "")
		return
	}
	response.ResponseOk(c, "", list)
	return
}

// 获取麦序列表
func GetWheatQueueList(c *gin.Context) {
	paramsJSON := request.GetWheatQueueListReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	redisModel := redismodels.WheatQueue{}
	list, err := redisModel.QueryList(paramsJSON.RoomId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, err.Error(), "", "")
		return
	}
	if len(list) > 0 {
		response.ResponseOk(c, "", list)
	} else {
		response.ResponseOk(c, "", []string{})
	}

	return
}

// 更新麦序列表
func UpdateWheatQueue(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.UpdateWheatQueueReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	// 查询房间是否存在
	model := dbmodels.AppLiveRoom{}
	room, err := model.QueryRoomId(paramsJSON.RoomId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间不存在", "", "")
		return
	}

	redisModel := redismodels.WheatQueue{}
	data, err := redisModel.Update(paramsJSON.RoomId, userId, paramsJSON.Action)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, err.Error(), "", "")
		return
	}
	go new(services.LiveMsg).AnnounceUpdateWheatQueue(&room, data, paramsJSON.Action)
	response.ResponseOk(c, "", data)
	return
}

// 抱上下麦序
func HodUpAndOnWheat(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.HodUpAndOnWheatReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	// 查询房间是否存在
	model := dbmodels.AppLiveRoom{}
	room, err := model.QueryRoomId(paramsJSON.RoomId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间不存在", "", "")
		return
	}

	// 麦位
	wheatModel := redismodels.Wheat{}
	wheatData, err := wheatModel.HodUpAndOnWheat(paramsJSON.RoomId, int64(paramsJSON.UpUserId), userId, paramsJSON.WheatKey, paramsJSON.Action)
	if err != nil {
		if err != redismodels.ErrWheatNoFree {
			response.ResponseError(c, response.RESPONSE_LIVE_ERROR, err.Error(), "", "操作麦位错误")
			return
		} else {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, err.Error(), "", "操作麦位错误")
			return
		}
	}
	// 发送上下麦位消息
	go new(services.LiveMsg).AnnounceUpDownWheat(&room, &wheatData, paramsJSON.Action, int64(paramsJSON.UpUserId))

	if paramsJSON.Action == 1 {
		wheatQueueModel := redismodels.WheatQueue{}
		wheatQueueData, err := wheatQueueModel.Update(paramsJSON.RoomId, int64(paramsJSON.UpUserId), redismodels.WHEAT_QUEUE_ACTION_DEL)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, err.Error(), "", "操作麦序错误")
			return
		}
		// 发送麦序消息
		go new(services.LiveMsg).AnnounceUpdateWheatQueue(&room, wheatQueueData, redismodels.WHEAT_QUEUE_ACTION_DEL)
	}

	response.ResponseOk(c, "", wheatData)
	return
}

// 送礼
func SendProp(c *gin.Context) {
	userId := utils.FuncUserId(c)
	userIdStr := strconv.Itoa(int(userId))
	var form request.SendPropReq
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	// 校验直播间信息
	room, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(form.RoomId))
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取直播间出错", "", err.Error())
		return
	}
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "直播间不存在", "", "")
		return
	}
	if room.RoomStatus != dbmodels.ROOM_STATUS_OK {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前直播间状态禁止送礼", "", "")
		return
	}
	// 麦位信息
	wheat, err := new(redismodels.Wheat).QueryWheatDetail(int(form.RoomId))
	if err != nil {
		utils.LogErrorF("获取房间[%d]的麦位详情失败，err:%s", form.RoomId, err.Error())
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取房间麦位信息失败", "", "")
		return
	}
	userInfo, err := new(redismodels.MsgUserObj).GetMsgUserInfo(userId, map[string]bool{})
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户信息失败", err.Error(), "")
		return
	}
	gift := services.InitGift()
	timeout := utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT
	acquireTimeout := utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT
	// 背包礼物
	if *form.PropSource == request.SEND_PROP_TYPE_BACKPACK {
		if form.BackpackId == 0 {
			response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", "backpack_id required")
			return
		}
		// 加锁
		giftLock := utils.REDIS_LIVE_GIFT_LOCK + userIdStr + ":" + strconv.Itoa(int(form.BackpackId))
		lock, isLock := utils.AcquireLock(giftLock, acquireTimeout, timeout)
		if !isLock {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "操作频繁", "", "")
			return
		}
		// 释放锁
		defer utils.ReleaseLock(giftLock, lock)
		// 校验背包信息
		backpack, resp := gift.CheckPropByBackpack(userId, &form)
		if resp.ERR != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, resp.Msg, "", resp.ERR.Error())
			return
		}
		whs, err := gift.ValidateReceiver(&form, wheat.WheatLoveSwitch, &backpack.AppProp)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "校验接收用户失败", "", err.Error())
			return
		}
		mqInfo := services.SendPropInfoToMq{
			SendPropReq: &form,
			LiveRoom:    &room,
			Prop:        &backpack.AppProp,
			SenderId:    userId,
			Receivers:   whs,
			SendTime:    time.Now().Unix(),
		}
		// 匹配麦位
		for i, u := range whs {
			for _, position := range wheat.WheatObj {
				if position.UserId == int(u.UserInfo.UserId) {
					p := position
					whs[i].Position = p.Position
					whs[i].UserInfo.Role = p.Role
				}
			}
		}
		// 赠送礼物
		resp = gift.SendByBackpackProp(&userInfo, &backpack, &form, &room, whs)
		if resp.ERR != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, resp.Msg, "", resp.ERR.Error())
			return
		}
		go services.UpdateWeekStarInfo(&mqInfo)
		liveMsg := services.InitLiveMsg()
		go func() {
			// 发送消息
			liveMsg.AnnounceSendGift(&room, whs, &userInfo)
			// 推送mq
			mqInfo.PushMq()
		}()

		go liveMsg.HeadlineMsgSendGift(&room, whs, &userInfo, &backpack.AppProp)
		data := services.SendPropResp{
			PropInfo: whs,
			UserOver: userInfo.UserOver,
		}
		go func() {
			_ = new(redismodels.Task).Init().ReportConditionTag(userId, "sendGift", 1)
		}()
		response.ResponseOk(c, "ok", data)
	} else {
		if form.PropId == 0 {
			response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", "prop_id required")
			return
		}
		prop, resp := gift.CheckPropByNormal(&form, &userInfo)
		if resp.ERR != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, resp.Msg, "", resp.ERR.Error())
			return
		}
		if prop.PropClass == dbmodels.DB_CLASS_FREE {
			timeout = int(prop.PropInterval)
			acquireTimeout = 1
		}
		// 锁住用户信息，防止金额算错
		giftLock := utils.REDIS_LIVE_GIFT_LOCK + userIdStr + ":" + strconv.Itoa(int(prop.PropId))
		lock, isLock := utils.AcquireLock(giftLock, acquireTimeout, timeout)
		if !isLock {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "操作频繁", "", "")
			return
		}
		// 释放锁
		if prop.PropClass != dbmodels.DB_CLASS_FREE {
			defer utils.ReleaseLock(giftLock, lock)
		}
		whs, err := gift.ValidateReceiver(&form, wheat.WheatLoveSwitch, prop)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "校验接收用户失败", "", err.Error())
			return
		}
		mqInfo := services.SendPropInfoToMq{
			SendPropReq: &form,
			LiveRoom:    &room,
			Prop:        prop,
			SenderId:    userId,
			Receivers:   whs,
			SendTime:    time.Now().Unix(),
		}
		// 匹配麦位
		for i, u := range whs {
			for _, position := range wheat.WheatObj {
				if position.UserId == int(u.UserInfo.UserId) {
					p := position
					whs[i].Position = p.Position
					whs[i].UserInfo.Role = p.Role
				}
			}
		}
		over, resp := gift.SendByNormalProp(&userInfo, prop, &form, &room, whs)
		if resp.ERR != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, resp.Msg, "", resp.ERR.Error())
			return
		}

		fmt.Println(mqInfo.Prop.PropId)
		go services.UpdateWeekStarInfo(&mqInfo)
		liveMsg := services.InitLiveMsg()
		go func() {
			// 发送消息
			liveMsg.AnnounceSendGift(&room, whs, &userInfo)
			// 推送mq
			mqInfo.PushMq()
		}()
		liveMsg.HeadlineMsgSendGift(&room, whs, &userInfo, prop)
		data := services.SendPropResp{
			PropInfo: whs,
			UserOver: over,
		}
		go func() {
			_ = new(redismodels.Task).Init().ReportConditionTag(userId, "sendGift", 1)
		}()
		response.ResponseOk(c, "ok", data)
	}

}

// 设置管理员
func SetAdmin(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.SetAdminReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	// 主播用户身份鉴权
	roomModel := dbmodels.AppLiveRoom{}
	roomData, err := roomModel.QueryRoomId(paramsJSON.RoomId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间不存在", "", err.Error())
		return
	}

	if roomData.RoomUserId == int64(paramsJSON.AdminUserId) {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "不能设置主播为管理员", "", "")
		return
	}

	// 查询当前用户身份
	role, err := new(redismodels.Wheat).QueryUserRole(paramsJSON.RoomId, userId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "", "", err.Error())
		return
	}

	// 当前用户的权限<=设置的权限
	if role <= *paramsJSON.AdminLevel {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "无权操作", "", "")
		return
	}

	// 查询用户管理员是否存在
	userAdminModel := dbmodels.SystemUser{}
	_, err = userAdminModel.UserIdByUser(int64(paramsJSON.AdminUserId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "用户不存在", "", err.Error())
		return
	}

	// 查询管理员
	roomAdminModel := dbmodels.AppRoomAdmin{}
	row, roomAdminData, err := roomAdminModel.GetRoomIdByUser(int64(paramsJSON.AdminUserId), int64(paramsJSON.RoomId))
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "设置管理员失败", "", err.Error())
		return
	}
	if row > 0 {
		if roomAdminData.AdminRole == dbmodels.ROOM_ADMIN_ROLE_LANDLORD {
			response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "对方是房主", "", "")
			return
		}
		if roomAdminData.AdminRole == dbmodels.ROOM_ADMIN_ROLE_ADMIN {
			response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "对方已是高级管理员", "", "")
			return
		}

		if roomAdminData.AdminRole == dbmodels.ROOM_ADMIN_ROLE_DEPUTY_ANCHOR {
			if *paramsJSON.AdminLevel == dbmodels.ROOM_ADMIN_ROLE_ADMIN {
				// 副管理员可以被设置为管理员
				err = new(dbmodels.AppRoomAdmin).Delete(paramsJSON.RoomId, paramsJSON.AdminUserId)
				if err != nil {
					response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "取消管理员身份失败", "", err.Error())
					return
				}
			} else {
				response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "对方已是管理员", "", "")
				return
			}
		}
	}

	// 创建管理员
	roomAdminModel.AdminRoomID = int64(paramsJSON.RoomId)
	roomAdminModel.AdminUserID = int64(paramsJSON.AdminUserId)
	// roomAdminModel.AdminRole = dbmodels.ROOM_ADMIN_ROLE_ADMIN
	roomAdminModel.AdminRole = *paramsJSON.AdminLevel
	err = roomAdminModel.Create()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "设置管理员失败", "", err.Error())
		return
	}
	adminUser := redismodels.MsgUserObj{UserId: userId, Role: role}
	go func() {
		liveMsg := services.InitLiveMsg()
		info, err := new(redismodels.UserInfo).GetUserInfo(int64(paramsJSON.AdminUserId))
		if err != nil {
			utils.LogErrorF("获取房管个人信息失败,err:%s", err.Error())
			return
		}
		liveMsg.AssistantBeManager(&roomData, fmt.Sprintf("%d", paramsJSON.AdminUserId), roomAdminModel.AdminRole, role)
		liveMsg.AnnounceBeManager(&roomData, &info, roomAdminModel.AdminRole, &adminUser)
	}()
	response.ResponseOk(c, "设置成功", nil)
	return
}

// 取消管理员
func CancelAdmin(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.CancelAdminReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	roomModel := dbmodels.AppLiveRoom{}
	roomData, err := roomModel.QueryRoomId(paramsJSON.RoomId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间不存在", "", err.Error())
		return
	}

	// 查询请求接口用户身份
	apiRole, err := new(redismodels.Wheat).QueryUserRole(paramsJSON.RoomId, userId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "", "", err.Error())
		return
	}

	// 查询用户身份
	role, err := new(redismodels.Wheat).QueryUserRole(paramsJSON.RoomId, int64(paramsJSON.AdminUserId))
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "", "", err.Error())
		return
	}

	if apiRole <= role {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "无权操作", "", "")
		return
	}

	err = new(dbmodels.AppRoomAdmin).Delete(paramsJSON.RoomId, paramsJSON.AdminUserId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "取消管理员失败", "", err.Error())
		return
	}

	go func() {
		liveMsg := services.InitLiveMsg()
		info, err := new(redismodels.UserInfo).GetUserInfo(int64(paramsJSON.AdminUserId))
		if err != nil {
			utils.LogErrorF("获取房管个人信息失败,err:%s", err.Error())
			return
		}
		liveMsg.AssistantCancelManager(&roomData, fmt.Sprintf("%d", paramsJSON.AdminUserId), role, apiRole)
		liveMsg.AnnounceCancelManager(&roomData, &info)
	}()

	response.ResponseOk(c, "取消管理员成功", nil)
	return
}

// 获取管理员列表
func AdminList(c *gin.Context) {
	paramsJSON := request.AdminListReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	adminRoomModel := dbmodels.AppRoomAdmin{}
	row, data, err := adminRoomModel.GetAdminDetails(int64(paramsJSON.RoomId))
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_UNKNOWN, "", "", err.Error())
		return
	}
	if row > 0 {
		r := []response.AdminListRep{}
		// 查询用户在线状态
		for _, v := range data {
			adminData := response.AdminListRep{
				UserId:           v.AdminUserID,
				UserNickName:     v.SystemUser.UserNickname,
				UserIconurl:      v.SystemUser.UserIconurl,
				UserGender:       v.SystemUser.UserGender,
				UserAge:          utils.FuncGetAge(int(v.SystemUser.UserBirthday)),
				UserRole:         v.AdminRole,
				UserOnlineStatus: v.SystemUser.UserIsOnline,
			}
			if v.SystemUser.AppUserVipExperience.ExperienceUserId != 0 {
				adminData.UserLevel = v.SystemUser.AppUserVipExperience.ExperienceLevel
			}
			r = append(r, adminData)
		}

		response.ResponseOk(c, "", r)
		return
	} else {
		response.ResponseOk(c, "", []string{})
		return
	}
}

// 禁言
func LiveMute(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var form request.MuteReq
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	adminer, err := new(redismodels.UserInfo).GetUserInfo(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户信息失败", "", err.Error())
		return
	}
	// 校验管理员身份
	admin, err := new(dbmodels.AppRoomAdmin).GetAnchorByUIdAndRId(userId, form.RoomId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询管理员错误", "", err.Error())
		return
	}
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "对不起，权限不足", "", "")
		return
	}
	roomInfo, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(form.RoomId))
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询房间信息失败", "", err.Error())
		return
	}

	// 校验被封禁对象信息
	muter, err := new(dbmodels.AppRoomAdmin).GetAnchorByUIdAndRId(form.UserId, form.RoomId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询管理员错误", "", err.Error())
		return
	}
	if err == nil {
		// 判断权限
		if muter.AdminRole >= admin.AdminRole {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "对不起，权限不足", "", "")
			return
		}
	}
	mute, err := new(redismodels.UserInfo).GetUserInfo(form.UserId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户信息失败", "", err.Error())
		return
	}

	muteUser := redismodels.MsgUserObj{
		UserId: form.UserId, NickName: mute.UserNickname,
		Icon: mute.UserIconurl, Gender: mute.UserGender,
		Role: muter.AdminRole, VipLevel: mute.VipLevel,
	}
	adminUser := redismodels.MsgUserObj{
		UserId: userId, NickName: adminer.UserNickname,
		Role: admin.AdminRole, VipLevel: adminer.VipLevel,
	}
	muteItem := redismodels.MsgMuteItem{
		User:   muteUser,
		Admin:  adminUser,
		StartT: time.Now().Unix(),
	}
	muteItem.EndT += muteItem.StartT + form.Duration
	uids := []string{strconv.Itoa(int(form.UserId))}
	err = tencentIm.MuteGroup(strconv.Itoa(int(form.RoomId)), uids, form.Duration)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "调用im禁言err", "", err.Error())
		return
	}
	key := utils.REDIS_LIVE_MUTE + strconv.Itoa(int(form.RoomId)) + ":" + strconv.Itoa(int(form.UserId))
	err = utils.RedisClient.Set(key, muteItem, time.Duration(int(form.Duration))*time.Second).Err()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "存储禁言信息出错", "", err.Error())
		return
	}
	liveMsg := services.InitLiveMsg()
	// 群通知
	go liveMsg.AnnounceMute(&roomInfo, &mute, muteItem.StartT, muteItem.EndT, &adminUser)
	// 私聊通知
	uidStr := strconv.Itoa(int(form.UserId))
	go liveMsg.AssistantBeMute(&roomInfo, uidStr, muteItem.EndT, admin.AdminRole)
	response.ResponseOk(c, "ok", nil)
	return
}

// 取消禁言
func LiveUnMute(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var form request.ForbiddenUserReq
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	var adminModel dbmodels.AppRoomAdmin
	// 校验管理员身份
	admin, err := adminModel.GetAnchorByUIdAndRId(userId, form.RoomId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询管理员错误", "", err.Error())
		return
	}
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "对不起，权限不足", "", "")
		return
	}
	roomInfo, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(form.RoomId))
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询房间信息失败", "", err.Error())
		return
	}
	// 校验被封禁对象信息
	kicker, err := adminModel.GetAnchorByUIdAndRId(form.UserId, form.RoomId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询管理员错误", "", err.Error())
		return
	}
	if err == nil {
		// 判断权限
		if kicker.AdminRole >= admin.AdminRole {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "对不起，权限不足", "", "")
			return
		}
	}
	uids := []string{strconv.Itoa(int(form.UserId))}
	err = tencentIm.MuteGroup(strconv.Itoa(int(form.RoomId)), uids, 0)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "调用im禁言err", "", err.Error())
		return
	}
	key := utils.REDIS_LIVE_MUTE + strconv.Itoa(int(form.RoomId)) + ":" + strconv.Itoa(int(form.UserId))
	err = utils.RedisClient.Del(key).Err()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "存储禁言信息出错", "", err.Error())
		return
	}
	liveMsg := services.InitLiveMsg()
	// 私聊通知
	uidStr := strconv.Itoa(int(form.UserId))
	go liveMsg.AssistantCancelMute(&roomInfo, uidStr, admin.AdminRole)
	response.ResponseOk(c, "ok", nil)
	return

}

// 获取禁言列表
func LiveMuteUsers(c *gin.Context) {
	var muters redismodels.MuteList
	roomId := c.Query("room_id")
	if roomId == "" {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", "")
		return
	}
	key := utils.REDIS_LIVE_MUTE + roomId + ":*"
	muteList, err := utils.RedisClient.Keys(key).Result()
	if err != nil {
		utils.LogErrorF("获取禁言列表失败,err:%s", err.Error())
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取禁言列表失败", "", "")
		return
	}
	wg := sync.WaitGroup{}
	mutechan := make(chan redismodels.MsgMuteItem, len(muteList))
	for _, v := range muteList {
		wg.Add(1)
		go redismodels.GetMuteUserInfo(&wg, mutechan, v)
	}
	wg.Wait()
	close(mutechan)

	for m := range mutechan {
		muters = append(muters, m)
	}
	sort.Sort(muters)
	response.ResponseOk(c, "ok", muters)
	return
}

// 踢出直播间
func LiveKickOut(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var form request.MuteReq
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	var adminModel dbmodels.AppRoomAdmin
	// 校验管理员身份
	admin, err := adminModel.GetAnchorByUIdAndRId(userId, form.RoomId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询管理员错误", "", err.Error())
		return
	}
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "对不起，权限不足", "", "")
		return
	}
	roomInfo, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(form.RoomId))
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询房间信息失败", "", err.Error())
		return
	}
	// 校验被封禁对象信息
	kicker, err := adminModel.GetAnchorByUIdAndRId(form.UserId, form.RoomId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询管理员错误", "", err.Error())
		return
	}
	if err == nil {
		// 判断权限
		if kicker.AdminRole >= admin.AdminRole {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "对不起，权限不足", "", "")
			return
		}
	}
	mute, err := new(redismodels.UserInfo).GetUserInfo(form.UserId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户信息失败", "", err.Error())
		return
	}
	adminer, err := new(redismodels.UserInfo).GetUserInfo(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户信息失败", "", err.Error())
		return
	}
	kickUser := redismodels.MsgUserObj{
		UserId: form.UserId, NickName: mute.UserNickname,
		Icon: mute.UserIconurl, Gender: mute.UserGender,
		Role: kicker.AdminRole, VipLevel: mute.VipLevel,
	}
	adminUser := redismodels.MsgUserObj{
		UserId: userId, NickName: adminer.UserNickname,
		Role: admin.AdminRole, Gender: adminer.UserGender,
		VipLevel: adminer.VipLevel,
	}
	muteItem := redismodels.MsgMuteItem{
		User:   kickUser,
		Admin:  adminUser,
		StartT: time.Now().Unix(),
	}
	muteItem.EndT += muteItem.StartT + form.Duration
	uids := []string{strconv.Itoa(int(form.UserId))}
	err = tencentIm.MuteGroup(strconv.Itoa(int(form.RoomId)), uids, form.Duration)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "调用im禁言err", "", err.Error())
		return
	}
	key := utils.REDIS_LIVE_FORBIDEN + strconv.Itoa(int(form.RoomId)) + ":" + strconv.Itoa(int(form.UserId))
	err = utils.RedisClient.Set(key, muteItem, time.Duration(int(form.Duration))*time.Second).Err()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "存储踢人信息出错", "", err.Error())
		return
	}

	// 删除麦位
	_, data, _, err := new(redismodels.Wheat).SystemDown(int(form.RoomId), int(form.UserId))
	if err != nil {
		str := fmt.Sprintf("删除麦位失败[%d][%d],%s,%s", form.RoomId, form.UserId, key, err.Error())
		utils.Logger.Error(str)
		return
	}
	// 删除麦序
	_, _, err = new(redismodels.WheatQueue).SystemDown(int(form.RoomId), int(form.UserId))
	if err != nil && err != redis.Nil {
		str := fmt.Sprintf("删除麦位失败[%d][%d],%s,%s", form.RoomId, form.UserId, key, err.Error())
		utils.Logger.Error(str)
		return
	}
	liveMsg := services.InitLiveMsg()
	// 群通知
	go liveMsg.AnnounceKick(&roomInfo, &mute, muteItem.StartT, muteItem.EndT, &data, &adminUser)
	// 私聊通知
	uidStr := strconv.Itoa(int(mute.UserID))
	go liveMsg.AssistantBeKick(&roomInfo, uidStr, muteItem.EndT, admin.AdminRole)
	response.ResponseOk(c, "ok", data)
	return
}

// 取消被踢
func LiveUnKickOut(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var form request.ForbiddenUserReq
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	var adminModel dbmodels.AppRoomAdmin
	// 校验管理员身份
	admin, err := adminModel.GetAnchorByUIdAndRId(userId, form.RoomId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询管理员错误", "", err.Error())
		return
	}
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "对不起，权限不足", "", "")
		return
	}
	roomInfo, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(form.RoomId))
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询房间信息失败", "", err.Error())
		return
	}
	// 校验被封禁对象信息
	kicker, err := adminModel.GetAnchorByUIdAndRId(form.UserId, form.RoomId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询管理员错误", "", err.Error())
		return
	}
	if err == nil {
		// 判断权限
		if kicker.AdminRole >= admin.AdminRole {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "对不起，权限不足", "", "")
			return
		}
	}

	uids := []string{strconv.Itoa(int(form.UserId))}
	err = tencentIm.MuteGroup(strconv.Itoa(int(form.RoomId)), uids, 0)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "调用im禁言err", "", err.Error())
		return
	}
	key := utils.REDIS_LIVE_FORBIDEN + strconv.Itoa(int(form.RoomId)) + ":" + strconv.Itoa(int(form.UserId))
	err = utils.RedisClient.Del(key).Err()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "存储禁言信息出错", "", err.Error())
		return
	}
	liveMsg := services.InitLiveMsg()
	// 私聊通知
	uidStr := strconv.Itoa(int(form.UserId))
	go liveMsg.AssistantCancelKick(&roomInfo, uidStr, admin.AdminRole)
	response.ResponseOk(c, "ok", nil)
	return
}

// 获取被踢列表
func LiveKickers(c *gin.Context) {
	roomId := c.Query("room_id")
	if roomId == "" {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", "")
		return
	}
	key := utils.REDIS_LIVE_FORBIDEN + roomId + ":" + "*"
	muteList, err := utils.RedisClient.Keys(key).Result()
	if err != nil {
		utils.LogErrorF("获取被踢列表失败,err:%s", err.Error())
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取被踢列表失败", "", "")
		return
	}
	wg := sync.WaitGroup{}
	mutechan := make(chan redismodels.MsgMuteItem, len(muteList))
	for _, v := range muteList {
		wg.Add(1)
		go redismodels.GetMuteUserInfo(&wg, mutechan, v)
	}
	wg.Wait()
	close(mutechan)
	var muters redismodels.MuteList
	for m := range mutechan {
		if m.EndT != -1 {
			muters = append(muters, m)
		}
	}

	sort.Sort(muters)

	response.ResponseOk(c, "ok", muters)
	return
}

const DEFAULT_FORBIDDENUSER = 60 * 60 * 24 * 365

// 拉黑
func LiveForbidden(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var form request.ForbiddenUserReq
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	var adminModel dbmodels.AppRoomAdmin
	// 校验管理员身份
	admin, err := adminModel.GetAnchorByUIdAndRId(userId, form.RoomId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询管理员错误", "", err.Error())
		return
	}
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "对不起，权限不足", "", "")
		return
	}
	roomInfo, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(form.RoomId))
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询房间信息失败", "", err.Error())
		return
	}
	// 校验被封禁对象信息
	kicker, err := adminModel.GetAnchorByUIdAndRId(form.UserId, form.RoomId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询管理员错误", "", err.Error())
		return
	}
	if err == nil {
		// 判断权限
		if kicker.AdminRole >= admin.AdminRole {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "对不起，权限不足", "", "")
			return
		}
	}
	mute, err := new(redismodels.UserInfo).GetUserInfo(form.UserId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户信息失败", "", err.Error())
		return
	}
	adminer, err := new(redismodels.UserInfo).GetUserInfo(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户信息失败", "", err.Error())
		return
	}
	forbiddenUser := redismodels.MsgUserObj{
		UserId: form.UserId, NickName: mute.UserNickname,
		Icon: mute.UserIconurl, Gender: mute.UserGender,
		Role: kicker.AdminRole, VipLevel: mute.VipLevel,
	}
	adminUser := redismodels.MsgUserObj{
		UserId: userId, NickName: adminer.UserNickname,
		Role: admin.AdminRole, Gender: adminer.UserGender,
		VipLevel: adminer.VipLevel,
	}
	muteItem := redismodels.MsgMuteItem{
		User:   forbiddenUser,
		Admin:  adminUser,
		StartT: time.Now().Unix(),
		EndT:   -1,
	}
	uids := []string{strconv.Itoa(int(form.UserId))}
	err = tencentIm.MuteGroup(strconv.Itoa(int(form.RoomId)), uids, DEFAULT_FORBIDDENUSER)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "调用im禁言err", "", err.Error())
		return
	}
	key := utils.REDIS_LIVE_FORBIDEN + strconv.Itoa(int(form.RoomId)) + ":" + strconv.Itoa(int(form.UserId))
	err = utils.RedisClient.Set(key, muteItem, -1).Err()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "存储拉黑信息出错", "", err.Error())
		return
	}

	// 删除麦位
	_, data, _, err := new(redismodels.Wheat).SystemDown(int(form.RoomId), int(form.UserId))
	if err != nil {
		str := fmt.Sprintf("删除麦位失败[%d][%d],%s,%s", form.RoomId, form.UserId, key, err.Error())
		utils.Logger.Error(str)
		return
	}
	// 删除麦序
	_, _, err = new(redismodels.WheatQueue).SystemDown(int(form.RoomId), int(form.UserId))
	if err != nil && err != redis.Nil {
		str := fmt.Sprintf("删除麦位失败[%d][%d],%s,%s", form.RoomId, form.UserId, key, err.Error())
		utils.Logger.Error(str)
		return
	}
	liveMsg := services.InitLiveMsg()
	// 群通知
	go liveMsg.AnnounceForbidden(&roomInfo, &mute, &data, &adminUser)
	// 私聊通知
	uidStr := strconv.Itoa(int(mute.UserID))
	go liveMsg.AssistantBeBan(&roomInfo, uidStr, admin.AdminRole)
	response.ResponseOk(c, "ok", data)
	return
}

// 取消拉黑
func LiveUnForbidden(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var form request.ForbiddenUserReq
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	var adminModel dbmodels.AppRoomAdmin
	// 校验管理员身份
	admin, err := adminModel.GetAnchorByUIdAndRId(userId, form.RoomId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询管理员错误", "", err.Error())
		return
	}
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "对不起，权限不足", "", "")
		return
	}
	// 校验被封禁对象信息
	kicker, err := adminModel.GetAnchorByUIdAndRId(form.UserId, form.RoomId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询管理员错误", "", err.Error())
		return
	}
	if err == nil {
		// 判断权限
		if kicker.AdminRole >= admin.AdminRole {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "对不起，权限不足", "", "")
			return
		}
	}
	roomInfo, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(form.RoomId))
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询房间信息失败", "", err.Error())
		return
	}

	uids := []string{strconv.Itoa(int(form.UserId))}
	err = tencentIm.MuteGroup(strconv.Itoa(int(form.RoomId)), uids, 0)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "调用im禁言err", "", err.Error())
		return
	}
	key := utils.REDIS_LIVE_FORBIDEN + strconv.Itoa(int(form.RoomId)) + ":" + strconv.Itoa(int(form.UserId))
	err = utils.RedisClient.Del(key).Err()
	if err != nil {
		return
	}
	liveMsg := services.InitLiveMsg()
	// 私聊通知
	uidStr := strconv.Itoa(int(form.UserId))
	go liveMsg.AssistantCancelBan(&roomInfo, uidStr, admin.AdminRole)
	response.ResponseOk(c, "ok", nil)
	return
}

// 黑名单
func LiveForbiddenUsers(c *gin.Context) {
	roomId := c.Query("room_id")
	if roomId == "" {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", "")
		return
	}
	key := utils.REDIS_LIVE_FORBIDEN + roomId + ":" + "*"
	muteList, err := utils.RedisClient.Keys(key).Result()
	if err != nil {
		utils.LogErrorF("获取拉黑列表失败,err:%s", err.Error())
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取拉黑列表失败", "", "")
		return
	}
	wg := sync.WaitGroup{}
	mutechan := make(chan redismodels.MsgMuteItem, len(muteList))
	for _, v := range muteList {
		wg.Add(1)
		go redismodels.GetMuteUserInfo(&wg, mutechan, v)
	}
	wg.Wait()
	close(mutechan)
	var muters redismodels.MuteList
	for m := range mutechan {
		if m.EndT == -1 {
			muters = append(muters, m)
		}
	}

	sort.Sort(muters)
	response.ResponseOk(c, "ok", muters)
	return
}

// 获取在线人员列表
func GetLiveRoomOnlineMember(c *gin.Context) {
	roomId := c.Query("room_id")
	if roomId == "" {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", "")
		return
	}
	results, err := redismodels.GetLiveRoomOnline(redismodels.DEFAULT_ONLINE_NUMBER, roomId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取在线人员错误", "", "")
		utils.Logger.Error(err.Error())
		return
	}
	response.ResponseOk(c, "ok", results)
	return
}

// 开关麦位
func LiveSwitchWheat(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.LiveSwitchWheatReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	room, err := new(dbmodels.AppLiveRoom).QueryRoomId(paramsJSON.RoomId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间不存在", "", err.Error())
		return
	}
	wheat := redismodels.Wheat{}
	updateMap := make(map[string]interface{})
	if paramsJSON.Switch == 1 {
		wheat, err = new(redismodels.Wheat).OpenWheat(paramsJSON.RoomId, room.RoomUserId)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, err.Error(), "", "")
			return
		}
		updateMap["room_speak_type"] = dbmodels.SPEAK_TYPE_LIVE_WITH_MIC
	} else {
		wheat, err = new(redismodels.Wheat).OffWheat(paramsJSON.RoomId, userId)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, err.Error(), "", "")
			return
		}
		updateMap["room_speak_type"] = dbmodels.SPEAK_TYPE_LIVE_WITHOUT_MIC
	}
	err = new(dbmodels.AppLiveRoom).Update(paramsJSON.RoomId, updateMap)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "修改房间信息失败", "", err.Error())
		return
	}
	// 删除缓存
	go utils.RedisClient.Del(fmt.Sprintf("%s%d", utils.REDIS_LIVE_ROOM_INFO, paramsJSON.RoomId))
	go new(services.LiveMsg).AnnounceSwitchWheat(&room, &wheat, paramsJSON.Switch)
	response.ResponseOk(c, "", wheat)
	return
}

// 进入直播间前预计预检查
func LiveRoomBeforeToCheck(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.LiveRoomBeforeToCheckReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	// 查询房间缓存
	data, err := new(dbmodels.AppLiveRoom).QueryRoomId(paramsJSON.RoomId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间不存在", "", err.Error())
		return
	}
	rep := response.JoinStudioBeforeCheckResp{
		RoomType:       data.RoomType,
		RoomLiveStatus: data.RoomLiveStatus,
		RoomStatus:     data.RoomStatus,
		CanJoin:        response.JOIN_ROOM_TYPE_CAN,
		NeedPassword:   response.NEED_PASSWORD_NEED_NO,
	}

	// 查询用户是否超管
	info, err := new(redismodels.UserInfo).GetUserInfo(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if info.UserIsSuper == redismodels.USER_INFO_IS_SUPER_YES {
		rep.CanJoin = response.JOIN_ROOM_TYPE_CAN
		rep.NeedPassword = response.NEED_PASSWORD_NEED_NO
		response.ResponseOk(c, "", rep)
		return
	}
	// 用户身份
	key := utils.REDIS_LIVE_FORBIDEN + strconv.Itoa(paramsJSON.RoomId) + ":" + strconv.Itoa(int(userId))
	get, err := utils.RedisClient.Get(key).Result()
	if err != nil && err != redis.Nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if get != "" {
		rep.CanJoin = response.JOIN_ROOM_TYPE_CANT
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "你已经被房主踢出或拉黑，暂无法进入该直播间", "", "")
		return
	}
	// 判断房间当前状态,封禁和整改
	if data.RoomStatus == dbmodels.ROOM_STATUS_PLATFORM_RECTIFICATION {
		// 查询封禁时间
		closeLog, err := new(dbmodels.AppRoomCloseLog).GetLastRectifyCloseLogByRoomId(data.RoomId, dbmodels.CLOSE_LOG_TYPE_RECTIFY)
		if err != nil && err != gorm.ErrRecordNotFound {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询关闭日志错误", "", err.Error())
			return
		}
		rep.ControlEndTime = closeLog.LogEndTime
		rep.CanJoin = response.JOIN_ROOM_TYPE_CANT
		response.ResponseOk(c, "", rep)
		return
	}
	if data.RoomStatus == dbmodels.ROOM_STATUS_PLATFORM_BAN {
		rep.CanJoin = response.JOIN_ROOM_TYPE_CANT
		response.ResponseOk(c, "", rep)
		return
	}
	role, err := new(redismodels.Wheat).QueryUserRole(paramsJSON.RoomId, userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	rep.Role = role
	// 房间关闭状态
	if data.RoomStatus == dbmodels.ROOM_STATUS_TIME_OUT_OFF || data.RoomStatus == dbmodels.ROOM_STATUS_ADMIN_OFF {
		if role >= dbmodels.ROOM_ADMIN_ROLE_ADMIN {
			rep.CanJoin = response.JOIN_ROOM_TYPE_CAN
			rep.NeedPassword = response.NEED_PASSWORD_NEED_NO
		} else {
			rep.CanJoin = response.JOIN_ROOM_TYPE_CANT
		}
		response.ResponseOk(c, "", rep)
		return
	}
	// 校验正常房间管理员身份
	if role >= dbmodels.ROOM_ADMIN_ROLE_DEPUTY_ANCHOR {
		rep.CanJoin = response.JOIN_ROOM_TYPE_CAN
		rep.NeedPassword = response.NEED_PASSWORD_NEED_NO
		response.ResponseOk(c, "", rep)
		return
	}

	// 校验密码
	if data.RoomPassword != "" {
		rep.NeedPassword = response.NEED_PASSWORD_NEED
		rep.Password = utils.FuncMD5(data.RoomPassword)
	}

	response.ResponseOk(c, "", rep)
	return
}

// 确认下播
func LiveConfirmDowncast(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.LiveConfirmToDownloadReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	// 查询房间是否存在
	model := dbmodels.AppLiveRoom{}
	room, err := model.QueryRoomId(paramsJSON.RoomId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间不存在", "", "")
		return
	}

	// 校验房间状态
	if room.RoomLiveStatus != dbmodels.ROOM_LIVE_STATUS_ON || room.RoomType != dbmodels.ROOM_TYPE_LIVE || room.RoomStatus != dbmodels.ROOM_STATUS_OK {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前房间状态不能下播", "", "")
		return
	}

	// 用户身份鉴权
	role, err := new(redismodels.Wheat).QueryUserRole(paramsJSON.RoomId, userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "", "", err.Error())
		return
	}

	if role != redismodels.WHEAT_ROLE_ANCHOR {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "无权操作", "", "")
		return
	}
	// 下播
	err = model.UpdateLiveStatus(paramsJSON.RoomId, dbmodels.ROOM_LIVE_STATUS_OFF)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	_, err = new(redismodels.Wheat).ConfirmDowncast(paramsJSON.RoomId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "", "", err.Error())
		return
	}

	err = new(redismodels.WheatQueue).ConfirmDowncast(paramsJSON.RoomId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "", "", err.Error())
		return
	}
	// 下播后删除邀请记录
	m := services.InviteUpWheat{
		RoomId: int(room.RoomId),
	}
	err = m.RemoveInviteUpWheatLog()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	// 发送下播消息
	go new(services.LiveMsg).AnnounceConfirmDownload(&room, false)
	// 根据用户获取自定义时间段的收礼物数
	err, settlement := new(dbmodels.AppAnchorRoomProp).GetLiveAnchorIncome(userId, room.RoomId, room.RoomLastOnline, room.RoomLogId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取礼物收益失败", "", err.Error())
		return
	}
	// 删除热度
	go redismodels.NewRoomHeat().Delete(paramsJSON.RoomId)
	settlement.LiveTime = time.Now().Unix() - room.RoomLastOnline
	response.ResponseOk(c, "确认下播成功", settlement)
	return
}

// 房间日榜
func GetDailyLeaderboard(c *gin.Context) {
	// roomId := c.Query("room_id")
	// if roomId == "" {
	//	response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", "")
	//	return
	// }
	// id, err := strconv.Atoi(roomId)
	// if err != nil {
	//	response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "id类型有误", "", err.Error())
	//	return
	// }
	// //在线成员，按照贡献大小排序,获取礼物今日送礼最多五十人
	// gift := dbmodels.AppAnchorRoomGift{}
	// list, err := gift.GetContributionList(int64(id), 50)
	// if err != nil {
	//	response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询用户财富值失败", "", err.Error())
	//	return
	// }
	// response.ResponseOk(c, "ok", list)
	// return
}

// 背景图
func LiveBackground(c *gin.Context) {
	paramsJSON := request.LiveBackgroundReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	attr, err := new(dbmodels.AppLiveAttr).GetAppLiveAttrById(int64(paramsJSON.AttrId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	background := []string{}
	err = json.Unmarshal([]byte(attr.AttrBackground), &background)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取直播背景图成功", background)
	return
}

// 禁麦
func LiveBanWheat(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.LiveBanWheatReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	// 查询房间是否存在
	model := dbmodels.AppLiveRoom{}
	room, err := model.QueryRoomId(paramsJSON.RoomId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "房间不存在", "", "")
		return
	}

	wheat, err := new(redismodels.Wheat).BanWheat(paramsJSON.RoomId, userId, paramsJSON.WheatKey, paramsJSON.Action)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, err.Error(), "", "")
		return
	}

	go new(services.LiveMsg).AnnounceSwitchBanWheat(&room, &wheat, paramsJSON.Action, userId)

	response.ResponseOk(c, "", wheat)
	return
}

// 获取直播中收益
func GetAnchorLiveIncome(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJson := request.LiveSettlementReq{}
	err := c.ShouldBind(&paramsJson)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	room := dbmodels.AppLiveRoom{}
	data, err := room.QueryRoomId(int(paramsJson.RoomId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "房间不存在", "", err.Error())
		return
	}
	if data.RoomUserId != userId {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "无权访问", "", "")
		return
	}
	if data.RoomType != dbmodels.ROOM_TYPE_LIVE {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "当前房间未直播", "", "")
		return
	}
	if data.RoomLiveStatus == dbmodels.ROOM_LIVE_STATUS_OFF || data.RoomLiveStatus == dbmodels.ROOM_LIVE_STATUS_TIMEOUT {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "当前房间未直播", "", "")
		return
	}
	// 收益
	settlement, err := new(dbmodels.AppAnchorRoomProp).GetAnchorLiveIncome(userId, paramsJson.RoomId, data.RoomLogId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取礼物收益失败", "", err.Error())
		return
	}

	response.ResponseOk(c, "ok", settlement)
	return
}
