package controller

import (
	"fmt"
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/models/dbmodels"
	"gamers/utils"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// 用户钱包
func GetUserWalletInfo(c *gin.Context) {
	userId := utils.FuncUserId(c)
	data, err := new(dbmodels.AppUserWallet).GetUserWallet(userId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if err == gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "未找到该用户", "", "")
		return
	}
	response.ResponseOk(c, "ok", data)
	return
}

// 兑换Go币
func ExchangeMoney(c *gin.Context) {
	userId := utils.FuncUserId(c)
	//加锁
	lock := fmt.Sprintf("%s%d", utils.REDIS_EXCHANGE_MONEY_LOCK, userId)
	lockVal, lockBool := utils.AcquireLock(lock, 1, 1)
	if !lockBool {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "稍后再试", "", "")
		return
	}
	defer utils.ReleaseLock(lock, lockVal)

	var form request.ExchangeMoneyReq
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	//因为前端显示的时候是除以100,用户输入的也是除以100的金额,所以这里乘以100
	form.Money = form.Money * 100
	// 获取用户钱包
	wallet, err := new(dbmodels.AppUserWallet).Query(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户钱包失败", "", err.Error())
		return
	}

	if form.Money > wallet.WalletTotalExtractable {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "余额不足", "", "")
		return
	}

	tx := utils.GEngine.Begin()
	err = new(dbmodels.AppUserWallet).UpdateExchange(tx, userId, form.Money)
	if err != nil {
		tx.Rollback()
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "兑换失败", "", err.Error())
		return
	}

	//流水
	appTransactionModel := dbmodels.AppTransaction{
		TransactionId:         dbmodels.IDBuilderGetId(utils.REDIS_IDBUILDER_TRANSACTION_ID),
		TransactionType:       dbmodels.DB_TRANSACTION_TYPE_BALANCE_TO_GO,
		TransactionRemark:     "兑换go币",
		TransactionAmount:     form.Money,
		TransactionGetAmount:  form.Money, //现在比例1:1,比例变更时修改此字段
		TransactionFromUserId: userId,
		TransactionToUserId:   userId,
		TransactionStatus:     dbmodels.DB_TRANSACTION_COMPLETE,
	}

	err = appTransactionModel.Create(tx)
	if err != nil {
		tx.Rollback()
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "兑换失败", "", err.Error())
		return
	}

	//更新缓存
	key := fmt.Sprintf("%s%d", utils.REDIS_USER_INFO, userId)
	over := wallet.WalletTotalOver + form.Money
	err = utils.RedisClient.HSet(key, "WalletTotalOver", over).Err()
	if err != nil {
		tx.Rollback()
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "兑换失败", "", err.Error())
		return
	}
	tx.Commit()
	response.ResponseOk(c, "兑换成功", nil)
}

// 用户收益明细
func GetUserIncome(c *gin.Context) {
	userId := utils.FuncUserId(c)
	st, et, err := utils.GetSTAndETTime(c)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "时间选择有误", "", err.Error())
		return
	}
	data, err := services.GetUserIncome(userId, st, et)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询收入有误", "", err.Error())
		return
	}
	response.ResponseOk(c, "ok", data)
}

//Go币明细
func UserGoBill(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.UserGoBillReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	r, err := services.UserGoBill(paramsJSON, userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "查询成功", r)
}

//用户首充
func UserFirstCharge(c *gin.Context) {
	userId := utils.FuncUserId(c)
	charge, err := services.UserFirstCharge(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取用户首充信息成功", charge)
	return
}

// 其他收入
func UserOtherIncome(c *gin.Context) {
	userId := utils.FuncUserId(c)
	//获取分页参数
	page, size, skip, err := utils.GetPageAndSize(c)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "分页参数错误", "", err.Error())
		return
	}
	resp, err := services.UserOtherIncome(userId, page, size, skip)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取收入失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "ok", resp)
}
