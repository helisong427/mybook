package controller

import (
	"encoding/json"
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"gamers/utils/moderation"
	"strconv"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

//GetTweetTag 获取朋友圈tag
func GetTweetTag(gctx *gin.Context) {
	model := dbmodels.SystemParam{}
	data, err := model.QueryKey(dbmodels.PRAM_KEY_TWEET_TAG)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	r := []response.GetTweetTagRep{}
	err = json.Unmarshal([]byte(data["value"]), &r)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(gctx, "获取成功", r)
}

//TweetPublish 发布朋友圈
func TweetPublish(gctx *gin.Context) {
	paramsJSON := request.TweetPublishReq{}
	err := gctx.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	topicsLen := len(paramsJSON.Topics)
	if topicsLen > 5 {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "话题最多选择5个", "", "")
		return
	}

	str := moderation.TextModeration(paramsJSON.TweetContent)
	if len(str) > 0 {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "内容包含敏感词", "", "")
		return
	}

	//朋友圈类型
	var tweetType int
	attarMap := map[string]int{}
	//如果有附件内容，校验数据
	if len(paramsJSON.TweetAttachments) > 0 {
		//附件为图片和视频
		for _, v := range paramsJSON.TweetAttachments {
			if v.Url == "" {
				response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", "附件地址不能为空")
				return
			}

			if v.Type == dbmodels.ATTACHMENT_TYPE_IMAGE || v.Type == dbmodels.ATTACHMENT_TYPE_VIDEO {
				if v.Type == dbmodels.ATTACHMENT_TYPE_VIDEO && paramsJSON.TweetSound != "" {
					response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "语音不能和视频一起上传", "", "")
					return
				}
				attarMap[v.Type] = 0

				if v.Type == dbmodels.ATTACHMENT_TYPE_IMAGE {
					tweetType = dbmodels.TWEET_TYPE_IMAGE
				}
				if v.Type == dbmodels.ATTACHMENT_TYPE_VIDEO {
					tweetType = dbmodels.TWEET_TYPE_VIDEO
				}
				continue
			} else {
				response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", "附件文件类型不合法")
				return
			}
		}
	} else if len(paramsJSON.TweetAttachments) == 0 && paramsJSON.TweetSound == "" && paramsJSON.TweetContent == "" {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "内容不能为空", "", "")
		return
	}

	if len(attarMap) > 1 {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "图片和视频不能一起上传", "", "")
		return
	}

	//插入朋友圈数据
	userId, _ := gctx.Get("userID")
	userIdInt64, _ := strconv.ParseInt(userId.(string), 10, 64)
	attachmentString, _ := json.Marshal(paramsJSON.TweetAttachments)
	model := dbmodels.AppTweet{
		TweetUserID:        userIdInt64,
		TweetContent:       paramsJSON.TweetContent,
		TweetAttachment:    string(attachmentString),
		TweetSendTime:      time.Now().Unix(),
		TweetSendRegionId:  int64(paramsJSON.TweetSendRegionId),
		TweetSendLatitude:  paramsJSON.TweetSendLatitude,
		TweetSendLongitude: paramsJSON.TweetSendLongitude,
		TweetSendPosition:  paramsJSON.TweetSendPosition,
		TweetSendTerminal:  gctx.Request.Header.Get("Client-Type"),
		TweetVisible:       int(paramsJSON.TweetVisible),
		TweetSound:         paramsJSON.TweetSound,
		TweetSoundTime:     paramsJSON.TweetSoundTime,
		TweetType:          tweetType,
	}

	topics := make([]dbmodels.AppTweetTopic, topicsLen)
	//插入话题数据
	if topicsLen > 0 {
		for k, v := range paramsJSON.Topics {
			topics[k].TopicTweetID = model.TweetID
			topics[k].TopicTopicID = int64(v)
		}
	}
	err = model.Create(topics)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "发布失败", "", err.Error())
		return
	}
	//im := services.InitTweet()
	//go im.NewTweet(&model)
	go func() {
		_ = new(redismodels.Task).Init().ReportConditionTag(userIdInt64, "publishCircleOfFriend", 1)
	}()

	response.ResponseOk(gctx, "发布成功", nil)
}

//TweetDetail 获取朋友圈详情
func TweetDetail(gctx *gin.Context) {
	userId, _ := gctx.Get("userID")
	paramsJSON := request.TweetDetailReq{}
	err := gctx.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	model := dbmodels.AppTweet{}

	tweet, err := model.QueryByIdJoin(int64(paramsJSON.Id), userId.(string))
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	if tweet.TweetID == 0 {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "详情不存在", "", "")
		return
	}

	attachments := []response.TweetAttachments{}
	json.Unmarshal([]byte(tweet.TweetAttachment), &attachments)

	userinfo := response.TweetUserInfo{
		UserId:       tweet.UserID,
		UserNickname: tweet.UserNickname,
		UserIconurl:  tweet.UserIconurl,
		UserGender:   int(tweet.UserGender),
		UserAge:      utils.FuncGetAge(int(tweet.UserBirthday)),
	}

	////查询话题
	//topicModel := dbmodels.AppTweetTopic{}
	//topData, err := topicModel.Query([]int64{tweet.TweetID})
	//if err != nil {
	//	response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "获取详情失败", "", err.Error())
	//	return
	//}
	//
	////取topic
	//topic := []response.TweetTopic{}
	//for _, value := range topData {
	//	if tweet.TweetID == value.TopicTweetID {
	//		t := response.TweetTopic{
	//			TopicID:    value.TopicID,
	//			TopicTitle: value.AppTopics.TopicTitle,
	//		}
	//		topic = append(topic, t)
	//	}
	//
	//}

	r := response.TweetDetailRep{
		TweetId:            tweet.TweetID,
		TweetContent:       tweet.TweetContent,
		TweetAttachment:    attachments,
		TweetSound:         tweet.TweetSound,
		TweetSoundTime:     tweet.TweetSoundTime,
		TweetSendRegionId:  tweet.TweetSendRegionId,
		TweetSendLatitude:  tweet.TweetSendLatitude,
		TweetSendLongitude: tweet.TweetSendLongitude,
		TweetSendTime:      tweet.TweetSendTime,
		TweetSendPosition:  tweet.TweetSendPosition,
		TweetSendTerminal:  tweet.TweetSendTerminal,
		TweetLikeCount:     tweet.TweetLikeCount,
		TweetCommentCount:  tweet.TweetCommentCount,
		TweetShareCount:    tweet.TweetShareCount,
		TweetReadCount:     tweet.TweetReadCount,
		UserInfo:           userinfo,
		//Topic:              topic,
	}
	if tweet.UserIsLike == 1 {
		r.IsLike = 1
	}
	if tweet.IsAttention > 0 {
		r.IsAttention = 1
	}
	//增加阅读量
	go model.AddReadCount(int64(paramsJSON.Id))
	// 写历史记录表
	userIdNumber := utils.FuncUserId(gctx)
	tweetLog := dbmodels.AppTweetVisitorLog{
		LogMediaType:     tweet.TweetType,
		LogTweetId:       tweet.TweetID,
		LogOperateUserId: userIdNumber,
		LogType:          dbmodels.TWEET_LOG_TYPE_READ,
		LogTips:          "阅读了你的动态",
		LogTweetUserId:   tweet.UserID,
		LogTweetContent:  tweet.TweetContent,
		LogMediaUrl:      "",
	}
	err = tweetLog.Create()
	response.ResponseOk(gctx, "获取详情成功", r)
}

//TweetList 朋友圈列表
func TweetList(gctx *gin.Context) {
	userId := utils.FuncUserId(gctx)
	paramsJSON := request.TweetListReq{}
	err := gctx.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	var (
		total  int64
		tweets []dbmodels.AppTweetJoin
	)
	if paramsJSON.TagId == dbmodels.TWEET_TAG_ID_RECOMMEND {
		popular, err := services.NewTweetPopular(userId)
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "获取列表失败", "", err.Error())
			return
		}
		total, tweets, err = popular.GetPopularList(paramsJSON)
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "获取列表失败", "", err.Error())
			return
		}
	} else {
		model := dbmodels.AppTweet{}
		total, tweets, err = model.PageQuery(paramsJSON.Page, paramsJSON.Size, userId, paramsJSON.TagId)
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "获取列表失败", "", err.Error())
			return
		}
	}

	list := []response.TweetListRep{}
	for _, v := range tweets {
		attachments := []response.TweetAttachments{}
		json.Unmarshal([]byte(v.TweetAttachment), &attachments)
		userinfo := response.TweetUserInfo{
			UserId:       v.UserID,
			UserNickname: v.UserNickname,
			UserIconurl:  v.UserIconurl,
			UserGender:   int(v.UserGender),
			UserAge:      utils.FuncGetAge(int(v.UserBirthday)),
		}

		resp := response.TweetListRep{
			TweetId:            v.TweetID,
			TweetContent:       v.TweetContent,
			TweetAttachment:    attachments,
			TweetSound:         v.TweetSound,
			TweetSoundTime:     v.TweetSoundTime,
			TweetSendLatitude:  v.TweetSendLatitude,
			TweetSendLongitude: v.TweetSendLongitude,
			TweetSendTime:      v.TweetSendTime,
			TweetSendPosition:  v.TweetSendPosition,
			TweetSendRegionId:  v.TweetSendRegionId,
			TweetSendTerminal:  v.TweetSendTerminal,
			TweetLikeCount:     v.TweetLikeCount,
			TweetCommentCount:  v.TweetCommentCount,
			TweetShareCount:    v.TweetShareCount,
			TweetReadCount:     v.TweetReadCount,
			UserInfo:           userinfo,
		}
		if v.UserIsLike == 1 {
			resp.IsLike = 1
		}
		if v.IsAttention > 0 {
			resp.IsAttention = 1
		}
		list = append(list, resp)
	}
	r := response.BasePageList{
		Page:       paramsJSON.Page,
		Size:       paramsJSON.Size,
		Total:      total,
		TotalPages: utils.FuncTotalPages(total, paramsJSON.Size),
		List:       list,
	}

	response.ResponseOk(gctx, "朋友圈列表获取成功", r)
}

//SendTweetComment 发布朋友圈评论
func SendTweetComment(gctx *gin.Context) {
	paramsJSON := request.SendTweetCommentReq{}
	err := gctx.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	str := moderation.TextModeration(paramsJSON.Content)
	if len(str) > 0 {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "内容包含敏感词", "", "")
		return
	}
	_, tweet, err := new(dbmodels.AppTweet).QueryById(paramsJSON.Id)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "朋友圈不存在", "", "")
		return
	}
	userId := utils.FuncUserId(gctx)
	// 获取用户信息
	userInfo, err := new(redismodels.UserInfo).GetUserInfo(userId)
	if err != nil {
		utils.LogInfoF("获取用户信息失败，err:%s", err.Error())
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "获取用户信息失败", "", "")
		return
	}
	model := dbmodels.AppTweetComment{
		CommentTweetID:    int64(paramsJSON.Id),
		CommentUserID:     userId,
		CommentParentID:   int64(paramsJSON.CommentId),
		CommentToParentID: int64(paramsJSON.ToCommentId),
		CommentContent:    paramsJSON.Content,
		CommentToUserID:   int64(paramsJSON.ToUserId),
	}
	err = model.Create()
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	_, data, err := model.QueryByOne(model.CommentID, strconv.Itoa(int(userId)))
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	r := response.TweetCommentRep{
		CommentID:         data.CommentID,
		CommentUserID:     data.CommentUserID,
		CommentToUserID:   data.CommentToUserID,
		CommentParentID:   data.CommentParentID,
		CommentToParentID: data.CommentToParentID,
		CommentContent:    data.CommentContent,
		CommentLikeCount:  data.CommentLikeCount,
		Created:           data.Created,
		UserNickname:      data.UserNickname,
		UserIconurl:       data.UserIconurl,
		Child:             nil,
	}
	if data.UserIsLike == 1 {
		r.IsLike = 1
	}

	im := services.InitTweet()
	go im.Comment(tweet, redismodels.MsgUserObj{UserId: userId, Icon: userInfo.UserIconurl, NickName: userInfo.UserNickname}, &model)

	go func() {
		_ = new(redismodels.Task).Init().ReportConditionTag(userId, "commentCircleOfFriend", 1)
	}()

	response.ResponseOk(gctx, "评论成功", r)
}

//GetTweetComment 获取朋友圈评论
func GetTweetComment(gctx *gin.Context) {
	userId, _ := gctx.Get("userID")
	paramsJSON := request.GetTweetCommentReq{}
	err := gctx.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	model := dbmodels.AppTweetComment{}
	total, comment, err := model.QueryByTweetID(paramsJSON.Id, paramsJSON.Page, paramsJSON.Size, userId.(string))
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	child := []dbmodels.AppTweetCommentJoin{}
	wg := sync.WaitGroup{}
	childMap := sync.Map{}
	for _, v := range comment {
		wg.Add(1)
		go func(v dbmodels.AppTweetCommentJoin) {
			defer wg.Done()
			total, childData, err := model.QueryByCommentParentId(v.CommentID, userId.(string))
			if err != nil && err != gorm.ErrRecordNotFound {
				response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
				return
			}
			childMap.Store(v.CommentID, total)
			child = append(child, childData...)
		}(v)
	}
	wg.Wait()

	data := commentHandler(comment, child, &childMap)
	r := response.BasePageList{
		Page:       paramsJSON.Page,
		Size:       paramsJSON.Size,
		Total:      total,
		TotalPages: utils.FuncTotalPages(total, paramsJSON.Size),
		List:       data,
	}

	response.ResponseOk(gctx, "获取评论列表成功", r)
}

//获取评论详情列表
func TweetCommentDetailList(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.TweetCommentDetailListReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	total, comment, err := new(dbmodels.AppTweetComment).QueryPageByCommentParentId(int64(paramsJSON.CommentId), userId, paramsJSON.Page, paramsJSON.Size)
	list := []response.TweetCommentDetailListRep{}
	for _, v := range comment {
		t := response.TweetCommentDetailListRep{
			CommentID:         v.CommentID,
			CommentUserID:     v.CommentUserID,
			CommentToUserID:   v.CommentToUserID,
			ToUserNickname:    v.ToUserNickname,
			CommentParentID:   v.CommentParentID,
			CommentToParentID: v.CommentToParentID,
			CommentContent:    v.CommentContent,
			CommentLikeCount:  v.CommentLikeCount,
			Created:           v.Created,
			UserNickname:      v.UserNickname,
			UserIconurl:       v.UserIconurl,
		}
		if v.UserIsLike == 1 {
			t.IsLike = 1
		}
		list = append(list, t)
	}

	r := response.BasePageList{
		Page:       paramsJSON.Page,
		Size:       paramsJSON.Size,
		Total:      total,
		TotalPages: utils.FuncTotalPages(total, paramsJSON.Size),
		List:       list,
	}
	response.ResponseOk(c, "获取评论详情列表成功", r)
	return
}

// 大神详情朋友圈
func SparringDetailList(c *gin.Context) {
	paramsJSON := request.SparringDetailTweetReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	model := dbmodels.AppTweet{}
	tweets, err := model.QuerySparringDetailList(paramsJSON.UserId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取列表失败", "", err.Error())
		return
	}

	var list []response.TweetListRep
	for _, v := range tweets {
		var attachments []response.TweetAttachments
		json.Unmarshal([]byte(v.TweetAttachment), &attachments)
		userinfo := response.TweetUserInfo{
			UserId:       v.UserID,
			UserNickname: v.UserNickname,
			UserIconurl:  v.UserIconurl,
			UserGender:   v.UserGender,
			UserAge:      utils.FuncGetAge(int(v.UserBirthday)),
		}

		resp := response.TweetListRep{
			TweetId:            v.TweetID,
			TweetContent:       v.TweetContent,
			TweetAttachment:    attachments,
			TweetSound:         v.TweetSound,
			TweetSoundTime:     v.TweetSoundTime,
			TweetSendLatitude:  v.TweetSendLatitude,
			TweetSendLongitude: v.TweetSendLongitude,
			TweetSendTime:      v.TweetSendTime,
			TweetSendPosition:  v.TweetSendPosition,
			TweetSendRegionId:  v.TweetSendRegionId,
			TweetSendTerminal:  v.TweetSendTerminal,
			TweetLikeCount:     v.TweetLikeCount,
			TweetCommentCount:  v.TweetCommentCount,
			TweetShareCount:    v.TweetShareCount,
			TweetReadCount:     v.TweetReadCount,
			UserInfo:           userinfo,
		}
		if v.UserIsLike == 1 {
			resp.IsLike = 1
		}
		if v.IsAttention > 0 {
			resp.IsAttention = 1
		}
		list = append(list, resp)
	}

	response.ResponseOk(c, "获取大神详情朋友圈成功", list)
	return

}

//LikeTweetComment 朋友圈评论点赞
func LikeTweetComment(gctx *gin.Context) {
	paramsJSON := request.LikeTweetCommentReq{}
	err := gctx.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	commentModel := dbmodels.AppTweetComment{}
	has, err := commentModel.QueryExist(paramsJSON.CommentId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if has == 0 {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "评论不存在", "", "")
		return
	}

	userId, _ := gctx.Get("userID")
	userIdInt64, _ := strconv.ParseInt(userId.(string), 10, 64)
	model := dbmodels.AppTweetCommentUser{}
	has, data, err := model.QueryOne(paramsJSON.CommentId, int(userIdInt64))
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	r := response.LikeRep{IsLike: 1}

	//没有数据时创建点赞数据
	if has == 0 {
		model.UserCommentID = int64(paramsJSON.CommentId)
		model.UserUserID = int64(userIdInt64)
		model.UserIsLike = dbmodels.USER_IS_LIKE_YES
		err := model.Create()
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		response.ResponseOk(gctx, "点赞成功", r)
		return
	}

	//有数据，更具点赞状态点赞/取消
	if data.UserIsLike == dbmodels.USER_IS_LIKE_NO {
		model.UserID = data.UserID
		model.UserCommentID = data.UserCommentID //增加点赞数使用
		_, err := model.PointLike()
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		response.ResponseOk(gctx, "点赞成功", r)
	} else {
		model.UserID = data.UserID
		model.UserCommentID = data.UserCommentID //减少点赞数使用
		_, err := model.CancelLike()
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		r.IsLike = 0
		response.ResponseOk(gctx, "取消成功", r)
	}

}

//LikeTweet 朋友圈点赞
func LikeTweet(gctx *gin.Context) {
	paramsJSON := request.LikeTweetReq{}
	err := gctx.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	userId := utils.FuncUserId(gctx)
	// 获取用户信息
	userInfo, err := new(redismodels.UserInfo).GetUserInfo(userId)
	if err != nil {
		utils.LogInfoF("获取用户信息失败，err:%s", err.Error())
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "获取用户信息失败", "", "")
		return
	}
	//查询朋友圈是否存在
	_, tweet, err := new(dbmodels.AppTweet).QueryById(paramsJSON.TweetId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "朋友圈不存在", "", "")
		return
	}

	model := dbmodels.AppTweetUser{}
	has, data, err := model.QueryOne(paramsJSON.TweetId, int(userId))
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	r := response.LikeRep{IsLike: 1}

	//没有数据时创建点赞数据
	im := services.InitTweet()
	if has == 0 {
		model.UserTweetID = int64(paramsJSON.TweetId)
		model.UserUserID = userId
		model.UserIsLike = dbmodels.USER_IS_LIKE_YES
		err := model.Create()
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		if userId != tweet.TweetUserID {
			go im.Like(tweet, redismodels.MsgUserObj{UserId: userId, Icon: userInfo.UserIconurl, NickName: userInfo.UserNickname})
		}

		// 任务触发
		go func() {
			_ = new(redismodels.Task).Init().ReportConditionTag(userId, "likeCircleOfFriend", 1)
		}()

		response.ResponseOk(gctx, "点赞成功", r)
		return
	}
	//有数据，更具点赞状态点赞/取消
	if data.UserIsLike == dbmodels.USER_IS_LIKE_NO {
		model.UserID = data.UserID
		model.UserTweetID = data.UserTweetID //增加点赞数使用
		err := model.PointLike()
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		response.ResponseOk(gctx, "点赞成功", r)
	} else {
		model.UserID = data.UserID
		model.UserTweetID = data.UserTweetID //减少点赞数使用
		err := model.CancelLike()
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		r.IsLike = 0
		response.ResponseOk(gctx, "取消成功", r)
	}
}

//HiddenTweet 屏蔽朋友圈
func HiddenTweet(gctx *gin.Context) {
	paramsJSON := request.HiddenTweetReq{}
	err := gctx.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	userId, _ := gctx.Get("userID")
	userIdInt64, _ := strconv.ParseInt(userId.(string), 10, 64)

	//查询朋友圈是否存在
	tweetModel := dbmodels.AppTweet{}
	has, tweetData, err := tweetModel.QueryById(paramsJSON.TweetId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if has == 0 {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "朋友圈不存在", "", "")
		return
	}

	if tweetData.TweetUserID == userIdInt64 {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "不能屏蔽自己的朋友圈", "", "")
		return
	}

	model := dbmodels.AppTweetUser{}
	row, data, err := model.QueryOne(paramsJSON.TweetId, int(userIdInt64))
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	if row == 0 {
		model.UserTweetID = int64(paramsJSON.TweetId)
		model.UserUserID = int64(userIdInt64)
		model.UserIsLike = dbmodels.USER_IS_LIKE_NO      //未点赞
		model.UserIsHidden = dbmodels.USER_IS_HIDDEN_YES //屏蔽
		err := model.Create()
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		response.ResponseOk(gctx, "屏蔽成功", nil)
		return
	}

	if data.UserIsHidden == dbmodels.USER_IS_LIKE_NO {
		model.UserID = data.UserID
		err = model.UpdateHidden()
		if err != nil {
			response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		response.ResponseOk(gctx, "屏蔽成功", nil)
	} else {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "请勿重复屏蔽", "", "")
		return
	}

}

//MyTweetList 我的朋友圈
func MyTweetList(gctx *gin.Context) {
	userId := utils.FuncUserId(gctx)
	paramsJSON := request.MyTweetList{}
	err := gctx.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	model := dbmodels.AppTweet{}
	total, tweets, err := model.QueryPageByMy(paramsJSON.Page, paramsJSON.Size, int(userId))
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "获取列表失败", "", err.Error())
		return
	}

	list := []response.TweetListRep{}
	for _, v := range tweets {
		attachments := []response.TweetAttachments{}
		json.Unmarshal([]byte(v.TweetAttachment), &attachments)
		userinfo := response.TweetUserInfo{
			UserId:       v.UserID,
			UserNickname: v.UserNickname,
			UserIconurl:  v.UserIconurl,
			UserGender:   v.UserGender,
			UserAge:      utils.FuncGetAge(int(v.UserBirthday)),
		}

		resp := response.TweetListRep{
			TweetId:            v.TweetID,
			TweetContent:       v.TweetContent,
			TweetAttachment:    attachments,
			TweetSound:         v.TweetSound,
			TweetSoundTime:     v.TweetSoundTime,
			TweetSendLatitude:  v.TweetSendLatitude,
			TweetSendLongitude: v.TweetSendLongitude,
			TweetSendTime:      v.TweetSendTime,
			TweetSendPosition:  v.TweetSendPosition,
			TweetSendRegionId:  v.TweetSendRegionId,
			TweetSendTerminal:  v.TweetSendTerminal,
			TweetLikeCount:     v.TweetLikeCount,
			TweetCommentCount:  v.TweetCommentCount,
			TweetShareCount:    v.TweetShareCount,
			TweetReadCount:     v.TweetReadCount,
			UserInfo:           userinfo,
		}
		if v.UserIsLike == 1 {
			resp.IsLike = 1
		}
		list = append(list, resp)
	}
	r := response.BasePageList{
		Page:       paramsJSON.Page,
		Size:       paramsJSON.Size,
		Total:      total,
		TotalPages: utils.FuncTotalPages(total, paramsJSON.Size),
		List:       list,
	}

	response.ResponseOk(gctx, "我的朋友圈列表获取成功", r)
}

//其他人朋友圈
func OtherTweetList(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.OtherTweetList{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	model := dbmodels.AppTweet{}
	total, tweets, err := model.QueryPageByUserId(paramsJSON.Page, paramsJSON.Size, paramsJSON.UserId, userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取列表失败", "", err.Error())
		return
	}

	list := []response.TweetListRep{}
	for _, v := range tweets {
		attachments := []response.TweetAttachments{}
		json.Unmarshal([]byte(v.TweetAttachment), &attachments)
		userinfo := response.TweetUserInfo{
			UserId:       v.UserID,
			UserNickname: v.UserNickname,
			UserIconurl:  v.UserIconurl,
			UserGender:   v.UserGender,
			UserAge:      utils.FuncGetAge(int(v.UserBirthday)),
		}

		resp := response.TweetListRep{
			TweetId:            v.TweetID,
			TweetContent:       v.TweetContent,
			TweetAttachment:    attachments,
			TweetSound:         v.TweetSound,
			TweetSoundTime:     v.TweetSoundTime,
			TweetSendLatitude:  v.TweetSendLatitude,
			TweetSendLongitude: v.TweetSendLongitude,
			TweetSendTime:      v.TweetSendTime,
			TweetSendPosition:  v.TweetSendPosition,
			TweetSendRegionId:  v.TweetSendRegionId,
			TweetSendTerminal:  v.TweetSendTerminal,
			TweetLikeCount:     v.TweetLikeCount,
			TweetCommentCount:  v.TweetCommentCount,
			TweetShareCount:    v.TweetShareCount,
			TweetReadCount:     v.TweetReadCount,
			UserInfo:           userinfo,
		}
		if v.UserIsLike == 1 {
			resp.IsLike = 1
		}
		if v.IsAttention > 0 {
			resp.IsAttention = 1
		}
		list = append(list, resp)
	}
	r := response.BasePageList{
		Page:       paramsJSON.Page,
		Size:       paramsJSON.Size,
		Total:      total,
		TotalPages: utils.FuncTotalPages(total, paramsJSON.Size),
		List:       list,
	}

	response.ResponseOk(c, "其他人朋友圈列表获取成功", r)
}

//commentHandler 评论处理
func commentHandler(comment, child []dbmodels.AppTweetCommentJoin, childMap *sync.Map) []response.TweetCommentRep {
	data := []response.TweetCommentRep{}
	//一级评论
	for _, v := range comment {
		if v.CommentParentID == 0 {
			t := response.TweetCommentRep{
				CommentID:         v.CommentID,
				CommentUserID:     v.CommentUserID,
				CommentToUserID:   v.CommentToUserID,
				ToUserNickname:    v.ToUserNickname,
				CommentParentID:   v.CommentParentID,
				CommentToParentID: v.CommentToParentID,
				CommentContent:    v.CommentContent,
				CommentLikeCount:  v.CommentLikeCount,
				Created:           v.Created,
				UserNickname:      v.UserNickname,
				UserIconurl:       v.UserIconurl,
				Child:             []response.TweetCommentRep{},
			}
			if v.UserIsLike == 1 {
				t.IsLike = 1
			}
			if num, ok := childMap.Load(v.CommentID); ok {
				t.CommentNumber = num.(int64)
			}
			data = append(data, t)
		} else {
			child = append(child, v)
		}
	}

	//二级评论
	for k, v := range data {
		comments := []response.TweetCommentRep{}
		for _, val := range child {
			if v.CommentID == val.CommentParentID {
				t := response.TweetCommentRep{
					CommentID:         val.CommentID,
					CommentUserID:     val.CommentUserID,
					CommentToUserID:   val.CommentToUserID,
					ToUserNickname:    val.ToUserNickname,
					CommentParentID:   val.CommentParentID,
					CommentToParentID: val.CommentToParentID,
					CommentContent:    val.CommentContent,
					CommentLikeCount:  val.CommentLikeCount,
					Created:           val.Created,
					UserNickname:      val.UserNickname,
					UserIconurl:       val.UserIconurl,
					Child:             []response.TweetCommentRep{},
				}
				if val.UserIsLike == 1 {
					t.IsLike = 1
				}
				comments = append(comments, t)
			}
		}
		data[k].Child = comments
	}
	return data
}

//删除朋友圈
func TweetDelete(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.TweetDeleteReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	msg, err := services.TweetDelete(userId, paramsJSON.TweetId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}
	response.ResponseOk(c, "删除成功", nil)
}
func TweetListTest(gctx *gin.Context) {
	services.TweetPopularCount()
	response.ResponseOk(gctx, "朋友圈列表获取成功", nil)
}
