package controller

import (
	"gamers/controller/response"
	"gamers/models/dbmodels"
	"gamers/utils"
	"strconv"

	"github.com/gin-gonic/gin"
)

func IdTest(c *gin.Context) {
	//msg := redismodels.AssistantMsg{
	//	Type:       2,
	//	ActionType: 1,
	//	Action:     "102",
	//	Text:       "李老栓hkl0",
	//	Title:      "hahhahah",
	//	Image:      "https://testgogo-1304039281.cos.ap-shanghai.myqcloud.com/sys/msg-interact.png",
	//}
	//err := msg.SendAssistantMsg("sys_assistant", "1000080930")
	//tencentIm.AccountImport(1, "系统消息", "https://testcdn1.chatgogo.cn/sys/BG_A_01.jpg")
	//fmt.Println(utf8.RuneCountInString(msg.Text))
	//data := redismodels.AppMsg{
	//	CreateT: time.Now().Unix(),
	//	OrderMsg: &redismodels.SkillOrderMsg{},
	//	Assistant: &redismodels.Assistant{Type: 1},
	//	InteractiveMsg: &redismodels.InteractiveMsg{Type: 1},
	//	C2CMsg: &redismodels.C2CMsg{Type: 1},
	//	LiveMsg: &redismodels.LiveMsg{Type: 1},
	//}
	//tencentIm.PortraitManagerSet("sys_interactive", "互动消息", "https://testcdn1.chatgogo.cn/gogo/upload/sys/msg-interact.png")
	//tencentIm.PortraitManagerSet("sys_order", "订单消息", "https://testcdn1.chatgogo.cn/gogo/upload/sys/msg-order.png")
	//tencentIm.PortraitManagerSet("sys_assistant", "GOGO小助手", "https://testcdn1.chatgogo.cn/gogo/upload/sys/msg-gogohelp.png")

	//tm := time.Unix(int64(1606492799), 0)
	//tmStr := fmt.Sprintf("%d年%d月%d日 %d:%d:%d", tm.Year(), tm.Month(), tm.Day(), tm.Hour(), tm.Minute(), tm.Second())
	//data,_ := new(dbmodels.AppMsgModel).GetMsgByKey("sparring_apply")
	//id := c.Query("id")
	//icon := redismodels.IconStyle{IconId: 14, BgUrl: "https://testcdn1.chatgogo.cn/prop/1608713425000.svga"}
	//chat := redismodels.ChatStyle{ChatId: 16, BgUrl: "http://testcdn1.chatgogo.cn/prop/%E6%B0%94%E6%B3%A1.png"}
	//comein := redismodels.ComeInStyle{ComeInId: 15, BgUrl: "http://testcdn1.chatgogo.cn/prop/%E6%96%87%E5%AD%97%E6%A1%86.svga", PetUrl: "http://testcdn1.chatgogo.cn/prop/%E8%A3%85%E9%A5%B0.svga"}
	//tx := utils.redisClient.TxPipeline()
	////
	//tx.Set(utils.REDIS_USER_CHAT_INFO+id, chat, 0)
	//tx.Set(utils.REDIS_USER_ICON_INFO+id, icon, 0)
	//tx.Set(utils.REDIS_USER_COME_IN_INFO+id, comein, 0)
	//_, err := tx.Exec()
	//uid, _ := strconv.Atoi(id)
	//data, err := new(redismodels.MsgUserObj).GetMsgUserInfo(int64(uid), map[string]bool{"icon": true, "chat": true})
	//if err != nil {
	//	fmt.Println(err.Error())
	//}
	//var cmdObjs []*redismodels.MsgUserObj
	//cmdObjs = append(cmdObjs, &redismodels.MsgUserObj{UserId: 1, NickName: "111"})
	//var pobjs []*redismodels.MsgPropObj
	//pobjs = append(pobjs, &redismodels.MsgPropObj{LoveValue: 0, UserInfo: redismodels.MsgUserObj{NickName: "2"}, PropInfo: redismodels.PropInfo{PropUrl: "1111"}})
	//l := redismodels.WheatObj{UserId: 1}
	//msg := redismodels.LiveMsg{
	//	FromAccount: &redismodels.MsgUserObj{NickName: "11"},
	//	Type:        redismodels.MSG_TYPE_COME_IN,
	//	ContentType: redismodels.CONTENT_TYPE_CMD,
	//	Content:     redismodels.CMD_TYPE_COME_IN,
	//	Wheat:       &redismodels.Wheat{WheatLen: 1, WheatObj: []redismodels.WheatObj{l}},
	//	CmdObjs:     cmdObjs,
	//	GiftInfo:    pobjs,
	//	LiveInfo:    &redismodels.LiveInfo{RoomId: 1},
	//	MsgSource:   redismodels.MSG_SOURCE_SERVICE,
	//	MsgStyle: &redismodels.MsgStyle{
	//		PrimaryColor: redismodels.MSG_STYLE_PRIMARYCOLOR_WHITE,
	//		SecondColor:  redismodels.MSG_STYLE_SECOND_YELLOW,
	//	},
	//}
	//err = msg.SendLiveMsg("119")
	//err = tencentIm.AddUserTag("1000081103", "1000080930")
	//if err != nil {
	//	fmt.Println(err.Error())
	//}
	//live := dbmodels.AppLiveRoom{RoomId: 1}
	//user := redismodels.UserInfo{UserNickname: "huhuhuhu", UserID: 1000081103}
	//liveMsg := services.InitLiveMsg()
	//liveMsg.AssistantLiveStart(&live, &user)
	//if err != nil {
	//	utils.LogErrorF("发送欢迎语失败：", err.Error())
	//}
	//go func() {
	//	for i := 0; i < 10000; i++ {
	//		for j := 0; j < 100; j++ {
	//			task := delay.SystemTaskLog{
	//				LogId:              int64(1000000 + i*10 + j),
	//				LogTaskExecuteTime: time.Now().Unix() + 60*60*4 + int64(i),
	//				LogTaskTimeoutTime: 10,
	//				LogTaskId:          utils.FuncGenerateDataId(),
	//				LogTaskInfo:        "111111111",
	//				LogTaskTopic:       "delayTest",
	//			}
	//			go task.Push()
	//		}
	//		time.Sleep(30 * time.Millisecond)
	//	}
	//}()

	phone := c.Query("phone")
	//id, _ := strconv.Atoi(phone)
	//ids, err := new(dbmodels.AppLiveRoom).GetRoomIdsByAttrId(int64(id))
	//if err != nil {
	//	utils.LogErrorF("获取同标签房间[%d]失败, %s", id, err.Error())
	//}
	//pobjs = append(pobjs, &redismodels.MsgPropObj{LoveValue: 0, UserInfo: redismodels.MsgUserObj{NickName: "2"}, PropInfo: redismodels.PropInfo{PropUrl: "1111"}})
	//headline := redismodels.HeadlineMsg{
	//	Type:       redismodels.HEADLINE_MSG_TYPE_GIFT,
	//	Action:     "1111",
	//	ActionType: redismodels.MSG_ACTION_TYPE_LIVR_ROOM,
	//	Repeat:     1,
	//	GiftInfo:   pobjs,
	//	Content:    "11000",
	//	ActionStyle: redismodels.ActionStyle{Color: "1"},
	//	Priority: 1,
	//	BgUrl: "asdsasa",
	//	FromAccount: &redismodels.MsgUserObj{NickName: "11"},
	//}
	gene, _ := strconv.ParseInt(phone[len(phone)-3:], 0, 64)
	userBaseId := dbmodels.IDBuilderGetId(utils.REDIS_IDBUILDER_USER_ID)
	if userBaseId <= 0 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", "")
	}
	response.ResponseOk(c, "ok", userBaseId*100+(gene%32))

}
