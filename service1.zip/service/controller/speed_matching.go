package controller

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services/speedmatching"
	"gamers/models/dbmodels"
	"gamers/utils"

	"github.com/gin-gonic/gin"
)

// 极速匹配--匹配参数
func SpeedMatchingParams(c *gin.Context) {
	userId := utils.FuncUserId(c)
	params, err := speedmatching.New().Params(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取匹配参数成功", params)
	return
}

// 极速匹配--大神素材
func SpeedMatchingSparringMaterial(c *gin.Context) {
	material, err := speedmatching.New().SparringMaterial()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取大神素材成功", material)
	return
}

// 极速匹配--用户下单
func SpeedMatchingPlaceOrder(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var paramsJSON request.SMPlaceOrderReq
	if err := c.ShouldBindJSON(&paramsJSON); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	msg, r, err := speedmatching.New().PlaceOrder(&paramsJSON, userId)
	if err != nil {
		if err == speedmatching.UserBalanceErr {
			response.ResponseError(c, response.RESPONSE_BALANCE_ERROR, msg, "", err.Error())
		} else {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		}
		return
	}
	response.ResponseOk(c, "用户下单成功", r)
	return
}

// 极速匹配--状态查询
func SpeedMatchingQueryStatus(c *gin.Context) {
	userId := utils.FuncUserId(c)
	r, err := speedmatching.New().QueryStatus(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "状态查询成功", r)
	return
}

// 极速匹配--完成处理
func SpeedMatchingSuccess(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var paramsJSON request.SMExceptionSuccessReq
	if err := c.ShouldBindJSON(&paramsJSON); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	err := speedmatching.New().Success(paramsJSON.MatchingId, userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "异常处理失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "异常状态处理成功", nil)
	return
}

// 极速匹配--抢单中心
func SpeedMatchingOrderGrabbingCenter(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var paramsJSON request.SMOrderGrabbingCenterReq
	if err := c.ShouldBind(&paramsJSON); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	msg, r, err := speedmatching.New().OrderGrabbingCenter(paramsJSON.Page, paramsJSON.Size, userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}
	response.ResponseOk(c, "获取抢单中心成功", r)
	return
}

// 极速匹配--退款
func SpeedMatchingRefund(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var paramsJSON request.SMRefundReq
	if err := c.ShouldBindJSON(&paramsJSON); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	msg, status, info, err := speedmatching.New().Refund(paramsJSON.MatchingId, dbmodels.SPEED_MATCHING_STATUS_CANCEL, userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}
	response.ResponseOk(c, msg, gin.H{"status": status, "sparring_info": info})
	return
}

// 极速匹配--抢单
func SpeedMatchingGrabbingOrders(c *gin.Context) {
	userId := utils.FuncUserId(c)
	var paramsJSON request.SMGrabbingOrdersReq
	if err := c.ShouldBindJSON(&paramsJSON); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	msg, r, err := speedmatching.New().GrabbingOrders(paramsJSON.MatchingId, userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}
	response.ResponseOk(c, msg, r)
	return
}

// 重新匹配
func SpeedMatchingRematch(c *gin.Context) {
	userId := utils.FuncUserId(c)
	msg, r, err := speedmatching.New().Rematch(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}
	response.ResponseOk(c, "重新匹配成功", r)
	return
}
