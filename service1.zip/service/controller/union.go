package controller

import (
	"github.com/gin-gonic/gin"

	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/utils"
)

// 查找公会
func UnionSearch(c *gin.Context) {
	userId := utils.FuncUserId(c)

	var req request.UnionSearch
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	var data, err = services.UnionSearch(userId, &req)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查找公会失败", "", err.Error())
		return
	}

	response.ResponseOk(c, "查找公会成功", data)
}

// 申请加入公会
func UnionApplyForJoin(c *gin.Context) {
	userId := utils.FuncUserId(c)

	var req request.UnionApplyForJoin
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	var msg, err = services.UnionApplyForJoin(userId, &req)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, msg, "", err.Error())
		return
	}

	response.ResponseOk(c, "申请加入公会成功", nil)
}

// 获取自己所在公会房间
func UnionMineUnionRooms(c *gin.Context) {
	userId := utils.FuncUserId(c)

	var req request.UnionMineUnionRooms
	if err := c.ShouldBind(&req); err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	var data, err = services.UnionMineUnionRooms(userId, &req)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取自己所在公会房间失败", "", err.Error())
		return
	}

	response.ResponseOk(c, "获取自己所在公会房间成功", data)
}
