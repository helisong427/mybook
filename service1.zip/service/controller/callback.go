package controller

import (
	"encoding/json"
	"fmt"
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/models/dbmodels"
	"gamers/utils"
	"gamers/utils/pay"
	"io/ioutil"
	"net/http"
	"net/url"
	"strconv"
	"time"

	ua "github.com/mileusna/useragent"

	"github.com/gin-gonic/gin"
	"github.com/iGoogle-ink/gopay"
	"github.com/iGoogle-ink/gopay/alipay"
	"github.com/iGoogle-ink/gopay/wechat"
	"github.com/leyle/ginbase/returnfun"
)

func ImCallBack(gctx *gin.Context) {
	appid := gctx.Query("SdkAppid")
	if appid != strconv.Itoa(utils.Config.Tencent.IMAppId) {
		returnfun.ReturnErrJson(gctx, "sdkAppid有误")
		return
	}
	// 获取commond
	command := gctx.Query("CallbackCommand")
	if command == "" {
		returnfun.ReturnErrJson(gctx, "command有误")
		return
	}

	// 拿消息源
	data, err := ioutil.ReadAll(gctx.Request.Body)
	if err != nil {
		errstr := fmt.Sprintf("读取数据失败 %s", err.Error())
		utils.Logger.Error(errstr)
		returnfun.ReturnErrJson(gctx, err.Error())
		return
	}
	err = utils.KafkaSendMsg(command, utils.FuncGenerateDataId(), data)
	if err != nil {
		utils.Logger.Error(err.Error())
	}
	resp := response.CallBackResponse{ErrorCode: 0}
	resp.ActionStatus = "Ok"
	returnfun.ReturnOKJson(gctx, resp)
	return
}

// 微信支付回调
func WechatPayCallback(c *gin.Context) {
	notifyReq, err := wechat.ParseNotifyToBodyMap(c.Request)
	if err != nil {
		utils.LogErrorF("微信支付回调，解析参数失败:[%s]", err.Error())
		return
	}
	utils.LogInfoF("微信支付回调,%v", notifyReq)

	channel, err := new(dbmodels.AppTransactionChannel).QueryKey(dbmodels.TRANSACTION_CHANNEL_KEY_WECHATPAY)
	if err != nil {
		utils.LogErrorF("微信支付渠道错误!:[%s]", channel)
		return
	}
	channelId, err := strconv.Atoi(channel["id"])
	if err != nil {
		utils.LogErrorF("微信支付渠道错误")
		return
	}
	wechatPayParam := dbmodels.ChannelWechatPayParam{}
	err = json.Unmarshal([]byte(channel["param"]), &wechatPayParam)
	if err != nil {
		utils.LogErrorF("微信支付渠道错误:[%s]", channel["param"])
		return
	}

	// 验签操作
	ok, err := wechat.VerifySign(wechatPayParam.ApiKey, wechat.SignType_MD5, notifyReq)
	if err != nil {
		utils.LogErrorF("微信支付回调，验签错误:[%v],[%s]", notifyReq, err.Error())
		return
	}
	if !ok {
		utils.LogErrorF("微信支付回调，验签失败:[%v]", notifyReq)
		return
	}
	// 支付类型
	tradeType := notifyReq.Get("trade_type")
	if tradeType == "JSAPI" {
		channel, err = new(dbmodels.AppTransactionChannel).QueryKey(dbmodels.TRANSACTION_CHANNEL_KEY_WECHATJSAPIPAY)
		if err != nil {
			utils.LogErrorF("微信支付渠道错误!:[%s]", channel)
			return
		}
		channelId, err = strconv.Atoi(channel["id"])
		if err != nil {
			utils.LogErrorF("微信支付渠道错误!:[%s]", channel["id"])
			return
		}
	}

	// 投递任务
	payCallback := pay.PayCallback{
		PayType:     dbmodels.DB_ACCOUNT_TYPE_WEHCHAT,
		OutTradeNo:  notifyReq.Get("out_trade_no"),
		TotalAmount: notifyReq.Get("total_fee"),
		TradeStatus: notifyReq.Get("result_code"),
		TradeType:   tradeType,
		ThirdNo:     notifyReq.Get("transaction_id"),
		ChannelId:   channelId,
	}
	data, _ := json.Marshal(payCallback)
	err = utils.KafkaSendMsg("PayCallback", utils.FuncGenerateDataId(), data)
	if err != nil {
		utils.LogErrorF("微信支付回调,投递微信支付mq，失败:[%s]", err.Error())
	} else {
		utils.LogInfoF("微信支付回调,投递微信支付mq,成功:[%s]", data)
	}

	// 响应微信
	r := new(wechat.NotifyResponse)
	r.ReturnCode = gopay.SUCCESS
	r.ReturnMsg = gopay.OK
	c.String(http.StatusOK, "%s", r.ToXmlString())
}

// 微信jsapi支付回调
func WechatPayCallbackJsapi(c *gin.Context) {
	notifyReq, err := wechat.ParseNotifyToBodyMap(c.Request)
	if err != nil {
		utils.LogErrorF("微信jsapi支付回调，解析参数失败:[%s]", err.Error())
		return
	}
	utils.LogInfoF("微信jsapi支付回调,%v", notifyReq)

	channel, err := new(dbmodels.AppTransactionChannel).QueryKey(dbmodels.TRANSACTION_CHANNEL_KEY_WECHATJSAPIPAY)
	if err != nil {
		utils.LogErrorF("微信支付渠道错误!:[%s]", channel)
		return
	}
	channelId, err := strconv.Atoi(channel["id"])
	if err != nil {
		utils.LogErrorF("微信支付渠道错误")
		return
	}
	wechatJSAPIPayParam := dbmodels.ChannelWechatJSAPIPayParam{}
	err = json.Unmarshal([]byte(channel["param"]), &wechatJSAPIPayParam)
	if err != nil {
		utils.LogErrorF("微信支付渠道错误:[%s]", channel["param"])
		return
	}

	// 验签操作
	ok, err := wechat.VerifySign(wechatJSAPIPayParam.ApiKey, wechat.SignType_MD5, notifyReq)
	if err != nil {
		utils.LogErrorF("微信jsapi支付回调，验签错误:[%v],[%s]", notifyReq, err.Error())
		return
	}
	if !ok {
		utils.LogErrorF("微信jsapi支付回调，验签失败:[%v]", notifyReq)
		return
	}

	// 投递任务
	payCallback := pay.PayCallback{
		PayType:     dbmodels.DB_ACCOUNT_TYPE_WEHCHAT,
		OutTradeNo:  notifyReq.Get("out_trade_no"),
		TotalAmount: notifyReq.Get("total_fee"),
		TradeStatus: notifyReq.Get("result_code"),
		ThirdNo:     notifyReq.Get("transaction_id"),
		ChannelId:   channelId,
	}
	data, _ := json.Marshal(payCallback)
	err = utils.KafkaSendMsg("PayCallback", utils.FuncGenerateDataId(), data)
	if err != nil {
		utils.LogErrorF("微信jsapi支付回调,投递微信支付mq，失败:[%s]", err.Error())
	}

	// 响应微信
	r := new(wechat.NotifyResponse)
	r.ReturnCode = gopay.SUCCESS
	r.ReturnMsg = gopay.OK
	c.String(http.StatusOK, "%s", r.ToXmlString())
}

// 支付宝支付回调
func AlipayCallback(c *gin.Context) {
	notifyReq, err := alipay.ParseNotifyToBodyMap(c.Request)
	if err != nil {
		utils.LogErrorF("支付宝支付回调，解析参数失败:[%s]", err.Error())
		return
	}
	utils.LogInfoF("收到支付宝支付回调,%v", notifyReq)

	channel, err := new(dbmodels.AppTransactionChannel).QueryKey(dbmodels.TRANSACTION_CHANNEL_KEY_ALIPAY)
	if err != nil {
		utils.LogErrorF("支付宝支付渠道错误!:[%s]", channel)
		return
	}
	channelId, err := strconv.Atoi(channel["id"])
	if err != nil {
		utils.LogErrorF("支付宝支付渠道错误")
		return
	}
	aliPayParam := dbmodels.ChannelAliPayParam{}
	err = json.Unmarshal([]byte(channel["param"]), &aliPayParam)
	if err != nil {
		utils.LogErrorF("支付宝支付渠道错误:[%s]", channel["param"])
		return
	}

	ok, err := alipay.VerifySign(aliPayParam.PublicKey, notifyReq)
	if err != nil {
		utils.LogErrorF("支付宝支付回调，验签错误:[%v],[%s]", notifyReq, err.Error())
		return
	}
	if !ok {
		utils.LogErrorF("支付宝支付回调，失败:[%v]", notifyReq)
		return
	}

	// 投递任务
	payCallback := pay.PayCallback{
		PayType:     dbmodels.DB_ACCOUNT_TYPE_ALIPAY,
		OutTradeNo:  notifyReq.Get("out_trade_no"),
		TotalAmount: notifyReq.Get("total_amount"),
		TradeStatus: notifyReq.Get("trade_status"),
		ThirdNo:     notifyReq.Get("trade_no"),
		ChannelId:   channelId,
	}
	data, _ := json.Marshal(payCallback)
	err = utils.KafkaSendMsg("PayCallback", utils.FuncGenerateDataId(), data)
	if err != nil {
		utils.LogErrorF("投递支付宝支付mq，失败:[%s]", err.Error())
	} else {
		utils.LogInfoF("投递支付宝支付mq,成功:[%s]", data)
	}
	// 响应支付宝
	c.String(http.StatusOK, "%s", "success")
}

// 法大大回调
func FddCallback(c *gin.Context) {
	var paramsJSON request.FddCallbackReq
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	err = services.FddCallback(paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	response.ResponseOk(c, "法大大回调成功", nil)
}

// B站点击回调,微思敦
func BiliBiliWSDCallback(c *gin.Context) {
	var form request.BiliBiliAdCallbackReq
	err := c.ShouldBind(&form)
	if err != nil {
		response.ResponseErrorWithCode(c, http.StatusBadRequest, response.RESPONSE_PARAM_ERROR, "参数错误", err.Error())
		return
	}
	// 获取渠道id
	channel, err := new(dbmodels.AppUserChannel).GetChannelByKey(dbmodels.CHANNEL_KEY_WEISIDUN)
	if err != nil {
		utils.LogErrorF("查询存储微思敦渠道上报信息失败,err:%s")
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "数据处理失败", "", "")
		return
	}
	channelId := strconv.Itoa(int(channel.ChannelId))
	if form.Imei != "" && form.Imei != "__IMEI__" {
		err = services.SaveChannelToRedis(channelId+":"+"IMEI"+":"+form.Imei, form)
		if err != nil {
			utils.LogErrorF("存储微思敦渠道上报信息失败,err:%s")
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "数据处理失败", "", "")
		}
		response.ResponseOk(c, "微思敦回调处理成功", nil)
		return
	}
	if form.OAID != "" && form.OAID != "__OAID__" && form.OAID != "00000000-0000-0000-0000-000000000000" {
		err = services.SaveChannelToRedis(channelId+":"+"OAID"+":"+utils.FuncMD5(form.OAID), form)
		if err != nil {
			utils.LogErrorF("存储微思敦渠道上报信息失败,err:%s")
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "数据处理失败", "", "")
		}
		response.ResponseOk(c, "微思敦回调处理成功", nil)
		return
	}
	if form.IDFA != "" && form.IDFA != "__IDFA__" {
		err = services.SaveChannelToRedis(channelId+":"+"IDFA"+":"+form.IDFA, form)
		if err != nil {
			utils.LogErrorF("存储微思敦渠道上报信息失败,err:%s")
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "数据处理失败", "", "")
		}
		response.ResponseOk(c, "微思敦回调处理成功", nil)
		return
	}
	if form.UA != "" && form.Ip != "" {
		userAgent := ua.Parse(form.UA)
		key := userAgent.OS + userAgent.Version + userAgent.Device + form.Ip
		err = services.SaveChannelToRedis(channelId+":"+"UaIp"+":"+key, form)
		if err != nil {
			utils.LogErrorF("存储微思敦渠道上报信息失败,err:%s")
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "数据处理失败", "", "")
		}
		response.ResponseOk(c, "微思敦回调处理成功", nil)
		return
	}
	response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "无有效凭证，不处理微思敦此次回调", "", "")
	return
}

// 双笙
func BiliBiliSSCallback(c *gin.Context) {
	var form request.BiliBiliAdCallbackReq
	err := c.ShouldBind(&form)
	if err != nil {
		response.ResponseErrorWithCode(c, http.StatusBadRequest, response.RESPONSE_PARAM_ERROR, "参数错误", err.Error())
		return
	}
	// 获取渠道id
	channel, err := new(dbmodels.AppUserChannel).GetChannelByKey(dbmodels.CHANNEL_KEY_SHUANGSHENG)
	if err != nil {
		utils.LogErrorF("查询存储双笙渠道上报信息失败,err:%s")
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "数据处理失败", "", "")
		return
	}
	channelId := strconv.Itoa(int(channel.ChannelId))
	if form.Imei != "" && form.Imei != "__IMEI__" {
		err = services.SaveChannelToRedis(channelId+":"+"IMEI"+":"+form.Imei, form)
		if err != nil {
			utils.LogErrorF("存储双笙渠道上报信息失败,err:%s")
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "数据处理失败", "", "")
		}
		response.ResponseOk(c, "双笙回调处理成功", nil)
		return
	}
	if form.OAID != "" && form.OAID != "__OAID__" && form.OAID != "00000000-0000-0000-0000-000000000000" {
		err = services.SaveChannelToRedis(channelId+":"+"OAID"+":"+utils.FuncMD5(form.OAID), form)
		if err != nil {
			utils.LogErrorF("存储双笙渠道上报信息失败,err:%s")
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "数据处理失败", "", "")
		}
		response.ResponseOk(c, "双笙回调处理成功", nil)
		return
	}
	if form.IDFA != "" && form.IDFA != "__IDFA__" {
		err = services.SaveChannelToRedis(channelId+":"+"IDFA"+":"+form.IDFA, form)
		if err != nil {
			utils.LogErrorF("存储双笙渠道上报信息失败,err:%s")
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "数据处理失败", "", "")
		}
		response.ResponseOk(c, "双笙回调处理成功", nil)
		return
	}
	if form.UA != "" && form.Ip != "" {
		userAgent := ua.Parse(form.UA)
		key := userAgent.OS + userAgent.OSVersion + userAgent.Device + form.Ip
		err = services.SaveChannelToRedis(channelId+":"+"UaIp"+":"+key, form)
		if err != nil {
			utils.LogErrorF("存储双笙渠道上报信息失败,err:%s")
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "数据处理失败", "", "")
		}
		response.ResponseOk(c, "双笙回调处理成功", nil)
		return
	}
	response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "无有效凭证，不处理双笙此次回调", "", "")
	return
}

// 推啊
func TuiACallback(c *gin.Context) {
	var form request.TuiACallbackReq
	err := c.ShouldBind(&form)
	if err != nil {
		response.ResponseErrorWithCode(c, http.StatusBadRequest, response.RESPONSE_PARAM_ERROR, "参数错误", err.Error())
		return
	}
	form.ReqTime = time.Now().UnixNano() / 1e6
	// 获取渠道id
	channel, err := new(dbmodels.AppUserChannel).GetChannelByKey(dbmodels.CHANNEL_KEY_TUIA)
	if err != nil {
		utils.LogErrorF("查询存储推啊渠道上报信息失败,err:%s")
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "数据处理失败", "", "")
		return
	}
	channelId := strconv.Itoa(int(channel.ChannelId))
	uaDecode, err := url.Parse(form.UA)
	if err != nil {
		utils.LogErrorF("解析推啊ua失败,err:%s")
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "数据处理失败", "", err.Error())
		return
	}
	userAgent := ua.Parse(uaDecode.Path)
	key := userAgent.OS + userAgent.OSVersion + ":" + form.Ip
	err = services.SaveChannelToRedis(channelId+":"+"UaIp"+":"+key, form)
	if err != nil {
		utils.LogErrorF("存储推啊渠道上报信息失败,err:%s")
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "数据处理失败", "", "")
		return
	}
	response.ResponseOk(c, "推啊回调处理成功", nil)
	return
}

// 华为
func HuaWeiCallback(c *gin.Context) {
	var form request.HuaWeiCallbackReq
	err := c.ShouldBind(&form)
	if err != nil {
		response.ResponseErrorWithCode(c, http.StatusBadRequest, response.RESPONSE_PARAM_ERROR, "参数错误", err.Error())
		return
	}
	// 获取渠道id
	channel, err := new(dbmodels.AppUserChannel).GetChannelByKey(dbmodels.CHANNEL_KEY_HUAWEI)
	if err != nil {
		utils.LogErrorF("查询存储华为渠道上报信息失败,err:%s")
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "数据处理失败", "", "")
		return
	}
	channelId := strconv.Itoa(int(channel.ChannelId))
	key := utils.FuncMD5(form.OAID)
	form.ChannelConfig = channel.ChannelConfig
	err = services.SaveChannelToRedis(channelId+":"+"UaIp"+":"+key, form)
	if err != nil {
		utils.LogErrorF("存储华为渠道上报信息失败,err:%s")
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "数据处理失败", "", "")
		return
	}
	response.ResponseOk(c, "华为回调处理成功", nil)
	return
}
