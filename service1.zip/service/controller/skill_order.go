package controller

import (
	"encoding/json"
	"fmt"
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/mq/rabbitmqProducer"
	"gamers/utils"
	"gamers/utils/moderation"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// SkillOrderSubmit 下单
func SkillOrderSubmit(c *gin.Context) {
	userId := utils.FuncUserId(c)
	form := request.SkillOrderPlaceReq{}
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	clientType, err := strconv.Atoi(c.Request.Header.Get("Client-Type"))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	key := utils.REDIS_USER_WALLET_LOCK + strconv.Itoa(int(userId))
	lock, islock := utils.AcquireLock(key, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
	if !islock {
		utils.LogErrorF("下单加锁失败")
		return
	}
	// 释放锁
	defer utils.ReleaseLock(key, lock)

	str := moderation.TextModeration(form.Remark)
	if len(str) > 0 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "备注包含敏感词", "", "")
		return
	}

	// 查询用户信息
	userInfo, err := new(redismodels.UserInfo).GetUserInfo(userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户信息错误", "", err.Error())
		return
	}

	//查询技能数据
	sparringSkill := dbmodels.AppSparringSkill{}
	sparring, err := sparringSkill.QueryBySkillId(form.SparringId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "下单技能不存在", "", "")
		return
	}
	sellerInfo, err := new(redismodels.UserInfo).GetUserInfo(sparring.SkillUserID)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户信息错误", "", err.Error())
		return
	}
	commission, err := new(dbmodels.AppUserUnionCommission).GetCommissionByUserIdAndType(sparring.SkillUserID, sellerInfo.UserUnionId, dbmodels.COMMISSION_TYPE_SKILL_ORDER, dbmodels.DEFAULT_SKILL_ORDER_COMMISSION_LEVEL)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户抽成信息失败", "", err.Error())
		return
	}
	if sparring.SkillUserID == userId {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "不能对自己下单", "", "")
		return
	}
	if sparring.SkillStatus != dbmodels.SPARRING_SKILL_STATUS_OK {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前大神状态不可接单", "", "")
		return
	}
	// 查询价格
	var priceInfo *dbmodels.AppSparringSkillPrice
	for _, p := range sparring.AppSparringSkillPrice {
		if p.PriceId == form.PriceId {
			priceInfo = &p
			break
		}
	}
	if priceInfo == nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "下单价格有误", "", "")
		return
	}
	if priceInfo.BaseModel.Deleted != 0 {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "大神此价格未启用", "", "")
		return
	}
	//计算价格
	amount := priceInfo.PricePrice * form.Count
	if userInfo.WalletTotalOver < amount {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "账户余额不足", "", "")
		return
	}
	// 主播收入
	income := amount * commission.CommissionUser / 100
	// 公会扣除
	unionFee := amount * commission.CommissionUnion / 100

	//订单号
	oderBaseId := dbmodels.IDBuilderGetId(utils.REDIS_IDBUILDER_ORDER_ID)
	userIdStr := strconv.Itoa(int(userId))
	if len(userIdStr) < 2 {
		userIdStr = "0" + userIdStr
	}
	IdStr := userIdStr[len(userIdStr)-2:]
	parseId, _ := strconv.Atoi(IdStr)
	orderID := oderBaseId*100 + int64(parseId)
	order := dbmodels.AppSkillOrder{
		OrderId:              orderID,
		OrderBuyUserId:       userId,
		OrderSellUserId:      sparring.SkillUserID,
		OrderSparringSkillId: sparring.SkillID,
		OrderSkillId:         sparring.SkillSkillID,
		OrderPrice:           priceInfo.PricePrice,
		OrderWay:             priceInfo.AppSkillPrice.PriceWay,
		OrderTime:            priceInfo.AppSkillPrice.PriceTime * form.Count,
		OrderProtectionTime:  priceInfo.AppSkillPrice.PriceProtectionTime * form.Count,
		OrderCount:           form.Count,
		OrderAmount:          amount,
		OrderFee:             amount - income - unionFee,
		OrderUnionFee:        unionFee,
		OrderIncome:          income,
		OrderStatus:          dbmodels.SKILL_ORDER_STATUS_CONFIRM,
		OrderConfirmTime:     0,
		OrderCancelTime:      0,
		OrderFinishTime:      0,
		OrderPayStatus:       dbmodels.SKILL_ORDER_PAY_STATUS_PAID, //第一版，默认支付成功
		OrderPayTime:         time.Now().Unix(),
		OrderRefundStatus:    dbmodels.SKILL_ORDER_REFUND_STATUS_NO,
		OrderCommentStatus:   dbmodels.SKILL_ORDER_COMMENT_STATUS_NO,
		OrderClient:          clientType,
		OrderCancelClient:    0,
		OrderAppealStatus:    dbmodels.SKILL_ORDER_APPEAL_STATUS_NO, // 申诉状态
		OrderSettleTime:      0,
		OrderRemark:          form.Remark,
		AppSkill:             sparring.AppSkill,
		OrderBuyUserUnionId:  userInfo.UserUnionId,
		OrderSellUserUnionId: sellerInfo.UserUnionId,
	}
	// 数据库扣钱
	confirm := services.NewSkillOrder()
	err = confirm.Confirm.Commit(&order, sparring, userInfo)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "下单失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "下单成功", order.OrderId)
	return
}

// SkillOrderAccept 接单
func SkillOrderAccept(c *gin.Context) {
	userId := utils.FuncUserId(c)
	form := request.SkillOrderAcceptReq{}
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	model := dbmodels.AppSkillOrder{}

	has, orderInfo, err := model.QueryByOrderId(form.OrderId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if has == 0 {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "订单不存在", "", "")
		return
	}

	if orderInfo.OrderSellUserId != int64(userId) {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "非法操作", "", "非本人订单")
		return
	}

	if orderInfo.OrderStatus != dbmodels.SKILL_ORDER_STATUS_CONFIRM {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "该订单状态不能接单", "", "")
		return
	}
	if orderInfo.OrderConfirmStatus != dbmodels.SKILL_ORDER_CONFIRM_STATUS_NO {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "该订单状态不能接单", "", "")
		return
	}
	confirm := services.NewSkillOrder()
	err = confirm.Confirm.Accept(orderInfo)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "接单失败", "", err.Error())
		return
	}

	response.ResponseOk(c, "接单成功", nil)
	return
}

// 大神订单完成
func SkillOrderFinishBySparring(c *gin.Context) {
	userId := utils.FuncUserId(c)
	form := request.SkillOrderAcceptReq{}
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	model := dbmodels.AppSkillOrder{}

	has, orderInfo, err := model.QueryByOrderId(form.OrderId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if has == 0 {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "订单不存在", "", "")
		return
	}

	if orderInfo.OrderSellUserId != int64(userId) {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "非法操作", "", "不属于本人订单")
		return
	}
	if orderInfo.OrderStatus != dbmodels.SKILL_ORDER_STATUS_CONFIRM && orderInfo.OrderStatus != dbmodels.SKILL_ORDER_STATUS_FINISH {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前订单状态不能完成", "", "")
		return
	}

	// 买家已完成不能重复完成
	if orderInfo.OrderStatus != dbmodels.SKILL_ORDER_STATUS_CONFIRM && orderInfo.OrderStatus != dbmodels.SKILL_ORDER_STATUS_FINISH {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前订单状态不可完成，请检查订单状态", "", "")
		return
	}
	if orderInfo.OrderStatus == dbmodels.SKILL_ORDER_STATUS_CONFIRM {
		if orderInfo.OrderConfirmStatus != dbmodels.SKILL_ORDER_CONFIRM_STATUS_ACCEPT {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前订单状态不可完成，请检查订单状态", "", "")
			return
		}
	} else {
		if orderInfo.OrderFinishStatus != dbmodels.SKILL_ORDER_FINISH_STATUS_USER {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前订单状态不可完成，请检查订单状态", "", "")
			return
		}
	}
	// 校验保护时间
	duration := time.Now().Unix() - orderInfo.BaseModel.Created
	if orderInfo.OrderProtectionTime > duration {
		tips := fmt.Sprintf("%d秒后才可确定完成", orderInfo.OrderProtectionTime-duration)
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, tips, "", "")
		return
	}
	confirm := services.NewSkillOrder()
	err = confirm.Confirm.Finish(orderInfo)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "完成订单失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "ok", nil)
	return
}

// 用户订单完成
func SkillOrderFinishByUser(c *gin.Context) {
	userId := utils.FuncUserId(c)
	form := request.SkillOrderAcceptReq{}
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	model := dbmodels.AppSkillOrder{}

	has, orderInfo, err := model.QueryByOrderId(form.OrderId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if has == 0 {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "订单不存在", "", "")
		return
	}

	if orderInfo.OrderBuyUserId != int64(userId) {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "非法操作", "", "不属于本人订单")
		return
	}

	if orderInfo.OrderPayStatus != dbmodels.SKILL_ORDER_PAY_STATUS_PAID {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "未付款订单不能完成", "", "")
		return
	}

	//买家已完成不能重复完成
	if orderInfo.OrderStatus != dbmodels.SKILL_ORDER_STATUS_CONFIRM {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前订单状态不可完成，请检查订单状态", "", "")
		return
	}
	// 校验接单状态
	if orderInfo.OrderConfirmStatus != dbmodels.SKILL_ORDER_CONFIRM_STATUS_ACCEPT && orderInfo.OrderConfirmStatus != dbmodels.SKILL_ORDER_CONFIRM_STATUS_FINISH {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前订单状态不可完成，请检查订单状态", "", "")
		return
	}
	// 校验保护时间
	duration := time.Now().Unix() - orderInfo.BaseModel.Created
	if orderInfo.OrderProtectionTime > duration {
		tips := fmt.Sprintf("%d秒后才可确定完成", orderInfo.OrderProtectionTime-duration)
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, tips, "", "")
		return
	}
	confirm := services.NewSkillOrder()
	err = confirm.Finish.FinishByUser(orderInfo)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "完成订单失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "订单完成", nil)
	return

}

// SkillOrderCancel 拒绝接单
func SkillOrderSparringRefuse(c *gin.Context) {
	userId := utils.FuncUserId(c)
	form := request.SkillOrderAcceptReq{}
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	model := dbmodels.AppSkillOrder{}

	has, orderInfo, err := model.QueryByOrderId(form.OrderId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if has == 0 {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "订单不存在", "", "")
		return
	}
	key := utils.REDIS_USER_WALLET_LOCK + strconv.Itoa(int(orderInfo.OrderBuyUserId))
	lock, islock := utils.AcquireLock(key, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
	if !islock {
		utils.LogErrorF("拒绝接单加锁失败")
		return
	}
	// 释放锁
	defer utils.ReleaseLock(key, lock)
	// 查询用户信息
	userInfo, err := new(redismodels.UserInfo).GetUserInfo(int64(orderInfo.OrderBuyUserId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户信息错误", "", err.Error())
		return
	}
	if int64(userId) != orderInfo.OrderSellUserId {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "非法操作", "", "")
		return
	}
	if orderInfo.OrderStatus != dbmodels.SKILL_ORDER_STATUS_CONFIRM {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前订单状态不能取消", "", "")
		return
	}
	if orderInfo.OrderConfirmStatus != dbmodels.SKILL_ORDER_CONFIRM_STATUS_NO {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前订单状态不能取消", "", "")
		return
	}
	if orderInfo.OrderPayStatus != dbmodels.SKILL_ORDER_PAY_STATUS_PAID {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "未付款订单不能退款", "", "")
		return
	}
	confirm := services.NewSkillOrder()
	err = confirm.Confirm.Refuse(orderInfo, userInfo)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "拒绝失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "ok", nil)
}

// SkillOrderCancel 用户取消
func SkillOrderUserCancel(c *gin.Context) {
	userId := utils.FuncUserId(c)
	form := request.SkillOrderAcceptReq{}
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	clientType, err := strconv.Atoi(c.Request.Header.Get("Client-Type"))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	key := utils.REDIS_USER_WALLET_LOCK + strconv.Itoa(int(userId))
	lock, islock := utils.AcquireLock(key, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
	if !islock {
		utils.LogErrorF("申请退款失败")
		return
	}
	// 释放锁
	defer utils.ReleaseLock(key, lock)
	// 查询用户信息
	//userInfo, err := new(redismodels.UserInfo).GetUserInfo(userId)
	//if err != nil {
	//	response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户信息错误", "", err.Error())
	//	return
	//}
	model := dbmodels.AppSkillOrder{}
	has, orderInfo, err := model.QueryByOrderId(form.OrderId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if has == 0 {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "订单不存在", "", "")
		return
	}
	if orderInfo.OrderPayStatus != dbmodels.SKILL_ORDER_PAY_STATUS_PAID {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "未付款订单不能取消", "", "")
		return
	}
	if orderInfo.OrderBuyUserId != int64(userId) {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "非法操作", "", "非本人订单")
		return
	}
	//未取消或者已完成的才能进行取消操作
	if orderInfo.OrderStatus != dbmodels.SKILL_ORDER_STATUS_CONFIRM {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前订单状态不能取消", "", "")
		return
	}
	if orderInfo.OrderConfirmStatus != dbmodels.SKILL_ORDER_CONFIRM_STATUS_NO {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前订单状态不能取消", "", "")
		return
	}
	orderInfo.OrderCancelClient = clientType
	cancel := services.NewSkillOrder()
	err = cancel.Cancel.Cancel(orderInfo)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "取消失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "取消成功", nil)
	return
}

// SkillOrderCancel 用户退款
func SkillOrderUserRefund(c *gin.Context) {
	userId := utils.FuncUserId(c)
	form := request.SkillOrderRefundReq{}
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	clientType, err := strconv.Atoi(c.Request.Header.Get("Client-Type"))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	key := utils.REDIS_USER_WALLET_LOCK + strconv.Itoa(int(userId))
	lock, islock := utils.AcquireLock(key, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
	if !islock {
		utils.LogErrorF("申请退款失败")
		return
	}
	// 释放锁
	defer utils.ReleaseLock(key, lock)

	str := moderation.TextModeration(form.Remark)
	if len(str) > 0 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "备注包含敏感词", "", "")
		return
	}

	// 查询用户信息
	model := dbmodels.AppSkillOrder{}

	has, orderInfo, err := model.QueryByOrderId(form.OrderId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if has == 0 {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "订单不存在", "", "")
		return
	}
	if orderInfo.OrderRefundCount >= dbmodels.SKILL_ORDER_REFUND_COUNT_MAX {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "超过最大申请次数", "", "")
		return
	}
	if orderInfo.OrderPayStatus != dbmodels.SKILL_ORDER_PAY_STATUS_PAID {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前订单状态不能申请退款", "", "")
		return
	}
	if userId != int64(orderInfo.OrderBuyUserId) {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "非法请求", "", "")
		return
	}
	//未取消或者已完成的才能进行取消操作
	if orderInfo.OrderStatus != dbmodels.SKILL_ORDER_STATUS_CONFIRM && orderInfo.OrderStatus != dbmodels.SKILL_ORDER_STATUS_REFUND {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前订单状态不能申请退款", "", "")
		return
	}
	// 退款状态
	if orderInfo.OrderStatus == dbmodels.SKILL_ORDER_STATUS_REFUND {
		if orderInfo.OrderRefundStatus != dbmodels.SKILL_ORDER_REFUND_STATUS_SPARRING_REFUSE {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前订单状态不能申请退款", "", "")
			return
		} // 判断完成状态
	} else {
		// 判断确认状态
		if orderInfo.OrderConfirmStatus != dbmodels.SKILL_ORDER_CONFIRM_STATUS_ACCEPT && orderInfo.OrderConfirmStatus != dbmodels.SKILL_ORDER_CONFIRM_STATUS_FINISH {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前订单状态不能申请退款", "", "")
			return
		}
	}
	orderInfo.OrderCancelClient = clientType
	beforeStatus := orderInfo.OrderStatus
	// 判断系统自动完成的时间限制
	if orderInfo.OrderRefundCount == 1 {
		beforeRefund, err := new(dbmodels.AppSkillOrderRefund).GetAppSkillOrderRefundById(orderInfo.OrderRefundId)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取前次订单状态失败", "", err.Error())
			return
		}
		beforeStatus = beforeRefund.RefundOldStatus
	}
	//大神取消
	// 退款信息
	refundInfo := dbmodels.AppSkillOrderRefund{
		RefundClass:     *form.RefundType,
		RefundCount:     orderInfo.OrderAmount,
		RefundReason:    form.RefundReason,
		RefundOrderId:   orderInfo.OrderId,
		RefundRemark:    form.Remark,
		RefundOldStatus: beforeStatus,
	}
	refund := services.NewSkillOrder()
	err = refund.Refund.RefundApply(orderInfo, refundInfo)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "申请退款失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "申请成功", nil)
	return

}

// SkillOrderRefundConfirm 确认退款
func SkillOrderRefundConfirm(c *gin.Context) {
	userId := utils.FuncUserId(c)
	form := request.SkillOrderRefundConfirmReq{}
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	key := utils.REDIS_USER_WALLET_LOCK + strconv.Itoa(int(userId))
	lock, islock := utils.AcquireLock(key, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
	if !islock {
		utils.LogErrorF("退款加锁失败")
		return
	}
	// 释放锁
	defer utils.ReleaseLock(key, lock)

	str := moderation.TextModeration(form.Remark)
	if len(str) > 0 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "备注包含敏感词", "", "")
		return
	}

	model := dbmodels.AppSkillOrder{}

	has, orderInfo, err := model.QueryByOrderId(form.OrderId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if has == 0 {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "订单不存在", "", "")
		return
	}
	// 查询用户信息
	userInfo, err := new(redismodels.UserInfo).GetUserInfo(int64(orderInfo.OrderBuyUserId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取用户信息错误", "", err.Error())
		return
	}
	if orderInfo.OrderPayStatus != dbmodels.SKILL_ORDER_PAY_STATUS_PAID {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "未付款订单不能退款", "", "")
		return
	}
	if orderInfo.OrderStatus != dbmodels.SKILL_ORDER_STATUS_REFUND && orderInfo.OrderStatus != dbmodels.SKILL_ORDER_STATUS_APPEAL {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前状态不能退款", "", "")
		return
	}
	if orderInfo.OrderStatus == dbmodels.SKILL_ORDER_STATUS_REFUND {
		if orderInfo.OrderRefundStatus != dbmodels.SKILL_ORDER_REFUND_STATUS_REFUNDING {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前状态不能退款", "", "")
			return
		}
	} else {
		if orderInfo.OrderAppealStatus != dbmodels.SKILL_APPEAL_STATUS_ING {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "当前状态不能退款", "", "")
			return
		}
	}
	skillOrder := services.NewSkillOrder()
	// 判断拒绝退款
	if *form.Status == dbmodels.SKILL_ORDER_CONFIRM_REFUSE {
		err = skillOrder.Refund.RefundSparringRefuse(orderInfo, form)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "拒绝退款失败", "", err.Error())
			return
		}
		response.ResponseOk(c, "ok", nil)
		return
	}
	// 同意退款
	err = skillOrder.Refund.RefundSparringSure(orderInfo, userInfo)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "退款失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "ok", nil)
	return

}

//大神订单用户申诉
func SkillAppeal(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.SkillAppealReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	if len([]rune(paramsJSON.Remark)) > 100 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "说明最多100个字", "", "")
		return
	}

	str := moderation.TextModeration(paramsJSON.Remark)
	if len(str) > 0 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "说明包含敏感词", "", "")
		return
	}

	if len(paramsJSON.Images) > 6 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "凭证最多6张图片", "", "")
		return
	}

	//查询订单信息
	_, data, err := new(dbmodels.AppSkillOrder).QueryByOrderId(paramsJSON.OrderId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "订单不存在", "", err.Error())
		return
	}
	if data.OrderBuyUserId != int64(userId) {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "非法请求", "", "订单不属于该用户")
		return
	}

	row, appealData, err := new(dbmodels.AppSkillOrderAppeal).QueryByOrderId(paramsJSON.OrderId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	if row == 1 && appealData.AppealAppealStatus == dbmodels.SKILL_APPEAL_STATUS_ING {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "订单处理中,请勿重复提交", "", "")
		return
	}

	if row == 1 && appealData.AppealAppealStatus == dbmodels.SKILL_APPEAL_STATUS_OK {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "已处理订单,无法继续申诉", "", "")
		return
	}

	//订单完成时间+24小时
	finishTime := time.Unix(data.OrderFinishTime, 0).Add(time.Hour * 24).Unix()

	//退款失败次数
	count, err := new(dbmodels.AppSkillOrderRefund).QueryRefundFailCount(paramsJSON.OrderId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	//订单状态
	if (data.OrderStatus == dbmodels.SKILL_ORDER_STATUS_REFUND && data.OrderRefundStatus == dbmodels.SKILL_ORDER_REFUND_STATUS_SPARRING_REFUSE && count >= dbmodels.SKILL_ORDER_REFUND_APPEAL_COUNT) ||
		(data.OrderStatus == dbmodels.SKILL_ORDER_STATUS_FINISH && data.OrderFinishStatus == dbmodels.SKILL_ORDER_FINISH_STATUS_SYSTEM && finishTime >= time.Now().Unix()) {
		appeal := services.NewSkillOrder()
		err = appeal.Appeal.Apply(data, paramsJSON)
		if err != nil {
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "申请失败", "", err.Error())
			return
		}
		response.ResponseOk(c, "申诉成功", nil)
		return
	} else {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "不符合申诉条件", "", "")
		return
	}
}

// 取消退款
func SkillOrderRefundCancel(c *gin.Context) {
	userId := utils.FuncUserId(c)
	form := request.SkillOrderAcceptReq{}
	err := c.ShouldBindJSON(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	model := dbmodels.AppSkillOrder{}

	has, orderInfo, err := model.QueryByOrderId(form.OrderId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if has == 0 {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "订单不存在", "", "")
		return
	}
	if orderInfo.OrderBuyUserId != int64(userId) {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "非法操作", "", "")
		return
	}
	if orderInfo.OrderStatus != dbmodels.SKILL_ORDER_STATUS_REFUND {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "订单状态不允许取消退款", "", "")
		return
	}
	if orderInfo.OrderRefundStatus != dbmodels.SKILL_ORDER_REFUND_STATUS_REFUNDING && orderInfo.OrderRefundStatus != dbmodels.SKILL_ORDER_REFUND_STATUS_SPARRING_REFUSE {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "订单状态不允许取消退款", "", "")
		return
	}
	refundInfo, err := new(dbmodels.AppSkillOrderRefund).GetAppSkillOrderRefundById(orderInfo.OrderRefundId)
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询退款信息失败", "", "")
		return
	}
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "未查询到退款信息", "", "")
		return
	}
	orderInfo.OrderStatus = refundInfo.RefundOldStatus
	orderInfo.OrderRefundStatus = dbmodels.SKILL_ORDER_REFUND_STATUS_CANCEL
	orderInfo.OrderFinishTime = 0
	tx := utils.GEngine.Begin()
	err = orderInfo.Update(tx, form.OrderId)
	if err != nil {
		tx.Rollback()
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	tx.Commit()
	go rabbitmqProducer.ProducerOrder(orderInfo.OrderId, orderInfo.OrderStatus, dbmodels.SKILL_ORDER_CONFIRM_TIME)
	response.ResponseOk(c, "ok", nil)
	return
}

// SkillOrderDetail 订单详情
func SkillOrderDetail(c *gin.Context) {
	paramsJSON := request.SkillOrderDetailReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	model := dbmodels.AppSkillOrder{}
	_, data, err := model.QuerySparringDetail(paramsJSON.OrderId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "订单不存在", "", err.Error())
		return
	}
	r := response.SkillOrderDetailRep{
		OrderId:              data.OrderId,
		OrderBuyUserId:       data.OrderBuyUserId,
		OrderSellUserId:      data.OrderSellUserId,
		OrderSkillId:         data.OrderSkillId,
		OrderSparringSkillId: data.OrderSparringSkillId,
		OrderPrice:           data.OrderPrice,
		OrderWay:             data.OrderWay,
		OrderTime:            data.OrderTime,
		OrderProtectionTime:  data.OrderProtectionTime,
		OrderCount:           data.OrderCount,
		OrderAmount:          data.OrderAmount,
		OrderUnionFee:        data.OrderUnionFee,
		OrderFee:             data.OrderFee,
		OrderIncome:          data.OrderIncome,
		OrderStatus:          data.OrderStatus,
		OrderPayStatus:       data.OrderPayStatus,
		OrderPayTime:         data.OrderPayTime,
		OrderConfirmStatus:   data.OrderConfirmStatus,
		OrderConfirmTime:     data.OrderConfirmTime,
		OrderCancelStatus:    data.OrderCancelStatus,
		OrderCancelTime:      data.OrderCancelTime,
		OrderCancelClient:    data.OrderCancelClient,
		OrderRefundStatus:    data.OrderRefundStatus,
		OrderRefundTime:      data.OrderRefundTime,
		OrderRefundId:        data.OrderRefundId,
		OrderRefundCount:     data.OrderRefundCount,
		OrderAppealStatus:    data.OrderAppealStatus,
		OrderAppealTime:      data.OrderAppealTime,
		OrderFinishStatus:    data.OrderFinishStatus,
		OrderFinishTime:      data.OrderFinishTime,
		OrderCommentStatus:   data.OrderCommentStatus,
		OrderRemark:          data.OrderRemark,
		OrderClient:          data.OrderClient,
		OrderSettleStatus:    data.OrderSettleStatus,
		OrderSettleTime:      data.OrderSettleTime,
		OrderDeleteStatus:    data.OrderDeleteStatus,
		BuyUserNickname:      data.BuySystemUser.UserNickname,
		SellUserNickname:     data.SellSystemUser.UserNickname,
		SkillName:            data.AppSkill.SkillName,
		SkillIconurl:         data.AppSkill.SkillIconurl,
		CreatedTime:          data.BaseModel.Created,
		CountDown:            new(dbmodels.AppSkillOrder).CountDownNew(data),
		ProtectionTime:       new(dbmodels.AppSkillOrder).ProtectionTime(data),
		RefundInfo:           data.AppSkillOrderRefund,
		AppealInfo:           data.AppSkillOrderAppeal,
	}
	response.ResponseOk(c, "获取订单详情成功", r)
}

// 接单记录
func GetSparringOrderRecord(c *gin.Context) {
	userId := utils.FuncUserId(c)
	//获取分页参数
	page, size, skip, err := utils.GetPageAndSize(c)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "分页参数错误", "", err.Error())
		return
	}
	one := dbmodels.AppSkillOrder{}
	result, err, total := one.GetOrdersBySparringId(userId, size, skip)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "未获取订单记录", "", err.Error())
		return
	}
	data := response.BasePageList{
		Page:       page,
		Size:       size,
		Total:      total,
		TotalPages: utils.FuncTotalPages(total, size),
		List:       result,
	}
	response.ResponseOk(c, "ok", data)
	return
}

// 用户订单
func GetUserOrderRecord(c *gin.Context) {
	userId := utils.FuncUserId(c)
	//获取分页参数
	page, size, skip, err := utils.GetPageAndSize(c)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "分页参数错误", "", err.Error())
		return
	}
	one := dbmodels.AppSkillOrder{}
	result, err, total := one.GetOrdersByBuyerId(userId, size, skip)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "未获取订单记录", "", err.Error())
		return
	}
	data := response.BasePageList{
		Page:       page,
		Size:       size,
		Total:      total,
		TotalPages: utils.FuncTotalPages(total, size),
		List:       result,
	}
	response.ResponseOk(c, "ok", data)
	return
}

// 获取退款原因
func SkillRefundReason(c *gin.Context) {
	key, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_SKILL_ORDER_REFUND)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	r := []string{}
	err = json.Unmarshal([]byte(key["value"]), &r)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取退款原因成功", r)
	return
}

// 获取退款原因
func SkillRefundRefuseReason(c *gin.Context) {
	key, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_SKILL_ORDER_REFUSE_REFUND)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}

	r := []string{}
	err = json.Unmarshal([]byte(key["value"]), &r)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取拒绝退款原因成功", r)
	return
}

// 获取退款详情
func SkillRefundInfo(c *gin.Context) {
	form := request.SkillOrderDetailReq{}
	err := c.ShouldBind(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	refundInfo, err := new(dbmodels.AppSkillOrderRefund).GetAppSkillOrderRefundByOrderId(int64(form.OrderId))
	if err != nil && err != gorm.ErrRecordNotFound {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取退款原因失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "ok", refundInfo)
	return
}

//大神提交申诉资料
func SkillSparringAppeal(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.SkillSparringAppealReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	if len([]rune(paramsJSON.Remark)) > 100 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "说明最多100个字", "", "")
		return
	}

	str := moderation.TextModeration(paramsJSON.Remark)
	if len(str) > 0 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "说明包含敏感词", "", "")
		return
	}

	if len(paramsJSON.Images) > 6 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "凭证最多6张图片", "", "")
		return
	}

	//查询订单信息
	_, data, err := new(dbmodels.AppSkillOrder).QueryByOrderId(paramsJSON.OrderId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "订单不存在", "", err.Error())
		return
	}
	if data.OrderSellUserId != int64(userId) {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "非法请求", "", "订单不属于该用户")
		return
	}

	//用户申诉12小时之后，大神不能申诉
	now := time.Now().Unix()
	if (data.OrderAppealTime + int64(dbmodels.SKILL_ORDER_APPEAL_TIME)) < now {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "已超过申诉时间", "", "")
		return
	}

	//申诉中大神才能提交申诉资料
	if data.OrderStatus == dbmodels.SKILL_ORDER_STATUS_APPEAL && data.OrderAppealStatus == dbmodels.SKILL_ORDER_APPEAL_STATUS_ING {
		tx := utils.GEngine.Begin()
		image, _ := json.Marshal(paramsJSON.Images)

		//订单
		orderModel := dbmodels.AppSkillOrder{
			OrderAppealStatus: dbmodels.SKILL_ORDER_APPEAL_STATUS_PENDING, //修改为待处理
		}
		err = orderModel.Update(tx, paramsJSON.OrderId)
		if err != nil {
			tx.Rollback()
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}
		//申诉订单
		appealModel := dbmodels.AppSkillOrderAppeal{
			AppealSparringRemark: paramsJSON.Remark,
			AppealSparringImage:  string(image),
			AppealAppealStatus:   dbmodels.SKILL_APPEAL_STATUS_WAIT,
			AppealSparringTime:   time.Now().Unix(),
		}

		err = appealModel.Update(tx, paramsJSON.OrderId)
		if err != nil {
			tx.Rollback()
			response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
			return
		}

		tx.Commit()
		response.ResponseOk(c, "申诉成功", nil)
		return
	} else {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "不符合申诉条件", "", "")
		return
	}

}
