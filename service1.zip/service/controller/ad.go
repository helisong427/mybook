package controller

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/models/dbmodels"

	"github.com/gin-gonic/gin"
)

//AdList 获取广告列表
func AdList(gctx *gin.Context) {
	var (
		adList []dbmodels.AppAdResutl
		err    error
	)
	paramsJSON := request.AdListReq{}
	err = gctx.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	model := dbmodels.AppAd{}
	if paramsJSON.AdPositionID > 0 {
		adList, err = model.QueryByPositionID(paramsJSON.AdPositionID)
	} else {
		adList, err = model.QueryAll()
	}
	if err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "获取列表失败", "", err.Error())
		return
	}
	list := []response.AdListRep{}
	for _, v := range adList {
		if v.AdShowCount == 0 || v.AdShowCount > paramsJSON.ShowCount {
			resp := response.AdListRep{
				AdId:         v.AdId,
				AdName:       v.AdName,       // AdName 广告名称
				AdPositionID: v.AdPositionId, // AdPositionID 广告位id
				AdContent:    v.AdContent,    // AdContent 广告内容
				AdURL:        v.AdUrl,        // AdURL 广告链接
				AdURLParam:   v.AdURLParam,   // AdURL 广告链接参数
				AdJumpType:   v.AdJumpType,   // 跳转类型 0--网站跳转,1--app内跳转',
				AdType:       v.AdType,       // AdType 广告类型(0图片,1H5)
				AdOrder:      v.AdOrder,      // AdOrder 排序
				AdStartTime:  v.AdStartTime,  // AdStartTime 开始时间
				AdEndTime:    v.AdEndTime,    // AdEndTime 结束时间
				AdStatus:     v.AdStatus,     // AdStatus 广告状态 0--关闭 1--开启
			}
			list = append(list, resp)
		}
	}
	total := len(list)
	r := response.BasePageList{
		Page:       1,            //当前页
		Size:       total,        //每页条数
		Total:      int64(total), //总条数
		TotalPages: 1,            //总页数
		List:       list,         //数据列表
	}
	response.ResponseOk(gctx, "广告列表获取成功", r)
}

// 根据类型 获取 房间数据
func GetAdListByType(gctx *gin.Context) {
	var (
		err   error
		total int64
		list  []*dbmodels.AppLiveRoomAdList
	)

	if list, total, err = new(dbmodels.AppLiveRoom).QueryByLiveStatus(); err != nil {
		response.ResponseError(gctx, response.RESPONSE_BUSINESS_ERROR, "获取列表失败", "", err.Error())
		return
	}

	r := response.BasePageList{
		Page:       1,          //当前页
		Size:       int(total), //每页条数
		Total:      total,      //总条数
		TotalPages: 1,          //总页数
		List:       list,       //数据列表
	}
	response.ResponseOk(gctx, "广告列表获取成功", r)
}
