package request

// 上报前端任务完成条件行为来触发任务
type TaskReportCondition struct {
	ConditionTag   string `json:"condition_tag" binding:"required"`   // 任务条件标签
	ConditionCount uint32 `json:"condition_count" binding:"required"` // 任务条件数量
}

// 领取奖励
type TaskGetReward struct {
	SetID  uint32 `json:"set_id" binding:"required"` // 任务集合ID
	TaskID uint32 `json:"task_id"`                   // 任务ID
}
