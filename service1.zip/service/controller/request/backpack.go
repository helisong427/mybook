package request

// 请求背包数据
type BackpackListReq struct {
	BackpackPropType int `form:"backpack_prop_type" json:"backpack_prop_type" binding:"required"`
}

// 请求锤子数据
type BackpackHammerListReq struct {
	BackpackPropType int64 `form:"backpack_prop_type" json:"backpack_prop_type" binding:"required"`
	BackpackPropId   int64 `form:"backpack_prop_id" json:"backpack_prop_id" binding:"required"`
}
