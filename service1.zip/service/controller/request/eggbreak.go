package request

import "gamers/utils"

// 砸蛋列表
type EggBreakConfigListReq struct {
}

// 砸蛋设置
type EggBreakSettingReq struct {
}

// 砸蛋设置修改
type EggBreakSettingChangeReq struct {
	UserEggbreakMsg int `json:"user_eggbreak_msg" binding:"min=0,max=1"`
}

// 砸蛋
type EggBreakReq struct {
	RoomId        int `json:"room_id"`
	EggbreakId    int `json:"eggbreak_id"`
	EggbreakCount int `json:"eggbreak_count"`
}

// 砸蛋记录
type EggBreakRecordsReq struct {
	EggbreakId int `form:"eggbreak_id" json:"eggbreak_id" binding:"required"`
	utils.PageSearchReq
}

// 砸蛋排行
type EggBreakRankReq struct {
	RankEggbreakId int    `form:"rank_eggbreak_id" json:"rank_eggbreak_id" binding:"required"`
	RankTag        string `form:"rank_tag" json:"rank_tag" binding:"required"` // tag : daily/weekly
	RankPeriod     int    `form:"rank_period" json:"rank_period"`
}
