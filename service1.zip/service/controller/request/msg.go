package request

type GetQuickByTypeReq struct {
	Type *int `form:"type" binding:"required,min=0"` //大神id
}

type GetOrdersAndSkillsReq struct {
	UserId int64 `form:"user_id" binding:"required"`
}
