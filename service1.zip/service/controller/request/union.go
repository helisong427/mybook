package request

// 查找公会
type UnionSearch struct {
	InviteKey string `json:"invite_key"` // 邀请码
}

// 申请加入公会
type UnionApplyForJoin struct {
	UnionID int64 `json:"union_id"` // 公会ID
}

// 获取自己公会的房间
type UnionMineUnionRooms struct {
	BasePageReq
}
