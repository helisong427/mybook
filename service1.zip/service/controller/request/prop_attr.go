package request

type GetPropAttrByTypeReq struct {
	AttrType *int `form:"attr_type" binding:"required,min=0,max=10"`
}
