package request

// 设置用户信息
type SetUserInfoReq struct {
	Nickname  string   `json:"nickname" binding:"required"`            // 昵称
	Gender    int      `json:"gender" binding:"omitempty,min=0,max=2"` // 性别
	Iconurl   *string  `json:"iconurl" binding:"required"`             // 头像
	Birthday  uint     `json:"birthday"`                               // 生日
	CityID    int      `json:"city_id"`                                // 城市id
	Sound     string   `json:"sound"`                                  // 用户声音地址
	SoundTime int      `json:"sound_time"`                             // 用户声音时长
	Slogan    string   `json:"slogan"`                                 // 用户签名
	GameSavor []int    `json:"game_savor"`                             // 游戏兴趣
	LiveSavor []int    `json:"live_savor"`                             // 直播兴趣
	Images    []string `json:"images"`                                 // 背景图
}

// 客户端获取设备手机号
type QueryMobileReq struct {
	Token string `json:"token" binding:"required"` // 闪验token
}

// 用户初始化设置用户信息
type InitSetUserInfoReq struct {
	Gender int `json:"gender" binding:"omitempty,min=0,max=2"` // 性别
}

// 更新密码验证
type UpdatePasswordVerifyReq struct {
	OldPassword string `json:"old_password" binding:"omitempty"`
}

// 设置密码
type SetPasswordReq struct {
	Type         int    `json:"type" binding:"required"` // 类型：1设置密码,2更新密码,3重置密码
	NewPassword  string `json:"new_password" binding:"omitempty,min=16,max=16"`
	NewPassword2 string `json:"new_password2" binding:"omitempty,min=16,max=16"`
}

// 忘记密码
type ForGetPasswordReq struct {
	Timestamp int    `json:"timestamp" binding:"required"`
	Uuid      string `json:"uuid" binding:"required"` // 前端生成的唯一值
	Sign      string `json:"sign" binding:"required"`
}

// 忘记密码验证
type ForGetPasswordCheckReq struct {
	Code int `json:"code" binding:"required"`
}

// 忘记密码
type OldMobileSmsReq struct {
	Timestamp int    `json:"timestamp" binding:"required"`
	Uuid      string `json:"uuid" binding:"required"` // 前端生成的唯一值
	Sign      string `json:"sign" binding:"required"`
}

// 旧手机验证
type OldMobileCheckReq struct {
	Code int `json:"code" binding:"required"`
}

// 新手机号绑定
type NewMobileBindReq struct {
	Mobile string `json:"mobile"`
	Code   int    `json:"code"`
}

// 关注用户
type FollowUserReq struct {
	FollowUserId int `json:"follow_user_id"` // 被关注的用户id
}

// 获取用户关注
type GetUserFollowListReq struct {
	Page     int `form:"page" binding:"required"`
	Size     int `form:"size" binding:"required"`
	Type     int `form:"type" binding:"omitempty,min=1,max=2"`      // 类型：1--关注,2--粉丝
	IsOnline int `form:"is_online" binding:"omitempty,min=0,max=1"` // 在线状态:0--全部,1--在线
}

// 其他用户信息
type OtherUserInfoReq struct {
	UserId    int   `form:"user_id" binding:"required"` // 用户id
	VisitType int64 `form:"visit_type"`                 // 浏览类型, 不能强制required, 因为需要兼容老版本
}

type SparringMessageSetEdit struct {
	UserIsForwardsNews int64 `json:"user_is_forwards_news"` // 是否开启推送消息 0 关闭, 1开启
}

// 用户卡片
type UserCardReq struct {
	RoomId int64 `form:"room_id" binding:"required"` // 房间id
	UserId int64 `form:"user_id" binding:"required"` // 用户id
}

// 更新
type UpdateUserYouthReq struct {
	Action   int    `json:"action" binding:"omitempty,min=0,max=1"` // 青少年模式动作:0--取消,1--开启
	Password string `json:"password" binding:"required"`            // 密码
}

// 举报
type ReportReq struct {
	ReportType    int      `json:"report_type" binding:"omitempty,min=0,max=6"`    // 举报类型(0低俗色情,1涉政治,2广告,3侮辱诋毁,4诈骗,5侵权举报,6其他)
	ReportContent string   `json:"report_content" binding:"required"`              // 举报内容
	ReportImage   []string `json:"report_image"`                                   // 举报图片
	ReportToId    int      `json:"report_to_id" binding:"required"`                // 被举报id(人id,房间id,朋友圈动态id,朋友圈评论id,技能id)
	ReportToType  int      `json:"report_to_type" binding:"omitempty,min=0,max=4"` // 被举报的类型(0人,1房间,2朋友圈动态,3朋友圈评论,4技能)
	ReportRoomId  int      `json:"report_room_id"`                                 // 发生的聊天室
}

// 设置常用游戏顺序
type UserSetGameOrderReq struct {
	SkillId []int `json:"skill_id"` // 游戏id
}

// 查找用户
type UserFindReq struct {
	Account int `form:"account" binding:"required"` // 账号
}

// 更新用户坐标
type UserUpdateCoordinateReq struct {
	Longitude float64 `json:"longitude" binding:"required"` // 经度
	Latitude  float64 `json:"latitude" binding:"required"`  // 纬度
}
