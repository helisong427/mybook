package request

//栏目文章详情
type ArticleListReq struct {
	CategoryId int `form:"categoryid"`
}
type ArticleInfoReq struct {
	ArticleID int64 `form:"articleid"  binding:"required"`
}
