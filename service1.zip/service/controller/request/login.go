package request

//密码登录
type LoginByPasswordReq struct {
	Mobile   string `json:"mobile" binding:"required"`
	Password string `json:"password" binding:"required"`
}

//短信验证码登录
type LoginBySmsCodeReq struct {
	Mobile string `json:"mobile" binding:"required"`
	Code   int    `json:"code" binding:"required"`
}

//获取短信验证码
type GetSmsCodeReq struct {
	Mobile    string `json:"mobile" binding:"required"`
	Timestamp int    `json:"timestamp" binding:"required"`
	Uuid      string `json:"uuid" binding:"required"` //前端生成的唯一值
	Sign      string `json:"sign" binding:"required"`
}

//第三方openid登录
type LoginByOpenidReq struct {
	Openid    string `json:"openid" binding:"required"`
	Nickname  string `json:"nickname"`
	Gender    int    `json:"gender" binding:"omitempty,min=0,max=2"`
	Iconurl   string `json:"iconurl"`
	Opentype  int    `json:"opentype" binding:"omitempty,min=0,max=4"`
	Timestamp int    `json:"timestamp" binding:"required"`
	Uuid      string `json:"uuid" binding:"required"`
	Sign      string `json:"sign" binding:"required"`
}

// 短信绑定手机号
type SmsBindMobileReq struct {
	Openid   string `json:"openid" binding:"required"`
	Opentype int    `json:"opentype" binding:"omitempty,min=0,max=4"`
	Mobile   string `json:"mobile" binding:"required"`
	Code     int    `json:"code" binding:"required"`
}

// 绑定手机号
type BindMobileReq struct {
	Openid   string `json:"openid" binding:"required"`
	Opentype int    `json:"opentype" binding:"omitempty,min=0,max=4"`
	Token    string `json:"token" binding:"required"` // 创蓝token
}

type LoginGetMobile struct {
	Token string `json:"token" binding:"required"`
}
type LoginByMobile struct {
	Token    string `json:"token"   binding:"required"`
	Openid   string `json:"openid"` //第三方openid
	Opentype int    `json:"opentype"`
}
