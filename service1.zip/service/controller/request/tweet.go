package request

//发布朋友圈
type TweetPublishReq struct {
	TweetContent       string             `json:"tweet_content"`                                 //发送内容
	TweetAttachments   []TweetAttachments `json:"tweet_attachments"`                             //附件
	TweetSound         string             `json:"tweet_sound"`                                   //声音
	TweetSoundTime     int64              `json:"tweet_sound_time"`                              //声音时长
	TweetSendRegionId  int                `json:"tweet_send_region_id"`                          //发送城市id
	TweetSendLongitude float32            `json:"tweet_send_longitude"`                          //发送经度
	TweetSendLatitude  float32            `json:"tweet_send_latitude"`                           //发送维度
	TweetSendPosition  string             `json:"tweet_send_position"`                           //位置
	TweetVisible       int                `json:"tweet_visible" binding:"omitempty,min=0,max=2"` //可见度
	Topics             []int              `json:"topics"`                                        //话题
}

//朋友圈附件内容
type TweetAttachments struct {
	Type   string `json:"type"`   //附件类型
	Url    string `json:"url"`    //附件地址
	Width  string `json:"width"`  //附件宽度
	High   string `json:"high"`   //附件高度
	Length int    `json:"length"` //时长(视频/音频)
}

//朋友圈详情
type TweetDetailReq struct {
	Id int `form:"id" binding:"required"`
}

//朋友圈列表
type TweetListReq struct {
	Page  int `form:"page" binding:"required"`
	Size  int `form:"size" binding:"required"`
	TagId int `form:"tag_id" binding:"omitempty,min=0"`
}

//发布朋友圈评论
type SendTweetCommentReq struct {
	Id          int    `json:"id" binding:"required"`                    //朋友圈id
	CommentId   int    `json:"comment_id" binding:"omitempty,min=0"`     //评论id
	Content     string `json:"content"  binding:"required"`              //评论内容
	ToUserId    int    `json:"to_user_id"  binding:"omitempty,min=0"`    //回复评论用户id
	ToCommentId int    `json:"to_comment_id"  binding:"omitempty,min=0"` //回复的直接上级id
}

//获取朋友圈评论
type GetTweetCommentReq struct {
	Id   int `form:"id" binding:"required"`
	Page int `form:"page" binding:"required"`
	Size int `form:"size" binding:"required"`
}

//朋友圈点赞
type LikeTweetCommentReq struct {
	CommentId int `json:"comment_id"` //评论id
}

// 大神详情朋友圈
type SparringDetailTweetReq struct {
	UserId int `form:"user_id" binding:"required"`
}

//朋友圈点赞
type LikeTweetReq struct {
	TweetId int `json:"tweet_id"` //朋友圈id
}

//屏蔽朋友圈
type HiddenTweetReq struct {
	TweetId int `json:"tweet_id"` //朋友圈id
}

//我的朋友圈列表
type MyTweetList struct {
	Page int `form:"page" binding:"required"`
	Size int `form:"size" binding:"required"`
}

//其他朋友圈
type OtherTweetList struct {
	BasePageReq
	UserId int `form:"user_id" binding:"required"`
}

//朋友圈评论详情列表
type TweetCommentDetailListReq struct {
	BasePageReq
	CommentId int `form:"comment_id" binding:"required"`
}

//删除朋友圈
type TweetDeleteReq struct {
	TweetId int64 `json:"tweet_id" binding:"required"`
}
