package request

type AgoraTokenReq struct {
	RoomId int `json:"room_id" binding:"required"`           // 房间id
	Role   int `json:"role" binding:"omitempty,min=1,max=2"` // 角色:1--发言权限,2--没有发言权限
}

type StudioListReq struct {
	Page       int   `form:"page"  binding:"gt=0"`               // 第几页
	Size       int   `form:"size"  binding:"gt=0"`               // 每页数量
	RoomType   *int  `form:"room_type" binding:"required,max=1"` // 房间类型
	RoomAttrId int32 `form:"room_attr_id"`                       // 房间属性id:-1--收藏,0--推荐,1--其他
}

// Update直播间
type UpdateStudioReq struct {
	RoomId          int64  `json:"room_id" binding:"required"`                        // 房间id
	RoomName        string `json:"room_name" binding:"required"`                      // 房间名称
	RoomCover       string `json:"room_cover" binding:"required"`                     // 房间封面
	RoomIsPassword  int    `json:"room_is_password" binding:"omitempty,min=0,max=1"`  // 是否设置密码:0--否,1--是
	RoomPassword    string `json:"room_password"`                                     // 房间密码
	RoomType        int    `json:"room_type" binding:"omitempty,min=0,max=1"`         // 类型(0音频直播,1音频派对)
	RoomOpenIm      int    `json:"room_open_im" binding:"omitempty,min=0,max=1"`      // 是否开通公屏(图文聊天0关闭,1开通)
	RoomSpeakType   int    `json:"room_speak_type" binding:"omitempty,min=0,max=3"`   // 麦位模式(0音频直播无麦位,1音频直播有麦位,2音频派对自由模式,3音频派对麦序模式)
	RoomContent     string `json:"room_content" binding:"max=500"`                    // 房间简介(派对公告内容)
	RoomTitle       string `json:"room_title"`                                        // 房间标题
	RoomBackground  string `json:"room_background" binding:"required"`                // 房间背景
	RoomEggbreakMsg int    `json:"room_eggbreak_msg" binding:"omitempty,min=0,max=1"` // 是否显示砸蛋消息:0--否,1--是
}

type CreateStudioReq struct {
	RoomCover      string `json:"room_cover" binding:"required"`                  // 房间封面
	RoomName       string `json:"room_name" binding:"required,max=15"`            // 房间名称
	RoomTitle      string `json:"room_title" binding:"max=15"`                    // 房间标题
	RoomType       *int   `json:"room_type" binding:"required,max=1,min=0"`       // 房间类型 0直播，1派对
	RoomSpeakType  *int   `json:"room_speak_type" binding:"required,min=0,max=3"` // 麦位模式(0音频直播无麦位,1音频直播有麦位,2音频派对自由模式,3音频派对麦序模式)
	RoomContent    string `json:"room_content" binding:"max=500"`                 // 房间简介(派对公告内容)
	RoomAttrId     int64  `json:"room_attr_id" binding:"required"`                // 房间属性(唱歌,脱口秀)
	RoomBackground string `json:"room_background" binding:"required"`             // 房间背景
}

type LiveSettlementReq struct {
	RoomId int64 `form:"room_id" binding:"required"` // 房间id
}

type CloseStudioReq struct {
	RoomId int64 `json:"room_id" binding:"required"`
}

type LiveFavoriteReq struct {
	RoomId int64 `json:"room_id" binding:"required"`           // 房间id
	Flag   int   `json:"flag" binding:"omitempty,min=0,max=1"` // 1收藏，0取消收藏
}

type StudioCardReq struct {
	RoomId int64 `form:"room_id" binding:"required"` // 房间id
}

type GetOwnInfoReq struct {
	RoomId *int64 `form:"room_id" binding:"required"` // 房间id
}

type StudioGiftsReq struct {
	RoomId int64 `form:"room_id" binding:"required"` // 房间id
	StartT int64 `form:"start_t" binding:"required"` // 房间id
}
type UserGiftRecordsReq struct {
	Type *int `form:"type" binding:"required,min=0,max=1"`
}

type GetHugWheatListReq struct {
	RoomId *int64 `form:"room_id" binding:"required"` // 房间id
}

const (
	USER_GIFT_RECORD_TYPE_INCOME  = iota // 收入明细
	USER_GIFT_RECORD_TYPE_CONSUME        // 消耗
)

const (
	RoomPkPunishLen = 10 // 房间pk惩罚内容长度
)

type RoomPkBaseReq struct {
	RoomId       int64 `json:"room_id" binding:"required"`                    // 房间id
	RoomPkSwitch *int  `json:"room_pk_switch" binding:"required,min=0,max=1"` // 开启或者关闭(0 关闭 1 开启)
}

type RoomOpenPkReq struct {
	RoomSpeakType      int    `json:"room_speak_type" binding:"required,min=2,max=3"`  // 麦位模式(2音频派对自由模式,3音频派对麦序模式)
	RoomPkRecordTime   int    `json:"room_pk_record_time" binding:"required"`          // pk时长
	RoomPkRecordPunish string `json:"room_pk_record_punish" binding:"required,max=10"` // pk惩罚
	RoomPkBaseReq
}

// 房间开始pk请求
type RoomPkStartReq struct {
	RoomId int64 `json:"room_id" binding:"required"` // 房间id
}

// 自动结算房间pk请求
type RoomManualSettlePkReq struct {
	RoomId int64 `json:"room_id" binding:"required"` // 房间id
}

// 增加房间pk时间
type RoomAddPkTimeReq struct {
	RoomId         int64 `json:"room_id" binding:"required"` // 房间id
	RoomAddTimeKey int   `json:"room_add_time_key"`          // 增加房间pk时间
}

type RoomPkEndReq struct {
	RoomId int64 `json:"room_id" binding:"required"` // 房间id
}

// 获取pk结果快照
type RoomPkDetail struct {
	RoomPkRecordID int64 `form:"room_pk_record_id" ` // 房间pk场次id
}

// 任务info-推送delay
type RoomPKTaskInfo struct {
	RoomPkRecordID int64 `json:"room_pk_record_id" gorm:"column:room_pk_record_id"` // 房间pk场次id
	Forbidden      bool  `json:"forbidden"`                                         // 是否为后台封禁整改结算
}
