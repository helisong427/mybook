package request

//购买道具
type ShoppingBuyPropReq struct {
	PropId   int64 `json:"prop_id" binding:"required"`                //道具Id
	PropType int   `json:"prop_type" binding:"omitempty,min=2,max=5"` //道具类型
	BuyNum   int64 `json:"buy_num" binding:"required"`                //购买数量
}

//商城--装扮列表
type ShoppingDressUpListReq struct {
	BasePageReq
	PropType int   `form:"prop_type" binding:"omitempty,min=3,max=5"` //装扮类型
	AttrId   int64 `form:"attr_id" binding:"required"`                //属性
}

//道具id
type ShoppingDressUpUseReq struct {
	PropId   int64 `json:"prop_id" binding:"required"`                //道具Id
	PropType int   `json:"prop_type" binding:"omitempty,min=2,max=5"` //道具类型
}

//商城--取下装扮
type ShoppingDressTakeOffReq struct {
	PropType int `json:"prop_type" binding:"omitempty,min=3,max=5"` //道具类型
}
