package request

type IndexCommentReq struct {
	Page int `form:"page"`
}
