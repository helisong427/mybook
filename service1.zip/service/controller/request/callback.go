package request

//首次认证回调请求参数(认证回调)
type FddCallbackReq struct {
	AppId      string `form:"appId"`      //平台方id
	SerialNo   string `form:"serialNo"`   //认证序列号
	CustomerId string `form:"customerId"` //客户编号
	Status     string `form:"status"`     //状态:0：未激活；1：未认证；2：审核通过；3：已提交待审核；4：审核不通过
	StatusDesc string `form:"statusDesc"` //不通过原因描述

	//重复认证请求参数(签署回调)
	TransactionId string `form:"transaction_id"` //交易号
	ContractId    string `form:"contract_id"`    //合同编号
	ResultCode    string `form:"result_code"`    //签章结果代码:3000（签章成功）3001(签章失败)
	ResultDesc    string `form:"result_desc"`    //签章结果描述
	DownloadUrl   string `form:"download_url"`   //下载地址
	ViewpdfUrl    string `form:"viewpdf_url"`    //查看地址
	Timestamp     string `form:"timestamp"`      //请求时间
	MsgDigest     string `form:"msg_digest"`     //签名
}

type BiliBiliAdCallbackReq struct {
	TrackId      string `form:"track_id" binding:"required" json:"track_id"`
	AccountId    string `form:"account_id" json:"account_id"`     // b站账号
	CampaignId   string `form:"campaign_id" json:"campaign_id"`   // b站计划id
	UnitId       string `form:"unit_id" json:"unit_id"`           // b站单元id
	CreativeId   string `form:"creative_id" json:"creative_id"`   // b站创意id
	OS           string `form:"os" json:"os"`                     // 0安卓，1ios，2windows phone
	Imei         string `form:"imei" json:"imei"`                 // 用户终端的 IMEI，原始值为 15 位 IMEI，取其 32 位 MD5 摘要。
	CallbackUrl  string `form:"callback_url" json:"callback_url"` // 回调地址（需要 urlencode
	Mac          string `form:"mac" json:"mac"`                   // 保留分隔符”:”的大写 MAC 地址，取其 32 位 MD5 摘要
	IDFA         string `form:"idfa" json:"idfa"`                 // iOS IDFA，适用于 iOS6 及以上
	AAID         string `form:"aaid" json:"aaid"`                 // Android Advertising ID
	AndroidId    string `form:"android_id" json:"android_id"`     // 用户终端的 Android ID
	OAID         string `form:"oaid" json:"oaid"`                 // 匿名设备标识符
	Ip           string `form:"ip" json:"ip"`
	UA           string `form:"ua" json:"ua"`                         // 数据上报终端设备的 User Agent
	ModelPattern string `form:"model_pattern" json:"model_pattern"`   // 手机型号
	ClientClickT int64  `form:"client_click_t" json:"client_click_t"` // 客户端点击时间
	ShopId       string `form:"shop_id" json:"shop_id"`               // 店铺 ID
	UpMid        string `form:"up_mid" json:"up_mid"`                 // 视频 UP 主 MID
}

// 推啊上报请求参数
type TuiACallbackReq struct {
	TuiAId      string `form:"tui_a_id" binding:"required"` // 推啊用户id
	TuiAOrderId string `form:"tui_a_order_id"`
	Ip          string `form:"ip" json:"ip"`
	UA          string `form:"ua" json:"ua"`     // 数据上报终端设备的 User Agent
	Imei        string `form:"imei" json:"imei"` // 加密imei，原值MD5 32位加密小写
	IDFA        string `form:"idfa" json:"idfa"` // iOS IDFA，适用于 iOS6 及以上
	AAID        string `form:"aaid" json:"aaid"` // Android Advertising ID
	Device      string `form:"device"`           // 推啊的imeiMd5>idfaMd5>oaidMd5参数值替换
	ReqTime     int64  `form:"-" json:"req_time"`
}

// 华为请求参数
type HuaWeiCallbackReq struct {
	ChannelId       string `form:"channel_id" binding:"required" json:"channel_id"`   //渠道id
	ContentId       string `form:"content_id" binding:"required" json:"content_id"`   //素材id
	ADGroupId       string `form:"adgroup_id" binding:"required" json:"adgroup_id"`   //任务id
	CampaignId      string `form:"campaign_id" binding:"required" json:"campaign_id"` //计划id
	OAID            string `form:"oaid" binding:"required" json:"oaid"`               //设备标识符，明文
	TrackingEnabled string `form:"tracking_enabled"  json:"tracking_enabled"`         //是否跟踪
	IP              string `form:"ip" json:"ip"`                                      //点击时的IP地址
	UserAgent       string `form:"user_agent" json:"user_agent"`                      //做URL编码
	EventType       string `form:"event_type" json:"event_type"`                      //事件类型
	TraceTime       string `form:"trace_time"  json:"trace_time"`                     //事件发生的时间
	Callback        string `form:"callback" binding:"required" json:"callback"`       //回调参数
	CorpId          string `form:"corp_id" json:"corp_id"`                            //广告主标识
	AppId           string `form:"app_id" json:"app_id"`                              //推广的app标识
	ChannelConfig   string `form:"channel_config" json:"channel_config"`
}
