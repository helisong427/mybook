package request

type GetGiftByTypeReq struct {
	AttrId int64 `form:"attr_id" binding:"required"`
}

type GetPropListByTypeAndAttrIdReq struct {
	PropType int   `form:"prop_type" json:"prop_type"`
	AttrId   int64 `form:"attr_id" json:"attr_id"`
}
