package request

// 申请主播
type ApplyAnchorReq struct {
	AttrID int64 `json:"attr_id" binding:"required"` //  属性id
}
