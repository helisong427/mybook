package request

// 极速匹配--用户下单
type SMPlaceOrderReq struct {
	SkillId                   int64                          `json:"skill_id" binding:"required"`  // 游戏id
	Gender                    int                            `json:"gender" binding:"oneof=0 1 2"` // 性别：0--不限，1--男，2--女
	Count                     int64                          `json:"count" binding:"min=1"`        // 数量
	MatchingRemark            string                         `json:"matching_remark"`              // 备注
	MatchingOtherRequirements []MatchingOtherRequirementsReq `json:"matching_other_requirements"`  // 其他要求
}

type MatchingOtherRequirementsReq struct {
	OtherKey   string `json:"other_key" binding:"required"`   // 其他要求名称
	OtherValue string `json:"other_value" binding:"required"` // 其他要求内容
}

// 极速匹配--异常状态完成
type SMExceptionSuccessReq struct {
	MatchingId int64 `json:"matching_id" binding:"required"` // 匹配id
}

// 极速匹配--抢单中心
type SMOrderGrabbingCenterReq struct {
	Page int `form:"page" binding:"required"`
	Size int `form:"size" binding:"required"`
}

// 极速匹配--退款
type SMRefundReq struct {
	MatchingId int64 `json:"matching_id" binding:"required"` // 匹配id
}

// 极速匹配--抢单
type SMGrabbingOrdersReq struct {
	MatchingId int64 `json:"matching_id" binding:"required"` // 匹配id
}
