package request

//公众号获取AccessToke地址
type WechatAccessTokeUrlReq struct {
	Code string `form:"code" binding:"required"`
}
