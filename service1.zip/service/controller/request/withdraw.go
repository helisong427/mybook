package request

//提现绑定银行卡
type WithdrawBindBankCardReq struct {
	Mobile       string `json:"mobile" binding:"required"`         //手机号
	Card         string `json:"card" binding:"required"`           //卡号
	BankCardName string `json:"bank_card_name" binding:"required"` //银行名称
	Action       int    `json:"action"`                            //动作：0--编辑,1--增加
}

//提现绑定支付宝
type WithdrawBindAlipayReq struct {
	Alipay string `json:"alipay" binding:"required"` //支付宝账号
	Action int    `json:"action"`                    //动作：0--编辑,1--增加
}

//提交提现申请
type WithdrawSubmitReq struct {
	BankcardId     int64 `json:"bankcard_id" binding:"required"`     //账户id
	WithdrawAmount int64 `json:"withdraw_amount" binding:"required"` //提现金额
}
