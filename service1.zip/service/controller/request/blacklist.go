package request

type BlackListReq struct {
	UserId int64 `json:"user_id" binding:"required"`
}
