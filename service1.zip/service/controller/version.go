package controller

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/enum"
	"gamers/models/dbmodels"
	"strconv"

	"github.com/gin-gonic/gin"
)

// 获取版本信息
func GetVersionInfo(c *gin.Context) {
	var form request.GetVersionInfoReq
	err := c.ShouldBindHeader(&form)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	if *form.ClientType != enum.USER_CLIENT_TYPE_ANDROID && *form.ClientType != enum.USER_CLIENT_TYPE_IOS {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", "客户端有误")
		return
	}
	param, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_CHECK_SWITCH)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "获取全局开关失败", "", err.Error())
		return
	}
	data, err := new(dbmodels.AppVersionLog).GetVersionLogByVersionAndClient(form.Version, *form.ClientType)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "获取当前版本信息失败", "", err.Error())
		return
	}
	version, err := new(dbmodels.AppVersionLog).GetVersionLogByLogIdAndClient(&data)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取版本信息失败", "", err.Error())
		return
	}
	checkSwitch, err := strconv.Atoi(param["value"])
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取审查开关失败", "", err.Error())
		return
	}
	if checkSwitch == dbmodels.VERSION_CHECK_SWITCH_ON {
		version.CheckSwitch = dbmodels.VERSION_CHECK_SWITCH_ON
	}
	rep := response.GetVersionInfoResp{
		VersionInfo: &version,
	}
	response.ResponseOk(c, "请求成功", rep)
	return
}
