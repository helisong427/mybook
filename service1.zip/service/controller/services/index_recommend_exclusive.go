package services

import (
	"encoding/json"
	"errors"
	"fmt"
	"gamers/controller/response"
	"gamers/models/dbmodels"
	"gamers/utils"
	"strconv"
	"time"

	"github.com/go-redis/redis"
	wr "github.com/mroth/weightedrand"
	"gorm.io/gorm"
)

type indexRecommendExclusive int

type indexRecommendExclusiveType int

const (
	// 首页推荐类型
	typeParty    indexRecommendExclusiveType = iota // 派对
	typeLive                                        // 直播
	typeSparring                                    // 大神
	typeVideo                                       // 朋友圈视频
	typeImage                                       // 朋友圈图片
)

const (
	retryRetry indexRecommendExclusive = 1 // 重试次数
)

// 首页推荐
type IndexRecommendExclusive struct {
	redisClient   *redis.Client
	redisKey      string
	position      map[int]int              // 推荐位(已经配置的推荐位,用于最后打乱顺序)
	UserId        int64                    // 用户id
	partyRetry    indexRecommendExclusive  // 派对递归重试次数
	LiveRetry     indexRecommendExclusive  // 直播递归重试次数
	SparringRetry indexRecommendExclusive  // 大神递归重试次数
	record        IndexRecommendUserRecord // 用户推荐记录
	page          int                      // 当前页
	// 首页专属推荐位推荐数量
	partyAmount    int // 派对
	liveAmount     int // 直播
	sparringAmount int // 大神
	pageMax        int // 首页推荐最大页(大于此页数,随机推荐数据)
}

type IndexRecommendUserRecord struct {
	Part       []int64 `json:"part"`        // 派对记录
	Live       []int64 `json:"live"`        // 直播记录
	Sparring   []int64 `json:"sparring"`    // 大神记录
	TweetImage []int64 `json:"tweet_image"` // 朋友圈图片记录
	TweetVideo []int64 `json:"tweet_video"` // 朋友圈视频记录
}

// 初始化
func IndexExclusiveRecommend(userId int64, page int) (r []interface{}, err error) {
	m := new(IndexRecommendExclusive)
	m.position = make(map[int]int)
	m.redisClient = utils.RedisClient
	m.redisKey = fmt.Sprintf("%s%d", utils.REDIS_INDEX_RECOMMEND_USER_RECORD, userId)
	m.UserId = userId
	m.page = page

	// 用户推荐记录
	result, err := m.redisClient.Get(m.redisKey).Result()
	if err != nil && err != redis.Nil {
		return
	}
	if result != "" {
		err = json.Unmarshal([]byte(result), &m.record)
		if err != nil {
			return
		}
	}
	// 推荐位配置
	key, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_INDEX_RECOMMEND)
	if err != nil {
		return nil, errors.New("查询推荐位配置失败:" + err.Error())
	}
	params := dbmodels.IndexRecommendParams{}
	err = json.Unmarshal([]byte(key["value"]), &params)
	if err != nil {
		return nil, errors.New("序列化推荐位配置失败:" + err.Error())
	}

	maxPage, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_INDEX_RECOMMEND_PAGE_MAX)
	if err != nil {
		return nil, errors.New("查询推荐位配置失败:" + err.Error())
	}
	m.pageMax, _ = strconv.Atoi(maxPage["value"])
	m.partyAmount = params.PartyAmount
	m.liveAmount = params.LiveAmount
	m.sparringAmount = params.SparringAmount
	listLen := m.partyAmount + m.liveAmount + m.sparringAmount

	list := make([]interface{}, listLen)
	party, err := m.party()
	if err != nil {
		return
	}
	for k, v := range party {
		list[k] = v
	}

	live, err := m.live()
	if err != nil {
		return
	}
	for k, v := range live {
		list[k+m.partyAmount] = v
	}

	sparring, err := m.sparring()
	if err != nil {
		return
	}
	for k, v := range sparring {
		list[k+m.partyAmount+m.sparringAmount] = v
	}
	for _, v := range list {
		if v != nil {
			r = append(r, v)
		}
	}
	// 打乱非预期推荐位的数据
	m.shuffle(r)

	go func() {
		marshal, _ := json.Marshal(m.record)
		err := m.redisClient.Set(m.redisKey, string(marshal), time.Hour).Err()
		if err != nil {
			utils.LogErrorF("[首页推荐]保存用户推荐记录失败:%s", err.Error())
		}
	}()

	return
}

// 专属推荐派对
func (m *IndexRecommendExclusive) party() (model []response.IndexRecommendModel, err error) {
	var (
		data []dbmodels.AppLiveRoom
		ids  []int64
	)
	ids = make([]int64, m.partyAmount)
	// 获取推荐位
	recommend, err := new(dbmodels.AppRecommend).QueryByPositionAndType(dbmodels.RECOMMEND_POSITION_EXCLUSIVE, dbmodels.RECOMMEND_TYPE_PARTY)
	if err != nil {
		return
	}
	if len(recommend) > 0 && m.page <= m.pageMax {
		positionId := m.getWeightRand(recommend)
		for _, v := range positionId {
			m.position[int(v.RecommendNumber)] = 1
			ids[v.RecommendNumber] = v.RecommendPositionId
		}
		// 查询指定数量的房间id
		roomId, err := m.partyQuerySpecifiedNumberId(ids)
		if err != nil {
			return nil, err
		}
		data, err = new(dbmodels.AppLiveRoom).QueryOrderIn(roomId, dbmodels.ROOM_TYPE_PARTY)
		if err != nil && err != gorm.ErrRecordNotFound {
			return nil, err
		}
	} else {
		// 未配置随机推荐位置
		data, err = m.partyRandFind()
		if err != nil && err != gorm.ErrRecordNotFound {
			return model, err
		}
	}

	for _, v := range data {
		var hot int
		hot = int(v.RoomHeat)
		// 处理热度为负数
		if v.RoomHeat < 0 {
			hot = 0
		}
		mod := response.IndexRecommendModel{
			Type: int(typeParty),
			PartModel: response.IndexRecommendPart{
				RoomId:         v.RoomId,
				RoomType:       v.RoomType,
				RoomName:       v.RoomName,
				RoomCover:      v.RoomCover,
				RoomPkState:    v.RoomPkState,
				RoomAttrId:     v.RoomAttrId,
				RoomAttrName:   v.RoomLiveAttr.AttrName,
				RoomSpeakType:  v.RoomSpeakType,
				RoomLiveStatus: v.RoomStatus,
				UserIconurl:    v.SystemUser.UserIconurl,
				UserNickname:   v.SystemUser.UserNickname,
				Hot:            hot,
			},
		}
		model = append(model, mod)
		m.record.Part = append(m.record.Part, v.RoomId)
	}
	return
}

// 获取指定数量的派对id
func (m *IndexRecommendExclusive) partyQuerySpecifiedNumberId(ids []int64) (roomId []int64, err error) {
	var (
		notInIds     []int64 // 获取随机房间时,排除此id
		nullIdNumber int64   // ids为空的数量
	)
	for _, v := range ids {
		if v == 0 {
			nullIdNumber++
		} else {
			notInIds = append(notInIds, v)
		}
	}
	for _, v := range m.record.Part {
		notInIds = append(notInIds, v)
	}

	row, data, err := new(dbmodels.AppLiveRoom).QuerySpecifiedNumberId(notInIds, dbmodels.ROOM_TYPE_PARTY, nullIdNumber)
	if err != nil && err != gorm.ErrRecordNotFound {
		return nil, err
	}
	if row >= nullIdNumber {
		for _, v := range data {
			for kel, val := range ids {
				if val == 0 {
					ids[kel] = v.RoomId
					// 加入已经推荐记录
					m.record.Part = append(m.record.Part, v.RoomId)
					break
				}
			}
		}
	} else {
		m.record.Part = m.record.Part[:0]
		m.partyRetry++
		if m.partyRetry < retryRetry {
			return m.partyQuerySpecifiedNumberId(ids)
		}
	}
	for _, v := range ids {
		roomId = append(roomId, v)
	}
	return
}

// 未配置随机推荐位置
func (m *IndexRecommendExclusive) partyRandFind() (data []dbmodels.AppLiveRoom, err error) {
	var notIds []int64
	for _, v := range m.record.Part {
		notIds = append(notIds, v)
	}
	row, data, err := new(dbmodels.AppLiveRoom).QueryRandFind(dbmodels.ROOM_TYPE_PARTY, m.partyAmount, notIds)
	if row > 0 {
		if row < int64(m.partyAmount) {
			m.record.Part = m.record.Part[:0]
		}
		return
	} else {
		m.record.Part = m.record.Part[:0]
		m.partyRetry++
		if m.partyRetry < retryRetry {
			return m.partyRandFind()
		}
	}
	return
}

// 专属推荐直播
func (m *IndexRecommendExclusive) live() (model []response.IndexRecommendModel, err error) {
	var (
		data []dbmodels.AppLiveRoom
		ids  []int64
	)
	ids = make([]int64, m.liveAmount)
	// 获取推荐位
	recommend, err := new(dbmodels.AppRecommend).QueryByPositionAndType(dbmodels.RECOMMEND_POSITION_EXCLUSIVE, dbmodels.RECOMMEND_TYPE_LIVE)
	if err != nil {
		return
	}
	if len(recommend) > 0 && m.page <= m.pageMax {
		positionId := m.getWeightRand(recommend)
		for _, v := range positionId {
			m.position[int(v.RecommendNumber)] = 1
			ids[v.RecommendNumber-int64(m.partyAmount)] = v.RecommendPositionId
		}
		// 查询指定数量的房间id
		roomId, err := m.liveQuerySpecifiedNumberId(ids)
		if err != nil {
			return nil, err
		}
		data, err = new(dbmodels.AppLiveRoom).QueryOrderIn(roomId, dbmodels.ROOM_TYPE_LIVE)
		if err != nil && err != gorm.ErrRecordNotFound {
			return nil, err
		}
	} else {
		// 未配置随机推荐位置
		data, err = m.liveRandFind()
		if err != nil && err != gorm.ErrRecordNotFound {
			return model, err
		}
	}

	for _, v := range data {
		var hot int
		hot = int(v.RoomHeat)
		// 处理热度为负数
		if v.RoomHeat < 0 {
			hot = 0
		}
		mod := response.IndexRecommendModel{
			Type: int(typeLive),
			LiveModel: response.IndexRecommendPart{
				RoomId:         v.RoomId,
				RoomType:       v.RoomType,
				RoomName:       v.RoomName,
				RoomPkState:    v.RoomPkState,
				RoomCover:      v.RoomCover,
				RoomAttrId:     v.RoomAttrId,
				RoomAttrName:   v.RoomLiveAttr.AttrName,
				RoomSpeakType:  v.RoomSpeakType,
				RoomLiveStatus: v.RoomStatus,
				UserIconurl:    v.SystemUser.UserIconurl,
				UserNickname:   v.SystemUser.UserNickname,
				Hot:            hot,
			},
		}
		model = append(model, mod)
		m.record.Part = append(m.record.Part, v.RoomId)
	}
	return
}

// 获取指定数量的派对id
func (m *IndexRecommendExclusive) liveQuerySpecifiedNumberId(ids []int64) (roomId []int64, err error) {
	var (
		notInIds     []int64 // 获取随机房间时,排除此id
		nullIdNumber int64   // ids为空的数量
	)
	for _, v := range ids {
		if v == 0 {
			nullIdNumber++
		} else {
			notInIds = append(notInIds, v)
		}
	}
	for _, v := range m.record.Live {
		notInIds = append(notInIds, v)
	}

	row, data, err := new(dbmodels.AppLiveRoom).QuerySpecifiedNumberId(notInIds, dbmodels.ROOM_TYPE_LIVE, nullIdNumber)
	if err != nil && err != gorm.ErrRecordNotFound {
		return nil, err
	}
	if row >= nullIdNumber {
		for _, v := range data {
			for kel, val := range ids {
				if val == 0 {
					ids[kel] = v.RoomId
					// 加入已经推荐记录
					m.record.Live = append(m.record.Live, v.RoomId)
					break
				}
			}
		}
	} else {
		m.record.Live = m.record.Live[:0]
		m.LiveRetry++
		if m.LiveRetry < retryRetry {
			return m.liveQuerySpecifiedNumberId(ids)
		}
	}
	for _, v := range ids {
		roomId = append(roomId, v)
	}
	return
}

// 未配置随机推荐位置
func (m *IndexRecommendExclusive) liveRandFind() (data []dbmodels.AppLiveRoom, err error) {
	var notIds []int64
	for _, v := range m.record.Live {
		notIds = append(notIds, v)
	}
	row, data, err := new(dbmodels.AppLiveRoom).QueryRandFind(dbmodels.ROOM_TYPE_LIVE, m.liveAmount, notIds)
	if row > 0 {
		if row < int64(m.liveAmount) {
			m.record.Live = m.record.Live[:0]
		}
		return
	} else {
		m.record.Live = m.record.Live[:0]
		m.LiveRetry++
		if m.LiveRetry < retryRetry {
			return m.partyRandFind()
		}
	}
	return
}

// 专属大神
func (m *IndexRecommendExclusive) sparring() (model []response.IndexRecommendModel, err error) {
	var (
		data            []dbmodels.AppSparringSkill
		ids             []int64
		recommendUserId []int64 // 推荐位用户id(用于去重)
	)
	ids = make([]int64, m.sparringAmount)
	// 获取推荐位
	recommend, err := new(dbmodels.AppRecommend).QueryByPositionAndType(dbmodels.RECOMMEND_POSITION_EXCLUSIVE, dbmodels.RECOMMEND_TYPE_SPARRING)
	if err != nil {
		return
	}

	if len(recommend) > 0 && m.page <= m.pageMax {
		positionId := m.getWeightRand(recommend)
		for _, v := range positionId {
			m.position[int(v.RecommendNumber)] = 1
			recommendUserId = append(recommendUserId, v.RecommendUserId)
			ids[v.RecommendNumber-int64(m.partyAmount)-int64(m.liveAmount)] = v.RecommendPositionId
		}
		// 查询指定数量的大神id
		skillId, err := m.sparringQuerySpecifiedNumberId(ids, recommendUserId)
		if err != nil {
			return model, err
		}
		// 获取大神
		data, err = new(dbmodels.AppSparringSkill).QueryOrderIn(skillId)
		if err != nil {
			return model, err
		}
	} else {
		// 未配置推荐位随机查询
		data, err = m.sparringRandFind()
		if err != nil && err != gorm.ErrRecordNotFound {
			return
		}
		if len(data) == 0 {
			return model, err
		}
	}
	for _, v := range data {
		priceWay, pricePrice := skillMinPrice(v)
		mod := response.IndexRecommendModel{
			Type: int(typeSparring),
			SparringModel: response.IndexRecommendSparring{
				SparringId:   v.SkillID,
				SkillName:    v.AppSkill.SkillName,
				SkillType:    v.AppSkill.SkillType,
				SkillIconurl: v.AppSkill.SkillIconurl,
				SkillInfo:    v.SkillInfo,
				UserId:       v.SystemUser.UserID,
				UserNickname: v.SystemUser.UserNickname,
				UserIconurl:  v.SystemUser.UserIconurl,
				PriceWay:     priceWay,
				PricePrice:   pricePrice,
			},
		}
		model = append(model, mod)
		m.record.Sparring = append(m.record.Sparring, v.SkillID)
	}

	return
}

// 获取指定数量的大神id
func (m *IndexRecommendExclusive) sparringQuerySpecifiedNumberId(ids []int64, recommendUserId []int64) (roomId []int64, err error) {
	var (
		notInIds     []int64 // 获取随机房间时,排除此id
		nullIdNumber int64   // ids为空的数量
	)
	for _, v := range ids {
		if v == 0 {
			nullIdNumber++
		} else {
			notInIds = append(notInIds, v)
		}
	}
	for _, v := range m.record.Part {
		notInIds = append(notInIds, v)
	}

	row, data, err := new(dbmodels.AppSparringSkill).QuerySpecifiedNumberId(notInIds, recommendUserId, nullIdNumber)
	if err != nil && err != gorm.ErrRecordNotFound {
		return nil, err
	}
	if row >= nullIdNumber {
		for _, v := range data {
			for kel, val := range ids {
				if val == 0 {
					ids[kel] = v.SkillID
					// 加入已经推荐记录
					m.record.Sparring = append(m.record.Sparring, v.SkillID)
					break
				}
			}
		}
	} else {
		m.record.Sparring = m.record.Sparring[:0]
		m.SparringRetry++
		if m.SparringRetry < retryRetry {
			return m.sparringQuerySpecifiedNumberId(ids, recommendUserId)
		}
	}
	for _, v := range ids {
		roomId = append(roomId, v)
	}
	return
}

func (m *IndexRecommendExclusive) sparringRandFind() (data []dbmodels.AppSparringSkill, err error) {
	var notIds []int64
	for _, v := range m.record.Sparring {
		notIds = append(notIds, v)
	}

	row, data, err := new(dbmodels.AppSparringSkill).QueryNumberRandNotIn(m.sparringAmount, notIds)
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}

	if row > 0 {
		if row < int64(m.liveAmount) {
			m.record.Sparring = m.record.Sparring[:0]
		}
		return
	} else {
		m.record.Sparring = m.record.Sparring[:0]
		m.SparringRetry++
		if m.SparringRetry < retryRetry {
			return m.sparringRandFind()
		}
	}
	return
}

// 获取随机结果
func (m *IndexRecommendExclusive) getWeightRand(recommend []dbmodels.AppRecommend) (position []recommendPosition) {
	// 按照编号分组
	recommendNumber := make(map[int64][]dbmodels.AppRecommend)
	for _, v := range recommend {
		recommendNumber[v.RecommendNumber] = append(recommendNumber[v.RecommendNumber], v)
	}

	for _, v := range recommendNumber {
		var recommendUserId int64
		randPositionId := m.weightRand(v)

		// 取出positionId对应的userId
		for _, val := range recommendNumber {
			for _, value := range val {
				if randPositionId == value.RecommendPositionId {
					recommendUserId = value.RecommendUserId
				}
			}
		}
		r := recommendPosition{
			RecommendPositionId: randPositionId,
			RecommendUserId:     recommendUserId,
			RecommendNumber:     v[0].RecommendNumber,
		}
		position = append(position, r)
	}
	return
}

// 加权随机
func (m *IndexRecommendExclusive) weightRand(recommend []dbmodels.AppRecommend) (fruit int64) {
	choice := []wr.Choice{}
	for _, v := range recommend {
		choice = append(choice, wr.NewChoice(v.RecommendPositionId, uint(v.RecommendWeight)))
	}
	chooser, _ := wr.NewChooser(choice...)
	fruit = chooser.Pick().(int64)
	return
}

// 打乱顺序
func (m *IndexRecommendExclusive) shuffle(slice []interface{}) {
	if len(slice) < m.liveAmount+m.sparringAmount+m.sparringAmount {
		return
	}
	// 未预设推荐位直接打乱原始切片
	if len(m.position) == 0 {
		utils.FuncShuffle(slice)
	} else {
		data := []interface{}{}
		// 取出非预期推荐位的数据
		for k, v := range slice {
			if _, ok := m.position[k]; !ok {
				data = append(data, v)
			}
		}
		utils.FuncShuffle(data)

		// 推荐位差集
		optionsDifference := make(map[int64]int)
		// listLen := m.partyAmount + m.liveAmount + m.sparringAmount
		listLen := len(slice)
		for i := 0; i < listLen; i++ {
			if _, ok := m.position[i]; !ok {
				optionsDifference[int64(i)] = 1
			}
		}
		dateLen := len(data)
		for k, _ := range optionsDifference {
			if len(slice) >= int(k) && dateLen > 0 {
				slice[k] = data[dateLen-1]
				dateLen--
			}
		}
	}
}
