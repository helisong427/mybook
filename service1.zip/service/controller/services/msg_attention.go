package services

import (
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"gamers/utils/tencent/tencentIm"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"

	"github.com/go-redis/redis"
	"gorm.io/gorm"
)

type AttentionAction interface {
	Like()
}

type Attention struct {
}

func InitAttention() Attention {
	return Attention{}
}

const ATTENTION_LIKE_TIMEOUT = 60 * 60 * 24 * 7 * time.Second // 关注信息缓存时间
const (
	C2C_ATTENTION_LIKE     = "c2c_attention_like"     // 关注消息
	C2C_ATTENTION_ALL_LIKE = "c2c_attention_all_like" // 互相关注
)

// 关注
func (m Attention) Like(userId, followerId int) {
	key := utils.REDIS_ATTENTION_TIMEOUT + strconv.Itoa(userId) + ":" + strconv.Itoa(followerId)
	userInfo, err := new(redismodels.UserInfo).GetUserInfo(int64(userId))
	if err != nil {
		utils.LogErrorF("获取用户【%d】信息失败,err:%s", followerId, err.Error())
		return
	}
	_, err = utils.RedisClient.Get(key).Result()
	if err != nil && err != redis.Nil {
		utils.LogErrorF("获取关注缓存【%s】信息失败,err:%s", key, err.Error())
		return
	}
	if err == nil {
		return
	}
	// 判断是否互相关注
	_, err = new(dbmodels.AppAttention).QueryExist(followerId, userId)
	if err != nil && err != gorm.ErrRecordNotFound {
		utils.LogErrorF("获取互相关注缓存【%d】【%d】信息失败,err:%s", followerId, userId, err.Error())
		return
	}
	// 如果存在已关注
	if err == nil {
		msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(C2C_ATTENTION_ALL_LIKE)
		if err != nil {
			utils.LogErrorF("获取申请点赞消息model失败,err:%s", err.Error())
			return
		}
		userMsg := redismodels.C2CMsg{Type: redismodels.MSG_ASSISTANT_TYPE_TIPS, Text: msgModel.MsgContent}
		err = userMsg.SendC2CMsg(strconv.Itoa(followerId), strconv.Itoa(userId))
		if err != nil {
			utils.LogErrorF("发送互相关注推送失败,err:%s", err.Error())
		}
		err = userMsg.SendC2CMsg(strconv.Itoa(userId), strconv.Itoa(followerId))
		if err != nil {
			utils.LogErrorF("发送互相关注推送失败,err:%s", err.Error())
		}
		return
	}
	// 如果未关注
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(C2C_ATTENTION_LIKE)
	if err != nil {
		utils.LogErrorF("获取申请点赞消息model失败,err:%s", err.Error())
		return
	}
	tip := strings.NewReplacer("${fans_nickname}", userInfo.UserNickname).Replace(msgModel.MsgContent)
	attentionMsg := redismodels.C2CMsg{
		Type:       redismodels.MSG_ASSISTANT_TYPE_TIPS_ACTION,
		ActionType: redismodels.MSG_ACTION_TYPE_ATTENTION,
		ActionStyle: redismodels.ActionStyle{Color: msgModel.MsgColor,
			Start: utf8.RuneCountInString(userInfo.UserNickname) + msgModel.MsgActionStart,
			End:   utf8.RuneCountInString(userInfo.UserNickname) + msgModel.MsgActionEnd},
		Text:              tip,
		ActionParams:      map[string]interface{}{"user_id": userInfo.UserID},
		NotificationClose: msgModel.MsgNotificationClose,
	}

	err = attentionMsg.SendC2CMsg(strconv.Itoa(userId), strconv.Itoa(followerId))
	if err != nil {
		utils.LogErrorF("发送互相关注推送失败,err:%s", err.Error())
	}
	err = utils.RedisClient.Set(key, 1, ATTENTION_LIKE_TIMEOUT).Err()
	if err != nil {
		utils.LogErrorF("加入发送关注消息缓存信息失败,err:%s", err.Error())
	}
	return
}

// 关注加标签
func (m Attention) LikeTag(userId, followerId int, isAdd bool) {
	userIdStr := strconv.Itoa(userId)
	followerIdStr := strconv.Itoa(followerId)
	if isAdd {
		err := tencentIm.AddUserTag(userIdStr, followerIdStr)
		if err != nil {
			utils.LogErrorF("添加用户【%d】标签【%d】信息失败,err:%s", userId, followerId, err.Error())
		}
	} else {
		err := tencentIm.DelUserTag(userIdStr, followerIdStr)
		if err != nil {
			utils.LogErrorF("移除用户【%d】标签【%d】信息失败,err:%s", userId, followerId, err.Error())
		}
	}
	return
}
