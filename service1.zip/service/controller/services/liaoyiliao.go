package services

import (
	"fmt"
	"gamers/controller/request"
	"gamers/models/dbmodels"
	"gamers/utils"
	"sync"
	"time"

	"github.com/go-redis/redis"
)

var minUserId int64 //最小用户id
var lylOnce sync.Once

//撩一撩每日消息
func LiaoyiliaoDailyMsg(userId int64) {
	// 查询最小用户id
	lylOnce.Do(func() {
		u, err := new(dbmodels.SystemUser).QueryMinUserId()
		if err != nil {
			utils.LogErrorF("[撩一撩消息]查询最小用户id失败:%s", err.Error())
		}
		minUserId = u.UserID
	})
	userId = userId - minUserId
	// 检查用户今天是否发送过撩一撩消息
	redisClient := utils.RedisClient
	key := fmt.Sprintf("%s%s", utils.REDIS_LIAOYILIAO_DAILY_MSG, time.Now().Format("20060102"))
	isExist, err := redisClient.GetBit(key, userId).Result()
	if err != nil && err != redis.Nil {
		return
	}
	// 如果等于0，表示未发送消息
	if isExist == 0 {
		// 记录发送记录
		err = redisClient.SetBit(key, userId, 1).Err()
		if err != nil {
			utils.LogErrorF("[撩一撩消息]记录失败:%s", err.Error())
			return
		}
		// 设置过期时间
		redisClient.Expire(key, time.Hour*24)
		user, err := new(dbmodels.SystemUser).UserIdByUser(userId)
		if err != nil {
			return
		}
		//用户是大神或者主播发送消息
		if user.UserIsAnchor == 1 || user.UserIsSparring == 1 {
			// 发送消息撩一撩消息
			new(LiaoyiliaoMsg).AssistantDailyMsg(userId)
			return
		}
	}
}

// LocalInviteMessageRejectMsg 通过gogo助手给用户发送撩一撩邀请消息，审核不通过的消息。
func LocalInviteMessageRejectMsg(params request.LocalInviteMessageRejectMsgReq) (err error) {
	return new(LiaoyiliaoMsg).InviteMessageReject(params.UserID, params.Reason)
}
