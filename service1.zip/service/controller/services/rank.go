package services

import (
	"encoding/json"
	"errors"
	"fmt"
	"reflect"
	"time"

	"github.com/go-redis/redis"

	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"gamers/utils/trydo"
	"gamers/utils/ymd"
)

const (
	rankCacheTimeOutDefault           = time.Minute * 5                      // 当前阶段默认缓存时间
	rankCacheTimeOutLongCheckInterval = time.Minute * 5                      // 非当前阶段与当前时间允许的最大检查差值（满足就需要缓存更长时间）
	rankUserItemLength                = 10                                   // rank user 排行长度
	rankRoomItemLengthHourly          = redismodels.RankRoomItemLengthHourly // rank room 排行长度
	rankRoomUserItemLength            = 10                                   // rank room user 排行长度
)

// 不同时段的排行榜有不同的查询方法
var rankQueryInitTools = map[string]struct {
	getPeriod                     func(t time.Time) int            // 获取 Period 接口
	getPeriodBeginAndEndTimestamp func(t time.Time) (int64, int64) // 获取 Period 起始/结束时间戳
	timeOut                       time.Duration                    // 当前阶段时缓存时间
	timeOutLong                   time.Duration                    // 非当前阶段缓存时间（数据无变化，需要较长时间缓存）
}{}

func init() {
	rankQueryInitTools = map[string]struct {
		getPeriod                     func(t time.Time) int
		getPeriodBeginAndEndTimestamp func(t time.Time) (int64, int64)
		timeOut                       time.Duration
		timeOutLong                   time.Duration
	}{
		"hourly": {
			getPeriod:                     ymd.GetHourDigit,
			getPeriodBeginAndEndTimestamp: ymd.GetHourBeginAndEndTimestamp,
			timeOut:                       time.Minute * 1,
			timeOutLong:                   time.Hour * 24 * 7,
		},
		"daily": {
			getPeriod:                     ymd.GetDayDigit,
			getPeriodBeginAndEndTimestamp: ymd.GetDayBeginAndEndTimestamp,
			timeOut:                       time.Minute * 10,
			timeOutLong:                   time.Hour * 24 * 60,
		},
		"weekly": {
			getPeriod:                     ymd.GetWeekDigit,
			getPeriodBeginAndEndTimestamp: ymd.GetWeekBeginAndEndTimestamp,
			timeOut:                       time.Hour * 1,
			timeOutLong:                   time.Hour * 24 * 180,
		},
		"monthly": {
			getPeriod:                     ymd.GetMonthDigit,
			getPeriodBeginAndEndTimestamp: ymd.GetMonthBeginAndEndTimestamp,
			timeOut:                       time.Hour * 6,
			timeOutLong:                   time.Hour * 24 * 380,
		},
	}
}

var rankRetryIntervals = []time.Duration{
	time.Millisecond * 100,
	time.Millisecond * 50,
	time.Millisecond * 75,
	time.Millisecond * 70,
	time.Millisecond * 70,
	time.Millisecond * 50,
	time.Millisecond * 40,
	time.Millisecond * 50,
	time.Millisecond * 50,
	time.Millisecond * 50,
}

type rankQueryCtrl struct {
	roomId       int64
	isCurPeriod  bool
	Tag          string
	PeriodTime   time.Time
	Period       int
	Length       int
	Begin        int64
	End          int64
	Countdown    int64
	RedisKey     string
	CacheTimeOut time.Duration
}

func (c *rankQueryCtrl) Init(rankTag string, rankPeriodTime time.Time, redisKeyPrefix string, length int) (err error) {
	c.Tag = rankTag
	c.Period = 0
	c.PeriodTime = rankPeriodTime
	c.Length = length
	c.Begin = 0
	c.End = 0
	c.Countdown = 0
	c.RedisKey = ""
	c.CacheTimeOut = rankCacheTimeOutDefault

	tools, ok := rankQueryInitTools[c.Tag]
	if !ok {
		return errors.New("error query params")
	}

	c.isCurPeriod = false
	var nowTime = time.Now()
	var nowTimeStamp = nowTime.Unix()
	var nowPeriod = tools.getPeriod(nowTime)

	c.Period = tools.getPeriod(c.PeriodTime)
	c.Begin, c.End = tools.getPeriodBeginAndEndTimestamp(c.PeriodTime)

	if c.Period == nowPeriod { // 当前周期，更新倒计时
		c.isCurPeriod = true
		c.Countdown = c.End - nowTimeStamp
		c.CacheTimeOut = tools.timeOut
		if time.Duration(c.Countdown)*time.Second < tools.timeOut {
			c.CacheTimeOut = time.Duration(c.Countdown) * time.Second
		}
	} else if c.Period < nowPeriod { // 之前的周期，重新计算缓存时间，之前的周期还会查询吗？？？
		var interval = time.Duration(nowTimeStamp-c.End) * time.Second
		c.Countdown = 0
		c.CacheTimeOut = tools.timeOutLong
		if interval > 0 {
			if interval < rankCacheTimeOutLongCheckInterval {
				c.CacheTimeOut = rankCacheTimeOutLongCheckInterval - interval
			} else {
				c.CacheTimeOut = tools.timeOutLong - interval
				if c.CacheTimeOut < 1 {
					c.CacheTimeOut = tools.timeOutLong / 10
				}
			}
		}
	} else {
		return errors.New("error query period time")
	}

	c.RedisKey = fmt.Sprintf("%s%s:%d", redisKeyPrefix, c.Tag, c.Period)

	return
}

// 需要 roomId 区分
func (c *rankQueryCtrl) InitByRoomId(roomId int64, rankTag string, rankPeriodTime time.Time, redisKeyPrefix string, length int) (err error) {
	c.roomId = roomId

	if err := c.Init(rankTag, rankPeriodTime, redisKeyPrefix, length); err != nil {
		return err
	}

	c.RedisKey = fmt.Sprintf("%s%s:%d:%d", redisKeyPrefix, c.Tag, c.Period, c.roomId)

	return
}

// get_cache: list must be pointer(slice)
// 获取排行榜缓存数据
func (c *rankQueryCtrl) Get(list interface{}) error {
	if c.RedisKey == "" {
		return errors.New("get error")
	}

	val, err := utils.RedisClient.Get(c.RedisKey).Result()
	switch err {
	case redis.Nil:
		return err
	case nil:
	default:
		return err
	}

	err = json.Unmarshal([]byte(val), list)
	if err != nil {
		utils.RedisClient.Del(c.RedisKey) // del
		return err
	}
	return nil
}

// save_cache: list must be slice/array
func (c *rankQueryCtrl) Save(list interface{}) {
	if c.RedisKey == "" {
		return
	}

	var cacheTimeOut = c.CacheTimeOut
	if c.isCurPeriod {
		if reflect.ValueOf(list).Len() < c.Length && cacheTimeOut > rankCacheTimeOutDefault {
			cacheTimeOut = rankCacheTimeOutDefault
		}
	}

	if cacheTimeOut <= 0 {
		return
	}

	go func() {
		data, err := json.Marshal(list)
		if err != nil {
			return
		}
		_ = utils.RedisClient.Set(c.RedisKey, string(data), cacheTimeOut).Err()
	}()
}

type rankUserInfo struct {
	UserId        int64  `json:"user_id"`         // user_id
	Nickname      string `json:"nickname"`        // 昵称
	Gender        int    `json:"gender"`          // 性别
	Icon          string `json:"icon"`            // 头像
	AvatarDressUp string `json:"avatar_dress_up"` // 头像框
	VipLevel      int    `json:"vip_level"`       // vip_level
	UnionId       int64  `json:"union_id"`        // 公会id
	UnionName     string `json:"union_name"`      // 公会名字
	RoomId        int64  `json:"room_id"`
}

func (c *rankQueryCtrl) QueryUserInfoByUserIdMaps(userIdMaps map[int64]int64) map[int64]*rankUserInfo {
	var unCachedUserMaps = map[int64]int64{}
	var unionIdMaps = map[int64]int64{}
	var ret = map[int64]*rankUserInfo{}

	for userId, _ := range userIdMaps {
		userInfo, err := new(redismodels.UserInfo).GetUserInfo(userId)
		if err != nil || userInfo.UserID != userId {
			unCachedUserMaps[userId] = userId
		} else {
			ret[userId] = &rankUserInfo{
				UserId:   userId,
				Nickname: userInfo.UserNickname,
				Gender:   userInfo.UserGender,
				Icon:     userInfo.UserIconurl,
				VipLevel: userInfo.VipLevel,
				UnionId:  userInfo.UserUnionId,
			}
			unionIdMaps[userInfo.UserUnionId] = userInfo.UserUnionId
		}
	}

	if len(unCachedUserMaps) == 0 {
		goto fillAvatarBox
	}

	{
		var queryUserIds []int64
		for userId, _ := range unCachedUserMaps {
			queryUserIds = append(queryUserIds, userId)
		}

		var data, err = new(dbmodels.SystemUser).GetUserInfo(queryUserIds)
		if err != nil {
			// load userinfo by queryUserIds failed --> ignore it.
			goto fillAvatarBox
		}

		for _, v := range data {
			ret[v.UserID] = &rankUserInfo{
				UserId:   v.UserID,
				Nickname: v.UserNickname,
				Gender:   v.UserGender,
				Icon:     v.UserIconurl,
				UnionId:  v.UserUnionId,
			}
			vipInfo, err := new(dbmodels.AppUserVipExperience).GetUserVipLevelByUserId(v.UserID)
			if err == nil {
				ret[v.UserID].VipLevel = vipInfo.ExperienceLevel
			}
			unionIdMaps[v.UserUnionId] = v.UserUnionId
		}
	}

fillAvatarBox:

	for _, v := range ret {
		var iconStyle = new(redismodels.IconStyle)
		if avatarDressUp, err := iconStyle.Get(v.UserId); err == nil {
			v.AvatarDressUp = avatarDressUp
		}
		//v.RoomId, _ = new(redismodels.UserInfo).GetUserJoinRoomId(v.UserId)
	}

	return ret
}

type rankRoomInfo struct {
	Room             *dbmodels.AppLiveRoom
	WheatObjByUserId map[int64]*redismodels.WheatObj // 麦位 map[user_id]*WheatObj
}

func (c *rankQueryCtrl) QueryRoomInfo(roomId int64) *rankRoomInfo {
	var ret = rankRoomInfo{
		Room:             nil, // ignore
		WheatObjByUserId: map[int64]*redismodels.WheatObj{},
	}

	var detail, err = new(redismodels.Wheat).QueryWheatDetail(int(roomId))
	if err == nil {
		for _, v := range detail.WheatObj {
			if v.UserId > 0 {
				var wheatObj = v
				ret.WheatObjByUserId[int64(v.UserId)] = &wheatObj
			}
		}
	}

	return &ret
}

// 查询用户房间
func (c *rankQueryCtrl) QueryUserRoom(userId int64) (roomId int64) {
	roomId, _ = new(redismodels.UserInfo).GetUserJoinRoomId(userId)
	if roomId != 0 {
		//查询房间详情
		//查询直播间信息
		room, err := new(dbmodels.AppLiveRoom).QueryRoomId(int(roomId))
		if err != nil {
			return 0
		} else {
			//判断房间状态是否正常
			if (room.RoomType == dbmodels.ROOM_TYPE_LIVE && room.RoomStatus == dbmodels.ROOM_STATUS_OK && room.RoomLiveStatus == dbmodels.ROOM_LIVE_STATUS_ON) || (room.RoomType == dbmodels.ROOM_TYPE_PARTY && room.RoomStatus == dbmodels.ROOM_STATUS_OK) {
				return roomId
			} else {
				return 0
			}
		}
	}
	return 0
}

func (c *rankQueryCtrl) QueryRoomInfoByRoomIdMaps(roomIdMaps map[int64]int64) map[int64]*rankRoomInfo {
	var ret = map[int64]*rankRoomInfo{}
	if len(roomIdMaps) == 0 {
		return ret
	}

	var roomIds []int
	for roomId, _ := range roomIdMaps {
		roomIds = append(roomIds, int(roomId))
	}

	if data, err := new(dbmodels.AppLiveRoom).QueryInRoomId(roomIds); err == nil {
		for _, v := range data {
			var roomData = v
			ret[v.RoomId] = &rankRoomInfo{
				Room:             &roomData,
				WheatObjByUserId: map[int64]*redismodels.WheatObj{}, // ignore
			}
		}
	}

	return ret
}

func getRankPeriodTime(timestamp int64) time.Time {
	if timestamp == 0 {
		return time.Now()
	}
	return time.Unix(timestamp, 0)
}

// 用户送礼排行（财富榜）
func GetRankUserSendWealth(userId int64, req *request.RankUserSendWealth) (resp *response.RankUserSendWealth, msg string, err error) {
	var queryCtrl = new(rankQueryCtrl)
	err = queryCtrl.Init(req.Tag, time.Now(), utils.REDIS_RANK_USER_SEND_WEALTH, rankUserItemLength)
	if err != nil {
		return nil, "无效的参数", err
	}

	resp = &response.RankUserSendWealth{
		Tag:       queryCtrl.Tag,
		Period:    queryCtrl.Period,
		Countdown: queryCtrl.Countdown,
		List:      nil,
	}

	var useCache = true // 使用缓存数据
	var userIds = map[int64]int64{}
	var data []*response.RankUserSendWealthItem

	err = queryCtrl.Get(&data) // 从redis里面获取数据
	if err == nil {
		goto finishWork
		//return resp, "获取成功", nil
	}
	// redis里面没有数据，加锁查询
	{
		var lockVal, isLock = utils.AcquireLock(queryCtrl.RedisKey, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
		if !isLock { // 没有加到锁，有其他查询正在处理，等一段时间再尝试从redis获取
			var succeed = trydo.DoWithIntervals(rankRetryIntervals, func() (isOver bool) {
				if err := queryCtrl.Get(&data); err == nil {
					return true
				}
				return false
			})
			if !succeed {
				return nil, "获取失败", errors.New("get rank data failed")
			}
			goto finishWork
			//return resp, "获取成功", nil
		}
		defer utils.ReleaseLock(queryCtrl.RedisKey, lockVal)
	}

	{ // 加到锁，从mysql里面查询直播间送礼排行榜前10记录
		useCache = false
		queryData, err := new(dbmodels.AppAnchorRoomProp).GetRankUserSendWealth(queryCtrl.Begin, queryCtrl.End, queryCtrl.Length)
		if err != nil {
			return nil, "获取失败", err
		}

		data = nil
		for _, v := range queryData {
			userIds[v.UserId] = v.UserId
			data = append(data, &response.RankUserSendWealthItem{
				UserId: v.UserId,
				Wealth: v.Wealth,
			})
		}
	}

finishWork:

	var ownData *response.RankUserSendWealthItemOwn
	if userId > 0 {
		if !useCache { // 没有使用缓存获取，自己的数据从所有查询到的mysql记录里填充；useCache改为fromCache更合适？？
			for _, v := range data {
				if v.UserId == userId { // 如果用户自己在前10，则保存用户自己的数据
					ownData = &response.RankUserSendWealthItemOwn{
						RankUserSendWealthItem: *v,
					}
				}
			}
		}
		if ownData == nil { // 用户自己未在前10，查询自己的数据
			userIds[userId] = userId
			// 获取用户自己的记录
			ownQueryData, err := new(dbmodels.AppAnchorRoomProp).GetRankUserSendWealthByUserId(userId, queryCtrl.Begin, queryCtrl.End)
			if err != nil {
				return nil, "获取失败", err
			}
			ownData = &response.RankUserSendWealthItemOwn{ // ownData
				RankUserSendWealthItem: response.RankUserSendWealthItem{
					UserId: ownQueryData.UserId,
					Wealth: ownQueryData.Wealth,
				},
			}
		}

		// 计算差值
		ownData.Rank = 0
		ownData.DiffValue = ownData.Wealth
		if len(data) > 0 {
			for i, v := range data {
				if ownData.UserId == v.UserId {
					ownData.Rank = i + 1
					break
				}
			}
			switch ownData.Rank {
			case 0:
				ownData.DiffValue = ownData.Wealth - data[len(data)-1].Wealth
			case 1:
				if len(data) >= 2 {
					ownData.DiffValue = ownData.Wealth - data[1].Wealth
				}
			default:
				ownData.DiffValue = ownData.Wealth - data[ownData.Rank-2].Wealth
			}
		}
	}

	if len(userIds) > 0 {
		userInfos := queryCtrl.QueryUserInfoByUserIdMaps(userIds)
		for _, v := range data {
			if userInfo, ok := userInfos[v.UserId]; ok {
				v.Nickname = userInfo.Nickname
				v.Gender = userInfo.Gender
				v.Icon = userInfo.Icon
				v.AvatarDressUp = userInfo.AvatarDressUp
				v.UnionId = userInfo.UnionId
				v.RoomId = queryCtrl.QueryUserRoom(userInfo.UserId)
			}
		}
		//自己的排行榜数据
		if ownData != nil {
			if userInfo, ok := userInfos[ownData.UserId]; ok {
				ownData.Nickname = userInfo.Nickname
				ownData.Gender = userInfo.Gender
				ownData.Icon = userInfo.Icon
				ownData.AvatarDressUp = userInfo.AvatarDressUp
				ownData.UnionId = userInfo.UnionId
				ownData.RoomId = queryCtrl.QueryUserRoom(userInfo.UserId)
			}
		}
	}

	for _, v := range data {
		v.RoomId = queryCtrl.QueryUserRoom(v.UserId) // 上面490行不是已经查询了RoomId了吗？又查询？ data和userIds是一起赋值的，490行查了所以这里不需要在查一次了
	}

	resp.List = data
	resp.Own = ownData

	if !useCache { // 数据来源不是cache，保存到redis
		queryCtrl.Save(resp.List)
	}

	return resp, "获取成功", nil
}

// 用户收礼排行（魅力榜）
func GetRankUserRecvCharm(userId int64, req *request.RankUserRecvCharm) (resp *response.RankUserRecvCharm, msg string, err error) {
	var queryCtrl = new(rankQueryCtrl)
	err = queryCtrl.Init(req.Tag, time.Now(), utils.REDIS_RANK_USER_RECV_CHARM, rankUserItemLength)
	if err != nil {
		return nil, "无效的参数", err
	}

	resp = &response.RankUserRecvCharm{
		Tag:       queryCtrl.Tag,
		Period:    queryCtrl.Period,
		Countdown: queryCtrl.Countdown,
		List:      nil,
	}

	var useCache = true // 使用缓存数据
	var userIds = map[int64]int64{}
	var data []*response.RankUserRecvCharmItem

	err = queryCtrl.Get(&data)
	if err == nil {
		goto finishWork
		//return resp, "获取成功", nil
	}

	{
		var lockVal, isLock = utils.AcquireLock(queryCtrl.RedisKey, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
		if !isLock {
			var succeed = trydo.DoWithIntervals(rankRetryIntervals, func() (isOver bool) {
				if err := queryCtrl.Get(&data); err == nil {
					return true
				}
				return false
			})
			if !succeed {
				return nil, "获取失败", errors.New("get rank data failed")
			}
			goto finishWork
			//return resp, "获取成功", nil
		}
		defer utils.ReleaseLock(queryCtrl.RedisKey, lockVal)
	}

	{
		useCache = false
		queryData, err := new(dbmodels.AppAnchorRoomProp).GetRankUserRecvCharm(queryCtrl.Begin, queryCtrl.End, queryCtrl.Length)
		if err != nil {
			return nil, "获取失败", err
		}

		data = nil
		for _, v := range queryData {
			userIds[v.UserId] = v.UserId
			data = append(data, &response.RankUserRecvCharmItem{
				UserId: v.UserId,
				Charm:  v.Charm,
			})
		}
	}

finishWork:

	var ownData *response.RankUserRecvCharmItemOwn
	if userId > 0 {
		if !useCache {
			for _, v := range data {
				if v.UserId == userId {
					ownData = &response.RankUserRecvCharmItemOwn{
						RankUserRecvCharmItem: *v,
					}
				}
			}
		}
		//如果榜上没有自己的数据,查询近段时间自己的魅力值
		if ownData == nil {
			userIds[userId] = userId
			ownQueryData, err := new(dbmodels.AppAnchorRoomProp).GetRankUserRecvCharmByUserId(userId, queryCtrl.Begin, queryCtrl.End)
			if err != nil {
				return nil, "获取失败", err
			}
			ownData = &response.RankUserRecvCharmItemOwn{
				RankUserRecvCharmItem: response.RankUserRecvCharmItem{
					UserId: ownQueryData.UserId,
					Charm:  ownQueryData.Charm,
				},
			}
		}

		// 计算差值
		ownData.Rank = 0
		ownData.DiffValue = ownData.Charm
		if len(data) > 0 {
			for i, v := range data {
				if ownData.UserId == v.UserId {
					ownData.Rank = i + 1
					break
				}
			}
			switch ownData.Rank {
			case 0:
				ownData.DiffValue = ownData.Charm - data[len(data)-1].Charm
			case 1:
				if len(data) >= 2 {
					ownData.DiffValue = ownData.Charm - data[1].Charm
				}
			default:
				ownData.DiffValue = ownData.Charm - data[ownData.Rank-2].Charm
			}
		}
	}

	if len(userIds) > 0 {
		userInfos := queryCtrl.QueryUserInfoByUserIdMaps(userIds)
		for _, v := range data {
			if userInfo, ok := userInfos[v.UserId]; ok {
				v.Nickname = userInfo.Nickname
				v.Gender = userInfo.Gender
				v.Icon = userInfo.Icon
				v.AvatarDressUp = userInfo.AvatarDressUp
				v.UnionId = userInfo.UnionId
				v.RoomId = queryCtrl.QueryUserRoom(userInfo.UserId)
			}
		}
		if ownData != nil {
			if userInfo, ok := userInfos[ownData.UserId]; ok {
				ownData.Nickname = userInfo.Nickname
				ownData.Gender = userInfo.Gender
				ownData.Icon = userInfo.Icon
				ownData.AvatarDressUp = userInfo.AvatarDressUp
				ownData.UnionId = userInfo.UnionId
				ownData.RoomId = queryCtrl.QueryUserRoom(userInfo.UserId)
			}
		}
	}
	for _, v := range data {
		v.RoomId = queryCtrl.QueryUserRoom(v.UserId)
	}

	resp.List = data
	resp.Own = ownData

	if !useCache {
		queryCtrl.Save(resp.List)
	}

	return resp, "获取成功", nil
}

func getRankRoomSendCharmFromRedis(roomId int64, queryCtrl *rankQueryCtrl) ([]*response.RankRoomSendCharmItem, *response.RankRoomSendCharmItemOwn, error) {
	data, err := new(redismodels.RankRoomSendCharm).Init(queryCtrl.Tag, queryCtrl.PeriodTime, queryCtrl.Length).GetRank(roomId)
	if err != nil {
		return nil, nil, err
	}

	var rankData []*response.RankRoomSendCharmItem
	var ownData *response.RankRoomSendCharmItemOwn
	for _, v := range data.List {
		rankData = append(rankData, &response.RankRoomSendCharmItem{
			RoomId: v.RoomId,
			Charm:  v.Value,
		})
	}

	if data.Own != nil && roomId > 0 {
		ownData = &response.RankRoomSendCharmItemOwn{}
		ownData.RoomId = data.Own.RoomId
		ownData.Rank = data.Own.Rank
		ownData.Charm = data.Own.Value
	}

	return rankData, ownData, nil
}

// 房间送礼排行（魅力榜）
func GetRankRoomSendCharm(req *request.RankRoomSendCharm) (resp *response.RankRoomSendCharm, msg string, err error) {
	var queryCtrl = new(rankQueryCtrl)
	err = queryCtrl.Init(req.Tag, time.Now(), utils.REDIS_RANK_ROOM_SEND_CHARM, rankRoomItemLengthHourly)
	if err != nil {
		return nil, "无效的参数", err
	}

	resp = &response.RankRoomSendCharm{
		Tag:       queryCtrl.Tag,
		Period:    queryCtrl.Period,
		Countdown: queryCtrl.Countdown,
		List:      nil,
	}

	var (
		data    []*response.RankRoomSendCharmItem
		ownData *response.RankRoomSendCharmItemOwn
	)

	data, ownData, err = getRankRoomSendCharmFromRedis(req.RoomId, queryCtrl)
	if err != nil {
		return nil, "获取失败", err
	}

	if ownData != nil {
		// 计算差值
		var rank = ownData.Rank
		ownData.Rank = 0
		ownData.DiffValue = ownData.Charm
		if len(data) > 0 {
			for i, v := range data {
				if ownData.RoomId == v.RoomId {
					ownData.Rank = i + 1
					break
				}
			}
			switch ownData.Rank {
			case 0:
				ownData.DiffValue = ownData.Charm - data[len(data)-1].Charm
			case 1:
				if len(data) >= 2 {
					ownData.DiffValue = ownData.Charm - data[1].Charm
				}
			default:
				ownData.DiffValue = ownData.Charm - data[ownData.Rank-2].Charm
			}
		}
		if rank > 0 {
			ownData.Rank = rank
		}
	}

	var roomIds = map[int64]int64{}
	for _, v := range data {
		roomIds[v.RoomId] = v.RoomId
	}
	if ownData != nil {
		roomIds[ownData.RoomId] = ownData.RoomId
	}

	if len(roomIds) > 0 {
		roomInfos := queryCtrl.QueryRoomInfoByRoomIdMaps(roomIds)
		for _, v := range data {
			if roomInfo, ok := roomInfos[v.RoomId]; ok {
				v.RoomType = roomInfo.Room.RoomType
				v.RoomName = roomInfo.Room.RoomName
				v.RoomCover = roomInfo.Room.RoomCover
				v.RoomAttrType = roomInfo.Room.RoomLiveAttr.AttrType
				v.RoomAttrIsShow = roomInfo.Room.RoomLiveAttr.AttrIsShow
				v.UnionId = roomInfo.Room.RoomUnionId
				v.UnionName = roomInfo.Room.AppUnion.UnionName
				v.RoomAttrId = roomInfo.Room.RoomAttrId
				v.RoomAttrName = roomInfo.Room.RoomLiveAttr.AttrName
			}
		}

		if ownData != nil {
			if roomInfo, ok := roomInfos[ownData.RoomId]; ok {
				ownData.RoomType = roomInfo.Room.RoomType
				ownData.RoomName = roomInfo.Room.RoomName
				ownData.RoomCover = roomInfo.Room.RoomCover
				ownData.RoomAttrType = roomInfo.Room.RoomLiveAttr.AttrType
				ownData.RoomAttrIsShow = roomInfo.Room.RoomLiveAttr.AttrIsShow
				ownData.UnionId = roomInfo.Room.RoomUnionId
				ownData.UnionName = roomInfo.Room.AppUnion.UnionName
				ownData.RoomAttrId = roomInfo.Room.RoomAttrId
				ownData.RoomAttrName = roomInfo.Room.RoomLiveAttr.AttrName
			}
		}
	}

	resp.List = data
	resp.Own = ownData

	return resp, "获取成功", nil
}

// 房间送礼排行变更轮询（魅力榜）
func GetRankRoomSendCharmRollPolling(req *request.RankRoomSendCharmRollPolling) (resp *response.RankRoomSendCharmRollPolling, msg string, err error) {
	var queryCtrl = new(rankQueryCtrl)
	err = queryCtrl.Init(req.Tag, time.Now(), utils.REDIS_RANK_ROOM_SEND_CHARM, rankRoomItemLengthHourly)
	if err != nil {
		return nil, "无效的参数", err
	}

	resp = &response.RankRoomSendCharmRollPolling{
		RoomId:       req.RoomId,
		Tag:          req.Tag,
		Period:       req.Period,
		Rank:         req.Rank,
		Score:        req.Score,
		NewPeriod:    queryCtrl.Period,
		NewCountdown: queryCtrl.Countdown,
		NewRank:      0,
		NewScore:     0,
	}

	resp.NewRank, resp.NewScore = new(redismodels.RankRoomSendCharm).Init("hourly", queryCtrl.PeriodTime, queryCtrl.Length).Query(req.RoomId)

	return resp, "获取成功", nil
}

// 房间内用户送礼排行（财富榜）
func GetRankRoomUserSendWealth(userId int64, req *request.RankRoomUserSendWealth) (resp *response.RankRoomUserSendWealth, msg string, err error) {
	var queryCtrl = new(rankQueryCtrl)
	err = queryCtrl.InitByRoomId(req.RoomId, req.Tag, time.Now(), utils.REDIS_RANK_ROOM_USER_SEND_WEALTH, rankRoomUserItemLength)
	if err != nil {
		return nil, "无效的参数", err
	}

	resp = &response.RankRoomUserSendWealth{
		RoomId:    req.RoomId,
		Tag:       queryCtrl.Tag,
		Period:    queryCtrl.Period,
		Countdown: queryCtrl.Countdown,
		List:      nil,
	}

	var useCache = true // 使用缓存数据
	var userIds = map[int64]int64{}
	var data []*response.RankRoomUserSendWealthItem

	// 有缓存就使用缓存
	err = queryCtrl.Get(&data)
	if err == nil {
		goto finishWork
		//return resp, "获取成功", nil
	}

	{
		var lockVal, isLock = utils.AcquireLock(queryCtrl.RedisKey, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
		if !isLock {
			var succeed = trydo.DoWithIntervals(rankRetryIntervals, func() (isOver bool) {
				if err := queryCtrl.Get(&data); err == nil {
					return true
				}
				return false
			})
			if !succeed {
				return nil, "获取失败", errors.New("get rank data failed")
			}
			goto finishWork
			//return resp, "获取成功", nil
		}
		defer utils.ReleaseLock(queryCtrl.RedisKey, lockVal)
	}

	{
		useCache = false
		queryData, err := new(dbmodels.AppAnchorRoomProp).GetRankRoomUserSendWealth(req.RoomId, queryCtrl.Begin, queryCtrl.End, queryCtrl.Length)
		if err != nil {
			return nil, "获取失败", err
		}

		data = nil
		for _, v := range queryData {
			userIds[v.UserId] = v.UserId
			data = append(data, &response.RankRoomUserSendWealthItem{
				UserId: v.UserId,
				Wealth: v.Wealth,
			})
		}
	}

finishWork:

	var ownData *response.RankRoomUserSendWealthItemOwn
	if userId > 0 {
		if !useCache {
			for _, v := range data {
				if v.UserId == userId {
					ownData = &response.RankRoomUserSendWealthItemOwn{
						RankRoomUserSendWealthItem: *v,
					}
				}
			}
		}
		if ownData == nil {
			userIds[userId] = userId
			ownQueryData, err := new(dbmodels.AppAnchorRoomProp).GetRankRoomUserSendWealthByUserId(userId, req.RoomId, queryCtrl.Begin, queryCtrl.End)
			if err != nil {
				return nil, "获取失败", err
			}
			ownData = &response.RankRoomUserSendWealthItemOwn{
				RankRoomUserSendWealthItem: response.RankRoomUserSendWealthItem{
					UserId: ownQueryData.UserId,
					Wealth: ownQueryData.Wealth,
				},
			}
		}

		// 计算差值
		ownData.Rank = 0
		ownData.DiffValue = ownData.Wealth
		if len(data) > 0 {
			for i, v := range data {
				if ownData.UserId == v.UserId {
					ownData.Rank = i + 1
					break
				}
			}
			switch ownData.Rank {
			case 0:
				ownData.DiffValue = ownData.Wealth - data[len(data)-1].Wealth
			case 1:
				if len(data) >= 2 {
					ownData.DiffValue = ownData.Wealth - data[1].Wealth
				}
			default:
				ownData.DiffValue = ownData.Wealth - data[ownData.Rank-2].Wealth
			}
		}
	}

	if len(userIds) > 0 {
		userInfos := queryCtrl.QueryUserInfoByUserIdMaps(userIds)
		for _, v := range data {
			if userInfo, ok := userInfos[v.UserId]; ok {
				v.Nickname = userInfo.Nickname
				v.Gender = userInfo.Gender
				v.Icon = userInfo.Icon
				v.AvatarDressUp = userInfo.AvatarDressUp
				v.VipLevel = userInfo.VipLevel
				v.UnionId = userInfo.UnionId
			}
		}
		if ownData != nil {
			if userInfo, ok := userInfos[ownData.UserId]; ok {
				ownData.Nickname = userInfo.Nickname
				ownData.Gender = userInfo.Gender
				ownData.Icon = userInfo.Icon
				ownData.AvatarDressUp = userInfo.AvatarDressUp
				ownData.VipLevel = userInfo.VipLevel
				ownData.UnionId = userInfo.UnionId
			}
		}
	}

	// 补充房间内身份/房间内麦序信息
	if len(data) > 0 || ownData != nil {
		roomInfo := queryCtrl.QueryRoomInfo(req.RoomId)
		for _, v := range data {
			v.RoomWheatPosition = -1 // 房间麦序从0开始，每个都需要赋值一下，默认不在麦序（-1）
			if rwtInfo, ok := roomInfo.WheatObjByUserId[v.UserId]; ok {
				v.RoomRole = rwtInfo.Role
				v.RoomWheatPosition = rwtInfo.Position
			}
		}
		if ownData != nil {
			ownData.RoomWheatPosition = -1 // 房间麦序从0开始，每个都需要赋值一下，默认不在麦序（-1）
			if rwtInfo, ok := roomInfo.WheatObjByUserId[ownData.UserId]; ok {
				ownData.RoomRole = rwtInfo.Role
				ownData.RoomWheatPosition = rwtInfo.Position
			}
		}
	}

	resp.List = data
	resp.Own = ownData

	if !useCache {
		queryCtrl.Save(resp.List)
	}

	return resp, "获取成功", nil
}

// 房间内用户收礼排行（魅力榜）
func GetRankRoomUserRecvCharm(userId int64, req *request.RankRoomUserRecvCharm) (resp *response.RankRoomUserRecvCharm, msg string, err error) {
	var queryCtrl = new(rankQueryCtrl)
	err = queryCtrl.InitByRoomId(req.RoomId, req.Tag, time.Now(), utils.REDIS_RANK_ROOM_USER_RECV_CHARM, rankRoomUserItemLength)
	if err != nil {
		return nil, "无效的参数", err
	}

	resp = &response.RankRoomUserRecvCharm{
		RoomId:    req.RoomId,
		Tag:       queryCtrl.Tag,
		Period:    queryCtrl.Period,
		Countdown: queryCtrl.Countdown,
		List:      nil,
	}

	var useCache = true // 使用缓存数据
	var userIds = map[int64]int64{}
	var data []*response.RankRoomUserRecvCharmItem

	err = queryCtrl.Get(&data)
	if err == nil {
		goto finishWork
		//return resp, "获取成功", nil
	}

	{
		var lockVal, isLock = utils.AcquireLock(queryCtrl.RedisKey, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
		if !isLock {
			var succeed = trydo.DoWithIntervals(rankRetryIntervals, func() (isOver bool) {
				if err := queryCtrl.Get(&data); err == nil {
					return true
				}
				return false
			})
			if !succeed {
				return nil, "获取失败", errors.New("get rank data failed")
			}
			goto finishWork
			//return resp, "获取成功", nil
		}
		defer utils.ReleaseLock(queryCtrl.RedisKey, lockVal)
	}

	{
		useCache = false
		queryData, err := new(dbmodels.AppAnchorRoomProp).GetRankRoomUserRecvCharm(req.RoomId, queryCtrl.Begin, queryCtrl.End, queryCtrl.Length)
		if err != nil {
			return nil, "获取失败", err
		}

		data = nil
		for _, v := range queryData {
			userIds[v.UserId] = v.UserId
			data = append(data, &response.RankRoomUserRecvCharmItem{
				UserId: v.UserId,
				Charm:  v.Charm,
			})
		}
	}

finishWork:

	var ownData *response.RankRoomUserRecvCharmItemOwn
	if userId > 0 {
		if !useCache {
			for _, v := range data {
				if v.UserId == userId {
					ownData = &response.RankRoomUserRecvCharmItemOwn{
						RankRoomUserRecvCharmItem: *v,
					}
				}
			}
		}
		if ownData == nil {
			userIds[userId] = userId
			ownQueryData, err := new(dbmodels.AppAnchorRoomProp).GetRankRoomUserRecvCharmByUserId(userId, req.RoomId, queryCtrl.Begin, queryCtrl.End)
			if err != nil {
				return nil, "获取失败", err
			}
			ownData = &response.RankRoomUserRecvCharmItemOwn{
				RankRoomUserRecvCharmItem: response.RankRoomUserRecvCharmItem{
					UserId: ownQueryData.UserId,
					Charm:  ownQueryData.Charm,
				},
			}
		}

		// 计算差值
		ownData.Rank = 0
		ownData.DiffValue = ownData.Charm
		if len(data) > 0 {
			for i, v := range data {
				if ownData.UserId == v.UserId {
					ownData.Rank = i + 1
					break
				}
			}
			switch ownData.Rank {
			case 0:
				ownData.DiffValue = ownData.Charm - data[len(data)-1].Charm
			case 1:
				if len(data) >= 2 {
					ownData.DiffValue = ownData.Charm - data[1].Charm
				}
			default:
				ownData.DiffValue = ownData.Charm - data[ownData.Rank-2].Charm
			}
		}
	}

	if len(userIds) > 0 {
		userInfos := queryCtrl.QueryUserInfoByUserIdMaps(userIds)
		for _, v := range data {
			if userInfo, ok := userInfos[v.UserId]; ok {
				v.Nickname = userInfo.Nickname           //昵称
				v.Gender = userInfo.Gender               //性别
				v.Icon = userInfo.Icon                   //头像
				v.AvatarDressUp = userInfo.AvatarDressUp //头像框
				v.UnionId = userInfo.UnionId             //公会id
				v.UnionName = userInfo.UnionName
				v.VipLevel = userInfo.VipLevel //vip等级
			}
		}
		if ownData != nil {
			if userInfo, ok := userInfos[ownData.UserId]; ok {
				ownData.Nickname = userInfo.Nickname
				ownData.Gender = userInfo.Gender
				ownData.Icon = userInfo.Icon
				ownData.AvatarDressUp = userInfo.AvatarDressUp
				ownData.UnionId = userInfo.UnionId
				ownData.UnionName = userInfo.UnionName
				ownData.VipLevel = userInfo.VipLevel
			}
		}
	}

	// 补充房间内身份/房间内麦序信息
	if len(data) > 0 || ownData != nil {
		roomInfo := queryCtrl.QueryRoomInfo(req.RoomId)
		for _, v := range data {
			v.RoomWheatPosition = -1 // 房间麦序从0开始，每个都需要赋值一下，默认不在麦序（-1）
			if rwtInfo, ok := roomInfo.WheatObjByUserId[v.UserId]; ok {
				v.RoomRole = rwtInfo.Role
				v.RoomWheatPosition = rwtInfo.Position
			}
		}
		if ownData != nil {
			ownData.RoomWheatPosition = -1 // 房间麦序从0开始，每个都需要赋值一下，默认不在麦序（-1）
			if rwtInfo, ok := roomInfo.WheatObjByUserId[ownData.UserId]; ok {
				ownData.RoomRole = rwtInfo.Role
				ownData.RoomWheatPosition = rwtInfo.Position
			}
		}
	}

	resp.List = data
	resp.Own = ownData

	if !useCache {
		queryCtrl.Save(resp.List)
	}

	return resp, "获取成功", nil
}
