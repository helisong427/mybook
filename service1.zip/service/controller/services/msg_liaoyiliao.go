package services

import (
	"fmt"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"strings"
)

type LiaoyiliaoMsg struct {
}

const (
	ASSISTANT_LIAOYILIAO_DAILY_MSG         = "assistant_liaoyiliao_daily_msg"         //撩一撩每日消息
	ASSISTANT_LIAOYILIAO_INVITE_MSG_REJECT = "assistant_liaoyiliao_invite_msg_reject" // 撩一撩邀请消息审核拒绝
)

// 撩一撩每日消息
func (s *LiaoyiliaoMsg) AssistantDailyMsg(userId int64) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_LIAOYILIAO_DAILY_MSG)
	if err != nil {
		utils.LogErrorF("获取开播消息消息model失败,err:%s", err.Error())
		return
	}
	assistantMsg := &redismodels.AssistantMsg{
		Type:       redismodels.MSG_ASSISTANT_TYPE_ACTION,
		ActionType: redismodels.MSG_ACTION_TYPE_LIAOYILIAO,
		Title:      msgModel.MsgTitle,
		Text:       msgModel.MsgContent,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, fmt.Sprint(userId))
	if err != nil {
		utils.LogErrorF("发送撩一撩每日消息推送失败,err:%s", err.Error())
	}
	return
}

// InviteMessageReject 撩一撩邀请消息审核不通过
func (s *LiaoyiliaoMsg) InviteMessageReject(userID string, reason string) (err error) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_LIAOYILIAO_INVITE_MSG_REJECT)
	if err != nil {
		utils.LogErrorF("获取撩一撩邀请消息审核不通过model失败: %v", err)
		return
	}
	text := strings.NewReplacer("${reason}", reason).Replace(msgModel.MsgContent)
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              text,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userID)
	if err != nil {
		utils.LogErrorF("发送撩一撩邀请消息审核不通过消息失败：%v", err)
		return
	}
	return
}
