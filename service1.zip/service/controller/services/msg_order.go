package services

import (
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"gamers/utils/chuanglan/sms"
	"strconv"
	"strings"
	"time"
)

// 订单消息，用户端
const (
	C2C_ORDER_USER_KEY_CONFIRM_WAIT_ACCEPT     = "c2c_order_user_confirm_wait_accept"     // 用户提交订单，大神待接单
	C2C_ORDER_USER_KEY_CONFIRM_TIMEOUT         = "c2c_order_user_confirm_timeout"         // 用户提交订单，大神超时未接单订单取消
	C2C_ORDER_USER_KEY_CONFIRM_REFUSE          = "c2c_order_user_confirm_refuse"          // 用户提交订单，大神拒绝接单
	C2C_ORDER_USER_KEY_CONFIRM_ACCEPT          = "c2c_order_user_confirm_accept"          // 用户提交订单，大神接单
	C2C_ORDER_USER_KEY_CONFIRM_SPARRING_FINISH = "c2c_order_user_confirm_sparring_finish" // 大神确认服务完成，但用户尚未确认服务完成
	C2C_ORDER_USER_KEY_FINISH_BY_USER          = "c2c_order_user_finish_by_user"          // 用户确认服务完成
	C2C_ORDER_USER_KEY_FINISH_BY_SYSTEM        = "c2c_order_user_finish_by_system"        // 倒计时结束服务自动完成
	C2C_ORDER_USER_KEY_REFUND_APPLY            = "c2c_order_user_refund_apply"            // 用户申请退款
	C2C_ORDER_USER_KEY_REFUND_OK_SPARRING      = "c2c_order_user_refund_ok_sparring"      // 大神同意退款
	C2C_ORDER_USER_KEY_REFUND_OK_SYSTEM        = "c2c_order_user_refund_ok_system"        // 大神未响应自动退款
	C2C_ORDER_USER_KEY_REFUND_REFUSE           = "c2c_order_user_refund_refuse"           // 大神拒绝退款
	C2C_ORDER_USER_KEY_APPEAL_OK_FOR_USER      = "c2c_order_user_appeal_ok_for_user"      // 申诉成功（全额退款）
	C2C_ORDER_USER_KEY_APPEAL_FAIL_FOR_USER    = "c2c_order_user_appeal_fail_for_user"    // 申诉失败
	C2C_ORDER_USER_KEY_SEND_COMMENT_MSG        = "c2c_order_user_key_send_comment_msg"    // 订单完成后发送评价消息
)

// 订单消息 大神端
const (
	C2C_ORDER_SPARRING_KEY_CONFIRM_WAIT_ACCEPT   = "c2c_order_sparring_confirm_wait_accept"   // 用户提交订单，大神待接单
	C2C_ORDER_SPARRING_KEY_CANCEL_USER           = "c2c_order_sparring_cancel_user"           // 用户提交订单，用户取消订单
	C2C_ORDER_SPARRING_KEY_CONFIRM_TIMEOUT       = "c2c_order_sparring_confirm_timeout"       // 用户提交订单，大神超时未接单订单取消
	C2C_ORDER_SPARRING_KEY_CONFIRM_ACCEPT        = "c2c_order_sparring_confirm_accept"        // 用户提交订单，大神接单
	C2C_ORDER_SPARRING_KEY_REFUND_APPLY          = "c2c_order_sparring_refund_apply"          // 用户申请退款
	C2C_ORDER_SPARRING_KEY_REFUND_OK_SPARRING    = "c2c_order_sparring_refund_ok_sparring"    // 大神同意退款
	C2C_ORDER_SPARRING_KEY_REFUND_OK_SYSTEM      = "c2c_order_sparring_refund_ok_system"      // 大神未响应自动退款
	C2C_ORDER_SPARRING_KEY_APPEAL_APPLY          = "c2c_order_sparring_appeal_apply"          // 用户申述
	C2C_ORDER_SPARRING_KEY_APPEAL_COMMIT_TIMEOUT = "c2c_order_sparring_appeal_commit_timeout" // 大神提交申述超时
)

// 订单消息
const (
	SYS_ORDER_KEY_CONFIRM_COMMIT               = "sys_order_sparring_confirm_commit"               // 订单提交
	SYS_ORDER_KEY_CONFIRM_REFUSE_FOR_USER      = "sys_order_sparring_confirm_refuse_for_user"      // 拒绝接单，对于用户
	SYS_ORDER_KEY_CONFIRM_REFUSE_FOR_SPARRING  = "sys_order_sparring_confirm_refuse_for_sparring"  // 拒绝接单，对于大神
	SYS_ORDER_KEY_CONFIRM_TIMEOUT_FOR_USER     = "sys_order_sparring_confirm_timeout_for_user"     // 接单超时，用户端
	SYS_ORDER_KEY_CONFIRM_TIMEOUT_FOR_SPARRING = "sys_order_sparring_confirm_timeout_for_sparring" // 接单超时，大神端
	SYS_ORDER_KEY_CANCEL_FOR_USER              = "sys_order_sparring_cancel_for_user"              // 取消订单，用户端
	SYS_ORDER_KEY_CANCEL_FOR_SPARRING          = "sys_order_sparring_cancel_for_sparring"          // 取消订单，大神端
)

// 等待接单,订单消息
func (c Confirm) OrderMsgConfirmWaitAccept(order *dbmodels.AppSkillOrder, userInfo *redismodels.UserInfo, sparring *dbmodels.AppSparringSkill) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(SYS_ORDER_KEY_CONFIRM_COMMIT)
	if err != nil {
		utils.LogErrorF("获取待接单订单消息model失败,err:%s", err.Error())
		return
	}
	orderMsg := &redismodels.SkillOrderMsg{
		OrderId:            order.OrderId,
		OrderStatus:        order.OrderStatus,
		OrderConfirmStatus: order.OrderConfirmStatus,
		Tips:               msgOrder.MsgContent,
		Remark:             order.OrderRemark,
		OrderTime:          order.OrderTime,
		OrderWay:           order.OrderWay,
		OrderCount:         order.OrderCount,
		OrderPrice:         order.OrderPrice,
		Countdown:          order.BaseModel.Created + dbmodels.SKILL_ORDER_ORDER_TIME - time.Now().Unix(),
		OrderAmount:        order.OrderAmount,
		BuyerInfo:          redismodels.OrderUserInfo{UserId: userInfo.UserID, Nickname: userInfo.UserNickname, Icon: userInfo.UserIconurl},
		Created:            order.BaseModel.Created,
		SkillInfo:          redismodels.OrderSkillInfo{Icon: sparring.AppSkill.SkillIconurl, Name: sparring.AppSkill.SkillName, SkillId: sparring.SkillSkillID},
		NotificationClose:  msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{OrderMsg: orderMsg}
	err = msg.OrderMsg.SendOrderMsg(redismodels.MSG_ADMIN_USER_ORDER, strconv.Itoa(int(order.OrderSellUserId)))
	if err != nil {
		utils.LogErrorF("发送订单消息推送失败,err:%s", err.Error())
	}
	return
}

// 等待接单,大神订单消息
func (c Confirm) SparringMsgConfirmWaitAccept(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(C2C_ORDER_SPARRING_KEY_CONFIRM_WAIT_ACCEPT)
	if err != nil {
		utils.LogErrorF("获取待接单订单消息model失败,err:%s", err.Error())
		return
	}
	orderInfo := &redismodels.C2cOrderInfo{
		OrderId:              order.OrderId,
		OrderSparringSkillId: order.OrderSparringSkillId,
		OrderStatus:          order.OrderStatus,
		OrderPayStatus:       order.OrderPayStatus,
		OrderSellUserId:      order.OrderSellUserId,
		OrderBuyUserId:       order.OrderBuyUserId,
		OrderCancelStatus:    order.OrderCancelStatus,
		OrderAppealStatus:    order.OrderAppealStatus,
		OrderCommentStatus:   order.OrderCommentStatus,
		OrderCount:           order.OrderCount,
		OrderFinishStatus:    order.OrderFinishStatus,
		OrderPrice:           order.OrderPrice,
		OrderRefundCount:     order.OrderRefundCount,
		OrderRefundStatus:    order.OrderRefundStatus,
		OrderConfirmStatus:   order.OrderConfirmStatus,
		OrderSettleStatus:    order.OrderSettleStatus,
		OrderSkillId:         order.OrderSkillId,
		OrderWay:             order.OrderWay,
		Countdown:            order.BaseModel.Created + dbmodels.SKILL_ORDER_ORDER_TIME - time.Now().Unix(),
		OrderAmount:          order.OrderAmount,
		Created:              order.BaseModel.Created,
		SkillInfo:            redismodels.OrderSkillInfo{Icon: order.AppSkill.SkillIconurl, Name: order.AppSkill.SkillName, SkillId: order.AppSkill.SkillId},
	}
	orderMsg := &redismodels.C2CMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_ACTION,
		Title:             msgOrder.MsgTitle,
		Text:              msgOrder.MsgContent,
		ActionType:        redismodels.MSG_ACTION_TYPE_SPARRING_ORDER_INFO,
		Action:            strconv.Itoa(int(order.OrderId)),
		ActionParams:      map[string]interface{}{"order_id": order.OrderId},
		OrderInfo:         orderInfo,
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{C2CMsg: orderMsg}
	err = msg.C2CMsg.SendC2CMsg(strconv.Itoa(int(order.OrderBuyUserId)), strconv.Itoa(int(order.OrderSellUserId)))
	if err != nil {
		utils.LogErrorF("发送订单消息推送失败,err:%s", err.Error())
	}
	if msgOrder.MsgSmsSend == dbmodels.MSG_SEND_SMS_YES {
		mobile, err := new(dbmodels.SystemUser).GetUserMobile(order.OrderSellUserId)
		if err != nil {
			utils.LogErrorF("发送用户申诉订单短信推送失败,获取用户手机号失败,err:%s", err.Error())
		}
		sms.SendModelSms(1, msgOrder.MsgSmsContent, mobile)
	}
	return
}

// 等待接单,用户订单消息
func (c Confirm) UserMsgConfirmWaitAccept(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(C2C_ORDER_USER_KEY_CONFIRM_WAIT_ACCEPT)
	if err != nil {
		utils.LogErrorF("获取待接单订单消息model失败,err:%s", err.Error())
		return
	}
	orderInfo := &redismodels.C2cOrderInfo{
		OrderId:              order.OrderId,
		OrderSparringSkillId: order.OrderSparringSkillId,
		OrderStatus:          order.OrderStatus,
		OrderPayStatus:       order.OrderPayStatus,
		OrderSellUserId:      order.OrderSellUserId,
		OrderBuyUserId:       order.OrderBuyUserId,
		OrderCancelStatus:    order.OrderCancelStatus,
		OrderAppealStatus:    order.OrderAppealStatus,
		OrderCommentStatus:   order.OrderCommentStatus,
		OrderCount:           order.OrderCount,
		OrderFinishStatus:    order.OrderFinishStatus,
		OrderPrice:           order.OrderPrice,
		OrderRefundCount:     order.OrderRefundCount,
		OrderRefundStatus:    order.OrderRefundStatus,
		OrderConfirmStatus:   order.OrderConfirmStatus,
		OrderSettleStatus:    order.OrderSettleStatus,
		OrderSkillId:         order.OrderSkillId,
		OrderWay:             order.OrderWay,
		Countdown:            order.BaseModel.Created + dbmodels.SKILL_ORDER_ORDER_TIME - time.Now().Unix(),
		OrderAmount:          order.OrderAmount,
		Created:              order.BaseModel.Created,
		SkillInfo:            redismodels.OrderSkillInfo{Icon: order.AppSkill.SkillIconurl, Name: order.AppSkill.SkillName, SkillId: order.AppSkill.SkillId},
	}
	// 私聊用户订单消息
	orderMsg := &redismodels.C2CMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgOrder.MsgTitle,
		Text:              msgOrder.MsgContent,
		OrderInfo:         orderInfo,
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{C2CMsg: orderMsg}
	err = msg.C2CMsg.SendC2CMsg(strconv.Itoa(int(order.OrderSellUserId)), strconv.Itoa(int(order.OrderBuyUserId)))
	if err != nil {
		utils.LogErrorF("发送订单消息推送失败,err:%s", err.Error())
	}
	return
}

// 拒绝接单,订单消息大神端
func (c Confirm) OrderSparringMsgConfirmRefuse(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(SYS_ORDER_KEY_CONFIRM_REFUSE_FOR_SPARRING)
	if err != nil {
		utils.LogErrorF("获取拒绝接单消息model失败,err:%s", err.Error())
		return
	}
	orderMsg := &redismodels.SkillOrderMsg{
		Tips:               msgOrder.MsgContent,
		OrderId:            order.OrderId,
		OrderStatus:        order.OrderStatus,
		OrderConfirmStatus: order.OrderConfirmStatus,
		NotificationClose:  msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{OrderMsg: orderMsg}
	err = msg.OrderMsg.SendOrderMsg(redismodels.MSG_ADMIN_USER_ORDER, strconv.Itoa(int(order.OrderSellUserId)))
	if err != nil {
		utils.LogErrorF("发送拒绝订单消息推送失败,err:%s", err.Error())
	}
	return
}

// 拒绝接单，订单消息用户端
func (c Confirm) OrderUserMsgConfirmRefuse(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(SYS_ORDER_KEY_CONFIRM_REFUSE_FOR_USER)
	if err != nil {
		utils.LogErrorF("获取拒绝接单消息model失败,err:%s", err.Error())
		return
	}
	amount := order.OrderAmount / 100
	tip := strings.NewReplacer("${order_amount}", strconv.Itoa(int(amount))).Replace(msgOrder.MsgContent)
	orderMsg := &redismodels.SkillOrderMsg{
		Tips:              tip,
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{OrderMsg: orderMsg}
	err = msg.OrderMsg.SendOrderMsg(redismodels.MSG_ADMIN_USER_ORDER, strconv.Itoa(int(order.OrderBuyUserId)))
	if err != nil {
		utils.LogErrorF("发送拒绝订单消息推送失败,err:%s", err.Error())
	}
	return
}

// 拒绝接单，私聊消息用户
func (c Confirm) UserMsgConfirmRefuse(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(C2C_ORDER_USER_KEY_CONFIRM_REFUSE)
	if err != nil {
		utils.LogErrorF("获取拒绝接单消息model失败,err:%s", err.Error())
		return
	}
	orderInfo := &redismodels.C2cOrderInfo{
		OrderId:              order.OrderId,
		OrderSparringSkillId: order.OrderSparringSkillId,
		OrderStatus:          order.OrderStatus,
		OrderPayStatus:       order.OrderPayStatus,
		OrderSellUserId:      order.OrderSellUserId,
		OrderBuyUserId:       order.OrderBuyUserId,
		OrderCancelStatus:    order.OrderCancelStatus,
		OrderAppealStatus:    order.OrderAppealStatus,
		OrderCommentStatus:   order.OrderCommentStatus,
		OrderCount:           order.OrderCount,
		OrderFinishStatus:    order.OrderFinishStatus,
		OrderPrice:           order.OrderPrice,
		OrderRefundCount:     order.OrderRefundCount,
		OrderRefundStatus:    order.OrderRefundStatus,
		OrderConfirmStatus:   order.OrderConfirmStatus,
		OrderSettleStatus:    order.OrderSettleStatus,
		OrderSkillId:         order.OrderSkillId,
		OrderWay:             order.OrderWay,
		OrderAmount:          order.OrderAmount,
		Created:              order.BaseModel.Created,
		SkillInfo:            redismodels.OrderSkillInfo{Icon: order.AppSkill.SkillIconurl, Name: order.AppSkill.SkillName, SkillId: order.AppSkill.SkillId},
	}
	orderMsg := &redismodels.C2CMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgOrder.MsgTitle,
		Text:              msgOrder.MsgContent,
		OrderInfo:         orderInfo,
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{C2CMsg: orderMsg}
	err = msg.C2CMsg.SendC2CMsg(strconv.Itoa(int(order.OrderSellUserId)), strconv.Itoa(int(order.OrderBuyUserId)))
	if err != nil {
		utils.LogErrorF("发送拒绝订单消息推送失败,err:%s", err.Error())
	}
	return
}

// 大神完成订单
func (c Confirm) UserMsgConfirmFinish(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(C2C_ORDER_USER_KEY_CONFIRM_SPARRING_FINISH)
	if err != nil {
		utils.LogErrorF("获取大神完成订单消息model失败,err:%s", err.Error())
		return
	}
	orderInfo := &redismodels.C2cOrderInfo{
		OrderId:              order.OrderId,
		OrderSparringSkillId: order.OrderSparringSkillId,
		OrderStatus:          order.OrderStatus,
		OrderPayStatus:       order.OrderPayStatus,
		OrderSellUserId:      order.OrderSellUserId,
		OrderBuyUserId:       order.OrderBuyUserId,
		OrderCancelStatus:    order.OrderCancelStatus,
		OrderAppealStatus:    order.OrderAppealStatus,
		OrderCommentStatus:   order.OrderCommentStatus,
		OrderCount:           order.OrderCount,
		OrderFinishStatus:    order.OrderFinishStatus,
		OrderPrice:           order.OrderPrice,
		OrderRefundCount:     order.OrderRefundCount,
		OrderRefundStatus:    order.OrderRefundStatus,
		OrderConfirmStatus:   order.OrderConfirmStatus,
		OrderSettleStatus:    order.OrderSettleStatus,
		OrderSkillId:         order.OrderSkillId,
		OrderWay:             order.OrderWay,
		OrderAmount:          order.OrderAmount,
		Created:              order.BaseModel.Created,
		SkillInfo:            redismodels.OrderSkillInfo{Icon: order.AppSkill.SkillIconurl, Name: order.AppSkill.SkillName, SkillId: order.AppSkill.SkillId},
	}
	orderMsg := &redismodels.C2CMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgOrder.MsgTitle,
		Text:              msgOrder.MsgContent,
		OrderInfo:         orderInfo,
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{C2CMsg: orderMsg}
	err = msg.C2CMsg.SendC2CMsg(strconv.Itoa(int(order.OrderSellUserId)), strconv.Itoa(int(order.OrderBuyUserId)))
	if err != nil {
		utils.LogErrorF("发送大神完成订单消息推送失败,err:%s", err.Error())
	}
	return
}

// 大神接单，用户端消息
func (c Confirm) UserMsgConfirmAccept(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(C2C_ORDER_USER_KEY_CONFIRM_ACCEPT)
	if err != nil {
		utils.LogErrorF("获取接单消息model失败,err:%s", err.Error())
		return
	}
	param, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_SERVICE_QQ)
	if err != nil {
		utils.LogErrorF("获取客服qq出错,err:%s", err.Error())
	}
	tip := strings.NewReplacer("${qq}", param["value"]).Replace(msgOrder.MsgContent)
	orderInfo := &redismodels.C2cOrderInfo{
		OrderId:              order.OrderId,
		OrderSparringSkillId: order.OrderSparringSkillId,
		OrderStatus:          order.OrderStatus,
		OrderPayStatus:       order.OrderPayStatus,
		OrderSellUserId:      order.OrderSellUserId,
		OrderBuyUserId:       order.OrderBuyUserId,
		OrderCancelStatus:    order.OrderCancelStatus,
		OrderAppealStatus:    order.OrderAppealStatus,
		OrderCommentStatus:   order.OrderCommentStatus,
		OrderCount:           order.OrderCount,
		OrderFinishStatus:    order.OrderFinishStatus,
		OrderPrice:           order.OrderPrice,
		OrderRefundCount:     order.OrderRefundCount,
		OrderRefundStatus:    order.OrderRefundStatus,
		OrderConfirmStatus:   order.OrderConfirmStatus,
		OrderSettleStatus:    order.OrderSettleStatus,
		OrderSkillId:         order.OrderSkillId,
		OrderWay:             order.OrderWay,
		OrderAmount:          order.OrderAmount,
		Created:              order.BaseModel.Created,
		SkillInfo:            redismodels.OrderSkillInfo{Icon: order.AppSkill.SkillIconurl, Name: order.AppSkill.SkillName, SkillId: order.AppSkill.SkillId},
	}
	orderMsg := &redismodels.C2CMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgOrder.MsgTitle,
		Text:              tip,
		OrderInfo:         orderInfo,
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{C2CMsg: orderMsg}
	err = msg.C2CMsg.SendC2CMsg(strconv.Itoa(int(order.OrderSellUserId)), strconv.Itoa(int(order.OrderBuyUserId)))
	if err != nil {
		utils.LogErrorF("发送私聊接单消息推送失败,err:%s", err.Error())
	}
	return
}

// 大神接单，大神端消息
func (c Confirm) SparringMsgConfirmAccept(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(C2C_ORDER_SPARRING_KEY_CONFIRM_ACCEPT)
	if err != nil {
		utils.LogErrorF("获取接单消息model失败,err:%s", err.Error())
		return
	}
	orderInfo := &redismodels.C2cOrderInfo{
		OrderId:              order.OrderId,
		OrderSparringSkillId: order.OrderSparringSkillId,
		OrderStatus:          order.OrderStatus,
		OrderPayStatus:       order.OrderPayStatus,
		OrderSellUserId:      order.OrderSellUserId,
		OrderBuyUserId:       order.OrderBuyUserId,
		OrderCancelStatus:    order.OrderCancelStatus,
		OrderAppealStatus:    order.OrderAppealStatus,
		OrderCommentStatus:   order.OrderCommentStatus,
		OrderCount:           order.OrderCount,
		OrderFinishStatus:    order.OrderFinishStatus,
		OrderPrice:           order.OrderPrice,
		OrderRefundCount:     order.OrderRefundCount,
		OrderRefundStatus:    order.OrderRefundStatus,
		OrderConfirmStatus:   order.OrderConfirmStatus,
		OrderSettleStatus:    order.OrderSettleStatus,
		OrderSkillId:         order.OrderSkillId,
		OrderWay:             order.OrderWay,
		OrderAmount:          order.OrderAmount,
		Created:              order.BaseModel.Created,
		SkillInfo:            redismodels.OrderSkillInfo{Icon: order.AppSkill.SkillIconurl, Name: order.AppSkill.SkillName, SkillId: order.AppSkill.SkillId},
	}
	orderMsg := &redismodels.C2CMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_ACTION,
		Title:             msgOrder.MsgTitle,
		Text:              msgOrder.MsgContent,
		ActionType:        redismodels.MSG_ACTION_TYPE_SPARRING_ORDER_INFO,
		Action:            strconv.Itoa(int(order.OrderId)),
		ActionParams:      map[string]interface{}{"order_id": order.OrderId},
		OrderInfo:         orderInfo,
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{C2CMsg: orderMsg}
	err = msg.C2CMsg.SendC2CMsg(strconv.Itoa(int(order.OrderBuyUserId)), strconv.Itoa(int(order.OrderSellUserId)))
	if err != nil {
		utils.LogErrorF("发送拒绝订单消息推送失败,err:%s", err.Error())
	}
	return
}

// 接单超时，订单消息大神
func (c Confirm) OrderSparringMsgConfirmTimeout(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(SYS_ORDER_KEY_CONFIRM_TIMEOUT_FOR_SPARRING)
	if err != nil {
		utils.LogErrorF("获取超时接单消息model失败,err:%s", err.Error())
		return
	}
	orderMsg := &redismodels.SkillOrderMsg{
		Tips:              msgOrder.MsgContent,
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{OrderMsg: orderMsg}
	err = msg.OrderMsg.SendOrderMsg(redismodels.MSG_ADMIN_USER_ORDER, strconv.Itoa(int(order.OrderSellUserId)))
	if err != nil {
		utils.LogErrorF("发送超时接单消息推送失败,err:%s", err.Error())
	}
	return
}

// 接单超时，订单消息用户端
func (c Confirm) OrderUserMsgConfirmTimeout(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(SYS_ORDER_KEY_CONFIRM_TIMEOUT_FOR_USER)
	if err != nil {
		utils.LogErrorF("获取超时接单消息model失败,err:%s", err.Error())
		return
	}
	amount := order.OrderAmount / 100
	tip := strings.NewReplacer("${order_amount}", strconv.Itoa(int(amount))).Replace(msgOrder.MsgContent)
	orderMsg := &redismodels.SkillOrderMsg{
		Tips:              tip,
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{OrderMsg: orderMsg}
	err = msg.OrderMsg.SendOrderMsg(redismodels.MSG_ADMIN_USER_ORDER, strconv.Itoa(int(order.OrderBuyUserId)))
	if err != nil {
		utils.LogErrorF("发送超时订单消息推送失败,err:%s", err.Error())
	}
	return
}

// 超时接单,私聊消息大神端
func (c Confirm) SparringMsgConfirmTimeout(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(C2C_ORDER_SPARRING_KEY_CONFIRM_TIMEOUT)
	if err != nil {
		utils.LogErrorF("获取超时接单消息model失败,err:%s", err.Error())
		return
	}
	orderInfo := &redismodels.C2cOrderInfo{
		OrderId:              order.OrderId,
		OrderSparringSkillId: order.OrderSparringSkillId,
		OrderStatus:          order.OrderStatus,
		OrderPayStatus:       order.OrderPayStatus,
		OrderSellUserId:      order.OrderSellUserId,
		OrderBuyUserId:       order.OrderBuyUserId,
		OrderCancelStatus:    order.OrderCancelStatus,
		OrderAppealStatus:    order.OrderAppealStatus,
		OrderCommentStatus:   order.OrderCommentStatus,
		OrderCount:           order.OrderCount,
		OrderFinishStatus:    order.OrderFinishStatus,
		OrderPrice:           order.OrderPrice,
		OrderRefundCount:     order.OrderRefundCount,
		OrderRefundStatus:    order.OrderRefundStatus,
		OrderConfirmStatus:   order.OrderConfirmStatus,
		OrderSettleStatus:    order.OrderSettleStatus,
		OrderSkillId:         order.OrderSkillId,
		OrderWay:             order.OrderWay,
		OrderAmount:          order.OrderAmount,
		Created:              order.BaseModel.Created,
		SkillInfo:            redismodels.OrderSkillInfo{Icon: order.AppSkill.SkillIconurl, Name: order.AppSkill.SkillName, SkillId: order.AppSkill.SkillId},
	}
	orderMsg := &redismodels.C2CMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgOrder.MsgTitle,
		Text:              msgOrder.MsgContent,
		OrderInfo:         orderInfo,
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{C2CMsg: orderMsg}
	err = msg.C2CMsg.SendC2CMsg(strconv.Itoa(int(order.OrderBuyUserId)), strconv.Itoa(int(order.OrderSellUserId)))
	if err != nil {
		utils.LogErrorF("发送超时订单消息推送失败,err:%s", err.Error())
	}
	return
}

// 超时接单，私聊消息用户端
func (c Confirm) UserMsgConfirmTimeout(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(C2C_ORDER_USER_KEY_CONFIRM_TIMEOUT)
	if err != nil {
		utils.LogErrorF("获取超时接单消息model失败,err:%s", err.Error())
		return
	}
	orderInfo := &redismodels.C2cOrderInfo{
		OrderId:              order.OrderId,
		OrderSparringSkillId: order.OrderSparringSkillId,
		OrderStatus:          order.OrderStatus,
		OrderPayStatus:       order.OrderPayStatus,
		OrderSellUserId:      order.OrderSellUserId,
		OrderBuyUserId:       order.OrderBuyUserId,
		OrderCancelStatus:    order.OrderCancelStatus,
		OrderAppealStatus:    order.OrderAppealStatus,
		OrderCommentStatus:   order.OrderCommentStatus,
		OrderCount:           order.OrderCount,
		OrderFinishStatus:    order.OrderFinishStatus,
		OrderPrice:           order.OrderPrice,
		OrderRefundCount:     order.OrderRefundCount,
		OrderRefundStatus:    order.OrderRefundStatus,
		OrderConfirmStatus:   order.OrderConfirmStatus,
		OrderSettleStatus:    order.OrderSettleStatus,
		OrderSkillId:         order.OrderSkillId,
		OrderWay:             order.OrderWay,
		OrderAmount:          order.OrderAmount,
		Created:              order.BaseModel.Created,
		SkillInfo:            redismodels.OrderSkillInfo{Icon: order.AppSkill.SkillIconurl, Name: order.AppSkill.SkillName, SkillId: order.AppSkill.SkillId},
	}
	orderMsg := &redismodels.C2CMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgOrder.MsgTitle,
		Text:              msgOrder.MsgContent,
		OrderInfo:         orderInfo,
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{C2CMsg: orderMsg}
	err = msg.C2CMsg.SendC2CMsg(strconv.Itoa(int(order.OrderSellUserId)), strconv.Itoa(int(order.OrderBuyUserId)))
	if err != nil {
		utils.LogErrorF("发送超时订单消息推送失败,err:%s", err.Error())
	}
	return
}

// 用户取消订单,私聊大神
func (c Cancel) SparringCancelCancel(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(C2C_ORDER_SPARRING_KEY_CANCEL_USER)
	if err != nil {
		utils.LogErrorF("获取取消订单消息model失败,err:%s", err.Error())
		return
	}
	orderInfo := &redismodels.C2cOrderInfo{
		OrderId:              order.OrderId,
		OrderSparringSkillId: order.OrderSparringSkillId,
		OrderStatus:          order.OrderStatus,
		OrderPayStatus:       order.OrderPayStatus,
		OrderSellUserId:      order.OrderSellUserId,
		OrderBuyUserId:       order.OrderBuyUserId,
		OrderCancelStatus:    order.OrderCancelStatus,
		OrderAppealStatus:    order.OrderAppealStatus,
		OrderCommentStatus:   order.OrderCommentStatus,
		OrderCount:           order.OrderCount,
		OrderFinishStatus:    order.OrderFinishStatus,
		OrderPrice:           order.OrderPrice,
		OrderRefundCount:     order.OrderRefundCount,
		OrderRefundStatus:    order.OrderRefundStatus,
		OrderConfirmStatus:   order.OrderConfirmStatus,
		OrderSettleStatus:    order.OrderSettleStatus,
		OrderSkillId:         order.OrderSkillId,
		OrderWay:             order.OrderWay,
		OrderAmount:          order.OrderAmount,
		Created:              order.BaseModel.Created,
		SkillInfo:            redismodels.OrderSkillInfo{Icon: order.AppSkill.SkillIconurl, Name: order.AppSkill.SkillName, SkillId: order.AppSkill.SkillId},
	}
	orderMsg := &redismodels.C2CMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgOrder.MsgTitle,
		Text:              msgOrder.MsgContent,
		OrderInfo:         orderInfo,
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{C2CMsg: orderMsg}
	err = msg.C2CMsg.SendC2CMsg(strconv.Itoa(int(order.OrderBuyUserId)), strconv.Itoa(int(order.OrderSellUserId)))
	if err != nil {
		utils.LogErrorF("发送取消订单消息推送失败,err:%s", err.Error())
	}
	return
}

// 用户取消订单，订单消息大神端
func (c Cancel) OrderSparringMsgCancelCancel(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(SYS_ORDER_KEY_CANCEL_FOR_SPARRING)
	if err != nil {
		utils.LogErrorF("获取超时接单消息model失败,err:%s", err.Error())
		return
	}
	orderMsg := &redismodels.SkillOrderMsg{
		Tips:              msgOrder.MsgContent,
		OrderId:           order.OrderId,
		OrderStatus:       order.OrderStatus,
		OrderCancelStatus: order.OrderCancelStatus,
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{OrderMsg: orderMsg}
	err = msg.OrderMsg.SendOrderMsg(redismodels.MSG_ADMIN_USER_ORDER, strconv.Itoa(int(order.OrderSellUserId)))
	if err != nil {
		utils.LogErrorF("发送超时接单消息推送失败,err:%s", err.Error())
	}
	return
}

// 用户取消订单，订单消息用户端
func (c Cancel) OrderUserMsgCancelCancel(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(SYS_ORDER_KEY_CANCEL_FOR_USER)
	if err != nil {
		utils.LogErrorF("获取超时接单消息model失败,err:%s", err.Error())
		return
	}
	amount := order.OrderAmount / 100
	tip := strings.NewReplacer("${order_amount}", strconv.Itoa(int(amount))).Replace(msgOrder.MsgContent)
	orderMsg := &redismodels.SkillOrderMsg{
		Tips:              tip,
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{OrderMsg: orderMsg}
	err = msg.OrderMsg.SendOrderMsg(redismodels.MSG_ADMIN_USER_ORDER, strconv.Itoa(int(order.OrderBuyUserId)))
	if err != nil {
		utils.LogErrorF("发送超时接单消息推送失败,err:%s", err.Error())
	}
	return
}

// 用户完成订单 ,私聊用户
func (f Finish) UserFinishByUser(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(C2C_ORDER_USER_KEY_FINISH_BY_USER)
	if err != nil {
		utils.LogErrorF("获取完成订单消息model失败,err:%s", err.Error())
		return
	}
	param, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_SERVICE_QQ)
	if err != nil {
		utils.LogErrorF("获取客服qq出错,err:%s", err.Error())
	}
	tip := strings.NewReplacer("${qq}", param["value"]).Replace(msgOrder.MsgContent)
	orderInfo := &redismodels.C2cOrderInfo{
		OrderId:              order.OrderId,
		OrderSparringSkillId: order.OrderSparringSkillId,
		OrderStatus:          order.OrderStatus,
		OrderPayStatus:       order.OrderPayStatus,
		OrderSellUserId:      order.OrderSellUserId,
		OrderBuyUserId:       order.OrderBuyUserId,
		OrderCancelStatus:    order.OrderCancelStatus,
		OrderAppealStatus:    order.OrderAppealStatus,
		OrderCommentStatus:   order.OrderCommentStatus,
		OrderCount:           order.OrderCount,
		OrderFinishStatus:    order.OrderFinishStatus,
		OrderPrice:           order.OrderPrice,
		OrderRefundCount:     order.OrderRefundCount,
		OrderRefundStatus:    order.OrderRefundStatus,
		OrderConfirmStatus:   order.OrderConfirmStatus,
		OrderSettleStatus:    order.OrderSettleStatus,
		OrderSkillId:         order.OrderSkillId,
		OrderWay:             order.OrderWay,
		OrderAmount:          order.OrderAmount,
		Created:              order.BaseModel.Created,
		SkillInfo:            redismodels.OrderSkillInfo{Icon: order.AppSkill.SkillIconurl, Name: order.AppSkill.SkillName, SkillId: order.AppSkill.SkillId},
	}
	orderMsg := &redismodels.C2CMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgOrder.MsgTitle,
		Text:              tip,
		OrderInfo:         orderInfo,
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{C2CMsg: orderMsg}
	err = msg.C2CMsg.SendC2CMsg(strconv.Itoa(int(order.OrderSellUserId)), strconv.Itoa(int(order.OrderBuyUserId)))
	if err != nil {
		utils.LogErrorF("发送完成消息推送失败,err:%s", err.Error())
	}
	return
}

// 用户完成订单 发送订单评价消息
func (f Finish) SendCommendMsgByUser(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(C2C_ORDER_USER_KEY_SEND_COMMENT_MSG)
	if err != nil {
		utils.LogErrorF("获取完成订单评价model失败,err:%s", err.Error())
		return
	}
	orderInfo := &redismodels.C2cOrderInfo{
		OrderId:              order.OrderId,
		OrderSparringSkillId: order.OrderSparringSkillId,
		OrderStatus:          order.OrderStatus,
		OrderPayStatus:       order.OrderPayStatus,
		OrderSellUserId:      order.OrderSellUserId,
		OrderBuyUserId:       order.OrderBuyUserId,
		OrderCancelStatus:    order.OrderCancelStatus,
		OrderAppealStatus:    order.OrderAppealStatus,
		OrderCommentStatus:   order.OrderCommentStatus,
		OrderCount:           order.OrderCount,
		OrderFinishStatus:    order.OrderFinishStatus,
		OrderPrice:           order.OrderPrice,
		OrderRefundCount:     order.OrderRefundCount,
		OrderRefundStatus:    order.OrderRefundStatus,
		OrderConfirmStatus:   order.OrderConfirmStatus,
		OrderSettleStatus:    order.OrderSettleStatus,
		OrderSkillId:         order.OrderSkillId,
		OrderWay:             order.OrderWay,
		OrderAmount:          order.OrderAmount,
		Created:              order.BaseModel.Created,
		SkillInfo:            redismodels.OrderSkillInfo{Icon: order.AppSkill.SkillIconurl, Name: order.AppSkill.SkillName, SkillId: order.AppSkill.SkillId},
	}
	//strMap := make(map[string]interface{})
	//strMap["order_id"] = orderInfo.OrderId
	orderMsg := &redismodels.C2CMsg{
		Type:  redismodels.MSG_ASSISTANT_TYPE_COMMENT,
		Title: msgOrder.MsgTitle,
		Text:  msgOrder.MsgContent,
		//ActionParams: strMap,
		OrderInfo: orderInfo,
	}
	msg := &redismodels.AppMsg{C2CMsg: orderMsg}
	err = msg.C2CMsg.SendC2CMsg(strconv.Itoa(int(order.OrderSellUserId)), strconv.Itoa(int(order.OrderBuyUserId)))
	if err != nil {
		utils.LogErrorF("发送完成消息推送失败,err:%s", err.Error())
	}
	return

}

// 系统自动完成订单
func (f Finish) UserFinishBySys(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(C2C_ORDER_USER_KEY_FINISH_BY_SYSTEM)
	if err != nil {
		utils.LogErrorF("获取自动完成订单消息model失败,err:%s", err.Error())
		return
	}
	orderInfo := &redismodels.C2cOrderInfo{
		OrderId:              order.OrderId,
		OrderSparringSkillId: order.OrderSparringSkillId,
		OrderStatus:          order.OrderStatus,
		OrderPayStatus:       order.OrderPayStatus,
		OrderSellUserId:      order.OrderSellUserId,
		OrderBuyUserId:       order.OrderBuyUserId,
		OrderCancelStatus:    order.OrderCancelStatus,
		OrderAppealStatus:    order.OrderAppealStatus,
		OrderCommentStatus:   order.OrderCommentStatus,
		OrderCount:           order.OrderCount,
		OrderFinishStatus:    order.OrderFinishStatus,
		OrderPrice:           order.OrderPrice,
		OrderRefundCount:     order.OrderRefundCount,
		OrderRefundStatus:    order.OrderRefundStatus,
		OrderConfirmStatus:   order.OrderConfirmStatus,
		OrderSettleStatus:    order.OrderSettleStatus,
		OrderSkillId:         order.OrderSkillId,
		OrderWay:             order.OrderWay,
		OrderAmount:          order.OrderAmount,
		Created:              order.BaseModel.Created,
		SkillInfo:            redismodels.OrderSkillInfo{Icon: order.AppSkill.SkillIconurl, Name: order.AppSkill.SkillName, SkillId: order.AppSkill.SkillId},
	}
	orderMsg := &redismodels.C2CMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_ACTION,
		ActionType:        redismodels.MSG_ACTION_TYPE_USER_ORDER_INFO,
		Action:            strconv.Itoa(int(order.OrderId)),
		ActionStyle:       redismodels.ActionStyle{Start: msgOrder.MsgActionStart, End: msgOrder.MsgActionEnd, Color: msgOrder.MsgColor},
		Title:             msgOrder.MsgTitle,
		Text:              msgOrder.MsgContent,
		ActionParams:      map[string]interface{}{"order_id": order.OrderId},
		OrderInfo:         orderInfo,
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{C2CMsg: orderMsg}
	err = msg.C2CMsg.SendC2CMsg(strconv.Itoa(int(order.OrderSellUserId)), strconv.Itoa(int(order.OrderBuyUserId)))
	if err != nil {
		utils.LogErrorF("发送自动完成消息推送失败,err:%s", err.Error())
	}
	return
}

// 用户申请退款，用户端消息
func (r Refund) UserRefundApply(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(C2C_ORDER_USER_KEY_REFUND_APPLY)
	if err != nil {
		utils.LogErrorF("获取完成订单消息model失败,err:%s", err.Error())
		return
	}
	orderInfo := &redismodels.C2cOrderInfo{
		OrderId:              order.OrderId,
		OrderSparringSkillId: order.OrderSparringSkillId,
		OrderStatus:          order.OrderStatus,
		OrderPayStatus:       order.OrderPayStatus,
		OrderSellUserId:      order.OrderSellUserId,
		OrderBuyUserId:       order.OrderBuyUserId,
		OrderCancelStatus:    order.OrderCancelStatus,
		OrderAppealStatus:    order.OrderAppealStatus,
		OrderCommentStatus:   order.OrderCommentStatus,
		OrderCount:           order.OrderCount,
		OrderFinishStatus:    order.OrderFinishStatus,
		OrderPrice:           order.OrderPrice,
		OrderRefundCount:     order.OrderRefundCount,
		OrderRefundStatus:    order.OrderRefundStatus,
		OrderConfirmStatus:   order.OrderConfirmStatus,
		OrderSettleStatus:    order.OrderSettleStatus,
		OrderSkillId:         order.OrderSkillId,
		OrderWay:             order.OrderWay,
		OrderAmount:          order.OrderAmount,
		Created:              order.BaseModel.Created,
		SkillInfo:            redismodels.OrderSkillInfo{Icon: order.AppSkill.SkillIconurl, Name: order.AppSkill.SkillName, SkillId: order.AppSkill.SkillId},
	}
	orderMsg := &redismodels.C2CMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgOrder.MsgTitle,
		Text:              msgOrder.MsgContent,
		OrderInfo:         orderInfo,
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{C2CMsg: orderMsg}
	err = msg.C2CMsg.SendC2CMsg(strconv.Itoa(int(order.OrderSellUserId)), strconv.Itoa(int(order.OrderBuyUserId)))
	if err != nil {
		utils.LogErrorF("发送完成消息推送失败,err:%s", err.Error())
	}
	return
}

// 用户申请退款，大神端消息
func (c Refund) SparringRefundApply(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(C2C_ORDER_SPARRING_KEY_REFUND_APPLY)
	if err != nil {
		utils.LogErrorF("获取取消订单消息model失败,err:%s", err.Error())
		return
	}
	orderInfo := &redismodels.C2cOrderInfo{
		OrderId:              order.OrderId,
		OrderSparringSkillId: order.OrderSparringSkillId,
		OrderStatus:          order.OrderStatus,
		OrderPayStatus:       order.OrderPayStatus,
		OrderSellUserId:      order.OrderSellUserId,
		OrderBuyUserId:       order.OrderBuyUserId,
		OrderCancelStatus:    order.OrderCancelStatus,
		OrderAppealStatus:    order.OrderAppealStatus,
		OrderCommentStatus:   order.OrderCommentStatus,
		OrderCount:           order.OrderCount,
		OrderFinishStatus:    order.OrderFinishStatus,
		OrderPrice:           order.OrderPrice,
		OrderRefundCount:     order.OrderRefundCount,
		OrderRefundStatus:    order.OrderRefundStatus,
		OrderConfirmStatus:   order.OrderConfirmStatus,
		OrderSettleStatus:    order.OrderSettleStatus,
		OrderSkillId:         order.OrderSkillId,
		OrderWay:             order.OrderWay,
		OrderAmount:          order.OrderAmount,
		Created:              order.BaseModel.Created,
		SkillInfo:            redismodels.OrderSkillInfo{Icon: order.AppSkill.SkillIconurl, Name: order.AppSkill.SkillName, SkillId: order.AppSkill.SkillId},
	}
	orderMsg := &redismodels.C2CMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgOrder.MsgTitle,
		Text:              msgOrder.MsgContent,
		OrderInfo:         orderInfo,
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{C2CMsg: orderMsg}
	err = msg.C2CMsg.SendC2CMsg(strconv.Itoa(int(order.OrderBuyUserId)), strconv.Itoa(int(order.OrderSellUserId)))
	if err != nil {
		utils.LogErrorF("发送取消订单消息推送失败,err:%s", err.Error())
	}
	if msgOrder.MsgSmsSend == dbmodels.MSG_SEND_SMS_YES {
		mobile, err := new(dbmodels.SystemUser).GetUserMobile(order.OrderSellUserId)
		if err != nil {
			utils.LogErrorF("发送用户取消订单短信推送失败,获取用户手机号失败,err:%s", err.Error())
		}
		sms.SendModelSms(1, msgOrder.MsgSmsContent, mobile)
	}
	return
}

// 同意退款，大神端消息
func (c Refund) SparringRefundSure(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(C2C_ORDER_SPARRING_KEY_REFUND_OK_SPARRING)
	if err != nil {
		utils.LogErrorF("获取同意退款订单消息model失败,err:%s", err.Error())
		return
	}
	amount := order.OrderAmount / 100
	tip := strings.NewReplacer("${order_amount}", strconv.Itoa(int(amount))).Replace(msgOrder.MsgContent)
	orderInfo := &redismodels.C2cOrderInfo{
		OrderId:              order.OrderId,
		OrderSparringSkillId: order.OrderSparringSkillId,
		OrderStatus:          order.OrderStatus,
		OrderPayStatus:       order.OrderPayStatus,
		OrderSellUserId:      order.OrderSellUserId,
		OrderBuyUserId:       order.OrderBuyUserId,
		OrderCancelStatus:    order.OrderCancelStatus,
		OrderAppealStatus:    order.OrderAppealStatus,
		OrderCommentStatus:   order.OrderCommentStatus,
		OrderCount:           order.OrderCount,
		OrderFinishStatus:    order.OrderFinishStatus,
		OrderPrice:           order.OrderPrice,
		OrderRefundCount:     order.OrderRefundCount,
		OrderRefundStatus:    order.OrderRefundStatus,
		OrderConfirmStatus:   order.OrderConfirmStatus,
		OrderSettleStatus:    order.OrderSettleStatus,
		OrderSkillId:         order.OrderSkillId,
		OrderWay:             order.OrderWay,
		OrderAmount:          order.OrderAmount,
		Created:              order.BaseModel.Created,
		SkillInfo:            redismodels.OrderSkillInfo{Icon: order.AppSkill.SkillIconurl, Name: order.AppSkill.SkillName, SkillId: order.AppSkill.SkillId},
	}
	orderMsg := &redismodels.C2CMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_ACTION,
		ActionType:        redismodels.MSG_ACTION_TYPE_SPARRING_ORDER_INFO,
		Title:             msgOrder.MsgTitle,
		Text:              tip,
		OrderInfo:         orderInfo,
		Action:            strconv.Itoa(int(order.OrderId)),
		ActionParams:      map[string]interface{}{"order_id": order.OrderId},
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{C2CMsg: orderMsg}
	err = msg.C2CMsg.SendC2CMsg(strconv.Itoa(int(order.OrderBuyUserId)), strconv.Itoa(int(order.OrderSellUserId)))
	if err != nil {
		utils.LogErrorF("发送同意退款订单消息推送失败,err:%s", err.Error())
	}
	return
}

// 同意退款，用户端消息
func (r Refund) UserRefundSure(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(C2C_ORDER_USER_KEY_REFUND_OK_SPARRING)
	if err != nil {
		utils.LogErrorF("获取同意退款消息model失败,err:%s", err.Error())
		return
	}
	amount := order.OrderAmount / 100
	tip := strings.NewReplacer("${order_amount}", strconv.Itoa(int(amount))).Replace(msgOrder.MsgContent)
	orderInfo := &redismodels.C2cOrderInfo{
		OrderId:              order.OrderId,
		OrderSparringSkillId: order.OrderSparringSkillId,
		OrderStatus:          order.OrderStatus,
		OrderPayStatus:       order.OrderPayStatus,
		OrderSellUserId:      order.OrderSellUserId,
		OrderBuyUserId:       order.OrderBuyUserId,
		OrderCancelStatus:    order.OrderCancelStatus,
		OrderAppealStatus:    order.OrderAppealStatus,
		OrderCommentStatus:   order.OrderCommentStatus,
		OrderCount:           order.OrderCount,
		OrderFinishStatus:    order.OrderFinishStatus,
		OrderPrice:           order.OrderPrice,
		OrderRefundCount:     order.OrderRefundCount,
		OrderRefundStatus:    order.OrderRefundStatus,
		OrderConfirmStatus:   order.OrderConfirmStatus,
		OrderSettleStatus:    order.OrderSettleStatus,
		OrderSkillId:         order.OrderSkillId,
		OrderWay:             order.OrderWay,
		OrderAmount:          order.OrderAmount,
		Created:              order.BaseModel.Created,
		SkillInfo:            redismodels.OrderSkillInfo{Icon: order.AppSkill.SkillIconurl, Name: order.AppSkill.SkillName, SkillId: order.AppSkill.SkillId},
	}
	orderMsg := &redismodels.C2CMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_ACTION,
		ActionType:        redismodels.MSG_ACTION_TYPE_USER_ORDER_INFO,
		Title:             msgOrder.MsgTitle,
		Text:              tip,
		Action:            strconv.Itoa(int(order.OrderId)),
		ActionParams:      map[string]interface{}{"order_id": order.OrderId},
		OrderInfo:         orderInfo,
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{C2CMsg: orderMsg}
	err = msg.C2CMsg.SendC2CMsg(strconv.Itoa(int(order.OrderSellUserId)), strconv.Itoa(int(order.OrderBuyUserId)))
	if err != nil {
		utils.LogErrorF("发送同意退款消息推送失败,err:%s", err.Error())
	}
	return
}

// 拒绝退款，用户端消息
func (r Refund) UserRefundSparring(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(C2C_ORDER_USER_KEY_REFUND_REFUSE)
	if err != nil {
		utils.LogErrorF("获取完成订单消息model失败,err:%s", err.Error())
		return
	}
	orderInfo := &redismodels.C2cOrderInfo{
		OrderId:              order.OrderId,
		OrderSparringSkillId: order.OrderSparringSkillId,
		OrderStatus:          order.OrderStatus,
		OrderPayStatus:       order.OrderPayStatus,
		OrderSellUserId:      order.OrderSellUserId,
		OrderBuyUserId:       order.OrderBuyUserId,
		OrderCancelStatus:    order.OrderCancelStatus,
		OrderAppealStatus:    order.OrderAppealStatus,
		OrderCommentStatus:   order.OrderCommentStatus,
		OrderCount:           order.OrderCount,
		OrderFinishStatus:    order.OrderFinishStatus,
		OrderPrice:           order.OrderPrice,
		OrderRefundCount:     order.OrderRefundCount,
		OrderRefundStatus:    order.OrderRefundStatus,
		OrderConfirmStatus:   order.OrderConfirmStatus,
		OrderSettleStatus:    order.OrderSettleStatus,
		OrderSkillId:         order.OrderSkillId,
		OrderWay:             order.OrderWay,
		OrderAmount:          order.OrderAmount,
		Created:              order.BaseModel.Created,
		SkillInfo:            redismodels.OrderSkillInfo{Icon: order.AppSkill.SkillIconurl, Name: order.AppSkill.SkillName, SkillId: order.AppSkill.SkillId},
	}
	orderMsg := &redismodels.C2CMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgOrder.MsgTitle,
		Text:              msgOrder.MsgContent,
		OrderInfo:         orderInfo,
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{C2CMsg: orderMsg}
	err = msg.C2CMsg.SendC2CMsg(strconv.Itoa(int(order.OrderSellUserId)), strconv.Itoa(int(order.OrderBuyUserId)))
	if err != nil {
		utils.LogErrorF("发送完成消息推送失败,err:%s", err.Error())
	}
	return
}

// 系统退款，大神端消息
func (r Refund) SparringRefundSys(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(C2C_ORDER_SPARRING_KEY_REFUND_OK_SYSTEM)
	if err != nil {
		utils.LogErrorF("获取系统退款订单消息model失败,err:%s", err.Error())
		return
	}
	amount := order.OrderAmount / 100
	tip := strings.NewReplacer("${order_amount}", strconv.Itoa(int(amount))).Replace(msgOrder.MsgContent)
	orderInfo := &redismodels.C2cOrderInfo{
		OrderId:              order.OrderId,
		OrderSparringSkillId: order.OrderSparringSkillId,
		OrderStatus:          order.OrderStatus,
		OrderPayStatus:       order.OrderPayStatus,
		OrderSellUserId:      order.OrderSellUserId,
		OrderBuyUserId:       order.OrderBuyUserId,
		OrderCancelStatus:    order.OrderCancelStatus,
		OrderAppealStatus:    order.OrderAppealStatus,
		OrderCommentStatus:   order.OrderCommentStatus,
		OrderCount:           order.OrderCount,
		OrderFinishStatus:    order.OrderFinishStatus,
		OrderPrice:           order.OrderPrice,
		OrderRefundCount:     order.OrderRefundCount,
		OrderRefundStatus:    order.OrderRefundStatus,
		OrderConfirmStatus:   order.OrderConfirmStatus,
		OrderSettleStatus:    order.OrderSettleStatus,
		OrderSkillId:         order.OrderSkillId,
		OrderWay:             order.OrderWay,
		OrderAmount:          order.OrderAmount,
		Created:              order.BaseModel.Created,
		SkillInfo:            redismodels.OrderSkillInfo{Icon: order.AppSkill.SkillIconurl, Name: order.AppSkill.SkillName, SkillId: order.AppSkill.SkillId},
	}
	orderMsg := &redismodels.C2CMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgOrder.MsgTitle,
		Text:              tip,
		OrderInfo:         orderInfo,
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{C2CMsg: orderMsg}
	err = msg.C2CMsg.SendC2CMsg(strconv.Itoa(int(order.OrderBuyUserId)), strconv.Itoa(int(order.OrderSellUserId)))
	if err != nil {
		utils.LogErrorF("发送系统退款订单消息推送失败,err:%s", err.Error())
	}
	return
}

// 系统退款，用户端消息
func (r Refund) UserRefundSys(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(C2C_ORDER_USER_KEY_REFUND_OK_SYSTEM)
	if err != nil {
		utils.LogErrorF("获取同意退款消息model失败,err:%s", err.Error())
		return
	}
	amount := order.OrderAmount / 100
	tip := strings.NewReplacer("${order_amount}", strconv.Itoa(int(amount))).Replace(msgOrder.MsgContent)
	orderInfo := &redismodels.C2cOrderInfo{
		OrderId:              order.OrderId,
		OrderSparringSkillId: order.OrderSparringSkillId,
		OrderStatus:          order.OrderStatus,
		OrderPayStatus:       order.OrderPayStatus,
		OrderSellUserId:      order.OrderSellUserId,
		OrderBuyUserId:       order.OrderBuyUserId,
		OrderCancelStatus:    order.OrderCancelStatus,
		OrderAppealStatus:    order.OrderAppealStatus,
		OrderCommentStatus:   order.OrderCommentStatus,
		OrderCount:           order.OrderCount,
		OrderFinishStatus:    order.OrderFinishStatus,
		OrderPrice:           order.OrderPrice,
		OrderRefundCount:     order.OrderRefundCount,
		OrderRefundStatus:    order.OrderRefundStatus,
		OrderConfirmStatus:   order.OrderConfirmStatus,
		OrderSettleStatus:    order.OrderSettleStatus,
		OrderSkillId:         order.OrderSkillId,
		OrderWay:             order.OrderWay,
		OrderAmount:          order.OrderAmount,
		Created:              order.BaseModel.Created,
		SkillInfo:            redismodels.OrderSkillInfo{Icon: order.AppSkill.SkillIconurl, Name: order.AppSkill.SkillName, SkillId: order.AppSkill.SkillId},
	}
	orderMsg := &redismodels.C2CMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_ACTION,
		ActionType:        redismodels.MSG_ACTION_TYPE_USER_ORDER_INFO,
		Title:             msgOrder.MsgTitle,
		Text:              tip,
		Action:            strconv.Itoa(int(order.OrderId)),
		OrderInfo:         orderInfo,
		ActionParams:      map[string]interface{}{"order_id": order.OrderId},
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{C2CMsg: orderMsg}
	err = msg.C2CMsg.SendC2CMsg(strconv.Itoa(int(order.OrderSellUserId)), strconv.Itoa(int(order.OrderBuyUserId)))
	if err != nil {
		utils.LogErrorF("发送同意退款消息推送失败,err:%s", err.Error())
	}
	return
}

// 用户申述，大神端消息
func (r Appeal) SparringAppealApply(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(C2C_ORDER_SPARRING_KEY_APPEAL_APPLY)
	if err != nil {
		utils.LogErrorF("获取申诉订单订单消息model失败,err:%s", err.Error())
		return
	}
	orderInfo := &redismodels.C2cOrderInfo{
		OrderId:              order.OrderId,
		OrderSparringSkillId: order.OrderSparringSkillId,
		OrderStatus:          order.OrderStatus,
		OrderPayStatus:       order.OrderPayStatus,
		OrderSellUserId:      order.OrderSellUserId,
		OrderBuyUserId:       order.OrderBuyUserId,
		OrderCancelStatus:    order.OrderCancelStatus,
		OrderAppealStatus:    order.OrderAppealStatus,
		OrderCommentStatus:   order.OrderCommentStatus,
		OrderCount:           order.OrderCount,
		OrderFinishStatus:    order.OrderFinishStatus,
		OrderPrice:           order.OrderPrice,
		OrderRefundCount:     order.OrderRefundCount,
		OrderRefundStatus:    order.OrderRefundStatus,
		OrderConfirmStatus:   order.OrderConfirmStatus,
		OrderSettleStatus:    order.OrderSettleStatus,
		OrderSkillId:         order.OrderSkillId,
		OrderWay:             order.OrderWay,
		OrderAmount:          order.OrderAmount,
		Created:              order.BaseModel.Created,
		SkillInfo:            redismodels.OrderSkillInfo{Icon: order.AppSkill.SkillIconurl, Name: order.AppSkill.SkillName, SkillId: order.AppSkill.SkillId},
	}
	orderMsg := &redismodels.C2CMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_ACTION,
		ActionType:        redismodels.MSG_ACTION_TYPE_SPARRING_ORDER_INFO,
		Action:            strconv.Itoa(int(order.OrderId)),
		Title:             msgOrder.MsgTitle,
		Text:              msgOrder.MsgContent,
		ActionParams:      map[string]interface{}{"order_id": order.OrderId},
		OrderInfo:         orderInfo,
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{C2CMsg: orderMsg}
	err = msg.C2CMsg.SendC2CMsg(strconv.Itoa(int(order.OrderBuyUserId)), strconv.Itoa(int(order.OrderSellUserId)))
	if err != nil {
		utils.LogErrorF("发送申诉订单消息推送失败,err:%s", err.Error())
	}
	if msgOrder.MsgSmsSend == dbmodels.MSG_SEND_SMS_YES {
		mobile, err := new(dbmodels.SystemUser).GetUserMobile(order.OrderSellUserId)
		if err != nil {
			utils.LogErrorF("发送用户申诉订单短信推送失败,获取用户手机号失败,err:%s", err.Error())
		}
		sms.SendModelSms(1, msgOrder.MsgSmsContent, mobile)
	}
	return
}

// 用户申诉，系统处理，大神端消息
func (r Appeal) SparringAppealTimeout(order *dbmodels.AppSkillOrder) {
	msgOrder, err := new(dbmodels.AppMsgModel).GetMsgByKey(C2C_ORDER_SPARRING_KEY_APPEAL_COMMIT_TIMEOUT)
	if err != nil {
		utils.LogErrorF("获取超时申诉订单订单消息model失败,err:%s", err.Error())
		return
	}
	amount := order.OrderAmount / 100
	tip := strings.NewReplacer("${order_amount}", strconv.Itoa(int(amount))).Replace(msgOrder.MsgContent)
	orderInfo := &redismodels.C2cOrderInfo{
		OrderId:              order.OrderId,
		OrderSparringSkillId: order.OrderSparringSkillId,
		OrderStatus:          order.OrderStatus,
		OrderPayStatus:       order.OrderPayStatus,
		OrderSellUserId:      order.OrderSellUserId,
		OrderBuyUserId:       order.OrderBuyUserId,
		OrderCancelStatus:    order.OrderCancelStatus,
		OrderAppealStatus:    order.OrderAppealStatus,
		OrderCommentStatus:   order.OrderCommentStatus,
		OrderCount:           order.OrderCount,
		OrderFinishStatus:    order.OrderFinishStatus,
		OrderPrice:           order.OrderPrice,
		OrderRefundCount:     order.OrderRefundCount,
		OrderRefundStatus:    order.OrderRefundStatus,
		OrderConfirmStatus:   order.OrderConfirmStatus,
		OrderSettleStatus:    order.OrderSettleStatus,
		OrderSkillId:         order.OrderSkillId,
		OrderWay:             order.OrderWay,
		OrderAmount:          order.OrderAmount,
		Created:              order.BaseModel.Created,
		SkillInfo:            redismodels.OrderSkillInfo{Icon: order.AppSkill.SkillIconurl, Name: order.AppSkill.SkillName, SkillId: order.AppSkill.SkillId},
	}
	orderMsg := &redismodels.C2CMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgOrder.MsgTitle,
		Text:              tip,
		OrderInfo:         orderInfo,
		NotificationClose: msgOrder.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{C2CMsg: orderMsg}
	err = msg.C2CMsg.SendC2CMsg(strconv.Itoa(int(order.OrderBuyUserId)), strconv.Itoa(int(order.OrderSellUserId)))
	if err != nil {
		utils.LogErrorF("发送超时申诉订单消息推送失败,err:%s", err.Error())
	}
	return
}
