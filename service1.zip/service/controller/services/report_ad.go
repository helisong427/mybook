package services

import (
	"encoding/json"
	"gamers/utils"
)

const (
	ADYiMi   = 2 // 亿米上报
	ADHuaWei = 3 // 华为上报

	YiMiActivation = 0 // 激活
	YiMiLogin      = 1 // 注册
)

type ReportData struct {
	Type int    `json:"type"`
	Data string `json:"data"`
}

// YiMi 亿米上报
type YiMi struct {
	AppId      string `json:"app_id"`
	SignKey    string `json:"sign_key"`
	EncryptKey string `json:"encrypt_key"`
	CustomerId string `json:"customer_id"`
	IMEI       string `json:"imei"`
	OAId       string `json:"oaid"`
	IP         string `json:"ip"`
	Type       int    `json:"type"`
}

// Send 亿米上报数据
func (ym *YiMi) Send() (err error) {
	content, err := json.Marshal(ym)
	if err != nil {
		return
	}
	data, err := json.Marshal(&ReportData{
		Type: ADYiMi,
		Data: string(content),
	})
	if err != nil {
		return
	}

	key := utils.FuncGenerateDataId()
	return utils.KafkaSendMsg(ReportTopic, key, data)
}

// HuaWei 华为上报
type HuaWei struct {
	ChannelId       string `json:"channel_id"`       // 渠道id
	ContentId       string `json:"content_id"`       // 素材id
	ADGroupId       string `json:"adgroup_id"`       // 任务id
	CampaignId      string `json:"campaign_id"`      // 计划id
	OAId            string `json:"oaid"`             // 设备标识符，明文
	TrackingEnabled string `json:"tracking_enabled"` // 是否跟踪
	IP              string `json:"ip"`               // 点击时的IP地址
	UserAgent       string `json:"user_agent"`       // 做URL编码
	EventType       string `json:"event_type"`       // 事件类型
	TraceTime       string `json:"trace_time"`       // 事件发生的时间
	Callback        string `json:"callback"`         // 回调参数
	CorpId          string `json:"corp_id"`          // 广告主标识
	AppId           string `json:"app_id"`           // 推广的app标识
	ChannelConfig   string `json:"channel_config"`
}

// Send 华为上报数据
func (hw *HuaWei) Send() (err error) {
	content, err := json.Marshal(hw)
	if err != nil {
		return
	}
	data, err := json.Marshal(&ReportData{
		Type: ADHuaWei,
		Data: string(content),
	})
	if err != nil {
		return
	}

	key := utils.FuncGenerateDataId()
	return utils.KafkaSendMsg(ReportTopic, key, data)
}
