/**
 * @Author: panke
 * @Description:
 * @File: turn_table
 * @Date: 2021/4/22 15:56
 */

package services

import (
	"errors"
	"fmt"
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"gamers/utils/common"
	"gamers/utils/prop"
	"gamers/utils/trydo"
	"github.com/go-redis/redis"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

// 转盘抽奖
func Turn(userId int64, req *request.TurnTableReq) (*response.TurnTableResp, string, error) {

	if req.TurnTableCount <= 0 {
		return nil, "转盘失败0", errors.New("error params turn_table_count")
	}

	turnTableData, err := new(dbmodels.AppTurnTable).QueryByTurnTableId(int64(req.TurnTableId))
	if err != nil {
		return nil, "转盘失败1", errors.New("error params turn_table_id")
	}

	var resp = &response.TurnTableResp{
		TurnTableID:            req.TurnTableId,
		TurnTableCount:         req.TurnTableCount,
		TurnTableCostPropType:  prop.Type(turnTableData.TurnTableCostPropType),
		TurnTableCostPropID:    turnTableData.TurnTableCostPropID,
		TurnTableCostPropCount: turnTableData.TurnTableCostPropCount * int64(req.TurnTableCount),
		TurnTableDetails:       nil,
	}

	if valid, _ := new(dbmodels.AppBackpack).CheckEnough(userId, turnTableData.TurnTableCostPropID, turnTableData.TurnTableCostPropCount*int64(req.TurnTableCount)); !valid {
		return nil, "物品不足", errors.New("not enough props")
	}

	propMaps, propLength, err := GetTurnTableRewardsFromPool(req.TurnTableId, req.TurnTableCount)
	if err != nil {
		return nil, "转盘失败2", err
	}

	if propLength < req.TurnTableCount {
		var realErr = err
		if err := buildTurntablePool(req.TurnTableId); err != nil {
			realErr = err
		}
		var succeed = trydo.DoWithIntervals([]time.Duration{
			time.Millisecond * 100,
			time.Millisecond * 100,
			time.Millisecond * 100,
			time.Millisecond * 100,
			time.Millisecond * 100,
			time.Millisecond * 100,
			time.Millisecond * 100,
		}, func() (isOver bool) {
			var leftRewards, leftPropLength, err = GetTurnTableRewardsFromPool(req.TurnTableId, req.TurnTableCount-propLength)
			if err != nil {
				realErr = err
				return false
			}

			if leftPropLength > 0 {
				mergeTurnTablePropMaps(propMaps, leftRewards)
				propLength += leftPropLength
				if propLength == req.TurnTableCount {
					return true
				}
			}

			if err := buildTurntablePool(req.TurnTableId); err != nil {
				realErr = err
			}
			return false
		})
		if !succeed {
			if realErr == nil {
				realErr = errors.New("get egg break rewards failed")
			}
			return nil, "转盘失败3", realErr
		}
	}

	// 如果仍然不足，直接返回失败
	if propLength < req.TurnTableCount {
		return nil, "转盘失败4", errors.New("get egg break rewards failed")
	}

	resp.TurnTableDetails = convertTurnTablePropMaps(propMaps)
	if err := completeTurnTablePropInfos(resp); err != nil {
		return nil, "转盘失败5", err
	}

	var hammerCount int64
	if hammerCount, err = dealTurnTableResult(userId, resp); err != nil {
		return nil, "转盘失败6", err
	}
	resp.TurnTableTicket = hammerCount

	// 各种日志，排行榜等
	dealTurnTableFollowUp(turnTableData.TurnTableTitle, userId, req, resp)

	return resp, "转盘成功7", nil
}

// 从奖励池子获得对应个数的奖励
func GetTurnTableRewardsFromPool(turnTableId int, getCount int) (map[int]*response.TurnTableRewardDetail, int, error) {
	var script = redis.NewScript(`
local poolLotteryKey = tostring(KEYS[1])
local poolStatusKey = tostring(KEYS[2])
local getCount = tonumber(ARGV[1])
local realGetCount = 0
local valMap = {}
local valArr = {}
for _ = 1, getCount, 1 do
    local data = redis.call("rPop", poolLotteryKey)
    if data == false then
        break
    end

    local key = tostring(data)
    realGetCount = realGetCount + 1
    valArr[realGetCount] = key

    if valMap[key] == nil then
        valMap[key] = 0
    end
    valMap[key] = valMap[key] + 1
end

for fieldKey, decCount in pairs(valMap) do
    local data = redis.call("hGet", poolStatusKey, fieldKey)
    if data ~= false then
        local orgCount = tonumber(data)
        redis.call("hSet", poolStatusKey, fieldKey, orgCount - decCount)
    end
end

return valArr
`)

	var poolLotteryKey = fmt.Sprintf("%s%d", utils.REDIS_TURNTABLE_POOL_LOTTERY_LIST, turnTableId)
	var poolStatusKey = fmt.Sprintf("%s%d", utils.REDIS_TURNTABLE_POOL_STATUS, turnTableId)

	retVal, retErr := script.Eval(utils.RedisClient, []string{
		poolLotteryKey,
		poolStatusKey,
	}, getCount).Result()

	if retErr != nil {
		return nil, 0, retErr
	}

	var propMaps = map[int]*response.TurnTableRewardDetail{} // prop_id
	var keyRegexp = regexp.MustCompile("([^:]+)")
	var retList = retVal.([]interface{})

	for _, v := range retList {
		var key = v.(string)
		// 小蛋池id:奖励id:礼物id:礼物价格
		var parsed = keyRegexp.FindAllString(key, -1)
		if len(parsed) != 4 {
			return nil, 0, errors.New("error config")
		}
		var propId, err = strconv.ParseInt(parsed[2], 10, 64)
		if err != nil {
			return nil, 0, err
		}
		var propOrgPrice, errPrice = strconv.ParseInt(parsed[3], 10, 64)
		if errPrice != nil {
			return nil, 0, errPrice
		}

		if item, prs := propMaps[int(propId)]; prs {
			item.PropCount += 1
		} else {
			propMaps[int(propId)] = &response.TurnTableRewardDetail{
				PropType:     prop.UnexpectedType, // 未知，由配置补全
				PropId:       int(propId),
				PropCount:    1,
				PropOrgPrice: propOrgPrice,
			}
		}
	}
	return propMaps, len(retList), nil
}

// 重新生成缓存池子
func buildTurntablePool(turnTableId int) error {
	var redisKey = fmt.Sprintf("%s%d", utils.REDIS_TURNTABLE_POOL_INIT, turnTableId)
	var lockVal, isLock = utils.AcquireLock(redisKey, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
	if !isLock {
		return errors.New("init egg break pool failed")
	}
	defer utils.ReleaseLock(redisKey, lockVal)

	var poolLotteryKey = fmt.Sprintf("%s%d", utils.REDIS_TURNTABLE_POOL_LOTTERY_LIST, turnTableId)
	var val, err = utils.RedisClient.LLen(poolLotteryKey).Result()
	if err != nil {
		return err
	}
	if val > 0 {
		return nil
	}

	builder := redismodels.NewTurnTable()
	if err := builder.Init(int64(turnTableId)); err != nil {
		return err
	}
	return nil
}

func mergeTurnTablePropMaps(dst map[int]*response.TurnTableRewardDetail, src map[int]*response.TurnTableRewardDetail) {
	for _, v := range src {
		if _, prs := dst[v.PropId]; prs {
			dst[v.PropId].PropCount += src[v.PropId].PropCount
		} else {
			dst[v.PropId] = v
		}
	}
}

func convertTurnTablePropMaps(src map[int]*response.TurnTableRewardDetail) []*response.TurnTableRewardDetail {
	var ret []*response.TurnTableRewardDetail
	for _, v := range src {
		ret = append(ret, v)
	}
	// 砸蛋结果按照单价排序
	sort.Slice(ret, func(i, j int) bool {
		return ret[i].PropOrgPrice > ret[j].PropOrgPrice
	})
	return ret
}

// 根据物品配置补全物品信息
func completeTurnTablePropInfos(resp *response.TurnTableResp) error {
	resp.TurnTableTotalPrice = 0
	for _, v := range resp.TurnTableDetails {
		var cfg, err = (&dbmodels.AppProp{}).GetPropConfigById(int64(v.PropId))
		if err != nil {
			return err
		}
		v.PropType = prop.Type(cfg.PropType)
		v.PropExpiredType = cfg.PropExpiredType
		v.PropExpiredTime = cfg.PropExpiredTime
		v.PropOrgPrice = cfg.PropOrgPrice
		v.PropGetRadio1 = cfg.PropGetRadio1
		v.PropName = cfg.PropName
		v.PropAttrId = cfg.PropAttrId
		v.PropIcon = cfg.PropIcon
		v.PropDesc = cfg.PropRemark
		resp.TurnTableTotalPrice += cfg.PropOrgPrice * int64(v.PropCount)
	}
	return nil
}

// 处理砸蛋结果-礼物 实物
func dealGiftRealThing(userId int64, detail *response.TurnTableRewardDetail, resp *response.TurnTableResp) (hammerCount int64, err error) {

	var tx = utils.GEngine.Begin()

	var alteredBackpackList []*dbmodels.AppBackpack

	{
		var backpack = new(dbmodels.AppBackpack)
		if err := backpack.Dec(tx, userId, int(resp.TurnTableCostPropID), int(resp.TurnTableCostPropCount)); err != nil {
			tx.Rollback()
			return 0, err
		}
		hammerCount = backpack.BackpackCount
		alteredBackpackList = append(alteredBackpackList, backpack)
	}

	var backpack = &dbmodels.AppBackpack{
		BackpackUserId:      userId,
		BackpackPropType:    int(detail.PropType),
		BackpackPropId:      int64(detail.PropId),
		BackpackCount:       int64(detail.PropCount),
		BackpackPropAttrId:  detail.PropAttrId,
		BackpackExpiredTime: 0,
	}
	if err := backpack.Add(tx); err != nil {
		tx.Rollback()
		return hammerCount, err
	}
	alteredBackpackList = append(alteredBackpackList, backpack)
	err = tx.Commit().Error
	if err == nil {
		var redisFields []string
		for _, v := range alteredBackpackList {
			if prop.Type(v.BackpackPropType) == prop.TypeGift {
				var field = fmt.Sprintf("%d", v.BackpackId)
				redisFields = append(redisFields, field)
			}
		}
		if len(redisFields) > 0 {
			// 直接删除缓存
			var redisKey = fmt.Sprintf("%s%d", utils.REDIS_LIVE_GIFT_BACKPACK, userId)
			_ = utils.RedisClient.HDel(redisKey, redisFields...).Err()
		}
	}
	return
}

// 处理砸蛋结果-GO币
func dealGOGO(userId int64, detail *response.TurnTableRewardDetail, resp *response.TurnTableResp) (hammerCount int64, err error) {
	var tx = utils.GEngine.Begin()

	var alteredBackpackList []*dbmodels.AppBackpack

	{
		var backpack = new(dbmodels.AppBackpack)
		if err := backpack.Dec(tx, userId, int(resp.TurnTableCostPropID), int(resp.TurnTableCostPropCount)); err != nil {
			tx.Rollback()
			return 0, err
		}
		hammerCount = backpack.BackpackCount
		alteredBackpackList = append(alteredBackpackList, backpack)
	}

	// 用户钱包加go币
	count := common.RegexpGogoProp(detail.PropName)
	err = new(dbmodels.AppUserWallet).AddUserGogo(tx, userId, count*100)
	if err != nil {
		tx.Rollback()
		return hammerCount, err
	}

	// 增加流水日志
	transaction := dbmodels.AppTransaction{
		TransactionId:            dbmodels.IDBuilderGetId(utils.REDIS_IDBUILDER_TRANSACTION_ID),
		TransactionType:          dbmodels.DB_TRANSACTION_TYPE_ACTIVITY_GIVE,
		TransactionAmount:        count * 100,
		TransactionToUserId:      userId,
		TransactionRemark:        fmt.Sprintf("活动赠送:%s", detail.PropName),
		TransactionStatus:        dbmodels.DB_TRANSACTION_COMPLETE,
		TransactionToAccountType: dbmodels.DB_ACCOUNT_TYPE_PLATFORM,
	}
	err = transaction.Create(tx)
	if err != nil {
		tx.Rollback()
		return hammerCount, err
	}

	err = tx.Commit().Error
	if err == nil {
		// 更改用户info 钱包缓存
		_ = utils.RedisClient.HIncrBy(utils.REDIS_USER_INFO+strconv.FormatInt(userId, 10), "WalletTotalOver", int64(count*100)).Err()
	}
	return
}

// 处理砸蛋结果(扣东西，加东西etc)
func dealTurnTableResult(userId int64, resp *response.TurnTableResp) (hammerCount int64, err error) {
	var redisKey = fmt.Sprintf("%s%d", utils.REDIS_BACKPACK_LOCK, userId)
	var lockVal, isLock = utils.AcquireLock(redisKey, EGGBREAK_LOCK_TIME_OUT, EGGBREAK_LOCK_TIME_OUT)
	if !isLock {
		return 0, errors.New("lock failed")
	}
	defer utils.ReleaseLock(redisKey, lockVal)

	for _, v := range resp.TurnTableDetails {
		if v.PropType == prop.TypeGift || v.PropType == prop.TypeRealThing {
			hammerCount, err = dealGiftRealThing(userId, v, resp)
		} else if v.PropType == prop.TypeGOGO {
			hammerCount, err = dealGOGO(userId, v, resp)
		}
	}
	return
}

// 处理转盘后续
func dealTurnTableFollowUp(title string, userId int64, req *request.TurnTableReq, resp *response.TurnTableResp) {
	// 记录转盘日志
	var recordId = dbmodels.IDBuilderGetId(utils.REDIS_IDBUILDER_TURNTABLE_RECORD_ID)
	var logs []*dbmodels.AppTurnTableLog
	for _, v := range resp.TurnTableDetails {
		logs = append(logs, &dbmodels.AppTurnTableLog{
			LogRecordID:       recordId,
			LogUserID:         userId,
			LogTurnTableID:    resp.TurnTableID,
			LogTurnTableCount: resp.TurnTableCount,
			LogCostPropType:   resp.TurnTableCostPropType,
			LogCostPropID:     resp.TurnTableCostPropID,
			LogCostPropCount:  resp.TurnTableCostPropCount,
			LogPropType:       v.PropType,
			LogPropID:         v.PropId,
			LogPropCount:      v.PropCount,
		})
	}
	_ = new(dbmodels.AppTurnTableLog).Log(logs)

	// 处理消息
	for _, v := range resp.TurnTableDetails {
		if v.PropType == prop.TypeGift {
			SendGiftMsg(title, v.PropName, int(userId))
		}
		if v.PropType == prop.TypeGOGO {
			SendGoMsg(title, strconv.Itoa(int(common.RegexpGogoProp(v.PropName))), int(userId))
		}
		if v.PropType == prop.TypeRealThing {
			SendRealThingMsg(title, v.PropName, int(userId))
		}
	}
}

const (
	ASSISTANT_TURNTABLE_GIFT      = "assistant_turntable_gift"       // 大转盘推送礼物信息
	ASSISTANT_TURNTABLE_GO        = "assistant_turntable_go"         // 大转盘推送go币消息
	ASSISTANT_TURNTABLE_REALTHING = "assistant_turntable_real_thing" // 大转盘推送实物消息
)

// 发送礼物消息
func SendGiftMsg(title, name string, userId int) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_TURNTABLE_GIFT)
	if err != nil {
		utils.LogErrorF("获取大转盘推送礼物信息model失败,err:%s", err.Error())
		return
	}

	tip := strings.NewReplacer("${title}", title, "${name}", name).Replace(msgModel.MsgContent)
	skillMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TEXT,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: skillMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, strconv.Itoa(userId))
	if err != nil {
		utils.LogErrorF("发送大转盘推送礼物信息失败,err:%s", err.Error())
	}
}

// 发送go币消息
func SendGoMsg(title, num string, userId int) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_TURNTABLE_GO)
	if err != nil {
		utils.LogErrorF("获取大转盘推送Go币信息model失败,err:%s", err.Error())
		return
	}

	tip := strings.NewReplacer("${title}", title, "${num}", num).Replace(msgModel.MsgContent)
	skillMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TEXT,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: skillMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, strconv.Itoa(userId))
	if err != nil {
		utils.LogErrorF("发送大转盘推送Go币信息失败,err:%s", err.Error())
	}
}

// 发送实物消息
func SendRealThingMsg(title, name string, userId int) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_TURNTABLE_REALTHING)
	if err != nil {
		utils.LogErrorF("获取大转盘推送实物信息model失败,err:%s", err.Error())
		return
	}

	tip := strings.NewReplacer("${title}", title, "${name}", name).Replace(msgModel.MsgContent)
	skillMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TEXT,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: skillMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, strconv.Itoa(userId))
	if err != nil {
		utils.LogErrorF("发送大转盘推送实物信息失败,err:%s", err.Error())
	}
}
