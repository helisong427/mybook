package services

import (
	"gamers/controller/response"
	"gamers/models/dbmodels"
)

//地区信息处理成树形结构
func CityTree(data []*dbmodels.SystemRegion, pid int64) []response.GetRegionListRep {
	treeList := []response.GetRegionListRep{}
	for _, v := range data {
		if v.RegionParentID == pid {
			child := CityTree(data, v.RegionID)
			node := response.GetRegionListRep{
				RegionID: v.RegionID,
				Name:     v.RegionName,
				ParentID: v.RegionParentID,
				Fullname: v.RegionFullname,
				Level:    v.RegionLevel,
				Child:    child,
			}
			treeList = append(treeList, node)
		}
	}
	return treeList
}
