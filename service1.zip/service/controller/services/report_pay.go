package services

import (
	"encoding/json"
	"gamers/models/dbmodels"
	"gamers/utils"
)

const (
	ReportTopic = "topic_data_report"

	PayLog = 1 // 充值日志
)

// PayReport 支付成功上报消息结构体
type PayReport struct {
	Type          uint32 `json:"type"`          // 类型 1:充值日志
	UserId        int64  `json:"userId"`        // 用户id
	OrderId       string `json:"orderId"`       // 订单号
	Status        uint32 `json:"status"`        // 支付状态 1：发起状态未支付 2：充值成功 3：充值失败 4：支付成功未发Go币
	FinalQuantity uint64 `json:"finalQuantity"` // 剩余GO币(*100)
	Quantity      uint64 `json:"quantity"`      // 剩余余额(*1000)
}

// Send 发送消息
func (p *PayReport) Send() {
	// 获取用户钱包内容
	var w dbmodels.AppUserWallet
	wallet, err := w.Query(p.UserId)
	if err != nil {
		utils.LogErrorF("获取用户钱包信息失败, error: %v", err)
		return
	}

	p.FinalQuantity = uint64(wallet.WalletTotalOver)
	p.Quantity = uint64(wallet.WalletTotalExtractable)

	utils.LogInfoF("推送数据内容：%v", p)

	data, err := json.Marshal(p)
	if err != nil {
		utils.LogErrorF("支付上报序列化消息失败: %v", err)
		return
	}

	key := utils.FuncGenerateDataId()
	err = utils.KafkaSendMsg(ReportTopic, key, data)
	if err != nil {
		utils.LogErrorF("支付上报推送消息失败: %v", err)
	}
	return
}
