package services

import (
	"encoding/json"
	"fmt"
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/enum"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"gamers/utils/ymd"
	"github.com/go-redis/redis"
	jsoniter "github.com/json-iterator/go"
	"sort"
	"sync"
	"time"
)

// 周星榜 排行获取
// 这里需要 给redis加读写锁, 防止读空数据
func GetRankListOld(req *request.WeekStarRankListSearch) (result *response.BasePageList, msg string, err error) {
	var (
		list           []dbmodels.WeekStarPropItem
		user           string
		key, personKey string
		listMarshal    []byte
	)

	if *req.SearchType == 1 {
		user = "user"
		key = enum.REDIS_WEEK_STAR_WEALTH_LIST
		personKey = enum.REDIS_WEEK_STAR_WEALTH_PERSON_LIST
	} else {
		user = "anchor"
		key = enum.REDIS_WEEK_STAR_CHARM_LIST
		personKey = enum.REDIS_WEEK_STAR_CHARM_PERSON_LIST
	}

	// 首先 通过redis 获取数据, 如果有, 直接返回
	data := utils.RedisClient.Get(key).Val()
	if data != "" {
		// unmarshal 操作
		if err = json.Unmarshal([]byte(data), &list); err != nil {
			return
		}

		// 获取单人数据
		list = getPersonRank(list, personKey, *req.UserId)

		result = returnBasePage(list)

		return
	}

	// 如果 为空, 则没有数据, 进行数据获取 并 存入 redis
	// 这里查询 列表
	if list, err = new(dbmodels.AppWeekStarProp).GetListByPropPropId(*req.PropId, user); err != nil {
		return
	}

	// 如果数据不为空, 则存入redis
	if listMarshal, err = json.Marshal(&list); err != nil {
		return
	}

	pipeline := utils.RedisClient.Pipeline()

	if err = pipeline.Set(key, string(listMarshal), time.Second*enum.REDIS_WEEK_STAR_EXPIRE_TIME).Err(); err != nil {
		return
	}

	for _, v := range list {
		if v.PropCount == 0 {
			continue
		}

		if err = pipeline.Set(personKey+fmt.Sprintf("%v", v.PropUserId),
			v.PropCount,
			time.Second*enum.REDIS_WEEK_STAR_PERSON_EXPIRE_TIME).Err(); err != nil {
			utils.Logger.Error(err.Error())
		}
	}

	if _, err = pipeline.Exec(); err != nil {
		return
	}

	// 获取单人数据
	list = getPersonRank(list, personKey, *req.UserId)

	result = returnBasePage(list)

	return
}

// 获取 周星榜 历史纪录
func GetWeekStarHistory() (result *response.BasePageList, msg string, err error) {
	var (
		historyListStr    string
		list              []dbmodels.WeekStarPropItem
		redisSaveRankData []byte
	)

	// 从redis 取数据 (这个数据是 在 结算的时候存入redis的)
	historyListStr, _ = utils.RedisClient.Get(enum.REDIS_WEEK_STAR_HISTORY_LIST).Result()

	if historyListStr != "" {
		// 数据存在,直接返回
		if err = json.Unmarshal([]byte(historyListStr), &list); err != nil {
			utils.Logger.Error(err.Error())
			return
		}

		result = returnBasePage(list)
		return
	}

	// 数据不存在, 进行数据库获取
	if list, err = new(dbmodels.AppWeekStarList).GetHistoryRankList(); err != nil {
		utils.Logger.Error(err.Error())
		return
	}

	for k, v := range list {
		list[k].PropIcon, _ = new(redismodels.IconStyle).Get(v.PropUserId)
	}

	if redisSaveRankData, err = json.Marshal(&list); err != nil {
		utils.Logger.Error(err.Error())
		return
	}

	utils.RedisClient.Set(enum.REDIS_WEEK_STAR_HISTORY_LIST, string(redisSaveRankData), time.Second*enum.REDIS_WEEK_STAR_EXPIRE_TIME)

	result = returnBasePage(list)

	return
}

// 周星榜 排行获取
// 这里需要 给redis加读写锁, 防止读空数据
func GetRankList(req *request.WeekStarRankListSearch) (result *response.BasePageList, msg string, err error) {
	var (
		list         []dbmodels.WeekStarPropItem
		userList     []dbmodels.WeekStarPropItem
		lockName     string
		key, zsetKey string
		listMarshal  []byte
		userRankList []redis.Z
		userIds      []interface{}
		lockStr      string
		ok           bool
	)

	if *req.SearchType == 1 {
		key = enum.REDIS_WEEK_STAR_WEALTH_LIST + fmt.Sprintf("%v", *req.PropId)
		zsetKey = enum.REDIS_WEEK_STAR_ZSET_WEALTH_NAME + fmt.Sprintf("%v", *req.PropId)
		lockName = enum.REDIS_WEEK_STAR_LOCK_WEALTH_NAME + fmt.Sprintf("%v", *req.PropId)
	} else {
		key = enum.REDIS_WEEK_STAR_CHARM_LIST + fmt.Sprintf("%v", *req.PropId)
		zsetKey = enum.REDIS_WEEK_STAR_ZSET_CHARM_NAME + fmt.Sprintf("%v", *req.PropId)
		lockName = enum.REDIS_WEEK_STAR_LOCK_CHARM_NAME + fmt.Sprintf("%v", *req.PropId)
	}

	// 加锁
	if lockStr, ok = utils.AcquireLock(lockName, enum.REDIS_WEEK_STAR_LOCK_TIMEOUT, enum.REDIS_WEEK_STAR_LOCK_FORCE_TIMEOUT); ok {
		// 如果加锁成功, 则设置解锁
		defer func() {
			utils.ReleaseLock(lockName, lockStr)
		}()
	}
	// 首先 通过redis 获取数据, 如果有, 直接返回
	data := utils.RedisClient.Get(key).Val()
	if data != "" {
		// unmarshal 操作
		if err = json.Unmarshal([]byte(data), &list); err != nil {
			return
		}

		// 获取单人数据
		list = getPersonRank(list, zsetKey, *req.UserId)

		result = returnBasePage(list)

		return
	}

	if userRankList, err = utils.RedisClient.ZRevRangeByScoreWithScores(zsetKey, redis.ZRangeBy{
		Min:    "-inf",
		Max:    "+inf",
		Offset: 0,
		Count:  enum.REDIS_WEEK_STAR_RANK_NUM,
	}).Result(); err != nil {
		utils.Logger.Error(err.Error())
		return
	}

	// 拿到用户id 数组
	for _, v := range userRankList {
		userIds = append(userIds, v.Member)
	}

	// 如果 为空, 则没有数据, 进行数据获取 并 存入 redis
	// 这里查询 列表
	// 首先拿到 排名上榜用户的redis数据
	if len(userIds) == 0 {
		// 没有用户, 直接返回 空数据
		// 获取单人数据
		list = getPersonRank(list, zsetKey, *req.UserId)
		result = returnBasePage(list)
		return
	}

	if userList, err = new(dbmodels.AppWeekStarProp).GetUserInfoByIds(userIds); err != nil {
		return
	}

	for k, rankData := range userRankList {
		for _, user := range userList {
			if rankData.Member.(string) == fmt.Sprintf("%v", user.PropUserId) {
				user.PropCount = int64(rankData.Score)
				user.PropRank = int64(k + 1)
				user.PropIcon, _ = new(redismodels.IconStyle).Get(user.PropUserId)
				list = append(list, user)
			}
		}
	}

	// 如果数据不为空, 则存入redis
	if listMarshal, err = json.Marshal(&list); err != nil {
		return
	}

	if err = utils.RedisClient.Set(key, string(listMarshal), time.Second*enum.REDIS_WEEK_STAR_EXPIRE_TIME).Err(); err != nil {
		return
	}

	// 获取单人数据
	list = getPersonRank(list, zsetKey, *req.UserId)

	result = returnBasePage(list)

	return
}

// 获取个人 排行信息
func getPersonRank(list []dbmodels.WeekStarPropItem, key string, userId int64) []dbmodels.WeekStarPropItem {
	var (
		personModel  dbmodels.WeekStarPropItem
		propCountNum float64
		propCount    int64
		err          error
		userInfo     redismodels.UserInfo
	)

	if propCountNum = utils.RedisClient.ZScore(key, fmt.Sprintf("%v", userId)).Val(); propCountNum == 0 {
		propCount = 0
	} else {
		propCount = int64(propCountNum)
	}

	for k, v := range list {
		if userId == v.PropUserId {
			personModel.PropRank = int64(k + 1)
			break
		}
	}

	personModel.PropCount = propCount
	personModel.PropIcon, _ = new(redismodels.IconStyle).Get(userId)
	personModel.PropUserId = userId

	if userInfo, err = new(redismodels.UserInfo).GetUserInfo(userId); err != nil {
		utils.Logger.Error(err.Error())
		list = append(list, personModel)
		return list
	}

	personModel.PropUserNickname = userInfo.UserNickname
	personModel.PropUserIconurl = userInfo.UserIconurl

	list = append(list, personModel)

	return list
}

func returnBasePage(data interface{}) *response.BasePageList {
	return &response.BasePageList{
		Page:       1,
		Size:       11,
		Total:      11,
		TotalPages: 1,
		List:       data,
	}
}

// 获取 周星榜 活动信息
func GetWeekStarInfo() (result *dbmodels.AppWeekStarResultItem, msg string, err error) {
	if result, err = new(dbmodels.AppWeekStar).GetByNowTime(time.Now().Unix()); err != nil {
		msg = "周星榜活动获取失败"
		return
	}

	result.WeekStarGiftList = handleGiftImage(result.WeekStarGift)

	return
}

type giftStruct struct {
	Type     int64 `json:"type"`
	GiftType int64 `json:"giftType"`
	Id       int64 `json:"id"`
	Count    int64 `json:"count"`
	Level    int64 `json:"level"`
}

type sortGift struct {
	data []giftStruct
}

func (sort *sortGift) Len() int {
	return len(sort.data)
}

func (sort *sortGift) Less(i, j int) bool {
	return sort.data[i].Level < sort.data[j].Level
}

func (sort *sortGift) Swap(i, j int) {
	handleSwap(&sort.data[i], &sort.data[j])
}

func handleSwap(a *giftStruct, b *giftStruct) {
	*a, *b = *b, *a
}

func handleImage(data string) (result []*dbmodels.WeekStarResultItemImage) {
	var (
		list []giftStruct
		err  error
	)

	if err = json.Unmarshal([]byte(data), &list); err != nil {
		return
	}

	// 根据等级排序
	sortData := &sortGift{data: list}

	sort.Sort(sortData)

	for _, v := range list {

		tmpData := &dbmodels.WeekStarResultItemImage{
			Level: v.Level,
			Type:  v.Type,
		}

		if v.Type == enum.GIFT_TYPE {
			_, prop, _ := new(dbmodels.AppProp).QueryById(uint64(v.Id))
			tmpData.Name = prop.PropName
			tmpData.PropImage = prop.PropIcon
		}

		if v.Type == enum.GO_MONEY {
			tmpData.Name = enum.GO_MONEY_NAME
		}

		result = append(result, tmpData)
	}

	return
}

func handleGiftImage(data string) (result []*dbmodels.WeekStarResultItemImage) {
	var (
		list []uint64
		err  error
	)

	if err = json.Unmarshal([]byte(data), &list); err != nil {
		return
	}

	for _, v := range list {
		_, prop, _ := new(dbmodels.AppProp).QueryById(v)

		result = append(result, &dbmodels.WeekStarResultItemImage{
			PropImage: prop.PropIcon,
			Name:      prop.PropName,
		})
	}

	return
}

func UpdateWeekStarInfo(form *SendPropInfoToMq) {
	wg := sync.WaitGroup{}

	for _, v := range form.SendPropReq.ReceiverIDS {
		wg.Add(1)
		go UpdateWeekStarData(form.Prop.PropId, form.SenderId, v, form.SendPropReq.PropCount, &wg)
	}

	wg.Wait()
}

// 更新周星榜用户数据
// 这里要做活动礼物存储逻辑, 存入redis, 过期时间设置为 当天23:59:59的时间戳减去当前时间
func UpdateWeekStarData(propId, sendUserId, receiveUserId, propCount int64, wg *sync.WaitGroup) {
	var (
		nowGiftList string
		result      *dbmodels.AppWeekStarResultItem
		err         error
		lockName    string
		ok          bool
	)

	defer wg.Done()

	nowTime := time.Now().Unix()

	if lockName, ok = utils.AcquireLock(enum.REDIS_WEEK_STAR_LOCK, enum.REDIS_WEEK_STAR_LOCK_TIMEOUT, enum.REDIS_WEEK_STAR_LOCK_FORCE_TIMEOUT); ok {
		// 如果加锁成功, 则设置解锁
		defer func() {
			utils.Logger.Info("redis解锁 =========> unlock redis week_star_gift_lock")
			utils.ReleaseLock(enum.REDIS_WEEK_STAR_LOCK, lockName)
		}()
	}

	utils.Logger.Info("当前操作的礼物ID prop id ===========> " + fmt.Sprintf("%v", propId))

	// 首先从 redis获取 活动礼物列表
	if nowGiftList = utils.RedisClient.Get(enum.REDIS_WEEK_STAR_NOW_GIFT_LIST).Val(); nowGiftList != "" {

		updateWeekStarGiftCount(sendUserId, receiveUserId, propCount, propId, nowGiftList)

		return
	}

	// 如果没有, 则从数据库获取 当前活动列表, 并且存入 redis设置过期时间
	if result, err = new(dbmodels.AppWeekStar).GetByNowTime(nowTime); err != nil {
		utils.Logger.Error(err.Error())
		return
	}

	if result.WeekStarGift == "" {
		return
	}

	expireTime := ymd.GetToday24TimeStamp() - nowTime

	if err = utils.RedisClient.Set(enum.REDIS_WEEK_STAR_NOW_GIFT_LIST, result.WeekStarGift, time.Second*time.Duration(expireTime)).Err(); err != nil {
		utils.Logger.Error(err.Error())
		return
	}

	updateWeekStarGiftCount(sendUserId, receiveUserId, propCount, propId, result.WeekStarGift)
}

func updateWeekStarGiftCount(sendUserId, receiveUserId, propCount, propId int64, nowGiftList string) {
	var (
		err      error
		giftList []int64
	)

	// 不为空, 直接拿到数据 格式化
	if err = jsoniter.Unmarshal([]byte(nowGiftList), &giftList); err != nil {
		utils.Logger.Error(err.Error())
		return
	}

	utils.Logger.Info("当前操作的礼物ID数组 prop_id ===========> " + fmt.Sprintf("%v", giftList))

	// 遍历 查看, 送的礼物是否是当前活动礼物
	for _, v := range giftList {
		if propId == v {

			utils.Logger.Info("当前操作礼物 prop_id 满足 条件, start increment")

			utils.RedisClient.ZIncrBy(enum.REDIS_WEEK_STAR_ZSET_WEALTH_NAME+fmt.Sprintf("%v", propId), float64(propCount), fmt.Sprintf("%v", sendUserId))

			utils.RedisClient.ZIncrBy(enum.REDIS_WEEK_STAR_ZSET_CHARM_NAME+fmt.Sprintf("%v", propId), float64(propCount), fmt.Sprintf("%v", receiveUserId))

			break
		}
	}
}
