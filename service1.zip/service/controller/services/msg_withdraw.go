package services

import (
	"fmt"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"strconv"
	"strings"
	"time"
)

const (
	ASSISTANT_ORDER_EXTRACT_PROCESSING = "assistant_order_extract_processing" //提现处理中
)

//提现处理中
func WithdrawProcessing(userId int64, amount int64) (err error) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(ASSISTANT_ORDER_EXTRACT_PROCESSING)
	if err != nil {
		utils.LogErrorF("获取体现处理model失败,err:%s", err.Error())
		return
	}
	date := time.Now().Format("2006年01月02日 15:04:05")
	//替换金额
	message := strings.NewReplacer("${amount}", strconv.Itoa(int(amount))).Replace(msgModel.MsgContent)
	//替换Go币
	message = strings.NewReplacer("${date}", date).Replace(message)
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TEXT,
		Title:             "",
		Text:              message,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, fmt.Sprint(userId))
	if err != nil {
		utils.LogErrorF("发送提现处理推送失败,err:%s", err.Error())
	}
	return nil
}
