package services

import (
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"strconv"
	"strings"
)

const (
	ASSISTANT_UNION_JOIN   = "assistant_union_join"   // 加入工会
	ASSISTANT_UNION_REFUSE = "assistant_union_refuse" // 被拒绝加入工会
)

type UnionMsg struct {
}

func InitUnionMsg() UnionMsg {
	return UnionMsg{}
}

// 加入公会
func (m UnionMsg) AssistantJoinUnion(userId, applyTime int64, unionName string) {
	key := ASSISTANT_UNION_JOIN
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(key)
	if err != nil {
		utils.LogErrorF("获取加入公会消息model失败,err:%s", err.Error())
		return
	}
	userIdStr := strconv.Itoa(int(userId))
	tmStr := utils.MsgTimeFormatDay(applyTime)
	tip := strings.NewReplacer("${apply_date}", tmStr, "${union_name}", unionName).Replace(msgModel.MsgContent)
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userIdStr)
	if err != nil {
		utils.LogErrorF("发送加入公会推送失败,err:%s", err.Error())
	}
	return
}

// 拒绝加入公会
func (m UnionMsg) AssistantRefuseUnion(userId, applyTime int64, unionName string) {
	key := ASSISTANT_UNION_REFUSE
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(key)
	if err != nil {
		utils.LogErrorF("获取拒绝加入公会消息model失败,err:%s", err.Error())
		return
	}
	userIdStr := strconv.Itoa(int(userId))
	tmStr := utils.MsgTimeFormatDay(applyTime)
	tip := strings.NewReplacer("${apply_date}", tmStr, "${union_name}", unionName).Replace(msgModel.MsgContent)
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userIdStr)
	if err != nil {
		utils.LogErrorF("发送拒绝加入公会推送失败,err:%s", err.Error())
	}
	return
}
