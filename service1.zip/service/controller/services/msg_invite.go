package services

import (
	"gamers/controller/services/liaoyiliao"
	"gamers/models/redismodels"
	"gamers/utils"
	"gamers/utils/tencent/tencentIm"
	"strconv"
	"time"
)

const (
	MaximumNums = 10 // 发送最多10个大神的撩一撩消息
)

// InviteMessage 大神撩一撩邀请消息
type InviteMessage struct {
}

type Content struct {
	UserID        int64  `gorm:"column:review_user_id"` // 大神id
	UserGender    int    `gorm:"column:user_gender"`    // 大神性别
	ReviewContent string `gorm:"column:review_content"` // 撩一撩邀请消息
	Status        int    `gorm:"column:review_status"`  // 0 审核 1 审核通过 2 审核拒绝
}

// Send 给新注册用户发送撩一撩邀请消息
func (InviteMessage) Send(userID int64) (err error) {
	// 查询满足条件的用户。是大神且在线
	var data []Content
	sql := "SELECT  r.review_user_id,u.user_gender,r.review_content,r.review_status " +
		"FROM system_user u " +
		"INNER JOIN app_invite_message_review r " +
		"ON u.user_id = r.review_user_id " +
		"WHERE u.user_is_online = ? AND u.user_is_sparring = ?"
	err = utils.GEngine.Raw(sql, 1, 1).Scan(&data).Error
	if err != nil {
		utils.LogErrorF("查询在线大神用户失败：%v", err)
		return
	}

	utils.LogInfoF("获取出来的大神数据-------> %v", data)

	// 按照优先级给用户发送撩一撩消息
	// 优先发送异性大神的消息，再是同性大神的消息。
	user, err := new(redismodels.UserInfo).GetUserInfo(userID)
	if err != nil {
		utils.LogErrorF("获取用户信息失败：%v", err)
		return
	}

	times := 0                    // 撩一撩消息发送次数
	sd := make(map[int64]Content) // 性别相同大神
	dd := make(map[int64]Content) // 性别不同的大神

	// 过滤处满足条件的大神用户
	for _, v := range data {
		// 撩一撩邀请消息为空或审核未通过状态，直接继续.
		if v.ReviewContent == "" || v.Status != 1 {
			continue
		}

		if len(dd) == MaximumNums {
			break
		}
		// 大神和用户性别不同
		if v.UserGender != user.UserGender {
			dd[v.UserID] = v
		}
		// 大神和用户性别相同
		if v.UserGender == user.UserGender {
			sd[v.UserID] = v
		}
	}
	utils.LogInfoF("缓存大神数据------->异性 %v，同性 %v", dd, sd)

	// 不同性别大神发送撩一撩消息,dd 最多10个数据
	for _, v := range dd {
		err = sendIMMsg(v, userID)
		if err != nil {
			utils.LogErrorF("%d 给用户 %d 发送撩一撩私聊消息失败。", v.UserID, userID)
			return
		}
		times++
	}

	if times == MaximumNums {
		return
	}

	// 发送相同性别
	for _, v := range sd {
		err = sendIMMsg(v, userID)
		if err != nil {
			utils.LogErrorF("%d 给用户 %d 发送撩一撩私聊消息失败。", v.UserID, userID)
			return
		}
		times++
		// 若已经达到 10 次就返回
		if times == MaximumNums {
			break
		}
	}

	utils.LogInfoF("总共发送消息次数 ----> %d", times)
	return

	// 4.21 版本 // 给用户发送撩一撩邀请信息私聊消息
	// for i, v := range data {
	// 	// 撩一撩邀请消息为空，直接继续.
	// 	if v.ReviewContent == "" || v.Status != 1 {
	// 		continue
	// 	}
	// 	// 超过 10 个结束
	// 	if i == 10 {
	// 		break
	// 	}
	//
	// 	// 给用户发送私聊消息
	// 	err = tencentIm.SendC2CSingleMsg(strconv.Itoa(int(v.UserID)), strconv.Itoa(int(userID)), v.ReviewContent)
	// 	if err != nil {
	// 		utils.LogErrorF("%d 给用户 %d 发送撩一撩私聊消息失败。", v.UserID, userID)
	// 		return
	// 	}
	// 	// 减少用户被撩次数
	// 	liaoyiliao.NewCacheMod().DecreaseUserNum(userID)
	//
	// 	// 时间间隔 1 秒
	// 	time.Sleep(time.Second)
	// }

	// return
}

// 发送撩一撩消息
func sendIMMsg(v Content, userID int64) (err error) {
	// 给用户发送私聊消息
	err = tencentIm.SendC2CSingleMsg(strconv.Itoa(int(v.UserID)), strconv.Itoa(int(userID)), v.ReviewContent)
	if err != nil {
		return
	}
	liaoyiliao.NewCacheMod().DecreaseUserNum(userID) // 减少用户被撩次数
	time.Sleep(time.Second)
	return
}
