package services

import (
	"gamers/utils/tencent/tencentIm"
	"strconv"
)

// 连接腾讯im拉黑
func BlackListAdd(userId, bannerId int64) (err error) {
	userStr := strconv.Itoa(int(userId))
	bannerStr := strconv.Itoa(int(bannerId))
	err = tencentIm.BlacklistAdd(userStr, bannerStr)
	return
}

// 取消拉黑
func BlackListDel(userId, bannerId int64) (err error) {
	userStr := strconv.Itoa(int(userId))
	bannerStr := strconv.Itoa(int(bannerId))
	err = tencentIm.BlacklistDel(userStr, bannerStr)
	return
}
