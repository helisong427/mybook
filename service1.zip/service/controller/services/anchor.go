package services

import (
	"gamers/controller/response"
	"gamers/models/dbmodels"
)

type AnchorCenter struct {
	response.GiftIncomeResult
	Ads []dbmodels.AppAdResutl `json:"ads"`
}

func GetAnchorCenter(userId int64) (data AnchorCenter, err error) {
	gift := dbmodels.AppRoomOpenLog{}
	//统计记录
	result, err := gift.GetLiveIncome(userId)
	if err != nil {
		return
	}
	ads, err := new(dbmodels.AppAd).QueryByPositionID(dbmodels.AD_POSITION_LIVE)
	if err != nil {
		return
	}
	data.Ads = ads
	data.TimeCount = result.TimeCount
	data.IncomeCount = result.IncomeCount
	return
}
