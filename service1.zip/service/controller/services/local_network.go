package services

import (
	"gamers/controller/request"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"strconv"
	"time"
)

//发送直播消息
func LocalLiveMsg(paramsJSON request.LocalLiveMsgReq) (err error) {
	room, err := new(dbmodels.AppLiveRoom).QueryRoomId(paramsJSON.RoomId)
	if err != nil {
		return
	}
	liveMsg := InitLiveMsg()
	switch paramsJSON.Func {
	case "AnnounceBanRoom":
		liveMsg.AnnounceBanRoom(&room)                        //禁封房间消息
		go redismodels.NewRoomHeat().Delete(int(room.RoomId)) //删除热度
	case "AnnounceBanRoomCancel":
		liveMsg.AnnounceBanRoomCancel(&room) //取消禁封房间消息
	case "AnnounceRectifyRoom":
		liveMsg.AnnounceRectifyRoom(&room)                    //整改房间消息
		go redismodels.NewRoomHeat().Delete(int(room.RoomId)) //删除热度
	case "AnnounceRectifyRoomCancel":
		liveMsg.AnnounceRectifyRoomCancel(&room) //取消整改房间消息
	default:
	}
	return
}

func LocalJoinUnionMsg(paramsJSON request.LocalJoinUnionMsgReq) (err error) {
	switch paramsJSON.Func {
	case "AssistantJoinUnion":
		new(UnionMsg).AssistantJoinUnion(paramsJSON.UserId, paramsJSON.ApplyTime, paramsJSON.UnionName)
	case "AssistantRefuseUnion":
		new(UnionMsg).AssistantRefuseUnion(paramsJSON.UserId, paramsJSON.ApplyTime, paramsJSON.UnionName)
	default:
	}
	return
}

func LocalAssistantTextMsg(paramsJSON request.LocalTextMsgReq) (err error) {
	AssistantTextMsg(paramsJSON.UserIdString, paramsJSON.Message)
	return
}

func LocalRankRoomSendCharmModifyMsg(notifyList []*redismodels.RankRoomSendCharmUpdateNotifyItem) {
	new(redismodels.RankRoomSendCharm).Init("hourly", time.Now(), redismodels.RankRoomItemLengthHourly).Notify(notifyList)
}

func LocalSparringReviewMsg(paramsJSON request.LocalSparringReviewMsgReq) (err error) {
	switch paramsJSON.Func {
	case "AgreeSparring":
		new(Sparring).Agree(paramsJSON.SkillName, paramsJSON.UserId)
	case "RefuseSparring":
		new(Sparring).Refuse(paramsJSON.SkillName, paramsJSON.Reason, paramsJSON.QQ, paramsJSON.UserId)
	default:
	}
	return
}

func LocalAnchorReviewMsg(paramsJSON request.LocalAnchorReviewMsgReq) (err error) {
	switch paramsJSON.Func {
	case "AgreeAnchor":
		new(Anchor).Agree(paramsJSON.SkillName, paramsJSON.UserId, paramsJSON.Url, paramsJSON.ApplyT)
	case "RefuseAnchor":
		new(Anchor).Refuse(paramsJSON.SkillName, paramsJSON.UserId, paramsJSON.ApplyT)
	default:
	}
	return
}

//订单申诉消息
func LocalOrderAppealMsg(paramsJSON request.LocalOrderAppealMsgReq) (err error) {
	switch paramsJSON.Func {
	case "UserSuccess2User":
		new(Backend).OrderUserAppealSuccessToUser(paramsJSON.OrderId, paramsJSON.UserId, paramsJSON.Amount)
	case "UserSuccess2Sparring":
		new(Backend).OrderUserAppealSuccessToSparring(paramsJSON.OrderId, paramsJSON.UserId, paramsJSON.Amount)
	case "UserFail2User":
		new(Backend).OrderUserAppealFailToUser(paramsJSON.OrderId, paramsJSON.UserId)
	case "UserFail2Sparring":
		new(Backend).OrderUserAppealFailToSparring(paramsJSON.OrderId, paramsJSON.UserId)
	default:
	}
	return
}

//动态审核不通过
func LocalTweetRefuseMsg(paramsJSON request.LocalTweetRefuseMsgReq) (err error) {
	new(Backend).TweetRefuse(paramsJSON.CheckTime, paramsJSON.UserId)
	return
}

//素材审核不通过消息(头像/相册图片)
func LocalMaterialRefuseMsg(paramsJSON request.LocalMaterialRefuseMsgReq) (err error) {
	new(Backend).MaterialRefuse(paramsJSON.CheckTime, paramsJSON.UserId)
	return
}

//房间资料不通过消息
func LocalStudioRefuseMsg(paramsJSON request.LocalStudioRefuseMsgReq) (err error) {
	new(Backend).StudioRefuse(paramsJSON.CheckTime, paramsJSON.UserId)
	return
}

//大神冻结消息
func LocalSparringForbiddenMsg(paramsJSON request.LocalSparringForbiddenMsgReq) (err error) {
	new(Backend).SparringForbidden(paramsJSON.SkillName, paramsJSON.QQ, paramsJSON.UserId)
	return
}

//提现失败
func LocalExtractFailMsg(paramsJSON request.LocalExtractFailMsgReq) (err error) {
	new(Backend).ExtractFail(paramsJSON.Tips, paramsJSON.UserId, paramsJSON.NickName, paramsJSON.ApplyTime)
	return
}

//提现成功
func LocalExtractSuccessMsg(paramsJSON request.LocalExtractSuccessMsgReq) (err error) {
	new(Backend).ExtractSuccess(paramsJSON.UserId, paramsJSON.ApplyTime)
	return
}

func LocalTransactionId(paramsJSON request.LocalTransactionIdReq) (idstring string) {
	id := dbmodels.IDBuilderGetId(utils.REDIS_IDBUILDER_TRANSACTION_ID)
	if id > 0 {
		idstring = strconv.FormatInt(id, 10)
	}
	return
}
