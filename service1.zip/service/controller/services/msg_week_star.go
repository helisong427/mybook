package services

import (
	"fmt"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
)

type WeekStarSendMsg struct {
}

func InitWeekStarSendMsg() *WeekStarSendMsg {
	return &WeekStarSendMsg{}
}

// 发送 赠送礼物消息

// 第一名
// 恭喜您在上期周星榜中获得XX榜第1名，您将获得以下奖励：
// 1、上期荣誉榜展示7天
// 2、XXX（X天）

// 其他名次
// 恭喜您在上期周星榜中获得XX榜X名，您将获得以下奖励：XXX（X天）

// 发送 赠送礼物消息
// sendType 1 为给第一名发 2为 给其他名次发
func (m *WeekStarSendMsg) SendGivenGiftMsg(userId, sendType int64, sendMsg string, msgModel dbmodels.AppMsgModel) (err error) {
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TITLE,
		Title:             msgModel.MsgTitle,
		Text:              sendMsg,
		NotificationClose: msgModel.MsgNotificationClose,
	}

	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	if err = msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, fmt.Sprint(userId)); err != nil {
		utils.LogErrorF("发送周星榜赠送礼物消息推送失败,err:%s", err.Error())
	}

	return err
}
