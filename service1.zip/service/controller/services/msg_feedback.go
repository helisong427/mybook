package services

import (
	"gamers/models/redismodels"
	"gamers/utils"
)

// 纯文本消息
func AssistantTextMsg(userIDString string, message string) {
	assistantMsg := &redismodels.AssistantMsg{
		Type:  redismodels.MSG_ASSISTANT_TYPE_TEXT,
		Title: "",
		Text:  message,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err := msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, userIDString)
	if err != nil {
		utils.LogErrorF("发送意见反馈推送失败,err:%s", err.Error())
	}
	return
}
