package services

import (
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/enum"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"gamers/utils/fdd"
	"gamers/utils/moderation"
	"gamers/utils/tencent/tencentIm"
	"gamers/utils/ymd"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/go-redis/redis"
	"gorm.io/gorm"
)

const ONE_DAY_TIMESTAMP = 24 * 60 * 60

func SetUserInfo(userId int64, paramsJSON request.SetUserInfoReq) (msg string, err error) {
	nickNameLen := len([]rune(paramsJSON.Nickname))
	if nickNameLen > 15 {
		return "昵称不能超过15个字符", fmt.Errorf("paramsJSON.Nickname len:%d", nickNameLen)
	}
	// 敏感词过滤
	moderationNickname := moderation.TextModeration(paramsJSON.Nickname)
	if len(moderationNickname) > 0 {
		return "昵称包含敏感字符", fmt.Errorf("paramsJSON.Nickname:%s", paramsJSON.Nickname)
	}

	moderationSlogan := moderation.TextModeration(paramsJSON.Slogan)
	if len(moderationSlogan) > 0 {

	}

	if len(paramsJSON.Images) > 4 {
		return "背景图最多4张", fmt.Errorf("paramsJSON.Images:%v", paramsJSON.Images)
	}

	// 星座计算
	t := time.Unix(int64(paramsJSON.Birthday), 0)
	constellation := utils.FuncGetConstellation(int(t.Month()), t.Day())

	update := make(map[string]interface{})
	update["user_nickname"] = paramsJSON.Nickname
	update["user_gender"] = paramsJSON.Gender
	update["user_birthday"] = paramsJSON.Birthday
	update["user_iconurl"] = paramsJSON.Iconurl
	update["user_constellation"] = constellation
	update["user_city_id"] = paramsJSON.CityID
	update["user_sound"] = paramsJSON.Sound
	update["user_sound_time"] = paramsJSON.SoundTime
	update["user_slogan"] = paramsJSON.Slogan
	// 修改信息后将审核状态改为未审核
	update["user_is_review"] = enum.MaterialIsNotReview

	if len(paramsJSON.Images) == 0 {
		update["user_back_image"] = ""
	} else {
		images, _ := json.Marshal(paramsJSON.Images)
		update["user_back_image"] = images
	}

	// 兴趣数组转下划线
	if len(paramsJSON.GameSavor) > 0 {
		var gameSavor string
		for _, v := range paramsJSON.GameSavor {
			gameSavor += strconv.Itoa(v) + "_"
		}
		update["user_game_savor"] = strings.TrimRight(gameSavor, "_")
	}
	err = new(dbmodels.SystemUser).Update(userId, update)
	if err != nil {
		return "用户信息设置失败", err
	}

	userModel, err := new(dbmodels.SystemUser).UserIdByUser(userId)
	if err != nil {
		return "获取用户信息失败", err
	}

	go new(redismodels.UserInfoUpdate).UpdateUserInfo(userModel)

	go tencentIm.PortraitSet(userId, userModel.UserNickname, userModel.UserIconurl)

	if update["user_back_image"] != "" {
		go func() {
			_ = new(redismodels.Task).Init().ReportConditionTag(userId, "uploadImagePhoto", 1)
		}()
	}
	if update["user_slogan"] != "" {
		go func() {
			_ = new(redismodels.Task).Init().ReportConditionTag(userId, "editPersonalSignature", 1)
		}()
	}
	go func() {
		skillIds, err := new(dbmodels.AppSparringSkill).GetUserSkillIdsByUserId(userId)
		if err != nil {
			utils.LogErrorF("查询用户[%d]技能失败，err：%s", userId, err.Error())
		}
		for _, v := range skillIds {
			utils.RedisClient.HDel(utils.REDIS_SPARRING_INFO, v)
		}
	}()

	return "", nil
}

// 记录用户中心访客记录
// LogUserId 被访问id
// userId 访客id
func SaveUserVisitorLog(logUserId, userId, visitType int64) (err error) {
	var (
		countCache string
	)

	// 如果被访问者和访问者相同, 直接驳回
	if logUserId == userId {
		return
	}

	key := fmt.Sprintf("%s%d:%d", utils.REDIS_USER_VISITOR, logUserId, userId)
	lock := key + ":lock"
	// 加锁
	lockVal, lockBool := utils.AcquireLock(lock, 1, 1)
	if !lockBool {
		return
	}
	defer utils.ReleaseLock(lock, lockVal)

	// 更新次数表
	go updateVisitCount(logUserId, userId, visitType)

	key = fmt.Sprintf("%s%d:%d:%d", utils.REDIS_USER_TODAY_VISITOR_COUNT, logUserId, userId, visitType)
	// 先查询是否存在 对应缓存 flag, 如果存在,则不再做下续 消息推送 操作
	if countCache = utils.RedisClient.Get(key).Val(); countCache != "" {
		return
	}

	go sendVisitMsg(logUserId, userId, visitType)

	// 设置缓存和过期时间, 过期时间为 当天十二点, 然后 进行消息推送
	// 设置 缓存flag
	expireTime := ymd.GetTodayZeroStamp() + ONE_DAY_TIMESTAMP - time.Now().Unix()
	if err = utils.RedisClient.Set(key, "1", time.Second*time.Duration(expireTime)).Err(); err != nil {
		utils.LogErrorF("set %v error: %v", key, err.Error())
		return
	}

	// 判断是否是新的访问用户
	if _, err = new(dbmodels.AppUserVisitor).QueryByUidAndType(logUserId, userId); err != nil {
		if err != gorm.ErrRecordNotFound {
			return
		}
	}

	if err == gorm.ErrRecordNotFound {
		// 创建访问日志
		model := &dbmodels.AppUserVisitorLog{
			LogUserId:        logUserId,
			LogType:          visitType,
			LogVisitorUserId: userId,
		}
		if err = model.Create(); err != nil {
			utils.LogErrorF("增加访客记录失败:%s", err.Error())
		}

		// 访客次数增加
		visitsKey := fmt.Sprintf("%s%d", utils.REDIS_USER_NEW_VISITOR_COUNT, logUserId)
		utils.RedisClient.Incr(visitsKey)
	}

	return
}

// 给大神发送推送消息
func sendVisitMsg(userId, visitUserId, visitType int64) {
	var (
		err         error
		appMsgModel dbmodels.AppMsgModel
		userInfo    dbmodels.SystemUser
		key         string
	)

	key = "sparring_visit_msg:" + fmt.Sprintf("%v", visitType)
	if appMsgModel, err = new(dbmodels.AppMsgModel).GetMsgByKey(key); err != nil {
		utils.LogErrorF("get app msg model error: %v", err.Error())
		return
	}

	if userInfo, err = new(dbmodels.SystemUser).QueryById(userId); err != nil {
		return
	}

	// 未开启推送或者不是大神
	if userInfo.UserIsForwardsNews == 0 || userInfo.UserIsSparring == 0 {
		return
	}

	// 黑名单判断
	if _, err = new(dbmodels.AppBlacklist).GetBlackByUid(userId, visitUserId); err != nil {
		if err != gorm.ErrRecordNotFound {
			return
		}
	} else {
		return
	}

	if userInfo, err = new(dbmodels.SystemUser).QueryById(visitUserId); err != nil {
		utils.LogErrorF("get visit user info error: %v", err.Error())
		return
	}

	// if err = InitSparringVisitSendMsg().SendGoGoMsg(userId, &userInfo, &appMsgModel); err != nil {
	// 	return
	// }

	if err = InitSparringVisitSendMsg().SendInteractiveMsg(&appMsgModel, userId, visitUserId, &userInfo); err != nil {
		return
	}
}

// 更新 操作
func updateVisitCount(logUserId, userId, visitType int64) {
	var (
		err         error
		visitRecord *dbmodels.AppUserVisitorResult
	)

	defer func() {
		// 用recover 防止 主程序崩溃, 让其余程序继续执行
		if revErr := recover(); revErr != nil {
			utils.LogErrorF("updateVisitCount error: %v", revErr)
			return
		}
	}()

	// 首先查询对应数据是否存在, 不存在则创建
	if visitRecord, err = new(dbmodels.AppUserVisitor).QueryByUidAndType(logUserId, userId); visitRecord == nil {
		utils.LogErrorF("get app_user_visitor record error: visit record nil")
		return
	}

	// 创建记录
	if err != gorm.ErrRecordNotFound && err != nil {
		utils.LogErrorF("get app_user_visitor record error: %v", err.Error())
		return
	}

	if err == gorm.ErrRecordNotFound {
		// 创建记录
		visitModel := &dbmodels.AppUserVisitor{
			VisitUserId:        logUserId,
			VisitType:          visitType,
			VisitVisitorUserId: userId,
			VisitLastTime:      time.Now().Unix(),
			VisitTimes:         1,
		}

		if err = visitModel.Create(); err != nil {
			utils.LogErrorF("create app_user_visitor record error: %v", err.Error())
		}

		return
	}

	// 更新次数
	if err = new(dbmodels.AppUserVisitor).Update(visitRecord.VisitId, map[string]interface{}{
		"visit_times":     gorm.Expr("visit_times + ?", 1),
		"visit_last_time": time.Now().Unix(),
		"visit_type":      visitType,
	}); err != nil {
		utils.LogErrorF("update visit_record error: %v", err.Error())
		return
	}

}

// 设置大神是否接受用户浏览推送消息
func SparringMessageSet(req *request.SparringMessageSetEdit, userId int64) (err error) {
	err = new(dbmodels.SystemUser).Update(userId, map[string]interface{}{
		"user_is_forwards_news": req.UserIsForwardsNews,
	})

	return
}

func GetUserIncome(userId int64, st int64, et int64) (data response.UserIncome, err error) {
	giftIncome, err := new(dbmodels.AppAnchorRoomProp).GetGiftIncome(userId, st, et)
	if err != nil {
		return
	}
	data.Income += giftIncome
	orderIncome, err := new(dbmodels.AppSkillOrder).GetOrderIncome(userId, st, et)
	if err != nil {
		return
	}
	data.Income += orderIncome
	return
}

// 获取用户card
func GetUserCard(userId, roomId int64) (data *response.UserCartRep, err error) {
	userInfo, err := new(redismodels.MsgUserObj).GetMsgUserInfo(userId, map[string]bool{"icon": true})
	if err != nil {
		return
	}
	// 查询粉丝数量
	fansCount, err := new(dbmodels.AppAttention).GetUserFollowedCount(userId)
	if err != nil {
		return
	}

	// 查询关注数量
	followsCount, err := new(dbmodels.AppAttention).GetUserFollowCount(userId)
	if err != nil {
		return
	}
	data = &response.UserCartRep{
		UserId:       userId,
		UserPrettyId: userInfo.UserPrettyId,
		Nickname:     userInfo.NickName,
		Gender:       userInfo.Gender,
		Iconurl:      userInfo.Icon,
		Slogan:       userInfo.UserSlogan,
		FansCount:    fansCount,
		FollowCount:  followsCount,
		Age:          userInfo.Age,
		VipLevel:     userInfo.VipLevel,
		IconStyle:    response.IconStyle{IconId: userInfo.IconStyle.IconId, BgUrl: userInfo.IconStyle.BgUrl},
		UserRole:     redismodels.WHEAT_ROLE_USER,
	}
	// 查询用户是否管理员
	admin, err := new(dbmodels.AppRoomAdmin).GetAnchorByUIdAndRId(userId, roomId)
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	if err == nil {
		data.UserRole = admin.AdminRole
	} else {
		data.UserRole = dbmodels.ROOM_ADMIN_ROLE_NORMAL
	}
	// 查询用户是否禁言
	key := utils.REDIS_LIVE_MUTE + strconv.Itoa(int(roomId)) + ":" + strconv.Itoa(int(userId))
	_, err = utils.RedisClient.Get(key).Result()
	if err != nil && err != redis.Nil {
		return
	}
	if err == nil {
		data.IsMute = 1
	} else {
		data.IsMute = 0
		err = nil
	}
	return
}

// 获取活体认证地址
func UserLiveAuthenticationUrl(userId int64) (msg string, r response.UserLiveAuthenticationUrlRep, err error) {
	msg = "获取认证地址失败"
	certification, err := new(dbmodels.Certification).QueryByUserId(userId)
	if err != err && err != gorm.ErrRecordNotFound {
		return
	}
	if certification.CertificationLivingStatus == dbmodels.CERTIFICATION_STATUS_LIVING_YES {
		msg = "活体认证已通过,无法重复认证"
		err = errors.New(msg)
		return
	}

	fddClient := fdd.NewFdd()
	// 合同模板填充
	contractId, err := fddClient.GenerateContract(userId)
	if err != nil {
		return
	}
	openid := fmt.Sprintf("%s_%d", os.Getenv("GIN_CONFIG"), userId)
	// 注册用户信息到fdd
	register, err := fddClient.AccountRegister(openid)
	if err != nil {
		return
	}
	// 获取认证地址
	personVerifyUrl, transactionId, err := fddClient.PersonVerifySign(contractId, register.Data)
	if err != nil {
		return
	}
	var (
		url                  []byte // 认证地址
		authenticationNumber string // 认证编号
	)
	authenticationNumber = personVerifyUrl.Data.VerifiedSerialNo

	url, err = base64.StdEncoding.DecodeString(personVerifyUrl.Data.Url)
	if err != nil {
		return
	}
	r.Url = string(url)

	// 用户认证信息
	if certification.CertificationId == 0 {
		model := dbmodels.Certification{
			CertificationId:                   userId,
			CertificationCustomerId:           register.Data,
			CertificationTransactionId:        transactionId,
			CertificationAuthenticationNumber: authenticationNumber,
			CertificationFadadaUrl:            string(url),
			CertificationContractId:           contractId,
			CertificationApplyTime:            time.Now().Unix(),
		}
		_, err = model.Create()
	} else {
		model := dbmodels.Certification{
			CertificationCustomerId:           register.Data,
			CertificationTransactionId:        transactionId,
			CertificationAuthenticationNumber: authenticationNumber,
			CertificationFadadaUrl:            string(url),
			CertificationContractId:           contractId,
			CertificationApplyTime:            time.Now().Unix(),
		}
		_, err = model.Update(userId)
	}
	return
}

// 初始化用户属性
func SetUserClientAttr(userId int64, clientType int) {
	clientStr := strconv.Itoa(clientType)
	userIdStr := strconv.Itoa(int(userId))
	item := make(map[string]string)
	item[enum.IM_USER_ATTR_SPARRING] = "0"
	item[enum.IM_USER_ATTR_ANCHOR] = "0"
	item[enum.IM_USER_ATTR_CLIENT] = clientStr
	err := tencentIm.AddUserAttr(userIdStr, item)
	if err != nil {
		utils.LogErrorF("设置用户属性失败,err:%s", err.Error())
	}
}

// 更新用户坐标
func UserUpdateCoordinate(userId int64, paramsJSON request.UserUpdateCoordinateReq) (err error) {
	update := make(map[string]interface{})
	update["user_longitude"] = paramsJSON.Longitude
	update["user_latitude"] = paramsJSON.Latitude
	err = new(dbmodels.SystemUser).Update(userId, update)
	return
}
