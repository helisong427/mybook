package speedmatching

import (
	"fmt"
	"strings"

	"gamers/controller/services"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
)

// 用户下单
// 给大神发匹配系统消息
func (s *SpeedMatching) sendMatchingSparringMsg(userIds []int64, text *redismodels.MatchingUserMsg) {
	userIdStr := make([]string, len(userIds))
	for k, v := range userIds {
		userIdStr[k] = fmt.Sprint(v)
	}
	msg := redismodels.MatchingMsg{
		MatchingType:    redismodels.MSG_MATCHING_USER,
		MatchingUserMsg: text,
	}
	err := msg.BatchSendMatchingMsg(userIdStr, redismodels.MSG_ADMIN_USER_SUPERMASTER)
	if err != nil {
		utils.LogErrorF("[给大神发匹配系统消息]推送失败,ids:%v,err:%s", userIds, err.Error())
		return
	}
}

// 自动取消给用户发gogo消息
func (s *SpeedMatching) sendGoGoCancelMsg(userId int64) {
	// 当前暂无大神抢单，您支付的金额已退回
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_TEXT,
		Text:              "当前暂无大神抢单，您支付的金额已退回",
		NotificationClose: 0,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err := msg.AssistantMsg.SendAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, fmt.Sprint(userId))
	if err != nil {
		utils.LogErrorF("[自动取消给用户发gogo消息]推送失败,err:%s", err.Error())
		return
	}
	s.sendMatchingCancelMsg(userId)
}

// 自动取消
// 给用户发送取消系统消息
func (s *SpeedMatching) sendMatchingCancelMsg(userId int64) {
	msg := redismodels.MatchingMsg{
		MatchingType: redismodels.MSG_MATCHING_CANCEL,
	}
	// 发送系统消息
	err := msg.SendMatchingMsg(redismodels.MSG_ADMIN_USER_SUPERMASTER, fmt.Sprint(userId))
	if err != nil {
		utils.LogErrorF("[给用户发送取消系统消息]发送消息失败,err:%s", err.Error())
		return
	}
}

// 大神抢单
// 给用户发送匹配系统消息
func (s *SpeedMatching) sendMatchingResultMsg(sparringUserId int64, userId int64, skillId int64) {
	msg, err := s.querySparringInfo(skillId)
	if err != nil {
		return
	}
	msg.MatchingSparringMsg.UserId = sparringUserId

	// 发送私聊消息
	err = msg.SendMatchingMsg(redismodels.MSG_ADMIN_USER_SUPERMASTER, fmt.Sprint(userId))
	if err != nil {
		utils.LogErrorF("[给用户发送匹配系统消息][%d]发送消息失败,err:%s", skillId, err.Error())
		return
	}
}

// 查询大神详细信息
func (s *SpeedMatching) querySparringInfo(skillId int64) (msg *redismodels.MatchingMsg, err error) {
	var (
		level      string
		feature    []redismodels.Feature // 特色
		featureMap map[string][]string   // 特色map
	)
	featureMap = make(map[string][]string)
	// 查询大神详情
	skill, err := new(dbmodels.AppSparringSkill).QueryBySkillId(skillId)
	if err != nil {
		utils.LogErrorF("[给用户发送匹配系统消息][%d]查询大神详情失败,err:%s", skillId, err.Error())
		return
	}
	// 获取好评率
	rate, err := new(dbmodels.AppSkillOrderComment).QueryFavorableRate(skillId)
	if err != nil {
		utils.LogErrorF("[给用户发送匹配系统消息][%d]获取好评率失败,err:%s", skillId, err.Error())
		return
	}
	// 获取游戏等级
	level = services.GetSkillLevel(skill.AppSparringSkillInfo, skill.AppSkill.SkillRequiredField)

	// 名片字段
	cardFields := strings.Split(skill.AppSkill.SkillCardFields, ",")
	if len(cardFields) > 0 {
		cardMap := make(map[string]struct{})
		for _, v := range cardFields {
			cardMap[v] = struct{}{}
		}
		for _, v := range skill.AppSparringSkillInfo {
			if _, ok := cardMap[v.AppSkillFieldValue.ValueField]; ok {
				featureMap[v.AppSkillFieldValue.ValueFieldName] = append(featureMap[v.AppSkillFieldValue.ValueFieldName], v.AppSkillFieldValue.ValueValue)
			}
		}

		for k, v := range featureMap {
			_feature := redismodels.Feature{
				FeatureName:   k,
				FeatureValues: v,
			}
			feature = append(feature, _feature)
		}
	}

	msg = &redismodels.MatchingMsg{
		MatchingType: redismodels.MSG_MATCHING_SPARRING,
		MatchingSparringMsg: &redismodels.MatchingSparringMsg{
			Avatar:        skill.SystemUser.UserIconurl,
			NickName:      skill.SystemUser.UserNickname,
			Level:         level,
			Feature:       feature,
			SkillIcon:     skill.AppSkill.SkillIconurl,
			SkillName:     skill.AppSkill.SkillName,
			SoundUrl:      skill.SkillSound,
			SoundTime:     skill.SkillSoundTime,
			ServiceNumber: skill.SkillOrderCount,
			FavorableRate: rate,
			Introduction:  skill.SkillInfo,
			Gender:        skill.SystemUser.UserGender,
			Age:           utils.FuncGetAge(int(skill.SystemUser.UserBirthday)),
		},
	}
	return
}
