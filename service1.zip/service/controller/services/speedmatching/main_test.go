package speedmatching

import (
	"gamers/utils"
	"os"
	"testing"
)

func TestMain(m *testing.M) {
	conf := "test"
	utils.ConfigInitLocal(conf)
	utils.LoggerInit()
	utils.GDBInit()
	utils.RedisInit()
	utils.RabbitMQInit()
	utils.InitSingLefLight()
	os.Exit(m.Run())
}
