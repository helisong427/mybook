package speedmatching

import (
	"gamers/controller/request"
	"gamers/models/dbmodels"
	"testing"
)

// 匹配参数测试
func TestParams(t *testing.T) {
	params, err := New().Params(1)
	if err != nil {
		t.Error(err)
		return
	}
	t.Log(params)
}

// 大神素材
func TestSparringMaterial(t *testing.T) {
	// for i := 0; i < 10; i++ {
	// 	go func() {
	// 		material, err := New().SparringMaterial()
	// 		if err != nil {
	// 			t.Error(err)
	// 			return
	// 		}
	// 		t.Log(material)
	// 	}()
	// }
	// for {
	//
	// }
	material, err := New().SparringMaterial()
	if err != nil {
		t.Error(err)
		return
	}
	t.Log(material)
}

// 用户下单
func TestPlaceOrder(t *testing.T) {
	paramsJSON := request.SMPlaceOrderReq{
		SkillId:                   60,
		Gender:                    0,
		Count:                     1,
		MatchingRemark:            "来个大神",
		MatchingOtherRequirements: nil,
	}
	paramsJSON.MatchingOtherRequirements = append(paramsJSON.MatchingOtherRequirements, request.MatchingOtherRequirementsReq{
		OtherKey:   "大区",
		OtherValue: "微信区",
	})
	paramsJSON.MatchingOtherRequirements = append(paramsJSON.MatchingOtherRequirements, request.MatchingOtherRequirementsReq{
		OtherKey:   "段位",
		OtherValue: "最强王者",
	})

	msg, balance, err := New().PlaceOrder(&paramsJSON, 1006749917)
	if err != nil {
		t.Log(msg + ":" + err.Error())
		return
	}
	t.Log(balance)
}

// 状态查询
func TestQueryStatus(t *testing.T) {
	status, err := New().QueryStatus(1)
	if err != nil {
		t.Error(err)
		return
	}
	t.Log(status)
}

// 完成处理
func TestSuccess(t *testing.T) {
	err := New().Success(4, 1)
	if err != nil {
		t.Error(err)
		return
	}
	t.Log("ok")
}

// 抢单中心
func TestOrderGrabbingCenter(t *testing.T) {
	msg, r, err := New().OrderGrabbingCenter(1, 10, 1006746017)
	if err != nil {
		t.Error(msg)
		t.Error(err)
		return
	}
	t.Log(r)
}

// 退款
func TestRefundHandler(t *testing.T) {
	msg, _, _, err := New().Refund(7, dbmodels.SPEED_MATCHING_STATUS_CANCEL, 1)
	if err != nil {
		t.Error(msg)
		t.Error(err)
		return
	}
	t.Log("ok")
}

// 抢单
func TestGrabbingOrders(t *testing.T) {
	// ch := make(chan string, 10)
	// for i := 0; i < 10; i++ {
	// 	go func(i int) {
	// 		msg, err := New().GrabbingOrders(27, 1006081825)
	// 		if err != nil {
	// 			ch <- fmt.Sprintf("id:%d,msg:%s,err:%s", i, msg, err.Error())
	// 			return
	// 		}
	// 		ch <- fmt.Sprintf("id:%d,ok!", i)
	// 	}(i)
	// }
	//
	// for i := 0; i < 10; i++ {
	// 	t.Log(<-ch)
	// }

	msg, status, err := New().GrabbingOrders(27, 1006081825)
	if err != nil {
		t.Error(msg)
		t.Error(err)
		return
	}
	t.Log(status)
}

// TestRematch 重新匹配
func TestRematch(t *testing.T) {
	msg, r, err := New().Rematch(1006766216)
	if err != nil {
		t.Errorf("msg: %s, err: %v", msg, err)
		return
	}

	t.Log(r)
}
