package services

import (
	"errors"
	"fmt"
	"regexp"
	"sort"
	"strconv"
	"time"

	"github.com/go-redis/redis"

	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"gamers/utils/prop"
	"gamers/utils/trydo"
)

// 砸蛋
func EggBreak(userId int64, req *request.EggBreakReq) (*response.EggBreakResp, string, error) {
	if req.EggbreakCount <= 0 {
		return nil, "砸蛋失败0", errors.New("error params eggbreak_count")
	}

	var eggBreakId = req.EggbreakId
	eggData, err := (&dbmodels.AppEggbreak{}).QueryByEggbreakId(int64(eggBreakId))
	if err != nil {
		return nil, "砸蛋失败1", errors.New("error params eggbreak_id")
	}

	var resp = &response.EggBreakResp{
		EggbreakId:            req.EggbreakId,
		EggbreakCount:         req.EggbreakCount,
		EggbreakCostPropType:  prop.Type(eggData.EggbreakCostPropType),
		EggbreakCostPropId:    int(eggData.EggbreakCostPropId),
		EggbreakCostPropCount: int(eggData.EggbreakCostPropCount) * req.EggbreakCount,
		EggbreakDetails:       nil,
	}

	if valid, _ := (&dbmodels.AppBackpack{}).CheckEnough(userId, eggData.EggbreakCostPropId, eggData.EggbreakCostPropCount*int64(req.EggbreakCount)); !valid {
		return nil, "物品不足", errors.New("not enough props")
	}

	propMaps, propLength, err := GetEggBreakRewardsFromPool(req.EggbreakId, req.EggbreakCount)
	if err != nil {
		return nil, "砸蛋失败2", err
	}

	// 获取的奖励不足，尝试生成新的奖励池子，并再补足奖励
	if propLength < req.EggbreakCount {
		var realErr = err
		if err := buildEggBreakPool(req.EggbreakId); err != nil {
			realErr = err
		}
		var succeed = trydo.DoWithIntervals([]time.Duration{
			time.Millisecond * 100,
			time.Millisecond * 100,
			time.Millisecond * 100,
			time.Millisecond * 100,
			time.Millisecond * 100,
			time.Millisecond * 100,
			time.Millisecond * 100,
		}, func() (isOver bool) {
			var leftRewards, leftPropLength, err = GetEggBreakRewardsFromPool(req.EggbreakId, req.EggbreakCount-propLength)
			if err != nil {
				realErr = err
				return false
			}

			if leftPropLength > 0 {
				mergeEggBreakPropMaps(propMaps, leftRewards)
				propLength += leftPropLength
				if propLength == req.EggbreakCount {
					return true
				}
			}

			if err := buildEggBreakPool(req.EggbreakId); err != nil {
				realErr = err
			}
			return false
		})
		if !succeed {
			if realErr == nil {
				realErr = errors.New("get egg break rewards failed")
			}
			return nil, "砸蛋失败3", realErr
		}
	}

	// 如果仍然不足，直接返回失败
	if propLength < req.EggbreakCount {
		return nil, "砸蛋失败4", errors.New("get egg break rewards failed")
	}

	resp.EggbreakDetails = convertEggBreakPropMaps(propMaps)
	if err := completeEggBreakPropInfos(resp); err != nil {
		return nil, "砸蛋失败5", err
	}

	var hammerCount int64
	if hammerCount, err = dealEggBreakResult(userId, resp); err != nil {
		return nil, "砸蛋失败6", err
	}
	resp.EggbreakHammerCount = hammerCount

	// 各种日志，排行榜等
	dealEggBreakFollowUp(userId, req, resp)

	return resp, "砸蛋成功7", nil
}

// 重新生成缓存奖励池子
func buildEggBreakPool(eggBreakId int) error {
	var redisKey = fmt.Sprintf("%s%d", utils.REDIS_EGGBREAK_POOL_INIT, eggBreakId)
	var lockVal, isLock = utils.AcquireLock(redisKey, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
	if !isLock {
		return errors.New("init egg break pool failed")
	}
	defer utils.ReleaseLock(redisKey, lockVal)

	var poolLotteryKey = fmt.Sprintf("%s%d", utils.REDIS_EGGBREAK_POOL_LOTTERY_LIST, eggBreakId)
	var val, err = utils.RedisClient.LLen(poolLotteryKey).Result()
	if err != nil {
		return err
	}
	if val > 0 {
		return nil
	}

	builder := redismodels.NewEggbreak()
	if err := builder.Init(int64(eggBreakId)); err != nil {
		return err
	}
	return nil
}

// 从奖励池子获得对应个数的奖励
func GetEggBreakRewardsFromPool(eggBreakId int, getCount int) (map[int]*response.EggBreakRewardDetail, int, error) {
	var script = redis.NewScript(`
local poolLotteryKey = tostring(KEYS[1])
local poolStatusKey = tostring(KEYS[2])
local getCount = tonumber(ARGV[1])
local realGetCount = 0
local valMap = {}
local valArr = {}
for _ = 1, getCount, 1 do
    local data = redis.call("rPop", poolLotteryKey)
    if data == false then
        break
    end

    local key = tostring(data)
    realGetCount = realGetCount + 1
    valArr[realGetCount] = key

    if valMap[key] == nil then
        valMap[key] = 0
    end
    valMap[key] = valMap[key] + 1
end

for fieldKey, decCount in pairs(valMap) do
    local data = redis.call("hGet", poolStatusKey, fieldKey)
    if data ~= false then
        local orgCount = tonumber(data)
        redis.call("hSet", poolStatusKey, fieldKey, orgCount - decCount)
    end
end

return valArr
`)

	var poolLotteryKey = fmt.Sprintf("%s%d", utils.REDIS_EGGBREAK_POOL_LOTTERY_LIST, eggBreakId)
	var poolStatusKey = fmt.Sprintf("%s%d", utils.REDIS_EGGBREAK_POOL_STATUS, eggBreakId)

	retVal, retErr := script.Eval(utils.RedisClient, []string{
		poolLotteryKey,
		poolStatusKey,
	}, getCount).Result()

	if retErr != nil {
		return nil, 0, retErr
	}

	var propMaps = map[int]*response.EggBreakRewardDetail{} // prop_id
	var keyRegexp = regexp.MustCompile("([^:]+)")
	var retList = retVal.([]interface{})
	for _, v := range retList {
		var key = v.(string)
		// 小蛋池id:奖励id:礼物id:礼物价格
		var parsed = keyRegexp.FindAllString(key, -1)
		if len(parsed) != 4 {
			return nil, 0, errors.New("error config")
		}
		var propId, err = strconv.ParseInt(parsed[2], 10, 64)
		if err != nil {
			return nil, 0, err
		}
		var propOrgPrice, errPrice = strconv.ParseInt(parsed[3], 10, 64)
		if errPrice != nil {
			return nil, 0, errPrice
		}

		if item, prs := propMaps[int(propId)]; prs {
			item.PropCount += 1
		} else {
			propMaps[int(propId)] = &response.EggBreakRewardDetail{
				PropType:     prop.UnexpectedType, // 未知，由配置补全
				PropId:       int(propId),
				PropCount:    1,
				PropOrgPrice: propOrgPrice,
			}
		}
	}
	return propMaps, len(retList), nil
}

func mergeEggBreakPropMaps(dst map[int]*response.EggBreakRewardDetail, src map[int]*response.EggBreakRewardDetail) {
	for _, v := range src {
		if _, prs := dst[v.PropId]; prs {
			dst[v.PropId].PropCount += src[v.PropId].PropCount
		} else {
			dst[v.PropId] = v
		}
	}
}

func convertEggBreakPropMaps(src map[int]*response.EggBreakRewardDetail) []*response.EggBreakRewardDetail {
	var ret []*response.EggBreakRewardDetail
	for _, v := range src {
		ret = append(ret, v)
	}
	// 砸蛋结果按照单价排序
	sort.Slice(ret, func(i, j int) bool {
		return ret[i].PropOrgPrice > ret[j].PropOrgPrice
	})
	return ret
}

// 根据物品配置补全物品信息
func completeEggBreakPropInfos(resp *response.EggBreakResp) error {
	resp.EggbreakTotalPrice = 0
	for _, v := range resp.EggbreakDetails {
		var cfg, err = (&dbmodels.AppProp{}).GetPropConfigById(int64(v.PropId))
		if err != nil {
			return err
		}
		v.PropType = prop.Type(cfg.PropType)
		v.PropExpiredType = cfg.PropExpiredType
		v.PropExpiredTime = cfg.PropExpiredTime
		v.PropOrgPrice = cfg.PropOrgPrice
		v.PropGetRadio1 = cfg.PropGetRadio1
		v.PropName = cfg.PropName
		v.PropAttrId = cfg.PropAttrId
		v.PropIcon = cfg.PropIcon
		resp.EggbreakTotalPrice += cfg.PropOrgPrice * int64(v.PropCount)
	}
	return nil
}

const (
	EGGBREAK_LOCK_TIME_OUT = 10
)

// 处理砸蛋结果(扣东西，加东西etc)
func dealEggBreakResult(userId int64, resp *response.EggBreakResp) (hammerCount int64, err error) {
	var redisKey = fmt.Sprintf("%s%d", utils.REDIS_BACKPACK_LOCK, userId)
	var lockVal, isLock = utils.AcquireLock(redisKey, EGGBREAK_LOCK_TIME_OUT, EGGBREAK_LOCK_TIME_OUT)
	if !isLock {
		return 0, errors.New("lock failed")
	}
	defer utils.ReleaseLock(redisKey, lockVal)

	var tx = utils.GEngine.Begin()

	var alteredBackpackList []*dbmodels.AppBackpack

	{
		var backpack = new(dbmodels.AppBackpack)
		if err := backpack.Dec(tx, userId, resp.EggbreakCostPropId, resp.EggbreakCostPropCount); err != nil {
			tx.Rollback()
			return 0, err
		}
		hammerCount = backpack.BackpackCount
		alteredBackpackList = append(alteredBackpackList, backpack)
	}

	for _, v := range resp.EggbreakDetails {
		var backpack = &dbmodels.AppBackpack{
			BackpackUserId:      userId,
			BackpackPropType:    int(v.PropType),
			BackpackPropId:      int64(v.PropId),
			BackpackCount:       int64(v.PropCount),
			BackpackPropAttrId:  v.PropAttrId,
			BackpackExpiredTime: 0,
		}
		if err := backpack.Add(tx); err != nil {
			tx.Rollback()
			return 0, err
		}
		alteredBackpackList = append(alteredBackpackList, backpack)
	}

	err = tx.Commit().Error

	if err == nil {
		var redisFields []string
		for _, v := range alteredBackpackList {
			if prop.Type(v.BackpackPropType) == prop.TypeGift {
				var field = fmt.Sprintf("%d", v.BackpackId)
				redisFields = append(redisFields, field)
			}
		}
		if len(redisFields) > 0 {
			// 直接删除缓存
			var redisKey = fmt.Sprintf("%s%d", utils.REDIS_LIVE_GIFT_BACKPACK, userId)
			_ = utils.RedisClient.HDel(redisKey, redisFields...).Err()
		}
	}

	return
}

// 处理砸蛋后续
func dealEggBreakFollowUp(userId int64, req *request.EggBreakReq, resp *response.EggBreakResp) {
	// 记录砸蛋日志
	var recordId = dbmodels.IDBuilderGetId(utils.REDIS_IDBUILDER_EGGBREAK_RECORD_ID)
	var logs []*dbmodels.AppEggBreakLog
	for _, v := range resp.EggbreakDetails {
		logs = append(logs, &dbmodels.AppEggBreakLog{
			LogRecordId:   recordId,
			LogUserId:     userId,
			LogEggbreakId: resp.EggbreakId,

			LogEggbreakCount: resp.EggbreakCount,
			LogCostPropType:  resp.EggbreakCostPropType,
			LogCostPropId:    resp.EggbreakCostPropId,
			LogCostPropCount: resp.EggbreakCostPropCount,
			LogPropType:      v.PropType,
			LogPropId:        v.PropId,
			LogPropCount:     v.PropCount,
			LogRoomId:        req.RoomId,
		})
	}
	_ = (&dbmodels.AppEggBreakLog{}).Log(logs)

	// 任务触发
	go func() {
		_ = new(redismodels.Task).Init().ReportConditionTag(userId, "eggBreakBreak", uint32(req.EggbreakCount))
	}()

	// 排行相关
	go eggBreakFollowUpRank(userId, req, resp)
	// 各种消息通知
	go eggBreakFollowUpSendMsg(userId, req, resp)
}

func eggBreakFollowUpRank(userId int64, req *request.EggBreakReq, resp *response.EggBreakResp) {
	var nowTime = time.Now()

	trydo.DoWithIntervals([]time.Duration{
		time.Millisecond * 0,
		time.Millisecond * 100,
		time.Millisecond * 200,
		time.Millisecond * 200,
		time.Millisecond * 200,
		time.Millisecond * 200,
		time.Millisecond * 200,
		time.Millisecond * 200,
		time.Millisecond * 200,
		time.Millisecond * 200,
	}, func() (isOver bool) {
		var redisKey = fmt.Sprintf("%s%d", utils.REDIS_EGGBREAK_RECORDER, userId)
		var lockVal, isLock = utils.AcquireLock(redisKey, utils.DEFAULT_LOCK_ACQUIRE_TIMEOUT, utils.DEFAULT_LOCK_KEY_TIMEOUT)
		if !isLock {
			return false
		}
		defer utils.ReleaseLock(redisKey, lockVal)

		// rank_day
		for _, v := range resp.EggbreakDetails {
			(&dbmodels.AppEggBreakRankDetailDay{
				DetailEggbreakId: resp.EggbreakId,
				DetailUserId:     userId,
				DetailPropType:   v.PropType,
				DetailPropId:     v.PropId,
				DetailPropCount:  v.PropCount,
				TriggerTime:      nowTime,
			}).Log()
		}
		(&dbmodels.AppEggBreakRankDay{
			RankEggbreakId: resp.EggbreakId,
			RankUserId:     userId,
			RankTotalPrice: resp.EggbreakTotalPrice,
			TriggerTime:    nowTime,
		}).Log()

		// rank_week
		for _, v := range resp.EggbreakDetails {
			(&dbmodels.AppEggBreakRankDetailWeek{
				DetailEggbreakId: resp.EggbreakId,
				DetailUserId:     userId,
				DetailPropType:   v.PropType,
				DetailPropId:     v.PropId,
				DetailPropCount:  v.PropCount,
				TriggerTime:      nowTime,
			}).Log()
		}
		(&dbmodels.AppEggBreakRankWeek{
			RankEggbreakId: resp.EggbreakId,
			RankUserId:     userId,
			RankTotalPrice: resp.EggbreakTotalPrice,
			TriggerTime:    nowTime,
		}).Log()

		return true
	})
}

func eggBreakFollowUpSendMsg(userId int64, req *request.EggBreakReq, resp *response.EggBreakResp) {
	var ntcPropInfos []*redismodels.PropInfo
	var headlineNtcPropInfos []*redismodels.PropInfo
	for _, v := range resp.EggbreakDetails {
		ntcPropInfos = append(ntcPropInfos, &redismodels.PropInfo{
			PropType:  int(v.PropType),
			PropId:    int64(v.PropId),
			PropCount: int64(v.PropCount),
			PropName:  v.PropName,
		})
		// 全服跑马灯
		if v.PropGetRadio1 != 0 {
			headlineNtcPropInfos = append(headlineNtcPropInfos, &redismodels.PropInfo{
				PropType:      int(v.PropType),
				PropId:        int64(v.PropId),
				PropCount:     int64(v.PropCount),
				PropName:      v.PropName,
				PropGetRadio1: v.PropGetRadio1,
			})
		}
	}
	if len(ntcPropInfos) == 0 && len(headlineNtcPropInfos) == 0 {
		return
	}

	roomData, err := new(dbmodels.AppLiveRoom).QueryRoomId(req.RoomId)
	if err != nil {
		return
	}

	triggerMsgUserObj, err := (&redismodels.MsgUserObj{}).GetMsgUserInfo(userId, map[string]bool{})
	if err != nil {
		utils.LogErrorF("发送消息失败： %s", err.Error())
		return
	}

	// 跑马灯消息
	if len(headlineNtcPropInfos) != 0 {
		go new(LiveMsg).HeadlineMsgBreakEgg(&roomData, &triggerMsgUserObj, headlineNtcPropInfos)
	}

	// 房间内消息
	if len(ntcPropInfos) != 0 {
		// 检查 Room 是否允许发送消息
		if roomData.RoomEggbreakMsg != 0 {
			return
		}

		// 检查个人是否允许发送消息
		userEggbreakMsg, err := new(redismodels.UserInfo).GetUserEggbreakMsg(userId)
		if err != nil {
			return
		}
		if userEggbreakMsg != 0 {
			return
		}

		msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(LIVE_KEY_BREAK_EGG)
		if err != nil {
			utils.LogErrorF("获取砸蛋消息model失败,err:%s", err.Error())
			return
		}

		// 一个物品一条消息
		var length = len(ntcPropInfos)
		for i := 0; i < length; i++ {
			msg := redismodels.LiveMsg{
				FromAccount: &triggerMsgUserObj,
				Type:        redismodels.MSG_TYPE_BREAK_EGG,
				ContentType: redismodels.CONTENT_TYPE_CMD,
				Content:     msgModel.MsgContent,
				CMD:         redismodels.CMD_TYPE_BREAK_EGG,
				MsgStyle: &redismodels.MsgStyle{
					PrimaryColor: redismodels.MSG_STYLE_PRIMARYCOLOR_WHITE,
					SecondColor:  redismodels.MSG_STYLE_SECOND_YELLOW,
				},
				PropInfo: ntcPropInfos[i : i+1],
			}
			err = msg.SendLiveMsg(strconv.Itoa(req.RoomId))
			if err != nil {
				utils.LogErrorF("发送消息失败：%s", err.Error())
			}
		}
	}
}
