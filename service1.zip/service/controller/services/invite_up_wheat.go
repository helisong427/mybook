package services

import (
	"encoding/json"
	"gamers/models/redismodels"
	"gamers/utils"
	"strconv"
	"time"
)

const (
	RedisInviteUpWheatExpire = 60 * 15 * time.Second
)

type InviteUpWheat struct {
	RoomId        int   `json:"room_id"`         // 房间id
	UserId        int   `json:"user_id"`         // 邀请人的用户id
	WheatKey      int   `json:"wheat_key"`       // 麦位
	InvitedUserId int   `json:"invited_user_id"` // 被邀请的用户id
	CreateT       int64 `json:"create_t"`        // 邀请时间
}

func (m *InviteUpWheat) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, m)
}

func (m InviteUpWheat) MarshalBinary() ([]byte, error) {
	return json.Marshal(m)
}

// 邀请上麦
func (m *InviteUpWheat) InviteUpWheat() (err error) {
	roomIdStr := strconv.Itoa(m.RoomId)
	invitedUserIdStr := strconv.Itoa(m.InvitedUserId)
	key := utils.RedisInviteUpWheat + roomIdStr + ":" + invitedUserIdStr
	err = utils.RedisClient.Set(key, m, RedisInviteUpWheatExpire).Err()
	if err != nil {
		return
	}
	// 存储所有key，切换模式后删除
	err = utils.RedisClient.RPush(utils.RedisInviteUpWheatList+roomIdStr, key).Err()
	if err != nil {
		return
	}
	return
}

// 接受邀请上麦
func (m *InviteUpWheat) AcceptUpWheat() (err error, message string, wheat redismodels.Wheat) {
	roomIdStr := strconv.Itoa(m.RoomId)
	invitedUserIdStr := strconv.Itoa(m.InvitedUserId)
	key := utils.RedisInviteUpWheat + roomIdStr + ":" + invitedUserIdStr
	var inviteUpWheat InviteUpWheat
	err = utils.RedisClient.Get(key).Scan(&inviteUpWheat)
	if err != nil {
		message = "邀请已过期，请重新联系管理员"
		return
	}
	wheat, err = new(redismodels.Wheat).UpAndDownWheat(m.RoomId, int64(m.InvitedUserId), inviteUpWheat.WheatKey, redismodels.WHEAT_UP)
	if err != nil {
		if err != redismodels.ErrWheatIsAlreadyOccupied {
			message = "上麦失败"
			return
		}
		message = "当前麦位已被占据，请联系管理员重新邀请"
		return
	}
	// 接受邀请后删除邀请记录
	err = utils.RedisClient.Del(key).Err()
	if err != nil {
		message = "服务器错误"
		return
	}
	return
}

// 拒接邀请上麦
func (m *InviteUpWheat) RefuseUpWheat() (err error) {
	roomIdStr := strconv.Itoa(m.RoomId)
	invitedUserIdStr := strconv.Itoa(m.InvitedUserId)
	key := utils.RedisInviteUpWheat + roomIdStr + ":" + invitedUserIdStr
	err = utils.RedisClient.Del(key).Err()
	if err != nil {
		return
	}
	return
}

// 删除邀请上麦的所有记录
func (m *InviteUpWheat) RemoveInviteUpWheatLog() (err error) {
	key := utils.RedisInviteUpWheatList + strconv.Itoa(m.RoomId)
	lists, err := utils.RedisClient.LRange(key, 0, -1).Result()
	if err != nil {
		return
	}
	pipeline := utils.RedisClient.Pipeline()
	for _, v := range lists {
		pipeline.Del(v)
	}
	_, err = pipeline.Exec()
	if err != nil {
		return
	}
	err = utils.RedisClient.Del(key).Err()
	if err != nil {
		return
	}
	return
}
