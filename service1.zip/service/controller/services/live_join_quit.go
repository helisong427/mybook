package services

import (
	"encoding/json"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/mq/rabbitmqProducer"
	"gamers/utils"
	"strconv"
	"time"

	"github.com/go-redis/redis"
	"gorm.io/gorm"
)

const DEFAULT_USER_JOIN_ROOM_TIMEOUT = 60 * 60 * 24 * time.Second
const DEFAULT_JOIN_ROOM_TASK_TIME = 60 * 10

type JoinRoomCache struct {
	*redismodels.MsgUserObj
	JoinT int64 `json:"join_t"`
}

func (s *JoinRoomCache) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s JoinRoomCache) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

func AfterExitWheat(userIdStr, roomIdStr string) {
	key := utils.REDIS_LIVE_JOIN_USER + userIdStr
	err := utils.RedisClient.Del(key).Err()
	if err != nil {
		utils.LogErrorF("删除用户[%s]加入的房间[%s]信息失败%s", roomIdStr, userIdStr, err.Error())
		// return
	}
	roomId, _ := strconv.Atoi(roomIdStr)
	userId, _ := strconv.Atoi(userIdStr)

	room, err := new(dbmodels.AppLiveRoom).QueryRoomId(roomId)
	if err != nil {
		utils.LogErrorF("直播间不存在, %s, %v, %v", roomIdStr, userId, err.Error())
	}
	memberNum, err := utils.RedisClient.IncrBy(utils.REDIS_LIVE_ONLINE_MEMBER_NUM+roomIdStr, -1).Result()
	if err != nil && err != redis.Nil {
		utils.LogErrorF("更新用户在线人员失败, %s, %v, %v", roomIdStr, userIdStr, err.Error())
	}
	if memberNum < 0 {
		err = utils.RedisClient.Set(utils.REDIS_LIVE_ONLINE_MEMBER_NUM+roomIdStr, 0, DEFAULT_USER_JOIN_ROOM_TIMEOUT).Err()
	}

	// 从本地缓存的直播间移除
	err = utils.RedisClient.HDel(utils.REDIS_LIVE_ONLINE_MEMBER+roomIdStr, userIdStr).Err()
	if err != nil {
		utils.LogErrorF("移除房间[%s]的用户[%s]失败, %s", roomIdStr, userId, err.Error())
	}
	// 删除麦位
	isChanged, wheat, position, err := new(redismodels.Wheat).SystemDown(roomId, userId)
	if err != nil {
		utils.LogErrorF("删除麦位失败%s,%s", key, err.Error())
		return
	}
	// 主持麦位，推送关闭房间消息
	if isChanged && position == 0 && room.RoomType == dbmodels.ROOM_TYPE_PARTY {
		rabbitmqProducer.ProducerCloseRoom(roomId)
	}

	if isChanged {
		// 发送IM消息通知用户下麦
		new(LiveMsg).AnnounceUpDownWheat(&room, &wheat, redismodels.WHEAT_DOWN, int64(userId))
	}

	// 删除麦序
	isChanged, d, err := new(redismodels.WheatQueue).SystemDown(roomId, userId)
	if err != nil {
		if err != redis.Nil {
			utils.LogErrorF("删除麦序失败%s,%s", key, err.Error())
			return
		}
	}
	if isChanged {
		// 发送IM消息通知取消排麦
		new(LiveMsg).AnnounceChancelWheatQueue(&room, d)
	}

	if room.RoomType == dbmodels.ROOM_TYPE_LIVE && int(room.RoomUserId) == userId && room.RoomLiveStatus == dbmodels.ROOM_LIVE_STATUS_ON {
		err = new(dbmodels.AppLiveRoom).UpdateLiveStatus(roomId, dbmodels.ROOM_LIVE_STATUS_TIMEOUT)
		if err != nil {
			utils.LogErrorF("修改房间状态为下播失败%s,%s", key, err.Error())
			return
		}
		go redismodels.NewRoomHeat().Delete(roomId)
		new(LiveMsg).AnnounceConfirmDownload(&room, true)
	}
}

// 进入直播间处理用户信息
func JoinLiveRoom(liveRoom *dbmodels.AppLiveRoom, userInfo *redismodels.MsgUserObj) (err error) {
	userIdStr := strconv.Itoa(int(userInfo.UserId))
	roomIdStr := strconv.Itoa(int(liveRoom.RoomId))
	// 判断是否存在房间
	oldRoomStr, err := utils.RedisClient.Get(utils.REDIS_LIVE_JOIN_USER + userIdStr).Result()
	if err != nil && err != redis.Nil {
		utils.LogErrorF("查询用户加入的房间信息失败:userId[%s],err:%s", userIdStr, err.Error())
	}
	// 如果存在
	if err == nil {
		if roomIdStr != oldRoomStr {
			err = utils.RedisClient.HDel(utils.REDIS_LIVE_ONLINE_MEMBER+oldRoomStr, userIdStr).Err()
			if err != nil {
				utils.LogErrorF("缓存用户到[%s][%s]失败, %s", roomIdStr, userIdStr, err.Error())
			}
			AfterExitWheat(userIdStr, oldRoomStr)
		} else {
			return
		}
	}
	// 储存用户加入的房间信息
	err = utils.RedisClient.Set(utils.REDIS_LIVE_JOIN_USER+userIdStr, roomIdStr, DEFAULT_USER_JOIN_ROOM_TIMEOUT).Err()
	if err != nil {
		utils.LogErrorF("储存用户加入的房间信息失败:userId[%s],房间groupId[%s],err:%s", userIdStr, roomIdStr, err.Error())
	}
	// 查询用户角色
	var adminModel dbmodels.AppRoomAdmin
	admin, err := adminModel.GetAnchorByUIdAndRId(userInfo.UserId, liveRoom.RoomId)
	if err != nil && err != gorm.ErrRecordNotFound {
		utils.LogErrorF("查询房间[%d]的管理员[%d]错误的失败，err:%s", liveRoom.RoomId, userInfo.UserId, err.Error())
		return
	}
	if err == nil {
		userInfo.Role = admin.AdminRole
	} else {
		userInfo.Role = dbmodels.ROOM_ADMIN_ROLE_NORMAL
	}
	data := JoinRoomCache{
		MsgUserObj: userInfo,
		JoinT:      time.Now().Unix(),
	}
	err = utils.RedisClient.HSet(utils.REDIS_LIVE_ONLINE_MEMBER+roomIdStr, userIdStr, data).Err()
	if err != nil {
		utils.LogErrorF("缓存用户到[%s][%s]失败, %s", roomIdStr, userIdStr, err.Error())
	}
	err = utils.RedisClient.IncrBy(utils.REDIS_LIVE_ONLINE_MEMBER_NUM+roomIdStr, 1).Err()
	if err != nil {
		utils.LogErrorF("缓存用户在线人员失败, %s, %v, %v", roomIdStr, userIdStr, err.Error())
	}
	liveMsg := InitLiveMsg()
	go liveMsg.JoinLiveMsg(liveRoom, userInfo)
	return
}

// 退出直播间处理用户信息
func QuitLiveRoom(liveRoom *dbmodels.AppLiveRoom, userInfo *redismodels.MsgUserObj) (err error) {
	var form JoinRoomCache
	userIdStr := strconv.Itoa(int(userInfo.UserId))
	roomIdStr := strconv.Itoa(int(liveRoom.RoomId))
	err = utils.RedisClient.HGet(utils.REDIS_LIVE_ONLINE_MEMBER+roomIdStr, userIdStr).Scan(&form)
	if err != nil {
		return
	}
	if form.JoinT+DEFAULT_JOIN_ROOM_TASK_TIME <= time.Now().Unix() {
		go func() {
			// 任务埋点：在派对房/直播间呆10分钟
			_ = new(redismodels.Task).Init().ReportConditionTag(form.UserId, "stayInRoom10Minute", 1)
		}()
	}
	err = utils.RedisClient.HDel(utils.REDIS_LIVE_ONLINE_MEMBER+roomIdStr, userIdStr).Err()
	if err != nil {
		utils.LogErrorF("移除房间[%s]的用户[%s]失败, %s", roomIdStr, userIdStr, err.Error())
		return
	}
	// 离开之后麦位处理
	AfterExitWheat(userIdStr, roomIdStr)
	return
}

// 房间在派对房/直播间呆10分钟,完成任务
func LiveRoomStayIn10Minute(liveRoom *dbmodels.AppLiveRoom, userInfo *redismodels.MsgUserObj) (err error) {
	var form JoinRoomCache
	userIdStr := strconv.Itoa(int(userInfo.UserId))
	roomIdStr := strconv.Itoa(int(liveRoom.RoomId))
	err = utils.RedisClient.HGet(utils.REDIS_LIVE_ONLINE_MEMBER+roomIdStr, userIdStr).Scan(&form)
	if err != nil {
		return
	}
	if form.JoinT+DEFAULT_JOIN_ROOM_TASK_TIME <= time.Now().Unix() {
		// 任务埋点：在派对房/直播间呆10分钟
		_ = new(redismodels.Task).Init().ReportConditionTag(form.UserId, "stayInRoom10Minute", 1)
	}
	return
}
