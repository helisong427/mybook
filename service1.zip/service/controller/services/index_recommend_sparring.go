package services

import (
	"fmt"
	"gamers/controller/response"
	"gamers/models/dbmodels"
	"gamers/utils"
	"github.com/go-redis/redis"
	wr "github.com/mroth/weightedrand"
	"gorm.io/gorm"
	"strconv"
)

type indexRecommendSparring int

const (
	amount         indexRecommendSparring = 7 //首页大神推荐数量
	recursiveRetry indexRecommendSparring = 1 //递归重试次数
)

type IndexRecommendSparring struct {
	redisClient      *redis.Client
	redisKey         string
	alreadyRecommend []int64 //已经推荐的
	retry            indexRecommendSparring
}

//位置
type recommendPosition struct {
	RecommendPositionId int64
	RecommendUserId     int64
	RecommendNumber     int64
}

func NewIndexRecommendSparring(userId int64) *IndexRecommendSparring {
	m := new(IndexRecommendSparring)
	m.redisClient = utils.RedisClient
	//查询已经推荐过的id
	m.redisKey = fmt.Sprintf("%s%d", utils.REDIS_INDEX_RECOMMEND_SPARRING, userId)
	result, _ := m.redisClient.HGetAll(m.redisKey).Result()
	for k, _ := range result {
		toInt, _ := strconv.Atoi(k)
		m.alreadyRecommend = append(m.alreadyRecommend, int64(toInt))
	}
	return m
}

//获取大神
func (m *IndexRecommendSparring) Get() (list []response.SearchRecommendSparring, err error) {
	var (
		ids             [amount]int64 //筛选出来的大神id
		recommendUserId []int64       //推荐位用户id(用于去重)
		sparringData    []dbmodels.AppSparringSkill
	)
	//获取推荐位
	recommend, err := new(dbmodels.AppRecommend).QueryByPositionAndType(dbmodels.RECOMMEND_POSITION_SPARRING, dbmodels.RECOMMEND_TYPE_SPARRING)
	if err != nil {
		return
	}

	if len(recommend) > 0 {
		positionId := m.getWeightRand(recommend)
		for _, v := range positionId {
			recommendUserId = append(recommendUserId, v.RecommendUserId)
			ids[v.RecommendNumber] = v.RecommendPositionId
		}
		//查询指定数量的大神id
		skillId, err := m.querySpecifiedNumberId(ids, recommendUserId)
		if err != nil {
			return nil, err
		}
		//获取大神
		sparringData, err = new(dbmodels.AppSparringSkill).QueryOrderIn(skillId)
		if err != nil {
			return nil, err
		}
	} else {
		//未配置推荐位随机查询
		var row int64
		row, sparringData, err = new(dbmodels.AppSparringSkill).QueryNumberRand(int(amount))
		if err != nil && err != gorm.ErrRecordNotFound {
			return
		}
		if row == 0 {
			return list, err
		}
	}
	//大神推荐
	for _, v := range sparringData {
		s := response.SearchRecommendSparring{
			SparringId:   v.SkillID,
			SkillName:    v.AppSkill.SkillName,
			SkillType:    v.AppSkill.SkillType,
			UserId:       v.SystemUser.UserID,
			UserNickname: v.SystemUser.UserNickname,
			UserIconurl:  v.SystemUser.UserIconurl,
		}
		s.PriceWay, s.PricePrice = skillMinPrice(v)
		list = append(list, s)
	}

	//缓存推荐记录
	for _, v := range m.alreadyRecommend {
		errs := m.redisClient.HSet(m.redisKey, fmt.Sprint(v), 1).Err()
		if errs != nil {
			utils.LogErrorF("缓存大神推荐记录失败:%s", errs.Error())
		}
		//设置过期时间
		errs = m.redisClient.Expire(m.redisKey, recommendTtl).Err()
		if errs != nil {
			utils.LogErrorF("缓存大神推荐记录过期时间失败:%s", errs.Error())
		}
	}

	return
}

//查询指定数量的大神id
func (m *IndexRecommendSparring) querySpecifiedNumberId(ids [amount]int64, recommendUserId []int64) (skillId []int64, err error) {
	if m.retry > recursiveRetry {
		return []int64{}, nil
	}
	var (
		notInIds     []int64 //获取随机大神时,排除此id
		nullIdNumber int64   //ids为空的数量
	)
	for _, v := range ids {
		if v == 0 {
			nullIdNumber++
		} else {
			notInIds = append(notInIds, v)
		}
	}
	for _, v := range m.alreadyRecommend {
		notInIds = append(notInIds, v)
	}

	//如果有空位,随机获取缺少数量的id
	if nullIdNumber > 0 {
		//从缓存中查询出已经推荐过的数据
		row, data, err := new(dbmodels.AppSparringSkill).QuerySpecifiedNumberId(notInIds, recommendUserId, nullIdNumber)
		if err != nil && err != gorm.ErrRecordNotFound {
			return skillId, err
		}
		if row >= nullIdNumber {
			for _, v := range data {
				for kel, val := range ids {
					if val == 0 {
						ids[kel] = v.SkillID
						//加入已经推荐记录
						m.alreadyRecommend = append(m.alreadyRecommend, v.SkillID)
						break
					}
				}
			}
		} else {
			//没有查询到空推荐位数量的大神
			//清空之前的记录,重新查询
			m.alreadyRecommend = m.alreadyRecommend[:0]
			m.redisClient.Del(m.redisKey)
			m.retry++
			if m.retry < recursiveRetry {
				return m.querySpecifiedNumberId(ids, recommendUserId)
			}
		}
	}
	for _, v := range ids {
		skillId = append(skillId, v)
	}
	return skillId, err
}

//获取随机结果
func (m *IndexRecommendSparring) getWeightRand(recommend []dbmodels.AppRecommend) (position []recommendPosition) {
	//按照编号分组
	recommendNumber := make(map[int64][]dbmodels.AppRecommend)
	for _, v := range recommend {
		recommendNumber[v.RecommendNumber] = append(recommendNumber[v.RecommendNumber], v)
	}
	for _, v := range recommendNumber {
		var recommendUserId int64
		randPositionId := m.weightRand(v)

		//取出positionId对应的userId
		for _, val := range recommendNumber {
			for _, value := range val {
				if randPositionId == value.RecommendPositionId {
					recommendUserId = value.RecommendUserId
				}
			}
		}
		r := recommendPosition{
			RecommendPositionId: randPositionId,
			RecommendUserId:     recommendUserId,
			RecommendNumber:     v[0].RecommendNumber,
		}
		position = append(position, r)
	}

	return
}

//加权随机
func (m *IndexRecommendSparring) weightRand(recommend []dbmodels.AppRecommend) (fruit int64) {
	choice := []wr.Choice{}
	for _, v := range recommend {
		choice = append(choice, wr.NewChoice(v.RecommendPositionId, uint(v.RecommendWeight)))
	}
	chooser, _ := wr.NewChooser(choice...)
	fruit = chooser.Pick().(int64)
	return
}
