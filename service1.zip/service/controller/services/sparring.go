package services

import (
	"encoding/json"
	"errors"
	"fmt"
	"math/rand"
	"sort"
	"strings"
	"sync"
	"time"

	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services/recommend"
	"gamers/enum"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"

	"golang.org/x/sync/errgroup"
	"gorm.io/gorm"
)

var SkillFieldArray = map[string]string{
	"can_region": "可接大区", "accept_level": "可接段位", "good_position": "擅长位置",
	"good_type": "擅长模式", "game_level": "游戏等级", "good_map": "擅长地图",
	"good_hero": "擅长英雄", "personality_label": "个性标签", "features": "特色",
}

// SparringDetail 大神详情
func SparringDetail(sparringId int, userId int64) (r response.SparringInfoResult, err error) {
	// 获取大神技能信息
	sparringData, err := new(dbmodels.AppSparringSkill).QueryBySkillId(int64(sparringId))
	if err != nil {
		return
	}
	if sparringData.SkillStatus != dbmodels.SPARRING_SKILL_STATUS_OK {
		r.SkillStatus = sparringData.SkillStatus
		err = errors.New("大神状态未上架")
		return
	}

	r.SkillName = sparringData.AppSkill.SkillName
	r.SkillTitle = sparringData.SkillTitle
	r.SkillInfo = sparringData.SkillInfo
	r.SkillProveImage = sparringData.SkillProveImage
	r.SkillSound = sparringData.SkillSound
	r.SkillSoundTime = int(sparringData.SkillSoundTime)

	r.UserId = sparringData.SkillUserID
	r.UserPrettyId = sparringData.SystemUser.UserPrettyId
	r.UserAge = utils.FuncGetAge(int(sparringData.SystemUser.UserBirthday))
	r.UserGender = sparringData.SystemUser.UserGender
	r.UserNickName = sparringData.SystemUser.UserNickname
	r.UserIconurl = sparringData.SystemUser.UserIconurl
	r.SkillIconUrl = sparringData.AppSkill.SkillIconurl
	r.ServiceCount = int(sparringData.SkillOrderCount)
	r.SkillCardBackGroundUrl = sparringData.AppSkill.SkillCardBackGroundUrl

	go func() {
		if err = SaveUserVisitorLog(sparringData.SkillUserID, userId, 1); err != nil {
			return
		}
	}()

	// 游戏参数
	skillData, err := new(dbmodels.AppSkill).QueryFirst(sparringData.SkillSkillID)
	if err != nil {
		return
	}

	group := new(errgroup.Group)

	// 当前技能好评率
	group.Go(func() error {
		var favorableRate int64
		favorableRate, err = new(dbmodels.AppSkillOrderComment).QueryFavorableRate(sparringData.SkillID)
		if err != nil {
			return err
		}
		r.FavorableRate = favorableRate
		return nil
	})

	// 查询是否关注大神
	group.Go(func() error {
		ok, err := new(dbmodels.AppAttention).QueryExist(int(userId), int(sparringData.SkillUserID))
		if err != nil && err != gorm.ErrRecordNotFound {
			return err
		}
		if ok > 0 {
			r.IsAttention = true
		} else {
			r.IsAttention = false
		}
		return nil
	})

	// 处理用户背景图片
	group.Go(func() (err error) {
		// var image []string
		image := make([]string, 0)
		if sparringData.SystemUser.UserBackImage != "" {
			err = json.Unmarshal([]byte(sparringData.SystemUser.UserBackImage), &image)
			if err != nil {
				return err
			}
		}
		// if image == nil || len(image) == 0 {
		// 	image = []string{}
		// }
		r.Images = image
		return
	})

	// 获取大神评论总数
	group.Go(func() (err error) {
		commentNum, err := new(dbmodels.AppSkillOrderComment).GetSparringCommentNum(sparringData.SkillID)
		if err != nil {
			return err
		}
		r.CommentNum = commentNum
		return
	})

	// 获取第一条评论
	group.Go(func() (err error) {
		firstComment, err := new(dbmodels.AppSkillOrderComment).GetSparringFirstComment(sparringData.SkillID)
		if err != nil && err != gorm.ErrRecordNotFound {
			return
		}

		// 获取第一条评论评价标签数组
		labels, err := new(dbmodels.AppSkillLabel).GetSkillLabelById(strings.Split(firstComment.CommentLabel, ","))
		if err != nil {
			return
		}

		// 为了显示 只取5条标签
		if len(labels) > 5 {
			labels = labels[:5]
		}

		if firstComment.CommentID != 0 {
			r.FirstComment = &response.OrderEvaluationResp{
				CommentUserNickName: firstComment.SystemUser.UserNickname,
				CommentUserIconURL:  firstComment.SystemUser.UserIconurl,
				CommentDate:         firstComment.Created,
				CommentContent:      firstComment.CommentContent,
				CommentAttitude:     firstComment.CommentAttitude,
				CommentAnonymous:    firstComment.CommentAnonymous,
				CommentDispute:      false,
				CommentLabel:        labels,
			}

			// 如果第一条评论是匿名评价 则修改昵称和头像
			if firstComment.CommentAnonymous == enum.OrderEvaluationIsAnonymous {
				var anonymousIconUrl string
				anonymousParam, errQuery := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_DEFAULTANONYMOUSEVALUATIONICONURL)
				if errQuery != nil {
					return errQuery
				}
				if anonymousParam["value"] != "" {
					anonymousIconUrl = anonymousParam["value"]
				}
				r.FirstComment.CommentUserNickName = "匿名"
				r.FirstComment.CommentUserIconURL = anonymousIconUrl
			}
		}
		return
	})

	// 查询大神技能标签
	group.Go(func() (err error) {
		labelData, err := new(dbmodels.AppSparringSkillLabel).Query(sparringData.SkillID)
		if err != nil {
			return
		}
		for _, v := range labelData {
			// 因为运营后台删除标签 导致查询不到标签名称 则不返回给前端
			if v.SparringLabelName == "" {
				continue
			}
			var labelArray response.LabelArray
			labelArray.LabelId = v.SparringLabelID
			labelArray.LabelName = v.SparringLabelName
			labelArray.LabelNum = v.SparringLabelNum
			r.LabelDetail = append(r.LabelDetail, labelArray)
		}
		return
	})

	// 其他技能
	group.Go(func() (err error) {
		data, err := new(dbmodels.AppSparringSkill).QueryNormalSkillByUserId(sparringData.SystemUser.UserID)
		if err != nil {
			return
		}

		// 根据服务人数排序 只取前五个游戏
		sort.Slice(data, func(i, j int) bool {
			return data[i].SkillOrderCount > data[j].SkillOrderCount
		})

		for _, v := range data {
			// 去除当前技能
			if v.SkillID == int64(sparringId) {
				continue
			}
			skill := response.SparringOtherSkill{
				SparringId:   int(v.SkillID),
				SkillType:    v.AppSkill.SkillType,
				SkillName:    v.AppSkill.SkillName,
				SkillIconUrl: v.AppSkill.SkillIconurl,
				ServiceCount: int(v.SkillOrderCount),
			}

			// 游戏等级
			skillData, err := new(dbmodels.AppSkill).QueryFirst(v.SkillSkillID)
			sparringData, err := new(dbmodels.AppSparringSkill).QueryBySkillId(v.SkillID)

			level := SkillParamsSkillLevel(skillData, sparringData)
			skill.CertifiedValue = level

			// 价格
			min, err := new(dbmodels.AppSparringSkillPrice).GetSparringByMin(v.SkillID)
			if err != nil && err == gorm.ErrRecordNotFound {
				continue
			} else {
				skill.PriceWay = min.AppSkillPrice.PriceWay
				skill.PricePrice = int(min.PricePrice)
			}

			// 好评率
			var favorableRate int64
			favorableRate, err = new(dbmodels.AppSkillOrderComment).QueryFavorableRate(v.SkillID)
			if err != nil {
				return err
			}
			skill.FavorableRate = favorableRate
			r.SparringOtherSkill = append(r.SparringOtherSkill, skill)

		}
		if len(r.SparringOtherSkill) > 4 {
			r.SparringOtherSkill = r.SparringOtherSkill[:4]
		}

		return
	})

	// wait 协程 Done
	if err = group.Wait(); err != nil {
		utils.LogErrorF("查询大神详情失败sparringId[%d], userId[%d], err[%s]", sparringId, userId, err.Error())
		return
	}

	// 最小价格的key
	priceMinKey := 0

	r.SkillParams, r.CertifiedValue, priceMinKey = skillParamsUnmarshal(skillData, sparringData)

	// 格式化名片可选字段、详情字段
	r.SkillCardParams, r.SkillInfoParams = SkillCardAndInfoParamsUnmarshal(skillData, sparringData)

	// 单价(局/天)
	r.PriceWay = sparringData.AppSparringSkillPrice[priceMinKey].AppSkillPrice.PriceWay
	// 价格(go币)
	r.PricePrice = int(sparringData.AppSparringSkillPrice[priceMinKey].PricePrice)
	// 价格id
	r.PriceId = int(sparringData.AppSparringSkillPrice[priceMinKey].PriceId)
	// 价格类型
	r.PriceType = sparringData.AppSparringSkillPrice[priceMinKey].PriceType
	return
}

// 从redis 获取 在线 大神推荐列表缓存(陪玩列表)
func getOnlineSparringRcdCache(offset, size int64, key string) (data []string, total int64, err error) {
	var (
		length int64
	)

	length = utils.RedisClient.ZCard(key).Val()
	total = length

	// 如果已经超长了,直接返回数据
	if offset > length {
		return
	}

	if data, err = utils.RedisClient.ZRevRange(key, offset, offset+size-1).Result(); err != nil {
		utils.LogErrorF("get online data failed, error: %v", err.Error())
	}

	return
}

type longitudeMap struct {
	UserLatitude  float32 `json:"user_latitude"`
	UserLongitude float32 `json:"user_longitude"`
}

func userList2Map(list []*dbmodels.UserLongitudeResult) map[int64]longitudeMap {
	m := make(map[int64]longitudeMap)

	for _, v := range list {
		m[v.UserID] = longitudeMap{
			UserLatitude:  v.UserLatitude,
			UserLongitude: v.UserLongitude,
		}
	}

	return m
}

func getSparringRcdRedisData(sparringIdList []string) (data []response.SparringListRes, err error) {
	var (
		userList      []*dbmodels.UserLongitudeResult
		skillInfoData []dbmodels.AppSparringSkillInfo
		userIdList    []int64
		skillAll      []dbmodels.AppSkill
	)

	// 游戏参数
	if skillAll, err = new(dbmodels.AppSkill).QueryAll(); err != nil {
		err = errors.New("获取游戏参数失败")
		return
	}

	// 查询技能详情
	if skillInfoData, err = new(dbmodels.AppSparringSkillInfo).QueryByInSkillIdStr(sparringIdList); err != nil {
		return
	}

	if len(skillInfoData) == 0 {
		err = errors.New("技能详情不存在")
		return
	}

	for _, v := range sparringIdList {
		var (
			sparringGlobal recommend.SparringGlobal
		)
		// 获取对应信息并 构造数据
		if err = utils.RedisClient.HGet(utils.REDIS_RECOMMEND_SPARRING_GLOBAL, v).Scan(&sparringGlobal); err != nil {
			utils.LogErrorF("get nil sparring global data, err: %v", err)
			continue
		}

		userInfo, errUser := new(redismodels.UserInfo).GetUserInfo(sparringGlobal.UserId)
		if errUser != nil || userInfo.UserID == 0 {
			continue
		}

		sparring, _ := new(dbmodels.AppSparringSkill).QueryBySkillId(sparringGlobal.SparringSkillId)

		userIdList = append(userIdList, userInfo.UserID)

		sparringRes := response.SparringListRes{
			SparringId:      sparringGlobal.SparringSkillId,
			SkillSkillID:    sparringGlobal.SkillId,
			SparringName:    userInfo.UserNickname,
			IsOnline:        userInfo.UserIsOnline,
			ServiceCount:    sparring.SkillOrderCount,
			SkillSound:      sparring.SkillSound,
			SkillSoundTime:  sparring.SkillSoundTime,
			SparringIconurl: userInfo.UserIconurl,
			UserGender:      userInfo.UserGender,
			UserAge:         userInfo.UserAge,
			IsCertification: 1,
			PraiseRate:      4.1,
			UserId:          userInfo.UserID,
		}

		for _, val := range skillAll {
			// 如果相同的游戏
			if sparringGlobal.SkillId == val.SkillId {
				for _, value := range skillInfoData {
					if value.InfoSparringSkillId == sparringGlobal.SparringSkillId {
						// 如果技能表的必填字段等于技能配置表的技能字段名称
						if val.SkillRequiredField == value.AppSkillFieldValue.ValueField {
							// 游戏段位
							sparringRes.CertifiedValue = value.AppSkillFieldValue.ValueValue
						}
					}
				}
			}
		}

		// 价格
		min, _ := new(dbmodels.AppSparringSkillPrice).GetSparringByMin(sparringGlobal.SparringSkillId)
		sparringRes.PriceWay = min.AppSkillPrice.PriceWay
		sparringRes.PricePrice = int(min.PricePrice)

		data = append(data, sparringRes)
	}

	// 获取用户经度纬度信息
	userList, err = new(dbmodels.SystemUser).GetUserLongitudeList(userIdList)
	userMap := userList2Map(userList)

	for k, v := range data {
		data[k].Longitude = userMap[v.UserId].UserLongitude
		data[k].Latitude = userMap[v.UserId].UserLatitude
	}

	return
}

// 从redis 获取 大神推荐列表缓存(陪玩列表)
func getSparringRcdRedisCache(offset, size, selectOnline int64, skillId string) (data []response.SparringListRes, total int64, err error) {
	var (
		key            string
		sparringIdList []string
	)
	// 获取在线数据
	// 先获取 在线列表的长度
	switch selectOnline {
	case 0:
		// 不限
		key = utils.REDIS_RECOMMEND_SPARRING_SKILL_ONLINE + skillId
	case 1:
		// 离线
		key = utils.REDIS_RECOMMEND_SPARRING_SKILL_OFFLINE + skillId
	case 2:
		// 在线
		key = utils.REDIS_RECOMMEND_SPARRING_SKILL_ONLINE + skillId
	}

	if sparringIdList, total, err = getOnlineSparringRcdCache(offset, size, key); err != nil {
		return
	}

	// 如果是不限 的情况
	if selectOnline == 0 {
		key = utils.REDIS_RECOMMEND_SPARRING_SKILL_OFFLINE + skillId
		// 则判断 此时数据是否足够,不足够,则加上 部分离线数据
		if total-offset >= 0 {
			if len(sparringIdList) < int(size) {
				offset = 0
				size = size - int64(len(sparringIdList))
			} else {
				if offset == 0 {
					offset = 1
				}
				size = 0
			}
		} else {
			offset = offset - total
		}

		sparringIdOfflineList, totalOffline, errOffline := getOnlineSparringRcdCache(offset, size, key)
		if errOffline != nil {
			utils.LogErrorF("get online data failed, error: %v", errOffline.Error())
		}

		sparringIdList = append(sparringIdList, sparringIdOfflineList...)
		total = total + totalOffline
	}

	if len(sparringIdList) == 0 {
		return
	}

	data, err = getSparringRcdRedisData(sparringIdList)

	return
}

// 有条件的情况,直接从数据库获取
func getSparringRcdRedisFromSql(offset int64, req request.SparringListReq) (data []response.SparringListRes, total int64, err error) {
	var (
		list           []dbmodels.AppSparringIdsResult
		size           int
		sparringIdList []string
	)

	// 查询技能
	if total, list, err = new(dbmodels.AppSparringSkill).QueryPageRand(request.SparringListReq{
		BasePageReq: request.BasePageReq{
			Page: req.Page,
			Size: req.Size,
		},
		SkillId:        req.SkillId,
		Sex:            req.Sex,
		SelectOnline:   2,
		OtherCondition: req.OtherCondition,
	}, int(offset)); err != nil {
		return
	}

	if req.SelectOnline == 0 {
		if total-offset >= 0 {
			if len(list) < req.Size {
				offset = 0
				size = req.Size - len(list)
			} else {
				if offset == 0 {
					offset = 1
				}
				size = 0
			}
		} else {
			offset = offset - total
			size = req.Size
		}

		// 再从 离线数据获取一次
		totalOffline, sparringIdOfflineList, errOffline := new(dbmodels.AppSparringSkill).QueryPageRand(request.SparringListReq{
			BasePageReq: request.BasePageReq{
				Page: req.Page,
				Size: size,
			},
			SkillId:        req.SkillId,
			Sex:            req.Sex,
			SelectOnline:   1,
			OtherCondition: req.OtherCondition,
		}, int(offset))

		if errOffline != nil {
			utils.LogErrorF("get online data failed, error: %v", errOffline.Error())
		}

		list = append(list, sparringIdOfflineList...)
		total = total + totalOffline
	}

	for _, v := range list {
		sparringIdList = append(sparringIdList, fmt.Sprintf("%v", v.SkillID))
	}

	if len(sparringIdList) == 0 {
		return
	}

	data, err = getSparringRcdRedisData(sparringIdList)

	return
}

// 获取 为你推荐的数据
func getDataForYou(skillId int64) (data []response.SparringListRes) {
	// 直接从 所有大神 前60% 在线列表获取 十条数据
	var (
		length         int64
		key            string
		offset         int64
		end            int64
		randNum        int64
		err            error
		size           int64
		sparringIdList []string
		total          int64
	)

	// 这部分代码有点杂, 读代码可能读不懂
	key = utils.REDIS_RECOMMEND_SPARRING_SKILL_ONLINE + fmt.Sprintf("%v", skillId)

	length = utils.RedisClient.ZCard(key).Val()

	// 获取随机 区间
	randNum = length * 60 / 100
	if randNum < 10 {
		randNum = length
	}

	r := rand.NewSource(time.Now().Unix())
	rd := rand.New(r)

	// 获取start(offset) 值
	// Int63n 随机函数参数不能取0
	if length == 0 || randNum == 0 {
		offset = 0
	} else {
		offset = rd.Int63n(randNum)
	}

	end = offset + 10

	if end > length {
		offset = offset - (end - length)
		end = length
	}

	if offset < 0 {
		offset = 0
	}

	size = 10
	if sparringIdList, total, err = getOnlineSparringRcdCache(offset, size, key); err != nil {
		return
	}

	// 如果是不限 的情况
	key = utils.REDIS_RECOMMEND_SPARRING_SKILL_OFFLINE + fmt.Sprintf("%v", skillId)
	// 则判断 此时数据是否足够,不足够,则加上 部分离线数据
	if total-offset >= 0 {
		if len(sparringIdList) < int(size) {
			offset = 0
			size = size - int64(len(sparringIdList))
		} else {
			if offset == 0 {
				offset = 1
			}
			size = 0
		}
	} else {
		offset = offset - total
	}

	sparringIdOfflineList, totalOffline, errOffline := getOnlineSparringRcdCache(offset, size, key)
	if errOffline != nil {
		utils.LogErrorF("get online data failed, error: %v", errOffline.Error())
	}

	sparringIdList = append(sparringIdList, sparringIdOfflineList...)
	total = total + totalOffline

	if len(sparringIdList) == 0 {
		return
	}

	data, err = getSparringRcdRedisData(sparringIdList)

	data[0].IsRecommend = 1

	return
}

// 大神列表
func SparringList(paramsJSON request.SparringListReq, userId int64) (r response.BasePageList, err error) {
	var (
		list   []response.SparringListRes
		offset int
		total  int64
	)

	paramsJSON.Size = 50 // TODO: 之后要去掉这一句, 交给前端(app)进行去重

	r.Page = paramsJSON.Page
	r.Size = paramsJSON.Size
	offset = utils.GetOffset(r.Page, r.Size)

	// 先判断条件, 如果条件满足, 直接从 redis 缓存获取
	if paramsJSON.OtherCondition == "" && paramsJSON.Sex == 0 {
		if list, total, err = getSparringRcdRedisCache(int64(offset), int64(r.Size),
			int64(paramsJSON.SelectOnline),
			fmt.Sprintf("%v", paramsJSON.SkillId)); err != nil {
			utils.LogErrorF("get sparring recommend list failed: %v", err.Error())
		}
	} else {
		if list, total, err = getSparringRcdRedisFromSql(int64(offset), paramsJSON); err != nil {
			utils.LogErrorF("get sparring recommend list failed: %v", err.Error())
		}
	}

	if total == 0 {
		r.TotalPages = 0
	} else {
		r.TotalPages = utils.FuncTotalPages(total, paramsJSON.Size)
	}

	// 为你推荐
	if total < 5 && paramsJSON.OtherCondition != "" && paramsJSON.Page == 1 {
		list = append(list, getDataForYou(int64(paramsJSON.SkillId))...)
	}

	r.Total = total
	r.List = list

	return
}

// 大神下单前
func SparringBeforePlacingOrder(sparringId int, userId int64) (r response.SparringBeforePlacingOrderResp, err error) {
	data, err := new(dbmodels.AppSparringSkill).QueryBySkillId(int64(sparringId))
	if err != nil {
		return
	}
	if data.SkillStatus != dbmodels.SPARRING_SKILL_STATUS_OK {
		err = errors.New("大神状态未上架")
		return
	}

	// 查询技能名称
	name, err := new(dbmodels.AppSkill).QueryFirstSkillName(data.SkillSkillID)
	if err != nil {
		return
	}

	if name.SkillStatus == 0 {
		r.SkillStatus = name.SkillStatus
		err = errors.New("技能已下线")
		return
	}

	r.SparringId = int(data.SkillID)
	r.SkillName = name.SkillName
	r.UserNickName = data.SystemUser.UserNickname
	r.UserIconurl = data.SystemUser.UserIconurl
	r.UserGender = int(data.SystemUser.UserGender)
	r.UserAge = utils.FuncGetAge(int(data.SystemUser.UserBirthday))

	// 用户余额
	info, err := new(redismodels.UserInfo).GetUserInfo(userId)
	if err != nil {
		return
	}
	r.UserBalance = int(info.WalletTotalOver)

	params := []response.PlacingOrderSkillParams{}
	for _, v := range data.AppSparringSkillPrice {
		if v.BaseModel.Deleted == 0 {
			params = append(params, response.PlacingOrderSkillParams{
				PriceId:    int(v.PriceId),
				PriceWay:   v.AppSkillPrice.PriceWay,
				PricePrice: int(v.PricePrice),
				PriceType:  v.PriceType,
			})
		}
	}
	r.SkillParams = params
	return
}

// 我的技能
func SparringMySkill(userId int64) (r []response.SparringMySkillRep, err error) {
	data, err := new(dbmodels.AppSparringSkill).QuerySkillByUserId(userId)
	if err != nil {
		return
	}

	for _, v := range data {
		res := response.SparringMySkillRep{
			SparringId:               int(v.SkillID),
			SkillType:                v.AppSkill.SkillType,
			SkillName:                v.AppSkill.SkillName,
			SkillIconurl:             v.AppSkill.SkillIconurl,
			SkillStatus:              v.SkillStatus,
			SkillSetInfoStatus:       v.SkillSetInfoStatus,
			SkillMsgStatus:           v.SkillMsgStatus,
			SkillSpeedMatchingStatus: v.SkillSpeedMatchingStatus,
		}

		// 审核提示
		if res.SkillStatus == dbmodels.SPARRING_SKILL_STATUS_INIT {
			res.ReviewTips = fmt.Sprintf("您的技能申请已经提交，我们将在%s之前完成审核，并将审核结果以系统消息的方式通知您", time.Unix(v.BaseModel.Edited, 0).Add(time.Hour*24*3).Format("2006年01月02日"))
		} else if res.SkillStatus == dbmodels.SPARRING_SKILL_STATUS_BAN {
			// 冻结提示
			res.FreezeTips = "您的技能由于违规，已被平台冻结。冻结中无法接单，如需申诉请联系客服"
		}

		// 价格
		min, err := new(dbmodels.AppSparringSkillPrice).GetSparringByMin(v.SkillID)
		if err != nil && err == gorm.ErrRecordNotFound {
			// 如果为空
			res.IsSetPrice = 0
		} else {
			if err != nil {
				continue
			}

			res.IsSetPrice = 1
			res.PriceWay = min.AppSkillPrice.PriceWay
			res.PricePrice = int(min.PricePrice)
		}

		r = append(r, res)
	}
	return
}

// 格式化名片可选字段、详情字段
// @return cardRes 名片字段
// @return infoRes 详情字段
func SkillCardAndInfoParamsUnmarshal(skillData dbmodels.AppSkill, sparringSkillData dbmodels.AppSparringSkill) (cardRes []response.SkillParams, infoRes []response.SkillInfoParams) {
	cardTmpMap := map[string][]string{}
	infoTmpMap := map[string][]string{}

	var (
		cardValueField []dbmodels.AppSkillFieldValue
		infoValueField []dbmodels.AppSkillFieldValue
	)
	cardRes = make([]response.SkillParams, 0)
	infoRes = make([]response.SkillInfoParams, 0)

	// 区分名片字段、详情字段
	for _, v := range skillData.AppSkillFieldValue {
		if strings.Contains(skillData.SkillCardFields, v.ValueField) {
			cardValueField = append(cardValueField, v)
		} else {
			infoValueField = append(infoValueField, v)
		}
	}

	for _, v := range cardValueField {
		for _, val := range sparringSkillData.AppSparringSkillInfo {
			if v.ValueId == val.InfoValueId {
				cardTmpMap[v.ValueFieldName] = append(cardTmpMap[v.ValueFieldName], v.ValueValue)
			}
		}
	}

	for _, v := range infoValueField {
		for _, val := range sparringSkillData.AppSparringSkillInfo {
			if v.ValueId == val.InfoValueId && v.ValueField != skillData.SkillRequiredField {
				infoTmpMap[v.ValueFieldName] = append(infoTmpMap[v.ValueFieldName], v.ValueValue)
			}
		}
	}

	sortCardField := make([]string, 0)
	for k, _ := range cardTmpMap {
		sortCardField = append(sortCardField, k)
	}
	sort.Strings(sortCardField)
	for _, i := range sortCardField {
		r := response.SkillParams{}
		r.Title = i
		// fmt.Println(cardTmpMap[i])
		r.Value = cardTmpMap[i]
		cardRes = append(cardRes, r)
	}

	sortInfoField := make([]string, 0)
	for k, _ := range infoTmpMap {
		sortInfoField = append(sortInfoField, k)
	}
	sort.Strings(sortInfoField)
	for _, j := range sortInfoField {
		r := response.SkillInfoParams{}
		if j == SkillFieldArray["can_region"] {
			r.Icon = "https://procdn1.chatgogo.cn/gogo/upload/sys/can_region2x.png"
		} else if j == SkillFieldArray["personality_label"] {
			r.Icon = "https://procdn1.chatgogo.cn/gogo/upload/sys/personality_label2x.png"
		} else {
			r.Icon = "https://procdn1.chatgogo.cn/gogo/upload/sys/other2x.png"
		}
		r.Title = j
		r.Value = infoTmpMap[j]
		infoRes = append(infoRes, r)
	}
	return
}

// 获取游戏等级
func SkillParamsSkillLevel(skillData dbmodels.AppSkill, sparringSkillData dbmodels.AppSparringSkill) (skillLevel string) {
	for _, v := range skillData.AppSkillFieldValue {
		for _, val := range sparringSkillData.AppSparringSkillInfo {
			if v.ValueId == val.InfoValueId && v.ValueField == skillData.SkillRequiredField {
				skillLevel = v.ValueValue
				break
			}
		}
	}
	return
}

// GetSkillLevel 获取游戏等级
func GetSkillLevel(info []dbmodels.AppSparringSkillInfo, field string) (level string) {
	for _, v := range info {
		if v.AppSkillFieldValue.ValueField == field {
			level = v.AppSkillFieldValue.ValueValue
			break
		}
	}
	return
}

// 格式化游戏参数
func skillParamsUnmarshal(skillData dbmodels.AppSkill, sparringSkillData dbmodels.AppSparringSkill) (
	res []response.SkillParams, skillLevel string, min int) {
	tmpMap := map[string][]string{}
	res = make([]response.SkillParams, 0)
	// var (
	// 	cardFValueField []dbmodels.AppSkillFieldValue
	// 	skillFieldValue []dbmodels.AppSkillFieldValue
	// )
	// // 根据名片字段划分
	// for _, v := range skillData.AppSkillFieldValue {
	// 	if strings.Contains(skillData.SkillCardFields, v.ValueField) {
	// 		cardFValueField = append(cardFValueField, v)
	// 	} else {
	// 		skillFieldValue = append(skillFieldValue, v)
	// 	}
	// }
	for _, v := range skillData.AppSkillFieldValue {
		for _, val := range sparringSkillData.AppSparringSkillInfo {
			// 用户等级
			if v.ValueId == val.InfoValueId && v.ValueField == skillData.SkillRequiredField {
				skillLevel = v.ValueValue
				break
			}
			// 根据大神技能id格式化数据
			if v.ValueId == val.InfoValueId {
				tmpMap[v.ValueFieldName] = append(tmpMap[v.ValueFieldName], v.ValueValue)
			}
		}
	}
	// 最小单价id
	minId := sparringSkillData.AppSparringSkillPrice[0].PricePriceId
	// 查询价格的最小id
	for k, v := range sparringSkillData.AppSparringSkillPrice {
		if v.PricePriceId < minId {
			minId = v.PricePriceId
			min = k
		}
	}

	for k, v := range tmpMap {
		r := response.SkillParams{}
		r.Title = k
		r.Value = v
		res = append(res, r)
	}
	return
}

type ErrMsg struct {
	Msg      string `json:"msg"`
	Finished bool   `json:"finish"`
	Err      error  `json:"err"`
}

// 修改服务信息
func UpdateSparringServiceInfo(userId int64, form request.UpdateSparringServiceReq) (msg ErrMsg) {
	// 判断是否存在此游戏的认证
	var localSparring dbmodels.AppSparringSkill
	localSparring, msg.Err = new(dbmodels.AppSparringSkill).QueryBySkillId(form.SparringSkillID)
	if msg.Err != nil && msg.Err != gorm.ErrRecordNotFound {
		msg.Msg = "服务器错误"
		return
	}
	if msg.Err != nil {
		msg.Msg = "未查询大神信息"
		return
	}
	if localSparring.SkillStatus != dbmodels.SPARRING_SKILL_STATUS_OK && localSparring.SkillStatus != dbmodels.SPARRING_SKILL_STATUS_OFF {
		msg.Msg = "当前技能状态禁止修改"
		msg.Err = errors.New("forbidden update field")
		return
	}
	// 查询技能详情，匹配field
	skillInfo, err := new(dbmodels.AppSkill).QueryBySkillId(localSparring.SkillSkillID)
	if err != nil {
		msg.Msg = "查询skill出错"
		msg.Err = err
		return
	}
	// 校验字段是否全部传完
	errField := CheckAppSkillFieldRequired(skillInfo.SkillFields, skillInfo.SkillRequiredField, form.SkillFields)
	if errField != "" {
		msg.Msg = fmt.Sprintf("字段%s必传", errField)
		msg.Err = errors.New("field error")
		return
	}

	var pmodels dbmodels.AppSparringSkillPrice
	prices, err := pmodels.GetPriceBySparringSkillId(localSparring.SkillID)
	if err != nil || len(prices) == 0 {
		msg.Msg = "查询用户价格失败"
		msg.Err = errors.New("price error")
		if err != nil {
			msg.Err = err
		}
		return
	}
	var opens []int64
	closeMap := make(map[int64]int64)
	var closes []int64
	// 判断价格
	for _, p := range prices {
		closeMap[p.PriceId] = p.PriceId
	}
	for _, v := range form.SkillPriceIds {
		value, ok := closeMap[v]
		if ok {
			opens = append(opens, value)
			delete(closeMap, value)
		} else {
			msg.Msg = "价格id有误"
			msg.Err = errors.New("price_id error")
			return
		}
	}
	for _, v := range closeMap {
		closes = append(closes, v)
	}
	length := 0
	for _, l := range form.SkillFields {
		if l.SkillField == skillInfo.SkillRequiredField {
			msg.Msg = fmt.Sprintf("禁止修改[%s]字段", l.SkillField)
			msg.Err = errors.New("forbidden update field")
			return
		}
		length += len(l.SkillFieldValues)
	}
	wg := sync.WaitGroup{}
	checkChan := make(chan CheckFieldValue, length)
	for _, k := range form.SkillFields {
		if k.SkillField == "personality_label" {
			if len(k.SkillFieldValues) > 3 {
				msg.Msg = "个性标签最多选择3个"
				msg.Err = errors.New("validate personality_label error")
				return
			}
		}
		for _, v := range k.SkillFieldValues {
			wg.Add(1)
			go CheckAppSkillFieldValue(v, localSparring.SkillSkillID, k.SkillField, &wg, checkChan)
		}
	}
	wg.Wait()
	close(checkChan)
	var infos []dbmodels.AppSparringSkillInfo
	var errInfos []CheckFieldValue
	for m := range checkChan {
		if !m.Result {
			errInfos = append(errInfos, m)
		}
		value := dbmodels.AppSparringSkillInfo{
			InfoSkillId:         localSparring.SkillSkillID,
			InfoUserId:          localSparring.SkillUserID,
			InfoSparringSkillId: localSparring.SkillID,
			InfoValueId:         m.SkillFieldValues,
		}
		infos = append(infos, value)
	}
	if len(errInfos) > 0 {
		msg.Msg = fmt.Sprintf("校验参数[%v]的值有误，请检查", errInfos)
		return
	}
	// 修改值
	var smodels dbmodels.AppSparringSkillInfo
	data, err := smodels.GetSkillInfoByUserIdAndGameId(userId, skillInfo.SkillId)
	if err != nil {
		utils.LogErrorF("查询必填字段出错,err:%s", err.Error())
		msg.Msg = "查询必填字段出错"
		msg.Err = err
		return
	}

	tx := utils.GEngine.Begin()
	// 拼接值
	err = smodels.UpdateSkillInfoByValue(tx, infos, data)
	if err != nil {
		utils.LogErrorF("修改技能值出错,err:%s", err.Error())
		msg.Msg = "修改技能值出错"
		msg.Err = err
		tx.Rollback()
		return
	}
	err = new(dbmodels.AppSparringSkill).UpdateSetInfo(tx, localSparring.SkillID)
	if err != nil {
		utils.LogErrorF("修改技能设置状态值出错,err:%s", err.Error())
		msg.Msg = "修改技能设置状态值出错"
		msg.Err = err
		tx.Rollback()
		return
	}
	err = pmodels.UpdateSparringBySparringSkillId(tx, opens, closes, localSparring.SkillID)
	if err != nil {
		utils.LogErrorF("修改价格出错,err:%s", err.Error())
		msg.Msg = "修改价格出错"
		msg.Err = err
		tx.Rollback()
		return
	}
	if form.Wechat != "" || form.QQ != "" {
		err = new(dbmodels.SystemUser).UpdateUserQQAndWechat(tx, userId, form.QQ, form.Wechat)
		if err != nil {
			utils.LogErrorF("修改大神[%d]联系方式出错,err:%s", userId, err.Error())
			msg.Msg = "修改联系方式出错"
			msg.Err = err
			tx.Rollback()
			return
		}
	}

	err = tx.Commit().Error
	if err != nil {
		msg.Msg = "修改联系方式出错"
		msg.Err = err
		tx.Rollback()
		return
	}
	msg.Finished = true
	return
}

type CheckFieldValue struct {
	SkillField       string `json:"skill_field"` // 服务价格单位
	SkillFieldValues int64  `json:"skill_field_values"`
	Result           bool   `json:"result"`
}

// 校验必传字段
func CheckAppSkillFieldRequired(required, requiredKey string, fields []request.SField) (errStr string) {
	bindings := dbmodels.SplitSkillFields(required)
	for _, v := range bindings {
		if v == requiredKey {
			continue
		}
		length := len(bindings) - 1
		for _, j := range fields {
			if v == j.SkillField {
				length -= 1
				break
			}
		}
		if length == len(bindings)-1 {
			errStr = v
			return
		}
	}
	return ""
}

// 校验field合法性
func CheckAppSkillFieldValue(valueId int64, skillId int64, valueField string, wg *sync.WaitGroup, checkInfo chan CheckFieldValue) {
	defer wg.Done()
	result := CheckFieldValue{
		SkillField:       valueField,
		SkillFieldValues: valueId,
	}
	result.Result = new(dbmodels.AppSkillFieldValue).CheckedByValueIdAndSkillIdAndValueField(valueId, skillId, valueField)
	checkInfo <- result
}

// 大神编辑前获取信息
func SparringDetailByUpdate(sparringId int64) (r response.UpdateSparringSkillsResp, err error) {
	sparringData, err := new(dbmodels.AppSparringSkill).GetSparringInfo(sparringId)
	if err != nil {
		return
	}
	r.SkillSkillID = sparringData.SkillSkillID
	r.SkillInfo = sparringData.SkillInfo
	r.SkillCardBackGroundUrl = sparringData.AppSkill.SkillCardBackGroundUrl
	r.SkillProveImage = sparringData.SkillProveImage
	r.SkillSound = sparringData.SkillSound
	r.SkillSoundTime = sparringData.SkillSoundTime
	r.UserIconurl = sparringData.SystemUser.UserIconurl
	r.SkillUserID = sparringData.SkillUserID
	r.UserQQ = sparringData.SystemUser.UserQQ
	r.UserWechat = sparringData.SystemUser.UserWechat
	r.SkillID = sparringData.SkillID
	r.SkillTitle = sparringData.SkillTitle
	r.SkillStatus = sparringData.SkillStatus
	valueMap := map[string]*response.GameSkillFiledValue{}
	sortField := make([]string, 0)
	for _, v := range sparringData.AppSkill.AppSkillFieldValue {
		info := response.AppSkillFieldValue{
			ValueId:        v.ValueId,
			ValueSkillId:   v.ValueSkillId,
			ValueFieldName: v.ValueFieldName,
			ValueField:     v.ValueField,
			ValueOrder:     v.ValueOrder,
			ValueValue:     v.ValueValue,
		}
		for _, j := range sparringData.AppSparringSkillInfo {
			if v.ValueId == j.AppSkillFieldValue.ValueId {
				info.Choose = response.SPARRING_CHOOSE_STATUS_YES
			}
		}
		if valueMap[v.ValueField] != nil {
			valueMap[v.ValueField].Values = append(valueMap[v.ValueField].Values, info)
			continue
		}
		skillInfo := response.GameSkillFiledValue{
			ValueKey:     v.ValueField,
			ValueKeyName: v.ValueFieldName,
		}
		if v.ValueField == "personality_label" {
			skillInfo.MaxSize = 3
			skillInfo.ShowType = response.SKILL_FILED_SHOW_TYPE_FALLS
		}
		skillInfo.Values = append(skillInfo.Values, info)
		sortField = append(sortField, skillInfo.ValueKey)
		valueMap[skillInfo.ValueKey] = &skillInfo

	}
	sort.Strings(sortField)
	for _, m := range sortField {
		if m == sparringData.AppSkill.SkillRequiredField {
			r.SkillRequiredValue = valueMap[m].Values
		} else {
			r.GameSkillFiledValues = append(r.GameSkillFiledValues, *valueMap[m])
		}
	}
	// 拼价格
	for _, j := range sparringData.AppSparringSkillPrice {
		ap := response.AppSkillPrice{
			PriceSkillId:        j.PriceSkillId,
			PriceWay:            j.AppSkillPrice.PriceWay,
			PriceProtectionTime: j.AppSkillPrice.PriceProtectionTime,
			PriceTime:           j.AppSkillPrice.PriceTime,
			PriceRequired:       j.AppSkillPrice.PriceRequired,
		}
		info := response.AppSparringSkillPrice{
			PriceId: j.PriceId,
			// PriceOrgPrice:        j.PriceOrgPrice,
			PricePrice:           j.PricePrice,
			PriceSkillId:         j.PriceSkillId,
			PriceSparringSkillId: j.PriceSparringSkillId,
			PricePriceId:         j.PricePriceId,
			PriceUserId:          j.PriceUserId,
			PriceType:            j.PriceType,
			AppSkillPrice:        ap,
		}
		if j.BaseModel.Deleted == 0 {
			info.Choose = response.SPARRING_CHOOSE_STATUS_YES
		}
		r.AppSparringSkillPrice = append(r.AppSparringSkillPrice, info)
	}

	return
}

// 大神中心
func GetSparringCenter(userId int64) (data response.SparringHomeRes, err error) {
	data, err = new(dbmodels.SystemUser).GetSparringHomeInfo(userId)
	if err != nil {
		utils.LogInfoF("查询用户信息出错,err:%s", err.Error())
		return
	}
	data.Age = utils.FuncGetAge(data.Age)
	data.SkillInfos, data.SkillCount, err = new(dbmodels.AppSkill).GetOpenSkillsByUserId(userId)
	if err != nil {
		utils.LogInfoF("查询大神信息出错,err:%s", err.Error())
		return
	}
	income, err := new(dbmodels.AppSkillOrder).GetMonthIncomeBySparringId(userId)
	if err != nil {
		utils.LogInfoF("查询大神月收入信息出错,err:%s", err.Error())
		return
	}
	data.MonthIncome = income.MonthIncome
	data.TotalIncome += income.UnSettleIncome
	return
}
