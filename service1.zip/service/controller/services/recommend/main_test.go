package recommend

import (
	"gamers/utils"
	"os"
	"testing"
)

func TestMain(m *testing.M) {
	conf := os.Getenv("GIN_CONFIG")
	if conf == "" {
		conf = "test"
	}

	utils.ConfigInitLocal(conf)
	// 初始化日志
	utils.LoggerInit()
	utils.GDBInit()
	utils.RedisInit()
	os.Exit(m.Run())
}
