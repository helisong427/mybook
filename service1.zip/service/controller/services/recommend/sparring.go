package recommend

import (
	"encoding/json"
	"fmt"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"github.com/go-redis/redis"
	"math"
	"time"
)

// 推荐数据缓存模型
type Sparring struct {
	redis                *redis.Client                     // redis
	cacheKeyGlobal       string                            // 大神全局缓存,大神分数(list),用于储存大神分数和其他信息
	cacheKeyOnline       string                            // 大神推荐,在线列表(zset)
	cacheKeyOffline      string                            // 大神推荐,离线列表(zset)
	cacheKeySkillOnline  string                            // 大神游戏推荐,在线列表(zset)
	cacheKeySkillOffline string                            // 大神游戏推荐,离线列表(zset)
	cacheKeyUser         string                            // 首页专属推荐用户缓存
	ScoreConfig          dbmodels.SparringSkillScoreConfig // 分数配置
	OnlineSet            []int64                           // 在线集合
	OfflineSet           []int64                           // 离线集合
	OnlineCount          int64                             // 在线条数
	OfflineCount         int64                             // 离线条数
	recommendIds         []int64                           // 大神推荐id
	recommendOfflineIds  []int64                           // 大神离线推荐id
	userCacheIds         []int64                           // 用户缓存
}

const (
	sparringPercentage          float64 = 0.3 // 大神推荐占比
	exclusiveSparringPercentage float64 = 0.5 // 专属推荐占比
)

// 大神全局缓存
type SparringGlobal struct {
	UserId          int64 `json:"user_id"`           // 用户id
	SparringSkillId int64 `json:"sparring_skill_id"` // 大神技能id(app_sparring_skill主键)
	SkillId         int64 `json:"skill_id"`          // 技能id(app_skill表主键)
	Fraction        int64 `json:"fraction"`          // 分数
}

func (s *SparringGlobal) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s SparringGlobal) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

// 获取大神推荐参数
type GetRecommendParams struct {
	Page       int     // 当前页
	UserId     int64   // 用户id
	TotalSize  int64   // 总获取条数
	PositionId []int64 // 推荐位id(用于去重)
	Percentage float64 // 占比(用于取全品类排序分前30%)
}

func (s *GetRecommendParams) UnmarshalBinary(data []byte) error {
	return json.Unmarshal(data, s)
}

func (s GetRecommendParams) MarshalBinary() ([]byte, error) {
	return json.Marshal(s)
}

// 初始化
func NewSparring() *Sparring {
	return &Sparring{
		redis:                utils.RedisClient,
		cacheKeyGlobal:       utils.REDIS_RECOMMEND_SPARRING_GLOBAL,
		cacheKeyOnline:       utils.REDIS_RECOMMEND_SPARRING_ONLINE,
		cacheKeyOffline:      utils.REDIS_RECOMMEND_SPARRING_OFFLINE,
		cacheKeySkillOnline:  utils.REDIS_RECOMMEND_SPARRING_SKILL_ONLINE,
		cacheKeySkillOffline: utils.REDIS_RECOMMEND_SPARRING_SKILL_OFFLINE,
	}
}

// 初始化大神技能计算分数配置(计算分数时,调用此方法)
func (r *Sparring) initConfig() (err error) {
	param, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PARAM_KEY_SPARRING_SKILL_SCORE_PARAM)
	if err != nil {
		return
	}
	conf := dbmodels.SparringSkillScoreConfig{}
	err = json.Unmarshal([]byte(param["value"]), &conf)
	return
}

// 初始化大神推荐
func (r *Sparring) initRecommendCount(number float64, userId int64, page int) (err error) {
	// 如果用户id不为0，并且当前页大于1，取用户上次缓存
	if userId != 0 && page > 1 {
		r.cacheKeyUser = fmt.Sprintf("%s%d", utils.REDIS_RECOMMEND_SPARRING_EXCLUSIVE_USER, userId)
		// 查询用户上次缓存
		cache, _ := r.redis.Get(r.cacheKeyUser).Result()
		if cache != "" {
			json.Unmarshal([]byte(cache), &r.userCacheIds)
		}
	}
	// 查询总长度
	onlineCount, err := r.redis.ZCard(r.cacheKeyOnline).Result()
	if err != nil {
		return
	}
	offlineCount, err := r.redis.ZCard(r.cacheKeyOffline).Result()
	if err != nil {
		return
	}

	// 取前百分之n
	r.OnlineCount = int64(math.Ceil(float64(onlineCount) * number))
	r.OfflineCount = int64(math.Ceil(float64(offlineCount) * number))

	// 取前百分之大神id
	err = r.redis.ZRevRange(r.cacheKeyOnline, 0, r.OnlineCount).ScanSlice(&r.OnlineSet)
	if err != nil {
		return
	}

	err = r.redis.ZRevRange(r.cacheKeyOffline, 0, r.OfflineCount).ScanSlice(&r.OfflineSet)
	if err != nil {
		return
	}

	// 剔除用户已获取数据
	for _, v := range r.userCacheIds {
		for key, val := range r.OnlineSet {
			if v == val {
				r.OnlineSet = append(r.OnlineSet[:key], r.OnlineSet[key+1:]...)
				break
			}
		}
		for key, val := range r.OfflineSet {
			if v == val {
				r.OfflineSet = append(r.OfflineSet[:key], r.OfflineSet[key+1:]...)
				break
			}
		}
	}

	// 如果去重以后的数据长度为0,清空用户缓存
	if len(r.OnlineSet) == 0 && len(r.OfflineSet) == 0 {
		r.userCacheIds = r.userCacheIds[:0]

		// 取前百分之大神id
		err = r.redis.ZRevRange(r.cacheKeyOnline, 0, r.OnlineCount).ScanSlice(&r.OnlineSet)
		if err != nil {
			return
		}

		err = r.redis.ZRevRange(r.cacheKeyOffline, 0, r.OfflineCount).ScanSlice(&r.OfflineSet)
		if err != nil {
			return
		}
	}

	return
}

// 获取大神推荐
func (r *Sparring) GetRecommend(rp *GetRecommendParams) ([]int64, error) {
	countSize := rp.TotalSize
	err := r.initRecommendCount(rp.Percentage, rp.UserId, rp.Page)
	if err != nil {
		return nil, nil
	}

	// 获取在线数据
	err = r.getRecommendOnline(rp)
	if err != nil {
		return nil, err
	}
	// 在线数据不足,获取离线数据
	if len(r.recommendIds) < int(countSize) {
		rp.TotalSize = countSize - int64(len(r.recommendIds))
		err = r.getRecommendOffline(rp)
		if err != nil {
			return nil, err
		}
		r.recommendIds = append(r.recommendIds, r.recommendOfflineIds...)
	}

	if rp.UserId != 0 {
		r.userCacheIds = append(r.userCacheIds, r.recommendIds...)
		// 储存用户缓存
		marshal, _ := json.Marshal(r.userCacheIds)
		r.redis.Set(r.cacheKeyUser, string(marshal), time.Minute*10)
	}

	return r.recommendIds, nil
}

// 获取在线
func (r *Sparring) getRecommendOnline(rp *GetRecommendParams) (err error) {
	// 随机获取指定数量切片
	ids := randSlice(r.OnlineSet, int(rp.TotalSize))

	// 剔除已随机数据
	for _, v := range ids {
		for key, val := range r.OnlineSet {
			if v == val {
				r.OnlineSet = append(r.OnlineSet[:key], r.OnlineSet[key+1:]...)
				break
			}
		}
	}

	r.recommendIds = append(r.recommendIds, ids...)
	// 如果条数大于0
	if len(ids) > 0 {
		// 去重
		r.recommendIds = r.sliceRemoveRepeat(r.recommendIds, rp.PositionId)
		r.recommendIds = r.userIdRemoveRepeat(r.recommendIds, rp.PositionId)
	}

	// 如果条数为0
	// 没有剩余可查询位置
	// 返回
	if len(r.recommendIds) == 0 && len(r.OnlineSet) == 0 {
		return
	} else if len(r.OnlineSet) > 0 && (len(r.recommendIds) == 0 || len(r.recommendIds) < int(rp.TotalSize)) {
		// 如果条数为0
		// 有剩余可查询数量
		// 递归查询
		rp.TotalSize = rp.TotalSize - int64(len(r.recommendIds))
		return r.getRecommendOnline(rp)
	}
	return
}

// 获取离线
func (r *Sparring) getRecommendOffline(rp *GetRecommendParams) (err error) {
	ids := randSlice(r.OfflineSet, int(rp.TotalSize))
	// 剔除已随机数据
	for _, v := range ids {
		for key, val := range r.OfflineSet {
			if v == val {
				r.OfflineSet = append(r.OfflineSet[:key], r.OfflineSet[key+1:]...)
				break
			}
		}
	}

	r.recommendOfflineIds = append(r.recommendOfflineIds, ids...)
	// 如果条数大于0
	if len(r.recommendOfflineIds) > 0 {
		// 去重
		r.recommendOfflineIds = r.sliceRemoveRepeat(r.recommendOfflineIds, rp.PositionId)
		r.recommendOfflineIds = r.userIdRemoveRepeat(r.recommendOfflineIds, rp.PositionId)
	}

	// 如果条数为0
	// 没有剩余可查询位置
	if len(r.recommendOfflineIds) == 0 && len(r.OfflineSet) == 0 {
		return
	} else if len(r.OfflineSet) > 0 && (len(r.recommendOfflineIds) == 0 || len(r.recommendOfflineIds) < int(rp.TotalSize)) {
		// 如果条数为0
		// 有剩余可查询数量
		// 删除已查询数据
		// 递归查询
		rp.TotalSize = rp.TotalSize - int64(len(r.recommendOfflineIds))
		return r.getRecommendOffline(rp)
	}
	return
}

// 切片去重
func (r *Sparring) sliceRemoveRepeat(master []int64, servant []int64) []int64 {
	for _, v := range servant {
		for key, val := range master {
			if v == val {
				master = append(master[:key], master[key+1:]...)
				break
			}
		}
	}

	return master
}

// 使用大神id查询到userId,过滤相同的用户id
func (r *Sparring) userIdRemoveRepeat(ids []int64, positionId []int64) []int64 {
	sparringInfo := make(map[int64]dbmodels.AppSparringSkill)     // 可返回的大神信息
	sparringPosition := make(map[int64]dbmodels.AppSparringSkill) // 去重大神信息
	if len(positionId) > 0 {
		for _, val := range positionId {
			sparringRepeat, _ := new(dbmodels.AppSparringSkill).QueryBySkillId(val)
			sparringPosition[sparringRepeat.SkillUserID] = sparringRepeat
		}
	}
	// 查询大神
	for _, v := range ids {
		sparring, _ := new(dbmodels.AppSparringSkill).QueryBySkillId(v)
		// 如果用户id不存在推荐位
		if _, ok := sparringPosition[sparring.SkillUserID]; !ok {
			// 不存在则储存用户id
			// 因为是按照分数从大到小排序,所有这里只会优先储存分数最大的技能
			if _, ok := sparringInfo[sparring.SkillUserID]; !ok {
				sparringInfo[sparring.SkillUserID] = sparring
			}
		}
	}

	var tmp []int64
	for _, v := range sparringInfo {
		tmp = append(tmp, v.SkillID)
	}
	return tmp
}

// 返回随机数量切片
func randSlice(slice []int64, count int) []int64 {
	data := []int64{}
	tmp := make(map[int64]int)

	if len(slice) <= count {
		for _, v := range slice {
			data = append(data, v)
		}
		return data
	}

	for {
		if count == 0 {
			break
		}
		randKey := utils.FuncRandRangeInt(0, len(slice)-1)
		if _, ok := tmp[randKey]; !ok {
			tmp[randKey] = 1
			data = append(data, slice[randKey])
			count--
		}
	}

	return data
}

// 大神状态变更,从缓存中删除
func (s *Sparring) RemoveCache(skillId int64, skillSkillId int64) {
	var (
		err error
	)

	if err = new(dbmodels.AppSparringSkillScore).UpdateBySparringId(skillId, map[string]interface{}{
		"deleted": time.Now().Unix(),
	}); err != nil {
		utils.LogErrorF("delete app_sparring_skill_score error: %v", err.Error())
	}

	// 从推荐位删除
	new(dbmodels.AppRecommendIntervention).Delete(skillId)
	// 删除全局缓存
	s.redis.HDel(s.cacheKeyGlobal, fmt.Sprint(skillId))
	// 删除在线or离线缓存
	s.redis.ZRem(s.cacheKeyOnline, fmt.Sprint(skillId))
	s.redis.ZRem(s.cacheKeyOffline, fmt.Sprint(skillId))
	// 删除游戏缓存
	s.redis.ZRem(fmt.Sprintf("%s%d", s.cacheKeySkillOnline, skillSkillId), fmt.Sprint(skillId))
	s.redis.ZRem(fmt.Sprintf("%s%d", s.cacheKeySkillOffline, skillSkillId), fmt.Sprint(skillId))

	s.redis.Del(utils.REDIS_RECOMMEND_SPARRING_POSITION)
	s.redis.Del(utils.REDIS_RECOMMEND_SPARRING_EXCLUSIVE)
}

func (s *Sparring) RecoverCache(skillId int64, skillSkillId int64) {
	var (
		err        error
		scoreModel *dbmodels.AppSparringSkillScore
	)

	// 重新上架, 恢复数据
	// 获取 score 数据
	if scoreModel, err = new(dbmodels.AppSparringSkillScore).QueryBySparringSkillId(skillId); err != nil {
		utils.LogErrorF("get score record error: %v", err.Error())
		return
	}

	if err = new(dbmodels.AppSparringSkillScore).UpdateHasDeletedBySparringId(skillId, map[string]interface{}{
		"deleted": 0,
	}); err != nil {
		utils.LogErrorF("update score record error: %v", err.Error())
		return
	}

	// 刷新缓存
	refreshOnlineCache(scoreModel)
}

// 刷新在线 和 离线的数据缓存
func refreshOnlineCache(scoreModel *dbmodels.AppSparringSkillScore) {
	var (
		err                error
		sparringGlobalByte []byte
		userInfo           redismodels.UserInfo
	)

	// 获取 事务性 redis管道
	txPipeline := utils.RedisClient.TxPipeline()

	// 从redis 获取大神推荐 列表 全局缓存
	sparringGlobal := &SparringGlobal{
		UserId:          scoreModel.ScoreUserId,
		SparringSkillId: scoreModel.ScoreSparringSkillId,
		SkillId:         scoreModel.ScoreSkillId,
		Fraction:        scoreModel.ScoreRealScore + scoreModel.ScoreInterventionScore,
	}

	if sparringGlobalByte, err = sparringGlobal.MarshalBinary(); err != nil {
		utils.LogErrorF("marshal sparring global cache error: %v", err.Error())
		return
	}

	// 操作数据
	// 判断在线还是离线
	if userInfo, err = new(redismodels.UserInfo).GetUserInfo(sparringGlobal.UserId); err != nil {
		utils.LogErrorF("refreshOnlineCache:get user info error: %v", err.Error())
		return
	}

	txPipeline.HSet(utils.REDIS_RECOMMEND_SPARRING_GLOBAL, fmt.Sprintf("%v", scoreModel.ScoreSparringSkillId), sparringGlobalByte)

	// 在线
	if userInfo.UserIsOnline == 1 {
		// 存入 在线缓存
		saveSparringCacheToRedis(txPipeline,
			utils.REDIS_RECOMMEND_SPARRING_ONLINE,
			"save online cache error: %v",
			sparringGlobal)

		saveSparringCacheToRedis(txPipeline,
			utils.REDIS_RECOMMEND_SPARRING_SKILL_ONLINE+fmt.Sprintf("%v", sparringGlobal.SkillId),
			"save skill online cache error: %v",
			sparringGlobal)
	} else {
		// 不在线
		// 存入离线缓存
		saveSparringCacheToRedis(txPipeline,
			utils.REDIS_RECOMMEND_SPARRING_OFFLINE,
			"save offline cache error: %v",
			sparringGlobal)

		saveSparringCacheToRedis(txPipeline,
			utils.REDIS_RECOMMEND_SPARRING_SKILL_OFFLINE+fmt.Sprintf("%v", sparringGlobal.SkillId),
			"save skill offline cache error: %v",
			sparringGlobal)
	}

	// 执行所有语句
	if _, err = txPipeline.Exec(); err != nil {
		utils.LogErrorF("refresh online cache error: %v", err.Error())
	}

}

func saveSparringCacheToRedis(pipeline redis.Pipeliner, key, errInfo string, sparringGlobal *SparringGlobal) {
	var (
		err error
	)

	if err = pipeline.ZAdd(key, redis.Z{
		Score:  float64(sparringGlobal.Fraction),
		Member: sparringGlobal.SparringSkillId,
	}).Err(); err != nil {
		utils.LogErrorF(errInfo, err.Error())
	}
}
