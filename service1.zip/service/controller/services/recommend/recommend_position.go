package recommend

import (
	"gamers/controller/response"
	"gamers/models/dbmodels"
	"gamers/utils"

	"github.com/go-redis/redis"
	wr "github.com/mroth/weightedrand"
)

// 推荐位
type RecommendPosition struct {
	redis             *redis.Client
	weightRandUserIds map[int64]map[int]int // 每次随机出来的用户id,[用户id:[推荐位类型:1]]
}

const (
	INDEX_SPARRING_LEN  int = 7  // 首页推荐大神长度
	INDEX_EXCLUSIVE_LEN int = 16 // 首页专属推荐长度
)

const (
	// 首页推荐类型
	typeParty    int = iota // 派对
	typeLive                // 直播
	typeSparring            // 大神
)

func NewRecommendPosition() *RecommendPosition {
	return &RecommendPosition{
		redis:             utils.RedisClient,
		weightRandUserIds: make(map[int64]map[int]int),
	}
}

// 获取首页推荐大神(首页横向排放7条)
func (s *RecommendPosition) GetIndexSparring() (list []response.SearchRecommendSparring, err error) {
	sparringId := make([]int64, INDEX_SPARRING_LEN) // 大神id
	positionId := []int64{}                         // 存放随机过后的推荐位id
	// 查询大神推荐位
	position, err := new(dbmodels.AppRecommendIntervention).QuerySparringPosition()
	if err != nil {
		return nil, err
	}
	if len(position) > 0 {
		rand := s.getWeightRand(&position)
		for _, v := range rand {
			sparringId[v.InterventionPositionIndex] = v.InterventionContentId
			positionId = append(positionId, v.InterventionContentId)
		}
	}

	// 推荐位数量不足补充数据
	if len(positionId) < INDEX_SPARRING_LEN {

		// 需要获取的条数
		totalSize := int64(INDEX_SPARRING_LEN - len(positionId))
		// 获取大神推荐
		rp := GetRecommendParams{
			TotalSize:  totalSize,
			PositionId: positionId,
			Percentage: sparringPercentage,
		}
		recommend, err := NewSparring().GetRecommend(&rp)
		if err != nil {
			return nil, err
		}
		for _, v := range recommend {
			for key, val := range sparringId {
				if val == 0 {
					sparringId[key] = v
					break
				}
			}
		}
	}

	if len(sparringId) > 0 {
		// 获取大神信息
		sparringData, err := new(dbmodels.AppSparringSkill).QueryOrderIn(sparringId)
		if err != nil {
			return nil, err
		}

		if len(sparringData) > 0 {
			for _, v := range sparringData {
				s := response.SearchRecommendSparring{
					SparringId:   v.SkillID,
					SkillName:    v.AppSkill.SkillName,
					SkillType:    v.AppSkill.SkillType,
					UserId:       v.SystemUser.UserID,
					UserNickname: v.SystemUser.UserNickname,
					UserIconurl:  v.SystemUser.UserIconurl,
				}
				s.PriceWay, s.PricePrice = skillMinPrice(v)
				list = append(list, s)
			}
		}
	}

	return list, nil
}

// 获取首页专属推荐
func (s *RecommendPosition) GetExclusiveRecommend(page int, userId int64) (list []interface{}, err error) {
	var (
		start, end       int                                 // 推荐位起始位
		roomPosition     []dbmodels.AppRecommendIntervention // 存放房间推荐位
		sparringPosition []dbmodels.AppRecommendIntervention // 存放大神推荐位
		sparringId       []int64                             // 大神id
		roomId           []int64                             // 房间id
		positionKey      int                                 // 位置,当前页数减去总长度
	)
	list = make([]interface{}, INDEX_EXCLUSIVE_LEN)
	start = (page * INDEX_EXCLUSIVE_LEN) - INDEX_EXCLUSIVE_LEN
	end = start + INDEX_EXCLUSIVE_LEN - 1

	if page <= 0 {
		positionKey = 0
	} else {
		positionKey = (page * INDEX_EXCLUSIVE_LEN) - INDEX_EXCLUSIVE_LEN
	}

	// 获取推荐位
	position, err := new(dbmodels.AppRecommendIntervention).QueryExclusivePosition(start, end)
	if err != nil {
		return
	}

	// 取出大神和房间
	for _, v := range position {
		if v.InterventionContentType == dbmodels.INTERVENTION_CONTENT_TYPE_SPARRING {
			sparringPosition = append(sparringPosition, v)
		} else {
			roomPosition = append(roomPosition, v)
		}
	}

	// 如果有异常房间,剔除异常房间
	if len(roomPosition) > 0 {
		tmpRoomId := []int64{}
		for _, v := range roomPosition {
			tmpRoomId = append(tmpRoomId, v.InterventionContentId)
		}

		ids, err := new(dbmodels.AppLiveRoom).QueryInRoomIds(tmpRoomId)
		if err != nil {
			return nil, err
		}
		if len(ids) > 0 {
			idMap := make(map[int64]int)
			for _, v := range ids {
				idMap[v.RoomId] = 1
			}

			for range idMap {
				for key, val := range roomPosition {
					if _, ok := idMap[val.InterventionContentId]; !ok {
						roomPosition = append(roomPosition[:key], roomPosition[key+1:]...)
						break
					}
				}
			}
		} else {
			roomPosition = roomPosition[:0]
		}
	}

	// 随机房间id
	randRoomId := s.getWeightRand(&roomPosition)
	roomPosition = roomPosition[:0]
	for _, v := range randRoomId {
		roomId = append(roomId, v.InterventionContentId)
		roomPosition = append(roomPosition, *v)
	}

	// 随机大神id
	randSparringId := s.getWeightRand(&sparringPosition)
	sparringPosition = sparringPosition[:0]
	for _, v := range randSparringId {
		sparringId = append(sparringId, v.InterventionContentId)
		sparringPosition = append(sparringPosition, *v)
	}
	// 如果房间加上大神不足8条,获取推荐大神
	if INDEX_EXCLUSIVE_LEN > (len(roomPosition) + len(sparringPosition)) {
		rp := GetRecommendParams{
			Page:       page,
			UserId:     userId,
			TotalSize:  int64(INDEX_EXCLUSIVE_LEN - len(roomPosition) - len(sparringPosition)),
			Percentage: exclusiveSparringPercentage,
		}
		for _, v := range randSparringId {
			rp.PositionId = append(rp.PositionId, v.InterventionContentId)
		}
		recommend, err := NewSparring().GetRecommend(&rp)
		if err != nil {
			return nil, err
		}
		for _, v := range recommend {
			sparringId = append(sparringId, v)
		}
	}

	// 获取房间
	if len(roomId) > 0 {
		roomData, err := new(dbmodels.AppLiveRoom).QueryIn(roomId)
		if err != nil {
			return nil, err
		}
		for _, v := range roomData {
			for _, val := range roomPosition {
				if v.RoomId == val.InterventionContentId && list[val.InterventionPositionIndex-int64(positionKey)] == nil {
					var hot int
					hot = int(v.RoomHeat)
					// 处理热度为负数
					if v.RoomHeat < 0 {
						hot = 0
					}
					if v.RoomType == dbmodels.LIVE_ATTR_TYPE_LIVE {
						mod := response.IndexRecommendModel{
							Type: typeLive,
							LiveModel: response.IndexRecommendPart{
								RoomId:         v.RoomId,
								RoomType:       v.RoomType,
								RoomName:       v.RoomName,
								RoomPkState:    v.RoomPkState,
								RoomCover:      v.RoomCover,
								RoomAttrId:     v.RoomAttrId,
								RoomAttrName:   v.RoomLiveAttr.AttrName,
								RoomSpeakType:  v.RoomSpeakType,
								RoomLiveStatus: v.RoomStatus,
								UserIconurl:    v.SystemUser.UserIconurl,
								UserNickname:   v.SystemUser.UserNickname,
								Hot:            hot,
							},
						}
						list[val.InterventionPositionIndex-int64(positionKey)] = mod
					} else {
						mod := response.IndexRecommendModel{
							Type: typeParty,
							PartModel: response.IndexRecommendPart{
								RoomId:         v.RoomId,
								RoomType:       v.RoomType,
								RoomName:       v.RoomName,
								RoomCover:      v.RoomCover,
								RoomPkState:    v.RoomPkState,
								RoomAttrId:     v.RoomAttrId,
								RoomAttrName:   v.RoomLiveAttr.AttrName,
								RoomSpeakType:  v.RoomSpeakType,
								RoomLiveStatus: v.RoomStatus,
								UserIconurl:    v.SystemUser.UserIconurl,
								UserNickname:   v.SystemUser.UserNickname,
								Hot:            hot,
							},
						}
						list[val.InterventionPositionIndex-int64(positionKey)] = mod
					}
					break
				}
			}
		}
	}

	// 获取大神信息
	if len(sparringId) > 0 {
		sparringData, err := new(dbmodels.AppSparringSkill).QueryOrderIn(sparringId)
		if err != nil {
			return nil, err
		}

		// 优先存放预设推荐位大神
		useId := []int64{} // 已使用id
		for _, v := range sparringData {
			for _, val := range sparringPosition {
				if v.SkillID == val.InterventionContentId && list[val.InterventionPositionIndex-int64(positionKey)] == nil {
					priceWay, pricePrice := skillMinPrice(v)
					mod := response.IndexRecommendModel{
						Type: typeSparring,
						SparringModel: response.IndexRecommendSparring{
							SparringId:   v.SkillID,
							SkillName:    v.AppSkill.SkillName,
							SkillType:    v.AppSkill.SkillType,
							SkillIconurl: v.AppSkill.SkillIconurl,
							SkillInfo:    v.SkillInfo,
							UserId:       v.SystemUser.UserID,
							UserNickname: v.SystemUser.UserNickname,
							UserIconurl:  v.SystemUser.UserIconurl,
							PriceWay:     priceWay,
							PricePrice:   pricePrice,
						},
					}
					useId = append(useId, v.SkillID)
					list[val.InterventionPositionIndex-int64(positionKey)] = mod
				}
			}
		}

		// 剔除已排序数据
		for _, v := range useId {
			for key, val := range sparringData {
				if v == val.SkillID {
					sparringData = append(sparringData[:key], sparringData[key+1:]...)
					break
				}
			}
		}

		for k, v := range list {
			for key, val := range sparringData {
				if v == nil {
					priceWay, pricePrice := skillMinPrice(val)
					mod := response.IndexRecommendModel{
						Type: typeSparring,
						SparringModel: response.IndexRecommendSparring{
							SparringId:   val.SkillID,
							SkillName:    val.AppSkill.SkillName,
							SkillType:    val.AppSkill.SkillType,
							SkillIconurl: val.AppSkill.SkillIconurl,
							SkillInfo:    val.SkillInfo,
							UserId:       val.SystemUser.UserID,
							UserNickname: val.SystemUser.UserNickname,
							UserIconurl:  val.SystemUser.UserIconurl,
							PriceWay:     priceWay,
							PricePrice:   pricePrice,
						},
					}
					list[k] = mod
					sparringData = append(sparringData[:key], sparringData[key+1:]...)
					break
				}
			}
		}
	}

	// 如果是nil 删除
	for i := 0; i < INDEX_EXCLUSIVE_LEN; i++ {
		for k, v := range list {
			if v == nil {
				list = append(list[:k], list[k+1:]...)
				break
			}
		}
	}

	return
}

// 获取随机结果
func (s *RecommendPosition) getWeightRand(recommend *[]dbmodels.AppRecommendIntervention) (position []*dbmodels.AppRecommendIntervention) {
	// 按照编号进行分组
	bigGroup := make(map[int64][]dbmodels.AppRecommendIntervention)
	for _, v := range *recommend {
		bigGroup[v.InterventionPositionIndex] = append(bigGroup[v.InterventionPositionIndex], v)
	}

	// 遍历编号组,取出随机权重的推荐位
	for _, v := range bigGroup {
		// 获取推荐内容
		result := s.weightRand(&v)
		if result != nil {
			position = append(position, result)
		}
	}
	return
}

// 加权随机
func (s *RecommendPosition) weightRand(smallGroup *[]dbmodels.AppRecommendIntervention) (result *dbmodels.AppRecommendIntervention) {
	choice := []wr.Choice{}
	for _, v := range *smallGroup {
		// 过滤之前随机出来的用户id
		if arr, ok := s.weightRandUserIds[v.InterventionContentUserId]; !ok {
			// 不存在直接加入待随机切片
			choice = append(choice, wr.NewChoice(v.InterventionContentId, uint(v.InterventionContentWeight)))
		} else {
			// 兼容多种推荐位类型
			// 查询推荐位类型
			// 如果不存在相同类型推荐位
			// 加入随机切片
			if _, isSet := arr[v.InterventionContentType]; !isSet {
				choice = append(choice, wr.NewChoice(v.InterventionContentId, uint(v.InterventionContentWeight)))
			}
		}
	}
	if len(choice) == 0 {
		return
	}
	chooser, _ := wr.NewChooser(choice...)
	fruit := chooser.Pick().(int64) // 随机结果

	for _, v := range *smallGroup {
		if fruit == v.InterventionContentId {
			// 加入每次随机出来的用户
			if _, ok := s.weightRandUserIds[v.InterventionContentUserId]; !ok {
				s.weightRandUserIds[v.InterventionContentUserId] = map[int]int{v.InterventionContentType: 1}
			} else {
				s.weightRandUserIds[v.InterventionContentUserId][v.InterventionContentType] = 1
			}
			return &v
		}
	}
	return
}

// 获取技能最小单价
func skillMinPrice(sparringSkillData dbmodels.AppSparringSkill) (priceWay string, pricePrice int) {
	min := 0
	if len(sparringSkillData.AppSparringSkillPrice) == 0 {
		return
	}
	// 最小单价id
	minId := sparringSkillData.AppSparringSkillPrice[0].PricePriceId
	// 查询价格的最小id
	for k, v := range sparringSkillData.AppSparringSkillPrice {
		if v.PricePriceId < minId {
			minId = v.PricePriceId
			min = k
		}
	}
	// 单价(局/天)
	priceWay = sparringSkillData.AppSparringSkillPrice[min].AppSkillPrice.PriceWay
	// 价格(go币)
	pricePrice = int(sparringSkillData.AppSparringSkillPrice[min].PricePrice)
	return
}
