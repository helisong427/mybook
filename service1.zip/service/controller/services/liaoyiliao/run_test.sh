#!/bin/sh

# -covermode=count 表示 生成的二进制中包含覆盖率计数信息
# coverprofile 用来指定覆盖率信息写入到哪个文件
go test -covermode=count -coverprofile=test.out

# 把覆盖率文件转换成html并打开
go tool cover -html=test.out

# 删除产生的文件
rm -rf test.out

go test -cover -count 10  -benchmem  -bench=.
