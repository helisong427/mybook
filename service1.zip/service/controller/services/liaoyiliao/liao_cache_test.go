/**
 * @Author: 陈建君
 * @Date: 2021/3/14 2:41 下午
 * @Description:
 */

package liaoyiliao

import (
	"fmt"
	"strconv"
	"testing"

	"github.com/fatih/structs"
	. "github.com/smartystreets/goconvey/convey"

	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
)

func pre() {
	// 向数据库插入十条数据
	utils.GEngine.Exec("truncate table system_user")
	for i := 0; i < 10; i++ {
		err := utils.GEngine.Create(&dbmodels.SystemUser{
			UserMobile: fmt.Sprintf("1380000%d", i),
		}).Error
		if err != nil {
			panic(err)
		}
	}

	// 向缓存插入十条数据
	for i := 1; i < 20; i++ {
		rmod := redismodels.UserInfo{
			UserID:       int64(i),
			UserIconurl:  fmt.Sprintf("https://wwww.vspn.com/%d", i),
			UserNickname: fmt.Sprintf("测试%d", i),
			UserGender:   i % 2,
			UserIsOnline: dbmodels.USER_IS_ONLINE_ONLINE,
		}

		userStr := strconv.Itoa(int(rmod.UserID))
		err := utils.RedisClient.HMSet(utils.REDIS_USER_INFO+userStr, structs.Map(&rmod)).Err()
		if err != nil {
			panic(err)
		}
	}
}

func TestCacheMod_Cache(t *testing.T) {
	Convey("测试数据初始化", t, func() {
		pre()
		cache := NewCacheMod()
		// 全局数据初始化
		cache.InitGlobalCache()
		// 更新桶
		cache.RepCacheData()
		// 获取撩一撩用户列表
		data, err := cache.UserList(0, 0, 0, 4)
		So(err, ShouldEqual, nil)
		t.Log(data.List[0], data.List[1], data.List[2], data.List[3])

		data, err = cache.UserList(data.OffSet, data.RegOffSet, 0, 4)
		So(err, ShouldEqual, nil)
		t.Log(data.List[0], data.List[1], data.List[2], data.List[3])

		data, err = cache.UserList(data.OffSet, data.RegOffSet, 0, 4)
		So(err, ShouldEqual, nil)
		t.Log(data.List[0], data.List[1], data.List[2], data.List[3])

		data, err = cache.UserList(data.OffSet, data.RegOffSet, 0, 4)
		So(err, ShouldEqual, nil)
		t.Log(data.List[0], data.List[1], data.List[2], data.List[3])

	})
}

func TestCacheMod_Cache_New(t *testing.T) {
	Convey("测试新的流程", t, func() {
		pre()
		cache := NewCacheMod()
		// 全局数据初始化
		cache.InitGlobalCache()
		// 更新桶
		cache.RepCacheData()

		data, err := cache.UserList(0, -1, 0, 8)
		So(err, ShouldEqual, nil)
		t.Log(data.OffSet, data.RegOffSet)
		for _, i2 := range data.List {
			t.Log(i2)
		}
		for i := 0; i < 5; i++ {
			data, err = cache.UserList(data.OffSet, -1, 0, 10)
			So(err, ShouldEqual, nil)
			t.Log(data.OffSet, data.RegOffSet)
			for _, i2 := range data.List {
				t.Log(i2)
			}
		}

		// 插入一个注册用户
		newUser := &dbmodels.SystemUser{
			UserID:     123456,
			UserMobile: "1388888888",
		}

		rmod := redismodels.UserInfo{
			UserID:       newUser.UserID,
			UserIconurl:  fmt.Sprintf("https://wwww.vspn.com/%d", 123),
			UserNickname: fmt.Sprintf("测试%d", 123),
			UserGender:   1,
			UserIsOnline: dbmodels.USER_IS_ONLINE_ONLINE,
		}
		userStr := strconv.Itoa(int(rmod.UserID))
		err = utils.RedisClient.HMSet(utils.REDIS_USER_INFO+userStr, structs.Map(&rmod)).Err()
		So(err, ShouldEqual, nil)

		cache.AddGlobalCache(newUser)
		data, err = cache.UserList(0, 0, 0, 10)
		So(err, ShouldEqual, nil)
		t.Log(data.OffSet, data.RegOffSet)
		for _, i2 := range data.List {
			t.Log(i2)
		}
		for i := 0; i < 5; i++ {
			data, err = cache.UserList(data.OffSet, data.RegOffSet, 0, 10)
			So(err, ShouldEqual, nil)
			t.Log(data.OffSet, data.RegOffSet)
			for _, i2 := range data.List {
				t.Log(i2)
			}
		}
	})
}
