package services

import (
	"errors"
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/enum"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"gamers/utils/tencent/tencentIm"
	"github.com/go-redis/redis"
	"gorm.io/gorm"
	"time"
)

type CreateStudioResp struct {
	RoomInfo   dbmodels.AppLiveRoom       `json:"room_info"`
	Settlement response.LiveSettlementRes `json:"settlement"`
}

func GetOnlineMember(RoomId string) (onlineNum int) {
	key := utils.REDIS_LIVE_ONLINE_MEMBER_NUM + RoomId
	// 获取缓存
	onlineNum, err := utils.RedisClient.Get(key).Int()
	if err != nil && err != redis.Nil {
		utils.LogErrorF("获取直播间[%s]的在线人数失败,err:%s", RoomId, err.Error())
		return
	}
	return
}

func CreatStudioAndOpenLog(tx *gorm.DB, openLog *dbmodels.AppRoomOpenLog, liveRoom *dbmodels.AppLiveRoom, create bool) (err error) {
	// 如果是派对房间
	if liveRoom.RoomType == dbmodels.ROOM_TYPE_PARTY {
		err = liveRoom.CreateLiveRoom(true, tx)
		if err != nil {
			utils.LogErrorF("创建直播间失败，err:%s", err.Error())
			tx.Rollback()
			return
		}
		return
	}
	err = openLog.CreateOrUpdate(tx, true)
	if err != nil {
		utils.LogErrorF("创建直播记录失败，err:%s", err.Error())
		tx.Rollback()
		return
	}
	liveRoom.RoomLogId = openLog.LogId
	err = liveRoom.CreateLiveRoom(create, tx)
	if err != nil {
		utils.LogErrorF("创建直播间失败，err:%s", err.Error())
		tx.Rollback()
		return
	}
	openLog.LogRoomId = liveRoom.RoomId
	err = openLog.CreateOrUpdate(tx, false)
	if err != nil {
		utils.LogErrorF("更新直播间记录失败，err:%s", err.Error())
		tx.Rollback()
		return
	}
	return
}

func CreateNewStudio(paramJson *request.CreateStudioReq, tx *gorm.DB, userInfo *redismodels.UserInfo) (err error, localRoom dbmodels.AppLiveRoom) {
	localRoom = dbmodels.AppLiveRoom{
		RoomType:       *paramJson.RoomType,
		RoomName:       paramJson.RoomName,
		RoomSpeakType:  *paramJson.RoomSpeakType,
		RoomContent:    paramJson.RoomContent,
		RoomOpenIm:     dbmodels.ROOM_IM_STATUS_OPEN,
		RoomUserId:     userInfo.UserID,
		RoomCover:      paramJson.RoomCover,
		RoomTitle:      paramJson.RoomTitle,
		RoomBackground: paramJson.RoomBackground,
		RoomAttrId:     paramJson.RoomAttrId,
	}
	openLog := dbmodels.AppRoomOpenLog{
		LogAnchorId:      localRoom.RoomUserId,
		LogRoomType:      localRoom.RoomType,
		LogRoomAttrId:    localRoom.RoomAttrId,
		LogUnionId:       localRoom.RoomUnionId,
		LogAnchorUnionId: userInfo.UserUnionId,
	}

	if localRoom.RoomType == dbmodels.ROOM_TYPE_LIVE {
		localRoom.RoomLastOnline = time.Now().Unix()
		localRoom.RoomLiveStatus = dbmodels.ROOM_LIVE_STATUS_ON
		openLog.LogStartTime = localRoom.RoomLastOnline
		openLog.LogLiveStatus = localRoom.RoomLiveStatus
	} else {
		partyAttr, err := new(dbmodels.AppLiveAttr).GetPartyDefaultAttr()
		if err != nil {
			return err, localRoom
		}
		localRoom.RoomAttrId = partyAttr.AttrID
	}
	nameStr := localRoom.RoomName
	if len(localRoom.RoomName) > 10 {
		nameStr = localRoom.RoomName[0:10]
	}
	err = CreatStudioAndOpenLog(tx, &openLog, &localRoom, true)
	if err != nil {
		utils.LogErrorF("创建直播记录失败,err:%s", err.Error())
		tx.Rollback()
		return
	}
	err = tencentIm.CreatedGroup(localRoom.RoomId, nameStr)
	if err != nil {
		utils.LogErrorF("创建im失败,err:%s", err.Error())
		tx.Rollback()
		return
	}
	admin := dbmodels.AppRoomAdmin{
		AdminRole:   dbmodels.ROOM_ADMIN_ROLE_LANDLORD,
		AdminUserID: userInfo.UserID,
		AdminRoomID: localRoom.RoomId,
	}

	err = admin.CreateByTransaction(tx)
	if err != nil {
		utils.LogErrorF("创建房间管理员失败,err:%s", err.Error())
		tx.Rollback()
		return
	}
	return
}

func CreateUpdateStudio(paramJson *request.CreateStudioReq, tx *gorm.DB, userInfo *redismodels.UserInfo, room *dbmodels.AppLiveRoom, defaultAttr *dbmodels.AppLiveAttr) (err error) {
	err = new(dbmodels.AppRoomAdmin).QueryExitsMaster(userInfo.UserID, room.RoomId)
	if err != nil && err != gorm.ErrRecordNotFound {
		utils.LogErrorF("校验用户权限失败，err:%s", err.Error())
		tx.Rollback()
		return
	}
	if err == gorm.ErrRecordNotFound {
		err = errors.New("权限不足")
		tx.Rollback()
		return
	}
	log, err := new(dbmodels.AppRoomOpenLog).GetLogInfoById(room.RoomLogId)
	if err != nil && err != gorm.ErrRecordNotFound {
		utils.LogErrorF("获取房间开播记录失败，err:%s", err.Error())
		tx.Rollback()
		return
	}
	room.RoomLastOnline = time.Now().Unix()
	if err == nil {
		log.LogEndTime = room.RoomLastOnline
		err = log.CreateOrUpdate(tx, false)
	}
	attr, err := new(dbmodels.AppLiveAttr).GetAppLiveAttrById(paramJson.RoomAttrId)
	if err != nil {
		utils.LogErrorF("获取直播标签失败，err:%s", err.Error())
		tx.Rollback()
		return
	}
	// 如果直播间是关闭状态
	if room.RoomStatus == dbmodels.ROOM_STATUS_TIME_OUT_OFF || room.RoomStatus == dbmodels.ROOM_STATUS_ADMIN_OFF {
		closeLog, err := new(dbmodels.AppRoomCloseLog).GetLastCloseInfoByRoomId(room.RoomId, dbmodels.CLOSE_LOG_TYPE_ADMIN_CLOSE, dbmodels.CLOSE_LOG_TYPE_TIMEOUT_CLOSE)
		if err != nil && err != gorm.ErrRecordNotFound {
			utils.LogErrorF("查询关播日志出错,err:%s", err.Error())
		}
		if err != nil {
			return err
		}
		closeLog.LogEndTime = time.Now().Unix()
		err = closeLog.Update(tx)
		if err != nil {
			tx.Rollback()
			utils.LogErrorF("关闭房间日志更新失败[%d],%s", room.RoomId, err.Error())
			return err
		}
		room.RoomStatus = dbmodels.ROOM_STATUS_OK
	}
	room.RoomType = dbmodels.ROOM_TYPE_LIVE
	room.RoomCover = paramJson.RoomCover
	room.RoomName = paramJson.RoomName
	room.RoomSpeakType = *paramJson.RoomSpeakType
	room.RoomContent = paramJson.RoomContent
	room.RoomTitle = paramJson.RoomTitle
	room.RoomBackground = paramJson.RoomBackground
	//直播房间开启
	room.RoomLiveStatus = dbmodels.ROOM_LIVE_STATUS_ON
	room.RoomOldAttrId = defaultAttr.AttrID
	room.RoomAttrId = paramJson.RoomAttrId
	room.RoomLiveAttr = attr
	openLog := dbmodels.AppRoomOpenLog{
		LogAnchorId:      room.RoomUserId,
		LogRoomType:      room.RoomType,
		LogRoomAttrId:    paramJson.RoomAttrId,
		LogStartTime:     room.RoomLastOnline,
		LogLiveStatus:    room.RoomLiveStatus,
		LogUnionId:       room.RoomUnionId,
		LogAnchorUnionId: userInfo.UserUnionId,
	}
	err = CreatStudioAndOpenLog(tx, &openLog, room, false)
	if err != nil {
		utils.LogErrorF("创建直播记录失败，err:%s", err.Error())
		tx.Rollback()
		return
	}
	return
}

func UpdateStudioInfo(paramJson *request.UpdateStudioReq, room *dbmodels.AppLiveRoom, anchor *dbmodels.AppAnchorSkill) (err error) {
	tx := utils.GEngine.Begin()
	room.RoomCover = paramJson.RoomCover
	room.RoomName = paramJson.RoomName
	room.RoomSpeakType = paramJson.RoomSpeakType
	room.RoomContent = paramJson.RoomContent
	room.RoomTitle = paramJson.RoomTitle
	room.RoomBackground = paramJson.RoomBackground
	//直播房间开启

	room.RoomOpenIm = paramJson.RoomOpenIm
	room.RoomEggbreakMsg = paramJson.RoomEggbreakMsg
	room.RoomPassword = paramJson.RoomPassword
	// 修改房间信息后改为未审核
	room.RoomIsReview = enum.MaterialIsNotReview
	partyAttr, err := new(dbmodels.AppLiveAttr).GetPartyDefaultAttr()
	if err != nil {
		return err
	}
	// 如果是直播类型
	if paramJson.RoomType == dbmodels.ROOM_TYPE_LIVE {
		if paramJson.RoomType == room.RoomType {
			err = room.CreateLiveRoom(false, tx)
			if err != nil {
				utils.LogErrorF("更新直播间失败，err:%s", err.Error())
				tx.Rollback()
				return
			}
			err = tx.Commit().Error
			return
		}
		room.RoomLiveStatus = dbmodels.ROOM_LIVE_STATUS_ON
		room.RoomAttrId = anchor.SkillAttrId
		room.RoomOldAttrId = partyAttr.AttrID
		attr, err := new(dbmodels.AppLiveAttr).GetAppLiveAttrById(anchor.SkillAttrId)
		if err != nil {
			utils.LogErrorF("获取直播标签失败，err:%s", err.Error())
			tx.Rollback()
			return err
		}
		room.RoomLiveAttr = attr
		room.RoomType = paramJson.RoomType
		room.RoomLastOnline = time.Now().Unix()
		openLog := dbmodels.AppRoomOpenLog{
			LogAnchorId:   room.RoomUserId,
			LogRoomType:   room.RoomType,
			LogRoomAttrId: room.RoomAttrId,
			LogStartTime:  room.RoomLastOnline,
			LogLiveStatus: room.RoomLiveStatus,
		}
		err = CreatStudioAndOpenLog(tx, &openLog, room, false)
		if err != nil {
			utils.LogErrorF("创建直播记录失败，err:%s", err.Error())
			tx.Rollback()
			return err
		}
	} else {
		if paramJson.RoomType == room.RoomType {
			err = room.CreateLiveRoom(false, tx)
			if err != nil {
				utils.LogErrorF("更新直播间失败，err:%s", err.Error())
				tx.Rollback()
				return
			}
			err = tx.Commit().Error
			return
		}
		// 判断如果是直播状态,则下播
		if room.RoomType == dbmodels.ROOM_TYPE_LIVE {
			err = new(dbmodels.AppRoomOpenLog).QuitLive(tx, room.RoomLogId)
			if err != nil {
				utils.LogErrorF("更新房间下播失败，err:%s", err.Error())
				tx.Rollback()
				return err
			}
			room.RoomLogId = 0
			room.RoomLiveStatus = dbmodels.ROOM_LIVE_STATUS_OFF
			room.RoomLastOffline = time.Now().Unix()
		}
		room.RoomOldAttrId = room.RoomAttrId
		room.RoomAttrId = partyAttr.AttrID
		room.RoomLiveAttr = partyAttr
		room.RoomType = paramJson.RoomType
		err = room.CreateLiveRoom(false, tx)
		if err != nil {
			utils.LogErrorF("创建直播间失败，err:%s", err.Error())
			tx.Rollback()
			return err
		}
	}
	err = tx.Commit().Error
	return
}
