package services

import (
	"encoding/json"
	"errors"
	"fmt"
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"github.com/go-redis/redis"
	"gorm.io/gorm"
	"time"
)

//商城--购买道具
func ShoppingBuyProp(paramsJSON request.ShoppingBuyPropReq, userId int64) (msg string, userBuyOver int64, data dbmodels.AppBackpack, err error) {
	msg = "购买失败"

	//只有锤子可以买多个
	if paramsJSON.PropType != dbmodels.DB_PROP_TYPE_HAMMER && paramsJSON.BuyNum > 1 {
		msg = "该道具只能购买一个"
		err = errors.New(msg)
		return
	}

	//检查礼物类型
	transactionType, ok := dbmodels.TransactionTypeMap[paramsJSON.PropType]
	if !ok {
		msg = "类型错误"
		err = errors.New(msg)
		return
	}

	//查询道具是否存在
	propData, err := new(dbmodels.AppProp).GetPropById(paramsJSON.PropId, paramsJSON.PropType)
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	if propData.PropId == 0 {
		msg = "购买的道具不存在"
		err = errors.New(msg)
		return
	}

	//查询用户信息
	info, err := new(redismodels.UserInfo).GetUserInfo(userId)
	if err != nil {
		return
	}

	if propData.PropVipLevel > info.VipLevel {
		msg = fmt.Sprintf("需要到达vip%d才能解锁", propData.PropVipLevel)
		err = errors.New(msg)
		return
	}

	//总价
	totalPrice := paramsJSON.BuyNum * propData.PropPrice
	if info.WalletTotalOver < totalPrice {
		msg = "余额不足"
		err = errors.New(msg)
		return
	}

	//查询是购买过此道具
	backPack, err := new(dbmodels.AppBackpack).QueryFirstPropId(userId, paramsJSON.PropId, paramsJSON.PropType)
	if err != nil && err != gorm.ErrRecordNotFound {
		return msg, userBuyOver, dbmodels.AppBackpack{}, err
	}

	//查询装饰物是否重复购买
	if paramsJSON.PropType != dbmodels.DB_PROP_TYPE_HAMMER && backPack.BackpackId != 0 {
		msg = "未过期物品不能重复购买"
		err = errors.New(msg)
		return msg, userBuyOver, dbmodels.AppBackpack{}, err
	}

	tx := utils.GEngine.Begin()
	//操作背包表
	backpackModel := dbmodels.AppBackpack{
		BackpackUserId:     userId,
		BackpackPropType:   paramsJSON.PropType,
		BackpackPropId:     paramsJSON.PropId,
		BackpackCount:      paramsJSON.BuyNum,
		BackpackPropAttrId: propData.PropAttrId,
	}
	//购买装饰物品,计算过期时间
	if paramsJSON.PropType != dbmodels.DB_PROP_TYPE_HAMMER {
		//过期天数为0,永久
		if propData.PropExpiredTime == 0 {
			backpackModel.BackpackExpiredTime = 0
		} else {
			//计算n天后的过期时间
			backpackModel.BackpackExpiredTime = time.Now().AddDate(0, 0, int(propData.PropExpiredTime)).Unix()
		}
	}

	if backPack.BackpackId == 0 {
		data, err = backpackModel.Create(tx)
	} else {
		data, err = backpackModel.AddCount(tx, backPack.BackpackId, paramsJSON.BuyNum)
	}

	if err != nil {
		tx.Rollback()
		return
	}

	//增加流水日志
	transaction := dbmodels.AppTransaction{
		TransactionId:            dbmodels.IDBuilderGetId(utils.REDIS_IDBUILDER_TRANSACTION_ID),
		TransactionType:          transactionType,
		TransactionAmount:        totalPrice,
		TransactionFromUserId:    userId,
		TransactionRemark:        fmt.Sprintf("购买:%s", propData.PropName),
		TransactionStatus:        dbmodels.DB_TRANSACTION_COMPLETE,
		TransactionToAccountType: dbmodels.DB_ACCOUNT_TYPE_PLATFORM,
	}

	err = transaction.Create(tx)
	if err != nil {
		tx.Rollback()
		return
	}

	//增加日志
	backpackLogModel := dbmodels.AppBackpackLog{
		LogUserId:   int64(userId),
		LogTypeId:   transaction.TransactionId,
		LogPropType: paramsJSON.PropType,
		LogPropId:   paramsJSON.PropId,
		LogType:     dbmodels.DB_APP_BACK_PACK_LOG_LOG_TYPE_BUY,
		LogCount:    paramsJSON.BuyNum,
	}
	err = backpackLogModel.Create(tx)
	if err != nil {
		tx.Rollback()
		return
	}

	//减少用户余额
	over, err := new(dbmodels.AppUserWallet).UpdateWalletTotalOver(tx, userId, false, false, totalPrice)
	if err != nil {
		tx.Rollback()
		return
	}
	//修改用户余额缓存
	err = new(redismodels.UserInfo).UpdateUserWalletTotalOver(userId, over.WalletTotalOver)
	if err != nil {
		tx.Rollback()
		return
	}
	tx.Commit()
	userBuyOver = over.WalletTotalOver
	return
}

//商城--装扮属性
func ShoppingDressAttr() (r []response.ShoppingDressAttr, err error) {
	//查询所有装扮的属性
	attrAll, err := new(dbmodels.AppPropAttr).QueryDressAll()
	if err != nil {
		return
	}
	attr := []int{}
	attr = append(attr, dbmodels.PROP_TYPE_ICON_STYLE)
	attr = append(attr, dbmodels.PROP_TYPE_PET_STYLE)
	attr = append(attr, dbmodels.PROP_TYPE_CHAT_STYLE)

	for _, v := range attr {
		attrList := []response.AttrList{}
		for _, val := range attrAll {
			if v == val.AttrType {
				attrList = append(attrList, response.AttrList{
					AttrId:   val.AttrId,
					AttrName: val.AttrName,
				})
			}
		}

		if attrName, ok := dbmodels.DbPropTypeMap[v]; ok {
			r = append(r, response.ShoppingDressAttr{
				PropTypeName: attrName,
				PropType:     v,
				AttrList:     attrList,
			})
		}
	}
	return
}

//商城--装扮列表
func ShoppingDressUpList(paramsJSON request.ShoppingDressUpListReq, userId int64) (r response.BasePageList, err error) {
	var attrIds []int64 //装扮属性id
	r.Page = paramsJSON.Page
	r.Size = paramsJSON.Size
	list := []response.ShoppingDressUpList{}
	//查询所有装扮
	total, propData, err := new(dbmodels.AppProp).QueryDressPage(paramsJSON.Page, paramsJSON.Size, paramsJSON.PropType, paramsJSON.AttrId)
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	if total == 0 {
		r.Total = 0
		r.TotalPages = 0
		return
	}
	//获取禁止购买的attr_id
	param, err := new(dbmodels.SystemParam).QueryKey(dbmodels.PARAM_KEY_DRESS_PROHIBITED_TO_BUY_ATTR_ID)
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}
	if len(param) > 0 {
		err = json.Unmarshal([]byte(param["value"]), &attrIds)
		if err != nil {
			return
		}
	}

	//查询已拥有装扮
	backPack, err := new(dbmodels.AppBackpack).QueryDressType(userId, paramsJSON.PropType, paramsJSON.AttrId)
	if err != nil && err != gorm.ErrRecordNotFound {
		return
	}

	//查询用户使用中的装扮
	info, err := new(redismodels.MsgUserObj).GetMsgUserInfo(userId, map[string]bool{"icon": true, "chat": true, "comeIn": true})
	if err != nil && err != redis.Nil {
		return
	}

	for _, v := range propData {
		prop := response.ShoppingDressUpList{
			PropId:          v.PropId,
			PropName:        v.PropName,
			PropRemark:      v.PropRemark,
			PropType:        v.PropType,
			PropVipLevel:    v.PropVipLevel,
			PropPrice:       v.PropPrice,
			PropOrgPrice:    v.PropOrgPrice,
			PropIcon:        v.PropIcon,
			PropUrl:         v.PropUrl,
			PropExpiredTime: v.PropExpiredTime,
			IsBuy:           0,
			IsDressUp:       0,
			LastTime:        0,
			ProhibitedToBuy: 0,
		}
		for _, attrIds := range attrIds {
			if v.PropAttrId == attrIds {
				prop.ProhibitedToBuy = 1 //禁止购买
			}
		}

		if len(backPack) > 0 {
			for _, val := range backPack {
				if val.BackpackPropId == v.PropId {
					//是否穿戴
					prop.IsBuy = 1
					prop.LastTime = val.BackpackExpiredTime
					//是否穿戴
					if val.BackpackPropType == dbmodels.DB_PROP_TYPE_TYPE_AVATAR {
						//头像框
						if info.IconStyle.IconId == val.BackpackPropId {
							prop.IsDressUp = 1
						}

					} else if val.BackpackPropType == dbmodels.DB_PROP_TYPE_TYPE_CHAT {
						//聊天框
						if info.ChatStyle.ChatId == val.BackpackPropId {
							prop.IsDressUp = 1
						}

					} else if val.BackpackPropType == dbmodels.DB_PROP_TYPE_TYPE_CAR {
						//座驾
						if info.ComeInStyle.ComeInId == val.BackpackPropId {
							prop.IsDressUp = 1
						}
					}
				}
			}
		}

		list = append(list, prop)
	}
	r.Total = total
	r.TotalPages = utils.FuncTotalPages(total, paramsJSON.Size)
	r.List = list

	return
}

//商城--使用装扮
func ShoppingDressUpUse(userId int64, paramsJSON request.ShoppingDressUpUseReq) (err error) {
	//查询是否购买装扮
	backPack, err := new(dbmodels.AppBackpack).QueryFirstPropId(userId, paramsJSON.PropId, paramsJSON.PropType)
	if err != nil {
		return
	}
	//增加使用日志
	tx := utils.GEngine
	model := dbmodels.AppBackpackLog{
		LogType:     dbmodels.DB_APP_BACK_PACK_LOG_LOG_TYPE_USE,
		LogTypeId:   backPack.BackpackId,
		LogUserId:   backPack.BackpackUserId,
		LogPropId:   backPack.BackpackPropId,
		LogPropType: backPack.BackpackPropType,
		LogCount:    1,
	}
	err = model.Create(tx)
	if err != nil {
		return
	}
	switch backPack.BackpackPropType {
	case dbmodels.DB_PROP_TYPE_TYPE_AVATAR: //头像框
		err = new(redismodels.IconStyle).Set(userId, backPack.BackpackPropId, backPack.AppProp.PropUrl, backPack.BackpackExpiredTime)
	case dbmodels.DB_PROP_TYPE_TYPE_CHAT: //聊天框
		err = new(redismodels.ChatStyle).Set(userId, backPack.BackpackPropId, backPack.AppProp.PropUrl, backPack.BackpackExpiredTime)
	case dbmodels.DB_PROP_TYPE_TYPE_CAR: //座驾(入场)
		err = new(redismodels.ComeInStyle).Set(userId, backPack.BackpackPropId, backPack.AppProp.PropUrl, backPack.AppProp.PropUrl1, backPack.BackpackExpiredTime)
	default:
	}

	return
}

//商城--取下装扮
func ShoppingDressTakeOff(userId int64, paramsJSON request.ShoppingDressTakeOffReq) (err error) {
	switch paramsJSON.PropType {
	case dbmodels.DB_PROP_TYPE_TYPE_AVATAR: //头像框
		err = new(redismodels.IconStyle).Del(userId)
	case dbmodels.DB_PROP_TYPE_TYPE_CHAT: //聊天框
		err = new(redismodels.ChatStyle).Del(userId)
	case dbmodels.DB_PROP_TYPE_TYPE_CAR: //座驾(入场)
		err = new(redismodels.ComeInStyle).Del(userId)
	default:

	}
	return
}
