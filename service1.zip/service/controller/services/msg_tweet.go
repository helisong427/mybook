package services

import (
	"fmt"
	"gamers/models/dbmodels"
	"gamers/models/redismodels"
	"gamers/utils"
	"strconv"
	"strings"

	jsoniter "github.com/json-iterator/go"
)

// 朋友圈的消息
type TweetAction interface {
	Like()
	Comment()
	Dislike()
}
type Tweet struct {
}

func InitTweet() Tweet {
	return Tweet{}
}

// 媒体文件
type TweetAttachments struct {
	Type   string `json:"type"`   //附件类型
	Url    string `json:"url"`    //附件地址
	Width  string `json:"width"`  //附件宽度
	High   string `json:"high"`   //附件高度
	Length int    `json:"length"` //时长(视频/音频)
}

const (
	TWEET_KEY_LIKE            = "interactive_tweet_like"
	TWEET_KEY_TWEET_COMMENT   = "interactive_tweet_comment"
	TWEET_KEY_TWEET_ATTENTION = "interactive_tweet_attention"
	TWEET_KEY_COMMENT_COMMENT = "interactive_comment_comment"
)

// 评论
func (t Tweet) Comment(tweet dbmodels.AppTweet, userInfo redismodels.MsgUserObj, comment *dbmodels.AppTweetComment) {
	var media []TweetAttachments
	err := jsoniter.Unmarshal([]byte(tweet.TweetAttachment), &media)
	if err != nil {
		utils.LogErrorF("反序列化朋友圈媒体文件失败,err:%s", err.Error())
		return
	}
	key := TWEET_KEY_TWEET_COMMENT
	if comment.CommentToParentID != 0 {
		key = TWEET_KEY_COMMENT_COMMENT
	}
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(key)
	if err != nil {
		utils.LogErrorF("获取申请评论消息model失败,err:%s", err.Error())
		return
	}
	target := strconv.Itoa(int(tweet.TweetUserID))
	tip := userInfo.NickName + msgModel.MsgContent
	if comment.CommentToParentID == 0 {
		// 自己评论，不推送
		if userInfo.UserId == tweet.TweetUserID {
			return
		}
		// 写历史记录表
		tweetLog := dbmodels.AppTweetVisitorLog{
			LogMediaType:     tweet.TweetType,
			LogTweetId:       tweet.TweetID,
			LogOperateUserId: userInfo.UserId,
			LogType:          dbmodels.TWEET_LOG_TYPE_COMMENT,
			LogComment:       comment.CommentContent,
			LogTips:          msgModel.MsgContent,
			LogTweetUserId:   tweet.TweetUserID,
			LogTweetContent:  tweet.TweetContent,
		}
		if len(media) > 0 {
			tweetLog.LogMediaUrl = media[0].Url
		}
		err = tweetLog.Create()
		if err != nil {
			return
		}
	} else {
		_, data, err := new(dbmodels.AppTweetComment).QueryFirst(int(comment.CommentToParentID))
		if err != nil {
			utils.LogErrorF("发送朋友圈评论推送失败,查询父评论失败:%s", err.Error())
			return
		}
		// 写历史记录表
		tweetLog := dbmodels.AppTweetVisitorLog{
			LogMediaType:     tweet.TweetType,
			LogTweetId:       tweet.TweetID,
			LogOperateUserId: userInfo.UserId,
			LogType:          dbmodels.TWEET_LOG_TYPE_REPLY,
			LogComment:       data.CommentContent,
			LogTips:          msgModel.MsgContent,
			LogTweetUserId:   comment.CommentToUserID,
			LogTweetContent:  data.CommentContent,
		}
		err = tweetLog.Create()
		if err != nil {
			return
		}
		target = fmt.Sprintf("%d", comment.CommentToUserID)
	}
	interMsg := &redismodels.InteractiveMsg{
		Tips:              tip,
		Title:             msgModel.MsgTitle,
		Text:              tip,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{InteractiveMsg: interMsg}
	err = msg.InteractiveMsg.SendInteractiveMsg(redismodels.MSG_ADMIN_USER_INTERACTIVEMSG, target)
	if err != nil {
		utils.LogErrorF("发送朋友圈评论推送失败,err:%s", err.Error())
	}
	return
}

// 点赞消息
func (t Tweet) Like(tweet dbmodels.AppTweet, userInfo redismodels.MsgUserObj) {
	var media []TweetAttachments
	err := jsoniter.Unmarshal([]byte(tweet.TweetAttachment), &media)
	if err != nil {
		utils.LogErrorF("反序列化朋友圈媒体文件失败,err:%s", err.Error())
		return
	}

	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(TWEET_KEY_LIKE)
	if err != nil {
		utils.LogErrorF("获取申请点赞消息model失败,err:%s", err.Error())
		return
	}
	// 写历史记录表
	tweetLog := dbmodels.AppTweetVisitorLog{
		LogMediaType:     tweet.TweetType,
		LogTweetId:       tweet.TweetID,
		LogOperateUserId: userInfo.UserId,
		LogType:          dbmodels.TWEET_LOG_TYPE_LIKE,
		LogTips:          msgModel.MsgContent,
		LogTweetUserId:   tweet.TweetUserID,
		LogTweetContent:  tweet.TweetContent,
	}
	if len(media) > 0 {
		tweetLog.LogMediaUrl = media[0].Url
	}
	err = tweetLog.Create()
	if err != nil {
		utils.LogInfoF("创建点赞记录失败,err:%s", err.Error())
		return
	}
	interMsg := &redismodels.InteractiveMsg{
		Tips:              userInfo.NickName + msgModel.MsgContent,
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{InteractiveMsg: interMsg}
	err = msg.InteractiveMsg.SendInteractiveMsg(redismodels.MSG_ADMIN_USER_INTERACTIVEMSG, strconv.Itoa(int(tweet.TweetUserID)))
	if err != nil {
		utils.LogErrorF("发送朋友圈点赞推送失败,err:%s", err.Error())
	}
	return
}

// 取消点赞
func (t Tweet) DisLike(tweet dbmodels.AppTweet, userInfo redismodels.MsgUserObj) (err error) {
	tweetLog := dbmodels.AppTweetVisitorLog{
		LogMediaType:     tweet.TweetType,
		LogTweetId:       tweet.TweetID,
		LogOperateUserId: userInfo.UserId,
		LogType:          dbmodels.TWEET_LOG_TYPE_LIKE,
		LogTweetUserId:   tweet.TweetUserID,
		LogTweetContent:  tweet.TweetContent,
	}
	err = tweetLog.Deleted()
	return
}

// 关注的人发动态
func (t Tweet) NewTweet(tweet *dbmodels.AppTweet) {
	msgModel, err := new(dbmodels.AppMsgModel).GetMsgByKey(TWEET_KEY_TWEET_ATTENTION)
	if err != nil {
		utils.LogErrorF("获取朋友圈新动态推送消息model失败,err:%s", err.Error())
		return
	}
	userInfo, err := new(redismodels.UserInfo).GetUserInfo(tweet.TweetUserID)
	if err != nil {
		utils.LogErrorF("获取朋友圈用户信息失败,err:%s", err.Error())
		return
	}
	tip := strings.NewReplacer("${nickname}", userInfo.UserNickname).Replace(msgModel.MsgContent)
	assistantMsg := &redismodels.AssistantMsg{
		Type:              redismodels.MSG_ASSISTANT_TYPE_ACTION,
		ActionType:        redismodels.MSG_ACTION_TYPE_TWEET_INFO,
		Action:            fmt.Sprintf("%d", tweet.TweetID),
		Title:             msgModel.MsgTitle,
		Text:              tip,
		ActionParams:      map[string]interface{}{"tweet_id": tweet.TweetID},
		NotificationClose: msgModel.MsgNotificationClose,
	}
	msg := &redismodels.AppMsg{AssistantMsg: assistantMsg}
	err = msg.AssistantMsg.PushAssistantMsg(redismodels.MSG_ADMIN_USER_ASSISTANT, fmt.Sprintf("%d", tweet.TweetUserID))
	if err != nil {
		utils.LogErrorF("朋友圈新动态推送消息失败,err:%s", err.Error())
	}
	return
}
