package services

import (
	"errors"
	"fmt"
	"gamers/controller/response"
	"gamers/controller/services/liaoyiliao"
	"gamers/middleware"
	"gamers/models/dbmodels"
	"gamers/utils"
	"gamers/utils/chuanglan/shanyan"
	"gamers/utils/ymd"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/go-redis/redis"
	"gorm.io/gorm"
)

type loginStrategy interface {
	Login(c *gin.Context) (user response.UserLoginRep, msg string, err error)
}

//密码登录
type PasswordLogin struct {
	Mobile   string
	Password string
	ipv4     uint
}

//手机号一键登录
type MobileLogin struct {
	Token      string
	Openid     string
	Opentype   int
	ClientType int
	ipv4       uint
}

//验证码登录
type SmsCodeLogin struct {
	Mobile string
	Code   int
	ipv4   uint
}
type SmsCodeMultiLogin struct {
	Mobile string
	Code   int
	ipv4   uint
}

//第三方登录
type OpenidLogin struct {
	Openid    string
	Nickname  string
	Gender    int
	Iconurl   string
	Opentype  int
	Timestamp int
	Uuid      string
	Sign      string
	ipv4      uint
}

type LoginContext struct {
	Strategy loginStrategy
}

func NewLogin(loginFunc interface{}) LoginContext {
	m := new(LoginContext)
	m.Strategy = loginFunc.(loginStrategy)
	return *m
}

func (m *LoginContext) Login(c *gin.Context) (r response.UserLoginRep, msg string, err error) {
	r, msg, err = m.Strategy.Login(c)
	return
}

func loginHandler(user *dbmodels.SystemUser, c *gin.Context) (r response.UserLoginRep, msg string, err error) {
	update := make(map[string]interface{})
	ipv4, _ := utils.FuncIPv42Int(c.ClientIP())
	update["user_last_login_ip"] = ipv4
	update["user_status"] = 0
	update["user_last_login_time"] = time.Now().Unix()
	new(dbmodels.SystemUser).Update(user.UserID, update)

	//登录获取token
	token, refreshToken, err := middleware.UserToken(user.UserID)
	if err != nil {
		return r, "登录失败", fmt.Errorf("create user token err :%s", err.Error())
	}
	//后续赋值
	c.Header("Access-Token", token)
	c.Header("Refresh-Token", refreshToken)
	//获取登录信息
	r = getLoginInfo(user, c)
	return
}

//多点登录
func loginMultiHandler(user *dbmodels.SystemUser, c *gin.Context) (r response.UserLoginRep, msg string, err error) {
	update := make(map[string]interface{})
	ipv4, _ := utils.FuncIPv42Int(c.ClientIP())
	update["user_last_login_ip"] = ipv4
	update["user_status"] = 0
	update["user_last_login_time"] = time.Now().Unix()
	new(dbmodels.SystemUser).Update(user.UserID, update)
	var token, refreshToken = "", ""
	userIDString := strconv.FormatInt(user.UserID, 10)
	oldToken, _ := utils.RedisClient.HGet(utils.REDIS_USER_INFO+userIDString, "Token").Result()
	if oldToken != "" {
		token, refreshToken, err = middleware.UserMultiToken(user.UserID, oldToken)
	} else {
		//登录获取token
		token, refreshToken, err = middleware.UserToken(user.UserID)
	}
	if err != nil {
		return r, "登录失败", fmt.Errorf("create user token err :%s", err.Error())
	}
	//后续赋值
	c.Header("Access-Token", token)
	c.Header("Refresh-Token", refreshToken)
	//获取登录信息
	r = getLoginInfo(user, c)
	return
}

//获取登录信息
func getLoginInfo(user *dbmodels.SystemUser, c *gin.Context) (r response.UserLoginRep) {
	now := time.Now().Unix()
	r.Nickname = user.UserNickname
	r.Gender = user.UserGender
	r.Iconurl = user.UserIconurl
	r.UserId = user.UserID
	r.IsBindMobile = 1
	r.IsSetInfo = 0
	r.IsSuper = user.UserIsSuper
	if user.UserNickname != "" && user.UserGender > 0 {
		r.IsSetInfo = 1
	}
	//当日首次登录标记
	if !ymd.IsSameDay(time.Unix(now, 0), time.Unix(int64(user.UserLastLoginTime), 0)) {
		r.IsFirstOnDay = 1
	}
	go updateLoginInfo(user.UserID, c)
	return
}

//更新登录信息
func updateLoginInfo(userId int64, c *gin.Context) {
	now := time.Now().Unix()
	ip := c.ClientIP()
	ipv4, _ := utils.FuncIPv42Int(ip)
	//更新登录日志
	err := new(dbmodels.SystemUser).Update(userId, map[string]interface{}{
		"user_last_login_time": now, "user_last_login_ip": ipv4,
	})
	if err != nil {
		utils.LogErrorF("更新登录信息失败:%s", err.Error())
	}
}

//用户状态处理
func userStatusHandler(user *dbmodels.SystemUser) (msg string, err error) {
	t := time.Now().Unix()
	// 判断用户的状态
	if user.BaseModel.Deleted > 0 || user.UserStatus > 5 || (user.UserStatus == 5 && int(t)-user.UserLastLoginTime < 7200) {
		tips := "账号异常,请联系客服工作人员!"
		param, err1 := new(dbmodels.SystemParam).QueryKey(dbmodels.PRAM_KEY_SERVICE_QQ)
		if err1 == nil {
			tips = "该账号已被冻结，如有疑问，请联系客服QQ：" + param["value"] + "!"
		}
		return tips, errors.New("account exception")
	}
	return "", nil
}

//密码登录
func (m *PasswordLogin) Login(c *gin.Context) (r response.UserLoginRep, msg string, err error) {
	m.ipv4 = utils.FuncGetIpv4(c)
	if !utils.FuncVerifyMobile(m.Mobile) {
		return r, "手机号格式错误!", errors.New("mobile err")
	}
	var user dbmodels.SystemUser
	//查询用户
	row, user, err := new(dbmodels.SystemUser).MobileByUser(m.Mobile)
	if err != nil && err != gorm.ErrRecordNotFound {
		return r, "服务器错误", err
	}
	if row == 1 {
		//用户已存在状态下验证
		msg, err = m.UserAlreadyExistsHandler(&user)
		if err != nil {
			return r, msg, err
		}
		return loginHandler(&user, c)
	} else {
		return r, "手机号或密码错误!", errors.New("user not exits")
	}
}

//用户已存在验证
func (m *PasswordLogin) UserAlreadyExistsHandler(user *dbmodels.SystemUser) (msg string, err error) {
	t := time.Now().Unix()
	if user.UserPassword == "" {
		return "您的账号还未设置密码，请登陆账号后在个人中心设置登陆密码。", errors.New("user not set password")
	}
	//记录账号输错密码
	update := make(map[string]interface{})
	update["user_last_login_ip"] = m.ipv4
	//用户密码
	if utils.FuncMD5(m.Password+user.UserSalt) != user.UserPassword {
		if user.UserStatus == 0 {
			update["user_status"] = 1
			update["user_last_login_time"] = t
			msg = "手机号或密码错误,还有4次机会!"
		} else if 0 < user.UserStatus && user.UserStatus < 4 && int(t)-user.UserLastLoginTime <= 300 {
			update["user_status"] = user.UserStatus + 1
			msg = "手机号或密码错误,还有" + strconv.Itoa(4-user.UserStatus) + "次机会!"
		} else if user.UserStatus == 4 && int(t)-user.UserLastLoginTime <= 300 {
			update["user_status"] = 5
			update["user_last_login_time"] = t
			msg = "密码错误多次账号已被锁定,请联系管理员!"
		} else if user.UserStatus < 5 || (user.UserStatus == 5 && int(t)-user.UserLastLoginTime >= 7200) {
			update["user_status"] = 1
			update["user_last_login_time"] = t
			msg = "手机号或密码错误,还有4次机会!"
		} else {
			msg = "手机号或密码错误!"
		}
		err = new(dbmodels.SystemUser).Update(user.UserID, update)
		if err != nil {
			return "服务器错误", err
		}
		return msg, errors.New("user password verification failed")
	}

	//验证账号状态
	msg, err = userStatusHandler(user)
	if err != nil {
		return msg, err
	}

	return "", nil
}

//手机号一键登录
func (m *MobileLogin) Login(c *gin.Context) (r response.UserLoginRep, msg string, err error) {
	//主要渠道
	regChannel, err := strconv.Atoi(c.Request.Header.Get("channel"))
	if err != nil {
		regChannel = 0
	}
	//二级渠道
	regPoint, err := strconv.Atoi(c.Request.Header.Get("subchannel"))
	if err != nil {
		regPoint = 0
	}
	m.ipv4 = utils.FuncGetIpv4(c)

	phoneCode, err := shanyan.SdkWarp{}.QueryPhone(shanyan.ClientType(m.ClientType), m.Token)
	if err != nil {
		return r, "登录失败", fmt.Errorf("get mobile err:%s", err.Error())
	}
	if phoneCode == "" {
		return r, "获取手机号失败", fmt.Errorf("get mobile err:%d,%s", m.ClientType, m.Token)
	}
	var user dbmodels.SystemUser
	if m.Openid == "" {
		//如果没有openid直接登录(创建或者查询)
		userModel := dbmodels.SystemUser{}
		userModel.UserRegChannel = regChannel
		userModel.UserRegPoint = regPoint
		userModel.UserRegPlatform = m.ClientType
		hadUser := true
		hadUser, user, err = userModel.UserLogin(phoneCode, m.ipv4)
		if err != nil {
			return r, "登录失败", err
		}
		if !hadUser { //已经有用户了
			go ADReportRegister(regChannel, c.Request.Header.Get("imei"), c.Request.Header.Get("oaid"), c.ClientIP())
			go liaoyiliao.NewCacheMod().AddGlobalCache(&user)
		}
	} else if m.Openid != "" && m.Opentype > 0 {
		//如果有openid
		//绑定用户信息
		openinfoModel := dbmodels.SystemUserOpeninfo{
			OpeninfoType:   m.Opentype,
			OpeninfoOpenid: m.Openid,
		}
		userOpen, err := openinfoModel.OpenidByUser()
		if err != nil && err == gorm.ErrRecordNotFound {
			return r, "登录失败", fmt.Errorf("query system_user_openinfo err:%s", err.Error())
		}
		//查询用户信息
		userModel := dbmodels.SystemUser{}
		userModel.UserRegChannel = regChannel
		userModel.UserRegPoint = regPoint
		userModel.UserRegPlatform = m.ClientType
		hadUser := true
		hadUser, user, err = userModel.UserLogin(phoneCode, m.ipv4)
		if err != nil && err == gorm.ErrRecordNotFound {
			return r, "登录失败", err
		}
		if !hadUser { //已经有用户了
			go ADReportRegister(regChannel, c.Request.Header.Get("imei"), c.Request.Header.Get("oaid"), c.ClientIP())
			go liaoyiliao.NewCacheMod().AddGlobalCache(&user)
		}
		//如果用户信息为绑定
		if user.UserID != 0 && userOpen.OpeninfoUserID == 0 {
			//手机号已经存在,直接绑定用户信息
			openinfoModel.OpeninfoUserID = user.UserID
			_, err = openinfoModel.UpdateUserInfo(userOpen.OpeninfoID)
			if err != nil {
				return r, "登录失败", fmt.Errorf("update system_user_openinfo err:%s", err.Error())
			}
		} else if user.UserID == 0 && userOpen.OpeninfoUserID == 0 {
			//手机号不存在,openinfo 未绑定
			//按照手机号注册用户信息
			userModel := dbmodels.SystemUser{}
			userModel.UserMobile = phoneCode
			userModel.UserRegIP = m.ipv4
			userModel.UserRegPlatform = m.ClientType
			userModel.UserRegChannel = regChannel
			userModel.UserRegPoint = regPoint
			err = userModel.CreatUser()
			go ADReportRegister(regChannel, c.Request.Header.Get("imei"), c.Request.Header.Get("oaid"), c.ClientIP())
			go liaoyiliao.NewCacheMod().AddGlobalCache(&user)
			if err != nil {
				return r, "登录失败", fmt.Errorf("create system_user err:%s", err.Error())
			}
			//查询用户信息
			_, u, err := userModel.MobileByUser(phoneCode)
			if err != nil {
				return r, "登录失败", fmt.Errorf("query system_user func mobile_by_user err:%s", err.Error())
			}
			openinfoModel.OpeninfoUserID = u.UserID
			_, err = openinfoModel.UpdateUserInfo(userOpen.OpeninfoID)
			if err != nil {
				return r, "登录失败", fmt.Errorf("update system_user_openinfo err:%s", err.Error())
			}
		}
	}

	//用户状态处理
	msg, err = userStatusHandler(&user)
	if err != nil {
		return r, msg, err
	}
	return loginHandler(&user, c)
}

//验证码登录
func (m *SmsCodeLogin) Login(c *gin.Context) (r response.UserLoginRep, msg string, err error) {
	//平台
	clientType, err := strconv.Atoi(c.Request.Header.Get("Client-Type"))
	if err != nil {
		clientType = 0
	}
	//主要渠道
	regChannel, err := strconv.Atoi(c.Request.Header.Get("channel"))
	if err != nil {
		regChannel = 0
	}
	//二级渠道
	regPoint, err := strconv.Atoi(c.Request.Header.Get("subchannel"))
	if err != nil {
		regPoint = 0
	}
	m.ipv4 = utils.FuncGetIpv4(c)
	if !utils.FuncVerifyMobile(m.Mobile) {
		return r, "手机号格式错误", errors.New("mobile err")
	}
	msg, err = m.smsCodeHandler()
	if err != nil {
		return r, msg, err
	}
	userModel := dbmodels.SystemUser{}
	userModel.UserRegChannel = regChannel
	userModel.UserRegPoint = regPoint
	userModel.UserRegPlatform = clientType
	hadUser := true
	hadUser, user, err := userModel.UserLogin(m.Mobile, m.ipv4)
	if !hadUser { //已经有用户了
		go ADReportRegister(regChannel, c.Request.Header.Get("imei"), c.Request.Header.Get("oaid"), c.ClientIP())
		go liaoyiliao.NewCacheMod().AddGlobalCache(&user)
	}
	if err != nil {
		return r, "登录失败", err
	}
	msg, err = userStatusHandler(&user)
	if err != nil {
		return r, msg, err
	}
	return loginHandler(&user, c)
}

//验证码多点登录
func (m *SmsCodeMultiLogin) Login(c *gin.Context) (r response.UserLoginRep, msg string, err error) {
	m.ipv4 = utils.FuncGetIpv4(c)
	if !utils.FuncVerifyMobile(m.Mobile) {
		return r, "手机号格式错误", errors.New("mobile err")
	}
	msg, err = m.smsCodeHandler()
	if err != nil {
		return r, msg, err
	}
	_, user, err := new(dbmodels.SystemUser).MobileByUser(m.Mobile)
	if err != nil {
		return r, "登录失败", err
	}
	msg, err = userStatusHandler(&user)
	if err != nil {
		return r, msg, err
	}
	return loginMultiHandler(&user, c)
}

//验证码处理
func (m *SmsCodeMultiLogin) smsCodeHandler() (msg string, err error) {
	key := utils.REDIS_SMS_CODE + m.Mobile
	//验证验证码
	code, err := utils.RedisClient.Get(key).Int()
	if err != nil && err != redis.Nil {
		return "验证码错误", fmt.Errorf("get code err:%s", err.Error())
	}
	if err != nil && err == redis.Nil {
		return "验证码超时,请重新获取", err
	}
	if m.Code != code {
		return "验证码错误", errors.New("code unequal")
	}
	//删除验证码
	utils.RedisClient.Del(key)
	return "", nil
}

//验证码处理
func (m *SmsCodeLogin) smsCodeHandler() (msg string, err error) {
	key := utils.REDIS_SMS_CODE + m.Mobile
	//验证验证码
	code, err := utils.RedisClient.Get(key).Int()
	if err != nil && err != redis.Nil {
		return "验证码错误", fmt.Errorf("get code err:%s", err.Error())
	}
	if err != nil && err == redis.Nil {
		return "验证码超时,请重新获取", err
	}
	if m.Code != code {
		return "验证码错误", errors.New("code unequal")
	}

	//删除验证码
	utils.RedisClient.Del(key)
	return "", nil
}

//第三方登录
func (m *OpenidLogin) Login(c *gin.Context) (r response.UserLoginRep, msg string, err error) {
	now := time.Now()
	if int64(m.Timestamp) < now.Add(-120*time.Second).Unix() || int64(m.Timestamp) > now.Add(+120*time.Second).Unix() {
		return r, "请检查当前系统时间", errors.New("时间戳非法")
	}

	//openid校验
	ClientKey := utils.Config.App.ClientKey
	sign := utils.FuncMD5(fmt.Sprintf("%s%s%d%s", m.Openid, ClientKey, m.Timestamp, m.Uuid))
	fmt.Println("sign = ", sign)

	if sign != m.Sign {
		return r, "非法请求", errors.New("signature error")
	}

	model := dbmodels.SystemUserOpeninfo{
		OpeninfoType:     m.Opentype,
		OpeninfoOpenid:   m.Openid,
		OpeninfoNickname: m.Nickname,
		OpeninfoGender:   m.Gender,
		OpeninfoIconurl:  m.Iconurl,
		OpeninfoRegIP:    utils.FuncGetIpv4(c),
	}
	openUser, err := model.UserLogin()
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "登录失败", "", err.Error())
		return
	}

	//已绑定用户信息，直接返回登录信息
	r.Nickname = m.Nickname
	r.Gender = m.Gender
	r.Iconurl = m.Iconurl
	r.IsSetInfo = 0

	if openUser.OpeninfoUserID != 0 {
		token, refreshToken, err := middleware.UserToken(openUser.OpeninfoUserID)
		if err != nil {
			return r, "登录失败", fmt.Errorf("create user token err :%s", err.Error())
		}

		r.UserId = openUser.OpeninfoUserID
		r.IsBindMobile = 1

		user, err := new(dbmodels.SystemUser).UserIdByUser(openUser.OpeninfoUserID)
		if err != nil {
			return r, "登录失败", err
		}
		msg, err = userStatusHandler(&user)
		if err != nil {
			return r, msg, err
		}
		if user.UserNickname != "" && user.UserGender > 0 {
			r.IsSetInfo = 1
		}
		r.IsSuper = user.UserIsSuper
		now := time.Now().Unix()
		//当日首次登录标记
		if !ymd.IsSameDay(time.Unix(now, 0), time.Unix(int64(user.UserLastLoginTime), 0)) {
			r.IsFirstOnDay = 1
		}
		//设置登录信息
		c.Header("Access-Token", token)
		c.Header("Refresh-Token", refreshToken)
		go updateLoginInfo(user.UserID, c)
	} else {
		//声明用户未绑定手机号码
		r.IsBindMobile = 0
	}

	return r, "", nil
}
