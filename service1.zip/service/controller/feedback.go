package controller

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/utils"

	"github.com/gin-gonic/gin"
)

// 意见反馈
func FeedbackAdd(c *gin.Context) {
	feedback := request.FeedbackAdd{}
	userId := utils.FuncUserId(c)
	err := c.ShouldBindJSON(&feedback)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	err = services.FeedbackAdd(userId, feedback.FeedbackContent, feedback.FeedbackTerminal, feedback.FeedbackChannel)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "意见反馈成功,感谢您的支持!", "ok")
	return
}
