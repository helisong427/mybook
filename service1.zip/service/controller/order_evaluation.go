package controller

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/models/dbmodels"
	"gamers/utils"
	"gamers/utils/moderation"
	"github.com/gin-gonic/gin"
)

// 根据技能id获取标签
func GetEvaluationLabel(c *gin.Context) {
	req := request.EvaluationLabelReq{}
	err := c.ShouldBind(&req)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	data, err := services.GetSkillLabel(req.SparringSkillId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取评价标签成功", data)
	return
}

// 提交评论
func SubmitEvaluation(c *gin.Context) {
	userId := utils.FuncUserId(c)
	req := request.SubmitEvaluationReq{}
	err := c.ShouldBind(&req)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	// 查询订单并判断状态
	has, orderInfo, err := new(dbmodels.AppSkillOrder).QueryByOrderId(int64(req.CommentOrderId))
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	if has == 0 {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "订单不存在", "", "")
		return
	}

	//if orderInfo.OrderBuyUserId != userId {
	//	response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "非法操作", "", "不属于本人订单")
	//	return
	//}

	// 检测敏感词
	str := moderation.TextModeration(req.CommentContent)
	if len(str) > 0 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "订单评价包含敏感词", "", "")
		return
	}

	if orderInfo.OrderStatus < dbmodels.SKILL_ORDER_STATUS_FINISH || orderInfo.OrderCommentStatus == dbmodels.SKILL_ORDER_COMMENT_STATUS_NO {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "未完成状态不能评价", "", "")
		return
	}

	// 不可重复评价订单
	if orderInfo.OrderCommentStatus == dbmodels.SKILL_ORDER_COMMENT_STATUS_OK {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "不可重复评价订单", "", "")
		return
	}

	Comment := services.NewSkillOrder()
	err = Comment.Comment.SubmitEvaluation(uint64(userId), orderInfo, req)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "提交订单评价失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "提交订单评价成功", "")
	return
}

// 获取订单评价
func GetEvaluation(c *gin.Context) {
	req := request.OrderEvaluationDetailReq{}
	err := c.ShouldBind(&req)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	Comment := services.NewSkillOrder()
	data, err := Comment.GetOrderEvaluationDetail(req.CommentOrderId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "查询当前订单评价有误，请检查订单", "", "")
		return
	}
	response.ResponseOk(c, "获取订单评价成功", data)
}

// 获取订单评价列表
func GetEvaluationList(c *gin.Context) {
	req := request.OrderEvaluationListReq{}
	err := c.ShouldBind(&req)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	if req.CommentFilterLabelId < 0 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "非法的标签筛选", "", "")
		return
	}

	if req.CommentSkillId == 0 {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "非法的订单评价列表", "", "")
		return
	}

	Comment := services.NewSkillOrder()
	data, err := Comment.GetOrderEvaluationList(req)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取订单评价列表错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取订单评价列表成功", data)

}
