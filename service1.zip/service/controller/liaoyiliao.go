package controller

import (
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services/liaoyiliao"
	"gamers/utils"

	"github.com/gin-gonic/gin"
)

//撩一撩列表
func LiaoyiliaoList(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.LiaoyiliaoListReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}

	var list liaoyiliao.UserList
	if paramsJSON.RegOffSet == nil {
		// 老版本获取撩一撩列表,TODO:新版本上线以后删除
		list, err = liaoyiliao.NewCacheMod().UserList(paramsJSON.OffSet, -1, userId, 10)
	} else {
		list, err = liaoyiliao.NewCacheMod().UserList(paramsJSON.OffSet, *paramsJSON.RegOffSet, userId, 10)
	}
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取数据失败", "", err.Error())
		return
	}

	response.ResponseOk(c, "获取撩一撩列表成功", list)
}

//撩一撩发送
func LiaoyiliaoSend(c *gin.Context) {
	paramsJSON := request.LiaoyiliaoSendReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	err = liaoyiliao.NewCacheMod().DecreaseUserNum(paramsJSON.UserId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "撩一撩发送失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "ok", nil)
}

//撩一撩初始化(上线后删除)
func LiaoyiliaoInit(c *gin.Context) {
	paramsJSON := request.LiaoyiliaoInitReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误", "", err.Error())
		return
	}
	l := liaoyiliao.NewCacheMod()
	if paramsJSON.Action == "init" {
		l.InitGlobalCache()
	}
	if paramsJSON.Action == "change" {
		l.RepCacheData()
	}

	response.ResponseOk(c, paramsJSON.Action+" ok", nil)
}
