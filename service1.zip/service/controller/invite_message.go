package controller

import (
	"errors"
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/utils"
	"unicode/utf8"

	"github.com/gin-gonic/gin"
)

// InviteMessageQuery 查询用户撩一撩邀请消息状态
func InviteMessageQuery(c *gin.Context) {
	userID := utils.FuncUserId(c)
	data, err := services.InviteMessageQuery(userID)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "获取撩一撩邀请消息失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取撩一撩邀请消息成功", &data)
}

// InviteMessageAdd 提交用户的撩一撩邀请消息给后台审核
func InviteMessageAdd(c *gin.Context) {
	userID := utils.FuncUserId(c)
	paramsJSON := request.InviteMessageReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "参数错误", "", err.Error())
		return
	}

	// 检查撩一撩邀请消息长度
	if err = check(paramsJSON.Content); err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "参数错误", "", err.Error())
		return
	}
	reviewID, err := services.InviteMessageAdd(userID, paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "提交审核失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "提交审核成功", map[string]interface{}{
		"review_id": reviewID,
	})
}

// InviteMessageEdit 修改用户撩一撩的邀请消息
func InviteMessageEdit(c *gin.Context) {
	userID := utils.FuncUserId(c)
	paramsJSON := request.InviteMessageReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "参数错误", "", err.Error())
		return
	}
	// 检查撩一撩邀请消息长度
	if err = check(paramsJSON.Content); err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "参数错误", "", err.Error())
		return
	}
	err = services.InviteMessageEdit(userID, paramsJSON)
	if err != nil {
		if err == services.ErrInviteMessageEdited {
			response.ResponseError(c, response.RESPONSE_Invite_Message_Edit_StatusERROR, "提交审核失败", "", err.Error())
			return
		}
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "提交审核失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "提交审核成功", nil)
}

// 检查邀请消息的长度
func check(content string) error {
	l := utf8.RuneCountInString(content)
	if l < 5 || l > 50 {
		utils.LogErrorF("审核内容长度非法")
		return errors.New("审核内容长度非法")
	}
	return nil
}
