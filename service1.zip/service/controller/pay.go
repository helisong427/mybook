package controller

import (
	"encoding/json"
	"errors"
	"fmt"
	"gamers/controller/request"
	"gamers/controller/response"
	"gamers/controller/services"
	"gamers/enum"
	"gamers/models/dbmodels"
	"gamers/utils"
	"github.com/gin-gonic/gin"
	"strconv"
)

// 充值参数
func RechargeParameters(c *gin.Context) {
	userId := utils.FuncUserId(c)
	clientType := c.Request.Header.Get("Client-Type")
	client, err := strconv.Atoi(clientType)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}
	r, err := services.RechargeParameters(userId, client)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取充值参数成功", r)
	return
}

// 网页充值参数
func WebRechargeParameters(c *gin.Context) {
	r, err := services.RechargeParameters(0, 3)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "服务器错误", "", err.Error())
		return
	}
	response.ResponseOk(c, "获取充值参数成功", r)
	return
}

// 微信App下单
func AppPlaceOrderWechat(c *gin.Context) {
	userId := utils.FuncUserId(c)
	ip := c.ClientIP()
	paramsJSON := request.PlaceOrderReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}
	// 检查用户状态
	userErr := userPayStatusCheck(userId)
	if userErr != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, userErr.Error(), "", "")
	}
	// 查询充值金额
	cash := paramsJSON.Cash
	if !cashMinCheck(cash) {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "充值金额错误", "", "")
		return
	}
	amount := cash * 10
	if !utils.FuncEnv() {
		cash = 1 //改为1分
	}

	lock := fmt.Sprintf("%s%d", utils.REDIS_USER_PLACE_ORDER_LOCK, userId)
	lockVal, lockBool := utils.AcquireLock(lock, 1, 1)
	if !lockBool {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "稍后再试", "", "")
		return
	}
	defer utils.ReleaseLock(lock, lockVal)

	r, err := services.PlaceOrderWechat(amount, cash, paramsJSON.FromSystem, paramsJSON.FromWay, ip, userId, enum.APP_PAY)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "下单失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "下单成功", r)
	return
}

// 微信网页下单
func WapPlaceOrderWechat(c *gin.Context) {
	ip := c.ClientIP()
	paramsJSON := request.WapPlaceOrderWechatReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}

	// 检查用户状态
	userErr := userPayStatusCheck(paramsJSON.UserId)
	if userErr != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, userErr.Error(), "", "")
	}
	// 查询充值金额
	cash := paramsJSON.Cash
	if !cashMinCheck(cash) {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "充值金额错误", "", "")
		return
	}
	amount := cash * 10
	if !utils.FuncEnv() {
		cash = 1 //改为1分
	}

	lock := fmt.Sprintf("%s%d", utils.REDIS_USER_PLACE_ORDER_LOCK, paramsJSON.UserId)
	lockVal, lockBool := utils.AcquireLock(lock, 1, 1)
	if !lockBool {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "稍后再试", "", "")
		return
	}
	defer utils.ReleaseLock(lock, lockVal)

	r, err := services.PlaceOrderWechat(amount, cash, paramsJSON.FromSystem, paramsJSON.FromWay, ip, paramsJSON.UserId, enum.WAP_PAY)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "下单失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "下单成功", r)
	return
}

// 微信公众号下单
func JsapiPlaceOrderWechat(c *gin.Context) {
	ip := c.ClientIP()
	paramsJSON := request.JsapiPlaceOrderWechat{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}

	// 检查用户状态
	userErr := userPayStatusCheck(paramsJSON.UserId)
	if userErr != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, userErr.Error(), "", "")
	}
	// 查询充值金额
	cash := paramsJSON.Cash
	if !cashMinCheck(cash) {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "充值金额错误", "", "")
		return
	}
	amount := cash * 10
	if !utils.FuncEnv() {
		cash = 1 //改为1分
	}

	lock := fmt.Sprintf("%s%d", utils.REDIS_USER_PLACE_ORDER_LOCK, paramsJSON.UserId)
	lockVal, lockBool := utils.AcquireLock(lock, 1, 1)
	if !lockBool {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "稍后再试", "", "")
		return
	}
	defer utils.ReleaseLock(lock, lockVal)

	r, err := services.PlaceOrderWechatJsapi(amount, cash, paramsJSON.FromSystem, paramsJSON.FromWay, paramsJSON.UserId, ip, paramsJSON.Openid)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "下单失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "下单成功", r)
	return
}

// 支付宝App下单
func AppPlaceOrderAlipay(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.PlaceOrderReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}

	// 检查用户状态
	userErr := userPayStatusCheck(userId)
	if userErr != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, userErr.Error(), "", "")
	}
	// 查询充值金额
	cash := paramsJSON.Cash
	if !cashMinCheck(cash) {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "充值金额错误", "", "")
		return
	}
	amount := cash * 10
	if !utils.FuncEnv() {
		cash = 1 //改为1分
	}

	lock := fmt.Sprintf("%s%d", utils.REDIS_USER_PLACE_ORDER_LOCK, userId)
	lockVal, lockBool := utils.AcquireLock(lock, 1, 1)
	if !lockBool {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "稍后再试", "", "")
		return
	}
	defer utils.ReleaseLock(lock, lockVal)

	r, err := services.PlaceOrderAlipay(amount, cash, paramsJSON.FromSystem, paramsJSON.FromWay, userId, enum.APP_PAY)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "下单失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "下单成功", r)
	return
}

// 支付宝网页下单
func WapPlaceOrderAlipay(c *gin.Context) {
	paramsJSON := request.WapPlaceOrderAlipayReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}

	// 检查用户状态
	userErr := userPayStatusCheck(paramsJSON.UserId)
	if userErr != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, userErr.Error(), "", "")
	}
	// 查询充值金额
	cash := paramsJSON.Cash
	if !cashMinCheck(cash) {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "充值金额错误", "", "")
		return
	}
	amount := cash * 10
	if !utils.FuncEnv() {
		cash = 1 //改为1分
	}

	lock := fmt.Sprintf("%s%d", utils.REDIS_USER_PLACE_ORDER_LOCK, paramsJSON.UserId)
	lockVal, lockBool := utils.AcquireLock(lock, 1, 1)
	if !lockBool {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "稍后再试", "", "")
		return
	}
	defer utils.ReleaseLock(lock, lockVal)

	r, err := services.PlaceOrderAlipay(amount, cash, paramsJSON.FromSystem, paramsJSON.FromWay, paramsJSON.UserId, enum.WAP_PAY)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "下单失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "下单成功", r)
	return
}

// 苹果app支付下单
func PlaceOrderApplePay(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.ApplePlaceOrderReq{}
	clientType := c.Request.Header.Get("Client-Type")
	client, err := strconv.Atoi(clientType)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}
	if client != enum.USER_CLIENT_TYPE_IOS {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", "非iOS设备无法调用")
		return
	}
	err = c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}

	// 检查用户状态
	userErr := userPayStatusCheck(userId)
	if userErr != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, userErr.Error(), "", "")
	}
	// 查询充值金额
	amount, cash := checkRechargeParams(paramsJSON.ProductId, dbmodels.PRAM_KEY_RECHARGE_IOS)
	if amount == 0 || cash == 0 {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "充值参数错误", "", "")
		return
	}

	lock := fmt.Sprintf("%s%d", utils.REDIS_USER_PLACE_ORDER_LOCK, userId)
	lockVal, lockBool := utils.AcquireLock(lock, 1, 1)
	if !lockBool {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "稍后再试", "", "")
		return
	}
	defer utils.ReleaseLock(lock, lockVal)

	r, err := services.PlaceOrderApplePay(amount, cash, paramsJSON.ProductId, userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "下单失败", "", err.Error())
		return
	}

	response.ResponseOk(c, "下单成功", r)
	return
}

// 苹果支付收据验证
func ApplePayVerifyReceipt(c *gin.Context) {
	userId := utils.FuncUserId(c)
	paramsJSON := request.ApplePayVerifyReceiptReq{}
	err := c.ShouldBindJSON(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}
	// 检查用户状态
	userErr := userPayStatusCheck(userId)
	if userErr != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, userErr.Error(), "", "")
	}

	// 查询充值金额
	amount, cash := checkRechargeParams(paramsJSON.ProductId, dbmodels.PRAM_KEY_RECHARGE_IOS)
	if amount == 0 || cash == 0 {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "充值参数错误", "", "")
		return
	}

	walletTotalOver, err := services.ApplePayVerifyReceipt(paramsJSON.ProductId, paramsJSON.OutTradeNo, paramsJSON.TransactionId, paramsJSON.ReceiptData, userId)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "收据验证失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "验证成功", gin.H{"user_buy_over": walletTotalOver})
	return
}

// 支付结果查询
func PayResultQuery(c *gin.Context) {
	paramsJSON := request.PayResultQueryReq{}
	err := c.ShouldBind(&paramsJSON)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_PARAM_ERROR, "参数错误!", "", err.Error())
		return
	}
	r, err := services.PayResultQuery(paramsJSON.OutTradeNo)
	if err != nil {
		response.ResponseError(c, response.RESPONSE_BUSINESS_ERROR, "支付结果查询失败", "", err.Error())
		return
	}
	response.ResponseOk(c, "支付结果查询成功", r)
	return
}

// 检查用户状态
func userPayStatusCheck(userId int64) error {
	user, err := new(dbmodels.SystemUser).UserIdByUser(userId)
	if err != nil {
		return errors.New("用户不存在!")
	}
	if user.UserStatus >= dbmodels.USER_STATUS_LOCK {
		return errors.New("该用户暂时无法充值!")
	}
	return nil
}

func checkRechargeParams(productId string, rechargeKey string) (amount int64, cash int64) {
	if productId == "" || rechargeKey == "" {
		return 0, 0
	}
	param, err := new(dbmodels.SystemParam).QueryKey(rechargeKey)
	if err != nil {
		return 0, 0
	}
	rechargeParams := []dbmodels.RechargeParams{}
	err = json.Unmarshal([]byte(param["value"]), &rechargeParams)
	if err != nil {
		return amount, cash
	}
	for _, v := range rechargeParams {
		if v.Id == productId {
			return v.Token, v.Cash
		}
	}
	return 0, 0
}

// 金额最小值检查(最低充值1元)
func cashMinCheck(cash int64) bool {
	if cash < 100 || cash%100 != 0 { //不能只能整元充值
		return false
	}
	return true
}
